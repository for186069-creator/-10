# Аудит Limitless FAST_FLAT v1.0.161

## Висновок

Для депозиту $10–25 найреалістичніший режим цього коду — один короткий цикл:
maker BUY → підтверджений fill → exact-size maker SELL → контрольований full-depth
FAK лише за net-profit або в межах заданого loss budget. Одночасні legacy,
multi-level, hedge та arb execution у цьому режимі вимкнені.

Це не «беззбиткова» система. Неможливо одночасно гарантувати нуль збитку,
миттєвий вихід і безкінечне повторення: якщо доступна ціна нижча за loss budget,
бот лишає maker SELL, тому позиція все ще може дійти до resolution.

## Що виправлено

- Exchange acceptance більше не рахується fill; баланс змінює лише confirmed
  cumulative execution, повторний status є idempotent.
- Partial remainder спершу cancel-иться до terminal; нова нога до цього не
  відкривається.
- FAK перевіряє повну top-level depth, taker fee, gas і net PnL.
- LIVE balance, allowance, Base chain, CLOB positions та Base ETH gas reserve
  перевіряються fail-closed.
- Кожен Limitless submit записується за `clientOrderId` до HTTP call. Timeout,
  duplicate 409, rate-limit, maintenance і malformed response не забуваються.
- Clean shutdown/LIVE→PAPER не підтверджуються, доки всі recorded orders не
  видимі LIVE або не мають exact order-level terminal evidence.
- FAST_FLAT discovery, refill і entry використовують єдиний spread band 2–5¢;
  REST book старший за 3 секунди не використовується для entry або exit pricing.
- Виправлено фактичний LIVE blocker у EIP-712 виклику `eth-account`.

## Що ще не реалізовано

- Delegated signing для Limitless smart/server wallet. Поточний LIVE — лише
  окремий external EOA; ключ з основними коштами використовувати не можна.
- Автоматичний redeem/merge та підтверджене повернення collateral після
  resolution. До цього resolved LIVE inventory потребує ручного контролю.
- Limitless Socket.IO/WebSocket orderbook. Є REST polling 1.5 s і строгий
  freshness gate 3 s, але це повільніше за справжній low-latency feed.
- Автоматичне бухгалтерське відновлення fill у надзвичайно вузькому crash-window
  між HTTP submit та реєстрацією order у MM. Position-drift preflight це виявить
  і заблокує нову торгівлю, але reconciliation буде ручним.
- Production acceptance evidence: немає 5–7 днів FAST_FLAT PAPER статистики та
  немає supervised мінімального LIVE round trip.

## Безпечний старт $10–25

Використовувати `FAST_FLAT.env.example`, залишити `PAPER_TRADING=true` та
`AUTO_START_TRADING=false`. Базовий профіль: $2 на цикл, мінімум $5/40% cash
reserve, один ринок і одна позиція, target $0.02, rescue 90 s, max loss $0.05,
daily loss $0.50.

До LIVE потрібні: окремий EOA, невеликий Base ETH reserve, USDC/allowance,
порожній або reconciled order-scope ledger, нуль wallet/DB position drift і
ручне підтвердження checklist. Перший LIVE запуск — тільки під наглядом і з
мінімальним ордером; unattended LIVE поки не рекомендований.

