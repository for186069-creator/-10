# Argo backup

- Source: `C:\Users\w\Argo`
- Destination: `C:\Users\w\Argo2`
- Snapshot copied: **2026-07-17 08:41:40 UTC**
- Files copied: **382**
- Size at copy: **56,469,928 bytes**
- `paper_v1_0_165.db`: SQLite integrity check `ok`
- `paper_order_metrics_v1_0_165.db`: SQLite integrity check `ok`
- Source Argo was paused while files were copied and resumed afterwards.

Do not run this backup concurrently with the primary Argo instance: its copied
`.env` uses the same port (`8765`), database names and external credentials.

