# CHANGELOG v1.0.161 — FAST_FLAT і безпечний Limitless lifecycle

## Що виправлено

- Прийняття ордера більше не вважається виконанням. Баланс і позиція змінюються
  тільки за підтвердженим кумулятивним fill; повторний status не кредитує його двічі.
- Cancel ACK не видаляє ордер із контролю: бот чекає термінального статусу.
- Ручний `/exit_all` більше не зараховує прийнятий FAK як повний fill. Його GTC
  реєструється у спільному lifecycle, а fallback дозволений лише після terminal cancel.
- Shutdown і LIVE→PAPER вимагають підтвердженого порожнього open-order snapshot;
  при невизначеності режим не перемикається, а `RUNNING.lock` лишається для recovery.
- Частковий fill у FAST_FLAT одразу скасовує залишок і не відкриває наступну ногу,
  доки скасування не підтверджене.
- BUY/SELL обліковуються окремими token/cash delta з урахуванням fee; PAPER settlement
  став атомарним та ідемпотентним. LIVE resolved-позиція не кредитується до фактичного
  redeem/balance confirmation.
- Limitless positions розбираються зі справжнього `clob` payload і raw 6-decimal
  balances. Невідомий або несумісний payload зупиняє LIVE.

## Фінальний lifecycle-аудит

- Виправлено LIVE EIP-712 signing: `encode_typed_data(full_message=...)` для
  встановленої версії `eth-account`.
- Persistent scope тепер зберігає кожен `clientOrderId` до HTTP submit. Timeout,
  409, 429, 5xx, maintenance і malformed response лишаються unresolved; один
  порожній market snapshot більше не може приховати відкладений ордер.
- Clean shutdown вимагає exact batch reconciliation кожного scope-record.
  GTC видаляється лише за order-level terminal evidence, а не через settlement
  окремого partial fill.
- FAST_FLAT discovery та auto-refill використовують той самий spread band 2–5¢.
  Entry, maker reprice і FAK exit блокуються, якщо REST book старший за 3 секунди.
- External EOA preflight додатково перевіряє мінімальний Base ETH gas reserve.

## FAST_FLAT

- Один активний токен і один цикл на весь бот; усереднення та ротація відкритої
  позиції заборонені.
- Maker BUY лише за spread 2–5¢, достатньої top-depth, запасу часу і cash reserve.
- Вихід exact-size maker SELL. FAK дозволений тільки на повну top-level depth,
  за досягнутого net target або після rescue timer у межах loss budget.
- Вихід продовжує працювати під risk halt; нові входи при halt заборонені.

## LIVE preflight

- LIVE bankroll більше ніколи не підміняється PAPER-балансом або нулем після API error.
- Перед стартом перевіряються Base chain, реальний USDC `balanceOf`, allowance саме
  для venue spender і CLOB-позиції.
- Поточний signer — тільки EOA (`signatureType=0`). Limitless smart/server wallet
  навмисно блокується до реалізації delegated signing.
- LIVE вимагає окремий bot-only EOA (`LIMITLESS_DEDICATED_EOA=true`). Перед кожним
  submit slug атомарно пишеться в `.limitless_order_scope.json`, тому restart і
  shutdown перевіряють також ринки, які вже вибули з поточної ротації.
- Додано безпечний профіль `FAST_FLAT.env.example`; `.env` користувача не змінювався.

## Обмеження

FAST_FLAT не гарантує беззбитковість. Якщо досяжний вихід гірший за loss budget,
бот лишає maker SELL і позиція може зависнути. Це свідомий компроміс між швидкістю
та обмеженням збитку.
