# CHANGELOG v1.0.162 — PAPER readiness hardening

## Changes

- Updated the active `.env` profile to PAPER/FAST_FLAT and pinned the dashboard to `127.0.0.1:8765`.
- Disabled automatic trading and all legacy execution layers in the active PAPER profile.
- Isolated v1.0.162 PAPER state in fresh SQLite databases so historical v1.0.161 inventory is not restored accidentally.
- FastAPI/OpenAPI now reads the release version from the `VERSION` file instead of reporting stale `1.0.0`.
- Pytest environment is isolated from the production `.env`; the suite is deterministic with the PAPER profile enabled.
- Set pytest asyncio fixture scope explicitly, removing the deprecation/thread-shutdown warning.
- Removed the stale runtime lock from the distributable copy.

## Verification

- `279 passed, 4 skipped, 0 failed`. One intermittent Python 3.13/aiosqlite shutdown warning can appear after the suite; it does not fail a test.
- PAPER web service starts on port `8765`.
- `/health` returns `status=ok`.
- `/openapi.json` reports version `1.0.162`.
- External Limitless market discovery could not be verified in the isolated build environment because outbound DNS was unavailable.

## Safety

- `PAPER_TRADING=true`.
- `AUTO_START_TRADING=false`.
- LIVE was not enabled or exercised.
