# CHANGELOG v1.0.163 — final PAPER acceptance

## PAPER lifecycle

- Added automatic PAPER complete-set merge for matched YES/NO balances.
- Added automatic, idempotent PAPER redeem for resolved outcome tokens.
- Added explicit audit paths: `PAPER_COMPLETE_SET_MERGE` and `PAPER_REDEEM`.
- Preserved unmatched inventory during a partial complete-set merge.
- Kept all LIVE merge/redeem behavior disabled; no on-chain claim is made.

## Recovery and acceptance coverage

- Added deterministic offline acceptance tests for:
  - profitable maker-maker round trip;
  - partial entry cancellation and exact-token exit;
  - stale restored-position gating and recovery;
  - SQLite inventory restore after a dirty restart lock;
  - complete-set merge and repeat-call idempotency;
  - winning and losing resolved-token redeem;
  - stale entry-order TTL cancellation;
  - partial exit cancellation and exact-remainder replacement;
  - full-depth FAK rescue inside the configured loss budget.
- Added `scripts/run_paper_acceptance.py` for repeatable acceptance execution.
- Disposed the shared async database engine after tests, eliminating the
  Python 3.13/aiosqlite shutdown warning.

## Runtime reliability

- Removed the application-level SIGINT/SIGTERM override that prevented Uvicorn
  from entering lifespan shutdown. A termination signal now reaches
  `shutdown_initiated`, persists PAPER state, removes the runtime lock, closes
  services/databases, and reaches `shutdown_complete`.

## Configuration and release

- Synchronized `VERSION`, `pyproject.toml`, `.env`, README, and API metadata at
  v1.0.163.
- Pinned the PAPER dashboard to `127.0.0.1:8765`.
- Moved v1.0.163 to fresh PAPER and metrics database paths.
- Kept `PAPER_TRADING=true` and `AUTO_START_TRADING=false`.

## Verification

- Full suite: **291 passed, 4 skipped, 0 failed**.
- PAPER acceptance: **10 passed, 0 failed**.
- See `PAPER_TEST_REPORT_v1.0.163.md` for commands, scope, and limitations.
