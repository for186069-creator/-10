# CHANGELOG v1.0.164 — maker-first PAPER stabilization

Date: 2026-07-16

## Fixed

### Entry cancel/requote churn

- Replaced the old unconditional 3-second entry TTL with a maker-preserving policy.
- A resting entry is now cancelled only when:
  - the book moved materially by at least `FAST_FLAT_ENTRY_REQUOTE_THRESHOLD_CENTS` after `FAST_FLAT_ENTRY_REQUOTE_SEC`;
  - the market became invalid/unsafe for FAST_FLAT; or
  - the hard `FAST_FLAT_ENTRY_TTL_SEC` safety cap expires.
- Default PAPER profile:
  - minimum rest: 15 seconds;
  - material move: 1.0 cent;
  - hard TTL: 300 seconds.
- On an unchanged book the hard-TTL ceiling is therefore 12 planned entry refreshes per hour, rather than the observed 480 placements/hour in v1.0.163.

### FAK dependency

- Profitable taker/FAK exits are disabled by default with
  `FAST_FLAT_PROFIT_FAK_ENABLED=false`.
- Normal completion remains maker-first.
- Controlled FAK is retained only as an emergency full-depth escape path after
  `FAST_FLAT_RESCUE_AFTER_SEC=900`, and still must remain inside
  `FAST_FLAT_LOSS_BUDGET_USDC`.
- Maker exits now rest longer:
  - minimum repricing interval: 60 seconds;
  - material exit move: 0.5 cent;
  - hard max age: 300 seconds.

### Empty network error messages

- `limitless_request_failed` now records:
  - HTTP method and safe path;
  - exception type;
  - a non-empty message using `repr()` fallback;
  - elapsed request time;
  - retryability classification.
- Timeout, aiohttp client errors, generic exceptions, and invalid JSON responses
  now return structured error codes instead of an uninformative `None`.
- Credentials, signatures, auth headers, and request bodies are not logged.

## Tests added

- Stable entry remains working after the former three-second churn window.
- Material one-cent movement triggers controlled entry replacement.
- Profitable full-depth exit stays maker-first by default.
- Profitable FAK requires explicit opt-in.
- Loss-budget FAK cannot run before the 900-second emergency window.
- Timeout logging always contains a useful exception type and message.

## Configuration / release

- Version synchronized to `1.0.164`.
- PAPER database paths moved to `paper_v1_0_164.db` and
  `paper_order_metrics_v1_0_164.db`.
- LIVE remains disabled; no real order was submitted.
