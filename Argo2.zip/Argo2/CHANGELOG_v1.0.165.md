# CHANGELOG v1.0.165 — whole-cycle profitable FAK completion

Date: 2026-07-16

## Corrected FAK accounting

- Re-enabled profitable full-depth FAK by default.
- A profitable FAK is now evaluated against the projected NET P&L of the
  complete FAST_FLAT round trip, not the P&L of the remaining taker leg alone.
- The cycle records its bankroll before the first entry. The FAK gate projects:

  `current bankroll + conservative net cash from remaining FAK SELL - cycle-start bankroll`

- `current bankroll` already includes:
  - the entry cash outflow;
  - prior maker SELL proceeds;
  - realized partial-fill P&L;
  - fees and gas already paid.
- The remaining FAK estimate additionally includes:
  - Limitless taker fee;
  - one exit gas charge;
  - `FAST_FLAT_PROFIT_FAK_SLIPPAGE_CENTS` safety buffer.
- The FAK is permitted only when the projected whole-cycle net result is at
  least `FAST_FLAT_TARGET_PROFIT_USDC`.

This allows the intended behavior: a final FAK leg may be slightly negative by
itself when earlier maker fills earned more, provided the entire round trip
still closes above the configured net-profit floor.

## Timing and safety

- Profitable FAK is enabled with `FAST_FLAT_PROFIT_FAK_ENABLED=true`.
- The maker exit receives a 90-second opportunity window before profitable FAK
  may cancel it: `FAST_FLAT_PROFIT_FAK_AFTER_SEC=90`.
- Full top-of-book depth remains mandatory for the entire remaining position.
- Stale-book protection remains mandatory.
- Emergency controlled-loss rescue remains separate at 900 seconds and still
  obeys `FAST_FLAT_LOSS_BUDGET_USDC`.
- The entry anti-churn controls from v1.0.164 remain unchanged.

## Restart recovery

- FAST_FLAT cycle ID and cycle-start bankroll are persisted with open PAPER
  inventory.
- After restart, the bot can continue evaluating profitable FAK against the
  original whole-cycle bankroll baseline.
- Older saved positions without this baseline fail closed for profitable FAK
  and retain only the emergency rescue path.

## Logging

- Added `fast_flat_profitable_fak_armed` with safe audit fields:
  projected cycle P&L, projected final bankroll, cycle-start bankroll,
  remaining tokens, best bid and conservative expected FAK price.
- No credentials, headers, signatures or request bodies are logged.

## Tests

- Added a regression case where the final FAK leg loses one cent but earlier
  maker fills leave the whole cycle +$0.14; FAK must complete the cycle.
- Added the inverse case: FAK is blocked when the whole cycle remains below the
  target.
- Added persistence assertions for cycle ID and cycle-start bankroll.
- Existing maker-window, full-depth, stale-book, loss-budget and PAPER
  acceptance tests remain active.

## Release

- Version synchronized to `1.0.165`.
- PAPER database paths moved to `paper_v1_0_165.db` and
  `paper_order_metrics_v1_0_165.db`.
- LIVE remains disabled and was not exercised.
