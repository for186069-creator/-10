# Argo handoff — v1.0.165 PAPER whole-cycle FAK completion

## Current mode

- Exchange: Limitless
- Mode: PAPER only
- Strategy: FAST_FLAT
- Dashboard: http://127.0.0.1:8765
- Auto-start trading: disabled
- Active PAPER database: `paper_v1_0_165.db`
- Metrics database: `paper_order_metrics_v1_0_165.db`

## Completed PAPER roadmap

- Environment restored from the repository requirements.
- Full unit/integration suite passes without failures or shutdown warnings.
- Deterministic offline PAPER acceptance covers maker entry/exit, partial entry,
  partial exit replacement, stale-book protection, stale entry TTL cancellation,
  full-depth FAK rescue, crash/restart inventory recovery, complete-set merge,
  and resolved-token redeem.
- Complete-set merge consumes only matched YES/NO balances, credits $1 per set,
  preserves unmatched inventory, records realized P&L once, and is idempotent.
- Resolved PAPER inventory is redeemed exactly once and persisted with the
  `PAPER_REDEEM` exit path.
- The active `.env` is pinned to PAPER, FAST_FLAT, paused startup, and port 8765.
- Release metadata is synchronized at v1.0.165.

## Verification result

- Full suite: **297 passed, 4 skipped, 0 failed**.
- Focused whole-cycle FAK + PAPER acceptance: **32 passed, 0 failed**.
- Python bytecode compilation: passed.
- Focused Python lint (fatal/import checks): passed.
- Dashboard JavaScript syntax check: passed.
- API health, dashboard, OpenAPI v1.0.165, and graceful shutdown: passed.

The four skipped tests are documented stale short-selling tests. PAPER correctly
clamps selling beyond owned outcome-token balance, matching venue behavior.

## Operational rule

Do not switch to LIVE. Start the process while paused, wait for Limitless markets
and fresh books to appear, inspect diagnostics, and only then use Start Trading.

## Start on Windows

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m uvicorn app.main:app --host 127.0.0.1 --port 8765
```

Open: http://127.0.0.1:8765

## Still requires operator-machine evidence

- External Limitless API/market-feed connectivity could not be proven in the
  isolated build environment. The deterministic acceptance suite does not
  replace observing real public market data on the operator machine.
- A multi-day PAPER observation period has not been performed here.
- LIVE delegated smart-wallet signing and LIVE on-chain merge/redeem remain out
  of scope and fail-closed/manual. LIVE was not enabled or exercised.

## v1.0.165 cycle-completion correction

- Entry cancel/requote churn is bounded by 15s minimum rest, 1.0c material move and 300s hard TTL.
- Profitable FAK is enabled after a 90s maker window only when projected NET P&L for the whole cycle remains above target.
- Cycle-start bankroll and cycle ID are persisted for restart-safe accounting.
- Emergency controlled-loss rescue remains separate at 900s.
- Exit repricing uses 60s minimum rest, 0.5c material move and 300s max age.
- Limitless network failures now log exception type, non-empty message and elapsed time.
- LIVE remains disabled.
