# Handoff to Claude: Argo/GPT bot current state

Snapshot captured: **2026-07-17 08:29:10 UTC**  
Scope: **Argo/GPT bot only, `C:\Users\w\Argo`, port 8765**

This is an informational handoff. Do not reset, restart, reconfigure or edit
Argo unless Jiji explicitly asks you to do so. In particular, do not combine
its database or match history with another bot.

## Runtime state

- Process: PID **3520**, `python -m app.main`, autorestart watchdog active.
- Mode: **PAPER**, strategy `fast_flat`, trading running.
- `trading_paused=false`, `halted=false`, `degraded=false`, crash-recovery
  badge clear.
- Bankroll/equity: **$25.00**; inventory **$0**; realized/unrealized PnL **$0**;
  fees/gas **$0**.
- Session: **0 fills, 0 completed cycles, 0 open positions**.
- Three active entry quotes, total notional **$3 = 3 x $1**, on
  `Oil (UKOILSPOT) Up or Down - Daily`:
  - L1 bid `0.1250`
  - L2 bid `0.1255`
  - L3 bid `0.1260`
  - snapshot market bid/ask `0.1240 / 0.2150`
- A second qualified candidate, `TRX Up or Down - Daily`, is tracked, but
  fast_flat deliberately owns only one working market/position at a time.
- At the snapshot: `limitless_public_trade_seq=0`, buffered public trades `0`.
  This is expected: historical feed rows seeded deduplication and no new
  `NEW_TRADE` had arrived after startup. It is not evidence of a dead feed.

Runtime endpoints:

- health: `GET http://127.0.0.1:8765/health`
- state/quotes: `GET http://127.0.0.1:8765/api/quotes`
- dashboard: `GET http://127.0.0.1:8765/api/dashboard`
- markets: `GET http://127.0.0.1:8765/api/markets`

## Current PAPER fill evidence

Argo no longer treats a touched price or disappearing orderbook depth as a
Limitless maker fill. Limitless depth can disappear because of cancellation.

The conservative Limitless path now polls the official per-market
`NEW_TRADE` feed and uses:

- `bodyHash`/transaction deduplication;
- actual contract volume and event timestamp;
- aggressor `Buy`/`Sell` direction;
- YES/NO normalization to the YES orderbook (for example, BUY NO becomes the
  equivalent SELL YES at the complementary price);
- quote placement timestamp and price eligibility;
- visible queue-ahead consumption;
- price/time allocation across L1-L3, so one trade cannot be counted once at
  every level.

Old events seed the cursor and are never replayed into new quotes. A qualifying
PAPER fill is stored as `fill_verification=inferred` with evidence source
`limitless_new_trade_after_queue`. It is stronger evidence than a book-only
simulation, but still not `verified`: only a LIVE exchange receipt for our own
real order can prove our exact execution.

The official public Socket.IO protocol exposes full `orderbookUpdate` events,
not anonymous trade events. The market-wide trade data comes from the official
signed endpoint:
`GET /markets/{slug}/get-feed-events`, which returns `NEW_TRADE`, contracts,
strategy, outcome, timestamp and transaction hash.

## Important configuration

- `ADMIN_PORT=8765`
- `PAPER_TRADING=true`, `PAPER_BALANCE_USDC=25`
- `PAPER_FILL_MODEL=conservative`
- `STRATEGY_MODE=fast_flat`
- `FAST_FLAT_ORDER_SIZE_USDC=3.0`
- `FAST_FLAT_MULTILEVEL_ENABLED=true`, count `3`
- `LIMITLESS_MIN_ORDER_USDC=1.0`
- BUY ladder hardcoded from market bid: `+0.0010`, `+0.0015`, `+0.0020`
- SELL ladder after inventory, from market ask: `-0.0010`, `-0.0015`,
  `-0.0020`
- entry and exit repricing: minimum rest `1.5s`, anchor move at least `0.001`
- broader-market option enabled, target `3`; fast_flat remains single-owner
- dedicated 15-minute profile enabled
- profit FAK: after `90s`, final cycle must retain target profit, leg loss
  `<= $0.05`, loss `<=25%` of prior maker profit, remainder `<=20%`, and full
  visible depth is required
- rescue remains a separate exit path
- database: `paper_v1_0_165.db`

## Completed fix set

1. Match #1 frozen as unfinished/stopped at approximately 24 hours.
2. Dual FAK protection implemented.
3. Durable cycle IDs and distinct profit/rescue accounting implemented.
4. PAPER evidence classification and conservative PnL implemented.
5. HBAR unsupported profits reconstructed, marked random and excluded.
6. Dedicated 15m profile implemented and enabled.
7. Three-level fixed-total-notional quoting implemented and enabled.
8. Broader candidate pool implemented and enabled.
9. Non-blocking `NO_MARKETS` watchdog with recovery implemented.
10. Cycle analytics/win-rate/profit-factor corrected.
11. Crash-recovery badge clearing corrected.
12. UTF-8 autorestart launcher repaired and parser-tested.
13. Durable original position wall time restored across restart.
14. Limitless real `NEW_TRADE` volume is now used for PAPER queue consumption.

## Verification

- Alembic revision: `004`.
- Full suite after trade-feed integration: **319 passed, 4 skipped**.
- The four skips are the pre-existing stale shorting tests.
- Current process was restarted with the same `.env`, health returned `ok`,
  trading was resumed, and three quotes returned automatically.

## What to watch next

Wait for a new `NEW_TRADE` on the owned market. Then verify:

1. `limitless_public_trade_seq` increases.
2. An ineligible trade only advances evidence and does not fill.
3. An eligible trade first consumes queue-ahead volume.
4. Total filled contracts across L1-L3 never exceed that event's contracts.
5. Any resulting DB trade is `inferred` with
   `limitless_new_trade_after_queue`, never `verified` or `random`.

Zero fills by itself is not a failure now: it can be the correct result when no
real post-placement trade reaches the synthetic quote. Do not loosen the model
back to touch-, cancellation- or RNG-based fills to manufacture activity.

## Primary files

- `app/services/limitless_client.py` — market adapter and `NEW_TRADE` feed
- `app/services/market_maker.py` — queue allocation and PAPER fill inference
- `tests/unit/test_limitless_adapter.py` — feed normalization/dedup tests
- `tests/unit/test_paper_fill_evidence.py` — queue and multilevel allocation
- `MATCH_2_READINESS_REPORT_2026-07-17.md` — complete readiness record

