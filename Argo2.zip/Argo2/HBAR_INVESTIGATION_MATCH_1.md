# HBAR / token 160695… — Match #1 investigation

Conclusion: the large PAPER profit is **not verified** and must be excluded
from conservative P&L. The historical simulator did not retain public trades,
queue position, or book-depletion evidence. It generated maker fills from an
RNG whenever a quote was merely near best bid/ask.

Database reconstruction (UTC):

| Time | Side | Price | Size | Gross PnL | Path |
|---|---:|---:|---:|---:|---|
| 13:46:18 | BUY | 0.07 | $1.7248 | $0 | FAST_FLAT_ENTRY |
| 13:48:04 | SELL | 0.16 | $3.6603 | +$2.0589 | FAST_FLAT_MAKER_EXIT |
| 13:50:22 | BUY | 0.07 | $1.7827 | $0 | FAST_FLAT_ENTRY |
| 13:50:55 | SELL | 0.16 | $2.3377 | +$1.3150 | FAST_FLAT_MAKER_EXIT |

The token was stored without market metadata (`market_name=160695247694`), so
the DB alone cannot prove the HBAR label either. All pre-migration PAPER rows
are backfilled as `random`. From Match #2, conservative PAPER maker fills
require the public book to trade through the resting price and are labelled
`inferred`; LIVE exchange-confirmed fills are `verified`.
