# Аварійний інфраструктурний фікс STALE_DATA halt

Дата: 2026-07-17
Бот: Codex/GPT FAST_FLAT, порт 8765
Режим: PAPER

## Інцидент

- Початок STALE_DATA halt: `2026-07-17 04:13:41 UTC`.
- Feed згодом відновився, але halt не знімався автоматично за наявності
  відкритої FAST_FLAT-позиції.
- Відновлення торгівлі після перевіреного hotfix і перезапуску:
  `2026-07-17 05:38:21 UTC`.
- Зафіксований простій: **1 год 24 хв 40 с**.

## Причина

У `_requote_loop()` гілка `fast_flat + open inventory` запускала
`_cycle(exit_only=True)` і виконувала `continue` раніше, ніж код перевіряв
`last_ws_msg_age < 10`. Через це умова auto-resume була недосяжною, доки
позиція не закриється, навіть коли feed уже став свіжим.

## Виправлення

- Перевірку відновлення STALE_DATA винесено в
  `_resume_stale_halt_if_feed_recovered()`.
- Її виклик перенесено перед FAST_FLAT `exit_only`-гілкою.
- Логіку стратегії, rescue, FAK, sizing, market filters і `.env` не змінено.

## Перевірка

- Додано regression test: активний STALE_DATA halt + відкрита FAST_FLAT-
  позиція + `last_ws_msg_age=0.5` повинні дати auto-resume протягом одного
  requote-loop tick.
- Цільовий запуск: `30 passed`.
- Після перезапуску: PID `15692`, `halted=false`, feed age `2.4s`, TRX-позицію
  відновлено, SELL exit-котирування відновлено.
