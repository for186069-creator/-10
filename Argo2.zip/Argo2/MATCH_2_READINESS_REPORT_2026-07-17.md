# Match #2 readiness report

## Match #1

Recorded as **unfinished, stopped at ~24h for fixes**. Frozen figures and open
positions are in `MATCH_1_STOPPED_2026-07-17.md`; no post-stop activity belongs
to the match. The maintenance restart at 06:20 UTC used the same `.env`, PAPER
mode and PAUSED state.

## PAPER evidence and HBAR

- Every trade now stores `fill_verification` (`verified`, `inferred`, `random`),
  durable `cycle_id`, queue-ahead size, inferred-through volume and evidence
  source.
- Default PAPER maker fills require a post-placement book update, consumption
  of the visible queue ahead, and a trade-through of our resting price; a touch
  is insufficient. They are `inferred`, since snapshots cannot prove trades
  versus cancellations. LIVE exchange receipts are `verified`; the old RNG
  simulator is opt-in and always `random`.
- Limitless PAPER fills now use the official per-market `NEW_TRADE` feed:
  `bodyHash`/transaction deduplication, real contract volume, aggressor side,
  YES/NO normalization and price/time allocation across L1-L3. Historical
  events seed the cursor and are never replayed. Disappearing book depth alone
  no longer counts as a Limitless fill because it may be a cancellation.
- The durable shadow journal stores each public-book opportunity and compares
  inferred and legacy-random candidates. The first validation run reached the
  required 100 observations (104 observed; 0 inferred and 0 random candidates
  in that initial window). More observations remain necessary for a useful
  rate comparison.
- Dashboard/CSV expose evidence and cycle, raw net PnL and conservative PnL.
- All 139 Match #1 Argo fills backfill as `random`: raw net +$6.3399,
  conservative PnL $0.
- HBAR/token `160695…` produced +$2.0589 and +$1.3150 maker exits without
  retained execution evidence. They are excluded from conservative PnL. Full
  reconstruction: `HBAR_INVESTIGATION_MATCH_1.md`.

## FAK and cycle accounting

- Profit-FAK requires final cycle net >= target, residual FAK loss <= $0.05
  and <= 25% of prior maker profit, a losing residual <= 20% of initial tokens,
  and full visible depth.
- Profit and rescue are distinct DB paths:
  `FAST_FLAT_PROFIT_FAK_EXIT` / `FAST_FLAT_RESCUE_FAK_EXIT`.
- Analytics groups all partial fills by cycle, subtracts costs, excludes open
  cycles from wins, and reports `profit_factor=null` if no loss exists.

## Operations

- Non-blocking `NO_MARKETS` degraded watchdog with automatic recovery.
- Recovery badge clears after legacy or fast_flat clean quoting.
- `start_bot_autorestart.ps1` rewritten as valid UTF-8 PowerShell.
- Opening wall time persists; restart reconstructs true position age.

## Extensions enabled for the pre-match validation

- Separate 15m profile: discovery, full-cycle TTR, size, depth, entry TTL,
  exit age, profit-FAK, rescue and pre-resolution timers.
- Multilevel: total notional is $3, split into 3 x $1 levels. Every level must
  independently clear its estimated edge after gas; the local Limitless dust
  floor remains $1. The Limitless BUY ladder is hardcoded at market bid plus
  `0.0010`, `0.0015`, and `0.0020` for L1/L2/L3 respectively. After an entry,
  the SELL ladder is symmetric at market ask minus the same three offsets and
  splits only the tokens actually owned. Both ladders reprice after a minimum
  1.5-second rest (one Limitless polling cycle) when their market anchor moves
  by at least `0.001`.
- Broader candidate pool with configurable count. Fast_flat still owns only
  one active position.

The 15m, multilevel and broader-market options are explicitly ON in `.env`.

## Completion of the 13-point list

1. Match #1 was frozen as unfinished and stopped at about 24 hours.
2. Profit-FAK has cycle-profit, absolute leg-loss, maker-profit-share,
   remainder-size and visible-depth guards.
3. Durable cycle IDs join partial entry/exit fills; profit and rescue paths are
   distinct.
4. PAPER evidence is classified and queue-aware; Limitless queue consumption
   is driven by deduplicated `NEW_TRADE` contract volume, raw and conservative
   PnL are separate, and the opportunity journal reached its first 100
   observations.
5. HBAR was reconstructed; unsupported profits are classified `random` and
   excluded from conservative PnL.
6. The dedicated 15m profile is implemented and enabled, including discovery,
   full-cycle TTR, TTL, exit/rescue, pre-resolution, size and depth controls.
7. Multilevel is implemented and enabled with fixed total notional,
   per-level post-gas edge, and venue-minimum adaptation.
8. The broader candidate pool is implemented and enabled with a target of
   three markets; fast_flat still permits only one owned position.
9. The non-blocking `NO_MARKETS` watchdog degrades and recovers automatically.
10. Cycle analytics subtract costs, exclude open cycles from wins, do not fake
    100% win rate, and return null profit factor when there is no loss sample.
11. The crash-recovery badge clears after a confirmed clean quote cycle.
12. `start_bot_autorestart.ps1` is valid UTF-8 PowerShell and parser-tested.
13. Original position wall time is durable and restored, so a restart cannot
    reset exit/rescue age timers.

## Verification and state

- Alembic revision `004` applied.
- Full suite: **319 passed, 4 skipped** (pre-existing stale shorting tests).
- Launcher PowerShell parser: clean.
- Functional launcher test: killing bot PID 17312 caused watchdog PID 16948 to
  start PID 16772 after the configured 10 seconds; recovery cleared and two
  quotes returned automatically after discovery.
- Reset was extended to clear the queue-evidence journal and all fast_flat
  cycle state; its focused regression suite passes (5 tests).
- Both PAPER bots were reset and started together at
  **2026-07-17 07:16:55.511 UTC**. At the first post-start check Argo had bank
  $25, 0 fills and 2 quotes; Claude had bank $25, 0 fills and 3 quotes. Neither
  bot was halted.

All 13 implementation items are complete. The clean joint PAPER run started at
the timestamp above. `inferred` remains a conservative estimate, not an
exchange receipt; `random` PnL must never be used as the match result.
