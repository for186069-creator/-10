# Argo v1.0.163 PAPER test report

**Date:** 2026-07-16  
**Mode under test:** Limitless / PAPER / FAST_FLAT  
**Python:** 3.13.5

## Release safety configuration

- `PAPER_TRADING=true`
- `AUTO_START_TRADING=false`
- `STRATEGY_MODE=fast_flat`
- `ADMIN_HOST=127.0.0.1`
- `ADMIN_PORT=8765`
- `PAPER_AUTO_MERGE_COMPLETE_SETS=true`
- `PAPER_AUTO_REDEEM_RESOLVED=true`
- `ARB_EXECUTION_ENABLED=false`

No LIVE transaction, signing, balance mutation, or on-chain merge/redeem was
performed during this work.

## Test commands

```bash
python -m venv .venv
.venv/bin/python -m pip install -r requirements.txt -r requirements-dev.txt
.venv/bin/python scripts/run_paper_acceptance.py
.venv/bin/pytest -q
.venv/bin/python -m compileall -q app scripts tests
.venv/bin/ruff check --select F,E9,I <changed Python files>
node --check <extracted dashboard script>
```

On Windows, replace `.venv/bin/python` with `.venv\\Scripts\\python.exe`.

## Results

| Check | Result |
|---|---:|
| Deterministic PAPER acceptance | 10 passed, 0 failed |
| Full pytest suite | 291 passed, 4 skipped, 0 failed |
| Async DB shutdown warning | Not reproduced after engine-disposal fixture |
| Bytecode compilation | Passed |
| Focused Python lint (`F`, `E9`, `I`) | Passed |
| Dashboard JavaScript syntax | Passed |
| `GET /health` | `status=ok` |
| `GET /openapi.json` | version `1.0.163` |
| Dashboard `/` | Valid HTML served |
| SIGTERM lifecycle shutdown | Reached `shutdown_complete`; runtime lock removed |

Application coverage reported by the full suite was **54%**. Coverage is not a
proof of strategy profitability; the acceptance scenarios below are the relevant
release gates for the PAPER lifecycle.

## PAPER acceptance scenarios

1. Maker BUY fills, exact-share maker SELL fills, and the round trip closes.
2. Partial entry fill cancels its remainder before an exact-token exit is placed.
3. A restored position waits on a stale book and resumes exit handling on fresh data.
4. Inventory persists to SQLite, restores after a dirty lock, and does not open a second entry.
5. Matched YES/NO balances merge automatically; unmatched balance is preserved.
6. Repeating complete-set merge produces no second payout or P&L entry.
7. Winning resolved inventory redeems at $1 per token exactly once.
8. Losing resolved inventory redeems at $0 exactly once.
9. A stale working entry is cancelled at its configured TTL.
10. A partial exit is cancelled/replaced for the exact remainder, and a full-depth
    FAK rescue closes only when the configured age/loss/depth conditions permit it.

## Skipped tests

Four legacy tests are deliberately skipped because they assume PAPER shorting.
Current behavior clamps SELL quantity to owned outcome-token balance, matching
venue constraints:

- `tests/unit/test_bugN34_loss_cents_realistic.py:90`
- `tests/unit/test_inventory_manager.py:48`
- `tests/unit/test_inventory_manager.py:86`
- `tests/unit/test_inventory_manager.py:109`

## Runtime issue fixed during acceptance

The application previously installed its own SIGINT/SIGTERM handlers after
Uvicorn had installed its handlers. That override consumed the signal without
asking Uvicorn to stop, so the process could remain alive. v1.0.163 relies on
Uvicorn signal handling; the verified shutdown path persisted PAPER state,
removed the dirty-run lock, stopped services, closed databases, and logged
`shutdown_complete`.

## What this report does not prove

- It does not prove profitability or fill frequency on real Limitless books.
- It does not prove external Limitless API availability from the operator's PC.
  The build environment could not reliably access the public feed, so acceptance
  uses deterministic seeded market books and mocked status responses.
- It does not replace a multi-day PAPER observation with live public market data.
- It does not validate LIVE smart-wallet signing or LIVE on-chain merge/redeem.

## Operator startup check

```powershell
.\.venv\Scripts\python.exe -m uvicorn app.main:app --host 127.0.0.1 --port 8765
```

Open `http://127.0.0.1:8765`. The process starts paused. Confirm that markets load,
books remain fresh, and diagnostics are healthy before pressing **Start Trading**.
