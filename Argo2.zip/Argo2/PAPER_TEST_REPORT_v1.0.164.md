# Argo v1.0.164 PAPER stabilization test report

Date: 2026-07-16
Mode: PAPER only
Port: 8765

## Scope

This release addresses three issues observed in the user's real Limitless-fed
PAPER shell log:

1. 480 entry placements in roughly one hour;
2. every completed cycle eventually using `FAST_FLAT_FAK_EXIT`;
3. `limitless_request_failed` records with an empty `error` field.

## Implemented controls

| Control | v1.0.163 | v1.0.164 |
|---|---:|---:|
| Entry unconditional TTL | 3 s | removed |
| Entry minimum rest | none | 15 s |
| Entry material move | none | 1.0 cent |
| Entry hard safety TTL | 3 s | 300 s |
| Unchanged-book planned entry refresh ceiling | up to 1,200/hour by TTL; 480 observed | 12/hour by hard TTL |
| Profitable FAK | enabled implicitly | disabled by default |
| Emergency rescue | 90 s | 900 s |
| Exit reprice interval | 10 s | 60 s |
| Exit material move | one tick | 0.5 cent |
| Exit hard max age | 30 s | 300 s |
| Network exception message | could be empty | type + non-empty message + elapsed time |

The 12/hour unchanged-book ceiling is the direct calculation
`3600 seconds / 300-second hard TTL = 12`. Material market moves or an unsafe
market can still cause an earlier protective cancel.

## Focused regression tests

Command:

```text
python -m pytest -q tests/unit/test_fast_flat_strategy.py tests/unit/test_limitless_adapter.py tests/integration/test_paper_acceptance.py
```

Result before final packaging:

```text
42 passed, 0 failed
```

Covered behavior:

- stable entry does not churn after 3 or 30 seconds;
- one-cent price move after minimum rest cancels for controlled replacement;
- maker exit is preferred even when immediate FAK would be profitable;
- profitable FAK requires explicit configuration opt-in;
- emergency FAK remains available only after the rescue timer;
- full-depth and loss-budget checks remain active;
- timeout logging has a non-empty `TimeoutError()` fallback;
- PAPER acceptance scenarios for partial fills, restart recovery, merge and
  redeem continue to pass.

## Full suite

Final result:

```text
296 passed, 4 skipped, 0 failed
coverage: 54%
```

The four skipped tests are pre-existing stale short-selling tests; FAST_FLAT
continues to block uncontrolled short outcome-token positions.

## Security / packaging

- `LIMITLESS_PRIVATE_KEY`, `LIMITLESS_API_TOKEN_ID`, and
  `LIMITLESS_API_SECRET` are empty in the packaged `.env`.
- No `.venv`, runtime lock, cache, coverage HTML, test database, or Python bytecode
  is included in the release ZIP.
- LIVE remains disabled and was not exercised.

## Remaining real-world validation

The code-level fixes are deterministic and tested. Their live-feed effect must
be measured in a new PAPER session on the user's machine. The expected log
change is substantially fewer `fast_flat_entry_placed` events, maker exits
remaining active longer, and any network failure containing `error_type` and a
non-empty `error_message`.


## Runtime smoke test

| Check | Result |
|---|---|
| `GET /health` | `status=ok` |
| OpenAPI version | `1.0.164` |
| Startup mode | PAPER, paused |
| Graceful SIGTERM | `shutdown_complete`, lock removed |
| Network error detail | `ClientConnectorDNSError` plus non-empty DNS message |

The container had no DNS access to Limitless, which intentionally exercised the
new failure logging. The request log included method, path, exception type,
message, elapsed seconds and `retryable=true`.
