# Argo v1.0.165 whole-cycle FAK test report

Date: 2026-07-16
Mode: PAPER only
Port: 8765

## Purpose

v1.0.164 correctly reduced entry churn, but disabled profitable FAK entirely.
The user's real PAPER log showed why that was the wrong abstraction: partial
maker exits created the profit, while FAK closed the remaining inventory and
thereby completed the profitable round trip.

v1.0.165 restores profitable FAK and gates it on the projected NET result of the
whole cycle.

## Whole-cycle formula

The profitability gate uses:

```text
projected_final_bankroll =
    current_bankroll
    + remaining_tokens * conservative_fak_price
    - estimated_taker_fee
    - exit_gas

projected_cycle_pnl =
    projected_final_bankroll - cycle_start_bankroll
```

`current_bankroll` already reflects entry spend, prior maker SELL proceeds and
all costs already recorded. The conservative price is the current best bid less
`FAST_FLAT_PROFIT_FAK_SLIPPAGE_CENTS`.

FAK is armed only when all conditions hold:

- `FAST_FLAT_PROFIT_FAK_ENABLED=true`;
- maker window of 90 seconds has elapsed;
- book is fresh;
- top bid has depth for the full remaining token balance;
- projected whole-cycle net P&L is at least $0.02.

Emergency rescue remains a different path after 900 seconds and may close a
small controlled loss within the configured $0.05 budget.

## Key regression scenario

```text
Cycle start bankroll:       $25.00
BUY 4 tokens @ $0.45:       bankroll $23.20
Maker SELL 3 @ $0.50:       bankroll $24.70
Remaining 1 token cost:     $0.45
FAK remaining 1 @ $0.44:    final bankroll $25.14
Remaining FAK leg P&L:      -$0.01
Whole round-trip P&L:       +$0.14
Expected decision:          execute FAK and complete cycle
```

The test passes. The inverse test, where projected final bankroll stays below
the cycle target, correctly leaves the maker EXIT working.

## Focused tests

```text
32 passed, 0 failed
```

Coverage includes:

- whole-cycle profitable FAK after partial maker profit;
- block when whole-cycle target is not met;
- maker opportunity window;
- bid-only fresh-book FAK;
- stale-book block;
- full-depth requirement;
- emergency loss-budget rescue;
- persisted cycle-start bankroll across restart;
- existing PAPER acceptance lifecycle.

## Full suite

```text
297 passed, 4 skipped, 0 failed
coverage: 54%
```

The four skipped tests are pre-existing stale short-selling tests. FAST_FLAT
continues to prevent selling more outcome tokens than the account owns.

## Runtime smoke test

| Check | Result |
|---|---|
| `GET /health` | `status=ok` |
| OpenAPI version | `1.0.165` |
| Startup mode | PAPER, paused |
| Graceful SIGTERM | `shutdown_complete`, process stopped |
| Network error detail | exception type plus non-empty DNS message |

The isolated build environment had no DNS access to Limitless. This prevented a
real public-feed cycle but intentionally exercised safe network-failure logging.

## Configuration

```env
PAPER_TRADING=true
AUTO_START_TRADING=false
FAST_FLAT_PROFIT_FAK_ENABLED=true
FAST_FLAT_PROFIT_FAK_AFTER_SEC=90
FAST_FLAT_PROFIT_FAK_SLIPPAGE_CENTS=0.25
FAST_FLAT_RESCUE_AFTER_SEC=900
FAST_FLAT_TARGET_PROFIT_USDC=0.02
FAST_FLAT_LOSS_BUDGET_USDC=0.05
ADMIN_PORT=8765
```

## Safety / scope

- Entry anti-churn controls from v1.0.164 are retained.
- FAK still requires complete top-level depth and fresh market data.
- Cycle baseline is persisted for restart recovery.
- LIVE remains disabled and no real order was submitted.
- Real-feed behavior still requires a new PAPER run on the operator machine.
