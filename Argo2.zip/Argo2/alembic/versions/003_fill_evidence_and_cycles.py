"""Add PAPER fill evidence and strategy cycle identity.

Revision ID: 003
Revises: 002
"""
from __future__ import annotations

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "003"
down_revision: Union[str, Sequence[str], None] = "002"
branch_labels = None
depends_on = None


def upgrade() -> None:
    with op.batch_alter_table("mm_trades") as batch:
        batch.add_column(sa.Column("fill_verification", sa.String(), nullable=False, server_default="random"))
        batch.add_column(sa.Column("cycle_id", sa.Integer(), nullable=False, server_default="0"))
        batch.create_index("ix_mm_trades_fill_verification", ["fill_verification"])
        batch.create_index("ix_mm_trades_cycle_id", ["cycle_id"])


def downgrade() -> None:
    with op.batch_alter_table("mm_trades") as batch:
        batch.drop_index("ix_mm_trades_cycle_id")
        batch.drop_index("ix_mm_trades_fill_verification")
        batch.drop_column("cycle_id")
        batch.drop_column("fill_verification")
