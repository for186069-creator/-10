"""Persist PAPER queue evidence and opportunity journal.

Revision ID: 004
Revises: 003
"""
from __future__ import annotations

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "004"
down_revision: Union[str, Sequence[str], None] = "003"
branch_labels = None
depends_on = None


def upgrade() -> None:
    with op.batch_alter_table("mm_trades") as batch:
        batch.add_column(sa.Column("queue_ahead_tokens", sa.Float(), nullable=False, server_default="0"))
        batch.add_column(sa.Column("inferred_through_tokens", sa.Float(), nullable=False, server_default="0"))
        batch.add_column(sa.Column("fill_evidence_source", sa.String(), nullable=False, server_default=""))
    op.create_table(
        "mm_paper_fill_opportunities",
        sa.Column("id", sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column("market_id", sa.String(), nullable=False),
        sa.Column("cycle_id", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("side", sa.String(), nullable=False),
        sa.Column("quote_price", sa.Float(), nullable=False),
        sa.Column("best_bid", sa.Float(), nullable=False),
        sa.Column("best_ask", sa.Float(), nullable=False),
        sa.Column("last_price", sa.Float(), nullable=False),
        sa.Column("queue_ahead_tokens", sa.Float(), nullable=False, server_default="0"),
        sa.Column("inferred_through_tokens", sa.Float(), nullable=False, server_default="0"),
        sa.Column("inferred_candidate", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("random_candidate", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("timestamp", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
    )
    op.create_index("ix_paper_opportunity_market", "mm_paper_fill_opportunities", ["market_id"])
    op.create_index("ix_paper_opportunity_cycle", "mm_paper_fill_opportunities", ["cycle_id"])


def downgrade() -> None:
    op.drop_table("mm_paper_fill_opportunities")
    with op.batch_alter_table("mm_trades") as batch:
        batch.drop_column("fill_evidence_source")
        batch.drop_column("inferred_through_tokens")
        batch.drop_column("queue_ahead_tokens")
