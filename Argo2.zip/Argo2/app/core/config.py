"""
app/core/config.py — Validated configuration for the Professional MM Bot.

All settings are loaded from environment / .env via pydantic-settings.
Cents-based values are kept in ACTUAL CENTS (4.0 = 4¢ = $0.04) to match
the mental model of a market maker.
"""
from __future__ import annotations

from functools import lru_cache
from typing import Literal

from pydantic import Field, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Central configuration. All values validated at startup."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # ── Mode ─────────────────────────────────────────────────────────────
    paper_trading: bool = True
    paper_balance_usdc: float = Field(default=20.0, gt=0)
    # ``fast_flat`` is a separate one-position state machine.  It never runs
    # the legacy two-sided/multi-level market-maker logic at the same time.
    strategy_mode: Literal["legacy", "fast_flat"] = "legacy"

    # ── FAST_FLAT small-bank strategy ────────────────────────────────────
    # Defaults are deliberately sized for a $10-$25 Limitless pilot.
    fast_flat_order_size_usdc: float = Field(default=2.0, gt=0)
    fast_flat_cash_reserve_usdc: float = Field(default=5.0, ge=0)
    fast_flat_cash_reserve_pct: float = Field(default=0.40, ge=0, le=0.95)
    fast_flat_min_spread_cents: float = Field(default=2.0, gt=0)
    fast_flat_max_spread_cents: float = Field(default=5.0, gt=0)
    fast_flat_min_ttr_sec: float = Field(default=900.0, ge=0)
    fast_flat_min_top_depth_mult: float = Field(default=2.0, ge=1.0)
    # Limitless is REST-polled; fast entries/taker exits need a much tighter
    # freshness bound than the legacy global 120-second circuit breaker.
    fast_flat_max_book_age_sec: float = Field(default=3.0, gt=0)
    # Entry orders should rest long enough to earn maker priority.  The old
    # 3-second unconditional TTL produced hundreds of cancel/re-place cycles
    # per hour on an unchanged book.  Requote only after the minimum rest
    # period and a material price move; the TTL is now a hard safety cap.
    fast_flat_entry_requote_sec: float = Field(default=15.0, gt=0)
    fast_flat_entry_requote_threshold_cents: float = Field(default=1.0, gt=0)
    fast_flat_entry_ttl_sec: float = Field(default=300.0, gt=0)
    # Maker exits also get time to fill.  A partial fill is still cancelled
    # and resized exactly, but unchanged orders are not churned every 10-30s.
    fast_flat_exit_requote_sec: float = Field(default=60.0, gt=0)
    fast_flat_exit_requote_threshold_cents: float = Field(default=0.5, gt=0)
    fast_flat_exit_max_age_sec: float = Field(default=300.0, gt=0)
    fast_flat_target_profit_usdc: float = Field(default=0.02, ge=0)
    # After rescue_after_sec a top-of-book exit may realize at most this
    # whole-position loss.  If the loss is worse, the order stays maker-only.
    # A profitable FAK is a cycle-completion path, not a claim that the final
    # taker leg itself is profitable.  It is allowed only after the maker exit
    # has had time to rest and only when the projected NET P&L of the complete
    # round trip (including earlier maker partials, fees, gas and a slippage
    # buffer) remains above fast_flat_target_profit_usdc.
    fast_flat_profit_fak_enabled: bool = True
    fast_flat_profit_fak_after_sec: float = Field(default=90.0, ge=0)
    fast_flat_profit_fak_slippage_cents: float = Field(default=0.25, ge=0)
    fast_flat_rescue_after_sec: float = Field(default=900.0, ge=0)
    fast_flat_loss_budget_usdc: float = Field(default=0.05, ge=0)
    # A profitable cycle may not hide an expensive residual taker leg.
    fast_flat_max_fak_leg_loss_usdc: float = Field(default=0.05, ge=0)
    fast_flat_max_fak_loss_maker_profit_pct: float = Field(default=0.25, ge=0, le=1)
    fast_flat_max_fak_remainder_pct: float = Field(default=0.20, gt=0, le=1)
    fast_flat_max_daily_loss_usdc: float = Field(default=0.50, gt=0)

    # Experimental post-Match-1 extensions. All are OFF by default so Match
    # #2 measures the corrected single-level fast_flat baseline.
    fast_flat_15m_profile_enabled: bool = False
    fast_flat_15m_min_ttr_sec: float = Field(default=120.0, ge=30)
    fast_flat_15m_entry_ttl_sec: float = Field(default=45.0, gt=0)
    fast_flat_15m_exit_max_age_sec: float = Field(default=60.0, gt=0)
    fast_flat_15m_profit_fak_after_sec: float = Field(default=30.0, ge=0)
    fast_flat_15m_rescue_after_sec: float = Field(default=120.0, ge=0)
    fast_flat_15m_pre_resolution_exit_sec: float = Field(default=60.0, ge=15)
    fast_flat_15m_depth_mult: float = Field(default=2.0, ge=1)
    fast_flat_15m_order_size_usdc: float = Field(default=1.0, gt=0)
    fast_flat_multilevel_enabled: bool = False
    fast_flat_multilevel_count: int = Field(default=3, ge=2, le=5)
    fast_flat_broader_markets_enabled: bool = False
    fast_flat_broader_market_count: int = Field(default=3, ge=2, le=10)

    # PAPER settlement automation. Complete YES+NO sets may be merged back
    # into exactly $1 collateral before resolution; resolved single outcomes
    # may be redeemed atomically in the local PAPER ledger. LIVE remains
    # fail-closed and requires explicit venue/on-chain confirmation.
    paper_auto_merge_complete_sets: bool = True
    paper_auto_redeem_resolved: bool = True

    # ── Polymarket endpoints ─────────────────────────────────────────────
    clob_base_url: str = "https://clob.polymarket.com"
    gamma_url: str = "https://gamma-api.polymarket.com"
    ws_url: str = "wss://ws-subscriptions-clob.polymarket.com/ws/market"
    chain_id: int = 137

    # v1.0.144: Dust handling (Claude review Sections 1-3).
    # Dust = positions that CANNOT be sold on Polymarket because value < $5 minimum.
    # Threshold = POLYMARKET_MIN_ORDER_USDC (5.0), bound to constant per Claude Section 2.
    # Used in: auto-refill, should_quote_bid/ask, inventory checks.
    dust_threshold_usdc: float = Field(default=5.0, gt=0)
    # v1.0.144: Never cancel partials — prevents dust creation at source.
    # When true: bot never cancels quotes that have any fill (>= order_cancel_min_fill_pct).
    # Only enable for Phase 1 (small bankroll, $10-25).
    partial_fill_no_cancel: bool = False
    # Cancel only allowed if fill < X% (1.0 = basically never cancel partials).
    # Only active when partial_fill_no_cancel=true.
    order_cancel_min_fill_pct: float = Field(default=0.0, ge=0.0, le=1.0)
    # v1.0.144: Auto-refill dust handling. When true: can drop dust markets
    # but keeps real positions (>= dust_threshold_usdc).
    auto_refill_keep_partial: bool = True
    # v1.0.144: Max wait for partial positions before warning (Claude Section 3).
    # Cannot force-sell dust (exchange rejects < $5). Just log warning.
    # Default 72 hours = 3 days. 0 = disabled.
    max_partial_wait_sec: float = Field(default=259200.0, ge=0.0)
    # v1.0.144: Orphaned position reconciliation interval (Claude Section 1).
    # Every N seconds, check if orphaned positions (not in books) have resolved.
    # 0 = disabled. Default 600 = 10 min.
    orphaned_reconcile_interval_sec: float = Field(default=600.0, ge=0.0)
    # v1.0.158 (diagnostic §3): a market can be RESOLVED yet still sit in
    # clob.books — not an orphan, not tradable, its book frozen. A position
    # there hangs forever between two handlers. Once the book has been stale
    # this long, treat it as a reconcile candidate. 600s is comfortably above
    # the normal poll interval (1.5s) and any transient network gap
    # (STALE_DATA halts resolve within ~2 min).
    orphaned_book_stale_sec: float = Field(default=600.0, gt=0.0)
    # v1.0.144: Phase transition criteria (Claude Section 6).
    # Minimum days running before allowing phase advancement.
    min_track_record_days: int = Field(default=14, ge=0, le=365)
    # v1.0.144: Single order mode — 1 order per market (not bid+ask).
    # Claude Section 5: this is "Patient Directional Mode", NOT market making.
    # User must understand: profit depends on direction, not spread capture.
    single_order_mode: bool = False

    # ── Auth (LIVE only) ─────────────────────────────────────────────────
    polygon_private_key: str = ""
    polygon_wallet_address: str = ""

    # ── v1.0.147-preview: Exchange selector + Limitless (Claude) ─────────
    # "polymarket" (default) or "limitless". Selects which adapter main.py
    # wires into MarketMaker. MM core is exchange-agnostic.
    exchange: str = Field(default="polymarket", pattern="^(polymarket|limitless)$")
    # Limitless credentials: wallet private key on Base (USDC collateral)
    # + scoped API token generated at limitless.exchange → profile → Api keys.
    limitless_private_key: str = ""
    limitless_api_token_id: str = ""
    limitless_api_secret: str = ""  # base64-encoded secret
    # Limitless exposes open orders per market, not account-wide. LIVE is
    # therefore safe only on an EOA reserved for this bot; the adapter keeps
    # a persistent list of every market where it may have left an order.
    limitless_dedicated_eoa: bool = False
    limitless_order_scope_file: str = ".limitless_order_scope.json"
    base_rpc_url: str = "https://mainnet.base.org"
    base_usdc_address: str = "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913"
    # External EOA trading is not gas-free. Keep a small Base ETH reserve;
    # smart/server-wallet gas sponsorship is intentionally unsupported here.
    limitless_min_base_eth: float = Field(default=0.00001, ge=0)
    # Orderbook REST poll interval (Socket.IO WS is a later upgrade).
    limitless_book_poll_sec: float = Field(default=1.5, gt=0)
    # Limitless has NO documented $5-style exchange minimum. Keep a small
    # safety floor; dust_threshold_usdc should be set to the same value
    # when exchange=limitless (the $5 dust problem largely disappears).
    limitless_min_order_usdc: float = Field(default=1.0, ge=0)
    signature_type: int = 0  # 0=EOA, 1=POLY_PROXY, 2=POLY_GNOSIS_SAFE
    funder_address: str = ""
    clob_api_key: str = ""
    clob_api_secret: str = ""
    clob_api_passphrase: str = ""

    # ── Market selection ─────────────────────────────────────────────────
    market_token_ids: str = ""
    auto_pick_markets: bool = True
    auto_pick_min_volume_24h: float = Field(default=10000, ge=0)
    auto_pick_min_spread_cents: float = Field(default=1.5, ge=0)
    # v1.0.155 (GLM §3): markets with spread ≥ preferred get a ×1.5 score
    # bonus — wider spread = more capture per round trip…
    auto_pick_preferred_spread_cents: float = Field(default=5.0, ge=0)
    # …BUT ONLY on books that actually trade: hard 24h-volume floor. A wide
    # spread on a dead book is a trap (the ARB/HYPE tails), not an edge.
    # Below this volume the market is NEVER picked, regardless of spread.
    auto_pick_min_volume_usd: float = Field(default=50000.0, ge=0)
    # v1.0.159: YOUNG-MARKET EXEMPTION. A freshly opened market has no 24h
    # volume yet — not because it is dead, but because it has not existed for
    # 24h. The blanket $50k floor starved the bot of ALL markets right after
    # the 16:00 UTC daily rollover (live deadlock 2026-07-14). Markets younger
    # than this skip the VOLUME check and are judged on spread + book DEPTH
    # instead. 2h ≈ the point where a healthy daily has visibly started
    # trading, while still far from a full 24h cycle.
    auto_pick_young_market_age_sec: float = Field(default=7200.0, gt=0)
    # Depth demanded from a young market in place of volume: resting size on
    # BOTH sides must cover at least this multiple of our order size — a thin
    # book (the ARB/HYPE tail source) cannot sneak in through the exemption.
    auto_pick_young_min_depth_mult: float = Field(default=1.0, ge=0)
    # v1.0.155 (GLM §7): a market whose recent fills keep going adverse
    # (mid drops >0.5¢ within 60s after our BUY in >30% of the last 20
    # fills) is banned from rotation for this long.
    adverse_market_ban_sec: float = Field(default=3600.0, gt=0)
    auto_pick_count: int = Field(default=5, ge=1, le=20)
    # v1.0.59 (BUG-N9): auto-refill throttle.
    # Previously the bot used `cycle_count % 30 == 0` (≈30s with interval=1.0s)
    # which caused churning: when ALL Polymarket markets have tight spreads,
    # the bot replaced non-quotable markets every ~30s, getting back the SAME
    # tight-spread markets via the relaxed discovery fallback. 19 cycles in
    # 17 min = wasted CPU/network with no benefit.
    # Now uses a monotonic-clock-based cooldown (default 300s = 5 min).
    # Markets rarely change quotability in <5 min; this prevents churning
    # while still recovering from genuinely dead markets.
    auto_refill_cooldown_sec: float = Field(default=300.0, ge=30.0, le=3600.0)
    no_markets_degraded_sec: float = Field(default=300.0, ge=0, le=86400)
    # Dynamic market count: auto-adjust based on bankroll (overrides auto_pick_count)
    # Formula: max(1, floor(bankroll / 10)) — $10 capital per market
    # $20 → 2 markets, $35 → 3, $50 → 5, $100 → 10
    auto_pick_dynamic: bool = True
    auto_pick_keywords: str = (
        "NBA,NFL,MLB,NHL,Soccer,League,Match,Game,beat,win,Cup,Championship,"
        "Tournament,Election,Trump,President,Senate,Governor,Congress,"
        "Parliament,Prime,Minister,Russia,Cabinet,Supreme,Fed,rates,launch,"
        "before,July,August,September,announce,reveal,release,"
        "live,breaking,update,just,confirmed,report,today,tonight,tomorrow,"
        "verdict,ruling,decision,result,score,injury,trade,sign,draft,trade"
    )
    auto_pick_exclude_keywords: str = (
        # v1.0.44: expanded exclude list
        # Crypto (highly speculative, no MM edge)
        "bitcoin,btc,ethereum,eth,solana,sol,crypto,dogecoin,xrp,cardano,polygon,"
        # Esports (extreme volatility, 30-40¢ moves in 60s, near-empty books)
        "counter-strike,csgo,cs:go,cs go,dota,lol,lol_,league of legends,"
        "valorant,rainbow six,rocket league,overwatch,call of duty,cod,"
        "map 1,map 2,map 3,bo1,bo3,bo5,handicap,rounds handicap,"
        # Weather/temperature (resolution-style binary, not MM-able)
        "temperature,weather,forecast,degrees,celsius,"
        # High-frequency tweet/post markets (volatile)
        "tweets,posts,retweets,elon musk,twitter,"
        # v1.0.78 (BUG-N29): Esports tournaments (MSI etc) — extreme volatility
        "msi,bilibili,hanwha,t1,gen.g,dwg,skt,faze,navi,team liquid,"
        # v1.0.78: NOT excluding sports/politics anymore — resolution detector (v1.0.71) handles it.
        # Compromise: allow World Cup, F1, Wimbledon, elections — bot has pre-resolution exit + resolution detector.
    )
    pre_resolution_exit_sec: int = Field(default=900, ge=0)

    # ── Avellaneda-Stoikov ───────────────────────────────────────────────
    as_gamma: float = Field(default=0.3, ge=0, le=5.0)
    as_volatility_window_sec: int = Field(default=120, ge=10)
    as_min_volatility: float = Field(default=0.005, gt=0, lt=0.1)
    # v1.0.85 (N1): Real time-to-resolution horizon.
    # Old: T-t = 1.0 always (perpetual horizon).
    # New: T-t = normalized time to resolution (24h = 1.0, 1h = 0.04).
    # Closer to resolution → smaller inventory penalty (less risk over short horizon).
    as_use_real_horizon: bool = Field(default=True, alias="AS_USE_REAL_HORIZON")

    # ── Kyle's lambda ────────────────────────────────────────────────────
    kyle_max_spread_mult: float = Field(default=3.0, ge=1.0, le=10.0)
    kyle_depth_levels: int = Field(default=5, ge=1, le=20)

    # ── Spread (all values in CENTS) ─────────────────────────────────────
    spread_cents: float = Field(default=4.0, gt=0)
    spread_min_cents: float = Field(default=1.5, gt=0)
    spread_max_cents: float = Field(default=10.0, gt=0)

    # v1.0.115: Gap between our quote and market edge (single-level mode).
    # Lower = closer to market bid/ask = buy cheaper + sell dearer = wider our spread.
    # 0.05 = 5% of optimal spread as gap (was hardcoded 0.15 = 15%).
    # For SPREAD_CENTS=4.0: gap = 4.0/2 × 0.05 = 0.10¢ (was 0.30¢).
    # Trade-off: wider our spread = more profit per fill, but fewer fills.
    quote_gap_pct: float = Field(default=0.05, gt=0, le=0.5, alias="QUOTE_GAP_PCT",
                                  description="Gap from market edge as % of optimal spread. Lower = wider our spread.")

    # v1.0.120 (Claude audit Task 1): adaptive gap — scale with kyle_mult.
    quote_gap_kyle_sensitivity: float = Field(
        default=0.0, ge=0.0, le=3.0, alias="QUOTE_GAP_KYLE_SENSITIVITY",
        description="0=disabled (old behavior), 1.0=proportional to kyle_mult. Higher = stand further from top-of-book on risky markets."
    )
    quote_gap_max_cents: float = Field(
        default=1.5, ge=0.1, alias="QUOTE_GAP_MAX_CENTS",
        description="Upper bound for adaptive gap. Prevents gap from eating all profit."
    )

    # v1.0.120 (Claude audit Task 2): opportunity-cost liquidation.
    liquidation_trend_check_enabled: bool = Field(
        default=False, alias="LIQUIDATION_TREND_CHECK_ENABLED",
        description="If True, check price slope before skipping loss liquidation. Falling price → exit earlier."
    )
    liquidation_trend_window_sec: float = Field(
        default=180.0, gt=0, alias="LIQUIDATION_TREND_WINDOW_SEC",
        description="Window for price slope calculation (seconds)."
    )
    liquidation_capital_starved_threshold: int = Field(
        default=5, ge=1, alias="LIQUIDATION_CAPITAL_STARVED_THRESHOLD",
        description="If bid_blocked count in 60s >= this → override skip (capital needed elsewhere)."
    )
    # v1.0.122 (Claude audit p.2): explicit enable flag for capital-starved override.
    liquidation_capital_starved_enabled: bool = Field(
        default=False, alias="LIQUIDATION_CAPITAL_STARVED_ENABLED",
        description="If True, capital starvation can override loss-skip. Was implicitly ON, now explicit."
    )
    spread_volatility_mult: float = Field(default=2.0, ge=1.0, le=10.0)
    requote_threshold_cents: float = Field(default=1.0, gt=0)
    requote_interval_sec: float = Field(default=1.0, gt=0)

    # ── Order sizing ─────────────────────────────────────────────────────
    order_size_usdc: float = Field(default=5.0, gt=0)
    # v1.0.48 FIX (BUG-14): Polymarket hard minimum is $5 USDC. Was $2,
    # which let hedge/liquidation orders in $2-$4 range pass validation
    # and then get rejected by the Polymarket API. Now $5 to match.
    order_size_min_usdc: float = Field(default=5.0, gt=0)
    order_size_autoscale_max_mult: float = Field(default=1.5, ge=1.0, le=3.0)

    # ── Multi-level quoting ──────────────────────────────────────────────
    multi_level_enabled: bool = True
    multi_level_1_capture: float = Field(default=0.15, ge=0, le=1.0)
    multi_level_1_size_pct: float = Field(default=0.45, ge=0, le=1.0)
    multi_level_2_capture: float = Field(default=0.30, ge=0, le=1.0)
    multi_level_2_size_pct: float = Field(default=0.35, ge=0, le=1.0)
    multi_level_3_capture: float = Field(default=0.45, ge=0, le=1.0)
    multi_level_3_size_pct: float = Field(default=0.20, ge=0, le=1.0)

    # ── Inventory ────────────────────────────────────────────────────────
    max_inventory_usdc: float = Field(default=5.0, gt=0)
    max_inventory_pct_of_bankroll: float = Field(default=0.15, gt=0, le=1.0)

    # v1.0.123 (Claude audit — portfolio exposure cap):
    # Global limit: max % of bankroll tied up in inventory across ALL markets.
    max_total_exposure_pct_of_bankroll: float = Field(
        default=0.30, gt=0, le=1.0, alias="MAX_TOTAL_EXPOSURE_PCT_OF_BANKROLL",
        description="Max % of bankroll in inventory across ALL markets simultaneously. Default 30%."
    )
    inventory_skew_threshold: float = Field(default=0.25, ge=0, le=1.0)
    inventory_skew_max_cents: float = Field(default=0.5, ge=0)
    inventory_clear_threshold: float = Field(default=0.8, ge=0, le=1.0)
    # v1.0.38: reduced from 180→120 to clear stuck positions faster
    inventory_aging_threshold_sec: float = Field(default=120, ge=0)
    inventory_aging_discount_step_cents: float = Field(default=0.5, ge=0)
    inventory_aging_max_discount_cents: float = Field(default=2.0, ge=0)

    # ── Active inventory liquidation (v1.0.38) ───────────────────────────
    # Background task that aggressively sells aged positions before they
    # become permanently stuck. Solves the "$89 stuck inventory" problem.
    inventory_liquidation_enabled: bool = True
    inventory_liquidation_check_sec: float = Field(default=10.0, gt=0)
    # Age at which we start selling aggressively (at market bid + offset)
    inventory_liquidation_aggressive_age_sec: float = Field(default=240.0, gt=0)
    # Age at which we sell urgently (at/below market bid, accept any loss)
    inventory_liquidation_urgent_age_sec: float = Field(default=480.0, gt=0)
    # Max loss per token we'll accept during AGGRESSIVE liquidation (cents).
    # If loss > this AND not urgent → skip (wait for price recovery).
    inventory_liquidation_max_loss_cents: float = Field(default=4.0, ge=0)

    # ── Opportunistic take-profit (v1.0.88) ──────────────────────────────
    # Checked EVERY liquidation cycle, independent of age. If unrealized
    # profit already exceeds this threshold, exit immediately via taker
    # order rather than waiting for the aging timer or a natural
    # counterparty. Runs IN PARALLEL with the passive resting quote (which
    # keeps quoting for organic fills in _check_fills_paper) and with the
    # existing AGGRESSIVE/URGENT aging tiers (unchanged fallback).
    # NOTE: defaults are STARTING HYPOTHESES — tune via backtest
    # (scripts/backtest_hold_n_minutes.py) once mm_snapshots has data.
    inventory_profit_take_cents: float = Field(default=3.0, gt=0)
    # Small minimum age (15s) to avoid noise in the first seconds after
    # opening a position, while book/price are still stabilizing.
    inventory_profit_take_min_age_sec: float = Field(default=15.0, ge=0)

    # ── v1.0.150: PROFIT SNIPER + no-loss exit policy ────────────────────
    # DEPRECATED (v1.0.153): the sniper threshold now comes from the
    # HARDCODED exit ladder in app/services/profit_capture.py and this
    # field no longer participates in any decision. Kept only so existing
    # .env files with PROFIT_TAKE_MIN_CENTS don't break startup.
    profit_take_min_cents: float = Field(default=0.5, ge=0)
    # Taker-fee estimate (bps of notional) used on fee-bearing markets
    # (metadata.fee=true) when the LIVE profile feeRateBps is unknown —
    # i.e. in PAPER. Conservative default 100 bps = 1%.
    taker_fee_bps_assumed: float = Field(default=100.0, ge=0)
    # DRAWDOWN STOP: don't average down into a falling knife. When a long
    # position is underwater and mid has fallen more than this below entry,
    # new BUYs on that market are blocked (the ask keeps working). Caps the
    # "70 BUY fills into a crash" pattern (ARB 2026-07-12: $7.5 stuck).
    drawdown_stop_bid_cents: float = Field(default=3.0, ge=0)

    # ── v1.0.151: MOMENTUM FILTER ────────────────────────────────────────
    # The drawdown stop reacts to POSITION state; this reacts to MARKET
    # state. When mid moved more than the threshold within the window,
    # the side that would get run over is blocked (falling → no bid,
    # rising → no ask). Independent of the drawdown stop (OR).
    momentum_window_sec: float = Field(default=300.0, gt=0)
    momentum_bid_block_cents: float = Field(default=3.0, ge=0)
    momentum_ask_block_cents: float = Field(default=3.0, ge=0)

    # ── v1.0.154: crash protection ───────────────────────────────────────
    # LIVE watchdog: no open order may outlive this many seconds — it gets
    # cancelled and re-placed even if the price hasn't moved. Limitless has
    # no GTD/TTL (create-order requires expiration="0"), so if the bot dies
    # suddenly (power cut), the naked-order window is bounded by this value
    # instead of lasting until power returns. PAPER: not used.
    live_requote_max_order_age_sec: float = Field(default=120.0, gt=0)

    # ── v1.0.151: NO-HEDGE via merge (emergency brake, OFF by default) ──
    # For a deeply underwater YES position, buying NO fixes a KNOWN bounded
    # loss (entry + P_no − 1 + fee) instead of the 0-or-everything lottery
    # at resolution. Enable deliberately after PAPER evaluation.
    no_hedge_enabled: bool = Field(default=False)
    no_hedge_trigger_drawdown_cents: float = Field(default=15.0, ge=0)
    no_hedge_min_ttr_sec: float = Field(default=3600.0, ge=0)
    no_hedge_max_loss_cents: float = Field(default=25.0, ge=0)

    # ── mm_snapshots logging + retention (v1.0.88) ───────────────────────
    # Before v1.0.88 the MarketSnapshot table was defined but NEVER written,
    # making any 'hold N minutes' backtest impossible. These settings drive
    # the new _snapshot_loop background task.
    # Interval: log one row per active market every N seconds. 30s is a
    # compromise between resolution and DB size.
    mm_snapshot_log_interval_sec: float = Field(default=30.0, gt=0)
    # Retention: OLD hardcoded prune LIMIT 1000 held only ~25 min of history
    # (useless for multi-day backtests). 300k rows ≈ 5 days at 30s × 20
    # markets. Value is a validated pydantic int, so it is interpolated
    # safely into the prune SQL (no injection risk).
    mm_snapshot_keep_rows: int = Field(default=300_000, gt=0)

    # ── Volatility-scaled sizing (v1.0.63, BUG-N14) ──────────────────────
    # Professional MM scales order size INVERSELY to volatility: when σ is
    # high, reduce size (price moves fast, bigger risk per fill); when σ is
    # low, increase size (more inventory needed to capture same edge).
    # Formula: vol_mult = reference_vol / max(sigma, as_min_volatility)
    #          clamped to [min_mult, max_mult]
    #          final_size = base_size × vol_mult
    order_size_volatility_scaling: bool = Field(default=True)
    # Reference volatility — the σ at which vol_mult = 1.0 (no scaling).
    # 0.02 = 2% per-sample σ (typical for liquid Polymarket markets).
    order_size_reference_volatility: float = Field(default=0.02, gt=0)
    # Multiplier floor — even at very high σ, don't shrink below this.
    # 0.25 = max 4x reduction (e.g. $80 → $20).
    order_size_min_vol_mult: float = Field(default=0.25, gt=0, le=1.0)
    # Multiplier ceiling — even at very low σ, don't grow above this.
    # 1.5 = max 1.5x increase (e.g. $80 → $120).
    order_size_max_vol_mult: float = Field(default=1.5, ge=1.0, le=5.0)

    # ── Risk controls / circuit breakers ─────────────────────────────────
    max_daily_loss_usd: float = Field(default=5.0, gt=0)
    stop_trading_consecutive_losses: int = Field(default=5, ge=1)
    cancel_on_major_move_cents: float = Field(default=5.0, gt=0)
    min_balance_usd: float = Field(default=2.0, gt=0)
    # v1.0.64 (BUG-N15): raised from 30s to 120s. Polymarket WS sends messages
    # only on book changes; overnight/quiet markets can be silent 30-60s.
    # With REST poll fallback (3s interval) updating last_msg_time on success,
    # STALE_DATA now triggers only when BOTH WS and REST are unreachable.
    stale_data_threshold_sec: float = Field(default=120, gt=0)

    # ── Adverse selection ────────────────────────────────────────────────
    adverse_selection_enabled: bool = True
    adverse_selection_move_cents: float = Field(default=3.0, gt=0)
    adverse_selection_window_sec: float = Field(default=10.0, gt=0)
    adverse_selection_cooldown_sec: float = Field(default=30.0, gt=0)

    # ── Hedging ──────────────────────────────────────────────────────────
    hedging_enabled: bool = True
    hedging_active_enabled: bool = True

    # ── Session-based quoting ────────────────────────────────────────────
    session_quoting_enabled: bool = True
    session_active_start_utc: int = Field(default=14, ge=0, le=23)
    session_active_end_utc: int = Field(default=22, ge=1, le=24)
    session_active_spread_mult: float = Field(default=1.2, ge=0.1, le=5.0)
    session_quiet_spread_mult: float = Field(default=0.9, ge=0.1, le=5.0)

    # ── Gas / fees ──────────────────────────────────────────────────────
    # v1.0.48 FIX (BUG-12): gas cost was hardcoded as $0.005 PAPER / $0.001
    # LIVE — both 10-50x too optimistic. Real Polygon gas for order
    # signing/cancel is $0.01-0.05. Now configurable; defaults are still
    # optimistic but at least match order of magnitude. Users should tune
    # to their actual observed gas costs.
    # v1.0.153: Base mainnet reality is ~$0.001/fill (was 0.01 — a 10×
    # overstatement that distorted sniper-threshold economics in PAPER).
    paper_gas_cost_usdc: float = Field(default=0.001, ge=0, le=1.0)
    live_gas_cost_usdc: float = Field(default=0.02, ge=0, le=1.0)

    # ── PAPER simulation realism (v1.0.50, BUG-2) ──────────────────────
    # v1.0.50 FIX (BUG-2): PAPER was too optimistic (+56%/1.5h). Real LIVE
    # will be -50% to +10% due to higher rejection, competition, latency.
    # Now configurable so users can tune PAPER to match their observed LIVE.
    # Defaults are more realistic (were hardcoded before).
    paper_rejection_rate: float = Field(default=0.20, ge=0, le=1)  # was 0.15
    paper_competition_rate: float = Field(default=0.50, ge=0, le=1)  # was 0.40
    paper_fill_prob_base: float = Field(default=0.018, ge=0, le=1)  # was 0.025
    paper_fill_prob_max: float = Field(default=0.06, ge=0, le=1)  # was 0.08
    paper_adverse_drift_min: float = Field(default=0.008, ge=0, le=0.1)  # was 0.005
    paper_adverse_drift_max: float = Field(default=0.020, ge=0, le=0.1)  # was 0.015
    # Simulated latency in seconds (fills don't happen instantly)
    paper_latency_sec: float = Field(default=0.0, ge=0, le=10)
    # Fill evidence policy. ``conservative`` only books a PAPER maker fill
    # after the public book trades through our resting price.  The historical
    # probabilistic simulator remains available for replay tests, but its
    # fills are explicitly classified ``random``.
    paper_fill_model: Literal["conservative", "random"] = "conservative"

    # ── Telegram ─────────────────────────────────────────────────────────
    telegram_enabled: bool = False
    telegram_bot_token: str = ""
    telegram_chat_id: str = ""
    telegram_daily_summary_hour_utc: int = Field(default=23, ge=0, le=23)

    # ── Admin / DB / logging ─────────────────────────────────────────────
    admin_host: str = "127.0.0.1"
    admin_port: int = Field(default=8000, ge=1, le=65535)
    # v1.0.52: bot starts PAUSED by default. User must click "Start Trading".
    # Set AUTO_START_TRADING=true to auto-start (useful for headless servers).
    auto_start_trading: bool = False
    # NOTE: named MM_DATABASE_URL to avoid collision with the system-wide
    # DATABASE_URL env var present in some hosting environments.
    mm_database_url: str = Field(
        default="sqlite+aiosqlite:///./mm_bot.db", alias="MM_DATABASE_URL"
    )
    log_level: Literal["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"] = "INFO"
    log_format: Literal["json", "console"] = "json"
    # v1.0.52: optional log file. Empty = stdout only. Set to write logs
    # to a file (in addition to stdout). Useful for overnight sessions.
    # v1.0.148 (Jiji): log file ON by default — every bot instance keeps
    # its own log in ./logs/. Simple size rotation: when the file exceeds
    # log_max_mb it is renamed to .1 and a fresh file starts.
    log_file: str = "logs/botmm.log"
    log_max_mb: float = Field(default=50.0, gt=0)

    # ── Order metrics logger (v1.0.79 — handoff "Polymarket LIVE Limit
    # Order Metrics Logger"). Separate SQLite DB so instrumentation never
    # contends with the trading DB.
    metrics_db_path: str = Field(default="./order_metrics.db", alias="METRICS_DB_PATH")
    metrics_log_raw_response: bool = Field(default=False, alias="METRICS_LOG_RAW_RESPONSE")
    metrics_fill_poll_interval_sec: float = Field(
        default=5.0, ge=1.0, le=300.0, alias="METRICS_FILL_POLL_INTERVAL_SEC"
    )

    # ── Arbitrage scanner (v1.0.84 — Опція 4: cross-condition + time-spread)
    # Шукає корельовані ринки на Polymarket з порушеною monotonicity.
    # N1 (cross-condition): однакова подія, різні умови
    # N2 (time-spread): однакова подія, різні дати ("by July 8" vs "by July 10")
    # Опція A: niche filter — ринки з малим об'ємом (де професіонали не грають)
    arb_enabled: bool = Field(default=True, alias="ARB_ENABLED")
    arb_scan_interval_sec: float = Field(
        default=300.0, ge=60.0, le=3600.0, alias="ARB_SCAN_INTERVAL_SEC"
    )
    arb_min_edge_cents: float = Field(
        default=2.0, ge=0.5, le=50.0, alias="ARB_MIN_EDGE_CENTS",
        description="Мінімальна цінова різниця (cents) для arb opportunity"
    )
    arb_niche_max_volume_24h: float = Field(
        default=50000.0, ge=0.0, le=1000000.0, alias="ARB_NICHE_MAX_VOLUME_24H",
        description="Опція A: тільки ринки з volume < цієї межі (де професіонали не грають). 0 = без фільтра."
    )

    # ── Arb EXECUTION (v1.0.90, N3) ──────────────────────────────────────
    # Scanner (v1.0.84) лише знаходить opportunities; executor (v1.0.90)
    # купує YES + NO пару та тримає до resolution. Default OFF — треба
    # свідомо увімкнути після рев'ю коду.
    arb_execution_enabled: bool = Field(
        default=False, alias="ARB_EXECUTION_ENABLED",
        description="v1.0.90 N3: execute arb trades (buy YES+NO pair, hold to resolution). OFF by default."
    )
    arb_max_concurrent_positions: int = Field(
        default=2, ge=1, le=20, alias="ARB_MAX_CONCURRENT_POSITIONS",
        description="Max simultaneous open arb positions. $60 bankroll / $10 per leg ≈ 2-3."
    )
    arb_position_size_usdc: float = Field(
        default=5.0, gt=0, le=100.0, alias="ARB_POSITION_SIZE_USDC",
        description="USD size per LEG (YES leg and NO leg each this size). Must be ≥ order_size_min_usdc (5.0)."
    )
    arb_resolution_check_interval_sec: float = Field(
        default=300.0, ge=60.0, le=3600.0, alias="ARB_RESOLUTION_CHECK_INTERVAL_SEC",
        description="How often to poll Gamma API for resolved markets (sec)."
    )
    arb_max_position_age_sec: float = Field(
        default=1209600.0, ge=3600.0, le=7776000.0, alias="ARB_MAX_POSITION_AGE_SEC",
        description="Max age before an open arb is marked EXPIRED (sec). Default 14 days."
    )
    arb_min_edge_cents_execute: float = Field(
        default=3.0, ge=0.5, le=50.0, alias="ARB_MIN_EDGE_CENTS_EXECUTE",
        description="Min edge to EXECUTE (vs 2.0 to LOG). Higher threshold for real $ than for detection."
    )

    # ─────────────────────────────────────────────────────────────────────
    # Validation
    # ─────────────────────────────────────────────────────────────────────

    @field_validator("polygon_wallet_address", "funder_address")
    @classmethod
    def _normalize_address(cls, v: str) -> str:
        return v.strip().lower() if v else ""

    @field_validator("polygon_private_key", "limitless_private_key")
    @classmethod
    def _normalize_key(cls, v: str) -> str:
        v = v.strip()
        if v and not v.startswith("0x"):
            v = "0x" + v
        return v

    @model_validator(mode="after")
    def _check_live_auth(self) -> Settings:
        """If LIVE mode, require private key + wallet address."""
        if not self.paper_trading:
            missing = []
            if self.exchange == "limitless":
                if not self.limitless_private_key:
                    missing.append("LIMITLESS_PRIVATE_KEY")
                if not self.limitless_api_token_id:
                    missing.append("LIMITLESS_API_TOKEN_ID")
                if not self.limitless_api_secret:
                    missing.append("LIMITLESS_API_SECRET")
            else:
                if not self.polygon_private_key:
                    missing.append("POLYGON_PRIVATE_KEY")
                if not self.polygon_wallet_address:
                    missing.append("POLYGON_WALLET_ADDRESS")
            if missing:
                raise ValueError(
                    f"LIVE mode requires: {', '.join(missing)}. "
                    "Set PAPER_TRADING=true or provide credentials."
                )
            if self.signature_type not in (0, 1, 2):
                raise ValueError(
                    f"SIGNATURE_TYPE must be 0 (EOA), 1 (POLY_PROXY), or 2 (POLY_GNOSIS_SAFE); "
                    f"got {self.signature_type}"
                )
            if self.exchange == "limitless" and self.signature_type != 0:
                raise ValueError(
                    "Limitless LIVE currently supports SIGNATURE_TYPE=0 "
                    "(EOA/external wallet) only"
                )
            if self.exchange == "limitless" and not self.limitless_dedicated_eoa:
                raise ValueError(
                    "Limitless LIVE requires LIMITLESS_DEDICATED_EOA=true: "
                    "the wallet must be reserved for this bot"
                )
        return self

    @model_validator(mode="after")
    def _check_fast_flat_bounds(self) -> Settings:
        if self.fast_flat_min_spread_cents > self.fast_flat_max_spread_cents:
            raise ValueError(
                "FAST_FLAT_MIN_SPREAD_CENTS must be <= "
                "FAST_FLAT_MAX_SPREAD_CENTS"
            )
        if self.fast_flat_exit_requote_sec > self.fast_flat_exit_max_age_sec:
            raise ValueError(
                "FAST_FLAT_EXIT_REQUOTE_SEC must be <= "
                "FAST_FLAT_EXIT_MAX_AGE_SEC"
            )
        if self.fast_flat_entry_requote_sec > self.fast_flat_entry_ttl_sec:
            raise ValueError(
                "FAST_FLAT_ENTRY_REQUOTE_SEC must be <= "
                "FAST_FLAT_ENTRY_TTL_SEC"
            )
        if (
            self.strategy_mode == "fast_flat"
            and not self.paper_trading
            and self.exchange != "limitless"
        ):
            raise ValueError("LIVE FAST_FLAT currently supports EXCHANGE=limitless only")
        return self

    @model_validator(mode="after")
    def _check_spread_bounds(self) -> Settings:
        if not (self.spread_min_cents <= self.spread_cents <= self.spread_max_cents):
            raise ValueError(
                f"Spread bounds violated: need spread_min_cents ({self.spread_min_cents}) "
                f"<= spread_cents ({self.spread_cents}) <= spread_max_cents ({self.spread_max_cents})"
            )
        return self

    @model_validator(mode="after")
    def _check_multi_level_sizes(self) -> Settings:
        if self.multi_level_enabled:
            total = (
                self.multi_level_1_size_pct
                + self.multi_level_2_size_pct
                + self.multi_level_3_size_pct
            )
            if not 0.99 <= total <= 1.01:
                raise ValueError(
                    f"Multi-level size percentages must sum to 1.0; got {total:.3f}"
                )
        return self

    @model_validator(mode="after")
    def _check_session_bounds(self) -> Settings:
        if self.session_active_start_utc >= self.session_active_end_utc:
            raise ValueError(
                f"SESSION_ACTIVE_START_UTC ({self.session_active_start_utc}) must be < "
                f"SESSION_ACTIVE_END_UTC ({self.session_active_end_utc})"
            )
        return self

    # ── Derived helpers ──────────────────────────────────────────────────

    @property
    def keywords_list(self) -> list[str]:
        return [k.strip().lower() for k in self.auto_pick_keywords.split(",") if k.strip()]

    @property
    def exclude_keywords_list(self) -> list[str]:
        return [
            k.strip().lower()
            for k in self.auto_pick_exclude_keywords.split(",")
            if k.strip()
        ]

    @property
    def explicit_token_ids(self) -> list[str]:
        if not self.market_token_ids.strip():
            return []
        return [s.strip() for s in self.market_token_ids.split(",") if s.strip()]


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Cached settings singleton."""
    return Settings()


# Module-level singleton for convenience imports
settings = get_settings()
