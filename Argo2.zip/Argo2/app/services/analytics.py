"""
app/services/analytics.py — P&L analytics + market quality scoring.

Pure functions operating on Trade records (from DB) and current bot state.
"""
from __future__ import annotations

import time
from collections import defaultdict, deque
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone

from app.core.config import settings
from app.core.logging import get_logger

log = get_logger(__name__)


@dataclass
class PnLBucket:
    """One minute bucket of P&L for time-series charts."""

    timestamp: float
    realized_pnl: float = 0.0
    trade_count: int = 0


class Analytics:
    """Compute P&L, win rate, Sharpe, drawdown from Trade records."""

    @staticmethod
    def _to_aware(dt: datetime) -> datetime:
        """Convert naive datetime (from SQLite) to timezone-aware UTC.

        FIX: SQLite stores datetimes as naive strings. When SQLAlchemy parses
        them, we get offset-naive datetimes. Comparing with datetime.now(timezone.utc)
        (offset-aware) raises TypeError. This helper normalizes both sides.
        """
        if dt is None:
            return datetime.now(timezone.utc)
        if dt.tzinfo is None:
            return dt.replace(tzinfo=timezone.utc)
        return dt

    @staticmethod
    def _compute_summary_legacy(
        trades: list,
        total_count_override: int | None = None,
        total_pnl_override: float | None = None,
        trades_24h_override: int | None = None,
        pnl_24h_override: float | None = None,
    ) -> dict:
        """Compute all-time + 24h summary from a list of Trade ORM objects.

        v1.0.49 FIX (BUG-16): added optional override parameters so callers
        can pass SQL-aggregated totals (fast) instead of loading ALL trades
        into memory. When overrides are provided, only `trades` (which can
        be a limited recent subset) is used for round-trip analysis (win
        rate, drawdown, sharpe) — those still need chronological pairing.
        """
        if not trades and total_count_override is None:
            return {
                "total_trades": 0,
                "total_realized_pnl": 0.0,
                "win_rate": 0.0,
                "avg_win": 0.0,
                "avg_loss": 0.0,
                "profit_factor": 0.0,
                "max_drawdown": 0.0,
                "sharpe_estimate": 0.0,
                "trades_24h": 0,
                "pnl_24h": 0.0,
            }

        now = datetime.now(timezone.utc)
        cutoff_24h = now - timedelta(hours=24)

        # Win rate based on ROUND-TRIPS (BUY→SELL pairs), not individual fills
        # BUY fills have pnl=-0.005 (gas only) — not real wins/losses
        # SELL fills have real pnl — but counting only SELLs gives 100% if no losses
        # Correct: count each BUY→SELL pair as one round-trip, win if total pnl > 0

        # Group fills by market and pair BUY→SELL chronologically
        from collections import defaultdict
        market_fills = defaultdict(list)
        for t in trades:
            if t.pnl_usdc is not None:
                market_fills[t.market_id].append(t)

        winners = 0
        losers = 0
        wins_pnl = 0.0
        losses_pnl = 0.0

        for market_id, fills in market_fills.items():
            fills.sort(key=lambda x: x.timestamp if x.timestamp else datetime.min)
            open_buy = None
            for t in fills:
                if t.side.value == "BUY":
                    if open_buy is None:
                        open_buy = t
                    else:
                        # Stacked buys without sell — skip for simplicity
                        pass
                elif t.side.value == "SELL" and open_buy is not None:
                    # Complete round-trip
                    rt_pnl = (open_buy.pnl_usdc or 0) + (t.pnl_usdc or 0)
                    # v1.0.51 FIX (BUG-32): previously threshold was 0.01 which
                    # counted gas-only breakeven trades (rt_pnl = -0.02 = 2× gas)
                    # as LOSSES. This inflated the loss count and deflated win
                    # rate. Now threshold is 0.05 — trades with |rt_pnl| < 0.05
                    # are "breakeven" (gas-only) and not counted as win or loss.
                    # This gives a more accurate win rate.
                    if rt_pnl > 0.05:
                        winners += 1
                        wins_pnl += rt_pnl
                    elif rt_pnl < -0.05:
                        losers += 1
                        losses_pnl += abs(rt_pnl)
                    # else: breakeven (gas-only) — not counted
                    open_buy = None

        closed_count = winners + losers
        win_rate = (winners / max(closed_count, 1)) * 100
        avg_win = wins_pnl / max(winners, 1)
        avg_loss = losses_pnl / max(losers, 1)
        profit_factor = wins_pnl / max(losses_pnl, 0.0001)

        # Build list of round-trip P&Ls for drawdown + sharpe
        rt_pnls: list[float] = []
        for market_id, fills in market_fills.items():
            fills.sort(key=lambda x: x.timestamp if x.timestamp else datetime.min)
            open_buy = None
            for t in fills:
                if t.side.value == "BUY":
                    if open_buy is None:
                        open_buy = t
                elif t.side.value == "SELL" and open_buy is not None:
                    rt_pnl = (open_buy.pnl_usdc or 0) + (t.pnl_usdc or 0)
                    rt_pnls.append(rt_pnl)
                    open_buy = None

        # Max drawdown: peak-to-trough on cumulative P&L
        cumulative = 0.0
        peak = 0.0
        max_dd = 0.0
        for pnl in rt_pnls:
            cumulative += pnl
            peak = max(peak, cumulative)
            dd = peak - cumulative
            max_dd = max(max_dd, dd)

        # Sharpe estimate: mean/std of round-trip P&Ls
        if len(rt_pnls) >= 5:
            mean = sum(rt_pnls) / len(rt_pnls)
            var = sum((p - mean) ** 2 for p in rt_pnls) / max(len(rt_pnls) - 1, 1)
            std = var ** 0.5
            sharpe = mean / std if std > 0 else 0.0
        else:
            sharpe = 0.0

        # v1.0.49 (BUG-16): use overrides when provided (SQL aggregates),
        # otherwise compute from the (possibly limited) trades list.
        if total_count_override is not None:
            total_count = total_count_override
            total_pnl = total_pnl_override or 0.0
        else:
            total_count = len(trades)
            total_pnl = sum(t.pnl_usdc or 0 for t in trades)

        if trades_24h_override is not None:
            trades_24h_count = trades_24h_override
            pnl_24h = pnl_24h_override or 0.0
        else:
            # FIX: normalize timestamps to aware before comparison (SQLite stores naive)
            trades_24h = [
                t for t in trades
                if t.timestamp and Analytics._to_aware(t.timestamp) >= cutoff_24h
            ]
            trades_24h_count = len(trades_24h)
            pnl_24h = sum(t.pnl_usdc or 0 for t in trades_24h)

        # Include unrealized losses as "open losing positions" in win rate
        # This prevents 100% win rate when bot has stuck losing positions
        # that haven't been sold yet (v1.0.26 blocks selling below entry)
        open_losers = 0
        open_winners = 0
        for market_id, fills in market_fills.items():
            fills.sort(key=lambda x: x.timestamp if x.timestamp else datetime.min)
            open_buy = None
            for t in fills:
                if t.side.value == "BUY":
                    if open_buy is None:
                        open_buy = t
                elif t.side.value == "SELL" and open_buy is not None:
                    open_buy = None
            # If there's an unclosed BUY, it's an "open position"
            # We can't calculate unrealized P&L here (no current mid price)
            # but we count it as neither win nor loss — just "open"

        # Adjusted win rate: (winners) / (winners + losers + open_losers)
        # Open positions with unrealized loss count as "potential losses"
        # For now: just note that win rate only counts CLOSED round-trips
        adjusted_win_rate = win_rate if closed_count > 0 else 0.0

        return {
            "total_trades": total_count,
            "total_realized_pnl": round(total_pnl, 4),
            "closed_trades": closed_count,
            "win_rate": round(adjusted_win_rate, 1),
            "win_rate_note": f"{closed_count} closed, {len(market_fills) - closed_count} open" if closed_count > 0 else "no closed trades",
            "avg_win": round(avg_win, 4),
            "avg_loss": round(avg_loss, 4),
            "profit_factor": round(profit_factor, 2),
            "max_drawdown": round(max_dd, 4),
            "sharpe_estimate": round(sharpe, 3),
            "trades_24h": trades_24h_count,
            "pnl_24h": round(pnl_24h, 4),
        }

    @staticmethod
    def compute_summary(
        trades: list,
        total_count_override: int | None = None,
        total_pnl_override: float | None = None,
        trades_24h_override: int | None = None,
        pnl_24h_override: float | None = None,
    ) -> dict:
        """Cycle-accurate, fee-net summary.

        Fast-flat partial fills are grouped by durable cycle_id. Pre-v166 rows
        use a quantity-aware per-market fallback. Open cycles never inflate
        the win denominator, and profit factor is undefined when no loss has
        occurred instead of being rendered as an enormous finite number.
        """
        if not trades and total_count_override is None:
            return {
                "total_trades": 0, "total_realized_pnl": 0.0,
                "closed_trades": 0, "win_rate": 0.0,
                "win_rate_note": "no closed cycles", "avg_win": 0.0,
                "avg_loss": 0.0, "profit_factor": None,
                "max_drawdown": 0.0, "sharpe_estimate": 0.0,
                "trades_24h": 0, "pnl_24h": 0.0,
            }

        def net(t) -> float:
            return float(t.pnl_usdc or 0) - float(getattr(t, "fees_usdc", 0) or 0)

        cycles: dict[int, list] = defaultdict(list)
        legacy: dict[str, list] = defaultdict(list)
        for t in trades:
            cid = int(getattr(t, "cycle_id", 0) or 0)
            (cycles[cid] if cid > 0 else legacy[t.market_id]).append(t)

        pnls: list[float] = []
        open_count = 0
        for fills in cycles.values():
            bought = sum(float(getattr(t, "size_tokens", 0) or 0) for t in fills if t.side.value == "BUY")
            sold = sum(float(getattr(t, "size_tokens", 0) or 0) for t in fills if t.side.value == "SELL")
            if bought > 0 and sold + 1e-6 >= bought * 0.999:
                pnls.append(sum(net(t) for t in fills))
            else:
                open_count += 1

        for fills in legacy.values():
            fills.sort(key=lambda t: t.timestamp or datetime.min)
            tokens = 0.0
            cycle_net = 0.0
            for t in fills:
                qty = float(getattr(t, "size_tokens", 0) or 0)
                if t.side.value == "BUY":
                    tokens += qty
                    cycle_net += net(t)
                elif t.side.value == "SELL" and tokens > 0:
                    tokens -= qty
                    cycle_net += net(t)
                    if tokens <= 1e-6:
                        pnls.append(cycle_net)
                        tokens = 0.0
                        cycle_net = 0.0
            if tokens > 1e-6:
                open_count += 1

        winners = [p for p in pnls if p > 1e-9]
        losers = [p for p in pnls if p < -1e-9]
        breakeven = len(pnls) - len(winners) - len(losers)
        gross_profit = sum(winners)
        gross_loss = -sum(losers)
        win_rate = len(winners) / max(len(winners) + len(losers), 1) * 100
        profit_factor = gross_profit / gross_loss if gross_loss > 0 else None

        cumulative = peak = max_dd = 0.0
        for pnl in pnls:
            cumulative += pnl
            peak = max(peak, cumulative)
            max_dd = max(max_dd, peak - cumulative)
        sharpe = 0.0
        if len(pnls) >= 5:
            mean = sum(pnls) / len(pnls)
            std = (sum((p - mean) ** 2 for p in pnls) / (len(pnls) - 1)) ** 0.5
            sharpe = mean / std if std else 0.0

        now = datetime.now(timezone.utc)
        recent = [t for t in trades if t.timestamp and Analytics._to_aware(t.timestamp) >= now - timedelta(hours=24)]
        total_count = total_count_override if total_count_override is not None else len(trades)
        total_pnl = total_pnl_override if total_pnl_override is not None else sum(net(t) for t in trades)
        trades_24h = trades_24h_override if trades_24h_override is not None else len(recent)
        pnl_24h = pnl_24h_override if pnl_24h_override is not None else sum(net(t) for t in recent)
        return {
            "total_trades": total_count,
            "total_realized_pnl": round(total_pnl or 0.0, 4),
            "closed_trades": len(pnls),
            "win_rate": round(win_rate, 1),
            "win_rate_note": f"{len(pnls)} closed cycles ({breakeven} breakeven), {open_count} open",
            "avg_win": round(gross_profit / max(len(winners), 1), 4),
            "avg_loss": round(gross_loss / max(len(losers), 1), 4),
            "profit_factor": round(profit_factor, 2) if profit_factor is not None else None,
            "max_drawdown": round(max_dd, 4),
            "sharpe_estimate": round(sharpe, 3),
            "trades_24h": trades_24h,
            "pnl_24h": round(pnl_24h or 0.0, 4),
        }

    @staticmethod
    def by_market(trades: list) -> list[dict]:
        """P&L grouped by market_id.

        v1.0.49 (BUG-16): for large trade counts, prefer by_market_from_rows()
        which accepts SQL GROUP BY results instead of loading all trades.
        """
        by_mkt: dict[str, list] = defaultdict(list)
        for t in trades:
            by_mkt[t.market_id].append(t)

        result = []
        for market_id, mkt_trades in by_mkt.items():
            name = mkt_trades[0].market_name if mkt_trades else market_id[:12]
            pnl = sum(t.pnl_usdc or 0 for t in mkt_trades)
            buys = sum(1 for t in mkt_trades if t.side.value == "BUY")
            sells = sum(1 for t in mkt_trades if t.side.value == "SELL")
            result.append(
                {
                    "market_id": market_id[:16],
                    "market_name": name[:50],
                    "trade_count": len(mkt_trades),
                    "realized_pnl": round(pnl, 4),
                    "buys": buys,
                    "sells": sells,
                }
            )
        result.sort(key=lambda x: x["realized_pnl"], reverse=True)
        return result

    @staticmethod
    def by_market_from_rows(rows: list) -> list[dict]:
        """v1.0.49 (BUG-16): build by_market response from SQL GROUP BY rows.

        Each row should be a tuple/namedtuple with columns:
            (market_id, market_name, trade_count, realized_pnl, buys, sells)

        This avoids loading all Trade ORM objects into memory.
        """
        result = []
        for row in rows:
            market_id = row[0] or ""
            market_name = row[1] or market_id[:12]
            trade_count = row[2] or 0
            realized_pnl = row[3] or 0.0
            buys = row[4] or 0
            sells = row[5] or 0
            result.append(
                {
                    "market_id": market_id[:16],
                    "market_name": market_name[:50],
                    "trade_count": trade_count,
                    "realized_pnl": round(realized_pnl, 4),
                    "buys": buys,
                    "sells": sells,
                }
            )
        result.sort(key=lambda x: x["realized_pnl"], reverse=True)
        return result

    @staticmethod
    def pnl_time_series(trades: list, bucket_sec: int = 60) -> list[dict]:
        """Bucket trades into time intervals for charts."""
        if not trades:
            return []
        buckets: dict[int, PnLBucket] = {}
        for t in trades:
            ts = t.timestamp.timestamp() if t.timestamp else 0
            bucket_ts = (ts // bucket_sec) * bucket_sec
            if bucket_ts not in buckets:
                buckets[bucket_ts] = PnLBucket(timestamp=bucket_ts)
            buckets[bucket_ts].realized_pnl += t.pnl_usdc or 0
            buckets[bucket_ts].trade_count += 1
        return [
            {
                "timestamp": b.timestamp,
                "datetime": datetime.fromtimestamp(b.timestamp, tz=timezone.utc).isoformat(),
                "pnl": round(b.realized_pnl, 4),
                "trades": b.trade_count,
                "cumulative_pnl": 0.0,  # filled below
            }
            for b in sorted(buckets.values(), key=lambda x: x.timestamp)
        ]
