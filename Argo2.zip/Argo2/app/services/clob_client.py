"""
app/services/clob_client.py — Polymarket CLOB client wrapper.

CRITICAL: This module uses the OFFICIAL `py-clob-client` library which
provides REAL EIP-712 order signing via `py-order-utils`. The previous
bot version (v10.13) had a stub `_sign_order` that returned `signature: ""`
— every LIVE order was rejected. This wrapper fixes that.

Layers:
  1. `ClobClient` (official) — order placement, cancel, balance, market data
  2. `MarketDataFeed` (custom) — WebSocket for real-time book updates
  3. `ClobService` — unified facade used by the market maker

PAPER mode: ClobService short-circuits order placement to simulate fills.
LIVE mode: real orders via py-clob-client, real signing.
"""
from __future__ import annotations

import asyncio
import json
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

import aiohttp
import websockets

from app.core.config import settings
from app.core.logging import get_logger
from app.core.metrics import (
    ORDER_PLACE_LATENCY_SEC,
    WS_MSG_AGE_SEC,
)
# v1.0.79: order lifecycle metrics logger (handoff). Lazy import inside
# place_order() to avoid a circular import (order_logger imports
# ClobService for type hints under TYPE_CHECKING, but importing it eagerly
# here is fine — order_logger only references it inside TYPE_CHECKING).

log = get_logger(__name__)


def _float_or(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


# ─── Local imports of official client (deferred until first LIVE use) ────
_PY_CLOB_AVAILABLE: bool | None = None


def _ensure_py_clob() -> None:
    """Check that py-clob-client is importable. Raise informative error if not."""
    global _PY_CLOB_AVAILABLE
    if _PY_CLOB_AVAILABLE is True:
        return
    try:
        from py_clob_client.client import ClobClient as _PC  # noqa: F401
        from py_clob_client.clob_types import (  # noqa: F401
            ApiCreds,
            BalanceAllowanceParams,
            OpenOrderParams,
            OrderArgs,
            OrderType,
        )
        from py_clob_client.constants import POLYGON  # noqa: F401
        from py_clob_client.http_helpers.helpers import PolyApiException  # noqa: F401
    except ImportError as e:
        _PY_CLOB_AVAILABLE = False
        raise RuntimeError(
            "py-clob-client is not installed. Run: pip install -r requirements.txt"
        ) from e
    _PY_CLOB_AVAILABLE = True


# ═══════════════════════════════════════════════════════════════════════
# Data classes (used by both PAPER and LIVE)
# ═══════════════════════════════════════════════════════════════════════


@dataclass
class OrderLevel:
    """A single price level in the order book."""

    price: float
    size: float  # in tokens (shares)


@dataclass
class MarketBook:
    """Current order book for a token. Thread-safe via GIL (asyncio single-thread)."""

    token_id: str
    bids: list[OrderLevel] = field(default_factory=list)
    asks: list[OrderLevel] = field(default_factory=list)
    last_price: float = 0.5
    last_update: float = field(default_factory=time.monotonic)
    tick_size: float = 0.01  # minimum price increment
    neg_risk: bool = False
    min_order_size: float = 5.0

    @property
    def best_bid(self) -> float:
        return max((lvl.price for lvl in self.bids), default=0.0)

    @property
    def best_ask(self) -> float:
        return min((lvl.price for lvl in self.asks), default=1.0)

    @property
    def mid(self) -> float:
        if self.best_bid > 0 and self.best_ask < 1:
            return (self.best_bid + self.best_ask) / 2
        return self.last_price

    @property
    def spread(self) -> float:
        return self.best_ask - self.best_bid

    def depth_bid(self, levels: int) -> float:
        """Total USD depth on bid side, top N levels."""
        return sum(lvl.price * lvl.size for lvl in self.bids[:levels])

    def depth_ask(self, levels: int) -> float:
        return sum(lvl.price * lvl.size for lvl in self.asks[:levels])


@dataclass
class MarketInfo:
    """Static info about a market."""

    token_id: str
    condition_id: str
    question: str
    outcome: str  # "Yes" or "No"
    end_date_ts: float
    volume_24h: float
    tick_size: float = 0.01
    neg_risk: bool = False
    # v1.0.150 (Limitless): LP-rewards qualification threshold in SHARES
    # (settings.minSize / 1e6). NOT a minimum order size — docs (lp-rewards)
    # and create-order schema confirm small orders are accepted; they just
    # don't earn LP rewards. 0.0 = no threshold / unknown (Polymarket).
    min_size: float = 0.0


@dataclass
class OrderResult:
    """Result of order placement — unified PAPER/LIVE shape.

    ``success`` means that the exchange accepted the request; it does *not*
    imply a fill.  Immediate orders must use the explicit fill fields below
    (or wait for order-status polling) before mutating local inventory.
    """

    success: bool
    order_id: str = ""
    client_order_id: str = ""
    error: str = ""
    raw: dict[str, Any] | None = None
    filled_size_usdc: float = 0.0
    filled_tokens: float = 0.0
    fill_price: float | None = None
    settlement_status: str = ""
    terminal: bool = False
    fill_confirmed: bool = False


# ═══════════════════════════════════════════════════════════════════════
# WebSocket market data feed
# ═══════════════════════════════════════════════════════════════════════


class MarketDataFeed:
    """Real-time order book updates via Polymarket WS.

    WS endpoint: wss://ws-subscriptions-clob.polymarket.com/ws/market
    Subscribe with: {"auth": {}, "type": "Market", "assets_ids": [...]}
    Event types: "book", "price_change", "trade"
    """

    def __init__(self, books: dict[str, MarketBook]) -> None:
        self.books = books
        self._running = False
        self._task: asyncio.Task | None = None
        self._subscribed: set[str] = set()
        self.last_msg_time: float = time.monotonic()
        # v1.0.49 (BUG-17): store the active WS connection so subscribe()
        # can send additional subscribe messages without reconnecting.
        self._ws: Any = None  # websockets.WebSocketClientProtocol

    async def start(self, token_ids: list[str]) -> None:
        self._subscribed.update(token_ids)
        if self._task is None or self._task.done():
            self._running = True
            self._task = asyncio.create_task(self._ws_loop(), name="market_ws")

    async def stop(self) -> None:
        self._running = False
        self._ws = None  # v1.0.49: clear reference
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
            self._task = None

    async def subscribe(self, token_id: str) -> None:
        """Add a new token to the WS subscription.

        v1.0.49 FIX (BUG-17): previously this called stop()+start() which
        tore down the entire WS connection and reconnected — causing a data
        gap for ALL markets whenever one new market was added. Now we send
        a subscribe message on the existing connection (Polymarket WS
        supports adding subscriptions on the fly). If the connection is
        down (reconnecting), we just add to _subscribed and the next
        _ws_connect will pick it up.
        """
        if token_id in self._subscribed:
            return  # already subscribed
        self._subscribed.add(token_id)

        # If we have an active WS connection, send a subscribe message
        # for just this token (no need to reconnect).
        if self._ws is not None:
            try:
                sub_msg = {
                    "auth": {},
                    "type": "Market",
                    "assets_ids": [token_id],
                }
                await self._ws.send(json.dumps(sub_msg))
                log.info(
                    "ws_subscribe_added",
                    token=token_id[:12],
                    total_subscribed=len(self._subscribed),
                )
                return
            except Exception as e:
                log.debug(
                    "ws_subscribe_send_failed",
                    token=token_id[:12],
                    error=str(e),
                    error_type=type(e).__name__,
                    reason="will be picked up on next reconnect",
                )
                # Fall through — the token is in _subscribed, so the next
                # _ws_connect will include it in the initial subscribe.

        # No active connection — if the loop isn't running, start it.
        # If it IS running, it will reconnect eventually and pick up the
        # new token from _subscribed.
        if self._task is None or self._task.done():
            self._running = True
            self._task = asyncio.create_task(self._ws_loop(), name="market_ws")

    async def unsubscribe(self, token_id: str) -> None:
        self._subscribed.discard(token_id)

    async def _ws_loop(self) -> None:
        """Connect with exponential backoff. On disconnect, REST fallback kicks in."""
        backoff = 3
        while self._running:
            try:
                await self._ws_connect()
                backoff = 3  # reset on clean disconnect
            except asyncio.CancelledError:
                break
            except Exception as e:
                # v1.0.40: include exception type — `str(e)` is often empty for
                # websockets.ConnectionClosed / aiohttp connection errors.
                log.warning(
                    "ws_disconnect",
                    error=str(e),
                    error_type=type(e).__name__,
                    error_module=getattr(type(e), "__module__", "?"),
                    retry_in=backoff,
                )
                await asyncio.sleep(backoff)
                backoff = min(30, backoff * 2)

    async def _ws_connect(self) -> None:
        async with websockets.connect(
            settings.ws_url,
            ping_interval=15,
            ping_timeout=10,
            close_timeout=3,
            max_size=2**22,  # 4MB — large snapshots
        ) as ws:
            # v1.0.49 (BUG-17): store ws reference so subscribe() can send
            # additional subscribe messages without reconnecting.
            self._ws = ws
            sub_msg = {
                "auth": {},
                "type": "Market",
                "assets_ids": list(self._subscribed),
            }
            await ws.send(json.dumps(sub_msg))
            log.info("ws_connected", markets=len(self._subscribed))
            self.last_msg_time = time.monotonic()

            try:
                async for raw in ws:
                    try:
                        msgs = json.loads(raw)
                        if isinstance(msgs, dict):
                            msgs = [msgs]
                        for msg in msgs:
                            self._process_event(msg)
                    except Exception as e:
                        log.debug("ws_parse_error", error=str(e))
                    self.last_msg_time = time.monotonic()
                    WS_MSG_AGE_SEC.set(0.0)
            finally:
                # v1.0.49: clear ws reference on disconnect so subscribe()
                # doesn't try to send on a closed connection.
                self._ws = None

    def _process_event(self, event: dict) -> None:
        etype = event.get("event_type", "")
        asset_id = event.get("asset_id", "")
        book = self.books.get(asset_id)
        if not book:
            return

        if etype == "price_change":
            price = float(event.get("price", 0))
            side = event.get("side", "")
            size = float(event.get("size", 0))
            if price <= 0 or size <= 0:
                return
            level = OrderLevel(price=price, size=size)
            if side == "BUY":
                book.bids = [level] + [l for l in book.bids if abs(l.price - price) > 1e-9]
                book.bids = sorted(book.bids, key=lambda x: x.price, reverse=True)[:20]
            elif side == "SELL":
                book.asks = [level] + [l for l in book.asks if abs(l.price - price) > 1e-9]
                book.asks = sorted(book.asks, key=lambda x: x.price)[:20]
            if book.bids and book.asks:
                book.last_price = (book.best_bid + book.best_ask) / 2
            book.last_update = time.monotonic()

        elif etype == "book":
            self._apply_snapshot(book, event)
            book.last_update = time.monotonic()

        elif etype == "trade":
            price = float(event.get("price", book.last_price))
            if 0 < price < 1:
                book.last_price = price

    @staticmethod
    def _apply_snapshot(book: MarketBook, event: dict) -> None:
        def parse(raw: list) -> list[OrderLevel]:
            out: list[OrderLevel] = []
            for item in raw:
                try:
                    p = float(item.get("price", 0))
                    s = float(item.get("size", 0))
                    if p > 0 and s > 0:
                        out.append(OrderLevel(p, s))
                except (TypeError, ValueError):
                    pass
            return out

        bids = sorted(parse(event.get("bids", [])), key=lambda x: x.price, reverse=True)
        asks = sorted(parse(event.get("asks", [])), key=lambda x: x.price)
        # v1.0.48 FIX (BUG-13): always replace, even if empty (snapshot is
        # authoritative — if it says no bids, there are no bids).
        book.bids = bids
        book.asks = asks
        if bids and asks:
            book.last_price = (bids[0].price + asks[0].price) / 2


# ═══════════════════════════════════════════════════════════════════════
# Main service facade
# ═══════════════════════════════════════════════════════════════════════


class ClobService:
    """Unified facade for PAPER + LIVE modes.

    PAPER: order placement returns simulated immediate fill.
    LIVE:  real orders via py-clob-client with proper EIP-712 signing.
    """

    def __init__(self) -> None:
        self.books: dict[str, MarketBook] = {}
        self.markets: dict[str, MarketInfo] = {}
        self._feed = MarketDataFeed(self.books)
        self._poll_task: asyncio.Task | None = None
        self._running = False
        self._client: Any = None  # py_clob_client.client.ClobClient (LIVE only)
        self._creds: Any = None  # ApiCreds

    # ── Lifecycle ─────────────────────────────────────────────────────────

    async def start(self, token_ids: list[str]) -> None:
        self._running = True
        for tid in token_ids:
            self._feed._subscribed.add(tid)
            self.books.setdefault(tid, MarketBook(token_id=tid))

        # Fetch static info first
        await self._fetch_market_info(token_ids)
        # Initial REST snapshot of all books
        await self._refresh_all_books()
        # Start WS for real-time updates
        await self._feed.start(token_ids)
        # Start REST polling as fallback / heartbeat
        self._poll_task = asyncio.create_task(self._poll_loop(), name="clob_poll")

        # Initialize LIVE client if needed
        if not settings.paper_trading:
            await self._init_live_client()

        log.info(
            "clob_started",
            mode="PAPER" if settings.paper_trading else "LIVE",
            markets=len(token_ids),
        )

    async def stop(self) -> None:
        self._running = False
        await self._feed.stop()
        if self._poll_task:
            self._poll_task.cancel()
            try:
                await self._poll_task
            except asyncio.CancelledError:
                pass
        log.info("clob_stopped")

    async def _init_live_client(self) -> None:
        """Initialize official py-clob-client with real signing."""
        _ensure_py_clob()
        from py_clob_client.client import ClobClient as _PC
        from py_clob_client.clob_types import ApiCreds

        kwargs: dict[str, Any] = {
            "host": settings.clob_base_url,
            "key": settings.polygon_private_key,
            "chain_id": settings.chain_id,
            "signature_type": settings.signature_type,
        }
        if settings.funder_address and settings.signature_type != 0:
            kwargs["funder"] = settings.funder_address

        self._client = _PC(**kwargs)

        # Use provided creds, or derive them once
        if settings.clob_api_key and settings.clob_api_secret and settings.clob_api_passphrase:
            self._creds = ApiCreds(
                api_key=settings.clob_api_key,
                api_secret=settings.clob_api_secret,
                api_passphrase=settings.clob_api_passphrase,
            )
        else:
            log.info("deriving_api_creds", wallet=settings.polygon_wallet_address)
            self._creds = self._client.create_or_derive_api_creds()
            log.info(
                "api_creds_derived",
                api_key=self._creds.api_key[:8] + "...",
                secret_set=bool(self._creds.api_secret),
                passphrase_set=bool(self._creds.api_passphrase),
            )
            log.info(
                "PERSIST THESE IN .env",
                clob_api_key=self._creds.api_key,
                clob_api_secret=self._creds.api_secret,
                clob_api_passphrase=self._creds.api_passphrase,
            )
        self._client.set_api_creds(self._creds)

    # ── Market discovery (Gamma API) ──────────────────────────────────────

    async def discover_markets(self) -> list[MarketInfo]:
        """Find liquid markets matching keyword + spread filters."""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    f"{settings.gamma_url}/events",
                    params={
                        "active": "true",
                        "closed": "false",
                        "limit": "500",
                        "order": "volume24hr",
                        "ascending": "false",
                    },
                    headers={"User-Agent": "PolyMMBotPro/1.0"},
                    timeout=aiohttp.ClientTimeout(total=20),
                ) as resp:
                    if resp.status != 200:
                        raise ValueError(f"Gamma API status {resp.status}")
                    data = await resp.json()
                events = data if isinstance(data, list) else data.get("data", [])

            now_ts = datetime.now(timezone.utc).timestamp()
            keywords = settings.keywords_list
            exclude = settings.exclude_keywords_list
            min_spread_dollars = settings.auto_pick_min_spread_cents / 100.0

            candidates: list[tuple[float, MarketInfo, float, float]] = []

            for event in events:
                title = (event.get("title", "") + " " + event.get("slug", "")).lower()
                if keywords and not any(kw in title for kw in keywords):
                    continue
                if any(ex in title for ex in exclude):
                    continue

                for m in event.get("markets") or []:
                    if not m.get("active", True) or m.get("closed", False):
                        continue
                    end_ts = self._parse_date(m.get("endDate") or m.get("endDateIso") or "")
                    if end_ts < now_ts + 3600:
                        continue

                    raw_ids = m.get("clobTokenIds", "[]")
                    try:
                        token_ids = (
                            json.loads(raw_ids) if isinstance(raw_ids, str) else list(raw_ids)
                        )
                    except Exception:
                        continue
                    raw_outcomes = m.get("outcomes", "[]")
                    try:
                        outcomes = (
                            json.loads(raw_outcomes) if isinstance(raw_outcomes, str) else list(raw_outcomes)
                        )
                    except Exception:
                        outcomes = []
                    if len(token_ids) != len(outcomes):
                        continue

                    vol_24h = float(
                        m.get("volume24hr")
                        or m.get("volume24hrClob")
                        or m.get("volumeNum")
                        or 0
                    )
                    if vol_24h < settings.auto_pick_min_volume_24h:
                        continue

                    best_bid = float(m.get("bestBid") or 0)
                    best_ask = float(m.get("bestAsk") or 0)
                    market_spread = (
                        best_ask - best_bid if best_bid > 0 and best_ask > 0 else 0
                    )
                    if market_spread < min_spread_dollars:
                        continue
                    question = m.get("question", "")
                    # v1.0.44: skip markets with absurdly wide spreads (> 30¢).
                    # These have near-empty order books (e.g. esports "Map 1"
                    # markets where bid=2¢ ask=99¢, spread=97¢). MM can't
                    # operate there — fills are random, prices jump 30-40¢
                    # in 60s. Was causing fake +$223 PAPER profit.
                    if market_spread > 0.30:
                        log.debug(
                            "market_skip_wide_spread",
                            market=question[:40] if question else "",
                            spread_cents=round(market_spread * 100, 1),
                            reason="spread > 30¢ (empty book / resolution-style market)",
                        )
                        continue
                    # v1.0.77 (BUG-N28): Liquidity check via Gamma API liquidityNum.
                    # Skip markets with low liquidity (empty books, stuck fills risk).
                    # liquidityNum = total USDC committed to the market order book.
                    liquidity = float(m.get("liquidityNum") or m.get("liquidity") or 0)
                    if liquidity < 10000:
                        log.debug(
                            "market_skip_low_liquidity",
                            market=question[:40] if question else "",
                            liquidity=round(liquidity, 0),
                            reason="liquidity < $5,000 (empty book risk)",
                        )
                        continue
                    condition_id = m.get("conditionId", "")
                    raw_prices = m.get("outcomePrices", "[]")
                    try:
                        prices = (
                            json.loads(raw_prices) if isinstance(raw_prices, str) else list(raw_prices)
                        )
                    except Exception:
                        prices = []
                    if len(prices) != len(token_ids):
                        continue

                    # v1.0.104 (BUG-N44): take ONLY YES token per market.
                    # Previously looped all tokens (YES+NO), bot bought both
                    # = guaranteed $1 cost, $1 payout = -$0.0023 loss (not arb, not MM).
                    # Now: take first token that passes price filter, then break.
                    # YES is typically outcomes[0] (price ~0.50 for balanced markets).
                    for tid, outcome, price_str in zip(token_ids, outcomes, prices):
                        try:
                            price = float(price_str)
                        except (TypeError, ValueError):
                            continue
                        if price < 0.10 or price > 0.90:
                            continue

                        info = MarketInfo(
                            token_id=str(tid),
                            condition_id=condition_id,
                            question=question,
                            outcome=str(outcome),
                            end_date_ts=end_ts,
                            volume_24h=vol_24h,
                        )
                        uncertainty = 1.0 - abs(price - 0.5) * 2
                        spread_bonus = 1.0 + (market_spread * 50)
                        score = vol_24h * uncertainty * spread_bonus
                        candidates.append((score, info, price, market_spread))
                        break  # BUG-N44: only 1 token (YES) per market

            candidates.sort(key=lambda x: x[0], reverse=True)
            top = candidates[: settings.auto_pick_count]
            result = [info for _, info, _, _ in top]

            log.info(
                "markets_discovered",
                candidates=len(candidates),
                picked=len(result),
                min_spread_cents=settings.auto_pick_min_spread_cents,
            )
            for score, info, price, spread in top:
                log.info(
                    "market_picked",
                    question=info.question[:55],
                    outcome=info.outcome,
                    price=round(price, 3),
                    spread_cents=round(spread * 100, 1),
                    volume=round(info.volume_24h, 0),
                    score=round(score, 0),
                )

            # Fallback: relax spread threshold to settings.spread_min_cents.
            # v1.0.60 FIX (BUG-N10): was hardcoded 0.8¢ (0.008), which let the
            # fallback pick markets with 0.8–2.4¢ spreads. Those markets then
            # failed market_skip_tight_spread (spread < spread_min_cents) at
            # quote time — bot added them but never quoted them ("garbage"
            # markets, 22 724 skip events in 94-min PAPER session).
            # Now: relaxed = spread_min_cents/100, so any market found via
            # fallback is guaranteed quotable. Effectively makes fallback
            # useful only when primary found 0 candidates — it will still
            # find markets with spread_min_cents ≤ spread < auto_pick_min_spread_cents
            # (narrow window, e.g. 2.0¢–2.4¢ when auto_pick_min=2.5, spread_min=2.0).
            if not result:
                log.warning(
                    "markets_discovery_fallback",
                    relaxed_spread_cents=settings.spread_min_cents,
                )
                relaxed = settings.spread_min_cents / 100.0
                for event in events:
                    title = (event.get("title", "") + " " + event.get("slug", "")).lower()
                    if keywords and not any(kw in title for kw in keywords):
                        continue
                    if any(ex in title for ex in exclude):
                        continue
                    for m in event.get("markets") or []:
                        if not m.get("active", True) or m.get("closed", False):
                            continue
                        end_ts = self._parse_date(m.get("endDate") or "")
                        if end_ts < now_ts + 3600:
                            continue
                        raw_ids = m.get("clobTokenIds", "[]")
                        try:
                            token_ids = json.loads(raw_ids) if isinstance(raw_ids, str) else list(raw_ids)
                        except Exception:
                            continue
                        raw_outcomes = m.get("outcomes", "[]")
                        try:
                            outcomes = json.loads(raw_outcomes) if isinstance(raw_outcomes, str) else list(raw_outcomes)
                        except Exception:
                            outcomes = []
                        if len(token_ids) != len(outcomes):
                            continue
                        vol_24h = float(
                            m.get("volume24hr") or m.get("volume24hrClob") or m.get("volumeNum") or 0
                        )
                        if vol_24h < settings.auto_pick_min_volume_24h:
                            continue
                        best_bid = float(m.get("bestBid") or 0)
                        best_ask = float(m.get("bestAsk") or 0)
                        market_spread = best_ask - best_bid if best_bid > 0 and best_ask > 0 else 0
                        if market_spread < relaxed:
                            continue
                        # v1.0.46 FIX (BUG-8): apply the same wide-spread filter
                        # (>30¢) as the primary path. Previously the fallback
                        # skipped this filter, allowing empty-book markets
                        # (spread 97¢) to be picked — and because spread_bonus
                        # grows with market_spread, they sorted to the top.
                        if market_spread > 0.30:
                            log.debug(
                                "market_skip_wide_spread_fallback",
                                market=(m.get("question") or "")[:40],
                                spread_cents=round(market_spread * 100, 1),
                                reason="spread > 30¢ in fallback path too",
                            )
                            continue
                        question = m.get("question", "")
                        condition_id = m.get("conditionId", "")
                        raw_prices = m.get("outcomePrices", "[]")
                        try:
                            prices = json.loads(raw_prices) if isinstance(raw_prices, str) else list(raw_prices)
                        except Exception:
                            prices = []
                        if len(prices) != len(token_ids):
                            continue
                        for tid, outcome, price_str in zip(token_ids, outcomes, prices):
                            try:
                                price = float(price_str)
                            except (TypeError, ValueError):
                                continue
                            if price < 0.10 or price > 0.90:
                                continue
                            info = MarketInfo(
                                token_id=str(tid),
                                condition_id=condition_id,
                                question=question,
                                outcome=str(outcome),
                                end_date_ts=end_ts,
                                volume_24h=vol_24h,
                            )
                            uncertainty = 1.0 - abs(price - 0.5) * 2
                            spread_bonus = 1.0 + (market_spread * 50)
                            score = vol_24h * uncertainty * spread_bonus
                            candidates.append((score, info, price, market_spread))
                candidates.sort(key=lambda x: x[0], reverse=True)
                top = candidates[: settings.auto_pick_count]
                result = [info for _, info, _, _ in top]
                log.info("markets_discovery_fallback_result", picked=len(result))

            return result
        except Exception as e:
            # v1.0.40: log full exception info — previously `str(e)` was empty
            # for aiohttp connection errors (ClientConnectorError, TimeoutError, etc.),
            # leaving the user with `"error": ""` and no way to diagnose.
            import traceback
            log.error(
                "markets_discovery_failed",
                error=str(e),
                error_type=type(e).__name__,
                error_module=getattr(type(e), "__module__", "?"),
                traceback=traceback.format_exc().splitlines()[-5:],
            )
            return []

    # v1.0.144: Check if a market has resolved (Claude Section 1).
    # Used by _reconcile_orphaned_positions to settle orphaned inventory.
    async def fetch_market_status(self, token_id: str) -> dict | None:
        """Fetch market status from Gamma API. Returns dict with:
        - is_resolved: bool
        - resolved_price: float (1.0 for YES win, 0.0 for NO win)
        - end_date: str
        Returns None on error.
        """
        try:
            async with self._make_session() as session:
                resp = await self._fetch_with_dns_fallback(
                    session, "GET",
                    f"{settings.gamma_url}/markets",
                    params={"clob_token_ids": token_id, "limit": "1"},
                    headers={"User-Agent": "PolyMMBotPro/1.0"},
                    timeout=aiohttp.ClientTimeout(total=settings.polymarket_gamma_timeout_sec),
                )
                async with resp:
                    if resp.status != 200:
                        return None
                    data = await resp.json()
                    markets = data if isinstance(data, list) else data.get("data", [])
                    if not markets:
                        return None
                    m = markets[0]
                    is_resolved = bool(m.get("closed", False))
                    # resolved_price: if YES won → 1.0, if NO won → 0.0
                    outcome_prices = m.get("outcomePrices", "")
                    try:
                        if isinstance(outcome_prices, str):
                            outcome_prices = json.loads(outcome_prices)
                        if isinstance(outcome_prices, list) and len(outcome_prices) >= 2:
                            yes_price = float(outcome_prices[0])
                            resolved_price = 1.0 if yes_price >= 0.5 else 0.0
                        else:
                            resolved_price = 0.0
                    except (ValueError, TypeError, json.JSONDecodeError):
                        resolved_price = 0.0
                    return {
                        "is_resolved": is_resolved,
                        "resolved_price": resolved_price,
                        "end_date": m.get("endDate", ""),
                        "question": m.get("question", ""),
                    }
        except Exception as e:
            log.debug("fetch_market_status_error", token=token_id[:12], error=str(e))
            return None

    async def _fetch_market_info(self, token_ids: list[str]) -> None:
        """Populate self.markets via Gamma /events batch."""
        if not token_ids:
            return
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    f"{settings.gamma_url}/events",
                    params={"active": "true", "closed": "false", "limit": "500"},
                    headers={"User-Agent": "PolyMMBotPro/1.0"},
                    timeout=aiohttp.ClientTimeout(total=15),
                ) as resp:
                    if resp.status != 200:
                        return
                    events = await resp.json()
                    if isinstance(events, dict):
                        events = events.get("data", [])

                    tid_set = set(str(t) for t in token_ids)
                    for event in events:
                        for m in event.get("markets") or []:
                            raw_ids = m.get("clobTokenIds", "[]")
                            try:
                                ids = json.loads(raw_ids) if isinstance(raw_ids, str) else list(raw_ids)
                            except Exception:
                                continue
                            raw_outcomes = m.get("outcomes", "[]")
                            try:
                                outcomes = (
                                    json.loads(raw_outcomes) if isinstance(raw_outcomes, str) else list(raw_outcomes)
                                )
                            except Exception:
                                outcomes = []
                            for tid, outcome in zip(ids, outcomes):
                                if str(tid) in tid_set:
                                    end_ts = self._parse_date(
                                        m.get("endDate") or m.get("endDateIso") or ""
                                    )
                                    self.markets[str(tid)] = MarketInfo(
                                        token_id=str(tid),
                                        condition_id=m.get("conditionId", ""),
                                        question=m.get("question", ""),
                                        outcome=str(outcome),
                                        end_date_ts=end_ts,
                                        volume_24h=float(m.get("volume24hr") or 0),
                                    )
        except Exception as e:
            log.debug("market_info_fetch_failed", error=str(e))

    # ── Book polling (REST fallback) ──────────────────────────────────────

    async def _poll_loop(self) -> None:
        await asyncio.sleep(2)
        while self._running:
            try:
                await self._refresh_all_books()
            except Exception as e:
                log.debug("book_poll_error", error=str(e))
            await asyncio.sleep(3)

    async def _refresh_all_books(self) -> None:
        tids = list(self._feed._subscribed)
        if not tids:
            return
        async with aiohttp.ClientSession() as session:
            tasks = [self._fetch_book(session, tid) for tid in tids]
            results = await asyncio.gather(*tasks, return_exceptions=True)
            # v1.0.64 (BUG-N15): If at least one REST fetch succeeded, the
            # Polymarket API is reachable. Update last_msg_time so STALE_DATA
            # circuit breaker doesn't halt on quiet markets (WS sends messages
            # only on book changes; overnight markets can be silent 30-60s).
            # WS disconnect is still detected: if BOTH WS and REST fail, no
            # update happens and STALE_DATA triggers after threshold_sec.
            success_count = sum(
                1 for r in results if r is True
            )
            if success_count > 0:
                self._feed.last_msg_time = time.monotonic()

    async def _fetch_book(self, session: aiohttp.ClientSession, tid: str) -> bool:
        """Fetch order book via REST. Returns True on success (200 + applied)."""
        try:
            async with session.get(
                f"{settings.clob_base_url}/book",
                params={"token_id": tid},
                timeout=aiohttp.ClientTimeout(total=5),
            ) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    self._apply_book(tid, data)
                    # Update tick size if present
                    if "tick_size" in data and data["tick_size"]:
                        try:
                            self.books[tid].tick_size = float(data["tick_size"])
                        except (TypeError, ValueError):
                            pass
                    if "neg_risk" in data:
                        self.books[tid].neg_risk = bool(data["neg_risk"])
                    return True
                else:
                    # v1.0.49 FIX (BUG-19): log non-200 responses instead of
                    # silently ignoring them. Helps diagnose API issues.
                    log.info(
                        "fetch_book_non_200",
                        token=tid[:12],
                        status=resp.status,
                    )
                    return False
        except Exception as e:
            # v1.0.49 FIX (BUG-19): log exceptions instead of silently
            # swallowing them. Previously `except Exception: pass` made it
            # impossible to diagnose book-fetch failures (DNS, timeout, etc).
            log.info(
                "fetch_book_error",
                token=tid[:12],
                error=str(e),
                error_type=type(e).__name__,
            )
            return False

    def _apply_book(self, tid: str, data: dict) -> None:
        book = self.books.get(tid)
        if not book:
            book = MarketBook(token_id=tid)
            self.books[tid] = book

        def parse(raw: list) -> list[OrderLevel]:
            out: list[OrderLevel] = []
            for item in raw:
                try:
                    p = float(item.get("price", 0))
                    s = float(item.get("size", 0))
                    if p > 0 and s > 0:
                        out.append(OrderLevel(p, s))
                except (TypeError, ValueError):
                    pass
            return out

        bids = sorted(parse(data.get("bids", [])), key=lambda x: x.price, reverse=True)
        asks = sorted(parse(data.get("asks", [])), key=lambda x: x.price)
        # v1.0.48 FIX (BUG-13): previously `if bids: book.bids = bids` kept
        # STALE bids when the API returned an empty book (market lost
        # liquidity). Now we always replace — if API says book is empty,
        # we clear our cached book too. This prevents the bot from quoting
        # against stale data when liquidity dries up.
        book.bids = bids
        book.asks = asks
        if bids and asks:
            book.last_price = (bids[0].price + asks[0].price) / 2
        book.last_update = time.monotonic()
        self._feed.last_msg_time = time.monotonic()

    # ── Order placement ───────────────────────────────────────────────────

    # v1.0.49 FIX (BUG-18): removed dead @retry decorator.
    # The decorator was configured to retry on Exception, but ALL exceptions
    # were caught inside the function body by `except PolyApiException` and
    # `except Exception` handlers that returned OrderResult(success=False).
    # The retry never fired — it was misleading dead code.
    # If retry-on-network-error is needed in the future, the catch-all
    # `except Exception` must be narrowed to let ConnectionError/TimeoutError
    # propagate so the retry decorator can see them.
    async def place_order(
        self,
        token_id: str,
        side: str,  # "BUY" or "SELL"
        price: float,
        size_usdc: float,
        order_type: str = "GTC",  # GTC | FOK | GTD | FAK
        post_only: bool = True,
    ) -> OrderResult:
        """Place an order. PAPER = simulate, LIVE = real signed order.

        v1.0.79: instrumented with the order-lifecycle metrics logger
        (handoff "Polymarket LIVE Limit Order Metrics Logger"). Four hooks
        fire inside this method: pre_submit / submit / on_response plus a
        pre-submit-validation-reject path. All hooks are best-effort — a
        logger failure cannot break order submission.
        """
        from app.services.order_logger import order_logger

        # ── Hook (a): pre-submit (before any validation) ──
        _ref = ""
        try:
            _ref = await order_logger.pre_submit(
                token_id, side, price, size_usdc, order_type, self
            )
        except Exception as _e:
            log.warning("order_logger_pre_submit_exception", error=str(_e))

        # Validate inputs (pre-submit validation per handoff §4a)
        if side not in ("BUY", "SELL"):
            if _ref:
                try:
                    await order_logger.record_pre_submit_reject(_ref, f"Invalid side: {side}")
                except Exception:
                    pass
            return OrderResult(success=False, error=f"Invalid side: {side}")
        if not (0.0 < price < 1.0):
            if _ref:
                try:
                    await order_logger.record_pre_submit_reject(_ref, f"Price out of range: {price}")
                except Exception:
                    pass
            return OrderResult(success=False, error=f"Price out of range: {price}")
        if size_usdc < settings.order_size_min_usdc:
            if _ref:
                try:
                    await order_logger.record_pre_submit_reject(
                        _ref, f"Size below minimum: {size_usdc} < {settings.order_size_min_usdc}"
                    )
                except Exception:
                    pass
            return OrderResult(
                success=False, error=f"Size below minimum: {size_usdc} < {settings.order_size_min_usdc}"
            )

        # ── PAPER MODE: simulate immediate fill ──
        if settings.paper_trading:
            now_ms = int(time.time() * 1000)
            paper_id = f"PAPER-{now_ms}-{side[0]}"
            result = OrderResult(
                success=True,
                order_id=paper_id,
                raw={
                    "status": "MATCHED",
                    "orderID": paper_id,
                    "price": str(price),
                    "size": str(size_usdc / max(price, 0.01)),
                    "side": side,
                },
            )
            # Hook (c): on_response — PAPER acks immediately as MATCHED
            if _ref:
                try:
                    await order_logger.on_response(_ref, result, submitted_at_iso=None)
                except Exception as _e:
                    log.warning("order_logger_paper_response_exception", error=str(_e))
            return result

        # ── LIVE MODE: real order via py-clob-client ──
        if not self._client:
            await self._init_live_client()

        from py_clob_client.clob_types import OrderArgs, OrderType
        from py_clob_client.http_helpers.helpers import PolyApiException

        # Snap price to tick size to avoid rejection
        book = self.books.get(token_id)
        tick = book.tick_size if book else 0.01
        snapped_price = round(round(price / tick) * tick, 6)
        if not (tick <= snapped_price <= 1 - tick):
            if _ref:
                try:
                    await order_logger.record_pre_submit_reject(
                        _ref, f"Snapped price {snapped_price} outside [{tick}, {1 - tick}]"
                    )
                except Exception:
                    pass
            return OrderResult(
                success=False,
                error=f"Snapped price {snapped_price} outside [{tick}, {1 - tick}]",
            )

        # Convert USD size → token shares
        size_tokens = size_usdc / max(snapped_price, 0.01)
        if book and size_tokens < book.min_order_size:
            size_tokens = book.min_order_size
            size_usdc = size_tokens * snapped_price

        order_args = OrderArgs(
            token_id=token_id,
            price=snapped_price,
            size=size_tokens,
            side=side,
        )

        ot = OrderType.GTC
        if order_type == "FOK":
            ot = OrderType.FOK
        elif order_type == "GTD":
            ot = OrderType.GTD
        elif order_type == "FAK":
            ot = OrderType.FAK

        # ── Hook (b): submit (immediately before POST /order) ──
        _submitted_iso: str | None = None
        if _ref:
            try:
                from app.services.order_logger import _now_iso
                _submitted_iso = _now_iso()
                await order_logger.submit(_ref)
            except Exception as _e:
                log.warning("order_logger_submit_exception", error=str(_e))

        t0 = time.monotonic()
        try:
            signed = self._client.create_order(order_args)
            resp = self._client.post_order(signed, orderType=ot, post_only=post_only)
            elapsed = time.monotonic() - t0
            ORDER_PLACE_LATENCY_SEC.observe(elapsed)

            order_id = ""
            success = False
            if isinstance(resp, dict):
                order_id = resp.get("orderID") or resp.get("id", "")
                status = (resp.get("status") or "").upper()
                # v1.0.47: Polymarket API statuses: LIVE (on book),
                # PARTIALLY_FILLED, FILLED, CANCELLED. `MATCHED` kept for
                # backward compat (older API versions may use it).
                # Success = order is on book, partially/fully filled, or
                # we got an order_id at all.
                success = status in (
                    "LIVE", "MATCHED", "FILLED", "PARTIALLY_FILLED"
                ) or bool(order_id)

            log.info(
                "order_placed_live",
                token_id=token_id[:12],
                side=side,
                price=snapped_price,
                size_usdc=round(size_usdc, 2),
                size_tokens=round(size_tokens, 2),
                order_id=order_id,
                status=resp.get("status") if isinstance(resp, dict) else "?",
                latency_ms=round(elapsed * 1000, 1),
            )
            result = OrderResult(success=success, order_id=order_id, raw=resp)
            # ── Hook (c): on_response (success path) ──
            if _ref:
                try:
                    await order_logger.on_response(_ref, result, _submitted_iso)
                except Exception as _e:
                    log.warning("order_logger_response_exception", error=str(_e))
            return result

        except PolyApiException as e:
            elapsed = time.monotonic() - t0
            ORDER_PLACE_LATENCY_SEC.observe(elapsed)
            log.error(
                "order_rejected",
                token_id=token_id[:12],
                side=side,
                price=snapped_price,
                status=getattr(e, "status_code", "?"),
                error=str(getattr(e, "error_msg", e)),
                latency_ms=round(elapsed * 1000, 1),
            )
            result = OrderResult(
                success=False,
                error=f"PolyApiException {getattr(e, 'status_code', '?')}: {getattr(e, 'error_msg', e)}",
            )
            # ── Hook (c): on_response (API reject path) ──
            if _ref:
                try:
                    await order_logger.on_response(_ref, result, _submitted_iso)
                except Exception as _e:
                    log.warning("order_logger_response_exception", error=str(_e))
            return result
        except Exception as e:
            elapsed = time.monotonic() - t0
            ORDER_PLACE_LATENCY_SEC.observe(elapsed)
            log.exception("order_place_failed", error=str(e))
            result = OrderResult(success=False, error=str(e))
            # ── Hook (c): on_response (transport error path) ──
            if _ref:
                try:
                    await order_logger.on_response(_ref, result, _submitted_iso)
                except Exception as _e:
                    log.warning("order_logger_response_exception", error=str(_e))
            return result

    async def cancel_order(self, order_id: str) -> bool:
        """Cancel by order ID. PAPER = no-op, LIVE = real cancel."""
        if settings.paper_trading or order_id.startswith("PAPER-"):
            return True
        if not self._client:
            return False
        from py_clob_client.http_helpers.helpers import PolyApiException

        try:
            resp = self._client.cancel(order_id)
            log.info("order_canceled", order_id=order_id, resp=resp)
            return True
        except PolyApiException as e:
            log.warning("cancel_failed", order_id=order_id, error=str(getattr(e, "error_msg", e)))
            return False
        except Exception as e:
            log.warning("cancel_exception", order_id=order_id, error=str(e))
            return False

    async def cancel_all(self) -> int:
        """Cancel ALL open orders. Returns count canceled. LIVE only.

        v1.0.50 FIX (BUG-23): previously returned -1 on success (magic value
        meaning "API doesn't return count"). This was misleading — callers
        couldn't distinguish "canceled N orders" from "canceled all (unknown
        count)". Now returns the count of open orders BEFORE cancel (which
        we fetch via get_open_orders first). If that fetch fails, returns 0
        (not -1) to avoid breaking callers that sum the result.
        """
        if settings.paper_trading or not self._client:
            return 0
        # v1.0.50: count open orders before canceling so we can return a
        # meaningful count instead of -1.
        count_before = 0
        try:
            from py_clob_client.clob_types import OpenOrderParams

            open_orders = self._client.get_orders(OpenOrderParams())
            count_before = len(open_orders) if open_orders else 0
        except Exception as e:
            log.debug("cancel_all_count_failed", error=str(e))
            # Proceed with cancel anyway — we just won't know the count.
        try:
            self._client.cancel_all()
            log.info("cancel_all_done", orders_before=count_before)
            return count_before
        except Exception as e:
            log.warning("cancel_all_failed", error=str(e))
            return 0

    async def get_open_orders(self) -> list[dict]:
        """List all open orders. LIVE only; PAPER returns empty list."""
        rows, _ = await self.get_open_orders_snapshot()
        return rows

    async def get_open_orders_snapshot(self) -> tuple[list[dict], bool]:
        """Return open orders plus whether the empty/non-empty view is verified."""
        if settings.paper_trading:
            return [], True
        if not self._client:
            return [], False
        try:
            from py_clob_client.clob_types import OpenOrderParams

            return list(self._client.get_orders(OpenOrderParams()) or []), True
        except Exception as e:
            log.warning("get_open_orders_failed", error=str(e))
            return [], False

    async def get_order_statuses(
        self, order_ids: list[str]
    ) -> dict[str, dict[str, Any]]:
        """Normalized cumulative order state used by the MM lifecycle loop.

        This keeps Polymarket SDK details inside the adapter, matching the
        public Limitless adapter contract.  Missing/failed lookups are omitted
        so callers retain pending state instead of guessing a terminal fill.
        """
        if settings.paper_trading or not self._client or not order_ids:
            return {}
        try:
            from py_clob_client.clob_types import OpenOrderParams

            rows = list(self._client.get_orders(OpenOrderParams()) or [])
        except Exception as e:
            log.warning("get_order_statuses_open_failed", error=str(e))
            return {}

        open_by_id = {
            str(row.get("id")): row
            for row in rows
            if isinstance(row, dict) and row.get("id")
        }
        out: dict[str, dict[str, Any]] = {}
        for raw_id in order_ids:
            order_id = str(raw_id)
            final = open_by_id.get(order_id)
            is_open = final is not None
            if final is None:
                try:
                    final = self._client.get_order(order_id)
                except Exception as e:
                    log.debug(
                        "get_order_status_failed", order_id=order_id, error=str(e)
                    )
                    continue
            if not isinstance(final, dict):
                continue
            status = str(final.get("status", "") or "").upper()
            price = _float_or(final.get("price"), 0.0)
            matched_raw = final.get("size_matched")
            matched_size = _float_or(matched_raw, 0.0)
            if matched_raw is None and final.get("makingAmount") is not None:
                matched_size = _float_or(final.get("makingAmount"), 0.0) * price
            matched_tokens = matched_size / price if price > 0 else 0.0
            out[order_id] = {
                "order_id": order_id,
                "client_order_id": "",
                "found": True,
                "status": status,
                "settlement_status": status,
                "matched": matched_size > 0,
                "confirmed": True,
                "matched_size_usdc": matched_size,
                "matched_tokens": matched_tokens,
                "contracts_gross": matched_tokens,
                "contracts_net": matched_tokens,
                "usd_gross": matched_size,
                "usd_net": matched_size,
                "fee_usdc": 0.0,
                "price": price,
                "is_open": is_open,
                "open_snapshot_valid": True,
                "error": None,
                "raw": final,
            }
        return out

    async def get_balance_allowance(self) -> dict[str, Any]:
        """Check USDC balance + allowance on Polygon. LIVE only."""
        if settings.paper_trading or not self._client:
            return {
                "balance": "0",
                "allowance": "0",
                "verified": False,
                "allowance_verified": False,
            }
        try:
            from py_clob_client.clob_types import AssetType, BalanceAllowanceParams

            params = BalanceAllowanceParams(asset_type=AssetType.COLLATERAL)
            result = self._client.get_balance_allowance(params)
            if not isinstance(result, dict):
                raise RuntimeError("invalid balance response")
            float(result["balance"])
            float(result["allowance"])
            return {
                **result,
                "verified": True,
                "allowance_verified": True,
                "source": "py_clob_client",
            }
        except Exception as e:
            log.warning("balance_check_failed", error=str(e))
            raise RuntimeError(f"Polymarket balance check failed: {e}") from e

    # ── Helpers ───────────────────────────────────────────────────────────

    @property
    def last_ws_msg_age(self) -> float:
        return time.monotonic() - self._feed.last_msg_time

    @staticmethod
    def _parse_date(date_str: str) -> float:
        """Parse ISO date string → unix timestamp (UTC). Returns 0 on failure."""
        if not date_str:
            return 0.0
        try:
            # Try ISO format with Z (most common from Polymarket)
            return datetime.fromisoformat(date_str.replace("Z", "+00:00")).timestamp()
        except (ValueError, TypeError):
            pass
        # Fallback to common formats
        for fmt in ("%Y-%m-%dT%H:%M:%SZ", "%Y-%m-%dT%H:%M:%S.%fZ"):
            try:
                return datetime.strptime(date_str[:26], fmt).replace(
                    tzinfo=timezone.utc
                ).timestamp()
            except ValueError:
                continue
        return 0.0
