"""Limitless Exchange adapter — drop-in replacement for ClobService.

v1.0.147-preview (Claude, 2026-07-11)

Mirrors the public interface of app/services/clob_client.py:ClobService so
the MM core (market_maker.py, inventory_manager.py, risk/*) runs UNCHANGED.

Sources (verified against official docs 2026-07-11):
  - https://docs.limitless.exchange/developers/migrate-from-polymarket
  - https://docs.limitless.exchange/api-reference/trading/create-order
  - https://docs.limitless.exchange/developers/authentication

Key differences vs Polymarket:
  - Chain: Base (8453), collateral USDC (6 decimals) — NOT Polygon/pUSD
  - Single REST host: https://api.limitless.exchange
  - Auth: HMAC-signed scoped API token (lmts-api-key / lmts-timestamp /
    lmts-signature), token generated in UI → profile → Api keys
  - EIP-712 domain: name="Limitless CTF Exchange", version="1",
    verifyingContract = market venue.exchange (PER-MARKET, fetched+cached)
  - Order struct keeps classic CTF fields (taker/expiration/nonce/feeRateBps)
  - feeRateBps MUST equal profile rank.feeRateBps on fee-bearing markets
    (fetched once from GET /profiles/me and cached)
  - ownerId (profile id) required on every POST /orders
  - postOnly supported for GTC — MAKERS PAY ZERO FEES on Limitless
  - Markets keyed by slug; bot core keys by token_id → adapter keeps a map
  - expiration must be "0", nonce must be 0 (non-zero rejected)

STATUS: code-complete, NOT yet run against production (Limitless has no
testnet — first run must be with minimal real USDC). Areas marked
UNVERIFIED need a live smoke test.
"""

from __future__ import annotations

import asyncio
import base64
import hashlib
import hmac as hmac_mod
import json
import os
import secrets
import time
from collections import defaultdict, deque
from dataclasses import dataclass
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation, ROUND_DOWN
from pathlib import Path
from typing import Any

import aiohttp

from app.core.config import settings
from app.core.logging import get_logger

# Reuse the exact same data structures the MM core consumes.
from app.services.clob_client import MarketBook, MarketInfo, OrderLevel, OrderResult

log = get_logger(__name__)

API_BASE = "https://api.limitless.exchange"
CHAIN_ID = 8453  # Base mainnet
LIMITLESS_DEFAULT_PRICE_TICK = 0.001
ZERO_ADDR = "0x0000000000000000000000000000000000000000"
EIP712_DOMAIN_NAME = "Limitless CTF Exchange"
EIP712_DOMAIN_VERSION = "1"
# Official Limitless Base deployment. Outcome shares are ERC-1155 positions
# on this contract; USDC allowance alone does not make SELL orders possible.
CONDITIONAL_TOKENS_ADDRESS = "0xC9c98965297Bc527861c898329Ee280632B76e18"

ORDER_TYPES = {
    "EIP712Domain": [
        {"name": "name", "type": "string"},
        {"name": "version", "type": "string"},
        {"name": "chainId", "type": "uint256"},
        {"name": "verifyingContract", "type": "address"},
    ],
    "Order": [
        {"name": "salt", "type": "uint256"},
        {"name": "maker", "type": "address"},
        {"name": "signer", "type": "address"},
        {"name": "taker", "type": "address"},
        {"name": "tokenId", "type": "uint256"},
        {"name": "makerAmount", "type": "uint256"},
        {"name": "takerAmount", "type": "uint256"},
        {"name": "expiration", "type": "uint256"},
        {"name": "nonce", "type": "uint256"},
        {"name": "feeRateBps", "type": "uint256"},
        {"name": "side", "type": "uint8"},
        {"name": "signatureType", "type": "uint8"},
    ],
}


def _micro_amount(value: Any) -> float:
    """Convert a raw 6-decimal Limitless amount to a human float.

    Invalid or omitted execution totals deliberately become zero.  Order
    acceptance is never evidence of a fill.
    """
    try:
        return max(0.0, float(value) / 1_000_000.0)
    except (TypeError, ValueError):
        return 0.0


def _safe_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _market_price_tick(market: dict[str, Any]) -> float:
    """Return the Limitless CLOB price increment.

    Current public CLOB books quote to three decimal places (for example
    0.153/0.251), while the active-markets payload does not currently expose a
    tick field.  Honour a venue field if it is added later; otherwise use the
    observed Limitless increment instead of the old Polymarket-style 0.01.
    """
    settings_data = market.get("settings") or {}
    metadata = market.get("metadata") or {}
    for value in (
        market.get("tickSize"),
        market.get("priceIncrement"),
        settings_data.get("tickSize"),
        settings_data.get("priceIncrement"),
        metadata.get("tickSize"),
    ):
        tick = _safe_float(value)
        if 0.0 < tick <= 0.01:
            return tick
    return LIMITLESS_DEFAULT_PRICE_TICK


def _ensure_eth_deps() -> None:
    try:
        from eth_account import Account  # noqa: F401
        from eth_account.messages import encode_typed_data  # noqa: F401
        from web3 import Web3  # noqa: F401
    except ImportError as e:
        raise RuntimeError(
            "Limitless LIVE mode requires eth-account and web3: "
            "pip install eth-account web3"
        ) from e


@dataclass
class _MarketMeta:
    """Per-market data the adapter needs but the MM core doesn't see."""

    slug: str
    venue_exchange: str
    venue_adapter: str
    yes_token: str
    no_token: str
    fee_bearing: bool = False
    neg_risk: bool = False


@dataclass(frozen=True)
class PublicTrade:
    """A real Limitless ``NEW_TRADE`` feed event normalized to the YES book.

    ``side`` is the aggressor side against the YES order book.  A BUY NO is
    therefore represented as SELL YES at the complementary price (and vice
    versa).  These events prove traded volume, unlike an orderbook level
    disappearing, which may merely be a cancellation.
    """

    seq: int
    event_key: str
    token_id: str
    side: str
    price: float
    contracts: float
    traded_at: float
    tx_hash: str = ""


class LimitlessService:
    """Drop-in replacement for ClobService targeting Limitless Exchange.

    Public interface consumed by the MM core (kept identical):
      .books: dict[token_id, MarketBook]
      .markets: dict[token_id, MarketInfo]
      .start(token_ids) / .stop()
      .discover_markets() -> list[MarketInfo]
      .fetch_market_status(token_id) -> dict | None
      .place_order(token_id, side, price, size_usdc, order_type, post_only)
      .cancel_order(order_id) -> bool
      .cancel_all() -> int
      .get_open_orders() -> list[dict]
      .get_balance_allowance() -> dict
      .last_ws_msg_age -> float
      ._feed.unsubscribe(token_id)  (compat shim)
    """

    def __init__(self) -> None:
        self.books: dict[str, MarketBook] = {}
        self.markets: dict[str, MarketInfo] = {}
        self._meta: dict[str, _MarketMeta] = {}  # token_id -> meta
        self._slug_by_token: dict[str, str] = {}
        # v1.0.157: markets the API reports as inactive (resolved) — skipped
        # by the poll loop until a refill re-discovers them as active.
        self._dead_markets: set[str] = set()
        self._session: aiohttp.ClientSession | None = None
        self._poll_task: asyncio.Task | None = None
        self._trade_poll_task: asyncio.Task | None = None
        self._running = False
        self._last_book_update = time.monotonic()
        self._public_trade_seq = 0
        self._public_trades: dict[str, deque[PublicTrade]] = defaultdict(
            lambda: deque(maxlen=2000)
        )
        self._trade_feed_seeded_slugs: set[str] = set()
        self._seen_trade_keys: set[str] = set()
        self._seen_trade_key_order: deque[str] = deque(maxlen=10000)

        # LIVE credentials (lazy)
        self._owner_id: int | None = None
        self._fee_rate_bps: int = 0
        self._account = None  # eth_account Account
        self._approved_ctf_operators: set[str] = set()

        # Limitless has only per-market open-order snapshots. Persist every
        # slug before submitting an order so a later process can sweep old
        # markets after a crash or rotation.
        self._order_scope_slugs: set[str] = set()
        self._order_scope_legacy_slugs: set[str] = set()
        self._order_scope_orders: dict[str, dict[str, Any]] = {}
        self._order_scope_account = ""
        self._order_scope_verified = True
        # Populated by the same authoritative terminal user-orders snapshot
        # used to reconcile the durable ledger.  get_order_statuses consumes
        # this only within its immediately preceding open-order snapshot.
        self._terminal_orders_by_id: dict[tuple[str, str], dict[str, Any]] = {}
        self._terminal_orders_by_client: dict[tuple[str, str], dict[str, Any]] = {}
        self._load_order_scope()

        # Compat shim: MM core calls self.clob._feed.unsubscribe(tid)
        self._feed = _FeedShim(self)

    def _order_scope_path(self) -> Path:
        raw = str(settings.limitless_order_scope_file or "").strip()
        if not raw:
            raise RuntimeError("LIMITLESS_ORDER_SCOPE_FILE cannot be empty")
        return Path(raw)

    def _load_order_scope(self) -> None:
        try:
            path = self._order_scope_path()
            if not path.exists():
                return
            payload = json.loads(path.read_text(encoding="utf-8"))
            slugs = payload.get("slugs") if isinstance(payload, dict) else None
            account = payload.get("account", "") if isinstance(payload, dict) else ""
            raw_orders = payload.get("orders", []) if isinstance(payload, dict) else []
            raw_legacy_slugs = (
                payload.get("legacy_slugs") if isinstance(payload, dict) else None
            )
            if not isinstance(slugs, list) or not all(
                isinstance(slug, str) and slug for slug in slugs
            ):
                raise ValueError("scope file must contain a slugs[] list")
            if not isinstance(account, str):
                raise ValueError("scope account must be a string")
            if not isinstance(raw_orders, list):
                raise ValueError("scope orders must be a list")
            if raw_legacy_slugs is not None and (
                not isinstance(raw_legacy_slugs, list)
                or not all(
                    isinstance(slug, str) and slug for slug in raw_legacy_slugs
                )
            ):
                raise ValueError("scope legacy_slugs must be a string list")

            orders: dict[str, dict[str, Any]] = {}
            for raw_order in raw_orders:
                if not isinstance(raw_order, dict):
                    raise ValueError("scope order entries must be objects")
                client_id = str(raw_order.get("client_order_id", "") or "")
                slug = str(raw_order.get("slug", "") or "")
                order_type = str(raw_order.get("order_type", "") or "").upper()
                order_id = str(raw_order.get("order_id", "") or "")
                try:
                    created_at_ms = int(raw_order.get("created_at_ms", 0) or 0)
                except (TypeError, ValueError) as exc:
                    raise ValueError("scope created_at_ms must be an integer") from exc
                if not client_id or not slug or order_type not in ("GTC", "FAK", "FOK"):
                    raise ValueError("scope order is missing a valid id/slug/type")
                if client_id in orders:
                    raise ValueError("duplicate client_order_id in scope ledger")
                orders[client_id] = {
                    "client_order_id": client_id,
                    "slug": slug,
                    "order_type": order_type,
                    "order_id": order_id,
                    "created_at_ms": created_at_ms,
                }

            if (slugs or orders) and not account:
                raise ValueError("non-empty scope must be bound to an account")
            order_slugs = {order["slug"] for order in orders.values()}
            # Files written before the per-order ledger contained only slugs.
            # Keep those legacy entries sticky: there is no durable order ID
            # with which to prove that a delayed submission became terminal.
            if raw_legacy_slugs is not None:
                self._order_scope_legacy_slugs = set(raw_legacy_slugs)
                if set(slugs) != self._order_scope_legacy_slugs | order_slugs:
                    raise ValueError("scope slugs do not match its durable records")
            else:
                self._order_scope_legacy_slugs = (
                    set(slugs) - order_slugs if "orders" in payload else set(slugs)
                )
            self._order_scope_orders = orders
            self._refresh_order_scope_slugs()
            self._order_scope_account = str(account).lower()
        except Exception as exc:
            self._order_scope_verified = False
            log.error("limitless_order_scope_load_failed", error=str(exc))

    def _refresh_order_scope_slugs(self) -> None:
        self._order_scope_slugs = self._order_scope_legacy_slugs | {
            str(order["slug"]) for order in self._order_scope_orders.values()
        }

    def _persist_order_scope(self) -> None:
        path = self._order_scope_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_name(path.name + ".tmp")
        tmp.write_text(
            json.dumps(
                {
                    "version": 2,
                    "account": (
                        self._account.address.lower()
                        if self._account is not None
                        else self._order_scope_account
                    ),
                    "slugs": sorted(self._order_scope_slugs),
                    "legacy_slugs": sorted(self._order_scope_legacy_slugs),
                    "orders": sorted(
                        self._order_scope_orders.values(),
                        key=lambda order: str(order["client_order_id"]),
                    ),
                }
            ),
            encoding="utf-8",
        )
        os.replace(tmp, path)
        self._order_scope_verified = True
        if self._account is not None:
            self._order_scope_account = self._account.address.lower()

    def _remember_order_slug(
        self, slug: str, client_order_id: str, order_type: str
    ) -> None:
        if not self._order_scope_verified:
            raise RuntimeError(
                "Limitless order-scope ledger is invalid; LIVE order blocked"
            )
        if not slug or not client_order_id:
            raise RuntimeError("Cannot persist an empty Limitless order scope")
        if client_order_id in self._order_scope_orders:
            raise RuntimeError("Duplicate Limitless client order id")
        previous_orders = dict(self._order_scope_orders)
        self._order_scope_orders[client_order_id] = {
            "client_order_id": client_order_id,
            "slug": slug,
            "order_type": str(order_type).upper(),
            "order_id": "",
            "created_at_ms": int(time.time() * 1000),
        }
        self._refresh_order_scope_slugs()
        try:
            self._persist_order_scope()
        except Exception as exc:
            self._order_scope_orders = previous_orders
            self._refresh_order_scope_slugs()
            self._order_scope_verified = False
            raise RuntimeError(
                f"Cannot persist Limitless order scope: {exc}"
            ) from exc

    def _bind_scope_order_id(self, client_order_id: str, order_id: str) -> bool:
        """Durably attach the exchange ID after an accepted submission.

        The pre-submit client-ID record remains sufficient for recovery if
        this write fails, so the caller must keep tracking the accepted order
        while the ledger is marked unverified and further LIVE entry is halted.
        """
        record = self._order_scope_orders.get(client_order_id)
        if not record or not order_id or record.get("order_id") == order_id:
            return True
        previous = dict(record)
        record["order_id"] = order_id
        try:
            self._persist_order_scope()
            return True
        except Exception as exc:
            self._order_scope_orders[client_order_id] = previous
            self._refresh_order_scope_slugs()
            self._order_scope_verified = False
            log.error("limitless_order_scope_bind_failed", error=str(exc))
            return False

    def _forget_scope_orders(
        self,
        *,
        client_order_ids: set[str] | None = None,
        order_ids: set[str] | None = None,
    ) -> bool:
        """Prune only orders with durable rejection/terminal evidence."""
        clients = {str(value) for value in (client_order_ids or set()) if value}
        exchange_ids = {str(value) for value in (order_ids or set()) if value}
        matches = {
            client_id
            for client_id, record in self._order_scope_orders.items()
            if client_id in clients
            or (record.get("order_id") and str(record["order_id"]) in exchange_ids)
        }
        if not matches:
            return True
        previous_orders = dict(self._order_scope_orders)
        for client_id in matches:
            self._order_scope_orders.pop(client_id, None)
        self._refresh_order_scope_slugs()
        try:
            self._persist_order_scope()
            return True
        except Exception as exc:
            self._order_scope_orders = previous_orders
            self._refresh_order_scope_slugs()
            self._order_scope_verified = False
            log.error("limitless_order_scope_terminal_prune_failed", error=str(exc))
            return False

    @staticmethod
    def _scope_order_is_terminal(
        record: dict[str, Any],
        details: dict[str, Any],
        execution: dict[str, Any],
    ) -> bool:
        """Require order-level evidence, not just one trade settlement.

        OME order state and trade settlement are separate on Limitless. A
        partially matched GTC can retain a LIVE remainder even when the trade
        leg reports FAILED/CANCELED, so settlement alone cannot clear it.
        """
        order_type = str(record.get("order_type", "") or "").upper()
        order_status = str(details.get("status", "") or "").upper()
        settlement = str(
            execution.get("settlementStatus", "") or ""
        ).upper()
        totals = execution.get("totalsRaw") or {}
        gross_tokens = _micro_amount(totals.get("contractsGross"))
        matched = bool(execution.get("matched", False)) or gross_tokens > 0
        final_settlement = settlement in (
            "MINED", "CONFIRMED", "FAILED", "CANCELED", "UNMATCHED", "KILLED"
        )
        if order_type in ("FAK", "FOK"):
            # Immediate orders never leave a resting remainder, but retain the
            # ledger while their execution is still delayed/retrying.
            if order_status in ("LIVE", "OPEN", "PLACED"):
                return False
            if order_status in ("CANCELED", "UNMATCHED", "KILLED") and not matched:
                return True
            return final_settlement
        if order_status in ("LIVE", "OPEN", "PLACED", "PARTIALLY_FILLED"):
            return False
        if order_status in ("CANCELED", "UNMATCHED"):
            return not matched or final_settlement
        if order_status in ("MATCHED", "FILLED"):
            return settlement in ("MINED", "CONFIRMED")
        return False

    @staticmethod
    def _user_order_fields(row: dict[str, Any]) -> tuple[str, str, str]:
        """Normalize identity/status from the documented user-orders row.

        Limitless response examples have changed nesting over time.  Accept
        only object layers and extract identity without treating a missing
        status as terminal evidence.
        """
        layers: list[dict[str, Any]] = [row]
        first = row.get("order")
        if isinstance(first, dict):
            layers.append(first)
            nested = first.get("order")
            if isinstance(nested, dict):
                layers.append(nested)
        order_id = ""
        client_id = ""
        status = ""
        for layer in layers:
            order_id = order_id or str(
                layer.get("id")
                or layer.get("orderId")
                or layer.get("order_id")
                or ""
            )
            client_id = client_id or str(
                layer.get("clientOrderId")
                or layer.get("client_order_id")
                or ""
            )
            status = status or str(layer.get("status") or "").upper()
        return order_id, client_id, status

    async def _terminal_user_orders_snapshot(
        self, slugs: set[str]
    ) -> tuple[
        dict[tuple[str, str], dict[str, Any]],
        dict[tuple[str, str], dict[str, Any]],
        set[str],
    ]:
        """Fetch order-level terminal state from the official endpoint.

        ``/orders/status/batch`` documents execution/settlement data, not an
        order lifecycle status.  MATCHED/CANCELED/UNMATCHED therefore comes
        from per-market user-orders and is joined to batch execution by exact
        order/client ID.  A missing/malformed page stays unresolved.
        """
        by_id: dict[tuple[str, str], dict[str, Any]] = {}
        by_client: dict[tuple[str, str], dict[str, Any]] = {}
        verified_slugs: set[str] = set()
        terminal_statuses = {"MATCHED", "CANCELED", "UNMATCHED"}
        query = (
            "statuses=MATCHED&statuses=CANCELED&statuses=UNMATCHED&limit=1000"
        )
        for slug in sorted(slugs):
            resp = await self._request(
                "GET", f"/markets/{slug}/user-orders?{query}"
            )
            if (
                not isinstance(resp, dict)
                or "error" in resp
                or not isinstance(resp.get("orders"), list)
            ):
                log.warning(
                    "limitless_terminal_user_orders_invalid", slug=slug
                )
                continue
            valid = True
            staged_ids: dict[tuple[str, str], dict[str, Any]] = {}
            staged_clients: dict[tuple[str, str], dict[str, Any]] = {}
            for row in resp["orders"]:
                if not isinstance(row, dict):
                    valid = False
                    break
                order_id, client_id, status = self._user_order_fields(row)
                if status not in terminal_statuses or not (order_id or client_id):
                    valid = False
                    break
                if order_id:
                    staged_ids[(slug, order_id)] = row
                if client_id:
                    staged_clients[(slug, client_id)] = row
            if not valid:
                log.warning(
                    "limitless_terminal_user_orders_row_invalid", slug=slug
                )
                continue
            by_id.update(staged_ids)
            by_client.update(staged_clients)
            verified_slugs.add(slug)
        return by_id, by_client, verified_slugs

    async def _reconcile_order_scope(self, live_rows: list[dict]) -> bool:
        """Prove every durable record is LIVE-visible or terminal by ID.

        An empty per-market response validates transport/schema only. It is
        not proof against a POST whose response timed out and which becomes
        visible later. Missing records therefore require exact batch status;
        ``not_found`` stays unresolved and blocks a clean shutdown.
        """
        self._terminal_orders_by_id = {}
        self._terminal_orders_by_client = {}
        if self._order_scope_legacy_slugs:
            # Legacy slug-only records have no durable client/order ID. They
            # require manual cleanup after wallet inspection.
            return False

        live_fields = [self._user_order_fields(row) for row in live_rows]
        live_ids = {order_id for order_id, _, _ in live_fields if order_id}
        live_client_ids = {
            client_id for _, client_id, _ in live_fields if client_id
        }
        missing = [
            dict(record)
            for client_id, record in self._order_scope_orders.items()
            if client_id not in live_client_ids
            and (
                not record.get("order_id")
                or str(record["order_id"]) not in live_ids
            )
        ]
        if not missing:
            return True

        missing_slugs = {str(record["slug"]) for record in missing}
        (
            terminal_by_id,
            terminal_by_client,
            terminal_verified_slugs,
        ) = await self._terminal_user_orders_snapshot(missing_slugs)
        self._terminal_orders_by_id = terminal_by_id
        self._terminal_orders_by_client = terminal_by_client

        terminal_clients: set[str] = set()
        fully_reconciled = terminal_verified_slugs == missing_slugs
        for start in range(0, len(missing), 50):
            chunk = missing[start:start + 50]
            resp = await self._request(
                "POST",
                "/orders/status/batch",
                {
                    "items": [
                        {"clientOrderId": str(record["client_order_id"])}
                        for record in chunk
                    ]
                },
            )
            if not isinstance(resp, dict) or "error" in resp:
                fully_reconciled = False
                continue
            results = resp.get("results")
            if not isinstance(results, list):
                fully_reconciled = False
                continue
            by_index: dict[int, dict[str, Any]] = {}
            for fallback_index, result in enumerate(results):
                if not isinstance(result, dict):
                    continue
                try:
                    result_index = int(result.get("index", fallback_index))
                except (TypeError, ValueError):
                    continue
                if 0 <= result_index < len(chunk):
                    by_index[result_index] = result

            for index, record in enumerate(chunk):
                result = by_index.get(index)
                if not result or str(result.get("status", "")).lower() != "found":
                    fully_reconciled = False
                    continue
                data = (
                    result.get("data")
                    if isinstance(result.get("data"), dict)
                    else {}
                )
                outer_order = (
                    data.get("order")
                    if isinstance(data.get("order"), dict)
                    else {}
                )
                details = (
                    outer_order.get("order")
                    if isinstance(outer_order.get("order"), dict)
                    else outer_order
                )
                execution = (
                    data.get("execution")
                    if isinstance(data.get("execution"), dict)
                    else {}
                )
                if isinstance(outer_order.get("execution"), dict):
                    execution = {**execution, **outer_order["execution"]}
                actual_id = str(
                    details.get("id")
                    or result.get("orderId")
                    or record.get("order_id")
                    or ""
                )
                client_id = str(record["client_order_id"])
                if actual_id and not record.get("order_id"):
                    self._bind_scope_order_id(client_id, actual_id)
                slug = str(record["slug"])
                terminal_row = (
                    terminal_by_id.get((slug, actual_id)) if actual_id else None
                ) or terminal_by_client.get((slug, client_id))
                if terminal_row is None:
                    fully_reconciled = False
                    continue
                terminal_id, terminal_client, terminal_status = (
                    self._user_order_fields(terminal_row)
                )
                if (
                    terminal_id
                    and actual_id
                    and terminal_id != actual_id
                ) or (
                    terminal_client
                    and terminal_client != client_id
                ):
                    fully_reconciled = False
                    continue
                terminal_details = {**details, "status": terminal_status}
                if self._scope_order_is_terminal(
                    record, terminal_details, execution
                ):
                    terminal_clients.add(str(record["client_order_id"]))
                else:
                    fully_reconciled = False

        if terminal_clients and not self._forget_scope_orders(
            client_order_ids=terminal_clients
        ):
            return False
        return fully_reconciled

    # ── lifecycle ─────────────────────────────────────────────────────

    async def start(self, token_ids: list[str]) -> None:
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=15)
            )
        if not settings.paper_trading:
            await self._init_live_client()
        for tid in token_ids:
            self._feed._subscribed.add(tid)
            info = self.markets.get(tid)
            tick = info.tick_size if info else LIMITLESS_DEFAULT_PRICE_TICK
            self.books.setdefault(tid, MarketBook(token_id=tid, tick_size=tick))
        self._ensure_polling()
        self._ensure_trade_polling()
        log.info("limitless_service_started", markets=len(token_ids))

    def _ensure_polling(self) -> None:
        """Start the REST poll loop if it isn't running.

        v1.0.150: when startup discovery fails (e.g. 429), main.py never
        calls start() — markets added later via auto-refill or the admin
        API were then quoted on a book fetched exactly once, until the
        STALE_DATA breaker halted trading. Any subscribe path now lazily
        (re)arms the loop.
        """
        if self._poll_task is None or self._poll_task.done():
            self._running = True
            self._poll_task = asyncio.create_task(
                self._poll_loop(), name="limitless_book_poll"
            )
            log.info("limitless_poll_loop_started")

    def _ensure_trade_polling(self) -> None:
        """Start the authenticated public ``NEW_TRADE`` feed poller.

        Limitless exposes public market books over Socket.IO, but its public
        WebSocket protocol has no trade event.  The official market feed
        endpoint is the authoritative source that includes strategy, outcome,
        contract amount, transaction hash and timestamp.
        """
        if self._trade_poll_task is None or self._trade_poll_task.done():
            self._running = True
            self._trade_poll_task = asyncio.create_task(
                self._trade_feed_loop(), name="limitless_public_trade_feed"
            )
            log.info("limitless_public_trade_feed_started")

    async def stop(self) -> None:
        self._running = False
        for task in (self._poll_task, self._trade_poll_task):
            if task:
                task.cancel()
        for task in (self._poll_task, self._trade_poll_task):
            if not task:
                continue
            try:
                await task
            except (asyncio.CancelledError, Exception):
                pass
        if self._session:
            await self._session.close()
        log.info("limitless_service_stopped")

    async def _init_live_client(self) -> None:
        """Load wallet + profile (ownerId, feeRateBps)."""
        _ensure_eth_deps()
        from eth_account import Account

        pk = settings.limitless_private_key
        if not pk:
            raise RuntimeError("LIMITLESS_PRIVATE_KEY not set")
        if not settings.limitless_dedicated_eoa:
            raise RuntimeError(
                "LIMITLESS_DEDICATED_EOA=true is required: use an external "
                "EOA reserved exclusively for this bot"
            )
        if not self._order_scope_verified:
            raise RuntimeError(
                "Limitless order-scope ledger is unreadable; LIVE is blocked"
            )
        if not settings.limitless_api_token_id or not settings.limitless_api_secret:
            raise RuntimeError(
                "LIMITLESS_API_TOKEN_ID / LIMITLESS_API_SECRET not set "
                "(generate at limitless.exchange → profile → Api keys)"
            )
        self._account = Account.from_key(pk)
        if (
            self._order_scope_account
            and self._order_scope_account != self._account.address.lower()
        ):
            raise RuntimeError(
                "Limitless order-scope ledger belongs to another EOA; "
                "use that key to clean it or configure a separate scope file"
            )

        profile = await self._request("GET", "/profiles/me")
        if not profile or "id" not in profile:
            raise RuntimeError(f"Failed to fetch Limitless profile: {profile}")
        self._owner_id = int(profile["id"])
        profile_account = profile.get("account") or profile.get("walletAddress")
        if isinstance(profile_account, dict):
            profile_account = (
                profile_account.get("address") or profile_account.get("account")
            )
        wallet_option = str(
            profile.get("tradeWalletOption")
            or profile.get("trade_wallet_option")
            or profile.get("walletType")
            or ""
        ).lower()
        if "smart" in wallet_option or "server" in wallet_option:
            raise RuntimeError(
                "This adapter signs EOA orders (signatureType=0), but the "
                f"Limitless profile selects {wallet_option!r}. Smart/server "
                "wallet delegated signing is not implemented; LIVE is blocked."
            )
        if profile_account and str(profile_account).lower() != self._account.address.lower():
            raise RuntimeError(
                "Limitless profile account does not match LIMITLESS_PRIVATE_KEY: "
                f"profile={str(profile_account)[:10]}..., "
                f"key={self._account.address[:10]}..."
            )
        # rank.feeRateBps — REQUIRED in signed orders on fee-bearing markets.
        # Hardcoding 0 works only on zero-fee markets (per official docs).
        rank = profile.get("rank") or {}
        self._fee_rate_bps = int(rank.get("feeRateBps", 0))
        log.info(
            "limitless_profile_loaded",
            owner_id=self._owner_id,
            fee_rate_bps=self._fee_rate_bps,
            address=self._account.address[:10],
        )

    # ── auth ──────────────────────────────────────────────────────────

    def _sign_request(self, method: str, path: str, body: str = "") -> dict:
        """HMAC-SHA256 per Limitless docs.

        message = "{ISO timestamp}\\n{METHOD}\\n{path+query}\\n{body}"
        Timestamp must be within 30s of server time → keep host NTP-synced.
        """
        timestamp = datetime.now(timezone.utc).isoformat()
        message = f"{timestamp}\n{method}\n{path}\n{body}"
        secret = base64.b64decode(settings.limitless_api_secret)
        signature = base64.b64encode(
            hmac_mod.new(secret, message.encode("utf-8"), hashlib.sha256).digest()
        ).decode("utf-8")
        return {
            "lmts-api-key": settings.limitless_api_token_id,
            "lmts-timestamp": timestamp,
            "lmts-signature": signature,
        }

    async def _request(
        self, method: str, path: str, body: dict | None = None
    ) -> Any:
        # v1.0.149 FIX: main.py calls discover_markets() BEFORE start() —
        # create the session lazily instead of asserting it exists.
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=15)
            )
        body_str = json.dumps(body) if body is not None else ""
        headers = self._sign_request(method, path, body_str)
        if body is not None:
            headers["Content-Type"] = "application/json"
        started = time.monotonic()
        try:
            async with self._session.request(
                method, f"{API_BASE}{path}",
                data=body_str if body is not None else None,
                headers=headers,
            ) as resp:
                if resp.status == 425:
                    # Receive-window / stale timestamp. Docs: do NOT retry the
                    # same signed payload — caller must rebuild + resign.
                    log.warning("limitless_425_too_early", path=path)
                    return {"error": "425_too_early"}
                if resp.status == 429:
                    # Cloudflare rate limit (error code 1015) — body is plain
                    # text, not JSON. Verified live 2026-07-12: polling too
                    # many books trips this per-IP limit.
                    log.warning(
                        "limitless_rate_limited",
                        path=path,
                        retry_after=resp.headers.get("Retry-After"),
                    )
                    return {"error": "http_429"}
                if resp.status == 503:
                    # Maintenance mode (post_only / cancel_only / disabled)
                    data = await resp.json(content_type=None)
                    log.warning("limitless_maintenance", mode=data.get("mode"))
                    return {"error": "maintenance", **(data or {})}
                try:
                    data = await resp.json(content_type=None)
                except (aiohttp.ContentTypeError, json.JSONDecodeError, ValueError) as exc:
                    text = await resp.text()
                    log.warning(
                        "limitless_response_decode_failed",
                        method=method,
                        path=path,
                        status=resp.status,
                        error_type=type(exc).__name__,
                        error_message=str(exc) or repr(exc),
                        response_preview=text[:200],
                    )
                    return {
                        "error": "invalid_json_response",
                        "status": resp.status,
                    }
                if resp.status >= 400:
                    log.warning(
                        "limitless_http_error",
                        path=path, status=resp.status,
                        message=str(data)[:200],
                    )
                    return {"error": f"http_{resp.status}", "detail": data}
                return data
        except asyncio.TimeoutError as exc:
            elapsed = time.monotonic() - started
            log.warning(
                "limitless_request_failed",
                method=method,
                path=path,
                error_type=type(exc).__name__,
                error_message=str(exc) or repr(exc),
                elapsed_sec=round(elapsed, 3),
                retryable=True,
            )
            return {
                "error": "request_timeout",
                "error_type": type(exc).__name__,
            }
        except aiohttp.ClientError as exc:
            elapsed = time.monotonic() - started
            log.warning(
                "limitless_request_failed",
                method=method,
                path=path,
                error_type=type(exc).__name__,
                error_message=str(exc) or repr(exc),
                elapsed_sec=round(elapsed, 3),
                retryable=True,
            )
            return {
                "error": "client_error",
                "error_type": type(exc).__name__,
            }
        except Exception as exc:
            elapsed = time.monotonic() - started
            log.warning(
                "limitless_request_failed",
                method=method,
                path=path,
                error_type=type(exc).__name__,
                error_message=str(exc) or repr(exc),
                elapsed_sec=round(elapsed, 3),
                retryable=False,
            )
            return {
                "error": "request_exception",
                "error_type": type(exc).__name__,
            }

    # ── market discovery ──────────────────────────────────────────────

    async def discover_markets(self) -> list[MarketInfo]:
        """GET /markets/active → top auto_pick_count MarketInfo (YES token).

        Mirrors ClobService.discover_markets contract: filter by spread band
        [auto_pick_min_spread_cents, 30¢] and mid-price band [0.10, 0.90],
        score candidates, return the top auto_pick_count picks.

        Field mapping verified against the live payload (2026-07-12):
          expirationTimestamp — ms epoch (expirationDate is "Jul 12, 2026",
            NOT ISO — fromisoformat fails → every market fell back to now+24h,
            breaking PRE_RESOLUTION_EXIT on hourly markets);
          volumeFormatted — human USDC ("volume" is a raw 6-decimals string,
            ×1e6 inflated); metadata.fee — per-market fee flag (no
            "feeBearing" key); negRiskRequestId/groupId (no "group" key);
          tradePrices.{sell,buy}.market[0] — best bid/ask for YES.
        """
        data = await self._request("GET", "/markets/active")
        if not data or "error" in (data if isinstance(data, dict) else {}):
            return []
        raw_markets = data if isinstance(data, list) else data.get("data", [])
        fast_flat = settings.strategy_mode == "fast_flat"
        min_spread_cents = (
            settings.fast_flat_min_spread_cents
            if fast_flat
            else settings.auto_pick_min_spread_cents
        )
        max_spread_cents = (
            settings.fast_flat_max_spread_cents if fast_flat else 30.0
        )
        min_spread = min_spread_cents / 100.0
        max_spread = max_spread_cents / 100.0
        now_ts = time.time()
        # v1.0.150: don't pick a market that will hit PRE_RESOLUTION_EXIT
        # within 5 minutes of being picked (observed live: refill re-picked
        # the expiring daily whose spread ballooned to 30¢ right before
        # resolution, wasting the slot on an emptying book). ClobService
        # uses a flat 1h guard — that would permanently exclude Limitless
        # hourly markets, so the horizon adapts to pre_resolution_exit_sec.
        min_ttr_sec = settings.pre_resolution_exit_sec + 300.0
        if fast_flat:
            min_ttr_sec = max(min_ttr_sec, settings.fast_flat_min_ttr_sec)
        candidates: list[tuple[float, MarketInfo, _MarketMeta, float, dict]] = []
        for m in raw_markets:
            try:
                slug = m["slug"]
                tokens = m.get("tokens") or {}
                yes_token = str(tokens.get("yes", ""))
                no_token = str(tokens.get("no", ""))
                if not yes_token:
                    continue
                venue = m.get("venue") or {}
                exp_ms = m.get("expirationTimestamp")
                if exp_ms:
                    end_ts = float(exp_ms) / 1000.0
                else:
                    end_ts = _parse_iso_ts(
                        m.get("deadline") or m.get("expirationDate") or ""
                    )
                title = (m.get("title") or m.get("question") or slug).lower()
                is_15m = (
                    fast_flat
                    and settings.fast_flat_15m_profile_enabled
                    and any(marker in title for marker in ("15m", "15 min", "15-min", "15 minute"))
                )
                market_min_ttr = min_ttr_sec
                if is_15m:
                    market_min_ttr = max(
                        settings.fast_flat_15m_min_ttr_sec,
                        settings.fast_flat_15m_entry_ttl_sec
                        + settings.fast_flat_15m_rescue_after_sec
                        + settings.fast_flat_15m_pre_resolution_exit_sec,
                    )
                if end_ts - now_ts < market_min_ttr:
                    continue
                try:
                    vol_24h = float(m.get("volumeFormatted") or 0.0)
                except (TypeError, ValueError):
                    vol_24h = 0.0
                # Best bid/ask for YES from tradePrices (index 0 = YES):
                # sell-at-market hits the best bid, buy-at-market lifts the ask.
                tp = m.get("tradePrices") or {}
                try:
                    best_bid = float(((tp.get("sell") or {}).get("market") or [0])[0])
                    best_ask = float(((tp.get("buy") or {}).get("market") or [0])[0])
                except (TypeError, ValueError, IndexError):
                    best_bid = best_ask = 0.0
                spread = (
                    best_ask - best_bid if best_bid > 0 and best_ask > 0 else 0.0
                )
                if spread < min_spread:
                    continue
                # Same guard as ClobService v1.0.44: spread > 30¢ = near-empty
                # book, MM can't operate there.
                if spread > max_spread:
                    continue
                mid = (best_bid + best_ask) / 2.0
                if mid < 0.10 or mid > 0.90:
                    continue
                metadata = m.get("metadata") or {}
                # settings.minSize (fallback metadata.minSize): LP-rewards
                # qualification threshold in shares, raw 6-decimals string.
                raw_min = (m.get("settings") or {}).get("minSize")
                if raw_min is None:
                    raw_min = metadata.get("minSize")
                try:
                    min_size_shares = float(raw_min) / 1e6 if raw_min else 0.0
                except (TypeError, ValueError):
                    min_size_shares = 0.0
                info = MarketInfo(
                    token_id=yes_token,
                    condition_id=slug,  # slug plays the conditionId role
                    question=m.get("title") or m.get("question") or slug,
                    outcome="Yes",
                    end_date_ts=end_ts,
                    volume_24h=vol_24h,
                    tick_size=_market_price_tick(m),
                    neg_risk=bool(
                        m.get("negRiskRequestId") or m.get("groupId")
                    ),
                    min_size=min_size_shares,
                )
                meta = _MarketMeta(
                    slug=slug,
                    venue_exchange=str(venue.get("exchange") or ""),
                    venue_adapter=str(venue.get("adapter") or ""),
                    yes_token=yes_token,
                    no_token=no_token,
                    fee_bearing=bool(metadata.get("fee", False)),
                    neg_risk=info.neg_risk,
                )
                # v1.0.155 (GLM §3): HARD volume floor — a wide spread on a
                # dead book is a trap, not an edge. No volume → never picked.
                # v1.0.159: …UNLESS the market is simply too YOUNG to have any
                # 24h volume yet (deadlock 2026-07-14: after the 16:00 rollover
                # every fresh daily had <$50k and the bot was left with ZERO
                # markets). Young markets skip the volume check and are judged
                # on book DEPTH instead — checked below, after the cheap
                # spread/price filters, so we only pay for the extra orderbook
                # request on real candidates.
                created_ts = _parse_iso_ts(m.get("createdAt") or "")
                age_sec = now_ts - created_ts if created_ts else 1e9
                is_young = age_sec < settings.auto_pick_young_market_age_sec
                needs_depth_check = vol_24h < settings.auto_pick_min_volume_usd
                if needs_depth_check and not is_young:
                    continue
                if needs_depth_check and is_young:
                    # Young market: volume is excused, DEPTH is not. A thin
                    # book (the ARB/HYPE tail source) must not slip through.
                    if not await self._has_min_depth(slug):
                        log.info(
                            "limitless_young_market_too_thin",
                            slug=slug,
                            age_min=round(age_sec / 60, 0),
                            reason="young market exempt from volume floor but book too thin",
                        )
                        continue
                    log.info(
                        "limitless_young_market_exempt",
                        slug=slug,
                        age_min=round(age_sec / 60, 0),
                        volume_24h=round(vol_24h, 0),
                        reason="too young for 24h volume — passed on spread + depth",
                    )
                # Same scoring shape as ClobService, with 1+vol so brand-new
                # hourly markets (volume 0) still rank by uncertainty×spread.
                uncertainty = 1.0 - abs(mid - 0.5) * 2
                spread_bonus = 1.0 + (spread * 50)
                # v1.0.155: preferred-spread bonus (wide-but-liquid wins)
                preferred_bonus = (
                    1.5
                    if spread * 100.0 >= settings.auto_pick_preferred_spread_cents
                    else 1.0
                )
                volume_score = 1.0 + vol_24h
                score = volume_score * uncertainty * spread_bonus * preferred_bonus
                candidates.append(
                    (score, info, meta, spread,
                     {"spread_score": round(spread_bonus, 2),
                      "volume_score": round(volume_score, 0),
                      "uncertainty": round(uncertainty, 3),
                      "preferred_bonus": preferred_bonus})
                )
            except Exception as e:
                log.warning("limitless_market_parse_failed", error=str(e))
        candidates.sort(key=lambda x: x[0], reverse=True)
        top = candidates[: settings.auto_pick_count]
        out: list[MarketInfo] = []
        for score, info, meta, spread, breakdown in top:
            self._meta[info.token_id] = meta
            self._slug_by_token[info.token_id] = meta.slug
            self.markets[info.token_id] = info
            # v1.0.157: the API just listed it as active → polling allowed again
            self._dead_markets.discard(info.token_id)
            out.append(info)
            log.info(
                "limitless_market_picked",
                question=info.question[:55],
                spread_cents=round(spread * 100, 1),
                volume_24h=round(info.volume_24h, 0),
                score=round(score, 1),
                score_breakdown=breakdown,
                lp_rewards_min_shares=info.min_size,
            )
        log.info(
            "limitless_markets_discovered",
            candidates=len(candidates),
            picked=len(out),
            total_active=len(raw_markets),
            min_spread_cents=min_spread_cents,
            max_spread_cents=max_spread_cents,
        )
        return out

    async def _has_min_depth(self, slug: str) -> bool:
        """v1.0.159: does the book carry real size on BOTH sides?

        Used only for the young-market volume exemption: a fresh market has
        no 24h volume by definition, so we judge its liveness by depth
        instead. Resting notional on each side must cover at least
        auto_pick_young_min_depth_mult × our order size.
        """
        required = (
            settings.order_size_usdc * settings.auto_pick_young_min_depth_mult
        )
        if required <= 0:
            return True
        data = await self._request("GET", f"/markets/{slug}/orderbook")
        if not data or not isinstance(data, dict) or "error" in data:
            return False

        def notional(levels: list) -> float:
            total = 0.0
            for lvl in levels or []:
                try:
                    if isinstance(lvl, dict):
                        price, size = float(lvl["price"]), float(lvl["size"])
                    else:
                        price, size = float(lvl[0]), float(lvl[1])
                    total += price * size
                except (TypeError, ValueError, KeyError, IndexError):
                    continue
            return total

        bid_usd = notional(data.get("bids"))
        ask_usd = notional(data.get("asks"))
        return bid_usd >= required and ask_usd >= required

    async def fetch_market_status(self, token_id: str) -> dict | None:
        slug = self._slug_by_token.get(token_id)
        if not slug:
            return None
        m = await self._request("GET", f"/markets/{slug}")
        if not m or "error" in (m or {}):
            return None
        # Shape compat with the reconciliation consumer.  LOCKED means that
        # trading has stopped, not that an outcome is final; only RESOLVED is
        # safe to settle.
        status = str(m.get("status", "")).upper()
        winning_index = m.get("winningOutcomeIndex")
        if winning_index is None:
            winning_index = m.get("winning_index")
        if winning_index is None:
            winning_index = m.get("winningIndex")
        try:
            resolved_price = 1.0 if int(winning_index) == 0 else 0.0
        except (TypeError, ValueError):
            resolved_price = None
        is_resolved = status == "RESOLVED" and resolved_price is not None
        return {
            "active": status in ("FUNDED", "FUNDED_FLAGGED"),
            "closed": status in ("RESOLVED", "LOCKED"),
            "is_resolved": is_resolved,
            "resolved_price": resolved_price if is_resolved else None,
            "raw": m,
        }

    # ── order book polling ────────────────────────────────────────────

    async def _poll_loop(self) -> None:
        """REST polling of orderbooks.

        v1 uses polling (same fallback pattern botmm already has for
        Polymarket). Socket.IO WS (/markets namespace) is a later upgrade —
        python-socketio client needed, see websocket-events docs.
        """
        interval = getattr(settings, "limitless_book_poll_sec", 1.5)
        while self._running:
            try:
                await asyncio.gather(
                    *(self._fetch_book(tid) for tid in list(self.books.keys()))
                )
            except Exception as e:
                log.warning("limitless_poll_error", error=str(e))
            await asyncio.sleep(interval)

    @property
    def public_trade_seq(self) -> int:
        return self._public_trade_seq

    def public_trades_since(
        self, token_id: str, after_seq: int, *, placed_wall_time: float = 0.0
    ) -> list[PublicTrade]:
        """Return deduplicated real trades received after a quote cursor."""
        return [
            trade for trade in self._public_trades.get(token_id, ())
            if trade.seq > after_seq and trade.traded_at >= placed_wall_time
        ]

    async def _trade_feed_loop(self) -> None:
        interval = max(0.5, float(getattr(settings, "limitless_book_poll_sec", 1.5)))
        while self._running:
            try:
                by_slug: dict[str, str] = {}
                for token_id in list(self.books):
                    slug = self._slug_by_token.get(token_id)
                    if slug and token_id not in self._dead_markets:
                        by_slug.setdefault(slug, token_id)
                await asyncio.gather(
                    *(self._fetch_trade_feed(slug, token_id)
                      for slug, token_id in by_slug.items()),
                    return_exceptions=True,
                )
            except Exception as exc:
                log.warning("limitless_trade_feed_loop_error", error=str(exc))
            await asyncio.sleep(interval)

    async def _fetch_trade_feed(self, slug: str, token_id: str) -> None:
        payload = await self._request(
            "GET", f"/markets/{slug}/get-feed-events?page=1&limit=100"
        )
        if not isinstance(payload, dict) or payload.get("error"):
            return
        raw_events = payload.get("events")
        if raw_events is None:
            nested = payload.get("data")
            if isinstance(nested, dict):
                raw_events = nested.get("data") or nested.get("events")
        if not isinstance(raw_events, list):
            return

        # The first response is a historical snapshot.  Seed deduplication but
        # never replay old trades into newly-created PAPER quotes.
        seed_only = slug not in self._trade_feed_seeded_slugs
        accepted = 0
        for event in sorted(
            raw_events, key=lambda row: str(row.get("timestamp", ""))
            if isinstance(row, dict) else ""
        ):
            if not isinstance(event, dict) or event.get("eventType") != "NEW_TRADE":
                continue
            data = event.get("data")
            if not isinstance(data, dict):
                continue
            tx_hash = str(data.get("txHash") or "")
            key = str(event.get("bodyHash") or "") or "|".join((
                tx_hash,
                str(event.get("timestamp") or ""),
                str(data.get("strategy") or ""),
                str(data.get("outcome") or ""),
                str(data.get("contracts") or ""),
            ))
            if not key or key in self._seen_trade_keys:
                continue
            self._remember_trade_key(key)
            if seed_only:
                continue
            trade = self._normalize_public_trade(token_id, key, event)
            if trade is None:
                continue
            self._public_trades[token_id].append(trade)
            accepted += 1
        self._trade_feed_seeded_slugs.add(slug)
        if accepted:
            log.info(
                "limitless_public_trades_received",
                slug=slug,
                count=accepted,
                last_seq=self._public_trade_seq,
            )

    def _remember_trade_key(self, key: str) -> None:
        if len(self._seen_trade_key_order) == self._seen_trade_key_order.maxlen:
            oldest = self._seen_trade_key_order.popleft()
            self._seen_trade_keys.discard(oldest)
        self._seen_trade_key_order.append(key)
        self._seen_trade_keys.add(key)

    def _normalize_public_trade(
        self, token_id: str, event_key: str, event: dict[str, Any]
    ) -> PublicTrade | None:
        data = event.get("data") or {}
        strategy = str(data.get("strategy") or "").strip().upper()
        outcome = str(data.get("outcome") or "").strip().upper()
        contracts = _safe_float(data.get("contracts"))
        collateral = _safe_float(data.get("tradeAmount"))
        if strategy not in {"BUY", "SELL"} or outcome not in {"YES", "NO"}:
            return None
        if contracts <= 0 or collateral <= 0:
            return None
        raw_price = collateral / contracts
        if not (0 < raw_price < 1):
            return None
        side = strategy
        price = raw_price
        if outcome == "NO":
            side = "SELL" if strategy == "BUY" else "BUY"
            price = 1.0 - raw_price
        traded_at = _parse_iso_ts(str(event.get("timestamp") or ""))
        self._public_trade_seq += 1
        return PublicTrade(
            seq=self._public_trade_seq,
            event_key=event_key,
            token_id=token_id,
            side=side,
            price=price,
            contracts=contracts,
            traded_at=traded_at,
            tx_hash=str(data.get("txHash") or ""),
        )

    async def _fetch_book(self, token_id: str) -> None:
        slug = self._slug_by_token.get(token_id)
        if not slug:
            # v1.0.150 observability: this and the empty-payload case below
            # were silent — 18 transient STALE_DATA halts on 2026-07-12 gave
            # zero log evidence. Errors are already logged inside _request;
            # here we only log the previously-invisible reasons.
            log.warning("limitless_book_no_slug", token=token_id[:12])
            return
        # v1.0.157 noise cleanup: a resolved market keeps getting polled until
        # the next refill, and every poll returns HTTP 400 "Market is not
        # active" (13,315 such rows in one session). Once seen, mark it dead
        # and stop polling; discover_markets() clears the flag when the market
        # comes back as active.
        if token_id in self._dead_markets:
            return
        data = await self._request("GET", f"/markets/{slug}/orderbook")
        if data is None:
            return  # network/HTTP failure — already logged inside _request
        if isinstance(data, dict) and data.get("error") == "http_400" and (
            "not active" in str(data.get("detail", "")).lower()
        ):
            self._dead_markets.add(token_id)
            log.info(
                "limitless_market_inactive_stop_polling",
                slug=slug,
                reason="market resolved/inactive — no polling until next refill",
            )
            return
        if not data or "error" in data:
            if "error" not in data:
                log.warning(
                    "limitless_book_empty_payload",
                    slug=slug,
                    data_type=type(data).__name__,
                )
            return
        info = self.markets.get(token_id)
        tick = info.tick_size if info else LIMITLESS_DEFAULT_PRICE_TICK
        book = self.books.setdefault(
            token_id, MarketBook(token_id=token_id, tick_size=tick)
        )
        # A book may have been created by the feed shim before discovery
        # metadata was available. Refresh the venue tick on every poll.
        book.tick_size = tick

        def parse(raw: list) -> list[OrderLevel]:
            out = []
            for lvl in raw or []:
                try:
                    if isinstance(lvl, dict):
                        out.append(OrderLevel(
                            price=float(lvl["price"]), size=float(lvl["size"])
                        ))
                    else:  # [price, size] pair
                        out.append(OrderLevel(price=float(lvl[0]), size=float(lvl[1])))
                except Exception:
                    continue
            return out

        bids = parse(data.get("bids"))
        asks = parse(data.get("asks"))
        book.bids = sorted(bids, key=lambda x: -x.price)
        book.asks = sorted(asks, key=lambda x: x.price)
        book.last_update = time.monotonic()
        # Limitless has NO $5 exchange minimum — dust logic keys off this.
        book.min_order_size = getattr(settings, "limitless_min_order_usdc", 0.0)
        self._last_book_update = time.monotonic()

    async def _refresh_all_books(self) -> None:
        """One-shot refresh of every tracked book (ClobService compat —
        called by MM auto-refill and /api/markets/replace)."""
        tids = list(self.books.keys())
        if tids:
            await asyncio.gather(
                *(self._fetch_book(tid) for tid in tids),
                return_exceptions=True,
            )

    # ── trading ───────────────────────────────────────────────────────

    async def place_order(
        self,
        token_id: str,
        side: str,  # "BUY" | "SELL"
        price: float,
        size_usdc: float,
        order_type: str = "GTC",  # GTC | FOK | FAK
        post_only: bool = True,
    ) -> OrderResult:
        """Same contract as ClobService.place_order.

        Amount math (per official docs, GTC):
          shares      = size_usdc / price
          BUY : makerAmount = price*shares*1e6, takerAmount = shares*1e6
          SELL: makerAmount = shares*1e6,       takerAmount = price*shares*1e6
        """
        if side not in ("BUY", "SELL"):
            return OrderResult(success=False, error=f"Invalid side: {side}")
        if not (0.01 <= price <= 0.99):
            return OrderResult(success=False, error=f"Price out of range: {price}")
        order_type = str(order_type).upper()

        # PAPER GTC fills are simulated by MarketMaker against later book
        # updates. FAK/FOK, however, have no resting lifetime: settle them now
        # from the visible top level so they cannot remain pending forever in a
        # mode which intentionally has no LIVE order-status poller.
        if settings.paper_trading:
            paper_id = f"PAPER-LMTS-{time.time_ns()}-{side[0]}"
            if order_type in ("FAK", "FOK"):
                book = self.books.get(token_id)
                level = None
                if book is not None:
                    if side == "SELL" and book.bids:
                        candidate = book.bids[0]
                        if candidate.price + 1e-12 >= price:
                            level = candidate
                    elif side == "BUY" and book.asks:
                        candidate = book.asks[0]
                        if candidate.price <= price + 1e-12:
                            level = candidate

                requested_tokens = size_usdc / max(price, 0.000001)
                available_tokens = _safe_float(level.size) if level else 0.0
                if order_type == "FOK" and available_tokens + 1e-9 < requested_tokens:
                    filled_tokens = 0.0
                else:
                    filled_tokens = min(requested_tokens, available_tokens)
                execution_price = float(level.price) if level else price
                usd_gross = filled_tokens * execution_price
                meta = self._meta.get(token_id)
                fee_bps = (
                    settings.taker_fee_bps_assumed
                    if meta is not None and meta.fee_bearing
                    else 0.0
                )
                fee_usdc = usd_gross * fee_bps / 10_000.0
                if side == "BUY":
                    contracts_fee = fee_usdc / max(execution_price, 0.000001)
                    contracts_net = max(0.0, filled_tokens - contracts_fee)
                    usd_net = usd_gross
                else:
                    contracts_fee = 0.0
                    contracts_net = filled_tokens
                    usd_net = max(0.0, usd_gross - fee_usdc)
                settlement = "CONFIRMED" if filled_tokens > 0 else "UNMATCHED"
                raw = {
                    "price": str(execution_price),
                    "filled_size_usdc": usd_gross,
                    "filled_tokens": filled_tokens,
                    "contractsGross": filled_tokens,
                    "contractsFee": contracts_fee,
                    "contractsNet": contracts_net,
                    "usdGross": usd_gross,
                    "usdNet": usd_net,
                    "usdFee": fee_usdc if side == "SELL" else 0.0,
                    "feeUsdc": fee_usdc,
                    "fillConfirmed": filled_tokens > 0,
                    "size_matched": usd_gross,
                    "settlementStatus": settlement,
                    "matched": filled_tokens > 0,
                    "terminal": True,
                    "pending": False,
                }
                return OrderResult(
                    success=True,
                    order_id=paper_id,
                    raw=raw,
                    filled_size_usdc=usd_gross,
                    filled_tokens=filled_tokens,
                    fill_price=execution_price if filled_tokens > 0 else None,
                    settlement_status=settlement,
                    terminal=True,
                    fill_confirmed=filled_tokens > 0,
                )
            return OrderResult(
                success=True,
                order_id=paper_id,
                raw={"price": str(price), "size_usdc": size_usdc},
            )

        if order_type == "FOK":
            # Limitless LIVE FOK uses a different wire contract
            # (takerAmount=1 and no REST price).  FAST_FLAT uses FAK only;
            # fail closed instead of signing the GTC/FAK shape as FOK.
            return OrderResult(
                success=False,
                error="Limitless LIVE FOK is unsupported; use FAK or GTC",
            )

        meta = self._meta.get(token_id)
        if not meta:
            return OrderResult(success=False, error="Unknown market for token")
        if not meta.venue_exchange:
            return OrderResult(success=False, error="Missing venue.exchange")
        try:
            # Check before BUY as well as SELL: acquiring a position without
            # transfer approval would create the exact cannot-exit trap this
            # strategy is designed to avoid. Previously verified operators
            # are cached for the lifetime of the dedicated EOA process.
            await self._verify_conditional_token_approvals(
                self._conditional_operators_for_meta(meta)
            )
        except Exception as exc:
            return OrderResult(
                success=False,
                error=f"Conditional Tokens approval preflight failed: {exc}",
            )
        if order_type == "GTD":
            order_type = "GTC"  # Limitless has no GTD; expiration must be 0

        from eth_account import Account
        from eth_account.messages import encode_typed_data
        from web3 import Web3

        # Signed amounts must be derived with decimal arithmetic.  Binary
        # floats can turn values such as 0.95 into 949999 micro-units.
        try:
            price_dec = Decimal(str(price))
            size_dec = Decimal(str(size_usdc))
            shares_dec = size_dec / price_dec
            micro = Decimal(1_000_000)
        except (InvalidOperation, ZeroDivisionError):
            return OrderResult(success=False, error="Invalid decimal amount")
        if side == "BUY":
            maker_amount = int((size_dec * micro).to_integral_value(rounding=ROUND_DOWN))
            taker_amount = int((shares_dec * micro).to_integral_value(rounding=ROUND_DOWN))
            side_int = 0
        else:
            maker_amount = int((shares_dec * micro).to_integral_value(rounding=ROUND_DOWN))
            taker_amount = int(
                (Decimal(maker_amount) * price_dec).to_integral_value(
                    rounding=ROUND_DOWN
                )
            )
            side_int = 1

        fee_bps = self._fee_rate_bps if meta.fee_bearing else 0

        order_data = {
            # A millisecond timestamp collides when bid and ask are built in
            # the same loop.  A random uint128 remains valid EIP-712 uint256
            # while making each signed order unique.
            "salt": secrets.randbits(128),
            "maker": Web3.to_checksum_address(self._account.address),
            "signer": Web3.to_checksum_address(self._account.address),
            "taker": ZERO_ADDR,
            "tokenId": token_id,
            "makerAmount": maker_amount,
            "takerAmount": taker_amount,
            "expiration": 0,   # must be 0 — non-zero rejected
            "nonce": 0,        # must be 0 — non-zero rejected
            "feeRateBps": fee_bps,
            "side": side_int,
            "signatureType": 0,  # EOA
        }
        encoded = encode_typed_data(full_message={
            "types": ORDER_TYPES,
            "primaryType": "Order",
            "domain": {
                "name": EIP712_DOMAIN_NAME,
                "version": EIP712_DOMAIN_VERSION,
                "chainId": CHAIN_ID,
                "verifyingContract": Web3.to_checksum_address(meta.venue_exchange),
            },
            "message": order_data,
        })
        sig = Account.sign_message(
            encoded, private_key=settings.limitless_private_key
        ).signature.hex()
        if not sig.startswith("0x"):
            sig = "0x" + sig

        client_order_id = (
            f"argo-{side.lower()}-{time.time_ns()}-{secrets.token_hex(4)}"
        )
        # Keep uint256 values as integers in the EIP-712 message, but encode
        # the unbounded salt and documented string expiration as JSON strings
        # on the REST wire.  A random uint128 sent as a JSON number can be
        # rounded by JavaScript/TypeScript infrastructure above 2**53 and no
        # longer match the signature that we created locally.
        wire_order = {
            **order_data,
            "salt": str(order_data["salt"]),
            "expiration": str(order_data["expiration"]),
            "price": round(price, 6),
            "signature": sig,
        }
        body = {
            # Limitless exposes price in the REST order shape even though the
            # signed economics are encoded by makerAmount/takerAmount.
            "order": wire_order,
            "ownerId": self._owner_id,
            "orderType": order_type,
            "marketSlug": meta.slug,
            "clientOrderId": client_order_id,
            "timestamp": int(time.time() * 1000),
            "recvWindow": 5000,
            # Self-trade prevention: cancel_taker = reject incoming order
            # instead of eating our own resting quote. Critical for MM —
            # our bid and ask must never fill against each other.
            "stpPolicy": "cancel_taker",
        }
        if post_only and order_type == "GTC":
            body["postOnly"] = True

        # Persist the market scope before the network call. If the process
        # dies after submission, the next run can still find/cancel this slug.
        try:
            self._remember_order_slug(meta.slug, client_order_id, order_type)
        except Exception as exc:
            return OrderResult(
                success=False,
                client_order_id=client_order_id,
                error=str(exc),
                raw={"submission_uncertain": False},
            )

        resp = await self._request("POST", "/orders", body)
        if not isinstance(resp, dict) or not resp or "error" in resp:
            explicit_error = (
                resp.get("error", "malformed_or_empty_response")
                if isinstance(resp, dict)
                else "malformed_or_empty_response"
            )
            error_code = str(explicit_error)
            # Default to uncertainty. Only responses which definitively reject
            # the signed payload may release its durable client-ID record.
            definitive_rejection = error_code in (
                "http_400",
                "http_401",
                "http_403",
                "http_404",
                "http_422",
                "425_too_early",
            )
            uncertain = not definitive_rejection
            if not uncertain:
                self._forget_scope_orders(client_order_ids={client_order_id})
            return OrderResult(
                success=False,
                client_order_id=client_order_id,
                error=str(explicit_error),
                raw={
                    "clientOrderId": client_order_id,
                    "salt": order_data["salt"],
                    "submission_uncertain": uncertain,
                    "response": resp,
                },
            )
        if not isinstance(resp.get("order"), dict) or not isinstance(
            resp.get("execution"), dict
        ):
            return OrderResult(
                success=False,
                client_order_id=client_order_id,
                error="malformed create-order success payload",
                raw={
                    "clientOrderId": client_order_id,
                    "salt": order_data["salt"],
                    "submission_uncertain": True,
                    "response": resp,
                },
            )
        order = resp["order"]
        execution = resp["execution"]
        settlement = str(execution.get("settlementStatus", "") or "").upper()
        exchange_order_id = str(order.get("id", ""))
        totals = execution.get("totalsRaw") or {}
        gross_size_usdc = _micro_amount(totals.get("usdGross"))
        net_size_usdc = _micro_amount(totals.get("usdNet"))
        gross_tokens = _micro_amount(totals.get("contractsGross"))
        net_tokens = _micro_amount(totals.get("contractsNet"))
        contracts_fee = _micro_amount(totals.get("contractsFee"))
        usd_fee = _micro_amount(totals.get("usdFee"))
        fill_confirmed = settlement in ("MINED", "CONFIRMED")
        filled_size_usdc = gross_size_usdc if fill_confirmed else 0.0
        filled_tokens = gross_tokens if fill_confirmed else 0.0
        fill_price = (
            gross_size_usdc / gross_tokens
            if gross_size_usdc > 0 and gross_tokens > 0
            else None
        )
        fee_usdc = usd_fee if usd_fee > 0 else contracts_fee * (fill_price or price)
        matched = bool(execution.get("matched", False)) or gross_tokens > 0
        scope_record = self._order_scope_orders.get(client_order_id) or {
            "order_type": order_type
        }
        terminal = self._scope_order_is_terminal(
            scope_record, order, execution
        )
        if settlement in ("FAILED", "CANCELED") and terminal:
            self._forget_scope_orders(client_order_ids={client_order_id})
            return OrderResult(
                success=False,
                order_id=exchange_order_id,
                client_order_id=client_order_id,
                error=f"settlement:{settlement}:{execution.get('reason','')}",
                raw={
                    "clientOrderId": client_order_id,
                    "settlementStatus": settlement,
                    "response": resp,
                },
                settlement_status=settlement,
                terminal=True,
            )
        ledger_bound = self._bind_scope_order_id(client_order_id, exchange_order_id)
        # Remove only after order-level terminal proof. For GTC this explicitly
        # excludes a failed/canceled settlement on one partial trade leg.
        if terminal:
            ledger_bound = (
                self._forget_scope_orders(client_order_ids={client_order_id})
                and ledger_bound
            )
        normalized_raw = {
            "price": str(fill_price if fill_price is not None else price),
            "filled_size_usdc": filled_size_usdc,
            "filled_tokens": filled_tokens,
            "provisional_size_usdc": gross_size_usdc,
            "provisional_tokens": gross_tokens,
            "contractsGross": gross_tokens,
            "contractsFee": contracts_fee,
            "contractsNet": net_tokens,
            "usdGross": gross_size_usdc,
            "usdNet": net_size_usdc,
            "usdFee": usd_fee,
            "feeUsdc": fee_usdc,
            "fillConfirmed": fill_confirmed,
            # Backwards-compatible key, now with an explicit zero when the
            # exchange accepted but did not fill the order.
            "size_matched": filled_size_usdc,
            "settlementStatus": settlement,
            "matched": matched,
            "terminal": terminal,
            "pending": not terminal,
            "eligibleAt": execution.get("eligibleAt"),
            "tradeEventId": execution.get("tradeEventId"),
            "clientOrderId": client_order_id,
            "feeRateBps": execution.get("feeRateBps", 0),
            "effectiveFeeBps": execution.get("effectiveFeeBps", 0),
            "totalsRaw": totals,
            "orderScopeVerified": ledger_bound,
            "response": resp,
        }
        return OrderResult(
            success=True,
            order_id=(
                exchange_order_id or f"client:{client_order_id}"
            ),
            client_order_id=client_order_id,
            raw=normalized_raw,
            filled_size_usdc=filled_size_usdc,
            filled_tokens=filled_tokens,
            fill_price=fill_price,
            settlement_status=settlement,
            terminal=terminal,
            fill_confirmed=fill_confirmed,
        )

    async def get_order_statuses(
        self, order_ids: list[str]
    ) -> dict[str, dict[str, Any]]:
        """Return normalized cumulative execution state for tracked orders.

        Limitless replaced Polymarket's per-order lookup with
        ``POST /orders/status/batch``.  Fill sizes here are cumulative; the MM
        stores the previously recorded amount and applies only the delta.
        """
        ids = [str(oid) for oid in order_ids if oid]
        if not ids:
            return {}
        if settings.paper_trading:
            return {}

        # _open_orders_snapshot may prune a now-terminal scope record after
        # proving it through user-orders + batch execution.  Retain a local
        # copy for this status response so the same proof can also terminate
        # the MarketMaker's pending-order record.
        scope_records = [
            dict(record) for record in self._order_scope_orders.values()
        ]
        open_orders, open_snapshot_valid = await self._open_orders_snapshot()
        open_fields = [self._user_order_fields(o) for o in open_orders]
        open_ids = {order_id for order_id, _, _ in open_fields if order_id}
        open_client_ids = {
            client_id for _, client_id, _ in open_fields if client_id
        }
        open_status_by_id = {
            order_id: status
            for order_id, _, status in open_fields
            if order_id and status
        }
        open_status_by_client = {
            client_id: status
            for _, client_id, status in open_fields
            if client_id and status
        }
        out: dict[str, dict[str, Any]] = {}
        terminal_client_ids: set[str] = set()
        terminal_order_ids: set[str] = set()
        for start in range(0, len(ids), 50):
            chunk = ids[start:start + 50]
            items = [
                ({"clientOrderId": oid[7:]} if oid.startswith("client:")
                 else {"orderId": oid})
                for oid in chunk
            ]
            resp = await self._request(
                "POST",
                "/orders/status/batch",
                {"items": items},
            )
            if not isinstance(resp, dict) or "error" in resp:
                continue
            for fallback_index, result in enumerate(resp.get("results") or []):
                if not isinstance(result, dict):
                    continue
                try:
                    result_index = int(result.get("index", fallback_index))
                except (TypeError, ValueError):
                    continue
                if result_index < 0 or result_index >= len(chunk):
                    continue
                requested_id = chunk[result_index]
                found = str(result.get("status", "")).lower() == "found"
                data = result.get("data") if isinstance(result.get("data"), dict) else {}
                outer_order = data.get("order") if isinstance(data.get("order"), dict) else {}
                details = (
                    outer_order.get("order")
                    if isinstance(outer_order.get("order"), dict)
                    else outer_order
                )
                execution = data.get("execution") if isinstance(data.get("execution"), dict) else {}
                if isinstance(outer_order.get("execution"), dict):
                    # The nested execution contains settlementStatus; the
                    # duplicated top-level execution in the docs may omit it.
                    execution = {**execution, **outer_order["execution"]}
                actual_id = str(
                    details.get("id")
                    or result.get("orderId")
                    or requested_id
                )
                client_id = str(
                    execution.get("clientOrderId")
                    or result.get("clientOrderId")
                    or (requested_id[7:] if requested_id.startswith("client:") else "")
                )
                settlement = str(
                    execution.get("settlementStatus", "") or ""
                ).upper()
                totals = execution.get("totalsRaw") or {}
                gross_size = _micro_amount(totals.get("usdGross"))
                net_size = _micro_amount(totals.get("usdNet"))
                gross_tokens = _micro_amount(totals.get("contractsGross"))
                net_tokens = _micro_amount(totals.get("contractsNet"))
                contracts_fee = _micro_amount(totals.get("contractsFee"))
                usd_fee = _micro_amount(totals.get("usdFee"))
                confirmed = settlement in ("MINED", "CONFIRMED")
                price = _safe_float(details.get("price"))
                if gross_size > 0 and gross_tokens > 0:
                    price = gross_size / gross_tokens
                fee_usdc = usd_fee if usd_fee > 0 else contracts_fee * price
                is_open = (
                    actual_id in open_ids or (client_id and client_id in open_client_ids)
                    if open_snapshot_valid
                    else None
                )
                scope_record = next(
                    (
                        record
                        for record in scope_records
                        if (
                            client_id
                            and record.get("client_order_id") == client_id
                        )
                        or (
                            actual_id
                            and record.get("order_id")
                            and str(record["order_id"]) == actual_id
                        )
                    ),
                    None,
                )
                slug = str(scope_record.get("slug") or "") if scope_record else ""
                terminal_row = None
                if slug and actual_id:
                    terminal_row = self._terminal_orders_by_id.get(
                        (slug, actual_id)
                    )
                if terminal_row is None and slug and client_id:
                    terminal_row = self._terminal_orders_by_client.get(
                        (slug, client_id)
                    )
                terminal_status = ""
                if terminal_row is not None:
                    _, _, terminal_status = self._user_order_fields(terminal_row)
                order_status = (
                    terminal_status
                    or open_status_by_id.get(actual_id, "")
                    or open_status_by_client.get(client_id, "")
                )
                # Never prune from one empty per-market snapshot alone: a POST
                # that timed out can become visible after that response. Exact
                # batch execution plus the terminal user-orders row supplies
                # durable terminal evidence instead.
                terminal_evidence = bool(
                    found
                    and scope_record is not None
                    and terminal_row is not None
                    and self._scope_order_is_terminal(
                        scope_record,
                        {**details, "status": order_status},
                        execution,
                    )
                )
                if terminal_evidence:
                    if client_id:
                        terminal_client_ids.add(client_id)
                    if actual_id:
                        terminal_order_ids.add(actual_id)
                out[requested_id] = {
                    "order_id": actual_id,
                    "client_order_id": client_id,
                    "found": found,
                    "status": order_status,
                    "settlement_status": settlement,
                    "matched": bool(execution.get("matched", False)) or gross_tokens > 0,
                    "confirmed": confirmed,
                    "matched_size_usdc": gross_size if confirmed else 0.0,
                    "matched_tokens": gross_tokens if confirmed else 0.0,
                    "contracts_gross": gross_tokens,
                    "contracts_fee": contracts_fee,
                    "contracts_net": net_tokens,
                    "usd_gross": gross_size,
                    "usd_net": net_size,
                    "usd_fee": usd_fee,
                    "fee_usdc": fee_usdc,
                    "price": price,
                    "is_open": is_open,
                    "open_snapshot_valid": open_snapshot_valid,
                    "error": result.get("error"),
                    "raw": result,
                }
        if terminal_client_ids or terminal_order_ids:
            self._forget_scope_orders(
                client_order_ids=terminal_client_ids,
                order_ids=terminal_order_ids,
            )
        return out

    async def cancel_order(self, order_id: str) -> bool:
        if settings.paper_trading or order_id.startswith("PAPER"):
            return True
        # Combined cancel is the current API and is idempotent by internal ID.
        cancel_body = (
            {"clientOrderId": order_id[7:]}
            if order_id.startswith("client:")
            else {"orderId": order_id}
        )
        resp = await self._request(
            "POST", "/orders/cancel", cancel_body
        )
        ok = bool(resp is not None and "error" not in (resp or {}))
        if not ok:
            log.warning("limitless_cancel_failed", order_id=order_id[:16])
        return ok

    async def cancel_all(self) -> int:
        """Cancel all open orders across our markets.

        Limitless cancel-all is PER-MARKET (DELETE /orders/all/:slug),
        so iterate over known slugs.
        """
        if settings.paper_trading:
            return 0
        n = 0
        active_slugs = {
            self._slug_by_token[token_id]
            for token_id in self._feed._subscribed
            if token_id in self._slug_by_token
        }
        slugs = active_slugs | self._order_scope_slugs
        for slug in slugs:
            resp = await self._request("DELETE", f"/orders/all/{slug}")
            if resp is not None and "error" not in (resp or {}):
                n += 1
        return n

    async def _open_orders_snapshot(self) -> tuple[list[dict], bool]:
        """Fetch every bot-scoped market and validate the official schema.

        Limitless has no account-wide REST open-order endpoint. Verification
        is therefore valid only for a dedicated bot EOA plus the persistent
        set of slugs written before every order submission.
        """
        out: list[dict] = []
        successes = 0
        current_slugs = {
            self._slug_by_token[token_id]
            for token_id in self._feed._subscribed
            if token_id in self._slug_by_token
        }
        slugs = current_slugs | self._order_scope_slugs
        for slug in slugs:
            resp = await self._request("GET", f"/markets/{slug}/user-orders")
            if (
                not isinstance(resp, dict)
                or "error" in resp
                or not isinstance(resp.get("orders"), list)
            ):
                log.warning(
                    "limitless_user_orders_snapshot_invalid",
                    slug=slug,
                    response_type=type(resp).__name__,
                )
                continue
            successes += 1
            rows = resp["orders"]
            for row in rows:
                if not isinstance(row, dict):
                    successes -= 1
                    log.warning(
                        "limitless_user_orders_row_invalid", slug=slug
                    )
                    break
                status = str(row.get("status", "") or "").upper()
                if not status or status in (
                    "LIVE", "OPEN", "PLACED", "PARTIALLY_FILLED"
                ):
                    out.append(row)
        transport_verified = successes == len(slugs)
        scope_reconciled = False
        if transport_verified and self._order_scope_verified:
            scope_reconciled = await self._reconcile_order_scope(out)
        verified = (
            settings.limitless_dedicated_eoa
            and self._order_scope_verified
            and transport_verified
            and scope_reconciled
        )
        return out, verified

    async def get_open_orders(self) -> list[dict]:
        """Get currently resting user orders across tracked markets."""
        out, _ = await self._open_orders_snapshot()
        return out

    async def get_open_orders_snapshot(self) -> tuple[list[dict], bool]:
        """Return open orders plus a strict all-markets snapshot flag."""
        return await self._open_orders_snapshot()

    async def get_positions(self) -> list[dict]:
        """Return verified CLOB outcome-token balances.

        The official response uses a top-level ``clob`` list and raw
        6-decimal ``tokensBalance.yes/no`` values.  Invalid transport/schema
        must raise: treating it as an empty wallet would hide real positions.
        """
        resp = await self._request("GET", "/portfolio/positions")
        if not isinstance(resp, dict) or "error" in resp:
            raise RuntimeError(f"Limitless positions request failed: {resp}")
        raw = resp.get("clob")
        if not isinstance(raw, list):
            raise RuntimeError("Limitless positions response missing top-level clob[]")
        out: list[dict] = []
        for row in raw:
            if not isinstance(row, dict):
                raise RuntimeError("Malformed Limitless clob position row")
            market = row.get("market") or {}
            position_ids = (
                market.get("position_ids")
                or market.get("positionIds")
                or market.get("tokens")
                or []
            )
            balances = row.get("tokensBalance") or row.get("tokens_balance") or {}
            if not isinstance(balances, dict):
                raise RuntimeError("Malformed Limitless tokensBalance")
            slug = str(market.get("slug") or market.get("address") or "")
            meta = next(
                (m for m in self._meta.values() if m.slug == slug), None
            )
            token_by_side = {
                "yes": str(position_ids[0]) if len(position_ids) > 0 else "",
                "no": str(position_ids[1]) if len(position_ids) > 1 else "",
            }
            if meta is not None:
                token_by_side["yes"] = token_by_side["yes"] or meta.yes_token
                token_by_side["no"] = token_by_side["no"] or meta.no_token
            for side in ("yes", "no"):
                raw_balance = balances.get(side, 0)
                try:
                    tokens = float(raw_balance or 0) / 1_000_000.0
                except (TypeError, ValueError) as exc:
                    raise RuntimeError(
                        f"Invalid Limitless {side} token balance"
                    ) from exc
                if abs(tokens) <= 0.000001:
                    continue
                token = token_by_side[side]
                if not token:
                    raise RuntimeError(
                        f"Cannot map non-zero {side} balance to a token id"
                    )
                out.append({"token_id": token, "tokens": tokens})
        return out

    @staticmethod
    def _conditional_operators_for_meta(meta: _MarketMeta) -> set[str]:
        """Operators that must be able to transfer outcome tokens.

        Every CLOB SELL transfers Conditional Tokens through venue.exchange.
        NegRisk/grouped markets additionally route through venue.adapter.
        """
        if not meta.venue_exchange or meta.venue_exchange.lower() == ZERO_ADDR:
            raise RuntimeError("Missing venue.exchange for Conditional Tokens approval")
        operators = {meta.venue_exchange}
        if meta.neg_risk:
            if not meta.venue_adapter or meta.venue_adapter.lower() == ZERO_ADDR:
                raise RuntimeError(
                    "NegRisk market is missing venue.adapter approval target"
                )
            operators.add(meta.venue_adapter)
        return operators

    async def _verify_conditional_token_approvals(
        self, operators: set[str], *, force: bool = False
    ) -> None:
        """Fail closed unless ERC-1155 SELL approvals exist on Base.

        This check intentionally never sends approval transactions.  Startup
        and each previously unseen market prove readiness before a BUY is
        allowed, preventing the bot from acquiring tokens that it cannot sell.
        """
        if self._account is None:
            raise RuntimeError("Limitless EOA account is not initialized")
        normalized = {
            str(operator).lower() for operator in operators if operator
        }
        to_check = normalized if force else normalized - self._approved_ctf_operators
        if not to_check:
            return

        def _read_approvals() -> set[str]:
            from web3 import Web3

            w3 = Web3(
                Web3.HTTPProvider(
                    settings.base_rpc_url, request_kwargs={"timeout": 12}
                )
            )
            if int(w3.eth.chain_id) != CHAIN_ID:
                raise RuntimeError("BASE_RPC_URL is not Base mainnet (chainId 8453)")
            contract = w3.eth.contract(
                address=Web3.to_checksum_address(CONDITIONAL_TOKENS_ADDRESS),
                abi=[
                    {
                        "inputs": [
                            {"name": "account", "type": "address"},
                            {"name": "operator", "type": "address"},
                        ],
                        "name": "isApprovedForAll",
                        "outputs": [{"name": "", "type": "bool"}],
                        "stateMutability": "view",
                        "type": "function",
                    }
                ],
            )
            approved: set[str] = set()
            for operator in sorted(to_check):
                checksum = Web3.to_checksum_address(operator)
                if bool(
                    contract.functions.isApprovedForAll(
                        self._account.address, checksum
                    ).call()
                ):
                    approved.add(operator)
            return approved

        approved = await asyncio.to_thread(_read_approvals)
        missing = sorted(to_check - approved)
        if missing:
            raise RuntimeError(
                "Missing Conditional Tokens setApprovalForAll for operator(s): "
                + ", ".join(missing)
            )
        self._approved_ctf_operators.update(approved)

    async def get_balance_allowance(self) -> dict[str, Any]:
        """Strict Base-USDC, gas, USDC allowance, and SELL approval checks."""
        if self._account is None:
            raise RuntimeError("Limitless EOA account is not initialized")

        def _read_balances() -> tuple[int, int]:
            from web3 import Web3

            w3 = Web3(
                Web3.HTTPProvider(
                    settings.base_rpc_url, request_kwargs={"timeout": 12}
                )
            )
            if int(w3.eth.chain_id) != CHAIN_ID:
                raise RuntimeError("BASE_RPC_URL is not Base mainnet (chainId 8453)")
            contract = w3.eth.contract(
                address=Web3.to_checksum_address(settings.base_usdc_address),
                abi=[
                    {
                        "inputs": [{"name": "account", "type": "address"}],
                        "name": "balanceOf",
                        "outputs": [{"name": "", "type": "uint256"}],
                        "stateMutability": "view",
                        "type": "function",
                    }
                ],
            )
            usdc_raw = int(
                contract.functions.balanceOf(self._account.address).call()
            )
            native_wei = int(w3.eth.get_balance(self._account.address))
            return usdc_raw, native_wei

        balance_raw, native_wei = await asyncio.to_thread(_read_balances)
        min_native_wei = int(
            (
                Decimal(str(settings.limitless_min_base_eth))
                * Decimal(10**18)
            ).to_integral_value(rounding=ROUND_DOWN)
        )
        if native_wei < min_native_wei:
            raise RuntimeError(
                "Insufficient Base ETH gas reserve for external EOA: "
                f"have={native_wei / 1e18:.8f}, "
                f"need={settings.limitless_min_base_eth:.8f} ETH"
            )
        conditional_operators: set[str] = set()
        for meta in self._meta.values():
            conditional_operators.update(
                self._conditional_operators_for_meta(meta)
            )
        if not conditional_operators:
            raise RuntimeError(
                "Cannot verify Conditional Tokens approvals: no market venue loaded"
            )
        await self._verify_conditional_token_approvals(
            conditional_operators, force=True
        )
        spenders = {
            meta.venue_exchange.lower(): meta.venue_exchange
            for meta in self._meta.values()
            if meta.venue_exchange
        }
        if not spenders:
            raise RuntimeError("Cannot verify CLOB allowance: no venue.exchange loaded")
        allowances: list[int] = []
        for spender in spenders.values():
            path = f"/portfolio/trading/allowance?type=clob&spender={spender}"
            resp = await self._request("GET", path)
            if not isinstance(resp, dict) or "error" in resp:
                raise RuntimeError(f"Limitless allowance request failed: {resp}")
            checked = str(resp.get("checkedAddress") or "")
            returned_spender = str(resp.get("spender") or "")
            if checked and checked.lower() != self._account.address.lower():
                raise RuntimeError("Allowance checkedAddress does not match EOA")
            if returned_spender and returned_spender.lower() != spender.lower():
                raise RuntimeError("Allowance spender mismatch")
            if str(resp.get("type") or "").lower() not in ("", "clob"):
                raise RuntimeError("Allowance type mismatch")
            try:
                allowance_raw = int(resp.get("allowance"))
            except (TypeError, ValueError) as exc:
                raise RuntimeError("Invalid allowance amount") from exc
            if not bool(resp.get("hasMinimumAllowance")):
                raise RuntimeError(f"Insufficient CLOB allowance for {spender}")
            allowances.append(allowance_raw)
        return {
            "verified": True,
            "balance": balance_raw,
            "allowance": min(allowances),
            "allowance_verified": True,
            "conditional_tokens_approval_verified": True,
            "gas_verified": True,
            "native_balance_wei": native_wei,
            "wallet": self._account.address,
            "source": "base_usdc_balanceOf+base_eth_getBalance",
        }

    @property
    def last_ws_msg_age(self) -> float:
        """Compat: MM core treats this as 'book data freshness'."""
        return time.monotonic() - self._last_book_update


class _FeedShim:
    """Compat with ClobService._feed for MM core and admin API.

    Callers (market_maker auto-refill, /api/markets/replace) also use
    _subscribed, start() and stop() — books dict is the source of truth,
    the REST poll loop picks up membership changes on its next tick.
    """

    def __init__(self, svc: LimitlessService) -> None:
        self._svc = svc
        self._subscribed: set[str] = set()

    async def unsubscribe(self, token_id: str) -> None:
        self._subscribed.discard(token_id)
        self._svc.books.pop(token_id, None)

    async def subscribe(self, token_id: str) -> None:
        self._subscribed.add(token_id)
        info = self._svc.markets.get(token_id)
        tick = info.tick_size if info else LIMITLESS_DEFAULT_PRICE_TICK
        self._svc.books.setdefault(
            token_id, MarketBook(token_id=token_id, tick_size=tick)
        )
        self._svc._ensure_polling()
        self._svc._ensure_trade_polling()

    async def start(self, token_ids: list[str]) -> None:
        for tid in token_ids:
            await self.subscribe(tid)

    async def stop(self) -> None:
        self._subscribed.clear()


def _parse_iso_ts(s: str) -> float:
    if not s:
        return time.time() + 86400
    try:
        return datetime.fromisoformat(str(s).replace("Z", "+00:00")).timestamp()
    except Exception:
        return time.time() + 86400
