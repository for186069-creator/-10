"""
app/services/market_maker.py — Professional MM engine.

Combines:
  - Avellaneda-Stoikov reservation price (inventory-aware fair price)
  - Kyle's lambda spread multiplier (order-book imbalance aware)
  - Multi-level quoting (3 price levels)
  - Inventory skew + aging discount
  - Circuit breakers + adverse selection
  - Yes/No hedging (condition_id pairs)

Two modes:
  PAPER : realistic fill simulation (with adverse selection, competition, latency)
  LIVE  : real orders via py-clob-client with EIP-712 signing

Bot starts PAUSED. User must click "Start Trading" via /api/start.
"""
from __future__ import annotations

import asyncio
import json as _json
import math
import os
import random
import time
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from app.core.config import settings
from app.core.logging import get_logger
from app.core.metrics import (
    ACTIVE_QUOTES,
    ADVERSE_TRIGGERS,
    BANKROLL_USD,
    CYCLE_LATENCY_SEC,
    CYCLES_TOTAL,
    DAILY_PNL_USD,
    FILLS_TOTAL,
    HALTED,
    INVENTORY_RATIO,
    INVENTORY_USD,
    KYLE_LAMBDA,
    RESERVATION_PRICE,
    ROUND_TRIPS_TOTAL,
    SPREAD_CENTS,
)
from app.db.models import MarketSnapshot, OrderMode, PaperFillOpportunity, Side, Trade
from app.services.clob_client import ClobService, MarketBook, OrderResult
from app.services.inventory_manager import InventoryManager
from app.services.pricing.avellaneda_stoikov import AvellanedaStoikov
from app.services.pricing.kyle_lambda import KyleLambda
from app.services.pricing.spread_optimizer import SpreadOptimizer
from app.services.risk.risk_manager import RiskManager

log = get_logger(__name__)

# v1.0.154: dirty-shutdown marker. Created on MM start, removed on clean
# shutdown (after force-cancel). Present at startup ⇒ the previous run
# died unclean (power cut / kill) — run crash recovery before quoting.
RUNNING_LOCK_PATH = Path("data") / "RUNNING.lock"


@dataclass
class ActiveQuote:
    """Tracks one level of an actively-placed quote for a market."""

    token_id: str
    level: int  # 1, 2, or 3
    bid_price: float | None
    ask_price: float | None
    mid_at_place: float
    size_usdc: float
    reservation_price: float
    spread_cents: float
    placed_at: float = field(default_factory=time.monotonic)
    bid_filled: bool = False
    ask_filled: bool = False
    bid_order_id: str | None = None
    ask_order_id: str | None = None
    # v1.0.156: partial-fill fractions for the open-orders panel (0..1)
    bid_fill_pct: float = 0.0
    ask_fill_pct: float = 0.0
    strategy: str = "legacy"
    role: str = ""
    cycle_id: int = 0
    book_update_at_place: float = 0.0
    last_price_at_place: float = 0.0
    bid_queue_ahead_tokens: float = 0.0
    ask_queue_ahead_tokens: float = 0.0
    bid_last_visible_tokens: float = 0.0
    ask_last_visible_tokens: float = 0.0
    bid_inferred_through_tokens: float = 0.0
    ask_inferred_through_tokens: float = 0.0
    bid_opportunity_recorded: bool = False
    ask_opportunity_recorded: bool = False
    bid_last_opportunity_update: float = 0.0
    ask_last_opportunity_update: float = 0.0
    placed_wall_time: float = field(default_factory=time.time)
    public_trade_seq_at_place: int = 0


@dataclass
class FastFlatState:
    """One-at-a-time lifecycle for the small-bank spread strategy."""

    token_id: str
    cycle_id: int
    phase: str
    bankroll_start: float = 0.0
    started_at: float = field(default_factory=time.monotonic)
    had_position: bool = False
    round_trip_counted: bool = False


class MarketMaker:
    """Main MM engine. Runs a requote loop."""

    def __init__(
        self,
        clob: ClobService,
        inventory: InventoryManager,
        risk: RiskManager,
    ) -> None:
        self.clob = clob
        self.inventory = inventory
        self.risk = risk

        # active_quotes: token_id → list of ActiveQuote (one per level)
        self.active_quotes: dict[str, list[ActiveQuote]] = {}
        self._task: asyncio.Task | None = None
        self._cleanup_task: asyncio.Task | None = None
        self._poll_task: asyncio.Task | None = None
        self._liquidation_task: asyncio.Task | None = None  # v1.0.38
        self._persistence_task: asyncio.Task | None = None  # v1.0.72
        self._snapshot_task: asyncio.Task | None = None  # v1.0.88 (mm_snapshots logging)
        self._bankroll_sync_task: asyncio.Task | None = None  # v1.0.122 (Claude audit p.1)
        self._running = False
        self._cycle_count = 0
        self._fill_count = 0  # Loaded from DB on start()
        self._round_trip_count = 0
        self._liquidation_count = 0  # v1.0.38: tracks forced liquidations
        # v1.0.150: new headline exit metrics — profit-sniper fills and
        # forced loss liquidations (target: 0 outside pre-resolution).
        self._profit_take_count = 0
        self._loss_forced_count = 0
        # v1.0.150: markets currently under the drawdown stop (BUY blocked).
        # Tracked only to log state TRANSITIONS at INFO (per-cycle repeats
        # would spam the log like ask_lifted did).
        self._drawdown_stopped: set[str] = set()
        # v1.0.151: momentum filter — ring buffers of (monotonic_ts, mid)
        # per market (~10 min depth) and the sides currently blocked.
        self._mid_history: dict[str, deque] = {}
        self._momentum_bid_blocked: set[str] = set()
        self._momentum_ask_blocked: set[str] = set()
        # v1.0.151: NO-hedge — executed hedges + per-token check throttle.
        self._no_hedge_count = 0
        self._hedged_positions: set[str] = set()
        self._no_hedge_last_check: dict[str, float] = {}
        # v1.0.153: capture quality — running mean of taken_pct across
        # sniper exits + maker/taker exit split (Path A share).
        self._sniper_taken_pct_sum = 0.0
        self._sniper_fired_count = 0
        self._exit_maker_count = 0
        self._exit_taker_count = 0
        # v1.0.154: crash protection
        self._crash_recovery_active = False
        self._order_watchdog_task: asyncio.Task | None = None
        # v1.0.155 (GLM §7): adverse-rate market rotation. After each BUY
        # fill we probe the mid 60s later (reusing the v151 _mid_history
        # buffer); a market whose recent fills keep going adverse gets
        # banned from rotation for adverse_market_ban_sec.
        self._adverse_probes: list[tuple[str, float, float]] = []  # (token, fill_px, t)
        self._fill_outcomes: dict[str, deque] = {}  # token -> deque[bool], maxlen 20
        self._banned_markets: dict[str, float] = {}  # token -> ban_until (monotonic)
        self._adverse_ban_count = 0
        # v1.0.120 (Claude audit Task 2b): capital starvation counter.
        # Incremented when bid_blocked_insufficient_balance fires.
        # Reset every 60s. If > threshold → capital is starved →
        # opportunity cost of holding losing positions is high.
        self._capital_starved_count: int = 0
        self._capital_starved_reset_at: float = time.monotonic()
        # v1.0.59 (BUG-N9): monotonic-clock timestamp of last auto-refill.
        # Replaces the old `cycle_count % 30 == 0` throttle (≈30s) which
        # churned markets every 30s. Now throttled by auto_refill_cooldown_sec
        # (default 300s = 5 min). Initialized to -inf so the first refill can
        # happen immediately on startup (gives the bot a chance to populate
        # markets before the cooldown kicks in).
        self._last_auto_refill_mono: float = -float("inf")
        self._no_markets_since_mono: float | None = None
        self._degraded_reason: str = ""

        # Bot starts PAUSED. User clicks "Start Trading" to begin.
        self._trading_paused = True

        # Pricing models
        self._as_calc = AvellanedaStoikov()
        self._kyle = KyleLambda()

        # Yes/No hedging pairs: condition_id → {"yes": token_id, "no": token_id}
        self._condition_pairs: dict[str, dict[str, str]] = {}

        # Live mode: pending orders awaiting fill confirmation
        self._pending_orders: dict[str, dict[str, Any]] = {}
        # Background polling, admin drains, and shutdown must serialize fill
        # deltas or two coroutines can apply the same cumulative execution.
        self._order_poll_lock = asyncio.Lock()
        # Resolved LIVE inventory is not cash until redemption and a wallet
        # balance update are confirmed.  Never manufacture a local fill.
        self._live_resolved_waiting_redeem: set[str] = set()

        # FAST_FLAT owns at most one token and one working order.  Keeping a
        # separate state object makes it impossible for legacy two-sided
        # quoting to run concurrently with the small-bank strategy.
        self._fast_flat_state: FastFlatState | None = None
        self._fast_flat_cycle_seq = 0
        self._paper_opportunity_count = 0
        self._paper_inferred_candidate_count = 0
        self._paper_random_candidate_count = 0
        self._paper_public_trade_cursor: dict[str, int] = {}

        # Stats
        self._hedge_attempts = 0
        self._hedge_fills = 0

    # ── Lifecycle ─────────────────────────────────────────────────────────

    # ── v1.0.154: crash protection ────────────────────────────────────────

    async def _crash_recovery_check(self) -> None:
        """Dirty-shutdown detection. If RUNNING.lock survived from the
        previous run: cancel EVERYTHING on the exchange before any quoting,
        reconcile DB positions vs wallet, and raise the recovery badge.
        Then (re)write the lock for this run."""
        if RUNNING_LOCK_PATH.exists():
            age_sec = None
            prev_pid = None
            try:
                info = _json.loads(RUNNING_LOCK_PATH.read_text(encoding="utf-8"))
                prev_pid = info.get("pid")
                if info.get("ts"):
                    age_sec = round(time.time() - float(info["ts"]), 0)
            except Exception:
                pass
            log.warning(
                "unclean_shutdown_detected",
                marker_age_sec=age_sec,
                previous_pid=prev_pid,
                reason="RUNNING.lock survived — previous run died without clean shutdown",
            )
            self._crash_recovery_active = True
            if settings.paper_trading:
                log.info(
                    "crash_recovery_cancel_all_skipped",
                    reason="PAPER: no live orders exist on the exchange",
                )
                # PAPER has no exchange orders to reconcile. Keeping the
                # recovery badge until a quote is placed deadlocks the UI in
                # PAUSED mode, because a paused bot cannot produce that quote.
                # Local inventory was already restored before this check, so
                # recovery is complete here.
                self._crash_recovery_active = False
                log.info(
                    "crash_recovery_cleared",
                    reason="PAPER state restored; no exchange orders to reconcile",
                )
            else:
                clean_orders = await self.cancel_all_live_orders_and_wait(
                    timeout_sec=20.0
                )
                if not clean_orders:
                    self.inventory.live_ready = False
                    self.inventory.halt(
                        reason="LIVE_POSITION_PREFLIGHT",
                        detail=(
                            "could not prove all pre-crash exchange orders "
                            "were terminally cancelled"
                        ),
                    )
                await self._check_position_drift_after_crash()
        # (re)write the marker for THIS run
        try:
            RUNNING_LOCK_PATH.parent.mkdir(parents=True, exist_ok=True)
            RUNNING_LOCK_PATH.write_text(
                _json.dumps({"pid": os.getpid(), "ts": time.time()}),
                encoding="utf-8",
            )
        except OSError as e:
            log.warning("running_lock_write_failed", error=str(e))

    async def _check_position_drift_after_crash(self, *, strict: bool = False) -> bool:
        """LIVE: compare DB-restored inventory vs actual wallet balances.

        Returns True only when the snapshot is verified and matches.  In
        strict mode any mismatch blocks new LIVE entries.
        """
        get_positions = getattr(self.clob, "get_positions", None)
        if get_positions is None:
            log.debug("position_drift_check_unavailable")
            return not strict
        try:
            positions = await get_positions()
        except Exception as e:
            log.warning("position_drift_check_failed", error=str(e))
            if strict:
                self.inventory.live_ready = False
                self.inventory.halt(reason="LIVE_POSITION_PREFLIGHT", detail=str(e))
            return False
        wallet = {
            str(p.get("token_id", "")): float(p.get("tokens", 0.0))
            for p in (positions or [])
        }
        drifted = False
        for tid, inv in self.inventory.inventories.items():
            if abs(inv.net_tokens) < 0.000001:
                continue
            actual = wallet.pop(tid, 0.0)
            if abs(actual - inv.net_tokens) > 0.0001:
                drifted = True
                log.warning(
                    "position_drift_after_crash",
                    token=tid[:12],
                    db_tokens=round(inv.net_tokens, 4),
                    wallet_tokens=round(actual, 4),
                    delta=round(actual - inv.net_tokens, 4),
                )
        for tid, tokens in wallet.items():
            if abs(tokens) > 0.0001:
                drifted = True
                log.warning(
                    "position_drift_after_crash",
                    token=tid[:12],
                    db_tokens=0.0,
                    wallet_tokens=round(tokens, 4),
                    delta=round(tokens, 4),
                    reason="wallet position unknown to DB",
                )
        if strict and drifted:
            self.inventory.live_ready = False
            self.inventory.halt(
                reason="LIVE_POSITION_DRIFT",
                detail="wallet outcome-token balances do not match the local ledger",
            )
        return not drifted

    async def _live_order_watchdog_loop(self) -> None:
        """v1.0.154 LIVE: Limitless has no GTD/TTL (expiration must be "0"),
        so a dead bot leaves naked orders until power returns. This loop
        bounds the exposure window: no order may outlive
        live_requote_max_order_age_sec — it is force-cancelled (and the
        normal cycle re-places it within seconds), and exchange-side stray
        orders unknown to us are cancelled outright."""
        interval = max(10.0, settings.live_requote_max_order_age_sec / 4.0)
        while self._running:
            try:
                await self._sweep_old_live_orders()
            except asyncio.CancelledError:
                raise
            except Exception as e:
                log.warning("order_watchdog_error", error=str(e))
            await asyncio.sleep(interval)

    async def _sweep_old_live_orders(self) -> None:
        if settings.paper_trading:
            return
        max_age = settings.live_requote_max_order_age_sec
        now = time.monotonic()
        for tid, quotes in list(self.active_quotes.items()):
            keep: list[ActiveQuote] = []
            for q in quotes:
                age = now - q.placed_at
                if age > max_age:
                    log.info(
                        "watchdog_requote_old_order",
                        market=tid[:12],
                        level=q.level,
                        age_sec=round(age, 0),
                        max_age_sec=max_age,
                        reason="order outlived max age — cancel; cycle re-places",
                    )
                    await self._cancel_quote_level(tid, q)
                else:
                    keep.append(q)
            if keep:
                self.active_quotes[tid] = keep
            else:
                self.active_quotes.pop(tid, None)
        # Exchange-side sweep: cancel strays we don't track (post-crash
        # leftovers, failed cancels).
        try:
            open_orders = await self.clob.get_open_orders()
        except Exception:
            return
        known: set[str] = set(self._pending_orders.keys())
        for quotes in self.active_quotes.values():
            for q in quotes:
                if q.bid_order_id:
                    known.add(q.bid_order_id)
                if q.ask_order_id:
                    known.add(q.ask_order_id)
        for o in open_orders or []:
            oid = str(o.get("id") or o.get("orderId") or o.get("order_id") or "")
            if oid and oid not in known:
                log.warning(
                    "watchdog_cancel_stray_order",
                    order_id=oid[:16],
                    reason="live order unknown to the bot — cancelling",
                )
                try:
                    await self.clob.cancel_order(oid)
                except Exception as e:
                    log.warning("watchdog_stray_cancel_failed", order_id=oid[:16], error=str(e))

    async def start(self) -> None:
        self._running = True

        # v1.0.52 FIX: explicitly enforce paused state at startup.
        # Previously _trading_paused was only set in __init__, which could
        # be reset by accident. Now start() forces it based on settings.
        # Default: PAUSED — user must click "Start Trading".
        self._trading_paused = not settings.auto_start_trading
        if self._trading_paused:
            log.warning(
                "bot_started_PAUSED",
                message="Bot is PAUSED. Click 'Start Trading' in the dashboard to begin quoting.",
                auto_start_trading=settings.auto_start_trading,
            )
        else:
            log.warning(
                "bot_started_TRADING",
                message="Bot auto-started (AUTO_START_TRADING=true). Quotes will be placed immediately.",
                auto_start_trading=settings.auto_start_trading,
            )

        # Load fill_count from DB (survives bot restarts)
        try:
            from sqlalchemy import func, select

            from app.core.db import AsyncSessionLocal
            from app.db.models import Trade
            async with AsyncSessionLocal() as db:
                result = await db.execute(select(func.count(Trade.id)))
                self._fill_count = result.scalar() or 0
                log.info("fill_count_loaded_from_db", fill_count=self._fill_count)
        except Exception as e:
            log.debug("fill_count_load_failed", error=str(e))

        # v1.0.72 (BUG-N23): Load inventory state from DB (crash recovery)
        try:
            from app.core.db import AsyncSessionLocal
            async with AsyncSessionLocal() as db:
                restored = await self.inventory.load_state_from_db(db)
                if restored:
                    log.info(
                        "inventory_state_loaded_on_startup",
                        bankroll=round(self.inventory.bankroll, 2),
                        positions=len(self.inventory.inventories),
                    )
        except Exception as e:
            log.warning("inventory_state_load_failed", error=str(e))

        # Restore first, then compare that inventory with the wallet during
        # dirty-shutdown recovery.  The old order compared an empty in-memory
        # ledger and therefore could not detect real drift.
        await self._crash_recovery_check()

        # Strict LIVE preflight happens before any trading/background task is
        # created.  Failure keeps the dashboard alive but leaves the engine
        # paused + halted with bankroll zero (never the PAPER balance).
        if not settings.paper_trading:
            try:
                await self.inventory.sync_bankroll_from_wallet(self.clob)
                if settings.exchange == "limitless":
                    positions_match = await self._check_position_drift_after_crash(
                        strict=True
                    )
                    if not positions_match:
                        raise RuntimeError(
                            "verified wallet positions do not match the local ledger"
                        )
            except Exception as exc:
                self._trading_paused = True
                self.inventory.live_ready = False
                if not self.inventory.halted:
                    self.inventory.halt(
                        reason="LIVE_PREFLIGHT",
                        detail=str(exc),
                    )
                log.critical(
                    "live_preflight_blocked_trading",
                    error=str(exc),
                    reason="verified balance/allowance snapshot unavailable",
                )

        self._task = asyncio.create_task(self._requote_loop(), name="mm_loop")
        self._cleanup_task = asyncio.create_task(self._db_cleanup_loop(), name="db_cleanup")
        if not settings.paper_trading:
            self._poll_task = asyncio.create_task(self._poll_orders_loop(), name="mm_poll")
        # v1.0.38: active inventory liquidation — aggressively clears stuck positions
        if (
            settings.inventory_liquidation_enabled
            and settings.strategy_mode != "fast_flat"
        ):
            self._liquidation_task = asyncio.create_task(
                self._liquidation_loop(), name="mm_liquidation"
            )
        # v1.0.72 (BUG-N23): State persistence — save every 60s for crash recovery
        self._persistence_task = asyncio.create_task(
            self._state_persistence_loop(), name="mm_persistence"
        )
        # v1.0.88: mm_snapshots logging — populates the price-history table
        # required for backtesting hold-N-minutes / take-profit thresholds.
        # Before this the table was defined but never written.
        self._snapshot_task = asyncio.create_task(
            self._snapshot_loop(), name="mm_snapshot"
        )
        # v1.0.122 (Claude audit p.1): periodic bankroll sync in LIVE mode.
        # PAPER: no-op. LIVE: every 300s, sync bankroll with real wallet + drift check.
        if not settings.paper_trading:
            self._bankroll_sync_task = asyncio.create_task(
                self._bankroll_sync_loop(), name="bankroll_sync"
            )
            # v1.0.154: order-age watchdog — bounds the naked-order window
            # if the process dies suddenly (no GTD/TTL on Limitless).
            self._order_watchdog_task = asyncio.create_task(
                self._live_order_watchdog_loop(), name="order_watchdog"
            )
        # v1.0.144: Orphaned position reconciliation (Claude Section 1).
        # Every orphaned_reconcile_interval_sec, check if orphaned positions resolved.
        # Critical: without this, orphaned positions never settle (resolution monitor
        # only ran for tokens in self.clob.books).
        self._reconcile_task = asyncio.create_task(
            self._reconcile_loop(), name="orphaned_reconcile"
        )
        log.info(
            "market_maker_started",
            mode="LIVE" if not settings.paper_trading else "PAPER",
            interval=settings.requote_interval_sec,
            fill_count=self._fill_count,
            liquidation_enabled=settings.inventory_liquidation_enabled,
            trading_paused=self._trading_paused,
        )

    async def stop(self) -> None:
        """Stop the market maker and all background tasks.

        v1.0.49 FIX (BUG-21): previously `except (CancelledError, Exception):
        pass` silently swallowed ALL exceptions from background tasks. If a
        task crashed with a real error (DB failure, network issue), it was
        never logged — making debugging impossible. Now we separate
        CancelledError (expected during shutdown) from other exceptions
        (logged as warnings).
        """
        log.info("market_maker_stopping")
        self._running = False

        # Reconcile cancellation before saving: a cancel response is only an
        # ACK, and a late confirmed fill must reach the ledger first.
        clean_orders = True
        if not settings.paper_trading:
            clean_orders = await self.cancel_all_live_orders_and_wait(
                timeout_sec=20.0
            )

        # v1.0.72 (BUG-N23): save state after final order reconciliation.
        try:
            from app.core.db import AsyncSessionLocal
            async with AsyncSessionLocal() as db:
                await self.inventory.save_state_to_db(db)
                log.info("inventory_state_saved_on_shutdown")
        except Exception as e:
            log.warning("inventory_state_save_failed_on_shutdown", error=str(e))
        # Cancel all active quotes
        # v1.0.146 (Claude): force=True — on shutdown partially-filled
        # quotes must NOT stay live on the exchange while the bot is
        # offline (unmonitored real-money orders). The already-filled
        # part stays as inventory either way; cancelling the unfilled
        # remainder does not create additional dust.
        for tid in list(self.active_quotes.keys()):
            await self._cancel_all_levels(tid, force=True)
        # v1.0.154: force-cancel succeeded → this is a CLEAN shutdown.
        # Remove the dirty-shutdown marker.
        try:
            if clean_orders and RUNNING_LOCK_PATH.exists():
                RUNNING_LOCK_PATH.unlink()
                log.info("running_lock_removed", reason="clean shutdown")
        except OSError as e:
            log.warning("running_lock_remove_failed", error=str(e))
        if not clean_orders:
            log.critical(
                "shutdown_orders_not_terminal",
                pending_orders=len(self._pending_orders),
                reason="leaving RUNNING.lock for crash recovery",
            )
        task_names = {
            self._task: "requote_loop",
            self._cleanup_task: "db_cleanup",
            self._poll_task: "poll_orders",
            self._liquidation_task: "liquidation",
            self._persistence_task: "persistence",
            self._snapshot_task: "snapshot",
            self._bankroll_sync_task: "bankroll_sync",
            getattr(self, "_reconcile_task", None): "orphaned_reconcile",
            self._order_watchdog_task: "order_watchdog",
        }
        for task in (self._task, self._cleanup_task, self._poll_task, self._liquidation_task, self._persistence_task, self._snapshot_task, self._bankroll_sync_task, getattr(self, "_reconcile_task", None), self._order_watchdog_task):
            if task:
                task_name = task_names.get(task, "unknown")
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass  # expected during shutdown
                except Exception as e:
                    # v1.0.49 (BUG-21): log unexpected exceptions instead of
                    # silently swallowing them. Helps diagnose crashes.
                    log.warning(
                        "task_stopped_with_error",
                        task=task_name,
                        error=str(e),
                        error_type=type(e).__name__,
                    )
        log.info("market_maker_stopped")

    # ── User control ──────────────────────────────────────────────────────

    def start_trading(self) -> None:
        """User clicked 'Start Trading'."""
        if not settings.paper_trading and not self.inventory.live_ready:
            raise RuntimeError(
                "LIVE trading is blocked until wallet balance and allowance "
                "are verified"
            )
        self._trading_paused = False
        if self.inventory.halted and "USER_PAUSE" in (self.inventory.halt_reason or ""):
            self.inventory.resume()
        log.info("trading_started_by_user")

    def stop_trading(self) -> None:
        """User clicked 'Pause' — cancel all quotes immediately."""
        self._trading_paused = True
        # v1.0.146 (Claude): force=True — user pressed Pause, they want
        # ALL orders off the book, including partially-filled ones.
        for tid in list(self.active_quotes.keys()):
            asyncio.create_task(self._cancel_all_levels(tid, force=True))
        log.info("trading_paused_by_user")

    async def start_live_polling(self) -> None:
        """v1.0.39: start the LIVE fill-polling task at runtime.

        Previously _poll_orders_loop was only created in start() when the bot
        booted directly into LIVE mode. If the bot started in PAPER and the
        user toggled to LIVE via /api/mode/toggle, _poll_task was never
        created, so fills were never detected even after PATCH-1.
        This method is idempotent — safe to call multiple times.
        """
        if settings.paper_trading:
            log.warning("start_live_polling_called_in_paper_mode")
            return
        if self._poll_task is None or self._poll_task.done():
            self._poll_task = asyncio.create_task(
                self._poll_orders_loop(), name="mm_poll"
            )
        if self._bankroll_sync_task is None or self._bankroll_sync_task.done():
            self._bankroll_sync_task = asyncio.create_task(
                self._bankroll_sync_loop(), name="bankroll_sync"
            )
        if self._order_watchdog_task is None or self._order_watchdog_task.done():
            self._order_watchdog_task = asyncio.create_task(
                self._live_order_watchdog_loop(), name="order_watchdog"
            )
        log.info("live_polling_started_at_runtime")

    @property
    def is_trading(self) -> bool:
        return not self._trading_paused and not self.inventory.halted

    def _resume_stale_halt_if_feed_recovered(self) -> bool:
        """Lift STALE_DATA as soon as feed recovery is observable.

        This must run before FAST_FLAT ``exit_only`` handling. An open
        FAST_FLAT position keeps that branch active on every loop iteration;
        placing recovery below it made the fresh-feed condition unreachable
        until the position closed.
        """
        if "STALE_DATA" not in (self.inventory.halt_reason or ""):
            return False
        if not self.clob.books:
            self.inventory.resume(preserve_counters=True, source="AUTO")
            log.warning(
                "stale_halt_lifted_no_books",
                reason=(
                    "no books to go stale — releasing halt so auto-refill can run"
                ),
            )
            return True
        if self.clob.last_ws_msg_age < 10:
            self.inventory.resume(preserve_counters=True, source="AUTO")
            log.info("ws_recovered_resuming")
            return True
        return False

    # ── Main loop ─────────────────────────────────────────────────────────

    async def _requote_loop(self) -> None:
        # v1.0.52: track paused cycles to log "waiting" periodically
        _paused_cycle = 0
        while self._running:
            try:
                t0 = time.monotonic()
                if self._trading_paused:
                    # v1.0.52: log every 30 cycles (~30s) so user can see
                    # the bot is alive but waiting for "Start Trading"
                    _paused_cycle += 1
                    if _paused_cycle % 30 == 1:
                        log.info(
                            "waiting_for_start_trading",
                            paused_cycles=_paused_cycle,
                            message="Bot is PAUSED. Click 'Start Trading' to begin.",
                        )
                    await asyncio.sleep(settings.requote_interval_sec)
                    continue
                _paused_cycle = 0  # reset when not paused
                if self.inventory.halted:
                    # Check recovery before FAST_FLAT exit-only. Otherwise an
                    # open position reaches the ``continue`` below forever.
                    if self._resume_stale_halt_if_feed_recovered():
                        continue
                    if (
                        settings.strategy_mode == "fast_flat"
                        and self._has_fast_flat_inventory()
                    ):
                        # A risk stop forbids new entries, but freezing a live
                        # position would recreate the very "stuck until
                        # resolution" failure FAST_FLAT is meant to avoid.
                        await self._cycle(exit_only=True)
                        await asyncio.sleep(settings.requote_interval_sec)
                        continue
                    # Check if halt was due to stale data — auto-resume when WS recovers
                    # Cancel all quotes while halted
                    for tid in list(self.active_quotes.keys()):
                        await self._cancel_all_levels(tid)
                    await asyncio.sleep(settings.requote_interval_sec)
                    continue
                await self._cycle()
                CYCLE_LATENCY_SEC.observe(time.monotonic() - t0)
            except asyncio.CancelledError:
                break
            except Exception as e:
                log.exception("mm_cycle_error", error=str(e))
            await asyncio.sleep(settings.requote_interval_sec)

    async def _cycle(self, *, exit_only: bool = False) -> None:
        self._cycle_count += 1
        CYCLES_TOTAL.inc()

        # A failed LIVE preflight forbids every order, including an exit
        # inferred from an unverified/restored local position. The watchdog
        # may still cancel exchange orders, but no new order can be submitted.
        if not settings.paper_trading and not self.inventory.live_ready:
            for tid in list(self.active_quotes.keys()):
                await self._cancel_all_levels(tid, force=True)
            return

        # ── Global halt check ──
        should_halt, reason = self.risk.should_halt()
        if should_halt:
            self.inventory.halt(
                reason=reason.split(":")[0],
                detail=reason.split(":", 1)[1] if ":" in reason else "",
            )
            if not (
                settings.strategy_mode == "fast_flat"
                and self._has_fast_flat_inventory()
            ):
                for tid in list(self.active_quotes.keys()):
                    await self._cancel_all_levels(tid)
                HALTED.set(1)
                return
            exit_only = True

        # Auto-refill markets if too few
        if not exit_only:
            await self._maybe_auto_refill()
            self._update_market_availability()

        # ── Build YES/NO pairs and merge complete PAPER sets ──
        # Hedging uses the same map, but PAPER merge must work even when the
        # active hedging strategy is disabled.
        if self._cycle_count % 30 == 1 and (
            settings.hedging_enabled
            or (settings.paper_trading and settings.paper_auto_merge_complete_sets)
        ):
            self._build_hedging_pairs()
        if settings.paper_trading and settings.paper_auto_merge_complete_sets:
            await self._merge_paper_complete_sets()

        # ── Process each market ──
        for tid, book in list(self.clob.books.items()):
            await self._process_market(tid, book, exit_only=exit_only)

        # ── Update metrics ──
        BANKROLL_USD.set(self.inventory.bankroll)
        DAILY_PNL_USD.set(self.inventory.daily_pnl)
        total_inv = sum(inv.net_usdc_at_entry for inv in self.inventory.inventories.values())
        INVENTORY_USD.set(total_inv)
        ACTIVE_QUOTES.set(sum(len(qs) for qs in self.active_quotes.values()))
        HALTED.set(1 if self.inventory.halted else 0)

    async def _maybe_auto_refill(self) -> None:
        """If quotable markets dropped below USER'S target, discover new ones.

        v1.0.42: hard cap = target × 2 (prevented infinite refill, but still
                 allowed 2 markets when user wanted 1).
        v1.0.46 FIX (BUG-1): hard cap = target. If user wants 1 market, the
                 bot keeps at most 1. This means if the single market becomes
                 non-quotable (spread < min), the bot now actively REPLACES it
                 rather than keeping it + adding a buffer.
        v1.0.46 FIX (BUG-7): auto_pick_count is now restored via try/finally
                 even when discover_markets() raises.
        v1.0.59 FIX (BUG-N9): replaced `cycle_count % 30` throttle (≈30s)
                 with monotonic-clock cooldown (settings.auto_refill_cooldown_sec,
                 default 300s = 5 min). Prevents churning when ALL Polymarket
                 markets have tight spreads — old behavior burned 19 refill
                 cycles in 17 min getting back the same non-quotable markets.
        """
        # Count QUOTABLE markets. FAST_FLAT has a bounded spread window:
        # a very wide book is not a scalp candidate even though it satisfies
        # the legacy one-sided ``spread >= min`` check.
        quotable = sum(
            1 for book in self.clob.books.values()
            if self._is_auto_refill_quotable(book)
        )
        current = len(self.clob.books)

        # Dynamic target: adjust based on current bankroll
        if settings.strategy_mode == "fast_flat":
            target = (
                settings.fast_flat_broader_market_count
                if settings.fast_flat_broader_markets_enabled else 1
            )
        elif settings.auto_pick_dynamic:
            target = max(1, int(self.inventory.bankroll / 10))
        else:
            target = settings.auto_pick_count

        # Refill only if quotable < target
        if quotable >= target:
            return

        # v1.0.59 (BUG-N9): time-based throttle replaces cycle_count % 30.
        # First call after startup is allowed immediately (_last_auto_refill_mono
        # initialized to -inf in __init__). Subsequent calls are throttled by
        # auto_refill_cooldown_sec. This gives markets time to naturally widen
        # their spreads before we churn them.
        now_mono = time.monotonic()
        elapsed = now_mono - self._last_auto_refill_mono
        if elapsed < settings.auto_refill_cooldown_sec:
            return

        # v1.0.46 (BUG-1): HARD CAP = target (was target × 2).
        # If user set target=1, allow max 1 market. If the single market
        # becomes non-quotable, we REPLACE it (see replace logic below)
        # rather than keeping it and adding a buffer.
        if current >= target:
            # At cap and still not enough quotable markets → try to replace
            # the worst non-quotable market with a fresh one.
            self._last_auto_refill_mono = now_mono
            log.info(
                "auto_refill_throttle_passed",
                elapsed_sec=round(elapsed, 1) if elapsed != float("inf") else 0,
                cooldown_sec=settings.auto_refill_cooldown_sec,
                path="replace",
                quotable=quotable,
                target=target,
            )
            await self._replace_non_quotable_markets(target)
            return

        self._last_auto_refill_mono = now_mono
        log.info(
            "auto_refill_throttle_passed",
            elapsed_sec=round(elapsed, 1) if elapsed != float("inf") else 0,
            cooldown_sec=settings.auto_refill_cooldown_sec,
            path="add",
            quotable=quotable,
            target=target,
        )

        log.info(
            "auto_refill_started",
            total_markets=current,
            quotable_markets=quotable,
            target=target,
            hard_cap=target,
            bankroll=round(self.inventory.bankroll, 2),
            dynamic=settings.auto_pick_dynamic,
            reason=f"fewer than {target} quotable markets (bankroll-based)",
        )
        # v1.0.46 FIX (BUG-7): try/finally restores auto_pick_count even on
        # exception. Previously discover_markets() raising would leave the
        # setting permanently mutated.
        old_count = settings.auto_pick_count
        settings.auto_pick_count = max(1, target - quotable)
        try:
            new_markets = await self.clob.discover_markets()
        finally:
            settings.auto_pick_count = old_count
        added = 0
        for info in new_markets:
            # v1.0.155: never re-pick a market under an adverse-rate ban
            if self._is_market_banned(info.token_id):
                continue
            if info.token_id not in self.clob.books:
                self.clob.books[info.token_id] = MarketBook(token_id=info.token_id)
                self.clob.markets[info.token_id] = info
                await self.clob._feed.subscribe(info.token_id)
                added += 1
        if added > 0:
            await self.clob._refresh_all_books()
            log.info("auto_refill_done", added=added, quotable_before=quotable)

    def _update_market_availability(self) -> None:
        """Expose prolonged zero-quotable state without blocking discovery."""
        quotable = sum(
            1 for book in self.clob.books.values()
            if self._is_auto_refill_quotable(book)
        )
        now = time.monotonic()
        if quotable > 0:
            if self._degraded_reason == "NO_MARKETS":
                log.info("no_markets_recovered")
            self._no_markets_since_mono = None
            self._degraded_reason = ""
            return
        if self._no_markets_since_mono is None:
            self._no_markets_since_mono = now
        age = now - self._no_markets_since_mono
        if age >= settings.no_markets_degraded_sec:
            if self._degraded_reason != "NO_MARKETS":
                log.warning("no_markets_degraded", duration_sec=round(age, 1))
            self._degraded_reason = "NO_MARKETS"

    def _clear_crash_recovery_on_clean_quote(self) -> None:
        if self._crash_recovery_active:
            self._crash_recovery_active = False
            log.info("crash_recovery_cleared", reason="first clean quote cycle")

    async def _replace_non_quotable_markets(self, target: int) -> None:
        """v1.0.46 (BUG-1): replace non-quotable markets when at hard cap.

        When current >= target but quotable < target, we can't add more
        markets (hard cap reached). Instead we identify the WORST
        non-quotable market (widest spread or empty book), drop it, and
        discover a fresh replacement. This prevents the bot from being
        stuck indefinitely on a dead market.
        """
        # Find non-quotable markets (spread < min or missing side)
        non_quotable: list[tuple[str, float]] = []  # (token_id, spread_cents)
        for tid, book in self.clob.books.items():
            if not book.bids or not book.asks:
                # Empty book — worst kind, prioritize for replacement
                non_quotable.append((tid, 0.0))
            elif not self._is_auto_refill_quotable(book):
                non_quotable.append((tid, book.spread * 100))

        if not non_quotable:
            return  # all markets are quotable, nothing to replace

        # Sort: empty books (spread=0) first, then by tightest spread
        non_quotable.sort(key=lambda x: x[1])

        # Replace at most (target - quotable) markets
        quotable = sum(
            1 for book in self.clob.books.values()
            if self._is_auto_refill_quotable(book)
        )
        to_replace = min(target - quotable, len(non_quotable))
        if to_replace <= 0:
            return

        log.info(
            "auto_refill_replace_started",
            non_quotable_count=len(non_quotable),
            to_replace=to_replace,
            target=target,
        )

        # Don't replace markets that have open inventory (would orphan it).
        # We only replace flat markets (no net position).
        replaced = 0
        for tid, _spread in non_quotable:
            if replaced >= to_replace:
                break
            inv = self.inventory.get_inventory(tid)
            # Never rotate away from any real position or in-flight order.
            # A $2 FAST_FLAT position is intentionally below the old $5
            # Polymarket dust threshold but still represents real money.
            has_pending = any(
                p.get("token_id") == tid for p in self._pending_orders.values()
            )
            if abs(inv.net_tokens) > 0.000001 or has_pending:
                continue
            # v1.0.144: dollar-based dust threshold (Claude Section 2).
            # Old: `if abs(inv.net_tokens) > 0.5` — token count, inconsistent across prices.
            # New: position value in USD. Dust (< $5) can be dropped; real positions kept.
            position_value = abs(inv.net_tokens * inv.avg_entry_price) if inv.avg_entry_price > 0 else 0
            if settings.auto_refill_keep_partial:
                # Only skip markets with SIGNIFICANT positions (>= dust_threshold)
                if position_value >= settings.dust_threshold_usdc:
                    continue  # significant position, keep market
                # Dust — can drop market from quoting.
                # Inventory record stays for resolution reconciliation (v1.0.144).
                if position_value > 0:
                    log.info(
                        "auto_refill_dropping_dust_market",
                        token=tid[:12],
                        position_value=round(position_value, 2),
                        dust_threshold=settings.dust_threshold_usdc,
                        reason="dust position (< $5) — will resolve via reconciliation loop",
                    )
            else:
                # Old behavior: any position blocks refill
                if abs(inv.net_tokens) > 0.5:
                    continue

            # Cancel any quotes on this market
            # v1.0.146 (Claude): force=True — this market is being dropped
            # and WS is unsubscribed right below. A partially-filled quote
            # left live here would be an unmonitored order on a market the
            # bot no longer watches. The dust inventory record stays for
            # the reconciliation loop regardless.
            if tid in self.active_quotes:
                await self._cancel_all_levels(tid, force=True)
            # Unsubscribe WS
            try:
                await self.clob._feed.unsubscribe(tid)
            except Exception:
                pass
            # Remove from books + markets
            self.clob.books.pop(tid, None)
            self.clob.markets.pop(tid, None)
            self.inventory.inventories.pop(tid, None)
            self._as_calc.clear(tid)
            self._kyle.clear(tid)
            self.risk.adverse_selection.clear(tid)
            self.risk.circuit_breakers.clear_token(tid)
            replaced += 1
            log.info("auto_refill_dropped_market", token=tid[:12])

        if replaced == 0:
            return

        # Discover replacements
        old_count = settings.auto_pick_count
        settings.auto_pick_count = replaced
        try:
            new_markets = await self.clob.discover_markets()
        except Exception as e:
            log.debug("auto_refill_replace_discover_error", error=str(e))
            new_markets = []
        finally:
            settings.auto_pick_count = old_count

        added = 0
        for info in new_markets:
            # v1.0.155: never re-pick a market under an adverse-rate ban
            if self._is_market_banned(info.token_id):
                continue
            if info.token_id not in self.clob.books:
                self.clob.books[info.token_id] = MarketBook(token_id=info.token_id)
                self.clob.markets[info.token_id] = info
                await self.clob._feed.subscribe(info.token_id)
                added += 1
        if added > 0:
            await self.clob._refresh_all_books()
            log.info(
                "auto_refill_replace_done",
                replaced=replaced,
                added=added,
                total=len(self.clob.books),
            )

    # ── Per-market processing ─────────────────────────────────────────────

    @staticmethod
    def _is_auto_refill_quotable(book: MarketBook) -> bool:
        """Return whether *book* is eligible for the active strategy.

        Legacy quoting only has a minimum spread. FAST_FLAT deliberately
        trades a bounded window, so both of its spread limits must govern
        auto-refill as well as entry.
        """
        if not book.bids or not book.asks:
            return False
        spread_cents = book.spread * 100
        if settings.strategy_mode == "fast_flat":
            return (
                settings.fast_flat_min_spread_cents
                <= spread_cents
                <= settings.fast_flat_max_spread_cents
            )
        return spread_cents >= settings.spread_min_cents

    @staticmethod
    def _is_fast_flat_book_fresh(book: MarketBook) -> bool:
        """Fail closed when FAST_FLAT pricing is older than its tight SLA."""
        return (
            book.last_update > 0
            and time.monotonic() - book.last_update
            <= settings.fast_flat_max_book_age_sec
        )

    def _has_fast_flat_inventory(self) -> bool:
        return any(
            abs(inv.net_tokens) > 0.000001
            for inv in self.inventory.inventories.values()
        )

    def _fast_flat_pending(
        self, token_id: str | None = None, role: str | None = None
    ) -> list[tuple[str, dict[str, Any]]]:
        rows: list[tuple[str, dict[str, Any]]] = []
        for order_id, info in self._pending_orders.items():
            if info.get("strategy") != "fast_flat":
                continue
            if token_id is not None and info.get("token_id") != token_id:
                continue
            if role is not None and info.get("role") != role:
                continue
            rows.append((order_id, info))
        return rows

    def _fast_flat_quotes(
        self, token_id: str, role: str | None = None
    ) -> list[ActiveQuote]:
        return [
            q
            for q in self.active_quotes.get(token_id, [])
            if q.strategy == "fast_flat" and (role is None or q.role == role)
        ]

    def _set_fast_flat_phase(self, phase: str) -> None:
        state = self._fast_flat_state
        if state is None or state.phase == phase:
            return
        old = state.phase
        state.phase = phase
        log.info(
            "fast_flat_phase",
            token=state.token_id[:12],
            cycle_id=state.cycle_id,
            previous=old,
            phase=phase,
        )

    def _refresh_fast_flat_state(self) -> None:
        """Recover the single active cycle from inventory/orders after restart."""
        state = self._fast_flat_state
        if state is not None:
            inv = self.inventory.inventories.get(state.token_id)
            has_position = bool(inv and abs(inv.net_tokens) > 0.000001)
            if inv and inv.net_tokens > 0.000001 and inv.open_time <= 0:
                # DB restore cannot preserve a monotonic timestamp. Start a
                # new conservative rescue clock at process recovery; leaving
                # zero here makes position_age stay zero forever and disables
                # the controlled-loss escape path until resolution.
                inv.open_time = time.monotonic()
                inv.opened_at_epoch = time.time()
                log.warning(
                    "fast_flat_restored_position_timer_started",
                    token=state.token_id[:12],
                    cycle_id=state.cycle_id,
                )
            has_pending = bool(self._fast_flat_pending(state.token_id))
            has_quote = bool(self._fast_flat_quotes(state.token_id))
            if has_position:
                state.had_position = True
            if not has_position and not has_pending and not has_quote:
                if state.had_position and not state.round_trip_counted:
                    state.round_trip_counted = True
                    self._round_trip_count += 1
                    ROUND_TRIPS_TOTAL.inc()
                    log.info(
                        "fast_flat_round_trip_complete",
                        token=state.token_id[:12],
                        cycle_id=state.cycle_id,
                        bankroll=round(self.inventory.bankroll, 6),
                        daily_pnl=round(self.inventory.daily_pnl, 6),
                    )
                if inv is not None:
                    inv.fast_flat_cycle_id = 0
                    inv.fast_flat_cycle_start_bankroll = 0.0
                    inv.fast_flat_cycle_initial_tokens = 0.0
                self._fast_flat_state = None

        if self._fast_flat_state is not None:
            return

        # Inventory takes priority over pending orders: restored inventory is
        # always EXIT-only, never a signal to start another BUY.
        for tid, inv in self.inventory.inventories.items():
            if abs(inv.net_tokens) > 0.000001:
                if inv.net_tokens > 0 and inv.open_time <= 0:
                    inv.open_time = time.monotonic()
                    inv.opened_at_epoch = time.time()
                    log.warning(
                        "fast_flat_restored_position_timer_started",
                        token=tid[:12],
                    )
                restored_cycle_id = int(inv.fast_flat_cycle_id or 0)
                if restored_cycle_id <= 0:
                    self._fast_flat_cycle_seq += 1
                    restored_cycle_id = self._fast_flat_cycle_seq
                else:
                    self._fast_flat_cycle_seq = max(
                        self._fast_flat_cycle_seq, restored_cycle_id
                    )
                self._fast_flat_state = FastFlatState(
                    token_id=tid,
                    cycle_id=restored_cycle_id,
                    phase="LONG" if inv.net_tokens > 0 else "UNSUPPORTED_SHORT",
                    bankroll_start=float(inv.fast_flat_cycle_start_bankroll or 0.0),
                    had_position=True,
                )
                return
        pending = self._fast_flat_pending()
        if pending:
            _, info = pending[0]
            self._fast_flat_cycle_seq = max(
                self._fast_flat_cycle_seq, int(info.get("cycle_id") or 0)
            )
            pending_inv = self.inventory.get_inventory(info["token_id"])
            self._fast_flat_state = FastFlatState(
                token_id=info["token_id"],
                cycle_id=int(info.get("cycle_id") or self._fast_flat_cycle_seq),
                phase=f"{info.get('role', 'ORDER')}_WORKING",
                bankroll_start=float(
                    pending_inv.fast_flat_cycle_start_bankroll or self.inventory.bankroll
                ),
            )

    @staticmethod
    def _ceil_to_tick(value: float, tick: float) -> float:
        tick = max(tick, 0.000001)
        return round(math.ceil((value - 1e-12) / tick) * tick, 8)

    @staticmethod
    def _floor_to_tick(value: float, tick: float) -> float:
        tick = max(tick, 0.000001)
        return round(math.floor((value + 1e-12) / tick) * tick, 8)

    @staticmethod
    def _top_level_tokens(book: MarketBook, side: str) -> float:
        price = book.best_bid if side == "SELL" else book.best_ask
        levels = book.bids if side == "SELL" else book.asks
        return sum(lvl.size for lvl in levels if abs(lvl.price - price) < 1e-9)

    async def _cancel_fast_flat_role(self, token_id: str, role: str) -> None:
        quotes = self.active_quotes.get(token_id, [])
        keep: list[ActiveQuote] = []
        for quote in quotes:
            if quote.strategy == "fast_flat" and quote.role == role:
                await self._cancel_quote_level(token_id, quote)
            else:
                keep.append(quote)
        if keep:
            self.active_quotes[token_id] = keep
        else:
            self.active_quotes.pop(token_id, None)

    async def _cancel_legacy_orders_for_fast_flat(self) -> bool:
        """Drain any pre-switch legacy orders before FAST_FLAT can act."""
        found = False
        for tid, quotes in list(self.active_quotes.items()):
            legacy = [q for q in quotes if q.strategy != "fast_flat"]
            if legacy:
                found = True
                for quote in legacy:
                    await self._cancel_quote_level(tid, quote)
                self.active_quotes[tid] = [
                    q for q in quotes if q.strategy == "fast_flat"
                ]
                if not self.active_quotes[tid]:
                    self.active_quotes.pop(tid, None)
        for order_id, info in self._pending_orders.items():
            if info.get("strategy") == "fast_flat":
                continue
            found = True
            if not info.get("cancel_requested_at"):
                try:
                    if await self.clob.cancel_order(order_id):
                        info["cancel_requested_at"] = time.monotonic()
                except Exception as exc:
                    log.warning(
                        "fast_flat_legacy_cancel_failed",
                        order_id=order_id,
                        error=str(exc),
                    )
        return found

    def _mark_fast_flat_quote(
        self, quote: ActiveQuote, role: str, state: FastFlatState
    ) -> None:
        quote.strategy = "fast_flat"
        quote.role = role
        quote.cycle_id = state.cycle_id
        ttl = self._fast_flat_profile_value(
            quote.token_id,
            settings.fast_flat_entry_ttl_sec if role == "ENTRY" else settings.fast_flat_exit_max_age_sec,
            settings.fast_flat_15m_entry_ttl_sec if role == "ENTRY" else settings.fast_flat_15m_exit_max_age_sec,
        )
        for order_id in (quote.bid_order_id, quote.ask_order_id):
            if not order_id:
                continue
            pending = self._pending_orders.get(order_id)
            if pending is not None:
                pending.update(
                    {
                        "strategy": "fast_flat",
                        "role": role,
                        "cycle_id": state.cycle_id,
                        "ttl_sec": ttl,
                        "cancel_on_first_fill": True,
                        "exit_path": (
                            "FAST_FLAT_MAKER_EXIT" if role == "EXIT" else "FAST_FLAT_ENTRY"
                        ),
                    }
                )

    def _fast_flat_is_15m(self, token_id: str) -> bool:
        if not settings.fast_flat_15m_profile_enabled:
            return False
        info = self.clob.markets.get(token_id)
        name = (getattr(info, "question", "") or "").lower()
        return any(marker in name for marker in ("15m", "15 min", "15-min", "15 minute"))

    def _fast_flat_profile_value(self, token_id: str, regular: float, short: float) -> float:
        return short if self._fast_flat_is_15m(token_id) else regular

    def _fast_flat_minimum_ttr(self, token_id: str) -> float:
        if not self._fast_flat_is_15m(token_id):
            return settings.fast_flat_min_ttr_sec
        return max(
            settings.fast_flat_15m_min_ttr_sec,
            settings.fast_flat_15m_entry_ttl_sec
            + settings.fast_flat_15m_rescue_after_sec
            + settings.fast_flat_15m_pre_resolution_exit_sec,
        )

    async def _process_fast_flat_market(
        self,
        token_id: str,
        book: MarketBook,
        market_name: str,
        *,
        exit_only: bool = False,
    ) -> None:
        """One maker entry, then exact-share maker/FAK exit, repeat.

        The method owns the complete strategy branch.  It never calls the
        legacy multi-level quoting, hedge, sniper, or liquidation paths.
        """
        if await self._cancel_legacy_orders_for_fast_flat():
            return
        self._refresh_fast_flat_state()
        state = self._fast_flat_state
        if state is not None and state.token_id != token_id:
            return

        book_is_fresh = self._is_fast_flat_book_fresh(book)

        inv = self.inventory.get_inventory(token_id)
        if inv.net_tokens < -0.000001:
            self.inventory.halt(
                reason="FAST_FLAT_SHORT",
                detail="FAST_FLAT cannot safely recover a short outcome-token position",
            )
            return

        quotes = self._fast_flat_quotes(token_id)
        # PAPER fill simulation consumes book prices, so it must not invent
        # fills from an expired snapshot. LIVE fills are reconciled by the
        # authoritative order-status poller and do not depend on this branch.
        if quotes and (book_is_fresh or not settings.paper_trading):
            await self._check_fills(token_id, book, quotes, market_name)
            inv = self.inventory.get_inventory(token_id)
            if state is not None and inv.net_tokens > 0.000001:
                state.had_position = True
            if inv.net_tokens <= 0.000001 and any(
                q.role == "EXIT" and q.ask_filled for q in quotes
            ):
                await self._cancel_fast_flat_role(token_id, "EXIT")
                self._refresh_fast_flat_state()
                return

        # A confirmed partial ENTRY/EXIT always cancels its unfilled
        # remainder.  Never place the other side until terminal cancellation.
        entry_quotes_active = self._fast_flat_quotes(token_id, "ENTRY")
        if inv.net_tokens > 0.000001 and entry_quotes_active:
            all_paper_terminal = settings.paper_trading and all(
                q.bid_filled for q in entry_quotes_active
            )
            await self._cancel_fast_flat_role(token_id, "ENTRY")
            if not all_paper_terminal:
                self._set_fast_flat_phase("ENTRY_CANCEL_PENDING")
                return
        entry_pending = self._fast_flat_pending(token_id, "ENTRY")
        if inv.net_tokens > 0.000001 and entry_pending:
            for order_id, info in entry_pending:
                if not info.get("cancel_requested_at"):
                    try:
                        if await self.clob.cancel_order(order_id):
                            info["cancel_requested_at"] = time.monotonic()
                    except Exception as exc:
                        log.warning(
                            "fast_flat_partial_entry_cancel_failed",
                            order_id=order_id,
                            error=str(exc),
                        )
            await self._cancel_fast_flat_role(token_id, "ENTRY")
            self._set_fast_flat_phase("ENTRY_CANCEL_PENDING")
            return

        if inv.net_tokens > 0.000001:
            if state is None:
                self._refresh_fast_flat_state()
                state = self._fast_flat_state
            assert state is not None
            state.had_position = True
            self._set_fast_flat_phase("LONG")
            await self._cancel_fast_flat_role(token_id, "ENTRY")
            if self._fast_flat_pending(token_id, "ENTRY"):
                self._set_fast_flat_phase("ENTRY_CANCEL_PENDING")
                return

            exit_pending = self._fast_flat_pending(token_id, "EXIT")
            if exit_pending:
                self._set_fast_flat_phase("EXIT_WORKING")
                # A tracked maker EXIT may be cancelled once the whole cycle
                # is safely profitable at the current FAK price.  A pending
                # order without an ActiveQuote (for example after restart)
                # stays fail-closed to avoid placing a duplicate SELL.
                if not self._fast_flat_quotes(token_id, "EXIT"):
                    return

            # Never price a new maker exit or cross the book with FAK from a
            # stale snapshot. Existing maker orders remain tracked while we
            # wait for fresh market data; terminal reconciliation still runs.
            if not book_is_fresh:
                return

            tick = max(book.tick_size, 0.0001)
            # A long outcome-token position can still be crossed into a
            # bid-only book.  The ask side is needed for a new entry, but it
            # is not a prerequisite for either a FAK sell or a defensive
            # maker sell.  Use conservative one-sided references instead of
            # MarketBook.best_ask's empty-book sentinel (1.0).
            exit_mid = book.mid if book.asks else book.best_bid
            exit_spread = book.spread if book.asks else tick
            tokens = inv.net_tokens
            gas = (
                settings.paper_gas_cost_usdc
                if settings.paper_trading
                else settings.live_gas_cost_usdc
            )
            cost_basis = tokens * inv.avg_entry_price
            required_maker_proceeds = (
                cost_basis + settings.fast_flat_target_profit_usdc + 2.0 * gas
            )
            maker_floor = self._ceil_to_tick(
                required_maker_proceeds / max(tokens, 0.000001), tick
            )
            position_age = (
                time.monotonic() - inv.open_time if inv.open_time > 0 else 0.0
            )

            # Full-depth FAK only.  A shallow top level is never allowed to
            # create another partial remainder.  Profitability is evaluated
            # at the WHOLE-CYCLE level: current bankroll already includes the
            # entry cash outflow, prior maker SELL proceeds, their fees/gas,
            # and any partial-fill P&L.  Add only the conservative net cash
            # expected from selling the remaining tokens.
            top_bid_tokens = self._top_level_tokens(book, "SELL")
            slippage = settings.fast_flat_profit_fak_slippage_cents / 100.0
            expected_fak_price = max(0.01, book.best_bid - slippage)
            taker_fee = tokens * self._taker_fee_per_token(
                token_id, expected_fak_price
            )
            expected_exit_cash = (
                tokens * expected_fak_price - taker_fee - gas
            )
            bankroll_start = float(
                state.bankroll_start
                or inv.fast_flat_cycle_start_bankroll
                or 0.0
            )
            projected_final_bankroll = self.inventory.bankroll + expected_exit_cash
            cycle_pnl = (
                projected_final_bankroll - bankroll_start
                if bankroll_start > 0
                else expected_exit_cash - cost_basis - gas
            )
            fak_leg_pnl = (
                tokens * (expected_fak_price - inv.avg_entry_price)
                - taker_fee - gas
            )
            fak_leg_loss = max(0.0, -fak_leg_pnl)
            realized_cycle_pnl = (
                self.inventory.bankroll + cost_basis - bankroll_start
                if bankroll_start > 0 else 0.0
            )
            maker_profit = max(0.0, realized_cycle_pnl)
            max_fak_leg_loss = min(
                settings.fast_flat_max_fak_leg_loss_usdc,
                maker_profit * settings.fast_flat_max_fak_loss_maker_profit_pct,
            )
            initial_tokens = max(inv.fast_flat_cycle_initial_tokens, tokens)
            remainder_pct = tokens / max(initial_tokens, 0.000001)
            residual_guard_ok = (
                fak_leg_loss <= max_fak_leg_loss + 1e-9
                and (
                    fak_leg_loss <= 1e-9
                    or remainder_pct <= settings.fast_flat_max_fak_remainder_pct + 1e-9
                )
            )
            target_hit = (
                settings.fast_flat_profit_fak_enabled
                and bankroll_start > 0
                and position_age >= self._fast_flat_profile_value(
                    token_id, settings.fast_flat_profit_fak_after_sec,
                    settings.fast_flat_15m_profit_fak_after_sec,
                )
                and cycle_pnl >= settings.fast_flat_target_profit_usdc
                and residual_guard_ok
            )
            rescue_ok = (
                position_age >= self._fast_flat_profile_value(
                    token_id, settings.fast_flat_rescue_after_sec,
                    settings.fast_flat_15m_rescue_after_sec,
                )
                and cycle_pnl + 1e-9 >= -settings.fast_flat_loss_budget_usdc
            )
            full_depth = top_bid_tokens >= tokens * 1.001
            if full_depth and (target_hit or rescue_ok):
                fak_exit_path = (
                    "FAST_FLAT_PROFIT_FAK_EXIT"
                    if target_hit else "FAST_FLAT_RESCUE_FAK_EXIT"
                )
                if target_hit:
                    log.info(
                        "fast_flat_profitable_fak_armed",
                        token=token_id[:12],
                        cycle_id=state.cycle_id,
                        position_age_sec=round(position_age, 3),
                        best_bid=round(book.best_bid, 6),
                        expected_fak_price=round(expected_fak_price, 6),
                        remaining_tokens=round(tokens, 6),
                        projected_cycle_pnl=round(cycle_pnl, 6),
                        projected_final_bankroll=round(
                            projected_final_bankroll, 6
                        ),
                        cycle_bankroll_start=round(bankroll_start, 6),
                    )
                if self._fast_flat_quotes(token_id, "EXIT"):
                    await self._cancel_fast_flat_role(token_id, "EXIT")
                    return
                accepted, _ = await self._submit_immediate_order(
                    token_id,
                    "SELL",
                    book.best_bid,
                    tokens * book.best_bid,
                    market_name,
                    level=1,
                    mid_at_place=exit_mid,
                    exit_path=fak_exit_path,
                    is_liquidation=True,
                    cycle_id=state.cycle_id,
                )
                if accepted:
                    for _, info in self._pending_orders.items():
                        if (
                            info.get("token_id") == token_id
                            and info.get("exit_path") == fak_exit_path
                        ):
                            info.update(
                                {
                                    "strategy": "fast_flat",
                                    "role": "EXIT",
                                    "cycle_id": state.cycle_id,
                                }
                            )
                    self._set_fast_flat_phase("FAK_EXIT_PENDING")
                return

            # Keep exactly one maker SELL. Reprice only when materially stale;
            # partial PAPER fills are cancelled and replaced for exact remainder.
            competitive = book.best_bid + tick
            if book.asks:
                competitive = max(competitive, book.best_ask - tick)
            exit_price = self._ceil_to_tick(max(maker_floor, competitive), tick)
            exit_price = max(0.01, min(0.99, exit_price))
            if exit_price <= book.best_bid:
                exit_price = self._ceil_to_tick(book.best_bid + tick, tick)
            if exit_price > 0.99:
                return

            exit_prices = [exit_price]
            if settings.exchange == "limitless" and settings.fast_flat_multilevel_enabled:
                # Symmetric hardcoded Limitless SELL ladder.  All levels
                # improve the public best ask while respecting the cycle's
                # maker-profit floor.
                limitless_offsets = (0.0010, 0.0015, 0.0020)
                raw_exit_prices = [
                    round(book.best_ask - offset, 4)
                    for offset in limitless_offsets
                ]
                exit_prices = [
                    round(max(maker_floor, price), 4)
                    for price in raw_exit_prices
                ]
                if any(price <= book.best_bid or price > 0.99 for price in exit_prices):
                    return

                min_order = max(book.min_order_size, 0.000001)
                affordable = max(
                    1, int((tokens * min(exit_prices) + 1e-9) // min_order)
                )
                exit_prices = exit_prices[:min(len(exit_prices), affordable)]

            exit_quotes = self._fast_flat_quotes(token_id, "EXIT")
            if exit_quotes:
                quote = exit_quotes[0]
                age = time.monotonic() - quote.placed_at
                exit_requote_threshold = max(
                    tick,
                    settings.fast_flat_exit_requote_threshold_cents / 100.0,
                )
                current_prices = [q.ask_price for q in exit_quotes]
                changed = len(current_prices) != len(exit_prices) or any(
                    current is None
                    or abs(current - desired) >= exit_requote_threshold - 1e-9
                    for current, desired in zip(current_prices, exit_prices)
                )
                partial = (
                    any(q.ask_filled for q in exit_quotes)
                    and inv.net_tokens > 0.000001
                )
                if partial or age >= self._fast_flat_profile_value(
                    token_id, settings.fast_flat_exit_max_age_sec,
                    settings.fast_flat_15m_exit_max_age_sec,
                ) or (
                    changed and age >= settings.fast_flat_exit_requote_sec
                ):
                    await self._cancel_fast_flat_role(token_id, "EXIT")
                    self._set_fast_flat_phase("EXIT_CANCEL_PENDING")
                return

            placed_exit_quotes: list[ActiveQuote] = []
            remaining_tokens = tokens
            tokens_per_level = tokens / len(exit_prices)
            for level, price in enumerate(exit_prices, start=1):
                level_tokens = (
                    remaining_tokens
                    if level == len(exit_prices)
                    else tokens_per_level
                )
                quote = await self._place_quote_level(
                    token_id=token_id,
                    level=level,
                    bid_price=None,
                    ask_price=price,
                    size_usdc=level_tokens * price,
                    mid=exit_mid,
                    reservation=exit_mid,
                    spread_cents=exit_spread * 100,
                    market_name=market_name,
                    book=book,
                    inventory_usdc=inv.net_usdc_at_entry,
                    inventory_tokens=tokens,
                )
                if quote is not None:
                    self._mark_fast_flat_quote(quote, "EXIT", state)
                    placed_exit_quotes.append(quote)
                    remaining_tokens -= level_tokens
            if len(placed_exit_quotes) == len(exit_prices):
                self.active_quotes[token_id] = placed_exit_quotes
                self._set_fast_flat_phase("EXIT_WORKING")
            return

        # Flat: wait for any previous order/cancel to become terminal.
        self._refresh_fast_flat_state()
        state = self._fast_flat_state
        if state is not None and state.token_id != token_id:
            return
        if self._fast_flat_pending() or any(
            q.strategy == "fast_flat"
            for qs in self.active_quotes.values()
            for q in qs
        ):
            if state is not None:
                entry_quotes = self._fast_flat_quotes(token_id, "ENTRY")
                if entry_quotes:
                    quote = entry_quotes[0]
                    age = time.monotonic() - quote.placed_at
                    hard_expired = age >= self._fast_flat_profile_value(
                        token_id, settings.fast_flat_entry_ttl_sec,
                        settings.fast_flat_15m_entry_ttl_sec,
                    )
                    materially_moved = False
                    invalid_market = False
                    desired_entry: float | None = None
                    if book_is_fresh and book.bids and book.asks:
                        tick = max(book.tick_size, 0.0001)
                        desired_entry = self._floor_to_tick(
                            min(book.best_bid + tick, book.best_ask - tick), tick
                        )
                        invalid_market = (
                            desired_entry <= book.best_bid
                            or desired_entry >= book.best_ask
                            or not (
                                settings.fast_flat_min_spread_cents
                                <= book.spread * 100
                                <= settings.fast_flat_max_spread_cents
                            )
                            or self._is_market_banned(token_id)
                        )
                        threshold = max(
                            tick,
                            settings.fast_flat_entry_requote_threshold_cents / 100.0,
                        )
                        materially_moved = bool(
                            quote.bid_price is None
                            or abs(quote.bid_price - desired_entry) >= threshold - 1e-9
                        )
                    should_requote = (
                        age >= settings.fast_flat_entry_requote_sec
                        and materially_moved
                    )
                    if hard_expired or invalid_market or should_requote:
                        reason = (
                            "hard_ttl"
                            if hard_expired
                            else "market_invalid"
                            if invalid_market
                            else "material_price_move"
                        )
                        log.info(
                            "fast_flat_entry_requote",
                            token=token_id[:12],
                            cycle_id=state.cycle_id,
                            reason=reason,
                            age_sec=round(age, 3),
                            old_price=quote.bid_price,
                            desired_price=desired_entry,
                        )
                        await self._cancel_fast_flat_role(token_id, "ENTRY")
                        self._set_fast_flat_phase("ENTRY_CANCEL_PENDING")
            return
        if exit_only or self.inventory.halted:
            return

        # Entry filters apply only while flat.  Exit paths above remain active
        # even if a market later becomes banned, narrow, or close to expiry.
        if not book_is_fresh:
            return
        if self._is_market_banned(token_id):
            return
        info = self.clob.markets.get(token_id)
        if info and info.end_date_ts > 0:
            ttr = info.end_date_ts - datetime.now(timezone.utc).timestamp()
            min_ttr = self._fast_flat_minimum_ttr(token_id)
            if ttr < min_ttr:
                return
        if not (0.05 <= book.mid <= 0.95):
            return
        spread_cents = book.spread * 100
        if not (
            settings.fast_flat_min_spread_cents
            <= spread_cents
            <= settings.fast_flat_max_spread_cents
        ):
            return
        decision = self.risk.should_quote(token_id, book)
        if not decision.allow_bid:
            return

        tick = max(book.tick_size, 0.0001)
        entry_price = self._floor_to_tick(
            min(book.best_bid + tick, book.best_ask - tick), tick
        )
        if entry_price <= book.best_bid or entry_price >= book.best_ask:
            return
        reserve = max(
            settings.fast_flat_cash_reserve_usdc,
            self.inventory.bankroll * settings.fast_flat_cash_reserve_pct,
        )
        spendable = max(0.0, self.inventory.bankroll - reserve)
        order_size = self._fast_flat_profile_value(
            token_id, settings.fast_flat_order_size_usdc,
            settings.fast_flat_15m_order_size_usdc,
        )
        size_usdc = min(order_size, spendable)
        min_order = max(book.min_order_size, 0.000001)
        if size_usdc + 1e-9 < min_order:
            return
        requested_level_count = (
            settings.fast_flat_multilevel_count
            if settings.fast_flat_multilevel_enabled else 1
        )
        # Keep the configured total notional unchanged, but never split it
        # into child orders below the venue minimum.  For example, a $2
        # notional with a $1 venue minimum can support two levels, not three.
        affordable_level_count = max(1, int((size_usdc + 1e-9) // min_order))
        level_count = min(requested_level_count, affordable_level_count)
        level_size = size_usdc / level_count
        if level_size + 1e-9 < min_order:
            return
        if settings.exchange == "limitless" and settings.fast_flat_multilevel_enabled:
            # Hardcoded Limitless entry ladder.  All three levels improve the
            # public best bid and move inward through the spread:
            # bid 0.1460 -> 0.1470 / 0.1475 / 0.1480.
            limitless_offsets = (0.0010, 0.0015, 0.0020)
            if level_count > len(limitless_offsets):
                return
            level_prices = [
                round(book.best_bid + limitless_offsets[i], 4)
                for i in range(level_count)
            ]
            if any(px >= book.best_ask for px in level_prices):
                return
        else:
            level_prices = [
                self._floor_to_tick(max(0.01, entry_price - i * tick), tick)
                for i in range(level_count)
            ]
        gas_per_fill = settings.paper_gas_cost_usdc if settings.paper_trading else settings.live_gas_cost_usdc
        viable_prices = [
            px for px in level_prices
            if (level_size / px) * max(0.0, book.best_ask - px) - 2 * gas_per_fill
            >= settings.fast_flat_target_profit_usdc / level_count
        ]
        if len(viable_prices) != level_count:
            return
        desired_tokens = sum(level_size / px for px in viable_prices)
        bid_depth = self._top_level_tokens(book, "SELL")
        ask_depth = self._top_level_tokens(book, "BUY")
        depth_mult = self._fast_flat_profile_value(
            token_id, settings.fast_flat_min_top_depth_mult,
            settings.fast_flat_15m_depth_mult,
        )
        depth_need = desired_tokens * depth_mult
        if bid_depth < depth_need or ask_depth < depth_need:
            return

        self._fast_flat_cycle_seq += 1
        cycle_bankroll_start = self.inventory.bankroll
        cycle_inv = self.inventory.get_inventory(token_id)
        cycle_inv.fast_flat_cycle_id = self._fast_flat_cycle_seq
        cycle_inv.fast_flat_cycle_start_bankroll = cycle_bankroll_start
        cycle_inv.fast_flat_cycle_initial_tokens = desired_tokens
        state = FastFlatState(
            token_id=token_id,
            cycle_id=self._fast_flat_cycle_seq,
            phase="ENTRY_WORKING",
            bankroll_start=cycle_bankroll_start,
        )
        self._fast_flat_state = state
        entry_quotes: list[ActiveQuote] = []
        for level, price in enumerate(viable_prices, start=1):
            quote = await self._place_quote_level(
                token_id=token_id, level=level, bid_price=price, ask_price=None,
                size_usdc=level_size, mid=book.mid, reservation=book.mid,
                spread_cents=spread_cents, market_name=market_name, book=book,
                inventory_usdc=0.0, inventory_tokens=0.0,
            )
            if quote is not None:
                self._mark_fast_flat_quote(quote, "ENTRY", state)
                entry_quotes.append(quote)
        if len(entry_quotes) != level_count:
            for q in entry_quotes:
                for order_id in (q.bid_order_id, q.ask_order_id):
                    if order_id:
                        await self.clob.cancel_order(order_id)
            cycle_inv.fast_flat_cycle_id = 0
            cycle_inv.fast_flat_cycle_start_bankroll = 0.0
            cycle_inv.fast_flat_cycle_initial_tokens = 0.0
            self._fast_flat_state = None
            return
        self.active_quotes[token_id] = entry_quotes
        self._clear_crash_recovery_on_clean_quote()
        log.info(
            "fast_flat_entry_placed",
            market=market_name[:40],
            cycle_id=state.cycle_id,
            price=entry_price,
            levels=level_count,
            size_usdc=round(size_usdc, 6),
            reserve_usdc=round(reserve, 6),
            spread_cents=round(spread_cents, 4),
        )

    async def _process_market(
        self, token_id: str, book: MarketBook, *, exit_only: bool = False
    ) -> None:
        """Update quotes for one market."""
        info = self.clob.markets.get(token_id)
        market_name = info.question[:60] if info else token_id[:12]

        if settings.strategy_mode == "fast_flat":
            inv = self.inventory.get_inventory(token_id)
            # Entry requires both sides, but an existing long requires only a
            # bid to exit.  Blocking on a missing ask was one direct route to
            # holding inventory until resolution.
            usable = bool(book.bids) and (
                bool(book.asks) or inv.net_tokens > 0.000001
            )
            if not usable:
                log.info(
                    "market_skip_empty_book",
                    token=token_id[:12],
                    market=market_name[:30],
                )
                return
        elif not book.bids or not book.asks:
            log.info("market_skip_empty_book", token=token_id[:12], market=market_name[:30])
            return

        # v1.0.151: feed the momentum ring buffer every cycle, even for
        # markets that end up skipped below — history must keep flowing.
        self._push_mid(token_id, book.mid)

        if settings.strategy_mode == "fast_flat":
            self._process_adverse_probes()
            await self._process_fast_flat_market(
                token_id, book, market_name, exit_only=exit_only
            )
            return

        # v1.0.155: mature adverse probes; skip banned markets entirely
        # (auto-refill sees them as non-quotable and rotates them out).
        self._process_adverse_probes()
        if self._is_market_banned(token_id):
            if token_id in self.active_quotes:
                await self._cancel_all_levels(token_id)
            return

        # ── Market spread (visible in logs) ──
        market_spread_cents = round(book.spread * 100, 2)

        # ── TTR (Time To Resolution) — hours until market ends ──
        ttr_hours = None
        if info and info.end_date_ts > 0:
            now_ts = datetime.now(timezone.utc).timestamp()
            ttr = info.end_date_ts - now_ts
            ttr_hours = round(ttr / 3600, 1)

            # ── Pre-resolution exit ──
            pre_resolution_sec = self._fast_flat_profile_value(
                token_id, settings.pre_resolution_exit_sec,
                settings.fast_flat_15m_pre_resolution_exit_sec,
            )
            if ttr < pre_resolution_sec:
                log.info(
                    "market_skip_pre_resolution",
                    market=market_name[:40],
                    ttr_hours=ttr_hours,
                    market_spread_cents=market_spread_cents,
                )
                await self._handle_pre_resolution(token_id, book, market_name)
                return

        # ── Market quality filter: skip if spread < spread_min_cents ──
        if market_spread_cents < settings.spread_min_cents:
            log.info(
                "market_skip_tight_spread",
                market=market_name[:40],
                market_spread_cents=market_spread_cents,
                min_required=settings.spread_min_cents,
            )
            if token_id in self.active_quotes:
                await self._cancel_all_levels(token_id)
            return

        # v1.0.71 (BUG-N22): Resolution detector — ринок майже resolved.
        # Якщо mid < 0.05 або mid > 0.95 → ціна майже 0 або 1 → resolution imminent.
        # Продати інвентар негайно (mid-based), поки є ліквідність.
        # Захищає від Australia-сценарію: ціна впала -94%, бот тримав позицію.
        if book.mid < 0.05 or book.mid > 0.95:
            inv_check = self.inventory.get_inventory(token_id)
            if abs(inv_check.net_tokens) > 0.5 and inv_check.net_tokens > 0:
                log.warning(
                    "resolution_detector_triggered",
                    market=market_name[:40],
                    mid=round(book.mid, 4),
                    net_tokens=round(inv_check.net_tokens, 2),
                    avg_entry=round(inv_check.avg_entry_price, 4),
                    reason="mid < 5¢ or > 95¢ — market near resolution, exit now",
                )
                await self._handle_resolution_exit(token_id, book, market_name)
                return
            # No inventory — just skip quoting on near-resolved market
            log.info(
                "market_skip_near_resolution",
                market=market_name[:40],
                mid=round(book.mid, 4),
                reason="mid < 5¢ or > 95¢ — near resolution, no inventory to exit",
            )
            if token_id in self.active_quotes:
                await self._cancel_all_levels(token_id)
            return

        # CRITICAL: Skip very low-priced markets (< 5¢) — token count explodes
        # At $0.004, $5 order = 1250 tokens, tiny price move = huge fake P&L
        if book.mid < 0.05:
            log.info(
                "market_skip_low_price",
                market=market_name[:40],
                mid=round(book.mid, 4),
                reason="price < 5¢ causes token explosion and fake P&L",
            )
            if token_id in self.active_quotes:
                await self._cancel_all_levels(token_id)
            return

        # ── Update A-S pricing ──
        self._as_calc.update(token_id, book.mid)
        self.risk.on_cycle(token_id, book.mid)

        # v1.0.123: portfolio exposure warning (>80% of cap)
        if self._cycle_count % 30 == 0:  # log every ~30s, not every cycle
            exposure_pct = self.inventory.portfolio_exposure_pct()
            cap_pct = settings.max_total_exposure_pct_of_bankroll * 100
            if exposure_pct > cap_pct * 0.8:
                log.warning(
                    "portfolio_exposure_near_cap",
                    exposure_pct=round(exposure_pct, 1),
                    cap_pct=round(cap_pct, 1),
                    total_exposure=round(self.inventory.total_inventory_usdc(), 2),
                    portfolio_cap=round(self.inventory.portfolio_cap_usdc(), 2),
                    bankroll=round(self.inventory.bankroll, 2),
                )

        # v1.0.155: intraday wide-spread guard. The 30¢ rule existed only at
        # DISCOVER time (v1.0.44) — a held market that crashed intraday kept
        # being quoted, and PAPER's fill model harvested fantasy profits on
        # the torn book (SUI 2026-07-13: re-entries at 3¢, 416 tokens,
        # "+$37.5"). Runs AFTER pre-resolution/resolution-detector so exits
        # on held inventory still fire; the liquidation loop keeps handling
        # exits independently — this only stops NEW quoting.
        if market_spread_cents > 30.0:
            log.info(
                "market_skip_wide_spread_intraday",
                market=market_name[:40],
                market_spread_cents=market_spread_cents,
                reason="spread > 30¢ — crashed/empty book, no new quoting",
            )
            if token_id in self.active_quotes:
                await self._cancel_all_levels(token_id)
            return

        # ── Adverse selection trigger check ──
        if self.risk.adverse_selection.check_trigger(token_id):
            ADVERSE_TRIGGERS.inc()
            log.info(
                "market_skip_adverse_selection",
                market=market_name[:40],
                market_spread_cents=market_spread_cents,
            )
            await self._cancel_all_levels(token_id)
            return

        # ── Risk decision ──
        decision = self.risk.should_quote(token_id, book)
        if not decision.allow_any:
            log.info(
                "market_skip_risk",
                market=market_name[:40],
                market_spread_cents=market_spread_cents,
                reasons=decision.reasons,
            )
            if token_id in self.active_quotes:
                await self._cancel_all_levels(token_id)
            return

        # v1.0.151: momentum filter — market-state side blocking (the
        # drawdown stop handles position-state; they compose via OR).
        self._apply_momentum_filter(token_id, market_name, decision)
        if not decision.allow_bid and not decision.allow_ask:
            if token_id in self.active_quotes:
                await self._cancel_all_levels(token_id)
            return

        # ── Compute reservation price + optimal spread ──
        inv = self.inventory.get_inventory(token_id)
        max_inv_tokens = self.inventory.max_inventory_usdc() / max(book.mid, 0.01)
        # v1.0.85 (N1): pass real time-to-resolution for full A-S model
        ttr_sec = None
        if info and info.end_date_ts > 0:
            now_ts = datetime.now(timezone.utc).timestamp()
            ttr_sec = max(0.0, info.end_date_ts - now_ts)
        reservation, sigma, inv_penalty = self._as_calc.compute(
            token_id=token_id,
            current_mid=book.mid,
            inventory_tokens=inv.net_tokens,
            max_inventory_tokens=max_inv_tokens,
            time_to_resolution_sec=ttr_sec,
        )

        # Kyle's lambda spread multiplier
        kyle_lambda_val, kyle_mult = self._kyle.update_and_compute(token_id, book)

        # Session-based multiplier
        session_mult, session_name = SpreadOptimizer.get_session_multiplier()

        # Inventory aging discount (for stale positions)
        aging_discount = self._compute_aging_discount(inv)

        # Final spread
        optimal_spread_cents = SpreadOptimizer.compute(
            base_spread_cents=settings.spread_cents,
            sigma=sigma,
            kyle_mult=kyle_mult,
            session_mult=session_mult,
            aging_discount_cents=aging_discount,
        )

        # ── Update Prometheus gauges ──
        RESERVATION_PRICE.labels(token_id=token_id[:12]).set(reservation)
        KYLE_LAMBDA.labels(token_id=token_id[:12]).set(kyle_lambda_val)
        INVENTORY_RATIO.labels(token_id=token_id[:12]).set(
            inv.inventory_ratio(self.inventory.max_inventory_usdc())
        )
        SPREAD_CENTS.labels(token_id=token_id[:12]).set(optimal_spread_cents)

        # ── Check fills on existing quotes ──
        existing = self.active_quotes.get(token_id)
        if existing:
            await self._check_fills(token_id, book, existing, market_name)
            # Cancel stale quotes (mid drifted or too old)
            # v1.0.117: lowered age 10→3s + drift threshold 1.0→0.3¢ (config).
            # Was keeping stale bids 10s → fills at old high prices + adverse drift.
            # User: "чому ордер лишається а не відміняється з рухом ціни?"
            existing = self.active_quotes.get(token_id, [])
            still_active: list[ActiveQuote] = []
            for q in existing:
                age = time.monotonic() - q.placed_at
                drift = abs(book.mid - q.mid_at_place)
                if age > 3 or drift > settings.requote_threshold_cents / 100:
                    await self._cancel_quote_level(token_id, q)
                else:
                    still_active.append(q)
            if still_active:
                self.active_quotes[token_id] = still_active
            else:
                self.active_quotes.pop(token_id, None)

        # ── Place new quotes if none active ──
        if token_id not in self.active_quotes or not self.active_quotes[token_id]:
            # Do not overlap a replacement with a cancel that has only been
            # acknowledged. The old remainder stays authoritative until the
            # normalized lifecycle removes it from pending orders.
            if any(
                pending.get("token_id") == token_id
                for pending in self._pending_orders.values()
            ):
                return
            await self._place_multi_level_quotes(
                token_id=token_id,
                book=book,
                market_name=market_name,
                reservation=reservation,
                spread_cents=optimal_spread_cents,
                decision=decision,
                sigma=sigma,
                kyle_lambda=kyle_lambda_val,
                ttr_hours=ttr_hours,
                kyle_mult=kyle_mult,  # v1.0.120 Task 1: adaptive gap
            )

    async def _submit_immediate_order(
        self,
        token_id: str,
        side: str,
        price: float,
        size_usdc: float,
        market_name: str,
        *,
        level: int = 99,
        mid_at_place: float | None = None,
        exit_path: str = "",
        is_liquidation: bool = True,
        is_hedge: bool = False,
        cycle_id: int = 0,
    ) -> tuple[bool, bool]:
        """Submit a depth-capped FAK and account only confirmed execution.

        Returns ``(accepted_or_uncertain, filled_now)``.  A successful HTTP
        response with ``matched=false`` is accepted but not filled.
        """
        book = self.clob.books.get(token_id)
        original_price = max(price, 0.000001)
        requested_tokens = size_usdc / original_price
        execution_price = price
        if book is not None and side == "SELL" and book.bids:
            execution_price = book.best_bid
            try:
                top_depth = float(book.bids[0].size)
            except (TypeError, ValueError):
                top_depth = 0.0
            if top_depth > 0:
                requested_tokens = min(requested_tokens, top_depth)
        elif book is not None and side == "BUY" and book.asks:
            execution_price = book.best_ask
            try:
                top_depth = float(book.asks[0].size)
            except (TypeError, ValueError):
                top_depth = 0.0
            if top_depth > 0:
                requested_tokens = min(requested_tokens, top_depth)
        execution_price = max(0.01, min(0.99, execution_price))
        execution_size = requested_tokens * execution_price
        if requested_tokens <= 0 or execution_size <= 0:
            return False, False

        result = await self.clob.place_order(
            token_id,
            side,
            execution_price,
            execution_size,
            order_type="FAK",
            post_only=False,
        )
        raw = result.raw if isinstance(result.raw, dict) else {}
        pending_key = result.order_id or (
            f"client:{result.client_order_id}" if result.client_order_id else ""
        )
        uncertain = bool(raw.get("submission_uncertain"))
        if not result.success and not uncertain:
            return False, False
        if not pending_key:
            log.error(
                "immediate_order_untrackable",
                market=market_name[:40],
                side=side,
                reason="accepted/uncertain submission has no order or client id",
            )
            return False, False

        info = {
            "token_id": token_id,
            "side": side,
            "price": execution_price,
            "size_usdc": execution_size,
            "market_name": market_name,
            "level": level,
            "mid_at_place": mid_at_place if mid_at_place is not None else execution_price,
            "placed_at": time.monotonic(),
            "order_type": "FAK",
            "client_order_id": result.client_order_id,
            "accounted_contracts_gross": 0.0,
            "accounted_contracts_net": 0.0,
            "accounted_usd_gross": 0.0,
            "accounted_usd_net": 0.0,
            "accounted_fee_usdc": 0.0,
            "exit_path": exit_path,
            "is_liquidation": is_liquidation,
            "is_hedge": is_hedge,
            "ttl_sec": 10.0,
            "cycle_id": cycle_id,
        }
        self._pending_orders[pending_key] = info

        try:
            immediate_tokens = float(result.filled_tokens)
        except (TypeError, ValueError):
            immediate_tokens = 0.0
        try:
            immediate_usd = float(result.filled_size_usdc)
        except (TypeError, ValueError):
            immediate_usd = 0.0
        filled_now = bool(
            result.fill_confirmed is True
            and immediate_tokens > 0
            and immediate_usd > 0
        )
        if filled_now:
            contracts_gross = float(raw.get("contractsGross") or result.filled_tokens)
            contracts_net = float(raw.get("contractsNet") or contracts_gross)
            usd_gross = float(raw.get("usdGross") or result.filled_size_usdc)
            usd_net = float(raw.get("usdNet") or usd_gross)
            fee_usdc = float(raw.get("feeUsdc") or 0.0)
            fill_price = result.fill_price or execution_price
            await self._record_confirmed_execution(
                token_id=token_id,
                side=side,
                market_name=market_name,
                price=fill_price,
                contracts_gross=contracts_gross,
                contracts_net=contracts_net,
                usd_gross=usd_gross,
                usd_net=usd_net,
                fee_usdc=fee_usdc,
                level=level,
                is_taker=True,
                is_hedge=is_hedge,
                exit_path=exit_path,
                mid_at_fill=mid_at_place,
                fill_verification=("inferred" if settings.paper_trading else "verified"),
                cycle_id=cycle_id,
            )
            info["accounted_contracts_gross"] = contracts_gross
            info["accounted_contracts_net"] = contracts_net
            info["accounted_usd_gross"] = usd_gross
            info["accounted_usd_net"] = usd_net
            info["accounted_fee_usdc"] = fee_usdc
            if is_liquidation:
                self._liquidation_count += 1
                info["counted_exit"] = True
            if exit_path == "PROFIT_SNIPER":
                self._profit_take_count += 1
            if result.terminal:
                self._pending_orders.pop(pending_key, None)
        elif result.terminal:
            # Confirmed zero-fill FAK (UNMATCHED/KILLED).
            self._pending_orders.pop(pending_key, None)

        log.info(
            "immediate_order_submitted",
            market=market_name[:40],
            side=side,
            order_id=pending_key,
            requested_price=round(price, 6),
            execution_price=round(execution_price, 6),
            requested_size_usdc=round(size_usdc, 6),
            execution_size_usdc=round(execution_size, 6),
            fill_confirmed=filled_now,
            settlement=result.settlement_status,
            uncertain=uncertain,
            exit_path=exit_path,
        )
        return True, filled_now

    async def _handle_resolution_exit(
        self, token_id: str, book: MarketBook, market_name: str
    ) -> None:
        """v1.0.71 (BUG-N22): Exit position when market near resolution.

        Triggered by resolution detector: mid < 0.05 or mid > 0.95.
        Sells at max(mid, entry+5¢) capped at ask-0.001 — same A+C logic
        as Exit All (BUG-N16) and liquidations (BUG-N17).

        Difference from _handle_pre_resolution:
        - pre_resolution: time-based (1h before end_date)
        - resolution_exit: price-based (mid near 0 or 1)

        Both protect from holding through resolution (Australia scenario).
        """
        if token_id in self.active_quotes:
            await self._cancel_all_levels(token_id)
        inv = self.inventory.get_inventory(token_id)
        if abs(inv.net_tokens) > 0.5 and inv.net_tokens > 0 and book.best_bid > 0:
            # A+C pricing (same as Exit All / liquidations)
            mid = (book.best_bid + book.best_ask) / 2.0 if book.best_ask > book.best_bid else book.best_bid
            target_mid = round(mid, 4)
            target_min = round(inv.avg_entry_price + 0.05, 4)
            sell_price = max(target_mid, target_min)
            sell_price = max(0.01, min(0.99, sell_price))
            if book.best_ask > 0:
                sell_price = min(sell_price, round(book.best_ask - 0.001, 4))
            size_usdc = abs(inv.net_tokens) * sell_price

            log.warning(
                "resolution_exit_sell",
                market=market_name[:40],
                mid=round(mid, 4),
                sell_price=round(sell_price, 4),
                avg_entry=round(inv.avg_entry_price, 4),
                net_tokens=round(inv.net_tokens, 2),
                size_usdc=round(size_usdc, 2),
                loss_cents=round((inv.avg_entry_price - sell_price) * 100, 2),
            )

            if settings.paper_trading:
                await self._record_fill(
                    token_id, "SELL", sell_price, size_usdc, market_name,
                    is_liquidation=True,
                )
            else:
                await self._submit_immediate_order(
                    token_id,
                    "SELL",
                    sell_price,
                    size_usdc,
                    market_name,
                    mid_at_place=book.mid,
                    exit_path="RESOLUTION_EXIT",
                )

    async def _handle_pre_resolution(
        self, token_id: str, book: MarketBook, market_name: str
    ) -> None:
        """Cancel quotes + liquidate inventory before market resolution.

        v1.0.39 FIX: in LIVE mode this must place a real order. Previously
        _record_fill was called directly (no order sent to Polymarket), so
        the bot decremented inventory/bankroll locally while the real
        position stayed open on-chain through resolution.
        """
        if token_id in self.active_quotes:
            log.warning("pre_resolution_exit", market=market_name[:40], ttr_hours=0)
            await self._cancel_all_levels(token_id)
        inv = self.inventory.get_inventory(token_id)
        if abs(inv.net_tokens) > 0.5:
            if inv.net_tokens > 0 and book.best_bid > 0:
                size_usdc = abs(inv.net_tokens) * book.best_bid
                if settings.paper_trading:
                    await self._record_fill(
                        token_id, "SELL", book.best_bid,
                        size_usdc, market_name, is_liquidation=True,
                    )
                else:
                    # LIVE: place a real FAK sell at best_bid (take what we can).
                    accepted, _ = await self._submit_immediate_order(
                        token_id,
                        "SELL",
                        book.best_bid,
                        size_usdc,
                        market_name,
                        mid_at_place=book.mid,
                        exit_path="PRE_RESOLUTION",
                    )
                    if accepted:
                        log.info(
                            "pre_resolution_liquidation_live",
                            market=market_name[:40],
                            price=round(book.best_bid, 4),
                            size_usdc=round(size_usdc, 2),
                        )
                    else:
                        log.error(
                            "pre_resolution_liquidation_failed_live",
                            market=market_name[:40],
                            reason="position will go to resolution",
                        )
            elif inv.net_tokens < 0 and book.best_ask < 1:
                size_usdc = abs(inv.net_tokens) * book.best_ask
                if settings.paper_trading:
                    await self._record_fill(
                        token_id, "BUY", book.best_ask,
                        size_usdc, market_name, is_liquidation=True,
                    )
                else:
                    accepted, _ = await self._submit_immediate_order(
                        token_id,
                        "BUY",
                        book.best_ask,
                        size_usdc,
                        market_name,
                        mid_at_place=book.mid,
                        exit_path="PRE_RESOLUTION",
                    )
                    if accepted:
                        log.info(
                            "pre_resolution_buyback_live",
                            market=market_name[:40],
                            price=round(book.best_ask, 4),
                            size_usdc=round(size_usdc, 2),
                        )
                    else:
                        log.error(
                            "pre_resolution_buyback_failed_live",
                            market=market_name[:40],
                            reason="short position will go to resolution",
                        )

    def _compute_aging_discount(self, inv) -> float:
        """Discount spread for stale positions to encourage liquidation."""
        if inv.net_tokens == 0 or inv.open_time == 0:
            return 0.0
        age_sec = time.monotonic() - inv.open_time
        if age_sec < settings.inventory_aging_threshold_sec:
            return 0.0
        steps_past = int((age_sec - settings.inventory_aging_threshold_sec) / 60.0)
        discount = steps_past * settings.inventory_aging_discount_step_cents
        return min(discount, settings.inventory_aging_max_discount_cents)

    # ── Multi-level quote placement ───────────────────────────────────────

    async def _place_multi_level_quotes(
        self,
        token_id: str,
        book: MarketBook,
        market_name: str,
        reservation: float,
        spread_cents: float,
        decision,
        sigma: float,
        kyle_lambda: float,
        ttr_hours: float | None = None,
        kyle_mult: float = 1.0,  # v1.0.120 Task 1: for adaptive gap
    ) -> None:
        """Place up to 3 levels of bid/ask quotes around reservation price.

        FIX: exchanges reject live orders below their minimum size. If a
        level's computed size falls below the minimum, we bump it (rather
        than skipping) so the order is accepted. This means total quote size
        can exceed base_size when multi-level is enabled with small base —
        that's expected.

        v1.0.150: the minimum comes from book.min_order_size (Polymarket $5,
        Limitless = LIMITLESS_MIN_ORDER_USDC, default $1) instead of a
        hardcoded Polymarket $5. With a $10 bankroll the $5 bump exceeded
        the $3 portfolio cap and permanently blocked the BUY side.
        """
        # Exchange hard minimum (live orders below this are rejected)
        min_order_usdc = book.min_order_size

        # Auto-scale size with bankroll (capped)
        scaling = min(
            settings.order_size_autoscale_max_mult,
            self.inventory.bankroll / max(self.inventory.starting_balance, 1.0),
        )
        base_size = settings.order_size_usdc * scaling
        base_size = max(
            settings.order_size_min_usdc,
            min(base_size, settings.order_size_usdc * settings.order_size_autoscale_max_mult),
        )

        # v1.0.63 (BUG-N14): Volatility-scaled sizing.
        # Professional MM scales size INVERSELY to σ: high vol → smaller size,
        # low vol → larger size. This prevents accumulation of large positions
        # in volatile markets (e.g. Switzerland Round of 16, -$166 loss).
        # sigma comes from A-S calculator (avellaneda_stoikov.py:_estimate_sigma).
        if settings.order_size_volatility_scaling and sigma > 0:
            ref_vol = settings.order_size_reference_volatility
            eff_sigma = max(sigma, settings.as_min_volatility)
            vol_mult = ref_vol / eff_sigma
            vol_mult = max(
                settings.order_size_min_vol_mult,
                min(vol_mult, settings.order_size_max_vol_mult),
            )
            scaled_size = base_size * vol_mult
            # Don't shrink below Polymarket $5 minimum
            scaled_size = max(scaled_size, settings.order_size_min_usdc)
            if abs(vol_mult - 1.0) > 0.05:
                log.info(
                    "order_size_volatility_scaled",
                    market=market_name[:30],
                    sigma=round(sigma, 4),
                    vol_mult=round(vol_mult, 3),
                    base_size=round(base_size, 2),
                    scaled_size=round(scaled_size, 2),
                )
            base_size = scaled_size

        # Build levels
        levels = SpreadOptimizer.compute_levels(spread_cents)
        new_quotes: list[ActiveQuote] = []

        # Current inventory for logging
        inv = self.inventory.get_inventory(token_id)
        inventory_usdc = round(inv.net_usdc_at_entry, 2)
        inventory_tokens = round(inv.net_tokens, 4)

        # v1.0.43 FIX: track tokens already committed to asks across levels.
        # Previously each level independently checked `inv.net_tokens > 0`
        # and placed an ask. With 3 levels × ~$5 ask each, total ask tokens
        # could exceed actual holdings (e.g. 30.93 tokens to sell when only
        # 23.94 owned). In PAPER this was a warning; in LIVE Polymarket
        # rejects the 2nd/3rd ask. Now we decrement remaining_tokens as we
        # commit each level's ask.
        remaining_tokens = inv.net_tokens

        for level_idx, (capture_cents, size_pct) in enumerate(levels, start=1):
            level_size = base_size * size_pct
            # FIX: enforce the exchange minimum per level
            if level_size < min_order_usdc:
                level_size = min_order_usdc
                log.info(
                    "level_size_bumped_to_minimum",
                    market=market_name[:30],
                    level=level_idx,
                    original_size=round(base_size * size_pct, 2),
                    bumped_to=min_order_usdc,
                    reason=f"exchange minimum order = ${min_order_usdc}",
                )

            # v1.0.144: Single order mode (Claude Section 5).
            # When enabled: place ONLY bid OR ask, not both.
            # - If has inventory → place SELL only (close position)
            # - If flat → place BUY only (open position)
            # This is "Patient Directional Mode", NOT market making.
            if settings.single_order_mode:
                if inv.net_tokens > 0.5:
                    # Has long position → SELL only (close)
                    bid_price = None
                    log.info(
                        "single_order_mode_sell_only",
                        market=market_name[:30],
                        level=level_idx,
                        net_tokens=round(inv.net_tokens, 4),
                        reason="single_order_mode + has position → close only",
                    )
                elif inv.net_tokens < -0.5:
                    # Has short position → BUY only (close)
                    ask_price = None
                    log.info(
                        "single_order_mode_buy_only",
                        market=market_name[:30],
                        level=level_idx,
                        net_tokens=round(inv.net_tokens, 4),
                        reason="single_order_mode + has short → close only",
                    )
                else:
                    # Flat → BUY only (open)
                    ask_price = None
                    log.info(
                        "single_order_mode_buy_open",
                        market=market_name[:30],
                        level=level_idx,
                        reason="single_order_mode + flat → open long only",
                    )

            # ── JOIN-MARKET LOGIC (fixed v1.0.18) ───────────────────────────
            # Bot places quotes INSIDE the market spread, with FIXED gap from
            # each edge. Gap does NOT scale with optimal_spread — it's a fixed
            # distance that creates the user-requested spread pattern.
            #
            # User request: market 0.3200-0.3400 (2¢) → our 0.3215-0.3385 (1.7¢)
            # So Level 1 gap = 0.15¢ → our_spread = 2¢ - 2×0.15¢ = 1.7¢ ✅
            #
            # Levels (fixed gaps, NOT proportional to optimal spread):
            #   Level 1 (tightest): gap = 0.15¢ → our_spread = market - 0.30¢
            #   Level 2 (middle):   gap = 0.30¢ → our_spread = market - 0.60¢
            #   Level 3 (widest):   gap = 0.45¢ → our_spread = market - 0.90¢
            market_bid = book.best_bid
            market_ask = book.best_ask
            market_spread = market_ask - market_bid

            # ═══════════════════════════════════════════════════════════
            # v1.0.148 (Jiji's direct order): HARDCODED SPREAD LOGIC.
            # BUY = best_bid + 15 points, SELL = best_ask - 15 points.
            # Pricing goes EXCLUSIVELY through spread_invariant module.
            # Kyle lambda / A-S / skew / config may control SIZE and SIDE,
            # NEVER the entry PRICE. quote_gap_pct & friends no longer
            # affect pricing — kept in config only for backward compat.
            # ═══════════════════════════════════════════════════════════
            from app.services.spread_invariant import (
                hardcoded_quotes,
                validate_quote,
            )

            hq = hardcoded_quotes(market_bid, market_ask, level=level_idx)
            if hq is None:
                log.debug(
                    "quote_skipped_no_room_hardcoded",
                    market=market_name[:30],
                    level=level_idx,
                    market_bid=round(market_bid, 4),
                    market_ask=round(market_ask, 4),
                    spread_cents=round(market_spread * 100, 2),
                    reason="market spread too tight for hardcoded 15-point rule",
                )
                continue
            target_bid = hq.bid
            target_ask = hq.ask

            # BUG-N48 (v1.0.109): skip markets where our_spread < 1.0¢.
            # User: "РИНКИ ДЕ МЕНШЕ 1С СПРЕД НЕ ГОДЯТЬСЯ -- 0.4 І ТД..."
            # Market spread can shrink between discover and quote placement.
            # AUTO_PICK_MIN_SPREAD_CENTS=2.0 filters at discover time, but
            # market moves. This check catches it at quote time.
            our_quote_spread_cents = (target_ask - target_bid) * 100
            if our_quote_spread_cents < 1.0:
                log.debug(
                    "quote_skipped_our_spread_too_thin",
                    market=market_name[:30],
                    our_spread_cents=round(our_quote_spread_cents, 2),
                    market_bid=round(market_bid, 4),
                    market_ask=round(market_ask, 4),
                    market_spread_cents=round(market_spread * 100, 2),
                    reason="our spread < 1.0¢ — not profitable for MM",
                )
                continue

            # v1.0.148: NO price clamping — clamping would BEND the hardcoded
            # rule. Prices come from hardcoded_quotes() already inside
            # [0.01, 0.99] or the market was skipped. Final invariant gate:
            ok, reason = validate_quote(target_bid, target_ask, market_bid, market_ask)
            if not ok:
                log.warning(
                    "quote_dropped_invariant_violation",
                    market=market_name[:30],
                    level=level_idx,
                    target_bid=round(target_bid, 4),
                    target_ask=round(target_ask, 4),
                    market_bid=round(market_bid, 4),
                    market_ask=round(market_ask, 4),
                    reason=reason,
                )
                continue

            # Inventory-aware side blocking
            bid_price = target_bid if decision.allow_bid else None
            ask_price = target_ask if decision.allow_ask else None

            # CRITICAL: Don't place bid if bankroll can't cover it
            # (simulates Polymarket API rejecting order if insufficient balance)
            if bid_price is not None and self.inventory.bankroll < level_size:
                log.debug(
                    "bid_blocked_insufficient_balance",
                    market=market_name[:30],
                    level=level_idx,
                    level_size=round(level_size, 2),
                    bankroll=round(self.inventory.bankroll, 2),
                )
                # v1.0.120 (Task 2b): track capital starvation
                self._capital_starved_count += 1
                bid_price = None
            # v1.0.123 (Claude audit — portfolio exposure cap):
            # Check global exposure BEFORE placing bid. Even if bankroll covers
            # this order, total inventory across ALL markets must stay under cap.
            if bid_price is not None and not self.inventory.can_open_new_position(level_size):
                exposure_pct = round(self.inventory.portfolio_exposure_pct(), 1)
                log.info(
                    "bid_blocked_portfolio_cap",
                    market=market_name[:30],
                    level=level_idx,
                    level_size=round(level_size, 2),
                    total_exposure=round(self.inventory.total_inventory_usdc(), 2),
                    portfolio_cap=round(self.inventory.portfolio_cap_usdc(), 2),
                    exposure_pct=exposure_pct,
                    reason="portfolio exposure cap reached — not adding new position",
                )
                bid_price = None
            # v1.0.150: DRAWDOWN STOP — never average down into a falling
            # knife. If the position is underwater and mid has dropped more
            # than drawdown_stop_bid_cents below entry, block new BUYs on
            # this market; the ask keeps working (breakeven floor / sniper).
            # State transitions are logged at INFO, repeats at debug.
            if bid_price is not None:
                inv_dd = self.inventory.get_inventory(token_id)
                dd_limit = settings.drawdown_stop_bid_cents / 100.0
                # v1.0.155 FIX: drawdown is measured against the REALISTIC
                # exit (best_bid + tick), not mid. On a torn book a lone
                # high ask inflates mid and puts the stop to sleep while
                # the position is deep underwater vs the only real exit
                # (live case: entry 0.0971, bid 0.049/ask 0.108 → mid-based
                # drawdown 1.86¢ "OK", bid-based 4.7¢ — must block).
                realistic_exit_dd = book.best_bid + 0.001
                if (
                    inv_dd.net_tokens > 0
                    and inv_dd.avg_entry_price > 0
                    and realistic_exit_dd < inv_dd.avg_entry_price - dd_limit
                ):
                    logger_fn = (
                        log.debug if token_id in self._drawdown_stopped else log.info
                    )
                    self._drawdown_stopped.add(token_id)
                    logger_fn(
                        "bid_blocked_drawdown_stop",
                        market=market_name[:30],
                        level=level_idx,
                        avg_entry=round(inv_dd.avg_entry_price, 4),
                        realistic_exit=round(realistic_exit_dd, 4),
                        mid=round(book.mid, 4),
                        drawdown_cents=round(
                            (inv_dd.avg_entry_price - realistic_exit_dd) * 100, 2
                        ),
                        limit_cents=settings.drawdown_stop_bid_cents,
                        net_tokens=round(inv_dd.net_tokens, 2),
                        reason="position underwater beyond limit (bid-based) — no averaging down",
                    )
                    bid_price = None
                elif token_id in self._drawdown_stopped:
                    self._drawdown_stopped.discard(token_id)
                    log.info(
                        "drawdown_stop_released",
                        market=market_name[:30],
                        avg_entry=round(inv_dd.avg_entry_price, 4),
                        realistic_exit=round(realistic_exit_dd, 4),
                        reason="price recovered or position closed — BUYs re-enabled",
                    )

            # CRITICAL: Don't place ask if not enough tokens to sell
            # In LIVE: Polymarket API rejects SELL if insufficient token balance
            # (no traditional shorting on CTF — can only sell what you own)
            # v1.0.43: use remaining_tokens (decremented across levels) instead
            # of inv.net_tokens, so we don't commit to sell more than we own.
            #
            # BUG-N47 (v1.0.107): PAPER mode — allow ask even when flat (no tokens).
            # MM bot needs two-sided quoting (bid+ask) for round_trips. If ask is
            # blocked when flat, bot only buys, never sells → 0 round_trips.
            # PAPER simulates, so allow ask. When ask fills in PAPER, inventory
            # goes negative (BUG-N41 clamp prevents this — sells only what we have).
            # In PAPER: ask placed, if filled when flat → clamp to 0 (no short).
            # In LIVE: keep original check (API rejects SELL exceeding balance).
            inv = self.inventory.get_inventory(token_id)
            # tokens this level would sell at current ask price
            tokens_needed_for_this_level = level_size / max(ask_price or 0.01, 0.01)
            if ask_price is not None and remaining_tokens <= 0 and not settings.paper_trading:
                # LIVE only: No tokens to sell — block ask (API would reject)
                log.debug(
                    "ask_blocked_no_tokens_live",
                    market=market_name[:30],
                    level=level_idx,
                    net_tokens=round(inv.net_tokens, 4),
                    remaining_tokens=round(remaining_tokens, 4),
                    reason="LIVE: no tokens to sell (API would reject)",
                )
                ask_price = None
            elif ask_price is not None and remaining_tokens < tokens_needed_for_this_level and not settings.paper_trading:
                # LIVE only: Not enough tokens to cover this level's full ask size.
                # Two options: (a) skip this level, (b) reduce size to remaining.
                # We choose (b) — sell what we have, but only if >= the exchange
                # minimum. Otherwise skip (LIVE API rejects orders below it).
                reduced_size = remaining_tokens * (ask_price or 0.01)
                if reduced_size >= min_order_usdc:
                    log.info(
                        "ask_size_reduced_to_remaining_tokens",
                        market=market_name[:30],
                        level=level_idx,
                        original_size_usdc=round(level_size, 2),
                        reduced_size_usdc=round(reduced_size, 2),
                        remaining_tokens=round(remaining_tokens, 4),
                        reason="would exceed available tokens; reduced to remaining",
                    )
                    level_size = reduced_size
                    # Don't decrement remaining_tokens here — will do after place
                else:
                    log.debug(
                        "ask_skipped_insufficient_tokens_live",
                        market=market_name[:30],
                        level=level_idx,
                        remaining_tokens=round(remaining_tokens, 4),
                        tokens_needed=round(tokens_needed_for_this_level, 4),
                        reduced_size_usdc=round(reduced_size, 2),
                        reason="LIVE: remaining tokens below exchange minimum",
                    )
                    ask_price = None

            # v1.0.38: Aggressive ask pricing for aged positions.
            # Previously: bot blocked ALL sells below entry (v1.0.26), then
            # only "allowed" them after aging — but the ask price was still
            # computed from market spread join logic (near market ask), so
            # it never actually filled when price had dropped.
            #
            # NOW: when position is aged, actively LOWER the ask to be near
            # the market bid, ensuring it actually fills and clears inventory.
            if ask_price is not None and inv.net_tokens > 0:
                age_sec = time.monotonic() - inv.open_time if inv.open_time else 0
                is_aged = age_sec > settings.inventory_aging_threshold_sec
                is_very_aged = age_sec >= settings.inventory_liquidation_aggressive_age_sec
                is_urgent_age = age_sec >= settings.inventory_liquidation_urgent_age_sec
                # v1.0.150: loss-realizing asks allowed ONLY pre-resolution or
                # after the daily stop-loss (supersedes BUG-N43's blanket
                # "URGENT may sell at loss"). Maker fee is zero on Limitless,
                # so the breakeven floor for a resting ask is avg_entry.
                loss_ok, loss_why = self._loss_exit_allowed(token_id)

                if is_very_aged and book.best_bid > 0:
                    # Very aged: sell at market_bid + 0.001 (front of queue)
                    aggressive_ask = min(
                        book.best_bid + 0.001,
                        book.best_ask - 0.001,
                    )
                    aggressive_ask = max(0.01, min(0.99, aggressive_ask))
                    if aggressive_ask < inv.avg_entry_price and not (is_urgent_age and loss_ok):
                        aggressive_ask = round(inv.avg_entry_price + 0.001, 4)
                        log.info(
                            "ask_lowering_clamped_to_entry",
                            market=market_name[:30],
                            level=level_idx,
                            age_sec=round(age_sec, 0),
                            avg_entry=round(inv.avg_entry_price, 4),
                            clamped_ask=round(aggressive_ask, 4),
                            reason="v1.0.150: no loss exits outside pre-resolution/daily-stop",
                        )
                    if aggressive_ask < ask_price:
                        log.info(
                            "ask_aggressive_very_aged",
                            market=market_name[:30],
                            level=level_idx,
                            old_ask=round(ask_price, 4),
                            new_ask=round(aggressive_ask, 4),
                            market_bid=round(book.best_bid, 4),
                            age_sec=round(age_sec, 0),
                            reason="position very aged, lowering ask to market bid",
                        )
                        ask_price = aggressive_ask
                elif is_aged and book.best_bid > 0:
                    # Aged: lower ask toward market bid (but not below entry
                    # unless necessary). This encourages fills.
                    target_aggressive = book.best_bid + (book.spread * 0.25)
                    # v1.0.150: breakeven floor unless loss exits are allowed
                    if target_aggressive < inv.avg_entry_price and not (is_urgent_age and loss_ok):
                        target_aggressive = round(inv.avg_entry_price + 0.001, 4)
                    if target_aggressive < ask_price:
                        ask_price = target_aggressive
                        log.debug(
                            "ask_lowered_aged",
                            market=market_name[:30],
                            level=level_idx,
                            new_ask=round(ask_price, 4),
                            age_sec=round(age_sec, 0),
                        )

                # BUG-N42 (restored v1.0.106): prevent CROSSED quotes.
                # If ask would cross bid → RESTORE ask to bid+0.005 (not block).
                # Blocking ask (v1.0.98) left bot with NO ask → 0 round_trips.
                if (
                    ask_price is not None
                    and bid_price is not None
                    and ask_price <= bid_price
                ):
                    restored_ask = round(bid_price + 0.005, 4)
                    if book.best_ask < 1:
                        restored_ask = min(restored_ask, round(book.best_ask - 0.001, 4))
                    if restored_ask > bid_price:
                        log.info(
                            "ask_restored_above_bid",
                            market=market_name[:30],
                            level=level_idx,
                            bid_price=round(bid_price, 4),
                            original_ask=round(ask_price, 4),
                            restored_ask=round(restored_ask, 4),
                            reason="crossed quote avoided: ask restored above bid",
                        )
                        ask_price = restored_ask
                    else:
                        log.warning(
                            "ask_blocked_crossed_quote",
                            market=market_name[:30],
                            level=level_idx,
                            bid_price=round(bid_price, 4),
                            ask_price=round(ask_price, 4),
                            reason="cannot restore ask above bid (market too tight)",
                        )
                        ask_price = None

                # v1.0.150 final gate: an ask below the breakeven floor is
                # never allowed to rest on the book (it WILL fill at a loss),
                # regardless of age — except pre-resolution / daily stop-loss.
                # Instead of dropping the ask entirely, LIFT it to the floor:
                # the exit stays parked at breakeven ("стоїмо і чекаємо") and
                # fills only when the market recovers. PROFIT_SNIPER handles
                # the fast path when the bid comes back above entry.
                if ask_price is not None and ask_price < inv.avg_entry_price:
                    if is_urgent_age and loss_ok:
                        log.warning(
                            "loss_liquidation_forced",
                            market=market_name[:30],
                            level=level_idx,
                            ask_price=round(ask_price, 4),
                            avg_entry=round(inv.avg_entry_price, 4),
                            age_sec=round(age_sec, 0),
                            loss_cents=round((inv.avg_entry_price - ask_price) * 100, 2),
                            reason=f"maker ask below entry allowed: {loss_why}",
                        )
                    else:
                        lifted = round(inv.avg_entry_price + 0.001, 4)
                        if lifted <= 0.99:
                            # debug: fires every cycle for every underwater
                            # position (26k INFO rows/night at INFO level)
                            log.debug(
                                "ask_lifted_to_breakeven_floor",
                                market=market_name[:30],
                                level=level_idx,
                                original_ask=round(ask_price, 4),
                                lifted_ask=lifted,
                                avg_entry=round(inv.avg_entry_price, 4),
                                age_sec=round(age_sec, 0),
                                reason="v1.0.150: park exit at breakeven, wait for recovery",
                            )
                            ask_price = lifted
                        else:
                            ask_price = None  # entry too close to 1.0 — no room

            # v1.0.43: decrement remaining_tokens by the tokens this ask commits.
            # v1.0.150 FIX: the commit now happens AFTER the aggressive-aging
            # reprice above. Previously it used the pre-reprice ask: size was
            # computed at e.g. 0.5185, the reprice then lowered the ask to
            # 0.481, and size/price committed MORE tokens than owned (10.78 vs
            # 10) — LIVE API rejects such a SELL. In LIVE, clamp the size at
            # the FINAL price so committed tokens never exceed what remains.
            if ask_price is not None:
                tokens_committed = level_size / max(ask_price, 0.01)
                if not settings.paper_trading and tokens_committed > remaining_tokens:
                    clamped_size = remaining_tokens * ask_price
                    if clamped_size >= min_order_usdc:
                        log.info(
                            "ask_size_clamped_to_remaining_after_reprice",
                            market=market_name[:30],
                            level=level_idx,
                            original_size_usdc=round(level_size, 2),
                            clamped_size_usdc=round(clamped_size, 2),
                            ask_price=round(ask_price, 4),
                            remaining_tokens=round(remaining_tokens, 4),
                        )
                        level_size = clamped_size
                        tokens_committed = remaining_tokens
                    else:
                        log.debug(
                            "ask_skipped_insufficient_tokens_after_reprice",
                            market=market_name[:30],
                            level=level_idx,
                            remaining_tokens=round(remaining_tokens, 4),
                            reason="LIVE: remaining tokens below exchange minimum",
                        )
                        ask_price = None
                if ask_price is not None:
                    remaining_tokens -= tokens_committed

            if bid_price is None and ask_price is None:
                continue

            # Place the quote
            quote = await self._place_quote_level(
                token_id=token_id,
                level=level_idx,
                bid_price=bid_price,
                ask_price=ask_price,
                size_usdc=level_size,
                mid=book.mid,
                reservation=reservation,
                spread_cents=spread_cents,
                market_name=market_name,
                book=book,
                inventory_usdc=inventory_usdc,
                inventory_tokens=inventory_tokens,
                ttr_hours=ttr_hours,
            )
            if quote:
                new_quotes.append(quote)

        if new_quotes:
            self.active_quotes[token_id] = new_quotes
            # v1.0.154: first clean quoting cycle after a dirty restart —
            # drop the "⚡ Відновлення після збою" badge.
            self._clear_crash_recovery_on_clean_quote()

    async def _place_quote_level(
        self,
        token_id: str,
        level: int,
        bid_price: float | None,
        ask_price: float | None,
        size_usdc: float,
        mid: float,
        reservation: float,
        spread_cents: float,
        market_name: str,
        book: MarketBook | None = None,
        inventory_usdc: float = 0.0,
        inventory_tokens: float = 0.0,
        ttr_hours: float | None = None,
    ) -> ActiveQuote | None:
        """Place bid and/or ask for a single level. PAPER=simulate, LIVE=real."""
        if bid_price is None and ask_price is None:
            return None

        bid_order_id = None
        ask_order_id = None

        if not settings.paper_trading:
            # LIVE: place real orders + register them for fill polling.
            # v1.0.39 FIX: previously the order_id returned by place_order was
            # stored ONLY in ActiveQuote.bid/ask_order_id and never added to
            # _pending_orders. As a result _poll_orders() returned early at
            # `if not self._pending_orders: return` and LIVE fills were never
            # detected — bankroll/inventory diverged from reality on the very
            # first fill. We now populate _pending_orders so _poll_orders_loop
            # can detect fills via get_orders / get_order.
            now_mono_place = time.monotonic()
            if bid_price is not None:
                result: OrderResult = await self.clob.place_order(
                    token_id, "BUY", bid_price, size_usdc, post_only=True
                )
                result_raw = result.raw if isinstance(result.raw, dict) else {}
                bid_key = result.order_id or (
                    f"client:{result.client_order_id}"
                    if result.client_order_id
                    else ""
                )
                bid_uncertain = bool(result_raw.get("submission_uncertain"))
                if (result.success or bid_uncertain) and bid_key:
                    bid_order_id = bid_key
                    self._pending_orders[bid_order_id] = {
                        "token_id": token_id,
                        "side": "BUY",
                        "price": bid_price,
                        "size_usdc": size_usdc,
                        "market_name": market_name,
                        "level": level,
                        "mid_at_place": mid,
                        "placed_at": now_mono_place,
                        "order_type": "GTC",
                        "client_order_id": result.client_order_id,
                        "accounted_contracts_gross": 0.0,
                        "accounted_contracts_net": 0.0,
                        "accounted_usd_gross": 0.0,
                        "accounted_usd_net": 0.0,
                        "accounted_fee_usdc": 0.0,
                        "submission_uncertain": bid_uncertain,
                    }
                else:
                    log.warning(
                        "live_bid_failed",
                        market=market_name[:30],
                        level=level,
                        error=result.error or "no order_id returned",
                    )
                    bid_price = None  # don't track failed order

            if ask_price is not None:
                result = await self.clob.place_order(
                    token_id, "SELL", ask_price, size_usdc, post_only=True
                )
                result_raw = result.raw if isinstance(result.raw, dict) else {}
                ask_key = result.order_id or (
                    f"client:{result.client_order_id}"
                    if result.client_order_id
                    else ""
                )
                ask_uncertain = bool(result_raw.get("submission_uncertain"))
                if (result.success or ask_uncertain) and ask_key:
                    ask_order_id = ask_key
                    self._pending_orders[ask_order_id] = {
                        "token_id": token_id,
                        "side": "SELL",
                        "price": ask_price,
                        "size_usdc": size_usdc,
                        "market_name": market_name,
                        "level": level,
                        "mid_at_place": mid,
                        "placed_at": now_mono_place,
                        "order_type": "GTC",
                        "client_order_id": result.client_order_id,
                        "accounted_contracts_gross": 0.0,
                        "accounted_contracts_net": 0.0,
                        "accounted_usd_gross": 0.0,
                        "accounted_usd_net": 0.0,
                        "accounted_fee_usdc": 0.0,
                        "submission_uncertain": ask_uncertain,
                    }
                else:
                    log.warning(
                        "live_ask_failed",
                        market=market_name[:30],
                        level=level,
                        error=result.error or "no order_id returned",
                    )
                    ask_price = None

            if bid_price is None and ask_price is None:
                return None

        quote = ActiveQuote(
            token_id=token_id,
            level=level,
            bid_price=bid_price,
            ask_price=ask_price,
            mid_at_place=mid,
            size_usdc=size_usdc,
            reservation_price=reservation,
            spread_cents=spread_cents,
            bid_order_id=bid_order_id,
            ask_order_id=ask_order_id,
            book_update_at_place=book.last_update,
            last_price_at_place=book.last_price,
            public_trade_seq_at_place=int(
                getattr(self.clob, "public_trade_seq", 0) or 0
            ),
        )
        price_eps = max(book.tick_size, 0.0001) / 2
        if bid_price is not None:
            visible = sum(
                level.size for level in book.bids
                if abs(level.price - bid_price) <= price_eps
            )
            quote.bid_queue_ahead_tokens = visible
            quote.bid_last_visible_tokens = visible
        if ask_price is not None:
            visible = sum(
                level.size for level in book.asks
                if abs(level.price - ask_price) <= price_eps
            )
            quote.ask_queue_ahead_tokens = visible
            quote.ask_last_visible_tokens = visible

        # Compute our actual spread (after clamps) for logging
        our_bid = bid_price if bid_price is not None else None
        our_ask = ask_price if ask_price is not None else None
        our_spread_cents = (
            round((our_ask - our_bid) * 100, 2)
            if (our_bid is not None and our_ask is not None)
            else None
        )

        # Market context (from book, if available)
        market_bid_log = round(book.best_bid, 4) if book and book.best_bid > 0 else None
        market_ask_log = round(book.best_ask, 4) if book and book.best_ask < 1 else None
        market_spread_log = round(book.spread * 100, 2) if book else None

        log.info(
            "quote_placed",
            market=market_name[:30],
            level=level,
            # Market context (what the order book shows)
            market_bid=market_bid_log,
            market_ask=market_ask_log,
            market_spread_cents=market_spread_log,
            # Our quote (inside the market spread)
            our_bid=round(our_bid, 4) if our_bid is not None else None,
            our_ask=round(our_ask, 4) if our_ask is not None else None,
            our_spread_cents=our_spread_cents,
            # Strategy context
            mid=round(mid, 4),
            reservation=round(reservation, 4),
            optimal_spread_cents=round(spread_cents, 2),
            size_usdc=round(size_usdc, 2),
            # Inventory state (per user request)
            inventory_usdc=round(inventory_usdc, 2),
            inventory_tokens=round(inventory_tokens, 4),
            # Time to resolution (per user request — "ttr hours")
            ttr_hours=ttr_hours,
            mode="LIVE" if not settings.paper_trading else "PAPER",
        )
        return quote

    # ── Cancel ────────────────────────────────────────────────────────────

    async def _cancel_all_levels(self, token_id: str, force: bool = False) -> None:
        """Cancel all quote levels for a market.

        v1.0.144: respects partial_fill_no_cancel setting (Claude Section 3 Solution B).
        When partial_fill_no_cancel=true and force=false:
          - Quotes with NO fill → cancel (safe, no dust created)
          - Quotes with ANY fill → DON'T cancel (would create dust)
        When force=true: always cancel (used for shutdown, market drop, etc.)
        """
        quotes = self.active_quotes.pop(token_id, [])
        for q in quotes:
            if not force and settings.partial_fill_no_cancel:
                # Check if this quote has any fill
                if self._quote_has_partial_fill(q):
                    log.info(
                        "cancel_skipped_partial_fill",
                        token=token_id[:12],
                        level=q.level,
                        reason="partial_fill_no_cancel=true — cancelling would create dust",
                    )
                    # Put the quote back (don't cancel it)
                    self.active_quotes.setdefault(token_id, []).append(q)
                    continue
            await self._cancel_quote_level(token_id, q)

    def _quote_has_partial_fill(self, quote: ActiveQuote) -> bool:
        """Check if a quote has any partial fill.
        v1.0.144: used by never-cancel logic.
        """
        # bid_filled / ask_filled flags track if any fill occurred
        if quote.bid_filled or quote.ask_filled:
            return True
        return False

    async def _cancel_quote_level(self, token_id: str, quote: ActiveQuote) -> None:
        if not settings.paper_trading:
            if quote.bid_order_id:
                if await self.clob.cancel_order(quote.bid_order_id):
                    pending = self._pending_orders.get(quote.bid_order_id)
                    if pending is not None:
                        pending["cancel_requested_at"] = time.monotonic()
            if quote.ask_order_id:
                if await self.clob.cancel_order(quote.ask_order_id):
                    pending = self._pending_orders.get(quote.ask_order_id)
                    if pending is not None:
                        pending["cancel_requested_at"] = time.monotonic()

    # ── Fill checking ─────────────────────────────────────────────────────

    async def cancel_all_live_orders_and_wait(
        self, *, timeout_sec: float = 20.0
    ) -> bool:
        """Cancel every LIVE order and require verified terminal absence.

        A successful cancel response is only an acknowledgement. This method
        keeps the normalized fill poller alive so late confirmed fills are
        accounted, and returns ``True`` only after both the local pending set
        and a verified exchange open-order snapshot are empty.
        """
        self._trading_paused = True
        if settings.paper_trading:
            for tid in list(self.active_quotes.keys()):
                await self._cancel_all_levels(tid, force=True)
            return True

        for tid in list(self.active_quotes.keys()):
            await self._cancel_all_levels(tid, force=True)
        try:
            await self.clob.cancel_all()
        except Exception as exc:
            log.warning("cancel_all_request_failed", error=str(exc))

        deadline = time.monotonic() + max(0.1, timeout_sec)
        last_retry = 0.0
        last_open_count: int | None = None
        snapshot_verified = False
        while time.monotonic() < deadline:
            if self._pending_orders:
                await self._poll_orders_normalized()

            rows: list[dict] = []
            snapshot_verified = False
            snapshot_fn = getattr(self.clob, "get_open_orders_snapshot", None)
            if callable(snapshot_fn):
                try:
                    snapshot = await snapshot_fn()
                    if (
                        isinstance(snapshot, tuple)
                        and len(snapshot) == 2
                        and isinstance(snapshot[0], list)
                    ):
                        rows = snapshot[0]
                        snapshot_verified = snapshot[1] is True
                except Exception as exc:
                    log.warning("open_order_snapshot_failed", error=str(exc))

            last_open_count = len(rows) if snapshot_verified else None
            if snapshot_verified and not rows and not self._pending_orders:
                log.info("all_live_orders_terminal_confirmed")
                return True

            now_mono = time.monotonic()
            if now_mono - last_retry >= 1.0:
                # Retry both tracked orders and verified exchange-side strays.
                cancel_ids = set(self._pending_orders.keys())
                if snapshot_verified:
                    for row in rows:
                        if not isinstance(row, dict):
                            continue
                        nested = row.get("order")
                        if not isinstance(nested, dict):
                            nested = {}
                        order_id = str(
                            row.get("id")
                            or row.get("orderId")
                            or row.get("order_id")
                            or nested.get("id")
                            or ""
                        )
                        if order_id:
                            cancel_ids.add(order_id)
                for order_id in cancel_ids:
                    try:
                        if await self.clob.cancel_order(order_id):
                            pending = self._pending_orders.get(order_id)
                            if pending is not None:
                                pending["cancel_requested_at"] = now_mono
                    except Exception as exc:
                        log.warning(
                            "terminal_cancel_retry_failed",
                            order_id=order_id[:16],
                            error=str(exc),
                        )
                last_retry = now_mono
            await asyncio.sleep(0.25)

        log.critical(
            "live_orders_terminal_confirmation_timeout",
            pending_orders=len(self._pending_orders),
            open_orders=last_open_count,
            snapshot_verified=snapshot_verified,
        )
        return False

    async def _check_fills(
        self,
        token_id: str,
        book: MarketBook,
        quotes: list[ActiveQuote],
        market_name: str,
    ) -> None:
        """Check for fills on existing quotes. PAPER=simulate, LIVE=poll."""
        if settings.paper_trading:
            await self._check_fills_paper(token_id, book, quotes, market_name)
        # LIVE mode: fills are detected in _poll_orders_loop

    async def _check_fills_paper_conservative(
        self,
        token_id: str,
        book: MarketBook,
        quotes: list[ActiveQuote],
        market_name: str,
    ) -> None:
        """Queue-aware PAPER inference from real public trade volume.

        Limitless ``NEW_TRADE`` feed events are preferred because a book
        reduction alone cannot distinguish a fill from a cancellation.  The
        legacy book-price-through branch remains only for adapters which do
        not expose a public trade feed.
        """
        if hasattr(type(self.clob), "public_trades_since"):
            await self._check_fills_from_public_trades(
                token_id, book, quotes, market_name
            )
            return
        for quote in quotes:
            if book.last_update <= quote.book_update_at_place + 1e-9:
                continue
            eps = max(book.tick_size, 0.0001) / 2

            if not quote.bid_filled and quote.bid_price:
                current_visible = sum(
                    level.size for level in book.bids
                    if abs(level.price - quote.bid_price) <= eps
                )
                depletion = max(0.0, quote.bid_last_visible_tokens - current_visible)
                quote.bid_inferred_through_tokens += depletion
                quote.bid_last_visible_tokens = current_visible
                crossed_tokens = sum(
                    level.size for level in book.asks if level.price <= quote.bid_price
                )
                if crossed_tokens > 0:
                    quote.bid_inferred_through_tokens = max(
                        quote.bid_inferred_through_tokens,
                        quote.bid_queue_ahead_tokens + crossed_tokens,
                    )
                available = max(
                    0.0,
                    quote.bid_inferred_through_tokens - quote.bid_queue_ahead_tokens,
                )
                inferred = available > 0 and crossed_tokens > 0
                await self._record_paper_opportunity(
                    quote, book, "BUY", inferred,
                    quote.bid_queue_ahead_tokens,
                    quote.bid_inferred_through_tokens,
                )
                fill_tokens = min(quote.size_usdc / quote.bid_price, available)
                fill_size = fill_tokens * quote.bid_price
                if inferred and fill_size > 0 and self.inventory.bankroll >= fill_size:
                    await self._record_fill(
                        token_id, "BUY", quote.bid_price, fill_size, market_name,
                        level=quote.level, mid_at_fill=quote.mid_at_place,
                        _skip_hedge=quote.strategy == "fast_flat",
                        exit_path=("FAST_FLAT_ENTRY" if quote.strategy == "fast_flat" else "quote_bid"),
                        fill_verification="inferred", cycle_id=quote.cycle_id,
                        queue_ahead_tokens=quote.bid_queue_ahead_tokens,
                        inferred_through_tokens=quote.bid_inferred_through_tokens,
                        fill_evidence_source="book_price_through_after_queue",
                    )
                    quote.bid_filled = True
                    quote.bid_fill_pct = min(1.0, fill_size / quote.size_usdc)

            inv = self.inventory.get_inventory(token_id)
            if not quote.ask_filled and quote.ask_price and inv.net_tokens > 0:
                current_visible = sum(
                    level.size for level in book.asks
                    if abs(level.price - quote.ask_price) <= eps
                )
                depletion = max(0.0, quote.ask_last_visible_tokens - current_visible)
                quote.ask_inferred_through_tokens += depletion
                quote.ask_last_visible_tokens = current_visible
                crossed_tokens = sum(
                    level.size for level in book.bids if level.price >= quote.ask_price
                )
                if crossed_tokens > 0:
                    quote.ask_inferred_through_tokens = max(
                        quote.ask_inferred_through_tokens,
                        quote.ask_queue_ahead_tokens + crossed_tokens,
                    )
                available = max(
                    0.0,
                    quote.ask_inferred_through_tokens - quote.ask_queue_ahead_tokens,
                )
                inferred = available > 0 and crossed_tokens > 0
                await self._record_paper_opportunity(
                    quote, book, "SELL", inferred,
                    quote.ask_queue_ahead_tokens,
                    quote.ask_inferred_through_tokens,
                )
                fill_tokens = min(quote.size_usdc / quote.ask_price, available, inv.net_tokens)
                fill_size = fill_tokens * quote.ask_price
                if inferred and fill_size > 0:
                    await self._record_fill(
                        token_id, "SELL", quote.ask_price, fill_size, market_name,
                        level=quote.level, mid_at_fill=quote.mid_at_place,
                        _skip_hedge=quote.strategy == "fast_flat",
                        exit_path=("FAST_FLAT_MAKER_EXIT" if quote.strategy == "fast_flat" else "ask_fill"),
                        fill_verification="inferred", cycle_id=quote.cycle_id,
                        queue_ahead_tokens=quote.ask_queue_ahead_tokens,
                        inferred_through_tokens=quote.ask_inferred_through_tokens,
                        fill_evidence_source="book_price_through_after_queue",
                    )
                    quote.ask_filled = True
                    quote.ask_fill_pct = min(1.0, fill_size / quote.size_usdc)

            if quote.bid_filled and quote.ask_filled:
                log.info(
                    "round_trip",
                    market=market_name[:40], level=quote.level,
                    buy=round(quote.bid_price or 0, 4),
                    sell=round(quote.ask_price or 0, 4),
                    fill_verification="inferred",
                )

    async def _check_fills_from_public_trades(
        self,
        token_id: str,
        book: MarketBook,
        quotes: list[ActiveQuote],
        market_name: str,
    ) -> None:
        """Apply each confirmed trade once using price/time priority.

        One market trade must not be copied into all ladder levels.  Volume is
        allocated to eligible synthetic quotes in exchange priority order,
        first consuming the visible queue captured when each quote was placed.
        """
        if not quotes:
            return
        initial_cursor = min(q.public_trade_seq_at_place for q in quotes)
        cursor = self._paper_public_trade_cursor.get(token_id, initial_cursor)
        placed_floor = min(q.placed_wall_time for q in quotes)
        trades = self.clob.public_trades_since(
            token_id, cursor, placed_wall_time=placed_floor
        )
        if not trades:
            return

        eps = max(book.tick_size, 0.0001) / 2
        for trade in trades:
            self._paper_public_trade_cursor[token_id] = max(
                self._paper_public_trade_cursor.get(token_id, cursor), trade.seq
            )
            remaining = trade.contracts
            if trade.side == "SELL":
                eligible = sorted(
                    (
                        q for q in quotes
                        if not q.bid_filled and q.bid_price
                        and q.placed_wall_time <= trade.traded_at
                        and q.bid_price + eps >= trade.price
                    ),
                    key=lambda q: (-float(q.bid_price or 0), q.placed_at, q.level),
                )
                for quote in eligible:
                    if remaining <= 0:
                        break
                    queue_left = max(
                        0.0,
                        quote.bid_queue_ahead_tokens
                        - quote.bid_inferred_through_tokens,
                    )
                    consumed_queue = min(remaining, queue_left)
                    quote.bid_inferred_through_tokens += consumed_queue
                    remaining -= consumed_queue
                    if remaining <= 0:
                        await self._record_paper_opportunity(
                            quote, book, "BUY", False,
                            quote.bid_queue_ahead_tokens,
                            quote.bid_inferred_through_tokens,
                        )
                        continue
                    fill_tokens = min(
                        remaining, quote.size_usdc / float(quote.bid_price)
                    )
                    fill_size = fill_tokens * float(quote.bid_price)
                    if fill_size <= 0 or self.inventory.bankroll < fill_size:
                        continue
                    quote.bid_inferred_through_tokens += fill_tokens
                    remaining -= fill_tokens
                    await self._record_paper_opportunity(
                        quote, book, "BUY", True,
                        quote.bid_queue_ahead_tokens,
                        quote.bid_inferred_through_tokens,
                    )
                    await self._record_fill(
                        token_id, "BUY", float(quote.bid_price), fill_size,
                        market_name, level=quote.level,
                        mid_at_fill=quote.mid_at_place,
                        _skip_hedge=quote.strategy == "fast_flat",
                        exit_path=("FAST_FLAT_ENTRY" if quote.strategy == "fast_flat" else "quote_bid"),
                        fill_verification="inferred", cycle_id=quote.cycle_id,
                        queue_ahead_tokens=quote.bid_queue_ahead_tokens,
                        inferred_through_tokens=quote.bid_inferred_through_tokens,
                        fill_evidence_source="limitless_new_trade_after_queue",
                    )
                    quote.bid_filled = True
                    quote.bid_fill_pct = min(1.0, fill_size / quote.size_usdc)
            elif trade.side == "BUY":
                eligible = sorted(
                    (
                        q for q in quotes
                        if not q.ask_filled and q.ask_price
                        and q.placed_wall_time <= trade.traded_at
                        and q.ask_price - eps <= trade.price
                    ),
                    key=lambda q: (float(q.ask_price or 1), q.placed_at, q.level),
                )
                for quote in eligible:
                    if remaining <= 0:
                        break
                    inv = self.inventory.get_inventory(token_id)
                    if inv.net_tokens <= 0:
                        break
                    queue_left = max(
                        0.0,
                        quote.ask_queue_ahead_tokens
                        - quote.ask_inferred_through_tokens,
                    )
                    consumed_queue = min(remaining, queue_left)
                    quote.ask_inferred_through_tokens += consumed_queue
                    remaining -= consumed_queue
                    if remaining <= 0:
                        await self._record_paper_opportunity(
                            quote, book, "SELL", False,
                            quote.ask_queue_ahead_tokens,
                            quote.ask_inferred_through_tokens,
                        )
                        continue
                    fill_tokens = min(
                        remaining,
                        quote.size_usdc / float(quote.ask_price),
                        inv.net_tokens,
                    )
                    fill_size = fill_tokens * float(quote.ask_price)
                    if fill_size <= 0:
                        continue
                    quote.ask_inferred_through_tokens += fill_tokens
                    remaining -= fill_tokens
                    await self._record_paper_opportunity(
                        quote, book, "SELL", True,
                        quote.ask_queue_ahead_tokens,
                        quote.ask_inferred_through_tokens,
                    )
                    await self._record_fill(
                        token_id, "SELL", float(quote.ask_price), fill_size,
                        market_name, level=quote.level,
                        mid_at_fill=quote.mid_at_place,
                        _skip_hedge=quote.strategy == "fast_flat",
                        exit_path=("FAST_FLAT_MAKER_EXIT" if quote.strategy == "fast_flat" else "ask_fill"),
                        fill_verification="inferred", cycle_id=quote.cycle_id,
                        queue_ahead_tokens=quote.ask_queue_ahead_tokens,
                        inferred_through_tokens=quote.ask_inferred_through_tokens,
                        fill_evidence_source="limitless_new_trade_after_queue",
                    )
                    quote.ask_filled = True
                    quote.ask_fill_pct = min(1.0, fill_size / quote.size_usdc)

    async def _record_paper_opportunity(
        self,
        quote: ActiveQuote,
        book: MarketBook,
        side: str,
        inferred_candidate: bool,
        queue_ahead_tokens: float,
        inferred_through_tokens: float,
    ) -> None:
        """Persist one observation per side/book update for replay auditing."""
        attr = (
            "bid_last_opportunity_update" if side == "BUY"
            else "ask_last_opportunity_update"
        )
        if book.last_update <= getattr(quote, attr) + 1e-9:
            return
        setattr(quote, attr, book.last_update)

        price = quote.bid_price if side == "BUY" else quote.ask_price
        if not price:
            return
        distance = abs(
            price - (book.best_bid if side == "BUY" else book.best_ask)
        )
        closeness = max(0.0, 1.0 - distance / 0.015)
        legacy_probability = (
            (1.0 - settings.paper_rejection_rate)
            * (1.0 - settings.paper_competition_rate)
            * min(
                settings.paper_fill_prob_max,
                max(0.005, settings.paper_fill_prob_base * closeness),
            )
            * 0.8
        )
        seed = (
            f"{quote.token_id}:{quote.cycle_id}:{quote.level}:{side}:"
            f"{book.last_update:.6f}:{price:.6f}"
        )
        random_candidate = random.Random(seed).random() < legacy_probability
        self._paper_opportunity_count += 1
        self._paper_inferred_candidate_count += int(inferred_candidate)
        self._paper_random_candidate_count += int(random_candidate)

        try:
            from app.core.db import AsyncSessionLocal
            async with AsyncSessionLocal() as db:
                db.add(PaperFillOpportunity(
                    market_id=quote.token_id,
                    cycle_id=quote.cycle_id,
                    side=side,
                    quote_price=price,
                    best_bid=book.best_bid,
                    best_ask=book.best_ask,
                    last_price=book.last_price,
                    queue_ahead_tokens=queue_ahead_tokens,
                    inferred_through_tokens=inferred_through_tokens,
                    inferred_candidate=inferred_candidate,
                    random_candidate=random_candidate,
                ))
                await db.commit()
        except Exception as exc:
            log.warning("paper_opportunity_persist_failed", error=str(exc))

    async def _check_fills_paper(
        self,
        token_id: str,
        book: MarketBook,
        quotes: list[ActiveQuote],
        market_name: str,
    ) -> None:
        """PAPER fills, with an auditable evidence class on every fill."""
        if settings.paper_fill_model == "conservative":
            await self._check_fills_paper_conservative(
                token_id, book, quotes, market_name
            )
            return

        # Historical RNG simulator. Kept only for replay/comparison; every
        # resulting trade is persisted as ``random`` and can be excluded from
        # conservative analytics.
        direction = self._get_market_direction(token_id)

        for quote in quotes:
            # ── Bid fill simulation ──
            # v1.0.48 FIX (BUG-10): previously `continue` here would skip the
            # ask-fill block below for this quote. With 15% rejection + 40%
            # competition + 20% partial-none, ~60% of bid checks skipped ask.
            # Now we use `pass` so the ask block still runs after a bid skip.
            if not quote.bid_filled and quote.bid_price and quote.bid_price > 0:
                market_bid = book.best_bid
                if market_bid > 0:
                    distance = abs(quote.bid_price - market_bid)
                    if quote.bid_price >= market_bid - 0.003 and distance <= 0.015:
                        # v1.0.50 (BUG-2): rejection/competition rates are now
                        # configurable (paper_rejection_rate, paper_competition_rate).
                        # Defaults are more realistic: 20% rejection (was 15%),
                        # 50% competition (was 40%) — closer to real LIVE behavior.
                        if random.random() < settings.paper_rejection_rate:
                            pass  # v1.0.48: was `continue` (skipped ask block)
                        # Competition
                        elif random.random() < settings.paper_competition_rate:
                            pass  # v1.0.48: was `continue`
                        else:
                            # Directional bias (0.3 — informed traders)
                            direction_mult = 1.0 + (direction * -0.3)
                            # Fill probability — now configurable (paper_fill_prob_base/max)
                            market_spread = book.spread
                            activity_mult = 1.3 if market_spread < 0.015 else (0.6 if market_spread > 0.04 else 1.0)
                            closeness = 1.0 - (distance / 0.015)
                            fill_prob = settings.paper_fill_prob_base * closeness * activity_mult * max(0.5, direction_mult)
                            fill_prob = min(settings.paper_fill_prob_max, max(0.005, fill_prob))

                            if random.random() < fill_prob:
                                # Adverse drift — now configurable (paper_adverse_drift_min/max)
                                adverse_drift = book.mid * random.uniform(
                                    settings.paper_adverse_drift_min,
                                    settings.paper_adverse_drift_max,
                                )
                                # v1.0.75 (BUG-N26): Fix adverse drift for BUY.
                                # OLD: fill_price = min(quote.bid_price + adverse_drift, market_bid + 0.001)
                                #      This capped drift at bid+0.001 → drift never applied → 100% win rate.
                                # NEW: Cap at market_ask (can't buy higher than ask). Drift now actually
                                #      makes fill price worse (higher), modeling informed traders.
                                fill_price = (
                                    quote.bid_price
                                    if quote.strategy == "fast_flat"
                                    else min(
                                        quote.bid_price + adverse_drift,
                                        book.best_ask - 0.001,
                                    )
                                )
                                fill_price = max(0.01, min(0.99, fill_price))
                                # Partial fills (20% none, 40% partial, 40% full — realistic)
                                partial_roll = random.random()
                                if partial_roll < 0.20:
                                    pass  # v1.0.48: was `continue`
                                elif partial_roll < 0.60:
                                    fill_pct = random.uniform(0.40, 0.75)
                                else:
                                    fill_pct = random.uniform(0.85, 1.0)
                                if partial_roll >= 0.20:
                                    fill_size = quote.size_usdc * fill_pct
                                    if fill_size < 1.0 and quote.strategy != "fast_flat":
                                        pass  # v1.0.48: was `continue`
                                    elif not self.inventory.should_quote_bid(token_id):
                                        await self._cancel_all_levels(token_id)
                                        return
                                    # CRITICAL: check bankroll has enough cash for BUY
                                    # (simulates Polymarket API rejecting order if insufficient balance)
                                    elif self.inventory.bankroll < fill_size:
                                        log.warning(
                                            "fill_skipped_insufficient_balance",
                                            side="BUY",
                                            market=market_name[:30],
                                            fill_size=round(fill_size, 2),
                                            bankroll=round(self.inventory.bankroll, 2),
                                            reason="not enough cash to buy (would be rejected in LIVE)",
                                        )
                                        pass  # v1.0.48: was `continue`
                                    else:
                                        await self._record_fill(
                                            token_id, "BUY", fill_price, fill_size, market_name,
                                            level=quote.level, mid_at_fill=quote.mid_at_place,
                                            _skip_hedge=quote.strategy == "fast_flat",
                                            exit_path=(
                                                "FAST_FLAT_ENTRY"
                                                if quote.strategy == "fast_flat"
                                                else "quote_bid"
                                            ),
                                            fill_verification="random",
                                            cycle_id=quote.cycle_id,
                                        )
                                        quote.bid_filled = True
                                        quote.bid_fill_pct = fill_pct

            # ── Ask fill simulation ──
            # v1.0.48 FIX (BUG-10): same as bid — `continue` here would skip
            # the round-trip detection below. Now uses `pass`.
            # v1.0.153 (GLM P1): don't even attempt a SELL fill when flat —
            # previously the attempt ran and logged sell_fill_skipped_no_tokens
            # as a warning every time.
            if (
                not quote.ask_filled and quote.ask_price and quote.ask_price < 1
                and self.inventory.get_inventory(token_id).net_tokens > 0.5
            ):
                market_ask = book.best_ask
                if market_ask < 1:
                    distance = abs(quote.ask_price - market_ask)
                    if quote.ask_price <= market_ask + 0.003 and distance <= 0.015:
                        # v1.0.50 (BUG-2): configurable rejection/competition rates
                        if random.random() < settings.paper_rejection_rate:
                            pass  # v1.0.48: was `continue`
                        # Competition
                        elif random.random() < settings.paper_competition_rate:
                            pass  # v1.0.48: was `continue`
                        else:
                            # Directional bias (0.3 — informed traders)
                            direction_mult = 1.0 + (direction * 0.3)
                            market_spread = book.spread
                            activity_mult = 1.3 if market_spread < 0.015 else (0.6 if market_spread > 0.04 else 1.0)
                            closeness = 1.0 - (distance / 0.015)
                            fill_prob = settings.paper_fill_prob_base * closeness * activity_mult * max(0.5, direction_mult)
                            fill_prob = min(settings.paper_fill_prob_max, max(0.005, fill_prob))

                            if random.random() < fill_prob:
                                # v1.0.158 FIX (diagnostic §4): NO adverse drift
                                # on a MAKER ask-fill. A resting maker order
                                # executes at ITS OWN price — it never slides
                                # down. The old drift (mid × 0.8-2.0%) pushed
                                # fills below the breakeven floor and produced
                                # phantom losses (ETH 2026-07-14: −0.52/−0.67/
                                # −0.91¢ per token on asks parked exactly on
                                # the floor). Taker exits (sniper/liquidation)
                                # keep their slippage model — there drift is
                                # real (aggressive execution crosses the book).
                                fill_price = max(0.01, min(0.99, quote.ask_price))
                                # Partial fills (20% none, 40% partial, 40% full — realistic)
                                partial_roll = random.random()
                                if partial_roll < 0.20:
                                    pass  # v1.0.48: was `continue`
                                elif partial_roll < 0.60:
                                    fill_pct = random.uniform(0.40, 0.75)
                                else:
                                    fill_pct = random.uniform(0.85, 1.0)
                                if partial_roll >= 0.20:
                                    fill_size = quote.size_usdc * fill_pct
                                    if fill_size < 1.0 and quote.strategy != "fast_flat":
                                        pass  # v1.0.48: was `continue`
                                    else:
                                        # CRITICAL: Check if we have tokens to sell
                                        # In LIVE: Polymarket API rejects SELL if insufficient token balance
                                        inv_now = self.inventory.get_inventory(token_id)
                                        tokens_to_sell = fill_size / max(fill_price, 0.001)
                                        if inv_now.net_tokens < tokens_to_sell:
                                            log.warning(
                                                "sell_fill_skipped_no_tokens",
                                                market=market_name[:30],
                                                net_tokens=round(inv_now.net_tokens, 4),
                                                tokens_to_sell=round(tokens_to_sell, 4),
                                                reason="insufficient tokens (LIVE API would reject)",
                                            )
                                            pass  # v1.0.48: was `continue`
                                        elif not self.inventory.should_quote_ask(token_id):
                                            await self._cancel_all_levels(token_id)
                                            return
                                        else:
                                            await self._record_fill(
                                                token_id, "SELL", fill_price, fill_size, market_name,
                                                level=quote.level, mid_at_fill=quote.mid_at_place,
                                                _skip_hedge=quote.strategy == "fast_flat",
                                                exit_path=(
                                                    "FAST_FLAT_MAKER_EXIT"
                                                    if quote.strategy == "fast_flat"
                                                    else "ask_fill"
                                                ),
                                                fill_verification="random",
                                                cycle_id=quote.cycle_id,
                                            )
                                            quote.ask_filled = True
                                            quote.ask_fill_pct = fill_pct

            # ── Round-trip detection (per level) ──
            if quote.bid_filled and quote.ask_filled:
                buy_p = quote.bid_price or 0
                sell_p = quote.ask_price or 0
                log.info(
                    "round_trip",
                    market=market_name[:40],
                    level=quote.level,
                    buy=round(buy_p, 4),
                    sell=round(sell_p, 4),
                    gross_spread=round(sell_p - buy_p, 4),
                )
                ROUND_TRIPS_TOTAL.inc()
                self._round_trip_count += 1

        # Remove fully-filled quotes
        self.active_quotes[token_id] = [q for q in quotes if not (q.bid_filled and q.ask_filled)]
        if not self.active_quotes[token_id]:
            self.active_quotes.pop(token_id, None)

    def _get_market_direction(self, token_id: str) -> float:
        """Estimate short-term direction (-1..+1) from price history."""
        state = self._as_calc.get_state(token_id)
        if not state or len(state.price_history) < 5:
            return 0.0
        prices = [p for _, p in state.price_history]
        recent = prices[-1]
        past = prices[-5]
        if past == 0:
            return 0.0
        change = (recent - past) / past
        return max(-1.0, min(1.0, change * 50))

    # ── LIVE mode: order polling ──────────────────────────────────────────

    async def _poll_orders_loop(self) -> None:
        """In LIVE mode: poll order status to detect fills."""
        await asyncio.sleep(5)
        while self._running:
            try:
                await self._poll_orders()
            except asyncio.CancelledError:
                break
            except Exception as e:
                log.debug("poll_error", error=str(e))
            await asyncio.sleep(3)

    async def _poll_orders_normalized(self) -> None:
        """Serialize every consumer of cumulative exchange executions."""
        async with self._order_poll_lock:
            await self._poll_orders_normalized_locked()

    async def _poll_orders_normalized_locked(self) -> None:
        """Apply confirmed cumulative fill deltas from either exchange.

        A repeated status response is idempotent.  Transient/not-found
        responses retain the pending order, and a cancel request is not a
        terminal event until the exchange confirms removal.
        """
        order_ids = list(self._pending_orders.keys())
        try:
            states = await self.clob.get_order_statuses(order_ids)
        except Exception as e:
            log.warning("poll_orders_status_failed", error=str(e))
            return
        if not isinstance(states, dict):
            return

        now_mono = time.monotonic()
        terminal_order_statuses = {
            "FILLED", "CANCELLED", "CANCELED", "EXPIRED", "KILLED"
        }
        transient_settlement = {"DELAYED", "MATCHED", "RETRYING"}

        for order_id in order_ids:
            info = self._pending_orders.get(order_id)
            if info is None:
                continue
            state = states.get(order_id)
            if not isinstance(state, dict) or not state.get("found"):
                continue

            confirmed = bool(state.get("confirmed"))
            cumulative_cg = float(state.get("contracts_gross") or 0.0)
            cumulative_cn = float(state.get("contracts_net") or 0.0)
            cumulative_ug = float(state.get("usd_gross") or 0.0)
            cumulative_un = float(state.get("usd_net") or 0.0)
            cumulative_fee = float(state.get("fee_usdc") or 0.0)

            previous_cg = float(info.get("accounted_contracts_gross", 0.0))
            previous_cn = float(info.get("accounted_contracts_net", 0.0))
            previous_ug = float(info.get("accounted_usd_gross", 0.0))
            previous_un = float(info.get("accounted_usd_net", 0.0))
            previous_fee = float(info.get("accounted_fee_usdc", 0.0))

            delta_cg = max(0.0, cumulative_cg - previous_cg)
            delta_cn = max(0.0, cumulative_cn - previous_cn)
            delta_ug = max(0.0, cumulative_ug - previous_ug)
            delta_un = max(0.0, cumulative_un - previous_un)
            delta_fee = max(0.0, cumulative_fee - previous_fee)

            if confirmed and delta_cg > 0 and delta_ug > 0:
                price = float(state.get("price") or info.get("price") or 0.0)
                if price <= 0:
                    price = delta_ug / delta_cg
                await self._record_confirmed_execution(
                    token_id=info["token_id"],
                    side=info["side"],
                    market_name=info.get("market_name", ""),
                    price=price,
                    contracts_gross=delta_cg,
                    contracts_net=delta_cn if delta_cn > 0 else delta_cg,
                    usd_gross=delta_ug,
                    usd_net=delta_un if delta_un > 0 else delta_ug,
                    fee_usdc=delta_fee,
                    level=info.get("level", 1),
                    is_taker=info.get("order_type", "GTC") in ("FAK", "FOK"),
                    is_hedge=bool(info.get("is_hedge", False)),
                    exit_path=info.get("exit_path", ""),
                    mid_at_fill=info.get("mid_at_place", price),
                    fill_verification="verified",
                    cycle_id=int(info.get("cycle_id") or 0),
                )
                if info.get("is_liquidation") and not info.get("counted_exit"):
                    self._liquidation_count += 1
                    info["counted_exit"] = True
                if info.get("is_hedge") and not info.get("counted_hedge"):
                    self._hedge_fills += 1
                    info["counted_hedge"] = True
                if (
                    info.get("exit_path") == "PROFIT_SNIPER"
                    and not info.get("counted_profit_take")
                ):
                    self._profit_take_count += 1
                    info["counted_profit_take"] = True
                info["accounted_contracts_gross"] = cumulative_cg
                info["accounted_contracts_net"] = cumulative_cn
                info["accounted_usd_gross"] = cumulative_ug
                info["accounted_usd_net"] = cumulative_un
                info["accounted_fee_usdc"] = cumulative_fee
                if info.get("strategy") == "fast_flat":
                    # Stop the unfilled remainder after the first confirmed
                    # delta.  The cancel ACK is not terminal; the strategy
                    # waits for the next status snapshot before switching side.
                    info["ttl_sec"] = 0.0
                    if self._fast_flat_state is not None:
                        self._fast_flat_state.had_position = True
                    if state.get("is_open") is True and not info.get(
                        "cancel_requested_at"
                    ):
                        try:
                            if await self.clob.cancel_order(order_id):
                                info["cancel_requested_at"] = now_mono
                        except Exception as exc:
                            log.warning(
                                "fast_flat_partial_cancel_failed",
                                order_id=order_id,
                                error=str(exc),
                            )

                requested = float(info.get("size_usdc", 0.0))
                fill_pct = min(1.0, cumulative_ug / requested) if requested > 0 else 0.0
                for quotes in self.active_quotes.values():
                    for quote in quotes:
                        if quote.bid_order_id == order_id:
                            quote.bid_fill_pct = fill_pct
                            quote.bid_filled = fill_pct >= 0.999
                        if quote.ask_order_id == order_id:
                            quote.ask_fill_pct = fill_pct
                            quote.ask_filled = fill_pct >= 0.999
                log.info(
                    "poll_orders_confirmed_delta",
                    order_id=order_id,
                    settlement=state.get("settlement_status"),
                    side=info["side"],
                    delta_usdc=round(delta_ug, 6),
                    delta_tokens=round(delta_cg, 6),
                )

            order_type = str(info.get("order_type", "GTC")).upper()
            settlement = str(state.get("settlement_status", "") or "").upper()
            order_status = str(state.get("status", "") or "").upper()
            is_open = state.get("is_open")
            age = now_mono - float(info.get("placed_at", now_mono))
            full_fill = (
                float(info.get("accounted_usd_gross", 0.0))
                >= float(info.get("size_usdc", 0.0)) * 0.995
            )
            unsettled_reported_fill = (
                (cumulative_cg > 0 or cumulative_ug > 0) and not confirmed
            )

            terminal = False
            if order_type in ("FAK", "FOK"):
                terminal = (
                    settlement in {
                        "UNMATCHED", "MINED", "CONFIRMED", "FAILED",
                        "CANCELED", "CANCELLED",
                    }
                    and is_open is not True
                    and not unsettled_reported_fill
                )
            elif (
                settlement not in transient_settlement
                and (
                    is_open is False
                    or (is_open is None and full_fill)
                )
            ):
                # A cancel ACK or absence from the open-order snapshot alone
                # does not prove settlement. Require an explicit terminal
                # order/settlement status or a fully accounted execution.
                terminal_settlements = {
                    "UNMATCHED",
                    "MINED",
                    "CONFIRMED",
                    "FAILED",
                    "CANCELED",
                    "CANCELLED",
                }
                terminal = (
                    order_status in terminal_order_statuses
                    or settlement in terminal_settlements
                    or full_fill
                ) and not unsettled_reported_fill

            if terminal:
                if info.get("strategy") == "fast_flat":
                    token_quotes = self.active_quotes.get(info["token_id"], [])
                    keep: list[ActiveQuote] = []
                    for quote in token_quotes:
                        if (
                            quote.bid_order_id == order_id
                            or quote.ask_order_id == order_id
                        ):
                            continue
                        keep.append(quote)
                    if keep:
                        self.active_quotes[info["token_id"]] = keep
                    else:
                        self.active_quotes.pop(info["token_id"], None)
                self._pending_orders.pop(order_id, None)
                continue

            ttl_sec = float(info.get("ttl_sec", 30.0))
            cancel_requested_at = float(info.get("cancel_requested_at", 0.0))
            if age > ttl_sec and (
                cancel_requested_at <= 0 or now_mono - cancel_requested_at > 10.0
            ):
                try:
                    canceled = await self.clob.cancel_order(order_id)
                except Exception as e:
                    canceled = False
                    log.warning(
                        "poll_orders_cancel_exception",
                        order_id=order_id,
                        error=str(e),
                    )
                if canceled:
                    info["cancel_requested_at"] = now_mono
                    log.debug(
                        "poll_orders_cancel_requested",
                        order_id=order_id,
                        age_sec=round(age, 1),
                    )

    async def _poll_orders(self) -> None:
        """v1.0.46 FIX (BUG-5, BUG-6): safer fill detection.
        v1.0.47 FIX: corrected status strings per Polymarket API docs.

        BUG-5: previously `final.get("size_matched", info["size_usdc"])` would
          default to the FULL order size when the API omitted `size_matched`.
          For PARTIALLY_FILLED this recorded a phantom full fill. Now we treat
          a missing size_matched as 0 (no fill recorded) and log a warning.
        BUG-6: previously only MATCHED/FILLED/FILLED_PARTIAL triggered fill
          recording. A CANCELLED order with a partial fill was silently
          dropped. Now we check size_matched for ANY non-open status and
          record whatever partial fill exists.
        v1.0.47: Polymarket API uses `PARTIALLY_FILLED` (not `FILLED_PARTIAL`).
          Status values: LIVE (active on book), PARTIALLY_FILLED, FILLED,
          CANCELLED. `size_matched` is preserved after CANCELLED (partial
          fill kept). After cancel, size_matched does NOT increase further.
        """
        if not self._pending_orders:
            return
        # Real adapters expose an exchange-neutral status API.  The fallback
        # below remains only for legacy test doubles; production code must not
        # reach into a Polymarket SDK client from the MM core.
        if callable(getattr(type(self.clob), "get_order_statuses", None)):
            await self._poll_orders_normalized()
            return
        from py_clob_client.clob_types import OpenOrderParams

        try:
            open_orders = self.clob._client.get_orders(OpenOrderParams())
        except Exception as e:
            log.warning("poll_orders_failed", error=str(e))
            return

        open_ids = {o.get("id") for o in open_orders if isinstance(o, dict)}
        now_mono = time.monotonic()

        for order_id in list(self._pending_orders.keys()):
            info = self._pending_orders[order_id]
            age = now_mono - info["placed_at"]

            # If order is no longer in open list → it filled or was canceled
            if order_id not in open_ids:
                # Check final status via get_order
                try:
                    final = self.clob._client.get_order(order_id)
                except Exception as e:
                    log.debug("get_order_failed", order_id=order_id, error=str(e))
                    self._pending_orders.pop(order_id, None)
                    continue

                if not isinstance(final, dict):
                    log.warning(
                        "poll_orders_unexpected_response",
                        order_id=order_id,
                        response_type=type(final).__name__,
                    )
                    self._pending_orders.pop(order_id, None)
                    continue

                status = (final.get("status", "") or "").upper()

                # v1.0.46 (BUG-5): don't assume full fill when size_matched
                # is missing. Read it explicitly; default to 0 (not the
                # original size) so we don't record phantom fills.
                size_matched_raw = final.get("size_matched")
                if size_matched_raw is None:
                    # Some API responses use "size_matched" (USDC) others use
                    # "makingAmount"/"takingAmount" (tokens). Try both.
                    making = final.get("makingAmount")
                    if making is not None:
                        try:
                            # makingAmount is tokens; convert to USDC at price
                            price_for_conv = float(final.get("price", info["price"]))
                            size_matched_usd = float(making) * price_for_conv
                        except (TypeError, ValueError):
                            size_matched_usd = 0.0
                    else:
                        size_matched_usd = 0.0
                        if status in ("MATCHED", "FILLED", "PARTIALLY_FILLED"):
                            log.warning(
                                "poll_orders_size_matched_missing",
                                order_id=order_id,
                                status=status,
                                reason="API reports fill but no size_matched/makingAmount — recording 0",
                            )
                else:
                    try:
                        size_matched_usd = float(size_matched_raw)
                    except (TypeError, ValueError):
                        size_matched_usd = 0.0
                        log.warning(
                            "poll_orders_size_matched_unparseable",
                            order_id=order_id,
                            raw=size_matched_raw,
                        )

                # v1.0.46 (BUG-6): record ANY partial fill, regardless of
                # status (was: only MATCHED/FILLED/FILLED_PARTIAL). A
                # CANCELLED order may still have a partial fill recorded
                # in size_matched (v1.0.47: confirmed by Polymarket API docs
                # — size_matched is preserved after CANCELLED).
                if size_matched_usd > 0:
                    try:
                        fill_price = float(final.get("price", info["price"]))
                    except (TypeError, ValueError):
                        fill_price = info["price"]

                    # Skip tiny dust fills (< $0.01) — likely rounding noise
                    if size_matched_usd >= 0.01:
                        await self._record_fill(
                            info["token_id"], info["side"], fill_price,
                            size_matched_usd, info["market_name"],
                            level=info.get("level", 1),
                            mid_at_fill=info.get("mid_at_place", fill_price),
                        )
                        log.info(
                            "poll_orders_fill_detected",
                            order_id=order_id,
                            status=status,
                            side=info["side"],
                            size_usdc=round(size_matched_usd, 4),
                            price=round(fill_price, 4),
                            market=info["market_name"][:30],
                        )
                    else:
                        log.debug(
                            "poll_orders_dust_fill_skipped",
                            order_id=order_id,
                            size_usdc=size_matched_usd,
                        )
                elif status in ("MATCHED", "FILLED", "PARTIALLY_FILLED"):
                    # API says filled but size_matched=0 — suspicious, log it
                    log.warning(
                        "poll_orders_fill_zero_size",
                        order_id=order_id,
                        status=status,
                        reason="status indicates fill but size_matched=0; no fill recorded",
                    )

                self._pending_orders.pop(order_id, None)
            elif age > 30:
                # Timeout: cancel. Note: the cancelled order may still have
                # a partial fill that we'll detect on the NEXT poll cycle
                # (after it disappears from open_ids). So we don't pop here
                # immediately — we let the next cycle's get_order() read
                # the final status with size_matched.
                await self.clob.cancel_order(order_id)
                # Give the cancel one more cycle to settle before popping,
                # so the partial-fill check above can run on the final state.
                # If the cancel fails silently, the 30s timeout will retry.
                info["placed_at"] = now_mono - 25  # grace period for next cycle
                log.debug(
                    "poll_orders_cancel_sent",
                    order_id=order_id,
                    age_sec=round(age, 1),
                    reason="order timeout, will re-check final status next cycle",
                )

    # ── Active inventory liquidation (v1.0.38) ───────────────────────────
    # Solves the critical "inventory accumulation" problem: bot buys but
    # won't sell below entry, so positions get stuck when price drops.
    # This loop aggressively clears aged positions by placing sell orders
    # at/below market bid, accepting realized losses to free up capital.

    async def _state_persistence_loop(self) -> None:
        """v1.0.72 (BUG-N23): Save inventory state to DB every 60s.

        Enables crash recovery: if bot dies (power loss, kill -9, OOM),
        load_state_from_db() on next startup restores bankroll + positions.
        """
        await asyncio.sleep(10)  # let bot stabilize first
        while self._running:
            try:
                from app.core.db import AsyncSessionLocal
                async with AsyncSessionLocal() as db:
                    await self.inventory.save_state_to_db(db)
            except asyncio.CancelledError:
                break
            except Exception as e:
                log.warning(
                    "state_persistence_error",
                    error=str(e),
                    error_type=type(e).__name__,
                )
            await asyncio.sleep(60)

    async def _liquidation_loop(self) -> None:
        """Background task: aggressively liquidate aged inventory.

        Runs every `inventory_liquidation_check_sec` seconds. For each
        market with a long position older than `aggressive_age_sec`:
          - Cancel existing quotes (so we can place aggressive ones)
          - Place a SELL at market_bid + 0.001 (front of bid queue)
        If older than `urgent_age_sec`:
          - Place a SELL at market_bid (take whatever we can get)
        This ensures stuck positions are cleared, freeing capital.
        """
        await asyncio.sleep(settings.inventory_liquidation_check_sec)
        while self._running:
            try:
                if not self._trading_paused and not self.inventory.halted:
                    await self._liquidate_aged_positions()
                    # v1.0.50 FIX (BUG-3): also clean up orphaned positions.
                    # These are positions on markets that are no longer in
                    # self.clob.books (market was replaced/closed). Without
                    # this, orphaned positions stay in inventory forever
                    # (unless they hit pre-resolution exit, but if the market
                    # was already replaced we don't track end_date).
                    await self._cleanup_orphaned_positions()
            except asyncio.CancelledError:
                break
            except Exception as e:
                log.warning("liquidation_loop_error", error=str(e))
            await asyncio.sleep(settings.inventory_liquidation_check_sec)

    async def _snapshot_loop(self) -> None:
        """v1.0.88: periodically persist mm_snapshots (price history for backtest).

        Before v1.0.88 the MarketSnapshot table was defined in the schema but
        NEVER written (only pruned), making any 'hold N minutes' backtest
        impossible. This loop logs one row per active market every
        mm_snapshot_log_interval_sec. Kyle lambda is read READ-ONLY from the
        existing KyleLambda state (no mutation → no race with the quote loop,
        which calls update_and_compute); volatility is left 0.0 for now
        (A-S sigma is computed inside the quote loop and not cached here).
        Modeled on _liquidation_loop.
        """
        await asyncio.sleep(settings.mm_snapshot_log_interval_sec)
        while self._running:
            try:
                if not self._trading_paused and not self.inventory.halted:
                    await self._log_market_snapshots()
            except asyncio.CancelledError:
                break
            except Exception as e:
                log.warning("snapshot_loop_error", error=str(e))
            await asyncio.sleep(settings.mm_snapshot_log_interval_sec)

    async def _log_market_snapshots(self) -> None:
        """Write one MarketSnapshot row per active market in one DB transaction."""
        try:
            from app.core.db import AsyncSessionLocal

            rows: list[MarketSnapshot] = []
            for token_id, book in self.clob.books.items():
                # Skip markets with no usable quote (best_bid <= 0 means no
                # real market yet — mid/spread would be meaningless).
                if not book or book.best_bid <= 0:
                    continue
                inv = self.inventory.inventories.get(token_id)
                # READ-ONLY: get_state returns the existing KyleState without
                # mutating imbalance_history (unlike update_and_compute).
                kyle_state = self._kyle.get_state(token_id)
                rows.append(
                    MarketSnapshot(
                        market_id=token_id,
                        mid_price=book.mid,
                        spread=book.spread,
                        volatility=0.0,
                        kyle_lambda=kyle_state.last_lambda if kyle_state else 0.0,
                        our_inventory=inv.net_tokens if inv else 0.0,
                        bankroll_usdc=self.inventory.bankroll,
                    )
                )
            if not rows:
                return
            async with AsyncSessionLocal() as db:
                db.add_all(rows)
                await db.commit()
        except Exception as e:
            # Non-fatal: snapshot logging must never break trading.
            log.debug("snapshot_log_failed", error=str(e))

    # v1.0.122 (Claude audit p.1): periodic bankroll sync loop for LIVE mode.
    async def _bankroll_sync_loop(self) -> None:
        """Every 300s, sync internal bankroll with real wallet balance.

        PAPER: no-op (sync_bankroll_from_wallet returns immediately).
        LIVE: detects drift >5% between internal accounting and real wallet.
        """
        await asyncio.sleep(300)  # first sync after 5 min (startup sync already done)
        while self._running:
            try:
                await self.inventory.sync_bankroll_from_wallet(self.clob)
            except asyncio.CancelledError:
                raise
            except Exception as e:
                log.warning("bankroll_sync_loop_error", error=str(e))
            await asyncio.sleep(300)

    # ── v1.0.151: momentum filter ─────────────────────────────────────────

    def _push_mid(self, token_id: str, mid: float) -> None:
        """Append (ts, mid) to the market's ring buffer (~10 min depth)."""
        buf = self._mid_history.setdefault(token_id, deque())
        now = time.monotonic()
        buf.append((now, mid))
        cutoff = now - 600.0
        while buf and buf[0][0] < cutoff:
            buf.popleft()

    def _momentum_cents(self, token_id: str) -> float | None:
        """mid_now − mid_window_ago, in cents. None until the buffer spans
        the full momentum window (no blocking on insufficient data)."""
        buf = self._mid_history.get(token_id)
        if not buf:
            return None
        target = time.monotonic() - settings.momentum_window_sec
        ref = None
        for ts, mid in buf:
            if ts <= target:
                ref = mid  # latest sample at/before the window boundary
            else:
                break
        if ref is None:
            return None
        return (buf[-1][1] - ref) * 100.0

    def _apply_momentum_filter(self, token_id: str, market_name: str, decision) -> None:
        """Block the side a fast market would run over (falling → no bid,
        rising → no ask). Mutates decision in place; transition-only INFO."""
        mom = self._momentum_cents(token_id)
        falling = mom is not None and mom <= -settings.momentum_bid_block_cents
        rising = mom is not None and mom >= settings.momentum_ask_block_cents

        if falling:
            logger_fn = (
                log.debug if token_id in self._momentum_bid_blocked else log.info
            )
            self._momentum_bid_blocked.add(token_id)
            logger_fn(
                "momentum_bid_blocked",
                market=market_name[:30],
                momentum_cents=round(mom, 2),
                window_sec=settings.momentum_window_sec,
                reason="market falling — our bid is a feeding trough for sellers",
            )
            decision.allow_bid = False
        elif token_id in self._momentum_bid_blocked:
            self._momentum_bid_blocked.discard(token_id)
            log.info(
                "momentum_bid_block_released",
                market=market_name[:30],
                momentum_cents=round(mom, 2) if mom is not None else None,
            )

        if rising:
            logger_fn = (
                log.debug if token_id in self._momentum_ask_blocked else log.info
            )
            self._momentum_ask_blocked.add(token_id)
            logger_fn(
                "momentum_ask_blocked",
                market=market_name[:30],
                momentum_cents=round(mom, 2),
                window_sec=settings.momentum_window_sec,
                reason="market rising — our ask is a feeding trough for buyers",
            )
            decision.allow_ask = False
        elif token_id in self._momentum_ask_blocked:
            self._momentum_ask_blocked.discard(token_id)
            log.info(
                "momentum_ask_block_released",
                market=market_name[:30],
                momentum_cents=round(mom, 2) if mom is not None else None,
            )

    # ── v1.0.155: adverse-rate market rotation ────────────────────────────

    def _record_adverse_probe(self, token_id: str, fill_price: float) -> None:
        """Called on every BUY fill: schedule a +60s mid check."""
        self._adverse_probes.append((token_id, fill_price, time.monotonic()))

    def _mid_at_or_after(self, token_id: str, ts: float) -> float | None:
        """Earliest mid sample at/after ts from the v151 ring buffer."""
        buf = self._mid_history.get(token_id)
        if not buf:
            return None
        for sample_ts, mid in buf:
            if sample_ts >= ts:
                return mid
        return None

    def _process_adverse_probes(self) -> None:
        """Mature 60s-old probes into per-market outcome windows; ban a
        market whose adverse_rate > 30% over the last 20 fills (≥10)."""
        if not self._adverse_probes:
            return
        now = time.monotonic()
        remaining: list[tuple[str, float, float]] = []
        for token_id, fill_px, t0 in self._adverse_probes:
            if now - t0 < 60.0:
                remaining.append((token_id, fill_px, t0))
                continue
            mid_later = self._mid_at_or_after(token_id, t0 + 60.0)
            if mid_later is None:
                continue  # market gone / no data — drop the probe
            adverse = mid_later < fill_px - 0.005
            outcomes = self._fill_outcomes.setdefault(token_id, deque(maxlen=20))
            outcomes.append(adverse)
            if len(outcomes) >= 10:
                rate = sum(outcomes) / len(outcomes)
                if rate > 0.30 and token_id not in self._banned_markets:
                    self._banned_markets[token_id] = (
                        now + settings.adverse_market_ban_sec
                    )
                    self._adverse_ban_count += 1
                    info = self.clob.markets.get(token_id)
                    log.warning(
                        "market_banned_adverse_rate",
                        market=(info.question[:40] if info else token_id[:12]),
                        adverse_rate=round(rate, 2),
                        window_fills=len(outcomes),
                        ban_sec=settings.adverse_market_ban_sec,
                        reason="fills keep going adverse — rotate the market out",
                    )
        self._adverse_probes = remaining

    def _is_market_banned(self, token_id: str) -> bool:
        until = self._banned_markets.get(token_id)
        if until is None:
            return False
        if time.monotonic() >= until:
            self._banned_markets.pop(token_id, None)
            self._fill_outcomes.pop(token_id, None)  # fresh slate
            info = self.clob.markets.get(token_id)
            log.info(
                "market_ban_expired",
                market=(info.question[:40] if info else token_id[:12]),
            )
            return False
        return True

    # ── v1.0.150: exit-policy helpers ─────────────────────────────────────

    def _taker_fee_per_token(self, token_id: str, price: float) -> float:
        """Estimated taker fee in $ per token at the given price.

        Limitless: per-market flag metadata.fee (adapter stores it as
        _meta[token].fee_bearing); the actual rate comes from the LIVE
        profile (rank.feeRateBps) and is unknown in PAPER, where the
        conservative taker_fee_bps_assumed is used instead. Non-fee-bearing
        markets (and Polymarket) → 0. Maker fees are zero on Limitless.
        """
        meta_map = getattr(self.clob, "_meta", None)
        meta = meta_map.get(token_id) if isinstance(meta_map, dict) else None
        if meta is None or not getattr(meta, "fee_bearing", False):
            return 0.0
        live_bps = float(getattr(self.clob, "_fee_rate_bps", 0) or 0)
        bps = live_bps if live_bps > 0 else settings.taker_fee_bps_assumed
        return price * bps / 10000.0

    def _loss_exit_allowed(self, token_id: str) -> tuple[bool, str]:
        """Loss-realizing exits are allowed ONLY pre-resolution or after
        the daily stop-loss has tripped. Everywhere else: hold and wait."""
        info = self.clob.markets.get(token_id)
        if info and info.end_date_ts > 0:
            ttr = info.end_date_ts - datetime.now(timezone.utc).timestamp()
            if ttr < settings.pre_resolution_exit_sec:
                return True, f"pre_resolution (ttr={int(max(ttr, 0))}s)"
        if self.inventory.daily_pnl <= -settings.max_daily_loss_usd:
            return True, f"daily_stop_loss (daily_pnl={self.inventory.daily_pnl:.2f})"
        return False, ""

    async def _maybe_no_hedge(self, token_id: str, inv, book, market_name: str) -> bool:
        """v1.0.151 emergency brake (OFF by default, no_hedge_enabled).

        Deeply underwater YES position: buy NO → the YES+NO pair is worth
        exactly $1 (merge, or automatically at resolution), fixing a KNOWN
        bounded loss (entry + P_no − 1 + fee per token) instead of the
        0-or-everything lottery. Fires only when that fixed loss is small
        enough (no_hedge_max_loss_cents) and resolution is far enough away
        (pre-resolution handles the endgame otherwise). Returns True when
        the hedge executed (caller skips other liquidation logic).
        """
        if not settings.no_hedge_enabled:
            return False
        if not settings.paper_trading and settings.exchange == "limitless":
            log.warning(
                "no_hedge_blocked_limitless_live",
                market=market_name,
                reason="NO book/ledger and confirmed merge are not implemented",
            )
            return False
        if token_id in self._hedged_positions:
            return False
        now = time.monotonic()
        if now - self._no_hedge_last_check.get(token_id, 0.0) < 60.0:
            return False
        self._no_hedge_last_check[token_id] = now

        drawdown_cents = (inv.avg_entry_price - book.mid) * 100.0
        if drawdown_cents < settings.no_hedge_trigger_drawdown_cents:
            return False
        info = self.clob.markets.get(token_id)
        if not info or info.end_date_ts <= 0:
            return False
        ttr = info.end_date_ts - datetime.now(timezone.utc).timestamp()
        if ttr < settings.no_hedge_min_ttr_sec:
            return False  # pre-resolution exit owns the endgame

        # NO best ask. Binary CTF market: the NO side is the mirror of the
        # YES book, NO_ask = 1 − YES_bid. In PAPER this is an estimate
        # (marked in the log); LIVE should verify against the real NO book
        # on the smoke run.
        p_no_ask = round(1.0 - book.best_bid, 4)
        fee_per_token = self._taker_fee_per_token(token_id, p_no_ask)
        fixed_loss = inv.avg_entry_price + p_no_ask - 1.0 + fee_per_token
        if fixed_loss * 100.0 > settings.no_hedge_max_loss_cents:
            log.info(
                "no_hedge_skipped_too_expensive",
                market=market_name,
                avg_entry=round(inv.avg_entry_price, 4),
                p_no_ask=p_no_ask,
                fixed_loss_cents=round(fixed_loss * 100, 2),
                max_loss_cents=settings.no_hedge_max_loss_cents,
                reason="insurance costs more than the configured cap",
            )
            return False

        tokens = inv.net_tokens
        if settings.paper_trading:
            # Economically identical to selling YES at 1 − P_no_ask
            # (= best_bid): simulate via a SELL fill so inventory and
            # bankroll stay consistent. level 98 = NO-hedge.
            exit_px = round(1.0 - p_no_ask, 4)
            await self._record_fill(
                token_id, "SELL", exit_px, tokens * exit_px, market_name,
                level=98,
                mid_at_fill=book.mid,
                is_liquidation=True,
                exit_path="NO_HEDGE",
            )
        else:
            meta_map = getattr(self.clob, "_meta", None)
            meta = meta_map.get(token_id) if isinstance(meta_map, dict) else None
            no_token = getattr(meta, "no_token", "") if meta else ""
            if not no_token:
                log.warning(
                    "no_hedge_no_token_unknown",
                    market=market_name,
                    reason="adapter has no NO-token id for this market",
                )
                return False
            result = await self.clob.place_order(
                no_token, "BUY", p_no_ask, tokens * p_no_ask,
                order_type="FAK", post_only=False,
            )
            if not result.success:
                log.warning(
                    "no_hedge_order_failed",
                    market=market_name,
                    error=result.error,
                )
                return False
            # merge/redeem call is UNVERIFIED on Limitless — even without
            # it, a held YES+NO pair settles at exactly $1 on resolution,
            # which is economically equivalent to merging now.

        self._no_hedge_count += 1
        self._hedged_positions.add(token_id)
        log.warning(
            "no_hedge_executed",
            market=market_name,
            tokens=round(tokens, 4),
            avg_entry=round(inv.avg_entry_price, 4),
            p_no_ask=p_no_ask,
            p_no_source="estimated_from_yes_bid" if settings.paper_trading else "order",
            fee_per_token=round(fee_per_token, 5),
            fixed_loss_cents=round(fixed_loss * 100, 2),
            drawdown_cents=round(drawdown_cents, 2),
            ttr_sec=round(ttr, 0),
            mode="PAPER" if settings.paper_trading else "LIVE",
        )
        return True

    async def _liquidate_aged_positions(self) -> None:
        """Scan all inventories and liquidate aged ones."""
        now_mono = time.monotonic()
        for token_id, inv in list(self.inventory.inventories.items()):
            # Only liquidate long positions (we can only sell what we own)
            if inv.net_tokens <= 0.5:
                continue
            # v1.0.160 BUG FIX: open_time == 0 marks a position restored from
            # DB (inventory_manager sets it to 0 so aging restarts from zero).
            # The old `continue` here made such a position INVISIBLE to the
            # ENTIRE liquidation loop — including the profit sniper, which does
            # NOT depend on age (it acts on bid vs achievable max). Live case:
            # DOGE 2026-07-15 06:33 — bid hit 61% of the achievable max (inside
            # the corridor) but the sniper never even evaluated it because the
            # position had survived a restart. Fix: initialize open_time NOW
            # (age starts from zero, exactly as the reset intended) and FALL
            # THROUGH — the sniper/profit-take paths see it immediately (age 0
            # does not gate them), while the age-gated tiers (AGGRESSIVE/
            # URGENT) correctly begin their countdown from zero.
            if inv.open_time == 0:
                # Age it back by the sniper's initial pause: a RESTORED
                # position is not "fresh" — it survived a restart and has
                # already had its chance at a free maker ask-fill, so the
                # 3-min corridor pause (which exists to give brand-new
                # positions that first chance) should count as already
                # elapsed. This makes BOTH the upper threshold AND the
                # corridor visible immediately (the DOGE 61% case), while the
                # age-gated tiers (AGGRESSIVE 30min / URGENT 60min) start
                # effectively 3 min in — negligible against their thresholds.
                from app.services.profit_capture import INITIAL_PAUSE_SEC

                inv.open_time = now_mono - INITIAL_PAUSE_SEC
                log.info(
                    "position_age_initialized_on_first_check",
                    token=token_id[:12],
                    market=inv.market_name[:30] if inv.market_name else "",
                    net_tokens=round(inv.net_tokens, 4),
                    reason="restored position had open_time=0 — aging starts now "
                           "(past the corridor pause); sniper no longer blocked",
                )

            age_sec = now_mono - inv.open_time
            book = self.clob.books.get(token_id)
            if not book or book.best_bid <= 0:
                continue

            info = self.clob.markets.get(token_id)
            market_name = info.question[:40] if info else token_id[:12]

            # v1.0.151: NO-hedge emergency brake (disabled by default).
            if await self._maybe_no_hedge(token_id, inv, book, market_name):
                continue

            # Determine liquidation tier based on age
            market_bid = book.best_bid
            market_ask = book.best_ask
            # v1.0.66 (BUG-N17): mid-based liquidation pricing.
            # OLD: sell at bid+0.001 (ignored mid) → lost $3+ per position
            #      when spread was wide (bid 0.192, mid 0.320, ask 0.449).
            # NEW: target = max(mid, entry+5¢), capped at ask-0.001.
            #      Same A+C priority as Exit All (BUG-N16 fix).
            mid = (market_bid + market_ask) / 2.0 if market_ask > market_bid else market_bid
            target_mid = round(mid, 4)
            target_min = round(inv.avg_entry_price + 0.05, 4)  # entry + 5¢
            tier: str = ""

            # v1.0.153: PROFIT SNIPER now follows the HARDCODED exit ladder
            # (app/services/profit_capture.py, Jiji's ethalon). A fresh
            # position waits for the full spread (free maker ask-fill); the
            # sniper takes early ONLY when the bid delivers ≥70% of the
            # achievable max, the bar decaying linearly 70%→0% between 5 and
            # 30 minutes of age. PROFIT_TAKE_MIN_CENTS from .env no longer
            # participates (deprecated). Trigger and price remain bid-based
            # (BUG-N36 heritage), the v1.0.150 breakeven floor still rules.
            from app.services.profit_capture import should_fire
            from app.services.spread_invariant import hardcoded_quotes as _hq_now

            realistic_exit_for_trigger = round(market_bid, 4)
            taker_fee = self._taker_fee_per_token(token_id, realistic_exit_for_trigger)
            # Achievable max = today's hardcode ask − entry (maker exit, free).
            _hq = _hq_now(market_bid, market_ask, level=1)
            hardcode_ask = _hq.ask if _hq else round(market_ask - 0.0015, 4)
            achievable_max_cents = (hardcode_ask - inv.avg_entry_price) * 100.0
            net_bid_profit_cents = (
                (market_bid - inv.avg_entry_price) - taker_fee
            ) * 100.0
            # v1.0.158: corridor model replaces the linear decay ladder.
            fire, fire_reason = should_fire(
                achievable_max_cents, net_bid_profit_cents, age_sec
            )
            if fire:
                tier = "PROFIT_SNIPER"
                is_urgent = False
                # A SELL FAK must be priced at or below the resting bid.
                sell_price = realistic_exit_for_trigger
                taken_pct = (
                    round(net_bid_profit_cents / achievable_max_cents * 100.0, 1)
                    if achievable_max_cents > 0
                    else None
                )
                self._sniper_taken_pct_sum += taken_pct or 0.0
                self._sniper_fired_count += 1
                log.info(
                    "sniper_fired",
                    market=market_name,
                    age_sec=round(age_sec, 0),
                    avg_entry=inv.avg_entry_price,
                    market_bid=market_bid,
                    hardcode_ask=hardcode_ask,
                    achievable_max_cents=round(achievable_max_cents, 2),
                    net_bid_profit_cents=round(net_bid_profit_cents, 2),
                    taken_pct=taken_pct,
                    taker_fee_per_token=round(taker_fee, 5),
                    trigger=fire_reason,
                    reason="corridor model: bid delivers enough — take it",
                )
            elif age_sec < settings.inventory_liquidation_aggressive_age_sec:
                # v1.0.63 (BUG-N13): Critical tier — inventory at 95%+ of max.
                # Professional MM deleverages immediately when at hard cap,
                # regardless of age. Without this, bot can accumulate beyond
                # max_inventory_usdc via rapid fills and get stuck.
                max_usd = self.inventory.max_inventory_usdc()
                position_usd = abs(inv.net_tokens) * market_bid
                if max_usd > 0 and position_usd >= max_usd * 0.95:
                    is_urgent = False
                    tier = "CRITICAL"
                    # v1.0.66: mid-based pricing (was bid+0.001)
                    sell_price = max(target_mid, target_min)
                    sell_price = min(sell_price, round(market_ask - 0.001, 4))
                    log.warning(
                        "critical_tier_liquidation_triggered",
                        market=market_name,
                        age_sec=round(age_sec, 0),
                        position_usd=round(position_usd, 2),
                        max_usd=round(max_usd, 2),
                        ratio=round(position_usd / max_usd, 3),
                        mid=round(mid, 4),
                        target_mid=round(target_mid, 4),
                        target_min=round(target_min, 4),
                        sell_price=round(sell_price, 4),
                        reason="position at 95%+ of hard cap — deleverage now",
                    )
                else:
                    continue  # not aged enough, not at critical cap
            else:
                is_urgent = age_sec >= settings.inventory_liquidation_urgent_age_sec
                if is_urgent:
                    # Urgent: sell at max(mid, entry+5¢), capped at ask-0.001
                    # v1.0.66: was market_bid (any price), now mid-based
                    sell_price = max(target_mid, target_min)
                    sell_price = min(sell_price, round(market_ask - 0.001, 4))
                    tier = "URGENT"
                else:
                    # Aggressive: sell at max(mid, entry+5¢), capped at ask-0.001
                    # v1.0.66: was bid+0.001, now mid-based
                    sell_price = max(target_mid, target_min)
                    sell_price = min(sell_price, round(market_ask - 0.001, 4))
                    tier = "AGGRESSIVE"

            # Clamp to valid range
            sell_price = max(0.01, min(0.99, sell_price))

            # BUG-N34 (v1.0.91): compute the REALISTIC execution price BEFORE
            # the loss-tolerance check. Previously loss_cents was derived from
            # `sell_price` (mid-based, optimistic target), but the actual fill
            # for a taker SELL crossing the book cannot exceed market_bid (+0.001
            # tick improvement). On wide-spread books mid >> bid, so the old
            # loss_cents was systematically understated — the "max loss" guard
            # was partially blind exactly where it matters (AGGRESSIVE /
            # OPPORTUNISTIC_PROFIT tiers, where is_urgent=False makes the guard
            # active). URGENT bypasses the guard by design (unchanged).
            #
            # `realistic_exit_price` is reused below by both PAPER (was
            # `fillable_price`) and LIVE (for consistent logging).
            realistic_exit_price = min(sell_price, round(market_bid, 4))

            # Check loss tolerance — now against the realistic fill price.
            loss_cents = (inv.avg_entry_price - realistic_exit_price) * 100
            if loss_cents > settings.inventory_liquidation_max_loss_cents and not is_urgent:
                # Loss too big and not urgent yet — wait
                log.debug(
                    "liquidation_skipped_loss_too_big",
                    market=market_name,
                    age_sec=round(age_sec, 0),
                    loss_cents=round(loss_cents, 2),
                    max_loss_cents=settings.inventory_liquidation_max_loss_cents,
                    sell_price=round(sell_price, 4),
                    realistic_exit_price=round(realistic_exit_price, 4),
                )
                continue

            # v1.0.150: NO-LOSS EXIT POLICY. Any liquidation whose realistic
            # execution price sits below the breakeven floor (entry + taker
            # fee) is FORBIDDEN — for every tier including URGENT — except:
            #   (a) the pre-resolution window (ttr < pre_resolution_exit_sec)
            #   (b) the daily stop-loss has tripped.
            # Supersedes BUG-N39 (AGGRESSIVE no-loss) and REMOVES the
            # v1.0.120 opportunity-cost override (trend / capital-starvation
            # could force loss exits at any time — now banned).
            breakeven_floor = inv.avg_entry_price + self._taker_fee_per_token(
                token_id, realistic_exit_price
            )
            if realistic_exit_price < breakeven_floor:
                allowed, why = self._loss_exit_allowed(token_id)
                if is_urgent and allowed:
                    self._loss_forced_count += 1
                    log.warning(
                        "loss_liquidation_forced",
                        market=market_name,
                        tier=tier,
                        age_sec=round(age_sec, 0),
                        avg_entry=round(inv.avg_entry_price, 4),
                        realistic_exit_price=round(realistic_exit_price, 4),
                        breakeven_floor=round(breakeven_floor, 4),
                        loss_cents=round(loss_cents, 2),
                        reason=why,
                    )
                    # Fall through to execution — forced exit
                else:
                    log.info(
                        "liquidation_skipped_loss_vs_entry",
                        market=market_name,
                        tier=tier,
                        age_sec=round(age_sec, 0),
                        avg_entry=round(inv.avg_entry_price, 4),
                        realistic_exit_price=round(realistic_exit_price, 4),
                        breakeven_floor=round(breakeven_floor, 4),
                        sell_price=round(sell_price, 4),
                        loss_cents=round(loss_cents, 2),
                        reason="v1.0.150: loss exits forbidden outside pre-resolution / daily stop-loss",
                    )
                    continue

            # Size: sell entire position
            size_usdc = inv.net_tokens * sell_price
            if size_usdc < 1.0:
                continue  # too small to bother
            # v1.0.146 (Claude): LIVE — Polymarket rejects SELL < $5.
            # Without this check, a $1-$5 position triggers a FAK SELL
            # every liquidation cycle that the exchange rejects → endless
            # reject spam. Dust waits for resolution (settles in USDC,
            # no minimum) via the reconciliation loop.
            if not settings.paper_trading and size_usdc < settings.dust_threshold_usdc:
                log.debug(
                    "liquidation_skipped_dust_live",
                    market=market_name,
                    size_usdc=round(size_usdc, 2),
                    reason="below $5 exchange minimum — will settle on resolution",
                )
                continue

            # Check we have enough tokens (should always be true here)
            tokens_to_sell = inv.net_tokens
            if tokens_to_sell < 0.5:
                continue

            log.info(
                "liquidation_triggered",
                market=market_name,
                tier=tier,
                age_sec=round(age_sec, 0),
                net_tokens=round(inv.net_tokens, 4),
                avg_entry=round(inv.avg_entry_price, 4),
                sell_price=round(sell_price, 4),
                realistic_exit_price=round(realistic_exit_price, 4),
                market_bid=round(market_bid, 4),
                loss_cents=round(loss_cents, 2),
                size_usdc=round(size_usdc, 2),
            )

            # Cancel existing quotes for this market (so new aggressive
            # order isn't blocked by stale quotes)
            # v1.0.146 (Claude): force=True is REQUIRED here. With
            # partial_fill_no_cancel=true a partially-filled ask would stay
            # live while the FAK SELL below sells the ENTIRE position →
            # both could fill → sell more tokens than owned (naked short).
            # Force-cancel is safe: the FAK covers the whole position, so
            # no dust is created by cancelling the resting remainder.
            if token_id in self.active_quotes:
                await self._cancel_all_levels(token_id, force=True)

            # v1.0.39 FIX: in LIVE mode we must actually PLACE a sell order on
            # Polymarket. Previously _record_fill was called directly, which
            # updated local inventory/bankroll as if the position had been
            # sold — but no real SELL order ever hit the book. Result: the
            # bot believed it had liquidated, while the real position stayed
            # open on-chain and capital remained locked.
            #
            # We use order_type=FAK (Fill-And-Kill, a.k.a. IOC) so the order
            # either fills (partially or fully) immediately or is cancelled.
            # post_only=False is required because post_only orders can never
            # cross the book (they would be rejected when there is a matching
            # bid, which is exactly what we want here).
            if settings.paper_trading:
                # v1.0.81 (BUG-N30): PAPER liquidation now uses the same
                # probabilistic model as normal quotes — NOT a guaranteed
                # fill at mid (which has no buyer on the bid side).
                #
                # Root cause (found in 1h PAPER session): 13 fills, 6 closes,
                # 0 round_trips — all 6 closes were liquidations with
                # pnl_net > 0. The old PAPER branch called _record_fill
                # directly at sell_price (mid-based), bypassing the
                # paper_rejection_rate / paper_competition_rate / partial-fill
                # model that _check_fills_paper() applies to normal quotes.
                # This made PAPER P&L systematically OVERSTATED — the bot
                # "sold" at mid where no real buyer exists.
                #
                # Fix (Variant A from handoff): apply rejection probability +
                # partial-fill model + cap price to marketable (bid+0.001).
                # On rejection/partial-too-small → `continue` (position stays
                # open, retried next cycle; age_sec keeps growing because
                # open_time is only reset on position open/flip, not on
                # failed liquidation — verified in inventory_manager.py).
                #
                # BUG-N34 (v1.0.91): reuse `realistic_exit_price` computed
                # above (before loss-check) instead of re-deriving here.
                # Same formula, same value — just single source of truth.
                fillable_price = realistic_exit_price

                # BUG-N46 (v1.0.105): URGENT tier = "вийти за будь-яку ціну".
                # Previously URGENT went through the SAME probabilistic model
                # as normal quotes (paper_rejection_rate 27%, no_taker 20%,
                # partial fill 40-75%). Result: position dragged 10-30+ min,
                # fillable_price kept dropping with market, realized loss grew.
                # User: "entry 0.3311 → real exit 0.3210, P&L -1.01¢".
                # Fix: URGENT bypasses rejection/partial model entirely.
                # Full fill at fillable_price (realistic_exit_price).
                # This matches LIVE behavior: FAK/IOC order either fills
                # immediately against available depth or is cancelled —
                # but URGENT means we accept the price NOW, not wait.
                # v1.0.150: PROFIT_SNIPER joins the deterministic branch —
                # it sells INTO the resting best bid (real liquidity), so a
                # FAK there fills against available depth just like URGENT.
                if tier in ("URGENT", "PROFIT_SNIPER"):
                    tokens_filled = tokens_to_sell  # full fill
                    actual_size_usdc = tokens_filled * fillable_price
                    if actual_size_usdc < 1.0:
                        continue  # too small after all — skip

                    await self._record_fill(
                        token_id, "SELL", fillable_price, actual_size_usdc, market_name,
                        level=99,  # level 99 = liquidation
                        mid_at_fill=book.mid,
                        is_liquidation=True,
                        exit_path=tier,
                    )
                    self._liquidation_count += 1
                    if tier == "PROFIT_SNIPER":
                        self._profit_take_count += 1
                    log.info(
                        "liquidation_paper_filled_urgent",
                        market=market_name,
                        tier=tier,
                        sell_price=round(sell_price, 4),
                        fillable_price=round(fillable_price, 4),
                        fill_pct=1.0,
                        size_usdc=round(actual_size_usdc, 2),
                        age_sec=round(age_sec, 0),
                        reason=f"{tier}: full fill, bypass rejection/partial model",
                    )
                else:
                    # Non-URGENT (AGGRESSIVE/CRITICAL): keep probabilistic
                    # model — these tiers can wait for better fill conditions.
                    if random.random() < settings.paper_rejection_rate:
                        log.debug(
                            "liquidation_paper_rejected",
                            market=market_name,
                            tier=tier,
                            sell_price=round(sell_price, 4),
                            fillable_price=round(fillable_price, 4),
                            rejection_rate=settings.paper_rejection_rate,
                        )
                        continue  # retry next cycle (age keeps growing)

                    # Partial fill model (Polymarket depth-limited)
                    partial_roll = random.random()
                    if partial_roll < 0.20:
                        # No fill at all this cycle (FAK found no taker)
                        log.debug(
                            "liquidation_paper_no_taker",
                            market=market_name,
                            tier=tier,
                            fillable_price=round(fillable_price, 4),
                        )
                        continue
                    fill_pct = (
                        random.uniform(0.40, 0.75) if partial_roll < 0.60
                        else random.uniform(0.85, 1.0)
                    )
                    # v1.0.82 (BUG-N31): size MUST be computed from tokens, not
                    # from size_usdc (which was derived from sell_price, not
                    # fillable_price). The previous v1.0.81 code did:
                    #     actual_size_usdc = size_usdc * fill_pct
                    # which, when divided by fillable_price in on_fill(), gave
                    #     tokens_computed = net_tokens * (sell_price / fillable_price) * fill_pct
                    # Since sell_price > fillable_price almost always (mid > bid),
                    # tokens_computed > net_tokens → oversell → phantom short +
                    # open_time reset (the very thing BUG-N30 was meant to fix).
                    # Fix: compute tokens first from the source of truth
                    # (tokens_to_sell = inv.net_tokens), then derive USD size
                    # from the execution price (fillable_price).
                    tokens_filled = tokens_to_sell * fill_pct
                    actual_size_usdc = tokens_filled * fillable_price
                    if actual_size_usdc < 1.0:
                        continue  # too small after partial — wait for full attempt

                    await self._record_fill(
                        token_id, "SELL", fillable_price, actual_size_usdc, market_name,
                        level=99,  # level 99 = liquidation
                        mid_at_fill=book.mid,
                        is_liquidation=True,
                        exit_path=tier,
                    )
                    self._liquidation_count += 1
                    log.info(
                        "liquidation_paper_filled",
                        market=market_name,
                        tier=tier,
                        sell_price=round(sell_price, 4),
                        fillable_price=round(fillable_price, 4),
                        fill_pct=round(fill_pct, 3),
                        size_usdc=round(actual_size_usdc, 2),
                        age_sec=round(age_sec, 0),
                    )
            else:
                accepted, filled_now = await self._submit_immediate_order(
                    token_id,
                    "SELL",
                    sell_price,
                    size_usdc,
                    market_name,
                    level=99,
                    mid_at_place=book.mid,
                    exit_path=tier,
                )
                if accepted:
                    log.info(
                        "liquidation_order_placed_live",
                        market=market_name,
                        tier=tier,
                        requested_price=round(sell_price, 4),
                        realistic_exit_price=round(realistic_exit_price, 4),
                        requested_size_usdc=round(size_usdc, 2),
                        fill_confirmed=filled_now,
                        loss_cents=round(loss_cents, 2),
                    )
                else:
                    log.warning(
                        "liquidation_order_failed_live",
                        market=market_name,
                        tier=tier,
                        sell_price=round(sell_price, 4),
                        size_usdc=round(size_usdc, 2),
                        reason="FAK sell rejected; position remains open",
                    )

    async def _cleanup_orphaned_positions(self) -> None:
        """v1.0.50 FIX (BUG-3): clean up positions on markets no longer in books.

        When markets are replaced (via _replace_non_quotable_markets or
        manual /markets/replace), old positions may remain in
        inventory.inventories if they had open tokens. These "orphaned"
        positions:
          - Can't be liquidated (no book → no market_bid)
          - Can't hit pre-resolution exit (we don't track end_date after replace)
          - Stay forever, cluttering inventory + falsely inflating inventory_value

        This method:
          1. Finds positions where token_id NOT in self.clob.books
          2. If net_tokens == 0 (flat) → remove from inventory (just cleanup)
          3. If net_tokens != 0 (open position) → log warning, attempt to
             re-fetch book once; if still no book, mark as orphaned and
             leave (can't liquidate without market data).
        """
        orphaned_tids: list[str] = []
        for tid, inv in list(self.inventory.inventories.items()):
            if tid in self.clob.books:
                continue  # not orphaned
            if abs(inv.net_tokens) <= 0.0001:
                # Flat position on orphaned market → safe to remove
                orphaned_tids.append(tid)
                log.info(
                    "orphaned_position_removed_flat",
                    token=tid[:12],
                    market=inv.market_name[:40] if inv.market_name else "?",
                    realized_pnl=round(inv.realized_pnl, 4),
                )
            else:
                # Open position on orphaned market → can't liquidate without book
                log.warning(
                    "orphaned_position_open",
                    token=tid[:12],
                    market=inv.market_name[:40] if inv.market_name else "?",
                    net_tokens=round(inv.net_tokens, 4),
                    avg_entry=round(inv.avg_entry_price, 4),
                    realized_pnl=round(inv.realized_pnl, 4),
                    reason="market no longer in books; position will resolve at market close",
                )

        for tid in orphaned_tids:
            inv = self.inventory.inventories.pop(tid, None)
            if inv:
                # Persist the realized P&L to daily_pnl (already counted in
                # inv.realized_pnl, but we log it for audit)
                log.info(
                    "orphaned_inventory_cleaned",
                    token=tid[:12],
                    final_realized_pnl=round(inv.realized_pnl, 4),
                )
            # Also clean up pricing/risk state for this token
            self._as_calc.clear(tid)
            self._kyle.clear(tid)
            self.risk.adverse_selection.clear(tid)
            self.risk.circuit_breakers.clear_token(tid)
            # Remove from active_quotes if present (shouldn't be, but just in case)
            self.active_quotes.pop(tid, None)

    # v1.0.144: Reconcile orphaned positions (Claude Section 1).
    # Orphaned = positions on markets no longer in self.clob.books.
    # These positions:
    #   - Cannot be liquidated (no book → no market_bid)
    #   - Were NOT being checked for resolution (only _process_market did that)
    #   - Stayed forever as phantom inventory, inflating total_exposure
    # This method checks each orphaned position against Gamma API for resolution.
    # If resolved: settle the position (YES → $1/token credit, NO → $0) and remove.
    async def _merge_paper_complete_sets(self) -> int:
        """Merge all matched PAPER YES+NO balances into $1 complete sets.

        This is a local ledger operation used for PAPER acceptance and hedge
        recovery. LIVE deliberately does nothing until a venue/on-chain merge
        implementation can return authoritative transaction confirmation.
        """
        if not settings.paper_trading or not settings.paper_auto_merge_complete_sets:
            return 0
        if not self._condition_pairs:
            self._build_hedging_pairs()

        merged_count = 0
        for condition_id, pair in list(self._condition_pairs.items()):
            yes_token = pair.get("yes", "")
            no_token = pair.get("no", "")
            sets, payout, realized_pnl = self.inventory.on_complete_set_merge(
                yes_token, no_token
            )
            if sets <= 0:
                continue
            merged_count += 1
            self._fill_count += 1
            FILLS_TOTAL.labels(side="SELL", mode="PAPER").inc()
            yes_name = self.inventory.inventories.get(yes_token)
            no_name = self.inventory.inventories.get(no_token)
            market_name = (
                (yes_name.market_name if yes_name else "")
                or (no_name.market_name if no_name else "")
                or str(condition_id)
            )
            log.info(
                "paper_complete_set_merged",
                condition=str(condition_id)[:40],
                sets=round(sets, 6),
                payout=round(payout, 6),
                realized_pnl=round(realized_pnl, 6),
                bankroll=round(self.inventory.bankroll, 6),
            )
            await self._persist_trade(
                yes_token,
                "SELL",
                1.0,
                payout,
                realized_pnl,
                0.0,
                market_name,
                0,
                True,
                exit_path="PAPER_COMPLETE_SET_MERGE",
                size_tokens=sets,
            )
            for token_id in (yes_token, no_token):
                inv = self.inventory.inventories.get(token_id)
                if inv is not None and abs(inv.net_tokens) <= 0.000001:
                    self.inventory.inventories.pop(token_id, None)
                self.active_quotes.pop(token_id, None)
                self._as_calc.clear(token_id)
                self._kyle.clear(token_id)
                self.risk.adverse_selection.clear(token_id)
                self.risk.circuit_breakers.clear_token(token_id)
        return merged_count

    async def _reconcile_orphaned_positions(self) -> None:
        """Merge complete PAPER sets and redeem resolved PAPER inventory."""
        if settings.paper_trading and settings.paper_auto_merge_complete_sets:
            await self._merge_paper_complete_sets()
        if settings.orphaned_reconcile_interval_sec <= 0:
            return  # disabled
        for tid, inv in list(self.inventory.inventories.items()):
            # Skip flat positions
            if abs(inv.net_tokens) <= 0.0001:
                continue
            # v1.0.158 FIX (diagnostic §3): a market can be RESOLVED yet still
            # sit in clob.books — then it is not an "orphan" (this loop used to
            # skip it outright) and it is not tradable either (its book stopped
            # updating), so the pre-resolution handler spun forever on dead data
            # and the position hung between two handlers. Live case: XMR resolved
            # at 16:00, book frozen 2.4h, $0.011 dust stuck.
            # Now: still in books BUT the book is long stale → reconcile it too.
            if tid in self.clob.books:
                book = self.clob.books.get(tid)
                stale_sec = (
                    time.monotonic() - book.last_update
                    if book and book.last_update
                    else 0.0
                )
                if stale_sec <= settings.orphaned_book_stale_sec:
                    continue  # live market — normal handlers own it
                log.warning(
                    "position_on_stale_book_reconcile_candidate",
                    token=tid[:12],
                    market=inv.market_name[:30] if inv.market_name else "?",
                    book_stale_sec=round(stale_sec, 0),
                    net_tokens=round(inv.net_tokens, 4),
                    reason="book dead but market still in books — try to settle",
                )
            # v1.0.144: check resolution via Gamma API
            market_status = await self.clob.fetch_market_status(tid)
            if not market_status:
                log.debug(
                    "orphaned_reconcile_no_status",
                    token=tid[:12],
                    market=inv.market_name[:30] if inv.market_name else "?",
                )
                continue
            if not market_status.get("is_resolved"):
                # v1.0.144: log max_partial_wait warning (Claude Section 3)
                if settings.max_partial_wait_sec > 0 and inv.last_fill_time > 0:
                    age_sec = time.monotonic() - inv.last_fill_time
                    if age_sec > settings.max_partial_wait_sec:
                        position_value = abs(inv.net_tokens * inv.avg_entry_price)
                        log.warning(
                            "partial_stuck_below_minimum",
                            token=tid[:12],
                            market=inv.market_name[:30] if inv.market_name else "?",
                            age_hours=round(age_sec / 3600, 1),
                            value_usdc=round(position_value, 2),
                            reason="Cannot sell below $5 exchange minimum. "
                                   "Waiting for more fills or market resolution.",
                        )
                continue
            # PAPER may settle atomically in the local ledger.  LIVE must
            # retain the outcome tokens until redemption and wallet balance
            # are confirmed; resolution alone is not a cash receipt.
            resolved_price = market_status.get("resolved_price", 0.0)
            if not settings.paper_trading:
                first_seen = tid not in self._live_resolved_waiting_redeem
                self._live_resolved_waiting_redeem.add(tid)
                if first_seen:
                    log.warning(
                        "resolved_position_waiting_redeem_confirmation",
                        token=tid[:12],
                        market=inv.market_name[:40] if inv.market_name else "?",
                        net_tokens=round(inv.net_tokens, 6),
                        resolved_price=resolved_price,
                        reason=(
                            "LIVE accounting is unchanged until redeem/merge "
                            "and wallet balance are confirmed"
                        ),
                    )
                continue

            if not settings.paper_auto_redeem_resolved:
                log.warning(
                    "paper_resolved_position_waiting_manual_redeem",
                    token=tid[:12],
                    market=inv.market_name[:40] if inv.market_name else "?",
                    net_tokens=round(inv.net_tokens, 6),
                    resolved_price=resolved_price,
                )
                continue

            tokens, payout, realized_pnl = self.inventory.on_settlement(
                tid, resolved_price
            )
            if tokens <= 0:
                continue
            settle_price = 1.0 if resolved_price >= 0.5 else 0.0
            cost_basis = payout - realized_pnl
            log.info(
                "orphaned_position_resolved",
                token=tid[:12],
                market=inv.market_name[:40] if inv.market_name else "?",
                net_tokens=round(tokens, 4),
                resolved_price=settle_price,
                payout=round(payout, 4),
                cost_basis=round(cost_basis, 4),
                realized_pnl=round(realized_pnl, 4),
            )
            self._fill_count += 1
            FILLS_TOTAL.labels(side="SELL", mode="PAPER").inc()
            await self._persist_trade(
                tid,
                "SELL",
                settle_price,
                payout,
                realized_pnl,
                0.0,
                inv.market_name or "orphaned",
                0,
                False,
                exit_path="PAPER_REDEEM",
                size_tokens=tokens,
            )
            # on_settlement cleared the balance.  Removing the empty
            # container makes a second reconciliation pass a strict no-op.
            if abs(inv.net_tokens) <= 0.000001:
                self.inventory.inventories.pop(tid, None)
            # Clean up pricing/risk state
            self._as_calc.clear(tid)
            self._kyle.clear(tid)
            self.risk.adverse_selection.clear(tid)
            self.risk.circuit_breakers.clear_token(tid)
            self.active_quotes.pop(tid, None)

    # ── Fill recording ────────────────────────────────────────────────────

    async def _record_confirmed_execution(
        self,
        *,
        token_id: str,
        side: str,
        market_name: str,
        price: float,
        contracts_gross: float,
        contracts_net: float,
        usd_gross: float,
        usd_net: float,
        fee_usdc: float,
        level: int = 1,
        is_taker: bool = False,
        is_hedge: bool = False,
        exit_path: str = "",
        mid_at_fill: float | None = None,
        fill_verification: str | None = None,
        cycle_id: int = 0,
    ) -> None:
        """Record an authoritative exchange delta exactly once.

        Limitless BUY fees reduce outcome tokens; SELL fees reduce USDC.
        Keeping token and cash deltas separate prevents both phantom shares
        and double-counted fees.
        """
        if contracts_gross <= 0 or usd_gross <= 0:
            return
        if side == "BUY":
            token_amount = contracts_net if contracts_net > 0 else contracts_gross
            cash_amount = usd_gross
        else:
            token_amount = contracts_gross
            cash_amount = usd_net if usd_net > 0 else max(0.0, usd_gross - fee_usdc)
        if token_amount <= 0 or cash_amount < 0:
            return

        realized_net = self.inventory.on_execution(
            token_id, side, token_amount, cash_amount, market_name
        )
        gas_cost = (
            settings.paper_gas_cost_usdc
            if settings.paper_trading
            else settings.live_gas_cost_usdc
        )
        self.inventory.record_cost(gas_cost)
        realized_gross = (
            realized_net + fee_usdc if side == "SELL" else realized_net
        )
        fees_total = fee_usdc + gas_cost

        self._fill_count += 1
        FILLS_TOTAL.labels(
            side=side,
            mode="PAPER" if settings.paper_trading else "LIVE",
        ).inc()
        if side == "SELL":
            if is_taker:
                self._exit_taker_count += 1
            else:
                self._exit_maker_count += 1
        elif not is_hedge:
            self._record_adverse_probe(token_id, price)

        log.info(
            "confirmed_exchange_fill",
            market=market_name[:50],
            side=side,
            price=round(price, 6),
            contracts_gross=round(contracts_gross, 6),
            contracts_net=round(contracts_net, 6),
            usd_gross=round(usd_gross, 6),
            usd_net=round(usd_net, 6),
            fee_usdc=round(fee_usdc, 6),
            gas_usdc=round(gas_cost, 6),
            pnl_net=round(realized_net - gas_cost, 6),
            exit_path=exit_path,
        )
        await self._persist_trade(
            token_id,
            side,
            price,
            usd_gross,
            realized_gross,
            fees_total,
            market_name,
            level,
            is_hedge,
            fee_usdc=fee_usdc,
            gas_usdc=gas_cost,
            is_taker=is_taker,
            exit_path=exit_path,
            size_tokens=contracts_gross,
            fill_verification=fill_verification,
            cycle_id=cycle_id,
        )
        self.risk.on_fill(
            token_id, side, price, mid_at_fill if mid_at_fill is not None else price
        )

    async def _record_fill(
        self,
        token_id: str,
        side: str,
        price: float,
        size_usdc: float,
        market_name: str,
        level: int = 1,
        mid_at_fill: float | None = None,
        is_liquidation: bool = False,
        is_hedge: bool = False,
        _skip_hedge: bool = False,
        exit_path: str = "",
        fill_verification: str | None = None,
        cycle_id: int = 0,
        queue_ahead_tokens: float = 0.0,
        inferred_through_tokens: float = 0.0,
        fill_evidence_source: str = "",
    ) -> None:
        """Record a fill in inventory + DB. Triggers hedge if applicable."""
        # CRITICAL: Balance/short checks for hedge fills too
        # Hedge fills bypass the quote-placement checks (they come from _attempt_active_hedge)
        # but still must respect balance and short limits
        if is_hedge:
            inv_check = self.inventory.get_inventory(token_id)
            if side == "BUY":
                # Hedge BUY: check bankroll has enough cash
                if self.inventory.bankroll < size_usdc:
                    log.warning(
                        "hedge_fill_skipped_insufficient_balance",
                        market=market_name[:30],
                        side=side,
                        size_usdc=round(size_usdc, 2),
                        bankroll=round(self.inventory.bankroll, 2),
                    )
                    return
            elif side == "SELL":
                # Hedge SELL: check we have tokens to sell (no shorting allowed)
                tokens_to_sell = size_usdc / max(price, 0.001)
                if inv_check.net_tokens < tokens_to_sell:
                    log.warning(
                        "hedge_fill_skipped_no_tokens",
                        market=market_name[:30],
                        side=side,
                        net_tokens=round(inv_check.net_tokens, 4),
                        tokens_to_sell=round(tokens_to_sell, 4),
                        reason="insufficient tokens for hedge (LIVE API would reject)",
                    )
                    return

        realized = self.inventory.on_fill(token_id, side, price, size_usdc, market_name)
        if exit_path == "FAST_FLAT_ENTRY":
            inv_cycle = self.inventory.get_inventory(token_id)
            inv_cycle.fast_flat_cycle_initial_tokens = max(
                inv_cycle.fast_flat_cycle_initial_tokens, inv_cycle.net_tokens
            )

        # Costs
        # v1.0.73 (BUG-N24): Gas separated from profit.
        # v1.0.152: fee/gas split. Taker fills (FAK exits: profit sniper,
        # liquidations, NO-hedge — all arrive with is_liquidation=True) pay
        # the taker fee on fee-bearing markets; maker fills pay zero fee on
        # Limitless. Gas applies to every fill. fees_usdc keeps the TOTAL
        # for backwards compat; the split is persisted separately.
        gas_cost = settings.paper_gas_cost_usdc if settings.paper_trading else settings.live_gas_cost_usdc
        is_taker = bool(is_liquidation)
        # v1.0.153: exit-path split for the Капчур% metric (Path A = maker
        # ask-fill, free; taker = FAK exits: sniper/liquidation/hedge)
        if side == "SELL":
            if is_taker:
                self._exit_taker_count += 1
            else:
                self._exit_maker_count += 1
        elif side == "BUY" and not is_hedge:
            # v1.0.155: schedule the +60s adverse probe for this entry
            self._record_adverse_probe(token_id, price)
        taker_fee = (
            size_usdc / max(price, 0.001) * self._taker_fee_per_token(token_id, price)
            if is_taker
            else 0.0
        )
        fees_usdc = gas_cost + taker_fee
        realized_net = realized - fees_usdc  # kept for backwards-compat logging
        # Costs are part of the daily NET stop, not merely a dashboard
        # deduction.  Otherwise a gross-flat strategy can bleed through fees
        # without ever tripping MAX_DAILY_LOSS_USD.
        self.inventory.record_cost(fees_usdc)

        self._fill_count += 1
        FILLS_TOTAL.labels(side=side, mode="LIVE" if not settings.paper_trading else "PAPER").inc()

        if mid_at_fill is None:
            mid_at_fill = price

        log.info(
            "fill",
            market=market_name[:50],
            side=side,
            price=round(price, 4),
            size_usdc=round(size_usdc, 2),
            pnl_net=round(realized_net, 4),
            pnl_gross=round(realized, 4),
            fees=round(fees_usdc, 4),
            inv_after=round(self.inventory.get_inventory(token_id).net_tokens, 4),
            level=level,
            mode="LIVE" if not settings.paper_trading else "PAPER",
            liquidation=is_liquidation,
            hedge=is_hedge,
            fill_verification=(
                fill_verification
                or ("verified" if not settings.paper_trading else "inferred")
            ),
            cycle_id=cycle_id,
            queue_ahead_tokens=queue_ahead_tokens,
            inferred_through_tokens=inferred_through_tokens,
            fill_evidence_source=fill_evidence_source,
        )

        # Persist to DB
        # v1.0.73: pnl_usdc = gross realized (no gas), fees_usdc = gas (separate)
        # v1.0.152: + fee/gas split and taker flag
        await self._persist_trade(
            token_id, side, price, size_usdc, realized, fees_usdc, market_name,
            level, is_hedge,
            fee_usdc=taker_fee, gas_usdc=gas_cost, is_taker=is_taker,
            exit_path=exit_path,
            fill_verification=fill_verification,
            cycle_id=cycle_id,
        )

        # Update adverse selection tracking
        self.risk.on_fill(token_id, side, price, mid_at_fill)

        # Trigger hedge (Yes/No pair) — only on real fills, not on hedge fills
        if (
            settings.hedging_enabled
            and settings.hedging_active_enabled
            and not _skip_hedge
            and not is_liquidation
        ):
            try:
                await self._attempt_active_hedge(token_id, side, size_usdc, market_name, price)
            except Exception as e:
                log.debug("hedge_failed", error=str(e))

    async def _attempt_active_hedge(
        self,
        filled_token_id: str,
        filled_side: str,
        filled_size_usdc: float,
        market_name: str,
        filled_price: float,
    ) -> None:
        """Hedge by trading the paired Yes/No token (YES+NO=$1, risk-free).

        When we BUY YES at price P_yes, we can also BUY NO at P_no.
        If P_yes + P_no < 1.0, the position is risk-free (one side always pays $1).
        Same for SELL: SELL YES + SELL NO when P_yes_bid + P_no_bid > 1.0.
        """
        if not settings.paper_trading and settings.exchange == "limitless":
            log.debug(
                "active_hedge_blocked_limitless_live",
                reason="paired Limitless execution/merge is not verified",
            )
            return
        paired_token = self._get_paired_token(filled_token_id)
        if not paired_token:
            log.debug(
                "hedge_skipped_no_pair",
                filled_market=market_name[:30],
                filled_side=filled_side,
                reason="no paired Yes/No token found",
            )
            return
        paired_book = self.clob.books.get(paired_token)
        if not paired_book or not paired_book.bids or not paired_book.asks:
            log.debug(
                "hedge_skipped_no_book",
                filled_market=market_name[:30],
                reason="paired token has no order book",
            )
            return
        paired_info = self.clob.markets.get(paired_token)
        paired_name = paired_info.question[:50] if paired_info else paired_token[:12]

        if filled_side == "BUY":
            hedge_side = "BUY"
            hedge_price = paired_book.best_ask + 0.003
            if hedge_price > 0.99:
                log.debug("hedge_skipped_price", reason="hedge_price > 0.99")
                return
            # Profitability check: YES_ask + NO_ask must be < $1.00
            total_cost = filled_price + paired_book.best_ask
            if total_cost >= 1.0:
                log.debug(
                    "hedge_skipped_unprofitable",
                    filled_price=round(filled_price, 4),
                    paired_ask=round(paired_book.best_ask, 4),
                    total=round(total_cost, 4),
                    reason="YES_ask + NO_ask >= $1.00 (no arbitrage)",
                )
                return
            profit_cents = (1.0 - total_cost) * 100
        else:
            hedge_side = "SELL"
            hedge_price = paired_book.best_bid - 0.003
            if hedge_price < 0.01:
                log.debug("hedge_skipped_price", reason="hedge_price < 0.01")
                return
            # Profitability check: YES_bid + NO_bid must be > $1.00
            total_revenue = filled_price + paired_book.best_bid
            if total_revenue <= 1.0:
                log.debug(
                    "hedge_skipped_unprofitable",
                    filled_price=round(filled_price, 4),
                    paired_bid=round(paired_book.best_bid, 4),
                    total=round(total_revenue, 4),
                    reason="YES_bid + NO_bid <= $1.00 (no arbitrage)",
                )
                return
            profit_cents = (total_revenue - 1.0) * 100

        hedge_size = filled_size_usdc
        if hedge_size < 1.0:
            return

        # v1.0.46 FIX (BUG-4): pre-flight check BEFORE placing the LIVE
        # hedge order. Previously the check lived inside _record_fill(),
        # which is called AFTER place_order() — meaning the real SELL
        # order was sent to Polymarket, possibly filled, and then the
        # local inventory update was silently skipped (because we had
        # no tokens to sell). Result: position moved on-chain but the
        # bot's inventory never reflected it — a silent financial leak.
        #
        # v1.0.47 NOTE: Polymarket DOES support shorting (SELL without
        # tokens creates a short with $1 collateral per contract). So
        # the API would NOT reject this order — it would execute and
        # open a short position. However, opening a short via "hedge"
        # logic is NOT a real hedge: shorting the paired token is
        # economically equivalent to going long on the original token
        # (short NO = long YES), so it doubles our risk instead of
        # neutralizing it. We therefore block it: only hedge SELL when
        # we actually own the paired token (closing an existing long).
        #
        # We check BEFORE place_order():
        #   - hedge SELL: need enough tokens on the paired market
        #     (selling without tokens would open an uncontrolled short)
        #   - hedge BUY:  need enough bankroll
        # If the check fails, we DON'T place the order at all.
        if not settings.paper_trading:
            paired_inv_check = self.inventory.get_inventory(paired_token)
            if hedge_side == "SELL":
                tokens_needed = hedge_size / max(hedge_price, 0.001)
                if paired_inv_check.net_tokens < tokens_needed:
                    log.warning(
                        "hedge_skipped_insufficient_tokens_preflight",
                        filled_market=market_name[:30],
                        paired_market=paired_name[:30],
                        hedge_side=hedge_side,
                        paired_net_tokens=round(paired_inv_check.net_tokens, 4),
                        tokens_needed=round(tokens_needed, 4),
                        reason="would open uncontrolled short (Polymarket supports it with $1 collateral, but bot policy blocks shorts via hedge)",
                    )
                    return
            else:  # hedge_side == "BUY"
                if self.inventory.bankroll < hedge_size:
                    log.warning(
                        "hedge_skipped_insufficient_balance_preflight",
                        filled_market=market_name[:30],
                        paired_market=paired_name[:30],
                        hedge_side=hedge_side,
                        hedge_size=round(hedge_size, 2),
                        bankroll=round(self.inventory.bankroll, 2),
                        reason="would send LIVE BUY with insufficient bankroll",
                    )
                    return

        self._hedge_attempts += 1

        log.info(
            "hedge_attempt",
            filled_market=market_name[:30],
            filled_side=filled_side,
            filled_price=round(filled_price, 4),
            paired_market=paired_name[:30],
            hedge_side=hedge_side,
            hedge_price=round(hedge_price, 4),
            profit_cents=round(profit_cents, 2),
            size_usdc=round(hedge_size, 2),
        )

        if settings.paper_trading:
            if random.random() < 0.80:
                actual_price = hedge_price + random.uniform(-0.0005, 0.0005)
                actual_price = max(0.01, min(0.99, actual_price))
                await self._record_fill(
                    paired_token, hedge_side, actual_price, hedge_size, paired_name,
                    _skip_hedge=True, is_hedge=True,
                )
                self._hedge_fills += 1
                log.info(
                    "hedge_filled",
                    paired_market=paired_name[:40],
                    side=hedge_side,
                    price=round(actual_price, 4),
                    size_usdc=round(hedge_size, 2),
                    profit_cents=round(profit_cents, 2),
                )
            else:
                log.debug("hedge_not_filled", reason="20% paper rejection")
        else:
            accepted, filled_now = await self._submit_immediate_order(
                paired_token,
                hedge_side,
                hedge_price,
                hedge_size,
                paired_name,
                level=1,
                mid_at_place=paired_book.mid,
                exit_path="ACTIVE_HEDGE",
                is_liquidation=False,
                is_hedge=True,
            )
            if filled_now:
                self._hedge_fills += 1
            if not accepted:
                log.warning(
                    "hedge_failed_live",
                    paired_market=paired_name[:40],
                    side=hedge_side,
                    hedge_price=round(hedge_price, 4),
                    size_usdc=round(hedge_size, 2),
                )

    def _build_hedging_pairs(self) -> None:
        """Link Yes and No tokens sharing the same condition_id.

        Also supports fallback pairing by identical question text when
        condition_id is missing (some markets on Polymarket don't expose it
        via the events API).
        """
        self._condition_pairs.clear()
        by_condition: dict[str, list[str]] = {}
        by_question: dict[str, list[str]] = {}

        for tid, info in self.clob.markets.items():
            cid = info.condition_id
            if cid:
                by_condition.setdefault(cid, []).append(tid)
            # Fallback: group by question text (Yes/No outcomes share question)
            if info.question:
                by_question.setdefault(info.question, []).append(tid)

        # Primary: by condition_id
        for cid, tokens in by_condition.items():
            if len(tokens) == 2:
                self._register_pair(cid, tokens)

        # Fallback: by question text (only add if not already paired via condition_id)
        already_paired = set()
        for pair in self._condition_pairs.values():
            already_paired.add(pair["yes"])
            already_paired.add(pair["no"])

        for q, tokens in by_question.items():
            if len(tokens) == 2 and tokens[0] not in already_paired:
                # Use question hash as key to avoid collisions
                key = f"q:{hash(q)}"
                self._register_pair(key, tokens)

        if self._condition_pairs:
            log.info(
                "hedging_pairs_built",
                pairs=len(self._condition_pairs),
                by_condition=sum(1 for k in self._condition_pairs if not k.startswith("q:")),
                by_question=sum(1 for k in self._condition_pairs if k.startswith("q:")),
            )

    def _register_pair(self, key: str, tokens: list[str]) -> None:
        """Register a Yes/No pair, determining which is Yes by outcome field."""
        info0 = self.clob.markets.get(tokens[0])
        info1 = self.clob.markets.get(tokens[1])
        if not info0 or not info1:
            return
        # Determine Yes/No by outcome field (case-insensitive)
        out0 = (info0.outcome or "").lower().strip()
        out1 = (info1.outcome or "").lower().strip()
        if out0 == "yes" and out1 == "no":
            self._condition_pairs[key] = {"yes": tokens[0], "no": tokens[1]}
        elif out0 == "no" and out1 == "yes":
            self._condition_pairs[key] = {"yes": tokens[1], "no": tokens[0]}
        else:
            # Fallback: token with higher mid price = "Yes" (probability of event)
            if info0 and info1:
                yes_token = tokens[0] if self.clob.books.get(tokens[0]) and self.clob.books[tokens[0]].mid > 0.5 else tokens[1]
                no_token = tokens[1] if yes_token == tokens[0] else tokens[0]
                self._condition_pairs[key] = {"yes": yes_token, "no": no_token}

    def _get_paired_token(self, token_id: str) -> str | None:
        for pair in self._condition_pairs.values():
            if pair["yes"] == token_id:
                return pair["no"]
            if pair["no"] == token_id:
                return pair["yes"]
        return None

    # ── DB persistence ────────────────────────────────────────────────────

    async def _persist_trade(
        self,
        token_id: str,
        side: str,
        price: float,
        size_usdc: float,
        pnl: float,
        fees_usdc: float,
        market_name: str,
        level: int,
        is_hedge: bool,
        fee_usdc: float = 0.0,
        gas_usdc: float = 0.0,
        is_taker: bool = False,
        exit_path: str = "",
        size_tokens: float | None = None,
        fill_verification: str | None = None,
        cycle_id: int = 0,
        queue_ahead_tokens: float = 0.0,
        inferred_through_tokens: float = 0.0,
        fill_evidence_source: str = "",
    ) -> None:
        try:
            from app.core.db import AsyncSessionLocal

            async with AsyncSessionLocal() as db:
                t = Trade(
                    exit_path=exit_path,
                    fill_verification=(
                        fill_verification
                        or ("verified" if not settings.paper_trading else "inferred")
                    ),
                    cycle_id=cycle_id,
                    queue_ahead_tokens=queue_ahead_tokens,
                    inferred_through_tokens=inferred_through_tokens,
                    fill_evidence_source=fill_evidence_source,
                    market_id=token_id,
                    market_name=market_name,
                    condition_id=self.clob.markets.get(token_id, None).condition_id
                    if self.clob.markets.get(token_id)
                    else "",
                    side=Side.BUY if side == "BUY" else Side.SELL,
                    price=price,
                    size_usdc=size_usdc,
                    size_tokens=(
                        size_tokens
                        if size_tokens is not None
                        else size_usdc / max(price, 0.001)
                    ),
                    pnl_usdc=pnl,
                    fees_usdc=fees_usdc,
                    fee_usdc=fee_usdc,
                    gas_usdc=gas_usdc,
                    is_taker=1 if is_taker else 0,
                    inventory_after=self.inventory.get_inventory(token_id).net_tokens,
                    spread_cents=self._get_active_spread(token_id),
                    level=level,
                    mode=OrderMode.LIVE if not settings.paper_trading else OrderMode.PAPER,
                    is_hedge=is_hedge,
                )
                db.add(t)
                await db.commit()
        except Exception as e:
            log.debug("trade_persist_failed", error=str(e))

    def _get_active_spread(self, token_id: str) -> float | None:
        quotes = self.active_quotes.get(token_id)
        if not quotes:
            return None
        return quotes[0].spread_cents

    async def _db_cleanup_loop(self) -> None:
        """Every 10 minutes, prune old quotes + snapshots (keep last 1000 each)."""
        await asyncio.sleep(600)
        while self._running:
            try:
                from sqlalchemy import text

                from app.core.db import AsyncSessionLocal

                async with AsyncSessionLocal() as db:
                    await db.execute(
                        text(
                            "DELETE FROM mm_quotes WHERE id NOT IN "
                            "(SELECT id FROM mm_quotes ORDER BY id DESC LIMIT 1000)"
                        )
                    )
                    await db.execute(
                        text(
                            "DELETE FROM mm_snapshots WHERE id NOT IN "
                            "(SELECT id FROM mm_snapshots ORDER BY id DESC LIMIT "
                            f"{int(settings.mm_snapshot_keep_rows)})"
                        )
                    )
                    await db.execute(
                        text(
                            "DELETE FROM mm_metric_points WHERE id NOT IN "
                            "(SELECT id FROM mm_metric_points ORDER BY id DESC LIMIT 5000)"
                        )
                    )
                    await db.commit()
            except Exception as e:
                log.debug("db_cleanup_error", error=str(e))
            await asyncio.sleep(600)

    # v1.0.144: Orphaned position reconciliation loop (Claude Section 1).
    async def _reconcile_loop(self) -> None:
        """Periodically check orphaned positions for resolution."""
        interval = max(60.0, settings.orphaned_reconcile_interval_sec)
        await asyncio.sleep(interval)  # initial delay
        while self._running:
            try:
                await self._reconcile_orphaned_positions()
            except asyncio.CancelledError:
                break
            except Exception as e:
                log.warning("reconcile_loop_error", error=str(e))
            await asyncio.sleep(interval)

    # ── Status ────────────────────────────────────────────────────────────

    @property
    def status(self) -> dict:
        fast_state = self._fast_flat_state
        return {
            "cycle_count": self._cycle_count,
            "fill_count": self._fill_count,
            "round_trip_count": self._round_trip_count,
            "paper_opportunity_count": self._paper_opportunity_count,
            "paper_inferred_candidate_count": self._paper_inferred_candidate_count,
            "paper_random_candidate_count": self._paper_random_candidate_count,
            "limitless_public_trade_seq": int(
                getattr(self.clob, "public_trade_seq", 0) or 0
            ),
            "limitless_public_trades_buffered": sum(
                len(rows) for rows in getattr(self.clob, "_public_trades", {}).values()
            ),
            "liquidation_count": self._liquidation_count,  # v1.0.38
            # v1.0.150: headline exit metrics
            "profit_take_count": self._profit_take_count,
            "loss_liquidation_forced_count": self._loss_forced_count,
            # v1.0.151
            "no_hedge_count": self._no_hedge_count,
            # v1.0.155: adverse-rate rotation
            "adverse_banned_now": sum(
                1 for u in self._banned_markets.values() if time.monotonic() < u
            ),
            "adverse_ban_total": self._adverse_ban_count,
            # v1.0.153: capture quality
            "capture_pct_avg": (
                round(self._sniper_taken_pct_sum / self._sniper_fired_count, 1)
                if self._sniper_fired_count > 0
                else None
            ),
            "sniper_fired_count": self._sniper_fired_count,
            "exit_maker_count": self._exit_maker_count,
            "exit_taker_count": self._exit_taker_count,
            "ask_fill_share_pct": (
                round(
                    self._exit_maker_count
                    / (self._exit_maker_count + self._exit_taker_count)
                    * 100.0,
                    1,
                )
                if (self._exit_maker_count + self._exit_taker_count) > 0
                else None
            ),
            "active_quotes": sum(len(qs) for qs in self.active_quotes.values()),
            "pending_live_orders": len(self._pending_orders) if not settings.paper_trading else 0,
            "mode": "LIVE" if not settings.paper_trading else "PAPER",
            "strategy_mode": settings.strategy_mode,
            "fast_flat": (
                {
                    "token_id": fast_state.token_id,
                    "cycle_id": fast_state.cycle_id,
                    "phase": fast_state.phase,
                    "age_sec": round(time.monotonic() - fast_state.started_at, 1),
                    "had_position": fast_state.had_position,
                }
                if fast_state is not None
                else None
            ),
            "trading_paused": self._trading_paused,
            "halted": self.inventory.halted,
            "halt_reason": self.inventory.halt_reason,
            "hedge_attempts": self._hedge_attempts,
            "hedge_fills": self._hedge_fills,
            "hedge_fill_rate_pct": round(
                self._hedge_fills / max(self._hedge_attempts, 1) * 100, 1
            ),
            "adverse_global_cooldown_sec": round(
                self.risk.adverse_selection.global_cooldown_remaining(), 1
            ),
            "quotes_detail": [
                {
                    "token_id": q.token_id[:12],
                    "market_name": next(
                        (i.question[:30] for i in self.clob.markets.values()
                         if i.token_id == q.token_id),
                        q.token_id[:12]
                    ),
                    "level": q.level,
                    "bid": round(q.bid_price, 4) if q.bid_price is not None else None,
                    "ask": round(q.ask_price, 4) if q.ask_price is not None else None,
                    "mid": round(q.mid_at_place, 4),
                    "reservation": round(q.reservation_price, 4),
                    "optimal_spread_cents": round(q.spread_cents, 2),
                    "our_spread_cents": round(
                        (q.ask_price - q.bid_price) * 100, 2
                    ) if q.bid_price is not None and q.ask_price is not None else None,
                    # v1.0.99 (restored v1.0.110): full transparency fields
                    "market_bid": (
                        round(self.clob.books[q.token_id].best_bid, 4)
                        if q.token_id in self.clob.books and self.clob.books[q.token_id].best_bid > 0
                        else None
                    ),
                    "market_ask": (
                        round(self.clob.books[q.token_id].best_ask, 4)
                        if q.token_id in self.clob.books and self.clob.books[q.token_id].best_ask < 1
                        else None
                    ),
                    "avg_entry_price": (
                        round(self.inventory.get_inventory(q.token_id).avg_entry_price, 4)
                        if self.inventory.get_inventory(q.token_id).net_tokens != 0
                        else None
                    ),
                    "net_tokens": round(
                        self.inventory.get_inventory(q.token_id).net_tokens, 2
                    ),
                    "realistic_exit_price": None,  # computed in frontend
                    "realistic_profit_cents": None,  # computed in frontend
                    "bid_filled": q.bid_filled,
                    "ask_filled": q.ask_filled,
                    # v1.0.151: dashboard markers
                    "bid_mom_blocked": q.token_id in self._momentum_bid_blocked,
                    "ask_mom_blocked": q.token_id in self._momentum_ask_blocked,
                    "hedged": q.token_id in self._hedged_positions,
                    "age_sec": round(time.monotonic() - q.placed_at, 1),
                }
                for qs in self.active_quotes.values()
                for q in qs
            ],
        }
