"""Run the deterministic PAPER acceptance suite with the active interpreter."""
from __future__ import annotations

import subprocess
import sys


def main() -> int:
    cmd = [
        sys.executable,
        "-m",
        "pytest",
        "-q",
        "tests/integration/test_paper_acceptance.py",
    ]
    return subprocess.call(cmd)


if __name__ == "__main__":
    raise SystemExit(main())
