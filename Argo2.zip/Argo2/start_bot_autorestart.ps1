param(
    [int]$RestartDelaySeconds = 10,
    [string]$PythonExe = "python",
    [switch]$Once
)

$ErrorActionPreference = "Stop"
$botDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$logDir = Join-Path $botDir "logs"
$watchLog = Join-Path $logDir "watchdog.log"
New-Item -ItemType Directory -Path $logDir -Force | Out-Null
Set-Location -LiteralPath $botDir

function Write-WatchdogLog([string]$Message) {
    Add-Content -LiteralPath $watchLog -Encoding UTF8 -Value "$(Get-Date -Format o) $Message"
}

Write-WatchdogLog "watchdog started (dir=$botDir)"
do {
    Write-WatchdogLog "starting $PythonExe -m app.main"
    try {
        $process = Start-Process -FilePath $PythonExe `
            -ArgumentList @("-m", "app.main") `
            -WorkingDirectory $botDir -NoNewWindow -PassThru -Wait
        $exitCode = $process.ExitCode
    }
    catch {
        $exitCode = -1
        Write-WatchdogLog "launch failed: $($_.Exception.Message)"
    }
    Write-WatchdogLog "bot exited (code=$exitCode)"
    if (-not $Once) {
        Write-WatchdogLog "restart in ${RestartDelaySeconds}s"
        Start-Sleep -Seconds $RestartDelaySeconds
    }
} while (-not $Once)
