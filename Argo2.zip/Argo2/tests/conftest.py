"""
tests/conftest.py — Shared pytest fixtures.

Overrides settings to use paper mode + in-memory DB + test market data.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

# Ensure project root is on path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

# Override env BEFORE importing app modules
os.environ["PAPER_TRADING"] = "true"
os.environ["PAPER_BALANCE_USDC"] = "100.0"
# v1.0.150 FIX: the engine reads settings.mm_database_url whose env alias is
# MM_DATABASE_URL (app/core/config.py), NOT "DATABASE_URL". The old name here
# never took effect, so every pytest run wrote fixture trades (tok-A) into
# the production mm_bot.db, inflating fill_count and win-rate analytics.
os.environ["MM_DATABASE_URL"] = "sqlite+aiosqlite:///:memory:"
os.environ.setdefault("LOG_LEVEL", "WARNING")
os.environ.setdefault("LOG_FORMAT", "console")
os.environ["AUTO_PICK_MARKETS"] = "false"
os.environ["STRATEGY_MODE"] = "legacy"
os.environ.setdefault("ADMIN_PORT", "8765")
# v1.0.58 FIX (BUG-N3): tests in test_inventory_manager.py expect
# max_inventory_usdc = max($5, 25% × $100 bankroll) = $25. The .env ships
# MAX_INVENTORY_PCT_OF_BANKROLL=0.50 (production tuning), which makes the
# same math give $50 and breaks 4 inventory tests. Pin to 0.25 in tests so
# they are deterministic regardless of .env contents. Env vars take
# precedence over .env in pydantic-settings, so this override wins.
os.environ["MAX_INVENTORY_PCT_OF_BANKROLL"] = "0.25"

import pytest


@pytest.fixture
def settings_obj():
    """Fresh Settings instance for tests that mutate config."""
    from app.core.config import Settings

    return Settings()


@pytest.fixture
def sample_book():
    """A sample MarketBook with balanced bids/asks."""
    from app.services.clob_client import MarketBook, OrderLevel

    return MarketBook(
        token_id="test-token-123",
        bids=[
            OrderLevel(0.48, 100),
            OrderLevel(0.47, 200),
            OrderLevel(0.46, 150),
            OrderLevel(0.45, 300),
            OrderLevel(0.44, 250),
        ],
        asks=[
            OrderLevel(0.52, 100),
            OrderLevel(0.53, 200),
            OrderLevel(0.54, 150),
            OrderLevel(0.55, 300),
            OrderLevel(0.56, 250),
        ],
        last_price=0.50,
    )


@pytest.fixture
def imbalanced_book():
    """A heavily bid-heavy book (buyers aggressive → expect high Kyle lambda)."""
    from app.services.clob_client import MarketBook, OrderLevel

    return MarketBook(
        token_id="test-token-imb",
        bids=[
            OrderLevel(0.49, 1000),
            OrderLevel(0.48, 2000),
            OrderLevel(0.47, 3000),
            OrderLevel(0.46, 4000),
            OrderLevel(0.45, 5000),
        ],
        asks=[
            OrderLevel(0.51, 10),
            OrderLevel(0.52, 20),
            OrderLevel(0.53, 15),
            OrderLevel(0.54, 25),
            OrderLevel(0.55, 30),
        ],
        last_price=0.50,
    )


@pytest.fixture(autouse=True)
async def _dispose_test_database_engine():
    """Close aiosqlite worker threads before each function event loop ends."""
    yield
    from app.core.db import engine

    await engine.dispose()
