"""Deterministic offline PAPER acceptance for Limitless FAST_FLAT.

These tests exercise the complete core lifecycle without external DNS/API:
entry, maker exit, partial remainder handling, stale-book gating, restart
recovery, complete-set merge, and resolved-token redemption.
"""
from __future__ import annotations

import json
import time
from unittest.mock import AsyncMock

import pytest
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine

import app.services.market_maker as mm_mod
from app.core.config import settings
from app.core.db import Base
from app.db import models as _models  # noqa: F401  # register metadata
from app.services.clob_client import MarketBook, MarketInfo, OrderLevel
from app.services.inventory_manager import Inventory, InventoryManager
from app.services.limitless_client import LimitlessService
from app.services.market_maker import MarketMaker
from app.services.risk.risk_manager import RiskManager


def _configure(monkeypatch) -> None:
    monkeypatch.setattr(settings, "paper_trading", True)
    # These legacy acceptance scenarios deliberately exercise the retained
    # RNG replay model. Match #2 defaults to conservative price-through fills.
    monkeypatch.setattr(settings, "paper_fill_model", "random")
    monkeypatch.setattr(settings, "exchange", "limitless")
    monkeypatch.setattr(settings, "strategy_mode", "fast_flat")
    monkeypatch.setattr(settings, "fast_flat_multilevel_enabled", False)
    monkeypatch.setattr(settings, "fast_flat_15m_profile_enabled", False)
    monkeypatch.setattr(settings, "fast_flat_broader_markets_enabled", False)
    monkeypatch.setattr(settings, "fast_flat_order_size_usdc", 2.0)
    monkeypatch.setattr(settings, "fast_flat_cash_reserve_usdc", 0.0)
    monkeypatch.setattr(settings, "fast_flat_cash_reserve_pct", 0.0)
    monkeypatch.setattr(settings, "fast_flat_min_spread_cents", 2.0)
    monkeypatch.setattr(settings, "fast_flat_max_spread_cents", 5.0)
    monkeypatch.setattr(settings, "fast_flat_min_top_depth_mult", 1.0)
    monkeypatch.setattr(settings, "fast_flat_min_ttr_sec", 0.0)
    monkeypatch.setattr(settings, "fast_flat_max_book_age_sec", 3.0)
    monkeypatch.setattr(settings, "fast_flat_target_profit_usdc", 0.02)
    monkeypatch.setattr(settings, "fast_flat_profit_fak_enabled", True)
    monkeypatch.setattr(settings, "fast_flat_profit_fak_after_sec", 90.0)
    monkeypatch.setattr(settings, "fast_flat_profit_fak_slippage_cents", 0.0)
    monkeypatch.setattr(settings, "fast_flat_rescue_after_sec", 90.0)
    monkeypatch.setattr(settings, "fast_flat_loss_budget_usdc", 0.05)
    monkeypatch.setattr(settings, "paper_gas_cost_usdc", 0.0)
    monkeypatch.setattr(settings, "paper_rejection_rate", 0.0)
    monkeypatch.setattr(settings, "paper_competition_rate", 0.0)
    monkeypatch.setattr(settings, "paper_fill_prob_base", 10.0)
    monkeypatch.setattr(settings, "paper_fill_prob_max", 1.0)
    monkeypatch.setattr(settings, "paper_auto_merge_complete_sets", True)
    monkeypatch.setattr(settings, "paper_auto_redeem_resolved", True)
    monkeypatch.setattr(settings, "orphaned_reconcile_interval_sec", 1.0)


def _book(token_id: str = "yes", *, bid: float = 0.45, ask: float = 0.48) -> MarketBook:
    return MarketBook(
        token_id=token_id,
        bids=[OrderLevel(bid, 100.0)],
        asks=[OrderLevel(ask, 100.0)],
        tick_size=0.01,
        min_order_size=0.1,
    )


def _add_market(
    clob: LimitlessService,
    book: MarketBook,
    *,
    condition_id: str = "condition-1",
    outcome: str = "Yes",
    question: str = "Acceptance market",
) -> None:
    clob.books[book.token_id] = book
    clob.markets[book.token_id] = MarketInfo(
        token_id=book.token_id,
        condition_id=condition_id,
        question=question,
        outcome=outcome,
        end_date_ts=time.time() + 3600,
        volume_24h=100_000.0,
        tick_size=book.tick_size,
    )


def _maker() -> tuple[MarketMaker, LimitlessService, InventoryManager]:
    clob = LimitlessService()
    inventory = InventoryManager()
    inventory.bankroll = 25.0
    inventory.starting_balance = 25.0
    maker = MarketMaker(clob, inventory, RiskManager(inventory, clob))
    maker._persist_trade = AsyncMock()
    return maker, clob, inventory


@pytest.mark.asyncio
@pytest.mark.integration
async def test_fast_flat_profitable_maker_round_trip(monkeypatch):
    _configure(monkeypatch)
    maker, clob, inventory = _maker()
    book = _book()
    _add_market(clob, book)

    # Deterministically accept every simulated maker fill at full size.
    monkeypatch.setattr(mm_mod.random, "random", lambda: 0.99)
    monkeypatch.setattr(mm_mod.random, "uniform", lambda _a, b: b)

    await maker._process_market(book.token_id, book)  # place entry
    assert maker.active_quotes[book.token_id][0].role == "ENTRY"

    await maker._process_market(book.token_id, book)  # fill entry + place exit
    inv = inventory.get_inventory(book.token_id)
    assert inv.net_tokens == pytest.approx(2.0 / 0.46)
    exit_quote = maker.active_quotes[book.token_id][0]
    assert exit_quote.role == "EXIT"
    assert exit_quote.size_usdc / exit_quote.ask_price == pytest.approx(inv.net_tokens)

    await maker._process_market(book.token_id, book)  # fill exit
    assert inventory.get_inventory(book.token_id).net_tokens == pytest.approx(0.0)
    assert inventory.bankroll > 25.0
    assert maker._round_trip_count == 1
    assert maker._fast_flat_state is None


@pytest.mark.asyncio
@pytest.mark.integration
async def test_partial_entry_cancels_remainder_and_exits_exact_tokens(monkeypatch):
    _configure(monkeypatch)
    maker, clob, inventory = _maker()
    book = _book()
    _add_market(clob, book)

    await maker._process_market(book.token_id, book)

    random_values = iter([0.99, 0.99, 0.99, 0.30])
    uniform_values = iter([0.0, 0.50])
    monkeypatch.setattr(mm_mod.random, "random", lambda: next(random_values))
    monkeypatch.setattr(mm_mod.random, "uniform", lambda _a, _b: next(uniform_values))

    await maker._process_market(book.token_id, book)

    partial_tokens = inventory.get_inventory(book.token_id).net_tokens
    assert partial_tokens == pytest.approx(1.0 / 0.46)
    exit_quote = maker.active_quotes[book.token_id][0]
    assert exit_quote.role == "EXIT"
    assert exit_quote.size_usdc / exit_quote.ask_price == pytest.approx(partial_tokens)
    assert not maker._fast_flat_pending(book.token_id, "ENTRY")

    monkeypatch.setattr(mm_mod.random, "random", lambda: 0.99)
    monkeypatch.setattr(mm_mod.random, "uniform", lambda _a, b: b)
    await maker._process_market(book.token_id, book)
    assert inventory.get_inventory(book.token_id).net_tokens == pytest.approx(0.0)
    assert maker._round_trip_count == 1


@pytest.mark.asyncio
@pytest.mark.integration
async def test_stale_restored_position_waits_then_recovers(monkeypatch):
    _configure(monkeypatch)
    maker, clob, inventory = _maker()
    book = _book()
    _add_market(clob, book)
    inventory.inventories[book.token_id] = Inventory(
        token_id=book.token_id,
        market_name="Acceptance market",
        net_tokens=4.0,
        avg_entry_price=0.45,
        open_time=0.0,
    )

    book.last_update = time.monotonic() - settings.fast_flat_max_book_age_sec - 1.0
    await maker._process_market(book.token_id, book)
    assert maker.active_quotes == {}
    assert inventory.inventories[book.token_id].open_time > 0

    book.last_update = time.monotonic()
    await maker._process_market(book.token_id, book)
    quote = maker.active_quotes[book.token_id][0]
    assert quote.role == "EXIT"
    assert quote.size_usdc / quote.ask_price == pytest.approx(4.0)


@pytest.mark.asyncio
@pytest.mark.integration
async def test_restart_restores_inventory_and_never_opens_second_entry(monkeypatch, tmp_path):
    _configure(monkeypatch)
    db_path = tmp_path / "restart.db"
    engine = create_async_engine(f"sqlite+aiosqlite:///{db_path}")
    Session = async_sessionmaker(engine, expire_on_commit=False)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    before = InventoryManager()
    before.starting_balance = 25.0
    before.bankroll = 23.0
    before.inventories["yes"] = Inventory(
        token_id="yes",
        market_name="Restart market",
        net_tokens=2.0 / 0.46,
        avg_entry_price=0.46,
        open_time=time.monotonic(),
        opened_at_epoch=time.time() - 3600.0,
        fast_flat_cycle_id=42,
        fast_flat_cycle_start_bankroll=25.0,
    )
    async with Session() as db:
        await before.save_state_to_db(db)

    after = InventoryManager()
    async with Session() as db:
        assert await after.load_state_from_db(db) is True
    assert after.bankroll == pytest.approx(23.0)
    assert after.inventories["yes"].net_tokens == pytest.approx(2.0 / 0.46)
    assert after.inventories["yes"].fast_flat_cycle_id == 42
    assert after.inventories["yes"].fast_flat_cycle_start_bankroll == pytest.approx(25.0)
    assert time.monotonic() - after.inventories["yes"].open_time >= 3599.0

    clob = LimitlessService()
    book = _book("yes")
    _add_market(clob, book, question="Restart market")
    maker = MarketMaker(clob, after, RiskManager(after, clob))
    maker._persist_trade = AsyncMock()

    lock = tmp_path / "RUNNING.lock"
    lock.write_text(json.dumps({"pid": 123, "ts": time.time() - 60}), encoding="utf-8")
    monkeypatch.setattr(mm_mod, "RUNNING_LOCK_PATH", lock)
    await maker._crash_recovery_check()
    assert maker._crash_recovery_active is False

    await maker._process_market("yes", book)
    # The preserved one-hour age makes rescue eligible immediately. Whether
    # it fills or rests as EXIT, restart must never create a second entry.
    quotes = maker.active_quotes.get("yes", [])
    assert all(q.role == "EXIT" and q.bid_price is None for q in quotes)
    assert after.inventories["yes"].net_tokens == 0 or quotes

    await engine.dispose()


@pytest.mark.asyncio
@pytest.mark.integration
async def test_complete_set_merge_is_automatic_and_idempotent(monkeypatch):
    _configure(monkeypatch)
    maker, clob, inventory = _maker()
    yes_book = _book("yes", bid=0.44, ask=0.47)
    no_book = _book("no", bid=0.50, ask=0.53)
    _add_market(clob, yes_book, condition_id="same", outcome="Yes", question="Pair")
    _add_market(clob, no_book, condition_id="same", outcome="No", question="Pair")

    inventory.bankroll = 7.8
    inventory.starting_balance = 10.0
    inventory.inventories["yes"] = Inventory(
        token_id="yes", market_name="Pair", net_tokens=3.0, avg_entry_price=0.40
    )
    inventory.inventories["no"] = Inventory(
        token_id="no", market_name="Pair", net_tokens=2.0, avg_entry_price=0.50
    )

    assert await maker._merge_paper_complete_sets() == 1
    assert inventory.bankroll == pytest.approx(9.8)
    assert inventory.daily_pnl == pytest.approx(0.20)
    assert inventory.inventories["yes"].net_tokens == pytest.approx(1.0)
    assert "no" not in inventory.inventories
    assert maker._persist_trade.await_args.kwargs["exit_path"] == "PAPER_COMPLETE_SET_MERGE"

    assert await maker._merge_paper_complete_sets() == 0
    assert maker._persist_trade.await_count == 1


@pytest.mark.asyncio
@pytest.mark.integration
@pytest.mark.parametrize(("resolved_price", "expected_bankroll"), [(1.0, 12.0), (0.0, 8.0)])
async def test_resolved_position_redeems_once(monkeypatch, resolved_price, expected_bankroll):
    _configure(monkeypatch)
    maker, clob, inventory = _maker()
    inventory.bankroll = 8.0
    inventory.starting_balance = 10.0
    inventory.inventories["yes"] = Inventory(
        token_id="yes",
        market_name="Resolved market",
        net_tokens=4.0,
        avg_entry_price=0.50,
    )
    clob.fetch_market_status = AsyncMock(
        return_value={"is_resolved": True, "resolved_price": resolved_price}
    )

    await maker._reconcile_orphaned_positions()
    await maker._reconcile_orphaned_positions()

    assert inventory.bankroll == pytest.approx(expected_bankroll)
    assert "yes" not in inventory.inventories
    assert maker._persist_trade.await_count == 1
    assert maker._persist_trade.await_args.kwargs["exit_path"] == "PAPER_REDEEM"


@pytest.mark.asyncio
@pytest.mark.integration
async def test_stale_entry_order_is_cancelled_by_ttl(monkeypatch):
    _configure(monkeypatch)
    maker, clob, _inventory = _maker()
    book = _book()
    _add_market(clob, book)
    monkeypatch.setattr(settings, "paper_rejection_rate", 1.0)
    monkeypatch.setattr(settings, "fast_flat_entry_ttl_sec", 1.0)

    await maker._process_market(book.token_id, book)
    quote = maker.active_quotes[book.token_id][0]
    quote.placed_at = time.monotonic() - 2.0

    await maker._process_market(book.token_id, book)

    assert maker.active_quotes == {}
    assert maker._fast_flat_state is not None
    assert maker._fast_flat_state.phase == "ENTRY_CANCEL_PENDING"


@pytest.mark.asyncio
@pytest.mark.integration
async def test_partial_exit_is_replaced_for_exact_remainder(monkeypatch):
    _configure(monkeypatch)
    maker, clob, inventory = _maker()
    book = _book()
    _add_market(clob, book)
    inventory.bankroll = 23.2
    inventory.inventories[book.token_id] = Inventory(
        token_id=book.token_id,
        market_name="Acceptance market",
        net_tokens=4.0,
        avg_entry_price=0.45,
        open_time=time.monotonic(),
    )

    await maker._process_market(book.token_id, book)
    assert maker.active_quotes[book.token_id][0].role == "EXIT"

    random_values = iter([0.99, 0.99, 0.99, 0.30])
    uniform_values = iter([0.50])
    monkeypatch.setattr(mm_mod.random, "random", lambda: next(random_values))
    monkeypatch.setattr(mm_mod.random, "uniform", lambda _a, _b: next(uniform_values))
    await maker._process_market(book.token_id, book)

    assert inventory.inventories[book.token_id].net_tokens == pytest.approx(2.0)
    assert maker.active_quotes == {}

    await maker._process_market(book.token_id, book)
    replacement = maker.active_quotes[book.token_id][0]
    assert replacement.role == "EXIT"
    assert replacement.size_usdc / replacement.ask_price == pytest.approx(2.0)


@pytest.mark.asyncio
@pytest.mark.integration
async def test_rescue_fak_closes_full_depth_position_within_loss_budget(monkeypatch):
    _configure(monkeypatch)
    maker, clob, inventory = _maker()
    book = _book(bid=0.44, ask=0.47)
    _add_market(clob, book)
    inventory.bankroll = 23.2
    inventory.inventories[book.token_id] = Inventory(
        token_id=book.token_id,
        market_name="Acceptance market",
        net_tokens=4.0,
        avg_entry_price=0.45,
        open_time=time.monotonic() - settings.fast_flat_rescue_after_sec - 1.0,
    )

    await maker._process_market(book.token_id, book)

    assert inventory.get_inventory(book.token_id).net_tokens == pytest.approx(0.0)
    assert inventory.bankroll == pytest.approx(24.96)
    assert maker._exit_taker_count == 1
    assert maker._persist_trade.await_args.kwargs["exit_path"] == "FAST_FLAT_RESCUE_FAK_EXIT"

    await maker._process_market(book.token_id, book, exit_only=True)
    assert maker._fast_flat_state is None
    assert maker._round_trip_count == 1
