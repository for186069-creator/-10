from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest

from app.admin import api
from app.services.clob_client import MarketBook, OrderLevel


@pytest.mark.asyncio
async def test_manual_fak_acceptance_without_confirmed_fill_does_not_mutate_inventory(
    monkeypatch,
):
    inv = SimpleNamespace(net_tokens=10.0)

    class Inventory:
        def get_inventory(self, token_id):
            return inv

    class MM:
        _pending_orders = {}

        async def _submit_immediate_order(self, *args, **kwargs):
            return True, False

    monkeypatch.setattr(api, "_inventory", Inventory())
    monkeypatch.setattr(api, "_mm", MM())

    terminal, sold, error = await api._submit_tracked_manual_fak(
        "token", 0.60, 10.0, "market"
    )

    assert terminal is True
    assert sold == 0.0
    assert error == ""
    assert inv.net_tokens == 10.0


@pytest.mark.asyncio
async def test_paper_to_live_rolls_back_when_wallet_positions_mismatch(monkeypatch):
    monkeypatch.setattr(api.settings, "paper_trading", True)
    monkeypatch.setattr(api.settings, "exchange", "limitless")

    class Inventory:
        halted = False
        halt_reason = ""
        bankroll = 10.0
        starting_balance = 10.0
        _live_synced = False
        live_ready = True
        live_sync_error = ""

        def halt(self, reason, detail=""):
            self.halted = True
            self.halt_reason = reason

        async def sync_bankroll_from_wallet(self, clob):
            self.bankroll = 25.0
            self.starting_balance = 25.0
            self._live_synced = True
            self.live_ready = True

    class MM:
        active_quotes = {}

        def stop_trading(self):
            pass

        async def _check_position_drift_after_crash(self, *, strict=False):
            assert strict is True
            return False

        async def start_live_polling(self):
            raise AssertionError("polling must not start after failed preflight")

    class Clob:
        async def _init_live_client(self):
            pass

    async def checklist():
        return {"ready": True, "checks": []}

    monkeypatch.setattr(api, "_inventory", Inventory())
    monkeypatch.setattr(api, "_mm", MM())
    monkeypatch.setattr(api, "_clob", Clob())
    monkeypatch.setattr(api, "_risk", object())
    monkeypatch.setattr(api, "live_checklist", checklist)

    result = await api.toggle_mode()

    assert result["success"] is False
    assert api.settings.paper_trading is True
    assert api._inventory.bankroll == 10.0
    assert api._inventory.starting_balance == 10.0
    assert api._inventory._live_synced is False


@pytest.mark.asyncio
async def test_live_to_paper_fails_closed_when_orders_not_terminal(monkeypatch):
    monkeypatch.setattr(api.settings, "paper_trading", False)
    monkeypatch.setattr(api.settings, "exchange", "limitless")

    class Inventory:
        halted = False
        halt_reason = ""

        def halt(self, reason, detail=""):
            self.halted = True
            self.halt_reason = reason

    class MM:
        def __init__(self):
            self.called = False

        def stop_trading(self):
            pass

        async def cancel_all_live_orders_and_wait(self, *, timeout_sec):
            self.called = True
            return False

    mm = MM()
    monkeypatch.setattr(api, "_inventory", Inventory())
    monkeypatch.setattr(api, "_mm", mm)
    monkeypatch.setattr(api, "_clob", object())
    monkeypatch.setattr(api, "_risk", object())

    result = await api.toggle_mode()

    assert result["success"] is False
    assert result["mode"] == "LIVE"
    assert mm.called is True
    assert api.settings.paper_trading is False


@pytest.mark.asyncio
async def test_exit_all_never_clamps_no_loss_target_below_cost_floor(monkeypatch):
    monkeypatch.setattr(api.settings, "paper_trading", True)
    monkeypatch.setattr(api.settings, "paper_gas_cost_usdc", 0.0)
    token_id = "token-profit-floor"
    inv = SimpleNamespace(
        net_tokens=10.0,
        avg_entry_price=0.50,
        market_name="Profit floor market",
    )
    inventory = SimpleNamespace(inventories={token_id: inv})
    book = MarketBook(
        token_id=token_id,
        bids=[OrderLevel(price=0.40, size=100.0)],
        asks=[OrderLevel(price=0.42, size=100.0)],
    )
    clob = SimpleNamespace(books={token_id: book})
    mm = SimpleNamespace(
        active_quotes={},
        stop_trading=lambda: None,
        _record_fill=AsyncMock(),
        _taker_fee_per_token=lambda *_: 0.0,
    )
    monkeypatch.setattr(api, "_inventory", inventory)
    monkeypatch.setattr(api, "_clob", clob)
    monkeypatch.setattr(api, "_mm", mm)
    monkeypatch.setattr(api, "_risk", object())

    await api.exit_all(min_profit_cents=0.5, timeout_sec=0, accept_loss=False)

    recorded_price = mm._record_fill.await_args.args[2]
    assert recorded_price >= 0.505
