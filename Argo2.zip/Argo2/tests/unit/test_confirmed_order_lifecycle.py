from __future__ import annotations

import asyncio
import time
from unittest.mock import AsyncMock, MagicMock

import pytest

from app.core.config import settings
from app.services.clob_client import MarketBook, OrderLevel, OrderResult
from app.services.inventory_manager import InventoryManager
from app.services.market_maker import ActiveQuote, MarketMaker
from app.services.risk.risk_manager import RiskManager


@pytest.fixture
def lifecycle_maker(monkeypatch):
    """A LIVE maker with all exchange I/O under test control."""
    monkeypatch.setattr(settings, "paper_trading", False)
    monkeypatch.setattr(settings, "live_gas_cost_usdc", 0.0)

    book = MarketBook(
        token_id="yes-token",
        bids=[OrderLevel(price=0.49, size=20.0)],
        asks=[OrderLevel(price=0.51, size=20.0)],
        last_price=0.50,
    )
    clob = MagicMock()
    clob.books = {book.token_id: book}
    clob.markets = {}
    clob.last_ws_msg_age = 1.0
    clob.cancel_order = AsyncMock(return_value=True)

    inventory = InventoryManager()
    inventory.bankroll = 25.0
    inventory.starting_balance = 25.0
    maker = MarketMaker(clob, inventory, RiskManager(inventory, clob))
    maker._persist_trade = AsyncMock()
    return maker, clob, inventory


def _pending_order(*, order_type: str = "GTC", side: str = "BUY") -> dict:
    return {
        "token_id": "yes-token",
        "side": side,
        "price": 0.50,
        "size_usdc": 2.0,
        "market_name": "Lifecycle market",
        "level": 1,
        "mid_at_place": 0.50,
        "placed_at": time.monotonic(),
        "order_type": order_type,
        "accounted_contracts_gross": 0.0,
        "accounted_contracts_net": 0.0,
        "accounted_usd_gross": 0.0,
        "accounted_usd_net": 0.0,
        "accounted_fee_usdc": 0.0,
        "ttl_sec": 30.0,
    }


@pytest.mark.asyncio
async def test_accepted_but_unconfirmed_order_does_not_mutate_inventory(
    lifecycle_maker,
):
    maker, clob, inventory = lifecycle_maker
    clob.place_order = AsyncMock(
        return_value=OrderResult(
            success=True,
            order_id="accepted-1",
            settlement_status="DELAYED",
            terminal=False,
            fill_confirmed=False,
            raw={"matched": True},
        )
    )
    clob.get_order_statuses = AsyncMock(
        return_value={
            "accepted-1": {
                "found": True,
                "confirmed": False,
                "status": "PARTIALLY_FILLED",
                "settlement_status": "DELAYED",
                "contracts_gross": 4.0,
                "contracts_net": 3.98,
                "usd_gross": 2.0,
                "usd_net": 2.0,
                "fee_usdc": 0.01,
                "price": 0.50,
                "is_open": True,
                "open_snapshot_valid": True,
            }
        }
    )

    accepted, filled_now = await maker._submit_immediate_order(
        "yes-token", "BUY", 0.51, 2.0, "Lifecycle market"
    )
    await maker._poll_orders_normalized()

    assert accepted is True
    assert filled_now is False
    assert inventory.bankroll == pytest.approx(25.0)
    assert "yes-token" not in inventory.inventories
    assert "accepted-1" in maker._pending_orders
    maker._persist_trade.assert_not_awaited()


@pytest.mark.asyncio
async def test_confirmed_cumulative_fill_delta_is_accounted_exactly_once(
    lifecycle_maker,
):
    maker, clob, inventory = lifecycle_maker
    maker._pending_orders["fill-1"] = _pending_order()
    confirmed_state = {
        "found": True,
        "confirmed": True,
        "status": "PARTIALLY_FILLED",
        "settlement_status": "MINED",
        "contracts_gross": 4.0,
        "contracts_net": 3.98,
        "usd_gross": 2.0,
        "usd_net": 2.0,
        "fee_usdc": 0.01,
        "price": 0.50,
        "is_open": True,
        "open_snapshot_valid": True,
    }
    clob.get_order_statuses = AsyncMock(
        return_value={"fill-1": confirmed_state}
    )

    await maker._poll_orders_normalized()
    await maker._poll_orders_normalized()

    position = inventory.inventories["yes-token"]
    assert position.net_tokens == pytest.approx(3.98)
    assert position.fill_count_buy == 1
    assert inventory.bankroll == pytest.approx(23.0)
    assert maker._fill_count == 1
    assert maker._pending_orders["fill-1"]["accounted_usd_gross"] == pytest.approx(2.0)
    maker._persist_trade.assert_awaited_once()


@pytest.mark.asyncio
async def test_concurrent_poll_consumers_cannot_double_apply_fill(
    lifecycle_maker,
):
    maker, clob, inventory = lifecycle_maker
    maker._pending_orders["fill-concurrent"] = _pending_order()
    clob.get_order_statuses = AsyncMock(
        return_value={
            "fill-concurrent": {
                "found": True,
                "confirmed": True,
                "status": "PARTIALLY_FILLED",
                "settlement_status": "MINED",
                "contracts_gross": 4.0,
                "contracts_net": 3.98,
                "usd_gross": 2.0,
                "usd_net": 2.0,
                "fee_usdc": 0.01,
                "price": 0.50,
                "is_open": True,
                "open_snapshot_valid": True,
            }
        }
    )

    await asyncio.gather(
        maker._poll_orders_normalized(),
        maker._poll_orders_normalized(),
    )

    assert inventory.get_inventory("yes-token").net_tokens == pytest.approx(3.98)
    assert inventory.get_inventory("yes-token").fill_count_buy == 1
    maker._persist_trade.assert_awaited_once()


@pytest.mark.asyncio
async def test_partial_gtc_stays_pending_when_open_snapshot_is_unavailable(
    lifecycle_maker,
):
    maker, clob, inventory = lifecycle_maker
    maker._pending_orders["partial-unknown-open"] = _pending_order()
    clob.get_order_statuses = AsyncMock(
        return_value={
            "partial-unknown-open": {
                "found": True,
                "confirmed": True,
                "status": "PARTIALLY_FILLED",
                "settlement_status": "MINED",
                "contracts_gross": 2.0,
                "contracts_net": 2.0,
                "usd_gross": 1.0,
                "usd_net": 1.0,
                "fee_usdc": 0.0,
                "price": 0.50,
                "is_open": None,
                "open_snapshot_valid": False,
            }
        }
    )

    await maker._poll_orders_normalized()

    assert inventory.get_inventory("yes-token").net_tokens == pytest.approx(2.0)
    assert "partial-unknown-open" in maker._pending_orders


@pytest.mark.asyncio
async def test_cancel_request_keeps_pending_until_exchange_terminal_state(
    lifecycle_maker,
):
    maker, clob, _ = lifecycle_maker
    maker._pending_orders["cancel-1"] = _pending_order()
    quote = ActiveQuote(
        token_id="yes-token",
        level=1,
        bid_price=0.50,
        ask_price=None,
        mid_at_place=0.50,
        size_usdc=2.0,
        reservation_price=0.50,
        spread_cents=2.0,
        bid_order_id="cancel-1",
    )

    await maker._cancel_quote_level("yes-token", quote)

    clob.cancel_order.assert_awaited_once_with("cancel-1")
    assert "cancel-1" in maker._pending_orders
    assert maker._pending_orders["cancel-1"]["cancel_requested_at"] > 0

    clob.get_order_statuses = AsyncMock(
        return_value={
            "cancel-1": {
                "found": True,
                "confirmed": False,
                "status": "CANCELLED",
                "settlement_status": "CANCELED",
                "contracts_gross": 0.0,
                "contracts_net": 0.0,
                "usd_gross": 0.0,
                "usd_net": 0.0,
                "fee_usdc": 0.0,
                "is_open": False,
                "open_snapshot_valid": True,
            }
        }
    )
    await maker._poll_orders_normalized()

    assert "cancel-1" not in maker._pending_orders


@pytest.mark.asyncio
async def test_cancelled_order_with_transient_settlement_stays_tracked(
    lifecycle_maker,
):
    maker, clob, _ = lifecycle_maker
    maker._pending_orders["cancel-delayed"] = {
        **_pending_order(),
        "cancel_requested_at": time.monotonic(),
    }
    clob.get_order_statuses = AsyncMock(
        return_value={
            "cancel-delayed": {
                "found": True,
                "confirmed": False,
                "status": "CANCELLED",
                "settlement_status": "MATCHED",
                "contracts_gross": 4.0,
                "contracts_net": 4.0,
                "usd_gross": 2.0,
                "usd_net": 2.0,
                "fee_usdc": 0.0,
                "is_open": False,
                "open_snapshot_valid": True,
            }
        }
    )

    await maker._poll_orders_normalized()

    assert "cancel-delayed" in maker._pending_orders


@pytest.mark.asyncio
async def test_cancel_all_waits_for_terminal_status_and_verified_empty_snapshot(
    lifecycle_maker,
):
    maker, clob, _ = lifecycle_maker
    maker._pending_orders["shutdown-1"] = {
        **_pending_order(),
        "cancel_requested_at": time.monotonic(),
    }
    clob.cancel_all = AsyncMock(return_value=1)
    clob.get_open_orders_snapshot = AsyncMock(return_value=([], True))
    clob.get_order_statuses = AsyncMock(
        return_value={
            "shutdown-1": {
                "found": True,
                "confirmed": False,
                "status": "CANCELLED",
                "settlement_status": "CANCELED",
                "contracts_gross": 0.0,
                "contracts_net": 0.0,
                "usd_gross": 0.0,
                "usd_net": 0.0,
                "fee_usdc": 0.0,
                "is_open": False,
                "open_snapshot_valid": True,
            }
        }
    )

    clean = await maker.cancel_all_live_orders_and_wait(timeout_sec=0.5)

    assert clean is True
    assert not maker._pending_orders


@pytest.mark.asyncio
async def test_cancel_all_fails_closed_when_open_snapshot_is_unverified(
    lifecycle_maker,
):
    maker, clob, _ = lifecycle_maker
    clob.cancel_all = AsyncMock(return_value=0)
    clob.get_open_orders_snapshot = AsyncMock(return_value=([], False))

    clean = await maker.cancel_all_live_orders_and_wait(timeout_sec=0.1)

    assert clean is False


@pytest.mark.asyncio
async def test_failed_live_preflight_blocks_even_exit_only_cycle(lifecycle_maker):
    maker, _, inventory = lifecycle_maker
    inventory.live_ready = False
    inventory.on_execution(
        "yes-token", "BUY", token_amount=2.0, cash_amount=1.0,
        market_name="Lifecycle market",
    )
    maker._process_market = AsyncMock()

    await maker._cycle(exit_only=True)

    maker._process_market.assert_not_awaited()


@pytest.mark.asyncio
async def test_terminal_zero_fill_fak_does_not_create_a_fill(lifecycle_maker):
    maker, clob, inventory = lifecycle_maker
    clob.place_order = AsyncMock(
        return_value=OrderResult(
            success=True,
            order_id="fak-zero",
            settlement_status="UNMATCHED",
            terminal=True,
            fill_confirmed=False,
            raw={"matched": False},
        )
    )

    accepted, filled_now = await maker._submit_immediate_order(
        "yes-token", "SELL", 0.49, 2.0, "Lifecycle market"
    )

    assert accepted is True
    assert filled_now is False
    assert inventory.bankroll == pytest.approx(25.0)
    assert "yes-token" not in inventory.inventories
    assert maker._fill_count == 0
    assert maker._liquidation_count == 0
    assert "fak-zero" not in maker._pending_orders
    maker._persist_trade.assert_not_awaited()
