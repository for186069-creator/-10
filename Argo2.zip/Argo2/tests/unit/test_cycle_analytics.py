from datetime import datetime, timezone
from types import SimpleNamespace

from app.db.models import Side
from app.services.analytics import Analytics


def _trade(cycle, side, tokens, pnl=0.0, fees=0.0):
    return SimpleNamespace(
        cycle_id=cycle, market_id="m", side=side, size_tokens=tokens,
        pnl_usdc=pnl, fees_usdc=fees, timestamp=datetime.now(timezone.utc),
    )


def test_partial_exits_are_one_cycle_and_costs_are_net():
    trades = [
        _trade(1, Side.BUY, 10, fees=.01),
        _trade(1, Side.SELL, 6, pnl=.12, fees=.01),
        _trade(1, Side.SELL, 4, pnl=-.03, fees=.01),
        _trade(2, Side.BUY, 2, fees=.01),  # open: not a fake win
    ]
    summary = Analytics.compute_summary(trades)
    assert summary["closed_trades"] == 1
    assert summary["win_rate"] == 100.0
    assert summary["profit_factor"] is None
    assert summary["avg_win"] == .06
    assert "1 open" in summary["win_rate_note"]


def test_profit_factor_uses_actual_losing_cycles():
    trades = [
        _trade(1, Side.BUY, 1), _trade(1, Side.SELL, 1, pnl=.20),
        _trade(2, Side.BUY, 1), _trade(2, Side.SELL, 1, pnl=-.10),
    ]
    summary = Analytics.compute_summary(trades)
    assert summary["win_rate"] == 50.0
    assert summary["profit_factor"] == 2.0
