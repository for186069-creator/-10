"""
tests/unit/test_exit_policy_v150.py — v1.0.150 exit-policy rebuild.

Covers the two new rules:
  1. PROFIT SNIPER: as soon as best_bid covers entry + profit_take_min_cents
     + estimated taker fee, the position is FAK-sold into the bid — no age
     gate, no waiting for the maker ask.
  2. NO-LOSS EXITS: liquidations below the breakeven floor (entry + taker
     fee) are forbidden for every tier, including URGENT, except inside the
     pre-resolution window or after the daily stop-loss trips. The resting
     maker ask is likewise never allowed below entry — it is lifted to the
     breakeven floor instead.

Test style mirrors test_bugN34_loss_cents_realistic.py: behavior-based
(_record_fill mocked), no structlog parsing.
"""
from __future__ import annotations

import time
from unittest.mock import AsyncMock, MagicMock

import pytest


def _book(token_id: str, bid: float, ask: float):
    from app.services.clob_client import MarketBook, OrderLevel

    return MarketBook(
        token_id=token_id,
        bids=[OrderLevel(bid, 100)],
        asks=[OrderLevel(ask, 100)],
        last_price=round((bid + ask) / 2, 4),
    )


def _market_info(token_id: str, end_in_sec: float):
    from app.services.clob_client import MarketInfo

    return MarketInfo(
        token_id=token_id,
        condition_id="cond-x",
        question="Exit policy market",
        outcome="Yes",
        end_date_ts=time.time() + end_in_sec,
        volume_24h=1000.0,
    )


def _make_mm(
    monkeypatch,
    *,
    entry: float,
    bid: float,
    ask: float,
    age_sec: float,
    end_in_sec: float = 86400.0,
):
    """PAPER MarketMaker with one long position and a mocked _record_fill."""
    from app.core.config import settings
    from app.services.market_maker import MarketMaker
    from app.services.inventory_manager import InventoryManager, Inventory
    from app.services.risk.risk_manager import RiskManager

    monkeypatch.setattr(settings, "paper_trading", True)
    monkeypatch.setattr(settings, "paper_rejection_rate", 0.0)
    monkeypatch.setattr(settings, "inventory_liquidation_enabled", True)
    monkeypatch.setattr(settings, "inventory_liquidation_aggressive_age_sec", 240.0)
    monkeypatch.setattr(settings, "inventory_liquidation_urgent_age_sec", 480.0)
    monkeypatch.setattr(settings, "inventory_liquidation_max_loss_cents", 100.0)
    monkeypatch.setattr(settings, "profit_take_min_cents", 0.5)
    monkeypatch.setattr(settings, "pre_resolution_exit_sec", 300)
    monkeypatch.setattr(settings, "max_daily_loss_usd", 5.0)

    tid = "tok-exit"
    clob = MagicMock()
    clob.books = {tid: _book(tid, bid, ask)}
    clob.markets = {tid: _market_info(tid, end_in_sec)}
    clob.last_ws_msg_age = 1.0
    # No adapter _meta dict on the mock → taker fee estimate must be 0
    # (matches Polymarket / non-fee-bearing markets).
    clob._meta = {}

    inventory = InventoryManager()
    inventory.bankroll = 100.0
    inv = Inventory(token_id=tid, market_name="Exit policy market")
    inv.net_tokens = 10.0
    inv.avg_entry_price = entry
    inv.open_time = time.monotonic() - age_sec
    inventory.inventories[tid] = inv

    risk = RiskManager(inventory, clob)
    mm = MarketMaker(clob, inventory, risk)
    mm._running = True
    mm._record_fill = AsyncMock()
    return mm, tid


# ── 1. PROFIT SNIPER ──────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_profit_sniper_fires_without_age_gate(monkeypatch):
    """v1.0.158 corridor: the UPPER threshold (≥75% of the achievable max)
    fires immediately at ANY age — no pause, no age gate.
    entry 0.30, ask 0.40 → hardcode ask 0.3985, achievable 9.85¢;
    bid 0.376 → net 7.6¢ = 77% ≥ 75% → FAK SELL on a 5-second-old position."""
    mm, tid = _make_mm(monkeypatch, entry=0.30, bid=0.376, ask=0.40, age_sec=5.0)

    await mm._liquidate_aged_positions()

    assert mm._record_fill.called, "upper threshold must fire at any age"
    args = mm._record_fill.call_args
    assert args.args[1] == "SELL"
    # A SELL FAK must be executable at the current best bid. Pricing it
    # above best_bid can produce an avoidable zero-fill.
    assert args.args[2] == pytest.approx(0.376, abs=1e-6)
    assert mm._profit_take_count == 1
    assert mm._loss_forced_count == 0
    assert mm._sniper_fired_count == 1


@pytest.mark.asyncio
async def test_corridor_holds_fresh_position_below_upper(monkeypatch):
    """v1.0.158: 60% of the max is INSIDE the corridor but the position is
    5s old — the 3-min pause gives the free maker ask-fill its chance first."""
    mm, tid = _make_mm(monkeypatch, entry=0.30, bid=0.359, ask=0.40, age_sec=5.0)

    await mm._liquidate_aged_positions()

    assert not mm._record_fill.called, (
        "inside the corridor but younger than the initial pause → hold"
    )


@pytest.mark.asyncio
async def test_profit_sniper_holds_below_threshold(monkeypatch):
    """v1.0.153 ladder: fresh position, bid delivers only ~51% of the
    achievable max (entry 0.30, bid 0.35 → 5¢ of 9.85¢) → hold and wait
    for the maker ask instead of paying taker fees early."""
    mm, tid = _make_mm(monkeypatch, entry=0.30, bid=0.35, ask=0.40, age_sec=5.0)

    await mm._liquidate_aged_positions()

    assert not mm._record_fill.called
    assert mm._profit_take_count == 0


# ── 2. NO-LOSS LIQUIDATIONS ───────────────────────────────────────────────


@pytest.mark.asyncio
async def test_aggressive_liquidation_never_below_breakeven(monkeypatch):
    """AGGRESSIVE-age position under water (entry 0.45, bid 0.40): the old
    code could sell at a loss via overrides — now it must HOLD."""
    mm, tid = _make_mm(monkeypatch, entry=0.45, bid=0.40, ask=0.42, age_sec=300.0)

    await mm._liquidate_aged_positions()

    assert not mm._record_fill.called, (
        "loss exits are forbidden outside pre-resolution/daily-stop"
    )
    assert mm._loss_forced_count == 0


@pytest.mark.asyncio
async def test_urgent_loss_forbidden_far_from_resolution(monkeypatch):
    """URGENT age alone no longer justifies selling at a loss."""
    mm, tid = _make_mm(monkeypatch, entry=0.45, bid=0.40, ask=0.42, age_sec=10_000.0)

    await mm._liquidate_aged_positions()

    assert not mm._record_fill.called
    assert mm._loss_forced_count == 0


@pytest.mark.asyncio
async def test_urgent_loss_allowed_pre_resolution(monkeypatch):
    """Inside the pre-resolution window (ttr 100s < 300s) the forced loss
    exit is allowed and counted as loss_liquidation_forced."""
    mm, tid = _make_mm(
        monkeypatch, entry=0.45, bid=0.40, ask=0.42, age_sec=10_000.0, end_in_sec=100.0
    )

    await mm._liquidate_aged_positions()

    assert mm._record_fill.called, "pre-resolution URGENT exit must execute"
    assert mm._record_fill.call_args.args[1] == "SELL"
    assert mm._loss_forced_count == 1


@pytest.mark.asyncio
async def test_urgent_loss_allowed_after_daily_stop(monkeypatch):
    """Daily stop-loss tripped → forced loss exit allowed."""
    mm, tid = _make_mm(monkeypatch, entry=0.45, bid=0.40, ask=0.42, age_sec=10_000.0)
    mm.inventory.daily_pnl = -10.0  # beyond max_daily_loss_usd=5

    await mm._liquidate_aged_positions()

    assert mm._record_fill.called
    assert mm._loss_forced_count == 1


# ── 3. Maker-ask breakeven floor in the quote path ────────────────────────


@pytest.mark.asyncio
async def test_aggressive_ask_lifted_to_breakeven_floor(monkeypatch):
    """Very-aged underwater position: the aging reprice targets bid+0.001
    (0.401 < entry 0.45). The ask must NEVER rest below entry — it is
    lifted to the breakeven floor (entry + tick) instead."""
    from app.core.config import settings

    mm, tid = _make_mm(monkeypatch, entry=0.45, bid=0.40, ask=0.42, age_sec=10_000.0)
    monkeypatch.setattr(settings, "paper_trading", False)  # LIVE branch places orders
    monkeypatch.setattr(settings, "multi_level_enabled", False)
    # Limitless exchange minimum ($1) — the default $5 would reject the
    # reduced ask (10 tokens × 0.42 ≈ $4.2) before the floor logic runs.
    mm.clob.books[tid].min_order_size = 1.0

    placed = []

    async def fake_place(token_id, side, price, size_usdc, **kw):
        placed.append((side, price, size_usdc))
        res = MagicMock()
        res.success = True
        res.order_id = f"ord-{len(placed)}"
        res.raw = {"price": str(price)}
        return res

    mm.clob.place_order = AsyncMock(side_effect=fake_place)

    decision = MagicMock()
    decision.allow_bid = False
    decision.allow_ask = True

    await mm._place_multi_level_quotes(
        token_id=tid,
        book=mm.clob.books[tid],
        market_name="Exit policy market",
        reservation=0.41,
        spread_cents=2.0,
        decision=decision,
        sigma=0.01,
        kyle_lambda=1.0,
        ttr_hours=24.0,
    )

    sells = [p for p in placed if p[0] == "SELL"]
    assert sells, "an ask should still be placed (parked at breakeven)"
    for side, price, size in sells:
        assert price >= 0.45, (
            f"ask {price} rests below breakeven floor (entry 0.45) — "
            "loss exits outside pre-resolution/daily-stop are forbidden"
        )


# ── 4. Drawdown stop: no averaging down ───────────────────────────────────


async def _run_quote_cycle(mm, tid, allow_bid=True, allow_ask=True):
    placed = []

    async def fake_place(token_id, side, price, size_usdc, **kw):
        placed.append((side, price, size_usdc))
        res = MagicMock()
        res.success = True
        res.order_id = f"ord-{len(placed)}"
        res.raw = {"price": str(price)}
        return res

    mm.clob.place_order = AsyncMock(side_effect=fake_place)
    decision = MagicMock()
    decision.allow_bid = allow_bid
    decision.allow_ask = allow_ask
    await mm._place_multi_level_quotes(
        token_id=tid,
        book=mm.clob.books[tid],
        market_name="Exit policy market",
        reservation=mm.clob.books[tid].mid,
        spread_cents=2.0,
        decision=decision,
        sigma=0.01,
        kyle_lambda=1.0,
        ttr_hours=24.0,
    )
    return placed


@pytest.mark.asyncio
async def test_drawdown_stop_blocks_new_buys(monkeypatch):
    """Position underwater beyond drawdown_stop_bid_cents (entry 0.45,
    mid 0.41 → 4¢ drawdown > 3¢ limit): new BUYs must be blocked while
    the ask keeps working."""
    from app.core.config import settings

    mm, tid = _make_mm(monkeypatch, entry=0.45, bid=0.40, ask=0.42, age_sec=60.0)
    monkeypatch.setattr(settings, "paper_trading", False)
    monkeypatch.setattr(settings, "multi_level_enabled", False)
    monkeypatch.setattr(settings, "drawdown_stop_bid_cents", 3.0)
    mm.clob.books[tid].min_order_size = 1.0

    placed = await _run_quote_cycle(mm, tid)

    buys = [p for p in placed if p[0] == "BUY"]
    sells = [p for p in placed if p[0] == "SELL"]
    assert not buys, (
        "BUY must be blocked: mid 0.41 is 4¢ under entry 0.45 (> 3¢ limit) — "
        "averaging down into a falling knife is forbidden"
    )
    assert sells, "the ask side must keep working under the drawdown stop"
    assert tid in mm._drawdown_stopped


@pytest.mark.asyncio
async def test_drawdown_stop_not_masked_by_torn_book_mid(monkeypatch):
    """v1.0.155 regression (live case 2026-07-13): entry 0.0971, book
    0.049/0.108. Mid (0.0785) is inflated by a lone high ask → mid-based
    drawdown 1.86¢ kept the stop asleep while the REAL exit (bid) was
    4.7¢ under water. Bid-based measurement must block the BUY."""
    from app.core.config import settings

    mm, tid = _make_mm(monkeypatch, entry=0.0971, bid=0.049, ask=0.108, age_sec=60.0)
    monkeypatch.setattr(settings, "paper_trading", False)
    monkeypatch.setattr(settings, "multi_level_enabled", False)
    monkeypatch.setattr(settings, "drawdown_stop_bid_cents", 3.0)
    mm.clob.books[tid].min_order_size = 1.0

    placed = await _run_quote_cycle(mm, tid)

    assert not [p for p in placed if p[0] == "BUY"], (
        "mid inflated by a torn book must NOT mask the drawdown stop — "
        "measurement is bid-based"
    )
    assert tid in mm._drawdown_stopped


@pytest.mark.asyncio
async def test_drawdown_stop_allows_buys_within_limit(monkeypatch):
    """Drawdown smaller than the limit (entry 0.43, mid 0.41 → 2¢ < 3¢):
    BUYs stay enabled."""
    from app.core.config import settings

    mm, tid = _make_mm(monkeypatch, entry=0.43, bid=0.40, ask=0.42, age_sec=60.0)
    monkeypatch.setattr(settings, "paper_trading", False)
    monkeypatch.setattr(settings, "multi_level_enabled", False)
    monkeypatch.setattr(settings, "drawdown_stop_bid_cents", 3.0)
    mm.clob.books[tid].min_order_size = 1.0

    placed = await _run_quote_cycle(mm, tid)

    buys = [p for p in placed if p[0] == "BUY"]
    assert buys, "2¢ drawdown is within the 3¢ limit — BUY must be allowed"
    assert tid not in mm._drawdown_stopped
