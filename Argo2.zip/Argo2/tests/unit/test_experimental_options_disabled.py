from app.core.config import Settings
from types import SimpleNamespace
from unittest.mock import MagicMock

from app.core.config import settings
from app.services.inventory_manager import InventoryManager
from app.services.market_maker import MarketMaker


def test_match2_experimental_strategy_extensions_are_off_by_default():
    cfg = Settings(_env_file=None)
    assert cfg.fast_flat_15m_profile_enabled is False
    assert cfg.fast_flat_multilevel_enabled is False
    assert cfg.fast_flat_broader_markets_enabled is False


def test_15m_profile_is_used_only_when_explicitly_enabled(monkeypatch):
    clob = MagicMock()
    clob.books = {}
    clob.markets = {"x": SimpleNamespace(question="BTC Up or Down - 15 Minutes")}
    mm = MarketMaker(clob, InventoryManager(), MagicMock())
    monkeypatch.setattr(settings, "fast_flat_15m_profile_enabled", False)
    assert mm._fast_flat_profile_value("x", 900.0, 120.0) == 900.0
    monkeypatch.setattr(settings, "fast_flat_15m_profile_enabled", True)
    assert mm._fast_flat_profile_value("x", 900.0, 120.0) == 120.0
    monkeypatch.setattr(settings, "fast_flat_15m_entry_ttl_sec", 45.0)
    monkeypatch.setattr(settings, "fast_flat_15m_rescue_after_sec", 120.0)
    monkeypatch.setattr(settings, "fast_flat_15m_pre_resolution_exit_sec", 60.0)
    monkeypatch.setattr(settings, "fast_flat_15m_min_ttr_sec", 120.0)
    assert mm._fast_flat_minimum_ttr("x") == 225.0
