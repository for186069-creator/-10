import time
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock

import pytest

from app.core.config import settings
from app.services.clob_client import MarketBook, MarketInfo, OrderLevel
from app.services.clob_client import OrderResult
from app.services.inventory_manager import Inventory, InventoryManager
from app.services.market_maker import MarketMaker


@pytest.fixture
def fast_flat(monkeypatch):
    monkeypatch.setattr(settings, "strategy_mode", "fast_flat")
    monkeypatch.setattr(settings, "fast_flat_multilevel_enabled", False)
    monkeypatch.setattr(settings, "fast_flat_15m_profile_enabled", False)
    monkeypatch.setattr(settings, "fast_flat_broader_markets_enabled", False)
    monkeypatch.setattr(settings, "paper_trading", True)
    monkeypatch.setattr(settings, "exchange", "limitless")
    monkeypatch.setattr(settings, "fast_flat_order_size_usdc", 2.0)
    monkeypatch.setattr(settings, "fast_flat_cash_reserve_usdc", 0.0)
    monkeypatch.setattr(settings, "fast_flat_cash_reserve_pct", 0.0)
    monkeypatch.setattr(settings, "fast_flat_min_spread_cents", 2.0)
    monkeypatch.setattr(settings, "fast_flat_max_spread_cents", 5.0)
    monkeypatch.setattr(settings, "fast_flat_max_book_age_sec", 3.0)
    monkeypatch.setattr(settings, "fast_flat_min_top_depth_mult", 1.0)
    monkeypatch.setattr(settings, "fast_flat_target_profit_usdc", 0.02)
    monkeypatch.setattr(settings, "fast_flat_entry_requote_sec", 15.0)
    monkeypatch.setattr(settings, "fast_flat_entry_requote_threshold_cents", 1.0)
    monkeypatch.setattr(settings, "fast_flat_entry_ttl_sec", 120.0)
    monkeypatch.setattr(settings, "fast_flat_profit_fak_enabled", True)
    monkeypatch.setattr(settings, "fast_flat_profit_fak_after_sec", 90.0)
    monkeypatch.setattr(settings, "fast_flat_profit_fak_slippage_cents", 0.0)
    monkeypatch.setattr(settings, "paper_gas_cost_usdc", 0.0)

    clob = MagicMock()
    clob.books = {}
    clob.markets = {}
    clob._meta = {}
    clob.cancel_order = AsyncMock(return_value=True)
    inventory = InventoryManager()
    inventory.bankroll = 25.0
    inventory.starting_balance = 25.0
    risk = MagicMock()
    risk.should_quote.return_value = SimpleNamespace(allow_bid=True)
    maker = MarketMaker(clob, inventory, risk)
    return maker, clob, inventory


def _book(token_id="yes", bid=0.45, ask=0.48, depth=100.0):
    return MarketBook(
        token_id=token_id,
        bids=[OrderLevel(bid, depth)],
        asks=[OrderLevel(ask, depth)],
        tick_size=0.01,
        min_order_size=0.1,
    )


def _add_market(clob, book):
    clob.books[book.token_id] = book
    clob.markets[book.token_id] = MarketInfo(
        token_id=book.token_id,
        condition_id=f"condition-{book.token_id}",
        question=f"Market {book.token_id}",
        outcome="Yes",
        end_date_ts=time.time() + 3600,
        volume_24h=100_000,
        tick_size=book.tick_size,
    )


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("ask", "should_replace"),
    [
        (0.46, True),   # 1 cent: below FAST_FLAT minimum
        (0.48, False),  # 3 cents: inside FAST_FLAT window
        (0.51, True),   # 6 cents: above FAST_FLAT maximum
    ],
)
async def test_auto_refill_uses_fast_flat_bounded_spread_window(
    fast_flat, monkeypatch, ask, should_replace
):
    maker, clob, _ = fast_flat
    monkeypatch.setattr(settings, "spread_min_cents", 0.0)
    monkeypatch.setattr(settings, "auto_refill_cooldown_sec", 0.0)
    book = _book(ask=ask)
    _add_market(clob, book)
    maker._replace_non_quotable_markets = AsyncMock()

    await maker._maybe_auto_refill()

    if should_replace:
        maker._replace_non_quotable_markets.assert_awaited_once_with(1)
    else:
        maker._replace_non_quotable_markets.assert_not_awaited()


@pytest.mark.asyncio
async def test_replacement_classifies_overwide_fast_flat_book_as_non_quotable(
    fast_flat, monkeypatch
):
    maker, clob, _ = fast_flat
    monkeypatch.setattr(settings, "spread_min_cents", 0.0)
    book = _book(ask=0.51)
    _add_market(clob, book)
    clob._feed.unsubscribe = AsyncMock()
    clob.discover_markets = AsyncMock(return_value=[])

    await maker._replace_non_quotable_markets(target=1)

    assert book.token_id not in clob.books


@pytest.mark.asyncio
async def test_flat_places_exactly_one_maker_entry(fast_flat):
    maker, clob, _ = fast_flat
    book = _book()
    _add_market(clob, book)

    await maker._process_market(book.token_id, book)

    quotes = maker.active_quotes[book.token_id]
    assert len(quotes) == 1
    assert quotes[0].strategy == "fast_flat"
    assert quotes[0].role == "ENTRY"
    assert quotes[0].bid_price == pytest.approx(0.46)
    assert quotes[0].ask_price is None


@pytest.mark.asyncio
async def test_multilevel_is_opt_in_and_splits_same_total_notional(fast_flat, monkeypatch):
    maker, clob, _ = fast_flat
    monkeypatch.setattr(settings, "fast_flat_multilevel_enabled", True)
    monkeypatch.setattr(settings, "fast_flat_multilevel_count", 3)
    book = _book()
    _add_market(clob, book)

    await maker._process_market(book.token_id, book)

    quotes = maker.active_quotes[book.token_id]
    assert len(quotes) == 3
    assert sum(q.size_usdc for q in quotes) == pytest.approx(2.0)
    assert [q.level for q in quotes] == [1, 2, 3]


@pytest.mark.asyncio
async def test_multilevel_adapts_to_venue_minimum_without_increasing_notional(
    fast_flat, monkeypatch
):
    maker, clob, _ = fast_flat
    monkeypatch.setattr(settings, "fast_flat_multilevel_enabled", True)
    monkeypatch.setattr(settings, "fast_flat_multilevel_count", 3)
    book = _book()
    book.min_order_size = 1.0
    _add_market(clob, book)

    await maker._process_market(book.token_id, book)

    quotes = maker.active_quotes[book.token_id]
    assert len(quotes) == 2
    assert [q.size_usdc for q in quotes] == pytest.approx([1.0, 1.0])
    assert sum(q.size_usdc for q in quotes) == pytest.approx(2.0)


@pytest.mark.asyncio
async def test_limitless_multilevel_uses_mill_price_tick_without_l2_below_bid(
    fast_flat, monkeypatch
):
    maker, clob, _ = fast_flat
    monkeypatch.setattr(settings, "fast_flat_multilevel_enabled", True)
    monkeypatch.setattr(settings, "fast_flat_multilevel_count", 3)
    monkeypatch.setattr(settings, "fast_flat_order_size_usdc", 3.0)
    monkeypatch.setattr(settings, "fast_flat_max_spread_cents", 10.0)
    book = _book(bid=0.153, ask=0.251)
    book.tick_size = 0.001
    book.min_order_size = 1.0
    _add_market(clob, book)

    await maker._process_market(book.token_id, book)

    quotes = maker.active_quotes[book.token_id]
    assert [q.bid_price for q in quotes] == pytest.approx([0.154, 0.1545, 0.155])
    assert all(q.bid_price >= book.best_bid for q in quotes)

@pytest.mark.asyncio
async def test_stable_entry_rests_without_three_second_cancel_churn(fast_flat):
    maker, clob, _ = fast_flat
    book = _book()
    _add_market(clob, book)

    await maker._process_market(book.token_id, book)
    quote = maker.active_quotes[book.token_id][0]
    quote.placed_at = time.monotonic() - 30.0

    await maker._process_market(book.token_id, book)

    assert maker.active_quotes[book.token_id][0] is quote
    assert maker._fast_flat_state is not None
    assert maker._fast_flat_state.phase == "ENTRY_WORKING"


@pytest.mark.asyncio
async def test_entry_requotes_after_material_price_move_and_minimum_rest(fast_flat):
    maker, clob, _ = fast_flat
    book = _book()
    _add_market(clob, book)

    await maker._process_market(book.token_id, book)
    quote = maker.active_quotes[book.token_id][0]
    quote.placed_at = time.monotonic() - 20.0
    book.bids = [OrderLevel(0.46, 100.0)]
    book.asks = [OrderLevel(0.49, 100.0)]
    book.last_update = time.monotonic()

    await maker._process_market(book.token_id, book)

    assert maker.active_quotes == {}
    assert maker._fast_flat_state is not None
    assert maker._fast_flat_state.phase == "ENTRY_CANCEL_PENDING"


@pytest.mark.asyncio
async def test_stale_book_rejects_fast_flat_entry(fast_flat):
    maker, clob, _ = fast_flat
    book = _book()
    book.last_update = time.monotonic() - settings.fast_flat_max_book_age_sec - 0.1
    _add_market(clob, book)

    await maker._process_market(book.token_id, book)

    assert maker.active_quotes == {}
    assert maker._fast_flat_state is None


@pytest.mark.asyncio
async def test_two_books_still_create_only_one_global_entry(fast_flat):
    maker, clob, _ = fast_flat
    first = _book("first")
    second = _book("second")
    _add_market(clob, first)
    _add_market(clob, second)

    await maker._process_market(first.token_id, first)
    await maker._process_market(second.token_id, second)

    assert list(maker.active_quotes) == ["first"]
    assert maker._fast_flat_state.token_id == "first"


@pytest.mark.asyncio
async def test_existing_inventory_is_exit_only_and_exact_share_sized(fast_flat):
    maker, clob, inventory = fast_flat
    book = _book()
    _add_market(clob, book)
    inventory.inventories[book.token_id] = Inventory(
        token_id=book.token_id,
        market_name="Market yes",
        net_tokens=4.0,
        avg_entry_price=0.45,
        open_time=time.monotonic(),
    )

    await maker._process_market(book.token_id, book)

    quote = maker.active_quotes[book.token_id][0]
    assert quote.role == "EXIT"
    assert quote.bid_price is None
    assert quote.ask_price == pytest.approx(0.47)
    assert quote.size_usdc / quote.ask_price == pytest.approx(4.0)


@pytest.mark.asyncio
async def test_limitless_multilevel_exit_uses_hardcoded_ask_ladder(
    fast_flat, monkeypatch
):
    maker, clob, inventory = fast_flat
    monkeypatch.setattr(settings, "fast_flat_multilevel_enabled", True)
    monkeypatch.setattr(settings, "fast_flat_multilevel_count", 3)
    book = _book(bid=0.40, ask=0.48)
    book.tick_size = 0.001
    book.min_order_size = 1.0
    _add_market(clob, book)
    inventory.inventories[book.token_id] = Inventory(
        token_id=book.token_id,
        market_name="Market yes",
        net_tokens=10.0,
        avg_entry_price=0.40,
        open_time=time.monotonic(),
    )

    await maker._process_market(book.token_id, book)

    quotes = maker.active_quotes[book.token_id]
    assert [q.ask_price for q in quotes] == pytest.approx([0.479, 0.4785, 0.478])
    assert sum(q.size_usdc / q.ask_price for q in quotes) == pytest.approx(10.0)
    assert all(q.role == "EXIT" for q in quotes)


@pytest.mark.asyncio
async def test_no_entry_when_cash_reserve_would_be_breached(fast_flat, monkeypatch):
    maker, clob, inventory = fast_flat
    monkeypatch.setattr(settings, "fast_flat_cash_reserve_usdc", 24.95)
    book = _book()
    _add_market(clob, book)

    await maker._process_market(book.token_id, book)

    assert maker.active_quotes == {}
    assert inventory.inventories[book.token_id].net_tokens == 0


@pytest.mark.asyncio
async def test_shallow_bid_never_uses_fak_for_whole_position(fast_flat, monkeypatch):
    maker, clob, inventory = fast_flat
    monkeypatch.setattr(settings, "fast_flat_rescue_after_sec", 0.0)
    monkeypatch.setattr(settings, "fast_flat_loss_budget_usdc", 10.0)
    book = _book(bid=0.44, ask=0.47, depth=1.0)
    _add_market(clob, book)
    inventory.inventories[book.token_id] = Inventory(
        token_id=book.token_id,
        market_name="Market yes",
        net_tokens=4.0,
        avg_entry_price=0.45,
        open_time=time.monotonic() - 100,
    )
    maker._submit_immediate_order = AsyncMock(return_value=(True, True))

    await maker._process_market(book.token_id, book)

    maker._submit_immediate_order.assert_not_awaited()
    assert maker.active_quotes[book.token_id][0].role == "EXIT"


@pytest.mark.asyncio
async def test_loss_budget_fak_waits_for_emergency_rescue_window(
    fast_flat, monkeypatch
):
    maker, clob, inventory = fast_flat
    monkeypatch.setattr(settings, "fast_flat_rescue_after_sec", 900.0)
    monkeypatch.setattr(settings, "fast_flat_loss_budget_usdc", 0.50)
    book = _book(bid=0.44, ask=0.47, depth=100.0)
    _add_market(clob, book)
    inventory.inventories[book.token_id] = Inventory(
        token_id=book.token_id,
        market_name="Market yes",
        net_tokens=4.0,
        avg_entry_price=0.45,
        open_time=time.monotonic() - 100.0,
    )
    maker._submit_immediate_order = AsyncMock(return_value=(True, False))

    await maker._process_market(book.token_id, book)

    maker._submit_immediate_order.assert_not_awaited()
    assert maker.active_quotes[book.token_id][0].role == "EXIT"


@pytest.mark.asyncio
async def test_restored_position_starts_rescue_clock_and_can_exit_within_budget(
    fast_flat, monkeypatch
):
    maker, clob, inventory = fast_flat
    monkeypatch.setattr(settings, "fast_flat_rescue_after_sec", 90.0)
    monkeypatch.setattr(settings, "fast_flat_loss_budget_usdc", 0.05)
    book = _book(bid=0.44, ask=0.47, depth=100.0)
    _add_market(clob, book)
    inventory.inventories[book.token_id] = Inventory(
        token_id=book.token_id,
        market_name="Restored market",
        net_tokens=4.0,
        avg_entry_price=0.45,
        open_time=0.0,
    )
    maker._submit_immediate_order = AsyncMock(return_value=(True, False))

    maker._refresh_fast_flat_state()
    restored = inventory.inventories[book.token_id]
    assert restored.open_time > 0
    restored.open_time -= settings.fast_flat_rescue_after_sec + 1.0

    await maker._process_market(book.token_id, book)

    maker._submit_immediate_order.assert_awaited_once()
    call = maker._submit_immediate_order.await_args
    assert call.args[1] == "SELL"
    assert call.args[2] == pytest.approx(0.44)


@pytest.mark.asyncio
async def test_profitable_fak_waits_for_maker_window(fast_flat):
    maker, clob, inventory = fast_flat
    book = _book(bid=0.50, ask=0.53, depth=100.0)
    _add_market(clob, book)
    inventory.bankroll = 23.20
    inventory.inventories[book.token_id] = Inventory(
        token_id=book.token_id,
        market_name="Market yes",
        net_tokens=4.0,
        avg_entry_price=0.45,
        open_time=time.monotonic(),
        fast_flat_cycle_id=1,
        fast_flat_cycle_start_bankroll=25.0,
        fast_flat_cycle_initial_tokens=4.0,
    )
    maker._submit_immediate_order = AsyncMock(return_value=(True, False))

    await maker._process_market(book.token_id, book)

    maker._submit_immediate_order.assert_not_awaited()
    assert maker.active_quotes[book.token_id][0].role == "EXIT"


@pytest.mark.asyncio
async def test_profitable_fak_uses_whole_cycle_pnl_after_partial_maker_profit(
    fast_flat, monkeypatch
):
    maker, clob, inventory = fast_flat
    monkeypatch.setattr(maker, "_taker_fee_per_token", lambda *_: 0.0)
    book = _book(bid=0.44, ask=0.47, depth=100.0)
    _add_market(clob, book)

    # Cycle cash flow:
    #   BUY 5 @ .45  -> bankroll 22.75
    #   maker SELL 4 @ .50 -> bankroll 24.75
    #   remaining FAK 1 @ .44 loses .01 on that leg, but final bankroll is
    #   25.19, so the WHOLE cycle remains +.19 and should be completed.
    inventory.bankroll = 24.75
    inventory.inventories[book.token_id] = Inventory(
        token_id=book.token_id,
        market_name="Market yes",
        net_tokens=1.0,
        avg_entry_price=0.45,
        realized_pnl=0.20,
        open_time=time.monotonic() - 100.0,
        fast_flat_cycle_id=7,
        fast_flat_cycle_start_bankroll=25.0,
        fast_flat_cycle_initial_tokens=5.0,
    )
    maker._submit_immediate_order = AsyncMock(return_value=(True, False))

    await maker._process_market(book.token_id, book)

    maker._submit_immediate_order.assert_awaited_once()
    call = maker._submit_immediate_order.await_args
    assert call.args[1] == "SELL"
    assert call.args[2] == pytest.approx(0.44)
    assert call.args[3] == pytest.approx(0.44)


@pytest.mark.asyncio
async def test_profitable_fak_rejects_when_whole_cycle_is_below_target(
    fast_flat, monkeypatch
):
    maker, clob, inventory = fast_flat
    monkeypatch.setattr(maker, "_taker_fee_per_token", lambda *_: 0.0)
    book = _book(bid=0.44, ask=0.47, depth=100.0)
    _add_market(clob, book)
    inventory.bankroll = 24.50
    inventory.inventories[book.token_id] = Inventory(
        token_id=book.token_id,
        market_name="Market yes",
        net_tokens=1.0,
        avg_entry_price=0.45,
        open_time=time.monotonic() - 100.0,
        fast_flat_cycle_id=8,
        fast_flat_cycle_start_bankroll=25.0,
    )
    maker._submit_immediate_order = AsyncMock(return_value=(True, False))

    await maker._process_market(book.token_id, book)

    maker._submit_immediate_order.assert_not_awaited()
    assert maker.active_quotes[book.token_id][0].role == "EXIT"


@pytest.mark.asyncio
async def test_profitable_fak_rejects_expensive_residual_leg(fast_flat, monkeypatch):
    maker, clob, inventory = fast_flat
    monkeypatch.setattr(maker, "_taker_fee_per_token", lambda *_: 0.0)
    book = _book(bid=0.20, ask=0.47, depth=100.0)
    _add_market(clob, book)
    inventory.bankroll = 25.30  # prior maker leg leaves the whole cycle green
    inventory.inventories[book.token_id] = Inventory(
        token_id=book.token_id, market_name="Market yes",
        net_tokens=1.0, avg_entry_price=0.45,
        open_time=time.monotonic() - 100.0,
        fast_flat_cycle_id=10, fast_flat_cycle_start_bankroll=25.0,
        fast_flat_cycle_initial_tokens=5.0,
    )
    maker._submit_immediate_order = AsyncMock(return_value=(True, False))

    await maker._process_market(book.token_id, book)

    maker._submit_immediate_order.assert_not_awaited()
    assert maker.active_quotes[book.token_id][0].role == "EXIT"


@pytest.mark.asyncio
async def test_long_can_profitable_fak_exit_on_fresh_bid_only_book(
    fast_flat, monkeypatch
):
    maker, clob, inventory = fast_flat
    monkeypatch.setattr(maker, "_taker_fee_per_token", lambda *_: 0.0)
    book = _book(bid=0.50, ask=0.53, depth=100.0)
    book.asks = []
    _add_market(clob, book)
    inventory.bankroll = 23.20
    inventory.inventories[book.token_id] = Inventory(
        token_id=book.token_id,
        market_name="Market yes",
        net_tokens=4.0,
        avg_entry_price=0.45,
        open_time=time.monotonic() - 100.0,
        fast_flat_cycle_id=9,
        fast_flat_cycle_start_bankroll=25.0,
    )
    maker._submit_immediate_order = AsyncMock(return_value=(True, False))

    await maker._process_market(book.token_id, book)

    maker._submit_immediate_order.assert_awaited_once()
    call = maker._submit_immediate_order.await_args
    assert call.args[1] == "SELL"
    assert call.args[2] == pytest.approx(0.50)
    assert call.args[3] == pytest.approx(2.0)


@pytest.mark.asyncio
async def test_flat_bot_does_not_enter_on_bid_only_book(fast_flat):
    maker, clob, _ = fast_flat
    book = _book()
    book.asks = []
    _add_market(clob, book)

    await maker._process_market(book.token_id, book)

    assert maker.active_quotes == {}
    assert maker._fast_flat_state is None


@pytest.mark.asyncio
async def test_stale_book_never_uses_fast_flat_fak_exit(fast_flat):
    maker, clob, inventory = fast_flat
    book = _book(bid=0.50, ask=0.53, depth=100.0)
    book.last_update = time.monotonic() - settings.fast_flat_max_book_age_sec - 0.1
    _add_market(clob, book)
    inventory.inventories[book.token_id] = Inventory(
        token_id=book.token_id,
        market_name="Market yes",
        net_tokens=4.0,
        avg_entry_price=0.45,
        open_time=time.monotonic(),
    )
    maker._submit_immediate_order = AsyncMock(return_value=(True, False))

    await maker._process_market(book.token_id, book)

    maker._submit_immediate_order.assert_not_awaited()
    assert maker.active_quotes == {}


@pytest.mark.asyncio
async def test_risk_halt_still_allows_exit_but_not_new_entry(fast_flat):
    maker, clob, inventory = fast_flat
    book = _book()
    _add_market(clob, book)
    inventory.halted = True

    await maker._process_market(book.token_id, book, exit_only=True)
    assert maker.active_quotes == {}

    inventory.inventories[book.token_id] = Inventory(
        token_id=book.token_id,
        market_name="Market yes",
        net_tokens=4.0,
        avg_entry_price=0.45,
        open_time=time.monotonic(),
    )
    await maker._process_market(book.token_id, book, exit_only=True)
    assert maker.active_quotes[book.token_id][0].role == "EXIT"


@pytest.mark.asyncio
async def test_live_partial_entry_waits_for_terminal_cancel_then_sells_net_tokens(
    fast_flat, monkeypatch
):
    maker, clob, inventory = fast_flat
    monkeypatch.setattr(settings, "paper_trading", False)
    monkeypatch.setattr(settings, "live_gas_cost_usdc", 0.0)
    inventory.live_ready = True
    book = _book()
    _add_market(clob, book)
    clob.place_order = AsyncMock(
        return_value=OrderResult(success=True, order_id="entry-1")
    )
    maker._persist_trade = AsyncMock()

    await maker._process_market(book.token_id, book)
    assert maker._pending_orders["entry-1"]["role"] == "ENTRY"

    partial = {
        "found": True,
        "confirmed": True,
        "contracts_gross": 2.0,
        "contracts_net": 1.99,
        "usd_gross": 0.92,
        "usd_net": 0.92,
        "fee_usdc": 0.0046,
        "price": 0.46,
        "settlement_status": "MINED",
        "status": "PARTIALLY_FILLED",
        "is_open": True,
        "open_snapshot_valid": True,
    }
    clob.get_order_statuses = AsyncMock(return_value={"entry-1": partial})
    await maker._poll_orders_normalized()

    assert inventory.inventories[book.token_id].net_tokens == pytest.approx(1.99)
    assert "entry-1" in maker._pending_orders
    assert maker._pending_orders["entry-1"].get("cancel_requested_at") is not None

    await maker._process_market(book.token_id, book)
    assert not any(
        q.role == "EXIT" for q in maker.active_quotes.get(book.token_id, [])
    )

    terminal = {
        **partial,
        "status": "CANCELLED",
        "is_open": False,
        "settlement_status": "CONFIRMED",
    }
    clob.get_order_statuses = AsyncMock(return_value={"entry-1": terminal})
    await maker._poll_orders_normalized()
    assert "entry-1" not in maker._pending_orders

    clob.place_order = AsyncMock(
        return_value=OrderResult(success=True, order_id="exit-1")
    )
    await maker._process_market(book.token_id, book)

    args = clob.place_order.await_args.args
    assert args[1] == "SELL"
    assert args[3] / args[2] == pytest.approx(1.99)
    assert maker._pending_orders["exit-1"]["role"] == "EXIT"
