"""v1.0.147-preview: Limitless adapter unit tests (no network).

Verifies the deterministic parts: HMAC request signing format, EIP-712
order amount math, config selector. Live API behavior needs a real
smoke test (Limitless has no testnet).
"""

import base64
import asyncio
import time
from unittest.mock import AsyncMock, MagicMock

import pytest

from app.core.config import settings
from app.services.clob_client import MarketBook, OrderLevel
from app.services.limitless_client import LimitlessService


def _trade_event(
    key: str, *, strategy: str = "Buy", outcome: str = "YES",
    contracts: str = "10", amount: str = "2", timestamp: str = "2026-07-17T08:00:01Z",
):
    return {
        "eventType": "NEW_TRADE",
        "timestamp": timestamp,
        "bodyHash": key,
        "data": {
            "strategy": strategy,
            "outcome": outcome,
            "contracts": contracts,
            "tradeAmount": amount,
            "txHash": f"0x{key}",
        },
    }


@pytest.fixture
def svc(monkeypatch):
    monkeypatch.setattr(settings, "limitless_api_token_id", "test-token-id")
    monkeypatch.setattr(
        settings, "limitless_api_secret",
        base64.b64encode(b"super-secret").decode(),
    )
    return LimitlessService()


def test_hmac_headers_shape(svc):
    headers = svc._sign_request("POST", "/orders", '{"a":1}')
    assert headers["lmts-api-key"] == "test-token-id"
    assert "lmts-timestamp" in headers
    # ISO-8601 with timezone
    assert "T" in headers["lmts-timestamp"]
    # base64 signature decodes to 32 bytes (SHA256)
    assert len(base64.b64decode(headers["lmts-signature"])) == 32


def test_no_buy_is_normalized_to_yes_sell(svc):
    trade = svc._normalize_public_trade(
        "yes-token", "e1",
        _trade_event("e1", strategy="Buy", outcome="NO",
                     contracts="10", amount="7"),
    )

    assert trade is not None
    assert trade.side == "SELL"
    assert trade.price == pytest.approx(0.30)
    assert trade.contracts == 10.0


@pytest.mark.asyncio
async def test_trade_feed_seeds_history_then_emits_only_new_events(svc):
    old = _trade_event("old", timestamp="2026-07-17T08:00:00Z")
    new = _trade_event("new", strategy="Sell", timestamp="2026-07-17T08:00:02Z")
    svc._request = AsyncMock(side_effect=[
        {"events": [old]},
        {"events": [new, old]},
        {"events": [new, old]},
    ])

    await svc._fetch_trade_feed("slug", "yes-token")
    assert svc.public_trades_since("yes-token", 0) == []

    await svc._fetch_trade_feed("slug", "yes-token")
    trades = svc.public_trades_since("yes-token", 0)
    assert len(trades) == 1
    assert trades[0].side == "SELL"
    assert trades[0].contracts == 10.0

    await svc._fetch_trade_feed("slug", "yes-token")
    assert len(svc.public_trades_since("yes-token", 0)) == 1


def test_hmac_signature_deterministic(svc, monkeypatch):
    """Same timestamp+method+path+body → same signature."""
    import app.services.limitless_client as lc

    class FakeDT:
        @staticmethod
        def now(tz):
            from datetime import datetime, timezone
            return datetime(2026, 7, 11, 12, 0, 0, tzinfo=timezone.utc)

    monkeypatch.setattr(lc, "datetime", FakeDT)
    h1 = svc._sign_request("GET", "/markets/active")
    h2 = svc._sign_request("GET", "/markets/active")
    assert h1["lmts-signature"] == h2["lmts-signature"]


def test_order_amount_math_buy():
    """BUY: makerAmount = price*shares*1e6, takerAmount = shares*1e6.
    shares = size_usdc / price."""
    price, size_usdc = 0.50, 5.0
    shares = size_usdc / price  # 10 shares
    maker = int(round(price * shares * 1e6))
    taker = int(round(shares * 1e6))
    assert maker == 5_000_000   # $5.00
    assert taker == 10_000_000  # 10 shares
    # Matches the official docs example exactly (BUY 10 YES @ $0.50)


def test_order_amount_math_sell():
    """SELL: makerAmount = shares*1e6, takerAmount = price*shares*1e6."""
    price, size_usdc = 0.52, 5.2
    shares = size_usdc / price  # 10 shares
    maker = int(round(shares * 1e6))
    taker = int(round(price * shares * 1e6))
    assert maker == 10_000_000
    assert taker == 5_200_000


@pytest.mark.asyncio
async def test_paper_mode_order(svc, monkeypatch):
    monkeypatch.setattr(settings, "paper_trading", True)
    r = await svc.place_order("tok-x", "BUY", 0.48, 5.0)
    assert r.success
    assert r.order_id.startswith("PAPER-LMTS-")


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("order_type", "depth", "expected_tokens", "expected_status"),
    [
        ("FAK", 1.5, 1.5, "CONFIRMED"),
        ("FOK", 1.5, 0.0, "UNMATCHED"),
    ],
)
async def test_paper_immediate_order_is_terminal_and_respects_fak_fok_depth(
    svc,
    monkeypatch,
    order_type,
    depth,
    expected_tokens,
    expected_status,
):
    """PAPER IOC orders must settle now, never linger for a status poller."""
    monkeypatch.setattr(settings, "paper_trading", True)
    svc.books["tok-x"] = MarketBook(
        token_id="tok-x",
        bids=[OrderLevel(price=0.50, size=depth)],
        asks=[OrderLevel(price=0.53, size=20.0)],
    )

    # Request four shares. FAK may take the 1.5-share top level; FOK must
    # reject the whole request because that level cannot satisfy all four.
    result = await svc.place_order(
        "tok-x", "SELL", 0.50, 2.0, order_type=order_type, post_only=False
    )

    assert result.success is True
    assert result.terminal is True
    assert result.settlement_status == expected_status
    assert result.filled_tokens == pytest.approx(expected_tokens)
    assert result.filled_size_usdc == pytest.approx(expected_tokens * 0.50)
    assert result.fill_confirmed is (expected_tokens > 0)
    assert result.raw["terminal"] is True
    assert result.raw["pending"] is False


@pytest.mark.asyncio
async def test_paper_fak_without_crossing_liquidity_is_terminal_unmatched(
    svc, monkeypatch
):
    monkeypatch.setattr(settings, "paper_trading", True)
    svc.books["tok-x"] = MarketBook(
        token_id="tok-x",
        bids=[OrderLevel(price=0.50, size=20.0)],
        asks=[OrderLevel(price=0.53, size=20.0)],
    )

    result = await svc.place_order(
        "tok-x", "SELL", 0.51, 2.04, order_type="FAK", post_only=False
    )

    assert result.success is True
    assert result.terminal is True
    assert result.settlement_status == "UNMATCHED"
    assert result.fill_confirmed is False
    assert result.filled_tokens == 0.0
    assert result.filled_size_usdc == 0.0


@pytest.mark.asyncio
async def test_invalid_price_rejected(svc, monkeypatch):
    monkeypatch.setattr(settings, "paper_trading", True)
    r = await svc.place_order("tok-x", "BUY", 0.005, 5.0)
    assert not r.success


@pytest.mark.asyncio
async def test_fast_flat_discovery_uses_exact_strategy_spread_band(
    svc, monkeypatch
):
    monkeypatch.setattr(settings, "strategy_mode", "fast_flat")
    monkeypatch.setattr(settings, "fast_flat_min_spread_cents", 2.0)
    monkeypatch.setattr(settings, "fast_flat_max_spread_cents", 5.0)
    monkeypatch.setattr(settings, "auto_pick_count", 10)

    def market(slug: str, bid: float, ask: float, token: str) -> dict:
        return {
            "slug": slug,
            "title": slug,
            "tokens": {"yes": token, "no": token + "-no"},
            "venue": {"exchange": "0x" + "1" * 40},
            "expirationTimestamp": int((time.time() + 7200) * 1000),
            "volumeFormatted": "100000",
            "tradePrices": {
                "sell": {"market": [bid]},
                "buy": {"market": [ask]},
            },
        }

    svc._request = AsyncMock(
        return_value=[
            market("too-tight", 0.49, 0.505, "1"),
            market("tradable", 0.48, 0.51, "2"),
            market("too-wide", 0.47, 0.53, "3"),
        ]
    )

    found = await svc.discover_markets()

    assert [item.condition_id for item in found] == ["tradable"]
    assert found[0].tick_size == pytest.approx(0.001)

    svc._request = AsyncMock(
        return_value={
            "bids": [{"price": "0.153", "size": "100"}],
            "asks": [{"price": "0.251", "size": "100"}],
        }
    )
    await svc._fetch_book(found[0].token_id)
    assert svc.books[found[0].token_id].tick_size == pytest.approx(0.001)


@pytest.mark.asyncio
async def test_request_timeout_logs_nonempty_safe_error_details(svc, monkeypatch):
    monkeypatch.setattr(settings, "paper_trading", True)

    class TimeoutContext:
        async def __aenter__(self):
            raise asyncio.TimeoutError()

        async def __aexit__(self, exc_type, exc, tb):
            return False

    class TimeoutSession:
        closed = False

        def request(self, *args, **kwargs):
            return TimeoutContext()

    warning = MagicMock()
    monkeypatch.setattr("app.services.limitless_client.log.warning", warning)
    svc._session = TimeoutSession()

    result = await svc._request("GET", "/markets/active")

    assert result == {
        "error": "request_timeout",
        "error_type": "TimeoutError",
    }
    warning.assert_called_once()
    event, = warning.call_args.args
    assert event == "limitless_request_failed"
    fields = warning.call_args.kwargs
    assert fields["method"] == "GET"
    assert fields["path"] == "/markets/active"
    assert fields["error_type"] == "TimeoutError"
    assert fields["error_message"]
    assert fields["elapsed_sec"] >= 0
