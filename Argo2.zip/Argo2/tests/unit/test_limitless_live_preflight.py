"""Fail-closed Limitless LIVE preflight tests (no network calls)."""

from __future__ import annotations

import json
from unittest.mock import AsyncMock

import pytest
from eth_account import Account

from app.core.config import settings
from app.services.inventory_manager import InventoryManager
from app.services.limitless_client import LimitlessService, _MarketMeta


@pytest.fixture
def limitless() -> LimitlessService:
    return LimitlessService()


@pytest.mark.asyncio
async def test_get_positions_parses_official_clob_raw_yes_no_balances(
    limitless: LimitlessService,
) -> None:
    limitless._request = AsyncMock(
        return_value={
            "clob": [
                {
                    "market": {
                        "slug": "will-it-rain",
                        "positionIds": ["yes-token-id", "no-token-id"],
                    },
                    "tokensBalance": {
                        "yes": "1250000",
                        "no": 500000,
                    },
                }
            ]
        }
    )

    positions = await limitless.get_positions()

    assert positions == [
        {"token_id": "yes-token-id", "tokens": 1.25},
        {"token_id": "no-token-id", "tokens": 0.5},
    ]
    limitless._request.assert_awaited_once_with("GET", "/portfolio/positions")


@pytest.mark.asyncio
async def test_get_positions_accepts_verified_empty_clob(
    limitless: LimitlessService,
) -> None:
    limitless._request = AsyncMock(return_value={"clob": []})

    assert await limitless.get_positions() == []


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "response",
    [
        None,
        {},
        {"positions": []},
        {"clob": None},
        {"clob": {}},
        {"clob": ["not-a-position-row"]},
    ],
)
async def test_get_positions_rejects_missing_or_malformed_clob(
    limitless: LimitlessService,
    response: object,
) -> None:
    limitless._request = AsyncMock(return_value=response)

    with pytest.raises(RuntimeError):
        await limitless.get_positions()


@pytest.mark.asyncio
async def test_get_positions_rejects_nonzero_unmappable_balance(
    limitless: LimitlessService,
) -> None:
    limitless._request = AsyncMock(
        return_value={
            "clob": [
                {
                    "market": {"slug": "unknown-market"},
                    "tokensBalance": {"yes": "1000000", "no": "0"},
                }
            ]
        }
    )

    with pytest.raises(RuntimeError, match="Cannot map non-zero yes balance"):
        await limitless.get_positions()


def test_live_inventory_starts_fail_closed_at_zero(monkeypatch) -> None:
    monkeypatch.setattr(settings, "paper_trading", False)

    inventory = InventoryManager()

    assert inventory.bankroll == 0.0
    assert inventory.starting_balance == 0.0
    assert inventory.live_ready is False
    assert inventory._live_synced is False


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "response",
    [
        None,
        {},
        {"verified": False, "allowance_verified": True, "balance": 25_000_000},
        {
            "verified": True,
            "allowance_verified": False,
            "gas_verified": True,
            "balance": 25_000_000,
        },
        {
            "verified": True,
            "allowance_verified": True,
            "gas_verified": False,
            "balance": 25_000_000,
        },
        {
            "verified": True,
            "allowance_verified": True,
            "gas_verified": True,
            "balance": 25_000_000,
        },
        {
            "verified": True,
            "allowance_verified": True,
            "gas_verified": True,
            "balance": "invalid",
        },
    ],
)
async def test_live_inventory_rejects_unverified_balance_or_allowance(
    monkeypatch,
    response: object,
) -> None:
    monkeypatch.setattr(settings, "paper_trading", False)
    monkeypatch.setattr(settings, "exchange", "limitless")
    # halt() creates an audit coroutine. Close it immediately so this focused
    # unit test does not touch the database or leave a background task behind.
    monkeypatch.setattr(
        "app.services.inventory_manager.asyncio_create_task_safely",
        lambda coroutine: coroutine.close(),
    )
    inventory = InventoryManager()
    clob = AsyncMock()
    clob.get_balance_allowance.return_value = response

    with pytest.raises((RuntimeError, KeyError, TypeError, ValueError)):
        await inventory.sync_bankroll_from_wallet(clob)

    assert inventory.live_ready is False
    assert inventory._live_synced is False
    assert inventory.bankroll == 0.0
    assert inventory.live_sync_error


@pytest.mark.asyncio
async def test_live_inventory_accepts_verified_25_usdc(monkeypatch) -> None:
    monkeypatch.setattr(settings, "paper_trading", False)
    monkeypatch.setattr(settings, "exchange", "limitless")
    monkeypatch.setattr(settings, "min_balance_usd", 2.0)
    inventory = InventoryManager()
    clob = AsyncMock()
    clob.get_balance_allowance.return_value = {
        "verified": True,
        "allowance_verified": True,
        "conditional_tokens_approval_verified": True,
        "gas_verified": True,
        "balance": 25_000_000,
        "allowance": 100_000_000,
        "source": "test",
    }

    await inventory.sync_bankroll_from_wallet(clob)

    assert inventory.live_ready is True
    assert inventory._live_synced is True
    assert inventory.bankroll == pytest.approx(25.0)
    assert inventory.starting_balance == pytest.approx(25.0)
    assert inventory.live_sync_error == ""


@pytest.mark.asyncio
async def test_external_eoa_preflight_rejects_missing_base_eth(
    monkeypatch, tmp_path
) -> None:
    private_key = "0x" + "5" * 64
    monkeypatch.setattr(
        settings,
        "limitless_order_scope_file",
        str(tmp_path / "order-scope.json"),
    )
    monkeypatch.setattr(settings, "limitless_min_base_eth", 0.00001)
    service = LimitlessService()
    service._account = Account.from_key(private_key)
    monkeypatch.setattr(
        "app.services.limitless_client.asyncio.to_thread",
        AsyncMock(return_value=(25_000_000, 0)),
    )

    with pytest.raises(RuntimeError, match="Insufficient Base ETH gas reserve"):
        await service.get_balance_allowance()


def test_conditional_token_operators_include_negrisk_adapter() -> None:
    exchange = "0x" + "1" * 40
    adapter = "0x" + "2" * 40
    standard = _MarketMeta(
        slug="standard",
        venue_exchange=exchange,
        venue_adapter=adapter,
        yes_token="1",
        no_token="2",
    )
    neg_risk = _MarketMeta(
        slug="neg-risk",
        venue_exchange=exchange,
        venue_adapter=adapter,
        yes_token="3",
        no_token="4",
        neg_risk=True,
    )

    assert LimitlessService._conditional_operators_for_meta(standard) == {
        exchange
    }
    assert LimitlessService._conditional_operators_for_meta(neg_risk) == {
        exchange,
        adapter,
    }


@pytest.fixture
def eoa_credentials(monkeypatch):
    private_key = "0x" + "1" * 64
    account = Account.from_key(private_key)
    monkeypatch.setattr(settings, "limitless_private_key", private_key)
    monkeypatch.setattr(settings, "limitless_api_token_id", "test-token")
    monkeypatch.setattr(settings, "limitless_api_secret", "dGVzdC1zZWNyZXQ=")
    monkeypatch.setattr(settings, "limitless_dedicated_eoa", True)
    return account


@pytest.mark.asyncio
async def test_live_init_blocks_smart_wallet_profile(
    limitless: LimitlessService,
    eoa_credentials,
) -> None:
    limitless._request = AsyncMock(
        return_value={
            "id": 7,
            "account": eoa_credentials.address,
            "tradeWalletOption": "SMART_WALLET",
            "rank": {"feeRateBps": 0},
        }
    )

    with pytest.raises(RuntimeError, match="delegated signing is not implemented"):
        await limitless._init_live_client()


@pytest.mark.asyncio
async def test_live_init_blocks_profile_account_key_mismatch(
    limitless: LimitlessService,
    eoa_credentials,
) -> None:
    other_account = Account.from_key("0x" + "2" * 64)
    limitless._request = AsyncMock(
        return_value={
            "id": 8,
            "account": other_account.address,
            "tradeWalletOption": "external",
            "rank": {"feeRateBps": 0},
        }
    )

    with pytest.raises(RuntimeError, match="does not match LIMITLESS_PRIVATE_KEY"):
        await limitless._init_live_client()


@pytest.mark.asyncio
async def test_verified_empty_snapshot_keeps_sticky_legacy_market_scope(
    monkeypatch, tmp_path
) -> None:
    scope_path = tmp_path / "order-scope.json"
    scope_path.write_text(
        json.dumps({"account": "0xabc", "slugs": ["previous-market"]}),
        encoding="utf-8",
    )
    monkeypatch.setattr(settings, "limitless_order_scope_file", str(scope_path))
    monkeypatch.setattr(settings, "limitless_dedicated_eoa", True)
    service = LimitlessService()
    service._request = AsyncMock(return_value={"orders": []})

    rows, verified = await service.get_open_orders_snapshot()

    assert rows == []
    # The response schema/transport succeeded, but a legacy slug has no
    # durable order ID with which to prove absence. Keep the cleanup check
    # fail-closed while preserving the slug for future cancel sweeps.
    assert verified is False
    service._request.assert_awaited_once_with(
        "GET", "/markets/previous-market/user-orders"
    )
    assert json.loads(scope_path.read_text(encoding="utf-8")) == {
        "account": "0xabc",
        "slugs": ["previous-market"],
    }
    assert service._order_scope_legacy_slugs == {"previous-market"}
    assert service._order_scope_slugs == {"previous-market"}


@pytest.fixture
def scoped_live_service(monkeypatch, tmp_path):
    private_key = "0x" + "4" * 64
    account = Account.from_key(private_key)
    scope_path = tmp_path / "order-scope.json"
    monkeypatch.setattr(settings, "paper_trading", False)
    monkeypatch.setattr(settings, "limitless_private_key", private_key)
    monkeypatch.setattr(settings, "limitless_dedicated_eoa", True)
    monkeypatch.setattr(settings, "limitless_order_scope_file", str(scope_path))

    service = LimitlessService()
    service._account = account
    service._owner_id = 17
    service._meta["123"] = _MarketMeta(
        slug="scope-test-market",
        venue_exchange="0x" + "1" * 40,
        venue_adapter="0x" + "2" * 40,
        yes_token="123",
        no_token="456",
    )
    service._approved_ctf_operators.add(("0x" + "1" * 40).lower())
    return service, scope_path


@pytest.mark.asyncio
async def test_place_order_persists_pre_submit_record_before_http_call(
    scoped_live_service, monkeypatch,
) -> None:
    service, scope_path = scoped_live_service
    expected_salt = 2**127 + 123
    monkeypatch.setattr(
        "app.services.limitless_client.secrets.randbits",
        lambda _: expected_salt,
    )

    async def accepted_after_inspecting_ledger(method, path, body):
        assert (method, path) == ("POST", "/orders")
        assert body["order"]["salt"] == str(expected_salt)
        assert isinstance(body["order"]["salt"], str)
        assert body["order"]["expiration"] == "0"
        assert body["order"]["nonce"] == 0
        persisted = json.loads(scope_path.read_text(encoding="utf-8"))
        assert persisted["slugs"] == ["scope-test-market"]
        assert len(persisted["orders"]) == 1
        assert persisted["orders"][0]["client_order_id"] == body["clientOrderId"]
        assert persisted["orders"][0]["order_id"] == ""
        return {
            "order": {"id": "exchange-order-1"},
            "execution": {"settlementStatus": "LIVE"},
        }

    service._request = AsyncMock(side_effect=accepted_after_inspecting_ledger)

    result = await service.place_order("123", "BUY", 0.50, 2.0)

    assert result.success is True
    persisted = json.loads(scope_path.read_text(encoding="utf-8"))
    assert persisted["orders"] == [
        {
            "client_order_id": result.client_order_id,
            "slug": "scope-test-market",
            "order_type": "GTC",
            "order_id": "exchange-order-1",
            "created_at_ms": persisted["orders"][0]["created_at_ms"],
        }
    ]


@pytest.mark.asyncio
async def test_buy_is_blocked_before_submit_when_sell_approval_is_missing(
    scoped_live_service,
) -> None:
    service, scope_path = scoped_live_service
    service._approved_ctf_operators.clear()
    service._verify_conditional_token_approvals = AsyncMock(
        side_effect=RuntimeError("missing exchange operator")
    )
    service._request = AsyncMock()

    result = await service.place_order("123", "BUY", 0.50, 2.0)

    assert result.success is False
    assert "approval preflight failed" in result.error
    service._request.assert_not_awaited()
    assert not scope_path.exists()


@pytest.mark.asyncio
async def test_explicit_order_rejection_prunes_pre_submit_scope_record(
    scoped_live_service,
) -> None:
    service, scope_path = scoped_live_service
    service._request = AsyncMock(return_value={"error": "http_400"})

    result = await service.place_order("123", "BUY", 0.50, 2.0)

    assert result.success is False
    assert result.raw["submission_uncertain"] is False
    persisted = json.loads(scope_path.read_text(encoding="utf-8"))
    assert persisted["slugs"] == []
    assert persisted["orders"] == []


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "response",
    [
        None,
        {"error": "http_409"},
        {"error": "http_429"},
        {"error": "maintenance"},
        [],
        {"order": {}},
    ],
    ids=(
        "timeout-no-response",
        "conflict",
        "rate-limit",
        "maintenance",
        "malformed-non-object",
        "malformed-success-object",
    ),
)
async def test_uncertain_create_order_response_retains_pre_submit_scope_record(
    scoped_live_service, response
) -> None:
    service, scope_path = scoped_live_service
    # _request converts transport exceptions/timeouts into None. Conflict,
    # throttling, maintenance, and malformed success payloads likewise do not
    # prove that the signed payload was rejected by the exchange.
    service._request = AsyncMock(return_value=response)

    result = await service.place_order("123", "BUY", 0.50, 2.0)

    assert result.success is False
    assert result.raw["submission_uncertain"] is True
    persisted = json.loads(scope_path.read_text(encoding="utf-8"))
    assert persisted["slugs"] == ["scope-test-market"]
    assert len(persisted["orders"]) == 1
    assert persisted["orders"][0]["client_order_id"] == result.client_order_id
    assert persisted["orders"][0]["order_id"] == ""


@pytest.mark.asyncio
async def test_authoritative_terminal_batch_status_prunes_exact_scope_record(
    scoped_live_service,
) -> None:
    service, scope_path = scoped_live_service
    service._remember_order_slug("scope-test-market", "client-1", "GTC")
    assert service._bind_scope_order_id("client-1", "exchange-order-1") is True

    batch_bodies = []

    async def terminal_status(method, path, body=None):
        if (method, path) == (
            "GET",
            "/markets/scope-test-market/user-orders",
        ):
            return {"orders": []}
        if method == "GET" and path.startswith(
            "/markets/scope-test-market/user-orders?statuses="
        ):
            return {
                "orders": [
                    {
                        "id": "exchange-order-1",
                        "clientOrderId": "client-1",
                        "status": "CANCELED",
                    }
                ]
            }
        assert (method, path) == ("POST", "/orders/status/batch")
        batch_bodies.append(body)
        assert body in (
            {"items": [{"clientOrderId": "client-1"}]},
            {"items": [{"orderId": "exchange-order-1"}]},
        )
        return {
            "results": [
                {
                    "index": 0,
                    "status": "found",
                    "orderId": "exchange-order-1",
                    "clientOrderId": "client-1",
                    "data": {
                        "order": {
                            "order": {
                                "id": "exchange-order-1",
                                "price": "0.5",
                            },
                            "execution": {
                                "clientOrderId": "client-1",
                                "settlementStatus": "CANCELED",
                                "totalsRaw": {},
                            },
                        }
                    },
                }
            ]
        }

    service._request = AsyncMock(side_effect=terminal_status)

    statuses = await service.get_order_statuses(["exchange-order-1"])

    assert statuses["exchange-order-1"]["settlement_status"] == "CANCELED"
    assert batch_bodies == [
        {"items": [{"clientOrderId": "client-1"}]},
        {"items": [{"orderId": "exchange-order-1"}]},
    ]
    persisted = json.loads(scope_path.read_text(encoding="utf-8"))
    assert persisted["slugs"] == []
    assert persisted["orders"] == []


@pytest.mark.asyncio
async def test_partial_gtc_failed_settlement_keeps_live_remainder_in_scope(
    scoped_live_service,
) -> None:
    service, scope_path = scoped_live_service
    service._remember_order_slug("scope-test-market", "client-1", "GTC")
    assert service._bind_scope_order_id("client-1", "exchange-order-1") is True

    async def live_partial(method, path, body=None):
        if (method, path) == (
            "GET",
            "/markets/scope-test-market/user-orders",
        ):
            return {
                "orders": [
                    {
                        "id": "exchange-order-1",
                        "clientOrderId": "client-1",
                        "status": "LIVE",
                    }
                ]
            }
        return {
            "results": [
                {
                    "index": 0,
                    "status": "found",
                    "orderId": "exchange-order-1",
                    "clientOrderId": "client-1",
                    "data": {
                        "order": {
                            "order": {
                                "id": "exchange-order-1",
                                "status": "LIVE",
                                "price": "0.5",
                            },
                            "execution": {
                                "clientOrderId": "client-1",
                                "matched": True,
                                "settlementStatus": "FAILED",
                                "totalsRaw": {"contractsGross": "1000000"},
                            },
                        }
                    },
                }
            ]
        }

    service._request = AsyncMock(side_effect=live_partial)

    statuses = await service.get_order_statuses(["exchange-order-1"])

    assert statuses["exchange-order-1"]["is_open"] is True
    persisted = json.loads(scope_path.read_text(encoding="utf-8"))
    assert persisted["slugs"] == ["scope-test-market"]
    assert len(persisted["orders"]) == 1


@pytest.mark.asyncio
async def test_exact_not_found_keeps_uncertain_record_and_snapshot_unverified(
    scoped_live_service,
) -> None:
    service, scope_path = scoped_live_service
    service._remember_order_slug("scope-test-market", "client-1", "FAK")

    async def not_found(method, path, body=None):
        if method == "GET":
            return {"orders": []}
        return {"results": [{"index": 0, "status": "not_found"}]}

    service._request = AsyncMock(side_effect=not_found)

    rows, verified = await service.get_open_orders_snapshot()

    assert rows == []
    assert verified is False
    persisted = json.loads(scope_path.read_text(encoding="utf-8"))
    assert persisted["slugs"] == ["scope-test-market"]
    assert len(persisted["orders"]) == 1


def test_scope_slug_is_reference_counted_by_multiple_orders(
    scoped_live_service,
) -> None:
    service, scope_path = scoped_live_service
    service._remember_order_slug("scope-test-market", "client-1", "GTC")
    service._remember_order_slug("scope-test-market", "client-2", "GTC")

    assert service._forget_scope_orders(client_order_ids={"client-1"}) is True

    persisted = json.loads(scope_path.read_text(encoding="utf-8"))
    assert persisted["slugs"] == ["scope-test-market"]
    assert [row["client_order_id"] for row in persisted["orders"]] == [
        "client-2"
    ]


@pytest.mark.asyncio
async def test_open_order_snapshot_rejects_malformed_success_payload(
    monkeypatch, tmp_path
) -> None:
    monkeypatch.setattr(
        settings,
        "limitless_order_scope_file",
        str(tmp_path / "order-scope.json"),
    )
    monkeypatch.setattr(settings, "limitless_dedicated_eoa", True)
    service = LimitlessService()
    service._slug_by_token["token"] = "current-market"
    service._feed._subscribed.add("token")
    service._request = AsyncMock(return_value={})

    rows, verified = await service.get_open_orders_snapshot()

    assert rows == []
    assert verified is False


@pytest.mark.asyncio
async def test_live_init_rejects_order_scope_from_another_eoa(
    monkeypatch, tmp_path
) -> None:
    private_key = "0x" + "3" * 64
    account = Account.from_key(private_key)
    scope_path = tmp_path / "order-scope.json"
    scope_path.write_text(
        json.dumps({"account": Account.create().address.lower(), "slugs": []}),
        encoding="utf-8",
    )
    monkeypatch.setattr(settings, "limitless_order_scope_file", str(scope_path))
    monkeypatch.setattr(settings, "limitless_dedicated_eoa", True)
    monkeypatch.setattr(settings, "limitless_private_key", private_key)
    monkeypatch.setattr(settings, "limitless_api_token_id", "test-token")
    monkeypatch.setattr(settings, "limitless_api_secret", "dGVzdA==")
    service = LimitlessService()
    service._request = AsyncMock()

    with pytest.raises(RuntimeError, match="belongs to another EOA"):
        await service._init_live_client()

    service._request.assert_not_awaited()
    assert service._account.address == account.address
