import time
from unittest.mock import MagicMock

from app.core.config import settings
from app.services.clob_client import MarketBook, OrderLevel
from app.services.inventory_manager import InventoryManager
from app.services.market_maker import MarketMaker


def _maker():
    clob = MagicMock()
    clob.books = {}
    clob.markets = {}
    return MarketMaker(clob, InventoryManager(), MagicMock())


def test_no_markets_degraded_and_recovers(monkeypatch):
    monkeypatch.setattr(settings, "no_markets_degraded_sec", 1.0)
    mm = _maker()
    mm._update_market_availability()
    mm._no_markets_since_mono = time.monotonic() - 2.0
    mm._update_market_availability()
    assert mm._degraded_reason == "NO_MARKETS"

    mm.clob.books["x"] = MarketBook(
        token_id="x", bids=[OrderLevel(.45, 100)], asks=[OrderLevel(.48, 100)]
    )
    mm._update_market_availability()
    assert mm._degraded_reason == ""


def test_fast_flat_clean_quote_clears_recovery_badge():
    mm = _maker()
    mm._crash_recovery_active = True
    mm._clear_crash_recovery_on_clean_quote()
    assert mm._crash_recovery_active is False


def test_paper_dirty_restart_clears_badge_without_needing_quote(monkeypatch, tmp_path):
    import asyncio
    import app.services.market_maker as mm_mod

    monkeypatch.setattr(settings, "paper_trading", True)
    monkeypatch.setattr(mm_mod, "RUNNING_LOCK_PATH", tmp_path / "RUNNING.lock")
    mm_mod.RUNNING_LOCK_PATH.write_text('{"pid":123,"ts":1}', encoding="utf-8")
    mm = _maker()
    asyncio.run(mm._crash_recovery_check())
    assert mm._crash_recovery_active is False
