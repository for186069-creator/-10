from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock

import pytest

from app.core.config import settings
from app.services.clob_client import MarketBook, OrderLevel
from app.services.inventory_manager import InventoryManager
from app.services.limitless_client import PublicTrade
from app.services.market_maker import ActiveQuote, MarketMaker


def _maker(monkeypatch):
    monkeypatch.setattr(settings, "paper_trading", True)
    monkeypatch.setattr(settings, "paper_fill_model", "conservative")
    inv = InventoryManager()
    inv.bankroll = 25.0
    mm = MarketMaker(MagicMock(books={}, markets={}), inv, MagicMock())
    mm._record_fill = AsyncMock()
    mm._record_paper_opportunity = AsyncMock()
    return mm


@pytest.mark.asyncio
async def test_touch_does_not_create_inferred_maker_fill(monkeypatch):
    mm = _maker(monkeypatch)
    quote = ActiveQuote("hbar", 1, 0.07, None, 0.10, 2.0, 0.10, 9.0, cycle_id=7)
    book = MarketBook(
        token_id="hbar",
        bids=[OrderLevel(0.07, 100)],
        asks=[OrderLevel(0.16, 100)],
    )

    await mm._check_fills_paper("hbar", book, [quote], "HBAR")

    mm._record_fill.assert_not_awaited()


@pytest.mark.asyncio
async def test_price_through_creates_inferred_fill_with_cycle(monkeypatch):
    mm = _maker(monkeypatch)
    quote = ActiveQuote("hbar", 1, 0.07, None, 0.10, 2.0, 0.10, 9.0, cycle_id=7)
    book = MarketBook(
        token_id="hbar",
        bids=[OrderLevel(0.06, 100)],
        asks=[OrderLevel(0.07, 100)],
    )

    await mm._check_fills_paper("hbar", book, [quote], "HBAR")

    call = mm._record_fill.await_args
    assert call.args[1:4] == ("BUY", 0.07, 2.0)
    assert call.kwargs["fill_verification"] == "inferred"
    assert call.kwargs["cycle_id"] == 7


@pytest.mark.asyncio
async def test_queue_must_be_consumed_before_inferred_fill(monkeypatch):
    mm = _maker(monkeypatch)
    quote = ActiveQuote(
        "hbar", 1, 0.07, None, 0.10, 2.0, 0.10, 9.0, cycle_id=8,
        book_update_at_place=100.0, bid_queue_ahead_tokens=50.0,
        bid_last_visible_tokens=50.0,
    )
    first = MarketBook(
        token_id="hbar", bids=[OrderLevel(0.07, 20)],
        asks=[OrderLevel(0.08, 100)], last_update=101.0,
    )
    await mm._check_fills_paper("hbar", first, [quote], "HBAR")
    mm._record_fill.assert_not_awaited()
    assert quote.bid_inferred_through_tokens == 30.0

    crossed = MarketBook(
        token_id="hbar", bids=[OrderLevel(0.06, 20)],
        asks=[OrderLevel(0.07, 10)], last_update=102.0,
    )
    await mm._check_fills_paper("hbar", crossed, [quote], "HBAR")
    call = mm._record_fill.await_args
    assert call.kwargs["queue_ahead_tokens"] == 50.0
    assert call.kwargs["inferred_through_tokens"] == 60.0
    assert call.kwargs["fill_evidence_source"] == "book_price_through_after_queue"


@pytest.mark.asyncio
async def test_limitless_real_sell_trade_consumes_queue_then_fills(monkeypatch):
    class TradeFeed:
        public_trade_seq = 0
        books = {}
        markets = {}

        def public_trades_since(self, token_id, after_seq, *, placed_wall_time=0):
            return [PublicTrade(
                seq=1, event_key="trade-1", token_id=token_id,
                side="SELL", price=0.10, contracts=8.0,
                traded_at=101.0, tx_hash="0x1",
            )]

    monkeypatch.setattr(settings, "paper_trading", True)
    monkeypatch.setattr(settings, "paper_fill_model", "conservative")
    inv = InventoryManager()
    inv.bankroll = 25.0
    mm = MarketMaker(TradeFeed(), inv, MagicMock())
    mm._record_fill = AsyncMock()
    mm._record_paper_opportunity = AsyncMock()
    quote = ActiveQuote(
        "x", 1, 0.11, None, 0.15, 0.33, 0.15, 4.0,
        placed_wall_time=100.0, bid_queue_ahead_tokens=5.0,
    )
    book = MarketBook(
        "x", bids=[OrderLevel(.09, 20)], asks=[OrderLevel(.20, 20)],
        tick_size=.001, last_update=10.0,
    )

    await mm._check_fills_paper("x", book, [quote], "X")

    call = mm._record_fill.await_args
    assert call.args[1:4] == ("BUY", 0.11, pytest.approx(0.33))
    assert call.kwargs["queue_ahead_tokens"] == 5.0
    assert call.kwargs["inferred_through_tokens"] == pytest.approx(8.0)
    assert call.kwargs["fill_evidence_source"] == "limitless_new_trade_after_queue"


@pytest.mark.asyncio
async def test_one_public_trade_volume_is_not_duplicated_across_levels(monkeypatch):
    class TradeFeed:
        public_trade_seq = 0
        books = {}
        markets = {}

        def public_trades_since(self, token_id, after_seq, *, placed_wall_time=0):
            return [PublicTrade(
                seq=1, event_key="trade-1", token_id=token_id,
                side="SELL", price=0.10, contracts=7.0, traded_at=101.0,
            )]

    monkeypatch.setattr(settings, "paper_trading", True)
    monkeypatch.setattr(settings, "paper_fill_model", "conservative")
    inv = InventoryManager()
    inv.bankroll = 25.0
    mm = MarketMaker(TradeFeed(), inv, MagicMock())
    mm._record_fill = AsyncMock()
    mm._record_paper_opportunity = AsyncMock()
    quotes = [
        ActiveQuote("x", 1, .11, None, .15, .55, .15, 4,
                    placed_wall_time=100.0),
        ActiveQuote("x", 2, .105, None, .15, .525, .15, 4,
                    placed_wall_time=100.0),
    ]
    book = MarketBook("x", tick_size=.001, last_update=10.0)

    await mm._check_fills_paper("x", book, quotes, "X")

    filled_tokens = sum(
        call.args[3] / call.args[2] for call in mm._record_fill.await_args_list
    )
    assert filled_tokens == pytest.approx(7.0)
    assert len(mm._record_fill.await_args_list) == 2


@pytest.mark.asyncio
async def test_opportunity_journal_reaches_100_observations(monkeypatch):
    import app.core.db as db_mod

    class FakeSession:
        async def __aenter__(self): return self
        async def __aexit__(self, *_): return False
        def add(self, _): pass
        async def commit(self): pass

    monkeypatch.setattr(db_mod, "AsyncSessionLocal", lambda: FakeSession())
    mm = _maker(monkeypatch)
    # Exercise the real journal method, not the fixture spy.
    del mm._record_paper_opportunity
    quote = ActiveQuote("x", 1, .45, None, .5, 2.0, .5, 5.0, cycle_id=1)
    book = MarketBook("x", bids=[OrderLevel(.44, 10)], asks=[OrderLevel(.46, 10)])
    for i in range(100):
        book.last_update = 1000.0 + i
        await mm._record_paper_opportunity(quote, book, "BUY", False, 0.0, 0.0)
    assert mm._paper_opportunity_count == 100


@pytest.mark.asyncio
async def test_paper_reset_clears_evidence_journal_and_fast_flat_state(monkeypatch):
    import app.admin.api as api

    monkeypatch.setattr(settings, "paper_trading", True)
    mm = SimpleNamespace(
        active_quotes={}, _fill_count=4, _round_trip_count=2, _cycle_count=9,
        _hedge_attempts=1, _hedge_fills=1, _liquidation_count=1,
        _profit_take_count=1, _loss_forced_count=1, _no_hedge_count=1,
        _hedged_positions=set(), _drawdown_stopped=set(), _mid_history={},
        _momentum_bid_blocked=set(), _momentum_ask_blocked=set(),
        _pending_orders={}, _paper_opportunity_count=104,
        _paper_inferred_candidate_count=3, _paper_random_candidate_count=8,
        _fast_flat_state=object(), _fast_flat_cycle_seq=12,
    )
    inventory = SimpleNamespace(
        inventories={"x": object()}, bankroll=1.0, starting_balance=1.0,
        consecutive_losses=2, daily_pnl=-1.0, halted=True, halt_reason="test",
        clear_saved_state=AsyncMock(),
    )
    monkeypatch.setattr(api, "_mm", mm)
    monkeypatch.setattr(api, "_inventory", inventory)
    monkeypatch.setattr(api, "_clob", MagicMock())
    monkeypatch.setattr(api, "_risk", MagicMock())
    db = SimpleNamespace(execute=AsyncMock(), commit=AsyncMock())

    result = await api.reset_paper(db)

    assert result == {"ok": True, "new_bankroll": settings.paper_balance_usdc}
    assert mm._paper_opportunity_count == 0
    assert mm._paper_inferred_candidate_count == 0
    assert mm._paper_random_candidate_count == 0
    assert mm._fast_flat_state is None
    assert mm._fast_flat_cycle_seq == 0
    statements = [str(call.args[0]) for call in db.execute.await_args_list]
    assert any("mm_paper_fill_opportunities" in stmt for stmt in statements)
