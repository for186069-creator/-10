from unittest.mock import AsyncMock, MagicMock

import pytest

import app.services.market_maker as mm_mod
from app.core.config import settings
from app.services.inventory_manager import Inventory, InventoryManager
from app.services.market_maker import MarketMaker
from app.services.risk.risk_manager import RiskManager


def _maker_with_position(*, token_id: str = "yes-token"):
    clob = MagicMock()
    clob.books = {}
    clob.markets = {}
    clob.last_ws_msg_age = 1.0

    inventory = InventoryManager()
    inventory.bankroll = 8.0
    inventory.starting_balance = 10.0
    inventory.inventories[token_id] = Inventory(
        token_id=token_id,
        market_name="Test market",
        net_tokens=4.0,
        avg_entry_price=0.5,
    )
    maker = MarketMaker(clob, inventory, RiskManager(inventory, clob))
    maker._persist_trade = AsyncMock()
    return maker, clob, inventory


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("resolved_price", "expected_bankroll", "expected_pnl"),
    [(1.0, 12.0, 2.0), (0.0, 8.0, -2.0)],
)
async def test_paper_resolution_is_atomic_and_not_double_credited(
    monkeypatch, tmp_path, resolved_price, expected_bankroll, expected_pnl
):
    monkeypatch.setattr(mm_mod, "RUNNING_LOCK_PATH", tmp_path / "RUNNING.lock")
    monkeypatch.setattr(settings, "paper_trading", True)
    monkeypatch.setattr(settings, "orphaned_reconcile_interval_sec", 1.0)
    maker, clob, inventory = _maker_with_position()
    clob.fetch_market_status = AsyncMock(
        return_value={"is_resolved": True, "resolved_price": resolved_price}
    )

    await maker._reconcile_orphaned_positions()
    await maker._reconcile_orphaned_positions()

    assert inventory.bankroll == pytest.approx(expected_bankroll)
    assert inventory.daily_pnl == pytest.approx(expected_pnl)
    assert "yes-token" not in inventory.inventories
    maker._persist_trade.assert_awaited_once()
    assert maker._persist_trade.await_args.kwargs["exit_path"] == "PAPER_REDEEM"


@pytest.mark.asyncio
async def test_live_resolution_retains_tokens_until_redeem_confirmation(
    monkeypatch, tmp_path
):
    monkeypatch.setattr(mm_mod, "RUNNING_LOCK_PATH", tmp_path / "RUNNING.lock")
    monkeypatch.setattr(settings, "paper_trading", False)
    monkeypatch.setattr(settings, "orphaned_reconcile_interval_sec", 1.0)
    maker, clob, inventory = _maker_with_position()
    clob.fetch_market_status = AsyncMock(
        return_value={"is_resolved": True, "resolved_price": 1.0}
    )

    await maker._reconcile_orphaned_positions()
    await maker._reconcile_orphaned_positions()

    assert inventory.bankroll == pytest.approx(8.0)
    assert inventory.inventories["yes-token"].net_tokens == pytest.approx(4.0)
    assert "yes-token" in maker._live_resolved_waiting_redeem
    maker._persist_trade.assert_not_awaited()
