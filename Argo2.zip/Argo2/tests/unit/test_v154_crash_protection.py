"""
tests/unit/test_v154_crash_protection.py — v1.0.154 crash protection.

1. RUNNING.lock created on start, removed on clean stop.
2. Start with a surviving lock → cancel_all runs BEFORE any place_order.
3. Position drift after crash: DB says 5 tokens, wallet says 3 → warning.
4. LIVE order watchdog: an order older than the max age is cancelled and
   removed from active_quotes (the cycle re-places it) even with an
   unchanged price; exchange-side strays are cancelled outright.
"""
from __future__ import annotations

import json
import time
from unittest.mock import AsyncMock, MagicMock

import pytest

import app.services.market_maker as mm_mod
from app.services.market_maker import ActiveQuote, MarketMaker


def _mk_mm(monkeypatch, tmp_path, paper=True):
    from app.core.config import settings
    from app.services.inventory_manager import InventoryManager
    from app.services.risk.risk_manager import RiskManager

    # isolate the lock file per test
    monkeypatch.setattr(mm_mod, "RUNNING_LOCK_PATH", tmp_path / "RUNNING.lock")
    monkeypatch.setattr(settings, "paper_trading", paper)
    monkeypatch.setattr(settings, "auto_start_trading", False)
    monkeypatch.setattr(settings, "inventory_liquidation_enabled", False)

    clob = MagicMock()
    clob.books = {}
    clob.markets = {}
    clob.cancel_all = AsyncMock(return_value=3)
    clob.cancel_order = AsyncMock(return_value=True)
    clob.place_order = AsyncMock()
    clob.get_open_orders = AsyncMock(return_value=[])
    clob.get_open_orders_snapshot = AsyncMock(return_value=([], True))
    clob.last_ws_msg_age = 1.0

    inventory = InventoryManager()
    inventory.bankroll = 100.0
    risk = RiskManager(inventory, clob)
    mm = MarketMaker(clob, inventory, risk)
    return mm


@pytest.mark.asyncio
async def test_lock_created_on_start_removed_on_clean_stop(monkeypatch, tmp_path):
    mm = _mk_mm(monkeypatch, tmp_path)
    lock = mm_mod.RUNNING_LOCK_PATH

    await mm.start()
    assert lock.exists(), "RUNNING.lock must be created on start"
    info = json.loads(lock.read_text(encoding="utf-8"))
    assert info.get("pid") and info.get("ts")

    await mm.stop()
    assert not lock.exists(), "clean stop must remove RUNNING.lock"


@pytest.mark.asyncio
async def test_dirty_start_cancels_all_before_any_order(monkeypatch, tmp_path):
    from app.core.config import settings

    mm = _mk_mm(monkeypatch, tmp_path, paper=False)
    monkeypatch.setattr(settings, "paper_trading", False)
    lock = mm_mod.RUNNING_LOCK_PATH
    lock.write_text(json.dumps({"pid": 12345, "ts": time.time() - 3600}), encoding="utf-8")

    call_order: list[str] = []
    mm.clob.cancel_all = AsyncMock(side_effect=lambda: call_order.append("cancel_all") or 2)
    mm.clob.place_order = AsyncMock(side_effect=lambda *a, **k: call_order.append("place_order"))

    await mm.start()
    try:
        assert mm._crash_recovery_active, "recovery badge must be raised"
        assert "cancel_all" in call_order, "dirty restart must sweep the exchange"
        assert "place_order" not in call_order[: call_order.index("cancel_all") + 1], (
            "no order may be placed before the cancel-all sweep"
        )
        assert mm.clob.place_order.await_count == 0, (
            "start() itself must not place any orders"
        )
    finally:
        await mm.stop()


@pytest.mark.asyncio
async def test_position_drift_logged_after_crash(monkeypatch, tmp_path, caplog):
    """DB inventory 5 tokens, wallet 3 → position_drift_after_crash."""
    from app.services.inventory_manager import Inventory

    mm = _mk_mm(monkeypatch, tmp_path, paper=False)
    inv = Inventory(token_id="tok-d", market_name="D")
    inv.net_tokens = 5.0
    inv.avg_entry_price = 0.40
    mm.inventory.inventories["tok-d"] = inv
    mm.clob.get_positions = AsyncMock(
        return_value=[{"token_id": "tok-d", "tokens": 3.0}]
    )

    drift_logs: list[dict] = []
    orig_warning = mm_mod.log.warning

    def spy(event, **kw):
        if event == "position_drift_after_crash":
            drift_logs.append(kw)
        return orig_warning(event, **kw)

    monkeypatch.setattr(mm_mod.log, "warning", spy)

    await mm._check_position_drift_after_crash()

    assert len(drift_logs) == 1
    assert drift_logs[0]["db_tokens"] == pytest.approx(5.0)
    assert drift_logs[0]["wallet_tokens"] == pytest.approx(3.0)
    assert drift_logs[0]["delta"] == pytest.approx(-2.0)


@pytest.mark.asyncio
async def test_watchdog_requotes_old_order_even_without_price_move(monkeypatch, tmp_path):
    from app.core.config import settings

    mm = _mk_mm(monkeypatch, tmp_path, paper=False)
    monkeypatch.setattr(settings, "paper_trading", False)
    monkeypatch.setattr(settings, "live_requote_max_order_age_sec", 120.0)

    old_q = ActiveQuote(
        token_id="tok-w",
        level=1,
        bid_price=0.48,
        ask_price=0.52,
        mid_at_place=0.50,
        size_usdc=3.0,
        reservation_price=0.50,
        spread_cents=2.0,
        bid_order_id="bid-old",
        ask_order_id="ask-old",
    )
    old_q.placed_at = time.monotonic() - 300.0  # older than max age
    fresh_q = ActiveQuote(
        token_id="tok-w",
        level=2,
        bid_price=0.47,
        ask_price=0.53,
        mid_at_place=0.50,
        size_usdc=2.0,
        reservation_price=0.50,
        spread_cents=2.0,
        bid_order_id="bid-new",
    )
    mm.active_quotes["tok-w"] = [old_q, fresh_q]
    # a stray exchange-side order unknown to the bot
    mm.clob.get_open_orders = AsyncMock(
        return_value=[{"id": "bid-new"}, {"id": "stray-123"}]
    )

    await mm._sweep_old_live_orders()

    cancelled = [c.args[0] for c in mm.clob.cancel_order.await_args_list]
    assert "bid-old" in cancelled and "ask-old" in cancelled, (
        "order older than max age must be cancelled even with unchanged price"
    )
    assert "stray-123" in cancelled, "stray exchange order must be cancelled"
    assert "bid-new" not in cancelled, "fresh tracked order must survive"
    remaining = mm.active_quotes.get("tok-w", [])
    assert old_q not in remaining and fresh_q in remaining, (
        "old quote must leave active_quotes so the cycle re-places it"
    )


@pytest.mark.asyncio
async def test_watchdog_noop_in_paper(monkeypatch, tmp_path):
    from app.core.config import settings

    mm = _mk_mm(monkeypatch, tmp_path, paper=True)
    monkeypatch.setattr(settings, "paper_trading", True)
    q = ActiveQuote(
        token_id="tok-p", level=1, bid_price=0.48, ask_price=0.52,
        mid_at_place=0.50, size_usdc=2.0, reservation_price=0.50,
        spread_cents=2.0, bid_order_id="b1",
    )
    q.placed_at = time.monotonic() - 9999.0
    mm.active_quotes["tok-p"] = [q]

    await mm._sweep_old_live_orders()

    assert mm.clob.cancel_order.await_count == 0
    assert mm.active_quotes["tok-p"] == [q]


# ── v1.0.155: intraday wide-spread guard ─────────────────────────────────


@pytest.mark.asyncio
async def test_wide_spread_intraday_stops_new_quoting(monkeypatch, tmp_path):
    """A held market whose spread blew past 30¢ intraday must not receive
    new quotes (PAPER fill model fantasy-profits on torn books)."""
    from app.core.config import settings
    from app.services.clob_client import MarketBook, OrderLevel, MarketInfo

    mm = _mk_mm(monkeypatch, tmp_path, paper=True)
    monkeypatch.setattr(settings, "spread_min_cents", 1.0)
    tid = "tok-wide"
    book = MarketBook(
        token_id=tid,
        bids=[OrderLevel(0.03, 100)],
        asks=[OrderLevel(0.50, 100)],  # 47¢ spread — crashed book
        last_price=0.10,
    )
    mm.clob.books[tid] = book
    mm.clob.markets[tid] = MarketInfo(
        token_id=tid, condition_id="c", question="Wide", outcome="Yes",
        end_date_ts=time.time() + 86400, volume_24h=1000.0,
    )
    mm._trading_paused = False
    placed = AsyncMock()
    mm._place_multi_level_quotes = placed

    await mm._process_market(tid, book)

    assert placed.await_count == 0, (
        "no new quotes may be placed on a book with spread > 30¢"
    )
