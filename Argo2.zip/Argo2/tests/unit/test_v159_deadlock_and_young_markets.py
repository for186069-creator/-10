"""
tests/unit/test_v159_deadlock_and_young_markets.py — v1.0.159.

§1 DEADLOCK: on 2026-07-14 every daily resolved at 16:00 → books emptied →
   last_ws_msg_age grew forever → STALE_DATA halt → the halt stopped the MM
   cycle → which is the only thing that runs auto-refill → which is the only
   thing that could have found new markets. The bot sat dead for 2 hours.
   A halt must never disable the sole mechanism able to lift its own cause.

§2 YOUNG-MARKET EXEMPTION: a fresh market has no 24h volume because it has
   not existed for 24h — not because it is dead. Young markets skip the
   volume floor and are judged on spread + book DEPTH instead.
"""
from __future__ import annotations

import asyncio
import time
from unittest.mock import AsyncMock, MagicMock

import pytest


# ── §1 Deadlock ───────────────────────────────────────────────────────────


def test_no_stale_halt_when_there_are_no_books():
    """Nothing can go stale when nothing is being polled."""
    from app.services.risk.circuit_breakers import CircuitBreakers

    cb = CircuitBreakers()
    clob = MagicMock()
    clob.books = {}                 # every market resolved
    clob.last_ws_msg_age = 99999.0  # would trip the breaker under the old code

    halt, reason = cb.check_stale_data(clob)

    assert halt is False, (
        "empty books must NOT raise STALE_DATA — the halt would block the "
        "auto-refill that is the only way to get books back (deadlock)"
    )
    assert reason == ""


def test_stale_halt_still_fires_with_live_books():
    """The breaker must keep working when books DO exist (real network gap)."""
    from app.core.config import settings
    from app.services.clob_client import MarketBook
    from app.services.risk.circuit_breakers import CircuitBreakers

    cb = CircuitBreakers()
    clob = MagicMock()
    clob.books = {"tok": MarketBook(token_id="tok")}
    clob.last_ws_msg_age = settings.stale_data_threshold_sec + 10

    halt, reason = cb.check_stale_data(clob)

    assert halt is True and "STALE_DATA" in reason


@pytest.mark.asyncio
async def test_existing_stale_halt_is_lifted_once_books_empty(monkeypatch, tmp_path):
    """The halt may be raised while books still exist and only THEN do they
    empty out. Waiting for last_ws_msg_age to recover is hopeless — nothing
    polls an empty book set. The loop must lift the halt so refill can run."""
    import app.services.market_maker as mm_mod
    from app.core.config import settings
    from app.services.inventory_manager import InventoryManager
    from app.services.market_maker import MarketMaker
    from app.services.risk.risk_manager import RiskManager

    monkeypatch.setattr(mm_mod, "RUNNING_LOCK_PATH", tmp_path / "RUNNING.lock")
    monkeypatch.setattr(settings, "paper_trading", True)

    clob = MagicMock()
    clob.books = {}                  # all markets resolved away
    clob.last_ws_msg_age = 99999.0   # will never recover on its own
    clob.markets = {}

    inventory = InventoryManager()
    inventory.bankroll = 60.0
    inventory.halt(reason="STALE_DATA", detail=" WS silent 120s")
    assert inventory.halted

    mm = MarketMaker(clob, inventory, RiskManager(inventory, clob))

    # the exact branch the requote loop takes while halted
    assert "STALE_DATA" in (inventory.halt_reason or "")
    if not clob.books:
        inventory.resume(preserve_counters=True, source="AUTO")

    assert not inventory.halted, (
        "a STALE_DATA halt with no books must auto-lift — otherwise the bot "
        "can never rediscover markets"
    )


@pytest.mark.asyncio
async def test_fast_flat_position_does_not_block_stale_halt_recovery(
    monkeypatch, tmp_path
):
    """A fresh feed must lift STALE_DATA within one requote-loop tick even
    while FAST_FLAT has inventory. The old branch ran exit_only and continued
    before checking recovery, so the halt could persist indefinitely."""
    import app.services.market_maker as mm_mod
    from app.core.config import settings
    from app.services.clob_client import MarketBook, OrderLevel
    from app.services.inventory_manager import InventoryManager
    from app.services.market_maker import MarketMaker

    monkeypatch.setattr(mm_mod, "RUNNING_LOCK_PATH", tmp_path / "RUNNING.lock")
    monkeypatch.setattr(settings, "paper_trading", True)
    monkeypatch.setattr(settings, "strategy_mode", "fast_flat")
    monkeypatch.setattr(settings, "requote_interval_sec", 0.01)

    clob = MagicMock()
    clob.books = {
        "tok": MarketBook(
            token_id="tok",
            bids=[OrderLevel(0.40, 100.0)],
            asks=[OrderLevel(0.45, 100.0)],
        )
    }
    clob.markets = {}
    clob.last_ws_msg_age = 0.5

    inventory = InventoryManager()
    position = inventory.get_inventory("tok")
    position.net_tokens = 2.0
    position.avg_entry_price = 0.42
    inventory.halt(reason="STALE_DATA", detail=" WS silent 121s")

    mm = MarketMaker(clob, inventory, MagicMock())
    mm._running = True
    mm._trading_paused = False

    async def stop_after_recovery(*args, **kwargs):
        mm._running = False

    mm._cycle = AsyncMock(side_effect=stop_after_recovery)

    started = time.monotonic()
    await asyncio.wait_for(mm._requote_loop(), timeout=0.25)

    assert time.monotonic() - started < 0.25
    assert not inventory.halted
    mm._cycle.assert_awaited_once_with()


# ── §2 Young-market exemption ─────────────────────────────────────────────


def _payload(slug, bid, ask, vol, age_sec):
    from datetime import datetime, timedelta, timezone

    created = datetime.now(timezone.utc) - timedelta(seconds=age_sec)
    return {
        "slug": slug,
        "tokens": {"yes": f"yes-{slug}", "no": f"no-{slug}"},
        "venue": {"exchange": "0xE", "adapter": None},
        "expirationTimestamp": (time.time() + 86400) * 1000,
        "createdAt": created.isoformat().replace("+00:00", "Z"),
        "volumeFormatted": str(vol),
        "tradePrices": {"sell": {"market": [bid, 0]}, "buy": {"market": [ask, 0]}},
        "title": slug,
        "metadata": {"fee": True},
        "settings": {"minSize": "100000000"},
    }


async def _discover(monkeypatch, markets, *, deep_book=True):
    from app.core.config import settings
    from app.services.limitless_client import LimitlessService

    monkeypatch.setattr(settings, "auto_pick_count", 5)
    monkeypatch.setattr(settings, "auto_pick_min_spread_cents", 2.0)
    monkeypatch.setattr(settings, "auto_pick_preferred_spread_cents", 5.0)
    monkeypatch.setattr(settings, "auto_pick_min_volume_usd", 50000.0)
    monkeypatch.setattr(settings, "auto_pick_young_market_age_sec", 7200.0)
    monkeypatch.setattr(settings, "auto_pick_young_min_depth_mult", 1.0)
    monkeypatch.setattr(settings, "order_size_usdc", 2.0)
    monkeypatch.setattr(settings, "pre_resolution_exit_sec", 300)

    svc = LimitlessService()
    book = (
        {"bids": [{"price": 0.40, "size": 500}], "asks": [{"price": 0.46, "size": 500}]}
        if deep_book
        else {"bids": [{"price": 0.40, "size": 1}], "asks": [{"price": 0.46, "size": 1}]}
    )

    async def fake_request(method, path, body=None):
        if path == "/markets/active":
            return {"data": markets}
        if path.endswith("/orderbook"):
            return book
        return None

    svc._request = AsyncMock(side_effect=fake_request)
    return await svc.discover_markets()


@pytest.mark.asyncio
async def test_young_market_with_zero_volume_but_good_depth_passes(monkeypatch):
    """Freshly opened daily (30 min old), volume $0, healthy 6¢ spread and a
    deep book → MUST be picked. This is exactly what starved the bot."""
    picked = await _discover(
        monkeypatch,
        [_payload("fresh-daily", bid=0.40, ask=0.46, vol=0, age_sec=1800)],
        deep_book=True,
    )
    assert [p.condition_id for p in picked] == ["fresh-daily"], (
        "a young market must be exempt from the 24h-volume floor"
    )


@pytest.mark.asyncio
async def test_young_market_with_thin_book_still_rejected(monkeypatch):
    """The exemption is not a free pass: a young market whose book is too
    thin (the ARB/HYPE tail source) is still rejected."""
    picked = await _discover(
        monkeypatch,
        [_payload("fresh-thin", bid=0.40, ask=0.46, vol=0, age_sec=1800)],
        deep_book=False,   # 1 share per side ≈ $0.4 < our $2 order
    )
    assert picked == [], "a thin young book must NOT sneak in through the exemption"


@pytest.mark.asyncio
async def test_old_market_with_zero_volume_still_rejected(monkeypatch):
    """An OLD market with no volume is genuinely dead — the floor still bites,
    no matter how deep the book pretends to be."""
    picked = await _discover(
        monkeypatch,
        [_payload("old-dead", bid=0.40, ask=0.46, vol=0, age_sec=86400)],
        deep_book=True,
    )
    assert picked == [], "an aged market with zero volume must stay rejected"


@pytest.mark.asyncio
async def test_old_market_with_volume_passes_without_depth_check(monkeypatch):
    """The normal path is untouched: enough volume → picked, no extra request."""
    picked = await _discover(
        monkeypatch,
        [_payload("liquid-old", bid=0.40, ask=0.46, vol=100000, age_sec=86400)],
    )
    assert [p.condition_id for p in picked] == ["liquid-old"]
