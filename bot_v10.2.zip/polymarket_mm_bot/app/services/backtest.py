"""
app/services/backtest.py — v10.0 Backtesting Framework
═══════════════════════════════════════════════════════
Replays historical order book snapshots through the MM engine.
"""
from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

logger = logging.getLogger(__name__)


@dataclass
class BacktestConfig:
    snapshot_file: str = ""
    start_balance: float = 200.0
    spread_cents: float = 4.0
    order_size_usdc: float = 15.0
    max_inventory_usdc: float = 50.0
    max_snapshots: int = 0
    snapshot_stride: int = 1


@dataclass
class BacktestResults:
    start_balance: float = 0.0
    final_balance: float = 0.0
    total_pnl: float = 0.0
    total_trades: int = 0
    buys: int = 0
    sells: int = 0
    winning_trades: int = 0
    losing_trades: int = 0
    win_rate: float = 0.0
    max_drawdown: float = 0.0
    peak_balance: float = 0.0
    snapshots_processed: int = 0
    duration_sec: float = 0.0

    def summary(self) -> str:
        return (
            f"Backtest Results:\n"
            f"  Start balance: ${self.start_balance:.2f}\n"
            f"  Final balance: ${self.final_balance:.2f}\n"
            f"  Total P&L: ${self.total_pnl:.2f}\n"
            f"  Trades: {self.total_trades} ({self.buys}B/{self.sells}S)\n"
            f"  Win rate: {self.win_rate:.1f}%\n"
            f"  Max drawdown: ${abs(self.max_drawdown):.2f}\n"
        )


class BacktestRunner:
    def __init__(self, config: BacktestConfig):
        self.config = config
        self.snapshots: list[dict] = []
        self.balance = config.start_balance
        self.peak_balance = config.start_balance
        self.max_drawdown = 0.0
        self.trades: list[dict] = []

    def load_snapshots(self) -> int:
        path = Path(self.config.snapshot_file)
        if not path.exists():
            logger.error("Snapshot file not found: %s", path)
            return 0
        count = 0
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    snap = json.loads(line)
                    self.snapshots.append(snap)
                    count += 1
                    if self.config.max_snapshots and count >= self.config.max_snapshots:
                        break
                except json.JSONDecodeError:
                    pass
        if self.config.snapshot_stride > 1:
            self.snapshots = self.snapshots[::self.config.snapshot_stride]
        return len(self.snapshots)

    def run(self) -> BacktestResults:
        import time as _time
        start_time = _time.monotonic()
        results = BacktestResults(start_balance=self.config.start_balance)
        if not self.snapshots:
            self.load_snapshots()
        results.snapshots_processed = len(self.snapshots)
        for snap in self.snapshots:
            try:
                self._process_snapshot(snap)
            except Exception as e:
                logger.debug("Snapshot error: %s", e)
            if self.balance > self.peak_balance:
                self.peak_balance = self.balance
            drawdown = self.balance - self.peak_balance
            if drawdown < self.max_drawdown:
                self.max_drawdown = drawdown
        results.final_balance = self.balance
        results.total_pnl = self.balance - self.config.start_balance
        results.buys = sum(1 for t in self.trades if t["side"] == "BUY")
        results.sells = sum(1 for t in self.trades if t["side"] == "SELL")
        results.total_trades = len(self.trades)
        results.winning_trades = sum(1 for t in self.trades if t.get("pnl", 0) > 0)
        results.losing_trades = sum(1 for t in self.trades if t.get("pnl", 0) < 0)
        results.win_rate = results.winning_trades / max(results.winning_trades + results.losing_trades, 1) * 100
        results.max_drawdown = self.max_drawdown
        results.duration_sec = _time.monotonic() - start_time
        return results

    def _process_snapshot(self, snap: dict):
        import random
        token_id = snap.get("token_id", "")
        if not token_id:
            return
        bids = snap.get("bids", [])
        asks = snap.get("asks", [])
        if not bids or not asks:
            return
        best_bid = bids[0][0]
        best_ask = asks[0][0]
        mid = (best_bid + best_ask) / 2
        spread_dollars = self.config.spread_cents / 100
        our_bid = mid - spread_dollars / 2
        our_ask = mid + spread_dollars / 2
        if our_bid >= best_bid - 0.001 and random.random() < 0.05:
            self._execute_fill(token_id, "BUY", our_bid, self.config.order_size_usdc)
        if our_ask <= best_ask + 0.001 and random.random() < 0.05:
            self._execute_fill(token_id, "SELL", our_ask, self.config.order_size_usdc)

    def _execute_fill(self, token_id, side, price, size_usdc):
        pnl = 0.0
        if side == "BUY":
            self.balance -= size_usdc
        else:
            self.balance += size_usdc
        self.trades.append({
            "token_id": token_id, "side": side, "price": price,
            "size_usdc": size_usdc, "pnl": pnl,
            "timestamp": datetime.utcnow().isoformat(),
        })
