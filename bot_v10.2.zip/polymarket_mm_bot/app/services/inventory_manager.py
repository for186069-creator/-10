"""
app/services/inventory_manager.py — Position tracking & risk control
════════════════════════════════════════════════════════════════════
Tracks:
  - Net inventory per market (in tokens and USD)
  - Average entry price (for realized P&L on sells)
  - Unrealized P&L (mark-to-mid)
  - Bankroll (paper: starts at $200, grows/shrinks with realized P&L)

Risk controls:
  - Max inventory per market ($50 or 25% of bankroll)
  - Skew quotes when inventory grows (discourage more accumulation)
  - Force one-sided quotes when inventory near max
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field

from app.core.config import settings

logger = logging.getLogger(__name__)


@dataclass
class Inventory:
    """Per-market inventory state."""
    token_id: str
    market_name: str = ""
    net_tokens: float = 0.0       # + = long, - = short
    avg_entry_price: float = 0.0  # weighted average buy price
    realized_pnl: float = 0.0     # cumulative realized P&L for this market
    fill_count_buy: int = 0
    fill_count_sell: int = 0

    @property
    def net_usdc_at_entry(self) -> float:
        """USD value of net position at entry price."""
        return self.net_tokens * self.avg_entry_price

    def unrealized_pnl(self, current_mid: float) -> float:
        """Mark-to-mid unrealized P&L."""
        return self.net_tokens * (current_mid - self.avg_entry_price)

    def inventory_ratio(self, max_usdc: float) -> float:
        """How close we are to max inventory (-1..+1)."""
        if max_usdc <= 0:
            return 0.0
        # Use entry-price value as risk measure
        return max(-1.0, min(1.0, self.net_usdc_at_entry / max_usdc))


class InventoryManager:
    """Centralized inventory + bankroll tracking."""

    def __init__(self) -> None:
        self.inventories: dict[str, Inventory] = {}
        self.bankroll: float = settings.paper_balance_usdc
        self.consecutive_losses: int = 0
        self.daily_pnl: float = 0.0
        self.halted: bool = False
        self.halt_reason: str = ""

    # ── Inventory access ─────────────────────────────────────────────────────

    def get_inventory(self, token_id: str) -> Inventory:
        if token_id not in self.inventories:
            self.inventories[token_id] = Inventory(token_id=token_id)
        return self.inventories[token_id]

    def max_inventory_usdc(self) -> float:
        """Effective max inventory (respects both $ cap and % cap)."""
        pct_cap = self.bankroll * settings.max_inventory_pct_of_bankroll
        return min(settings.max_inventory_usdc, pct_cap)

    # ── Fill processing ──────────────────────────────────────────────────────

    def on_fill(
        self,
        token_id: str,
        side: str,             # "BUY" or "SELL"
        price: float,
        size_usdc: float,
        market_name: str = "",
    ) -> float:
        """Process a fill, update inventory + bankroll. Returns realized P&L."""
        inv = self.get_inventory(token_id)
        inv.market_name = market_name

        tokens = size_usdc / max(price, 0.001)
        realized = 0.0

        if side == "BUY":
            # Adding to long position
            new_total_tokens = inv.net_tokens + tokens
            if inv.net_tokens >= 0:
                # Increasing long — update avg entry
                new_cost = inv.net_tokens * inv.avg_entry_price + tokens * price
                inv.avg_entry_price = new_cost / max(new_total_tokens, 0.001)
            else:
                # Reducing short — realize P&L
                # Short was opened at avg_entry, now buying back at `price`
                # P&L = (entry - price) * tokens (if short, entry > price = profit)
                realized = (inv.avg_entry_price - price) * tokens
                # Adjust avg entry for remaining short
                # (simplified — assumes we reduce short proportionally)
            inv.net_tokens = new_total_tokens
            inv.fill_count_buy += 1
            self.bankroll -= size_usdc  # we paid cash
        else:  # SELL
            # Selling tokens (or going short)
            new_total_tokens = inv.net_tokens - tokens
            if inv.net_tokens > 0:
                # Selling long position — realize P&L
                realized = (price - inv.avg_entry_price) * min(tokens, inv.net_tokens)
                # If we sold more than we had, the excess becomes short at `price`
                if new_total_tokens < 0:
                    # Reset avg entry for the new short position
                    inv.avg_entry_price = price
            else:
                # Increasing short — update avg entry
                new_cost = abs(inv.net_tokens) * inv.avg_entry_price + tokens * price
                inv.avg_entry_price = new_cost / max(abs(new_total_tokens), 0.001)
            inv.net_tokens = new_total_tokens
            inv.fill_count_sell += 1
            self.bankroll += size_usdc  # we received cash

        inv.realized_pnl += realized
        self.daily_pnl += realized

        if realized < 0:
            self.consecutive_losses += 1
            if self.consecutive_losses >= settings.stop_trading_consecutive_losses:
                self.halt(f"{self.consecutive_losses} consecutive losses")
        elif realized > 0:
            self.consecutive_losses = 0

        if self.daily_pnl <= -settings.max_daily_loss_usd:
            self.halt("daily loss limit hit")

        return realized

    # ── Quote skew (inventory-aware) ─────────────────────────────────────────

    def quote_skew(self, token_id: str) -> float:
        """Return skew in cents to apply to quotes.

        Positive = shift quotes UP (we want to sell, discourage more buying)
        Negative = shift quotes DOWN (we want to buy, discourage more selling)
        Zero = symmetric quotes.

        PROGRESSIVE skew: as inventory grows from 30% → 100%, skew ramps up
        from 0¢ to 5¢. This makes our sell-side quote increasingly attractive
        (lower ask) so inventory naturally liquidates WITHOUT blocking one side.
        """
        inv = self.inventories.get(token_id)
        if not inv or inv.net_tokens == 0:
            return 0.0

        max_usd = self.max_inventory_usdc()
        ratio = inv.inventory_ratio(max_usd)
        # ratio = +1 = max long, -1 = max short

        if abs(ratio) < settings.inventory_skew_threshold:
            return 0.0

        # Skew direction: if long, push quotes DOWN slightly (encourage selling)
        # If short, push quotes UP slightly (encourage buying)
        sign = -1.0 if ratio > 0 else 1.0
        magnitude = (abs(ratio) - settings.inventory_skew_threshold) / (1.0 - settings.inventory_skew_threshold)
        # v9.20: Reduced max skew from 1.5¢ to 0.5¢ — was pushing quotes
        # too far from market, causing 0 fills
        max_skew_cents = 0.5
        return sign * magnitude * max_skew_cents

    def should_quote_bid(self, token_id: str) -> bool:
        """Block BUY when long inventory reaches max. Allow SELL to liquidate.

        v9.21: Changed from 200% to 100% — was allowing inventory to grow
        to 2x max, causing $47 inventory on $20 deposit.
        """
        inv = self.inventories.get(token_id)
        if not inv:
            return True
        max_usd = self.max_inventory_usdc()
        ratio = inv.inventory_ratio(max_usd)
        # Block BUY when long (ratio > 0.8 = 80% of max)
        # Allow BUY when short or neutral
        return ratio < 0.8

    def should_quote_ask(self, token_id: str) -> bool:
        """Block SELL when short inventory reaches max. Allow BUY to cover."""
        inv = self.inventories.get(token_id)
        if not inv:
            return True
        max_usd = self.max_inventory_usdc()
        ratio = inv.inventory_ratio(max_usd)
        # Block SELL when short (ratio < -0.8 = -80% of max)
        # Allow SELL when long or neutral
        return ratio > -0.8

    # ── Halt control ─────────────────────────────────────────────────────────

    def halt(self, reason: str) -> None:
        if not self.halted:
            logger.critical("TRADING HALTED: %s", reason)
            self.halted = True
            self.halt_reason = reason

    def resume(self) -> str:
        prev = self.halt_reason
        self.halted = False
        self.halt_reason = ""
        self.consecutive_losses = 0
        self.daily_pnl = 0.0
        return prev

    # ── Status snapshot ──────────────────────────────────────────────────────

    @property
    def status(self) -> dict:
        total_realized = sum(inv.realized_pnl for inv in self.inventories.values())
        total_inventory_usd = sum(
            inv.net_usdc_at_entry for inv in self.inventories.values()
        )
        return {
            "bankroll_usdc": round(self.bankroll, 2),
            "total_realized_pnl": round(total_realized, 2),
            "daily_pnl_usdc": round(self.daily_pnl, 2),
            "total_inventory_usd": round(total_inventory_usd, 2),
            "consecutive_losses": self.consecutive_losses,
            "halted": self.halted,
            "halt_reason": self.halt_reason,
            "max_inventory_usdc": self.max_inventory_usdc(),
            "markets": {
                tid: {
                    "name": inv.market_name,
                    "net_tokens": round(inv.net_tokens, 4),
                    "net_usdc": round(inv.net_usdc_at_entry, 2),
                    "avg_entry": round(inv.avg_entry_price, 4),
                    "realized_pnl": round(inv.realized_pnl, 4),
                    "buys": inv.fill_count_buy,
                    "sells": inv.fill_count_sell,
                }
                for tid, inv in self.inventories.items()
            },
        }
