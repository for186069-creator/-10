"""
app/services/market_maker.py — v10.0 PROFESSIONAL MM
═══════════════════════════════════════════════════
Market maker engine with ALL 15 professional features:

 1. Order Book Imbalance     — use full book depth
 2. Arb Detection            — Yes+No != 1.00
 3. Inventory Aging          — discount stale positions
 4. Adverse Selection        — cancel on sharp moves
 5. Correlation Awareness    — limit per-category exposure
 6. Session-Based Quoting    — wider spread in active hours
 7. Live Retry/Fallback      — 3x exponential backoff
 8. Telegram Alerts          — halt/emergency notifications
 9. Fee/Gas Awareness        — skip unprofitable quotes
10. Active Hedge-on-Fill     — BUY YES → BUY NO
11. Multi-level Quotes       — L1/L2/L3 with $5 min check
12. Smart Scoring            — 0..100 market quality score
13. PnL Panel                — win rate, today PnL, hedge stats
14. No Stop-Loss             — MM captures spread, never force-closes
15. Cross-quote Protection   — skip levels where bid >= ask
"""
from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field

from app.core.config import settings
from app.db.models import Quote, QuoteStatus, Side, Trade
from app.services.clob_client import ClobClient, MarketBook, MarketInfo
from app.services.inventory_manager import InventoryManager
from app.services.analytics import (
    OrderBookImbalance,
    ArbitrageDetector,
    InventoryAger,
    AdverseSelection,
    CorrelationDetector,
    SessionQuoting,
    GasEstimator,
)
from app.services.alerter import alerter

logger = logging.getLogger(__name__)


@dataclass
class ActiveQuote:
    """Tracks our currently-placed quote for a market."""
    token_id: str
    bid_price: float
    ask_price: float
    mid_at_place: float
    size_usdc: float
    placed_at: float = field(default_factory=time.monotonic)
    bid_filled: bool = False
    ask_filled: bool = False
    bid_order_id: str | None = None
    ask_order_id: str | None = None
    # Multi-level
    bid_levels: list[float] = field(default_factory=list)
    ask_levels: list[float] = field(default_factory=list)
    bid_sizes: list[float] = field(default_factory=list)
    ask_sizes: list[float] = field(default_factory=list)
    bid_filled_levels: list[bool] = field(default_factory=list)
    ask_filled_levels: list[bool] = field(default_factory=list)
    condition_id: str = ""
    paired_token_id: str = ""


class MarketMaker:
    """Main MM engine. Runs a requote loop with all 15 pro features."""

    def __init__(self, clob: ClobClient, inventory: InventoryManager) -> None:
        self.clob = clob
        self.inventory = inventory
        self.active_quotes: dict[str, ActiveQuote] = {}
        self._task: asyncio.Task | None = None
        self._running = False
        self._cycle_count = 0
        self._fill_count = 0

        # Trading state: bot starts PAUSED
        self._trading_paused = True

        # Volatility + spread tracking
        self._price_history: dict[str, list[float]] = {}
        self._spread_history: dict[str, list[float]] = {}

        # ── Pro MM: Yes/No Hedging pairs ──
        self._condition_pairs: dict[str, dict[str, str]] = {}

        # ── v10.0 Analytics modules ──
        self._adverse_selection = AdverseSelection()
        self._inventory_ager = InventoryAger()
        self._correlation = CorrelationDetector()
        self._gas_estimator = GasEstimator()

        # ── v10.0 Stats counters ──
        self._hedge_attempts: int = 0
        self._hedge_fills: int = 0
        self._hedge_skipped: int = 0
        self._arb_opportunities: int = 0
        self._arb_executed: int = 0
        self._adverse_triggers: int = 0
        self._quotes_skipped_fee: int = 0
        self._quotes_skipped_corr: int = 0

        # Live mode: pending orders
        self._pending_orders: dict[str, dict] = {}

        # Low-spread tracking (for market removal)
        self._low_spread_start: dict[str, float] = {}

    # ── Lifecycle ────────────────────────────────────────────────────────────

    async def start(self) -> None:
        self._running = True
        self._task = asyncio.create_task(self._requote_loop(), name="mm_loop")
        asyncio.create_task(self._db_cleanup_loop(), name="db_cleanup")
        if not settings.paper_trading:
            asyncio.create_task(self._poll_orders_loop(), name="mm_poll")
        logger.info(
            "MarketMaker started — %s mode, interval %.1fs",
            "LIVE" if not settings.paper_trading else "PAPER",
            settings.requote_interval_sec
        )

    async def stop(self) -> None:
        self._running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        for tid in list(self.active_quotes.keys()):
            await self._cancel_quote(tid)

    # ── DB cleanup ───────────────────────────────────────────────────────────

    async def _db_cleanup_loop(self) -> None:
        await asyncio.sleep(600)
        while self._running:
            try:
                from app.core.db import AsyncSessionLocal
                from sqlalchemy import text
                async with AsyncSessionLocal() as db:
                    await db.execute(text(
                        "DELETE FROM mm_quotes WHERE id NOT IN "
                        "(SELECT id FROM mm_quotes ORDER BY id DESC LIMIT 1000)"
                    ))
                    await db.execute(text(
                        "DELETE FROM mm_snapshots WHERE id NOT IN "
                        "(SELECT id FROM mm_snapshots ORDER BY id DESC LIMIT 1000)"
                    ))
                    await db.commit()
            except Exception:
                pass
            await asyncio.sleep(600)

    # ── Start/Stop trading ───────────────────────────────────────────────────

    def start_trading(self) -> None:
        self._trading_paused = False
        if self.inventory.halted and self.inventory.halt_reason == "Paused by user":
            self.inventory.resume()
        logger.info("▶ Trading STARTED by user")

    def stop_trading(self) -> None:
        self._trading_paused = True
        self.inventory.halted = True
        self.inventory.halt_reason = "Paused by user"
        tids = list(self.active_quotes.keys())
        self.active_quotes.clear()
        logger.info("⏸ Trading PAUSED by user — %d quotes canceled", len(tids))

    @property
    def is_trading(self) -> bool:
        return not self._trading_paused and not self.inventory.halted

    # ── Main loop ────────────────────────────────────────────────────────────

    async def _requote_loop(self) -> None:
        while self._running:
            try:
                if self._trading_paused:
                    await asyncio.sleep(settings.requote_interval_sec)
                    continue
                if self.inventory.halted:
                    for tid in list(self.active_quotes.keys()):
                        await self._cancel_quote(tid)
                    await asyncio.sleep(settings.requote_interval_sec)
                    continue
                await self._cycle()
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.exception("MM cycle error: %s", e)
            await asyncio.sleep(settings.requote_interval_sec)

    async def _cycle(self) -> None:
        self._cycle_count += 1

        # ── Build hedging pairs every 30 cycles ──
        if settings.hedging_enabled and self._cycle_count % 30 == 1:
            self._build_hedging_pairs()

        # ── Auto-refill markets (respect user's count, min 1) ──
        current_markets = len(self.clob.books)
        target_count = max(settings.auto_pick_count, 1)
        if current_markets < target_count and self._cycle_count % 30 == 0:
            logger.info("Only %d markets left (target %d) — auto-discovering", current_markets, target_count)
            try:
                old_count = settings.auto_pick_count
                settings.auto_pick_count = max(1, target_count - current_markets)
                new_markets = await self.clob.discover_markets()
                settings.auto_pick_count = old_count
                added = 0
                for info in new_markets:
                    if info.token_id not in self.clob.books:
                        from app.services.clob_client import MarketBook
                        self.clob.books[info.token_id] = MarketBook(token_id=info.token_id)
                        self.clob.markets[info.token_id] = info
                        self.clob._subscribed.add(info.token_id)
                        added += 1
                if added > 0:
                    await self.clob._refresh_all_books()
                    logger.info("Auto-refill: added %d new markets", added)
            except Exception as e:
                logger.debug("Auto-refill error: %s", e)

        # ── Live safety checks ──
        if not settings.paper_trading:
            if self.inventory.halted:
                for tid in list(self.active_quotes.keys()):
                    await self._cancel_quote(tid)
                return
            if self.inventory.bankroll < 5.0:
                self.inventory.halt("balance below $5 — emergency stop")
                for tid in list(self.active_quotes.keys()):
                    await self._cancel_quote(tid)
                logger.critical("EMERGENCY STOP: balance below $5")
                await alerter.send("critical", "🚨 EMERGENCY STOP",
                    f"Balance fell below $5 (current: ${self.inventory.bankroll:.2f}).",
                    alert_key="emergency_balance")
                return

        # ── Stale data protection (120s + REST fallback at 60s) ──
        ws_age = time.monotonic() - self.clob._last_ws_msg
        if ws_age > 60 and not self.inventory.halted:
            try:
                await self.clob._refresh_all_books()
                self.clob._last_ws_msg = time.monotonic()
                logger.info("REST fallback: refreshed books (WS silent %.0fs)", ws_age)
            except Exception:
                pass
        if ws_age > 120:
            if not self.inventory.halted:
                logger.warning("STALE DATA: WS silent for %.0fs — pausing", ws_age)
                self.inventory.halt(f"Stale data — WS silent {ws_age:.0f}s")
                for tid in list(self.active_quotes.keys()):
                    await self._cancel_quote(tid)
            return
        if ws_age < 30 and self.inventory.halted and "Stale data" in (self.inventory.halt_reason or ""):
            self.inventory.resume()
            logger.info("WS recovered — resuming trading")

        # ── Adverse Selection global cooldown ──
        global_cd = self._adverse_selection.global_cooldown_remaining()
        if global_cd > 0:
            logger.info("[ADVERSE SELECTION] global cooldown — %.1fs remaining", global_cd)
            for tid in list(self.active_quotes.keys()):
                await self._cancel_quote(tid)
            return

        # ── Correlation registration ──
        if self._cycle_count % 60 == 1:
            for tid, info in self.clob.markets.items():
                if info and info.question:
                    self._correlation.register_market(tid, info.question)

        # ── Arbitrage Detection (every 5 cycles) ──
        if settings.arb_detection_enabled and self._cycle_count % 5 == 0:
            await self._check_arbitrage_opportunities()

        # ── Daily Telegram summary ──
        if self._cycle_count % 300 == 0 and settings.telegram_enabled:
            try:
                await self._maybe_send_daily_summary()
            except Exception:
                pass

        # ── Process each market ──
        for tid, book in list(self.clob.books.items()):
            # Low-spread filter (skip, not remove, for 30s then remove)
            should_remove = False
            remove_reason = ""
            should_skip_quote = False

            if book.bids and book.asks:
                current_spread_cents = book.spread * 100
                if current_spread_cents < 2.0:
                    if tid not in self._low_spread_start:
                        self._low_spread_start[tid] = time.monotonic()
                        logger.info("[LOW SPREAD] %s — spread=%.1f¢, will remove in 30s", tid[:12], current_spread_cents)
                    if time.monotonic() - self._low_spread_start[tid] > 30:
                        should_remove = True
                        remove_reason = f"low spread {current_spread_cents:.1f}¢ for 30s"
                    else:
                        should_skip_quote = True
                else:
                    self._low_spread_start.pop(tid, None)

            info = self.clob.markets.get(tid)
            if not info and self._cycle_count > 30:
                should_remove = True
                remove_reason = "no market info"
            elif info and info.volume_24h == 0 and self._cycle_count > 30:
                should_remove = True
                remove_reason = "zero volume"
            elif info and not info.question and self._cycle_count > 30:
                should_remove = True
                remove_reason = "unknown name"

            if should_remove:
                logger.info("[MARKET REMOVED] %s — %s", tid[:12], remove_reason)
                if tid in self.active_quotes:
                    await self._cancel_quote(tid)
                self.clob.books.pop(tid, None)
                self.clob.markets.pop(tid, None)
                self.clob._subscribed.discard(tid)
                self._low_spread_start.pop(tid, None)
                continue

            if should_skip_quote:
                if tid in self.active_quotes:
                    await self._cancel_quote(tid)
                continue

            # ── Smart Scoring ──
            if settings.smart_scoring_enabled and book.bids and book.asks:
                self._track_spread(tid, book.spread)
                if self._cycle_count > 60:
                    score = self._smart_score(tid, book)
                    if score < settings.smart_scoring_min_score:
                        if tid in self.active_quotes:
                            await self._cancel_quote(tid)
                        continue

            # ── Adverse Selection per-market ──
            if settings.adverse_selection_enabled and book.bids and book.asks:
                self._adverse_selection.track(tid, book.mid)
                if self._adverse_selection.check_trigger(tid):
                    self._adverse_triggers += 1
                    if tid in self.active_quotes:
                        await self._cancel_quote(tid)
                    await alerter.send("warning", "Adverse Selection Triggered",
                        f"Market {tid[:12]} moved >{settings.adverse_selection_move_cents}¢.",
                        alert_key=f"adverse_{tid[:8]}")
                    continue
                if self._adverse_selection.is_in_cooldown(tid):
                    if tid in self.active_quotes:
                        await self._cancel_quote(tid)
                    continue

            # ── Correlation check ──
            if settings.correlation_aware_enabled:
                inv_by_token = {t: inv.net_usdc_at_entry for t, inv in self.inventory.inventories.items()}
                if self._correlation.is_category_saturated(tid, inv_by_token):
                    self._quotes_skipped_corr += 1
                    if tid in self.active_quotes:
                        await self._cancel_quote(tid)
                    continue

            await self._process_market(tid, book)

    # ── Process one market ───────────────────────────────────────────────────

    async def _process_market(self, token_id: str, book: MarketBook) -> None:
        if not book.bids or not book.asks:
            return

        info = self.clob.markets.get(token_id)
        market_name = info.question[:60] if info else token_id[:12]

        # ── Pre-resolution exit ──
        if info:
            from datetime import datetime, timezone
            now_ts = datetime.now(timezone.utc).timestamp()
            time_to_resolution = info.end_date_ts - now_ts
            if time_to_resolution < settings.pre_resolution_exit_sec:
                if token_id in self.active_quotes:
                    logger.warning("[PRE-RESOLUTION EXIT] %s — TTR=%.1fh", market_name[:40], time_to_resolution / 3600)
                    await self._cancel_quote(token_id)
                inv = self.inventory.get_inventory(token_id)
                if abs(inv.net_tokens) > 0.5:
                    if inv.net_tokens > 0:
                        sell_price = book.best_bid
                        if sell_price > 0:
                            await self._record_fill(token_id, "SELL", sell_price,
                                abs(inv.net_tokens) * sell_price, market_name)
                    elif inv.net_tokens < 0:
                        buy_price = book.best_ask
                        if buy_price < 1:
                            await self._record_fill(token_id, "BUY", buy_price,
                                abs(inv.net_tokens) * buy_price, market_name)
                return

        # ── Check fills on existing quotes ──
        existing = self.active_quotes.get(token_id)
        if existing:
            await self._check_fills(token_id, book, existing, market_name)
            existing = self.active_quotes.get(token_id)

        # ── Cancel if mid moved too much or quote is old ──
        if existing:
            mid_drift = abs(book.mid - existing.mid_at_place)
            age = time.monotonic() - existing.placed_at
            if mid_drift > settings.requote_threshold_cents / 100 or age > 10:
                await self._cancel_quote(token_id)
                existing = None

        # ── Place new quote ──
        if not existing:
            our_spread_cents = self._compute_spread(token_id, book)

            # ── Feature 6: Session-Based Quoting ──
            session_mult = SessionQuoting.get_spread_multiplier()
            our_spread_cents = our_spread_cents * session_mult
            our_spread_cents = max(settings.spread_min_cents, min(settings.spread_max_cents, our_spread_cents))

            skew_cents = self.inventory.quote_skew(token_id)
            skew_dollars = skew_cents / 100.0

            # ── Feature 1: Order Book Imbalance ──
            imbalance_cents = OrderBookImbalance.compute(book)
            imbalance_dollars = imbalance_cents / 100.0

            # ── Feature 3: Inventory Aging ──
            aging_discount_cents = self._inventory_ager.get_discount_cents(token_id)
            aging_discount_dollars = aging_discount_cents / 100.0

            market_bid = book.best_bid
            market_ask = book.best_ask
            market_spread = market_ask - market_bid
            market_mid = (market_bid + market_ask) / 2

            if market_spread >= 0.002:
                capture = 0.20
                target_bid = market_bid + market_spread * capture + skew_dollars + imbalance_dollars
                target_ask = market_ask - market_spread * capture + skew_dollars + imbalance_dollars
            else:
                target_bid = market_bid + 0.0003 + skew_dollars + imbalance_dollars
                target_ask = market_ask - 0.0003 + skew_dollars + imbalance_dollars

            # ── Feature 3: Apply inventory aging discount ──
            inv = self.inventory.get_inventory(token_id)
            if aging_discount_cents > 0 and inv.net_tokens != 0:
                if inv.net_tokens > 0:
                    target_ask -= aging_discount_dollars
                else:
                    target_bid += aging_discount_dollars

            # Safety: ensure bid < ask
            if target_bid >= target_ask:
                target_bid = market_bid + market_spread * 0.1
                target_ask = market_ask - market_spread * 0.1
            if target_bid >= market_ask:
                target_bid = market_mid - 0.001
            if target_ask <= market_bid:
                target_ask = market_mid + 0.001
            target_bid = max(0.01, min(0.99, target_bid))
            target_ask = max(0.01, min(0.99, target_ask))

            # ── Feature 9: Fee/Gas awareness ──
            if settings.fee_awareness_enabled:
                captured_cents = (target_ask - target_bid) * 100
                min_profit = self._gas_estimator.min_profit_cents()
                if captured_cents < min_profit:
                    self._quotes_skipped_fee += 1
                    return

            quote_bid = self.inventory.should_quote_bid(token_id)
            quote_ask = self.inventory.should_quote_ask(token_id)
            if not quote_bid and not quote_ask:
                return

            # ── Auto-scaling order size ──
            bankroll = self.inventory.bankroll
            base_size = settings.order_size_usdc
            scaling = min(1.5, bankroll / settings.paper_balance_usdc)
            size = base_size * scaling
            size = max(settings.order_size_min_usdc, min(size, base_size * 1.5))

            await self._place_quote(
                token_id=token_id,
                bid_price=target_bid if quote_bid else None,
                ask_price=target_ask if quote_ask else None,
                size_usdc=size,
                mid=market_mid,
                market_name=market_name,
            )

    # ── Hedging pairs ────────────────────────────────────────────────────────

    def _build_hedging_pairs(self) -> None:
        self._condition_pairs.clear()
        by_condition: dict[str, list[str]] = {}
        for tid, info in self.clob.markets.items():
            cid = info.condition_id
            if cid:
                by_condition.setdefault(cid, []).append(tid)
        for cid, tokens in by_condition.items():
            if len(tokens) == 2:
                info0 = self.clob.markets.get(tokens[0])
                info1 = self.clob.markets.get(tokens[1])
                if info0 and info1:
                    yes_token = tokens[0] if info0.outcome.lower() == "yes" else tokens[1]
                    no_token = tokens[1] if info0.outcome.lower() == "yes" else tokens[0]
                    self._condition_pairs[cid] = {"yes": yes_token, "no": no_token}

    def _get_paired_token(self, token_id: str) -> str | None:
        for cid, pair in self._condition_pairs.items():
            if pair["yes"] == token_id:
                return pair["no"]
            if pair["no"] == token_id:
                return pair["yes"]
        return None

    # ── Smart scoring ────────────────────────────────────────────────────────

    def _track_spread(self, token_id: str, spread: float) -> float:
        history = self._spread_history.setdefault(token_id, [])
        history.append(spread)
        if len(history) > 60:
            history.pop(0)
        if len(history) < 10:
            return 0.5
        avg = sum(history) / len(history)
        if avg <= 0:
            return 0.5
        variance = sum((s - avg) ** 2 for s in history) / len(history)
        cv = (variance ** 0.5) / avg
        return max(0.0, min(1.0, 1.0 - cv))

    def _smart_score(self, token_id: str, book: MarketBook) -> float:
        from datetime import datetime, timezone
        info = self.clob.markets.get(token_id)
        score = 0.0

        # 1. Spread stability (40 pts)
        spread_hist = self._spread_history.get(token_id, [])
        if len(spread_hist) >= 10:
            avg_spread = sum(spread_hist) / len(spread_hist)
            if avg_spread > 0:
                variance = sum((s - avg_spread) ** 2 for s in spread_hist) / len(spread_hist)
                cv = (variance ** 0.5) / avg_spread
                stability = max(0.0, min(1.0, 1.0 - cv))
                score += 40.0 * stability
            else:
                score += 20.0
        else:
            score += 20.0

        # 2. Volume trend (30 pts)
        if info and info.volume_24h > 0:
            vol_score = min(30.0, max(5.0, info.volume_24h / 2000.0))
            score += vol_score
        else:
            score += 5.0

        # 3. Distance to expiry (20 pts)
        if info and info.end_date_ts > 0:
            now_ts = datetime.now(timezone.utc).timestamp()
            hours_to_expiry = (info.end_date_ts - now_ts) / 3600.0
            penalty_hours = settings.smart_scoring_expiry_penalty_hours
            if hours_to_expiry < 0:
                score += 0.0
            elif hours_to_expiry < penalty_hours:
                score += 20.0 * (hours_to_expiry / penalty_hours)
            else:
                score += 20.0
        else:
            score += 10.0

        # 4. Time-of-day risk (10 pts)
        hour_utc = datetime.now(timezone.utc).hour
        if settings.smart_scoring_quiet_hours_start <= hour_utc < settings.smart_scoring_quiet_hours_end:
            score += 2.0
        else:
            score += 10.0

        return max(0.0, min(100.0, score))

    # ── Market direction ─────────────────────────────────────────────────────

    def _get_market_direction(self, token_id: str) -> float:
        history = self._price_history.get(token_id, [])
        if len(history) < 5:
            return 0.0
        recent = history[-1]
        past = history[-5]
        if past == 0:
            return 0.0
        change = (recent - past) / past
        return max(-1.0, min(1.0, change * 50))

    # ── Spread computation ───────────────────────────────────────────────────

    def _compute_spread(self, token_id: str, book: MarketBook) -> float:
        history = self._price_history.setdefault(token_id, [])
        history.append(book.mid)
        if len(history) > 60:
            history.pop(0)
        spread = settings.spread_cents
        if len(history) >= 10:
            recent = history[-10:]
            price_range = max(recent) - min(recent)
            if price_range > 0.02:
                vol_mult = 1.0 + (price_range * settings.spread_volatility_mult)
                spread = settings.spread_cents * vol_mult
        return max(settings.spread_min_cents, min(settings.spread_max_cents, spread))

    # ── Quote placement ──────────────────────────────────────────────────────

    async def _place_quote(self, token_id, bid_price, ask_price, size_usdc, mid, market_name):
        if bid_price is None and ask_price is None:
            return

        bid_levels = []
        ask_levels = []
        bid_sizes = []
        ask_sizes = []

        # ── Feature 11: Multi-level Quotes ──
        multi_level_threshold = settings.multi_level_threshold_usdc
        if settings.multi_level_enabled and bid_price and ask_price and size_usdc >= multi_level_threshold:
            market_bid = bid_price
            market_ask = ask_price
            market_spread = market_ask - market_bid
            captures = [settings.multi_level_1_capture, settings.multi_level_2_capture, settings.multi_level_3_capture]
            size_pcts = [settings.multi_level_1_size_pct, settings.multi_level_2_size_pct, settings.multi_level_3_size_pct]
            for i in range(3):
                cap = captures[i]
                sz = size_usdc * size_pcts[i]
                # ── Feature 15: Min order size check ($5 Polymarket minimum) ──
                if sz < settings.order_size_min_usdc:
                    continue
                bl = market_bid + market_spread * cap
                al = market_ask - market_spread * cap
                bl = max(0.01, min(0.99, bl))
                al = max(0.01, min(0.99, al))
                # ── Feature 15: Cross-quote protection ──
                if bl < al - 0.001:
                    bid_levels.append(bl)
                    ask_levels.append(al)
                    bid_sizes.append(round(sz, 2))
                    ask_sizes.append(round(sz, 2))

            # ── Feature 15: Clean crossed levels ──
            if bid_levels:
                bid_price = bid_levels[0]
                ask_price = ask_levels[0]
            else:
                logger.warning("[QUOTE ML] %s — all levels crossed, skipping", market_name[:30])
                return
        else:
            # Single-level: ensure min $5
            if size_usdc < settings.order_size_min_usdc:
                size_usdc = settings.order_size_min_usdc

        # ── Hedging: get paired token ──
        info = self.clob.markets.get(token_id)
        condition_id = info.condition_id if info else ""
        paired_token = self._get_paired_token(token_id) if settings.hedging_enabled else ""

        # ── Hedging: adjust quotes based on combined inventory ──
        if settings.hedging_enabled and paired_token:
            combined_inv = self._get_combined_inventory(token_id)
            if combined_inv > settings.hedging_max_combined_usdc * 0.5:
                hedge_adj = -0.005
                if bid_price:
                    bid_price = max(0.01, bid_price + hedge_adj * 0.5)
                if ask_price:
                    ask_price = max(0.01, ask_price + hedge_adj)
                for i in range(len(ask_levels)):
                    ask_levels[i] = max(0.01, ask_levels[i] + hedge_adj)
            elif combined_inv < -settings.hedging_max_combined_usdc * 0.5:
                hedge_adj = 0.005
                if bid_price:
                    bid_price = max(0.01, bid_price + hedge_adj)
                if ask_price:
                    ask_price = max(0.01, ask_price + hedge_adj * 0.5)
                for i in range(len(bid_levels)):
                    bid_levels[i] = max(0.01, bid_levels[i] + hedge_adj)

        # ── LIVE MODE: place real orders ──
        bid_order_id = None
        ask_order_id = None
        if not settings.paper_trading:
            for i, (bp, bs) in enumerate(zip(bid_levels or [bid_price], bid_sizes or [size_usdc])):
                if bp and bs >= settings.order_size_min_usdc:
                    result = await self.clob.place_order(token_id, "BUY", bp, bs)
                    if result and i == 0:
                        bid_order_id = result.get("orderID") or result.get("id", "")
            for i, (ap, asz) in enumerate(zip(ask_levels or [ask_price], ask_sizes or [size_usdc])):
                if ap and asz >= settings.order_size_min_usdc:
                    result = await self.clob.place_order(token_id, "SELL", ap, asz)
                    if result and i == 0:
                        ask_order_id = result.get("orderID") or result.get("id", "")

        # Track active quote
        self.active_quotes[token_id] = ActiveQuote(
            token_id=token_id,
            bid_price=bid_price or 0.0,
            ask_price=ask_price or 1.0,
            mid_at_place=mid,
            size_usdc=size_usdc,
            bid_order_id=bid_order_id,
            ask_order_id=ask_order_id,
            bid_levels=bid_levels,
            ask_levels=ask_levels,
            bid_sizes=bid_sizes,
            ask_sizes=ask_sizes,
            bid_filled_levels=[False] * len(bid_levels),
            ask_filled_levels=[False] * len(ask_levels),
            condition_id=condition_id,
            paired_token_id=paired_token,
        )

        # Log
        if settings.multi_level_enabled and bid_levels:
            level_str = " | ".join(
                f"L{i+1}: bid={bid_levels[i]:.4f} ask={ask_levels[i]:.4f} ${bid_sizes[i]:.0f}"
                for i in range(len(bid_levels))
            )
            hedge_str = f" | HEDGE: {paired_token[:8]}" if paired_token else ""
            logger.info("[QUOTE ML] %s | %s%s", market_name[:35], level_str, hedge_str)
        else:
            logger.info("[QUOTE] %s | bid=%s ask=%s mid=%.4f size=$%.0f",
                market_name, f"{bid_price:.4f}" if bid_price else "—",
                f"{ask_price:.4f}" if ask_price else "—", mid, size_usdc)

        # Persist quote
        try:
            await self._persist_quote(token_id, bid_price, ask_price, mid, size_usdc)
        except Exception:
            pass

    def _get_combined_inventory(self, token_id: str) -> float:
        inv_self = self.inventory.get_inventory(token_id)
        paired = self._get_paired_token(token_id)
        if not paired:
            return inv_self.net_usdc_at_entry
        inv_paired = self.inventory.get_inventory(paired)
        return inv_self.net_usdc_at_entry + inv_paired.net_usdc_at_entry

    async def _cancel_quote(self, token_id: str) -> None:
        existing = self.active_quotes.pop(token_id, None)
        if not existing:
            return
        if not settings.paper_trading:
            if existing.bid_order_id:
                await self.clob.cancel_order(existing.bid_order_id)
                self._pending_orders.pop(existing.bid_order_id, None)
            if existing.ask_order_id:
                await self.clob.cancel_order(existing.ask_order_id)
                self._pending_orders.pop(existing.ask_order_id, None)

    # ── Live mode order polling ──────────────────────────────────────────────

    async def _poll_orders_loop(self) -> None:
        await asyncio.sleep(5)
        while self._running:
            try:
                await self._poll_orders()
            except asyncio.CancelledError:
                break
            except Exception:
                pass
            await asyncio.sleep(3)

    async def _poll_orders(self) -> None:
        if not self._pending_orders:
            return
        for order_id in list(self._pending_orders.keys()):
            order_info = self._pending_orders[order_id]
            age = time.monotonic() - order_info["placed_at"]
            status = await self.clob.poll_order_status(order_id)
            if status:
                order_status = status.get("status", "").upper()
                token_id = order_info["token_id"]
                side = order_info["side"]
                price = order_info["price"]
                size_usdc = order_info["size_usdc"]
                market_name = order_info["market_name"]
                if order_status in ("MATCHED", "FILLED", "FILLED_PARTIAL"):
                    filled_size = float(status.get("size_matched", size_usdc))
                    fill_price = float(status.get("price", price))
                    is_hedge = order_info.get("is_hedge", False)
                    await self._record_fill(token_id, side, fill_price, filled_size, market_name, _skip_hedge=is_hedge)
                    existing = self.active_quotes.get(token_id)
                    if existing:
                        if side == "BUY":
                            existing.bid_filled = True
                        else:
                            existing.ask_filled = True
                        if existing.bid_filled and existing.ask_filled:
                            self.active_quotes.pop(token_id, None)
                    self._pending_orders.pop(order_id, None)
                elif order_status in ("CANCELED", "CANCELLED"):
                    self._pending_orders.pop(order_id, None)
                elif age > 30 and order_status == "LIVE":
                    await self.clob.cancel_order(order_id)
                    self._pending_orders.pop(order_id, None)

    # ── Fill simulation (paper mode) ─────────────────────────────────────────

    async def _check_fills(self, token_id, book, existing, market_name):
        if not settings.paper_trading:
            return
        import random
        direction = self._get_market_direction(token_id)
        perceived_mid = book.mid + random.gauss(0, 0.002)

        # Resolution risk
        info = self.clob.markets.get(token_id)
        if info:
            from datetime import datetime, timezone
            now_ts = datetime.now(timezone.utc).timestamp()
            ttr = info.end_date_ts - now_ts
            if 0 < ttr < 3600 and random.random() < 0.05:
                inv = self.inventory.get_inventory(token_id)
                if abs(inv.net_tokens) > 0.1:
                    if inv.net_tokens > 0:
                        await self._record_fill(token_id, "SELL", perceived_mid,
                            abs(inv.net_tokens) * perceived_mid, market_name)
                    else:
                        await self._record_fill(token_id, "BUY", perceived_mid,
                            abs(inv.net_tokens) * perceived_mid, market_name)
                    return

        # Volume-based fill boost
        volume_mult = 1.0
        if info and info.volume_24h > 0:
            if info.volume_24h > 100_000:
                volume_mult = 1.5
            elif info.volume_24h > 30_000:
                volume_mult = 1.2
            elif info.volume_24h < 2_000:
                volume_mult = 0.5
            else:
                volume_mult = 0.8

        bid_prices = existing.bid_levels if existing.bid_levels else ([existing.bid_price] if existing.bid_price else [])
        ask_prices = existing.ask_levels if existing.ask_levels else ([existing.ask_price] if existing.ask_price else [])
        bid_sizes_list = existing.bid_sizes if existing.bid_sizes else ([existing.size_usdc] * len(bid_prices))
        ask_sizes_list = existing.ask_sizes if existing.ask_sizes else ([existing.size_usdc] * len(ask_prices))

        # Check bid levels
        for level_idx, (bp, bs) in enumerate(zip(bid_prices, bid_sizes_list)):
            if existing.bid_filled_levels and level_idx < len(existing.bid_filled_levels):
                if existing.bid_filled_levels[level_idx]:
                    continue
            if not bp or bs < settings.order_size_min_usdc:
                continue
            market_bid = book.best_bid
            if market_bid <= 0:
                continue
            distance = abs(bp - market_bid)
            if bp >= market_bid - 0.003 and distance <= 0.015:
                level_mult = 1.4 - (level_idx * 0.3)
                size_mult = max(0.7, 1.0 - (bs / 50.0))
                if random.random() < 0.15:
                    continue
                if random.random() < 0.25:
                    continue
                direction_mult = 1.0  # v9.22: neutral, no BUY/SELL imbalance
                market_spread = book.spread
                activity_mult = 1.0
                if market_spread < 0.015:
                    activity_mult = 1.2
                elif market_spread > 0.04:
                    activity_mult = 0.5
                closeness = 1.0 - (distance / 0.015)
                fill_prob = 0.05 * closeness * activity_mult * max(0.3, direction_mult) * level_mult * size_mult * volume_mult
                fill_prob = min(0.08, max(0.005, fill_prob))
                if random.random() < fill_prob:
                    adverse_drift = random.uniform(0.001, 0.003)
                    fill_price = min(bp + adverse_drift, market_bid + 0.001)
                    fill_price = max(0.01, min(0.99, fill_price))
                    partial_roll = random.random()
                    if partial_roll < 0.25:
                        continue
                    elif partial_roll < 0.65:
                        fill_pct = random.uniform(0.30, 0.65)
                    elif partial_roll < 0.90:
                        fill_pct = random.uniform(0.65, 0.95)
                    else:
                        fill_pct = random.uniform(0.95, 1.0)
                    fill_size = bs * fill_pct
                    if fill_size < 1.0:  # v10.1: allow partial fills (was $5)
                        continue
                    await self._record_fill(token_id, "BUY", fill_price, fill_size, market_name)
                    if existing.bid_filled_levels and level_idx < len(existing.bid_filled_levels):
                        existing.bid_filled_levels[level_idx] = True

        # Check ask levels
        for level_idx, (ap, asz) in enumerate(zip(ask_prices, ask_sizes_list)):
            if existing.ask_filled_levels and level_idx < len(existing.ask_filled_levels):
                if existing.ask_filled_levels[level_idx]:
                    continue
            if not ap or asz < settings.order_size_min_usdc:
                continue
            market_ask = book.best_ask
            if market_ask >= 1:
                continue
            distance = abs(ap - market_ask)
            if ap <= market_ask + 0.003 and distance <= 0.015:
                level_mult = 1.4 - (level_idx * 0.3)
                size_mult = max(0.7, 1.0 - (asz / 50.0))
                if random.random() < 0.15:
                    continue
                if random.random() < 0.25:
                    continue
                direction_mult = 1.0
                market_spread = book.spread
                activity_mult = 1.0
                if market_spread < 0.015:
                    activity_mult = 1.2
                elif market_spread > 0.04:
                    activity_mult = 0.5
                closeness = 1.0 - (distance / 0.015)
                fill_prob = 0.05 * closeness * activity_mult * max(0.3, direction_mult) * level_mult * size_mult * volume_mult
                fill_prob = min(0.08, max(0.005, fill_prob))
                if random.random() < fill_prob:
                    adverse_drift = random.uniform(0.001, 0.003)
                    fill_price = max(ap - adverse_drift, market_ask - 0.001)
                    fill_price = max(0.01, min(0.99, fill_price))
                    partial_roll = random.random()
                    if partial_roll < 0.25:
                        continue
                    elif partial_roll < 0.65:
                        fill_pct = random.uniform(0.30, 0.65)
                    elif partial_roll < 0.90:
                        fill_pct = random.uniform(0.65, 0.95)
                    else:
                        fill_pct = random.uniform(0.95, 1.0)
                    fill_size = asz * fill_pct
                    if fill_size < 1.0:  # v10.1: allow partial fills (was $5)
                        continue
                    await self._record_fill(token_id, "SELL", fill_price, fill_size, market_name)
                    if existing.ask_filled_levels and level_idx < len(existing.ask_filled_levels):
                        existing.ask_filled_levels[level_idx] = True

        # Round-trip check
        all_bids_filled = existing.bid_filled_levels and all(existing.bid_filled_levels) and len(existing.bid_filled_levels) > 0
        all_asks_filled = existing.ask_filled_levels and all(existing.ask_filled_levels) and len(existing.ask_filled_levels) > 0
        if not existing.bid_levels:
            all_bids_filled = existing.bid_filled
        if not existing.ask_levels:
            all_asks_filled = existing.ask_filled
        if all_bids_filled and all_asks_filled:
            buy_price = existing.bid_price
            sell_price = existing.ask_price
            spread = sell_price - buy_price
            logger.info("[ROUND-TRIP] %s | buy@%.4f sell@%.4f gross_spread=%.4f",
                        market_name[:40], buy_price, sell_price, spread)
            self.active_quotes.pop(token_id, None)

    # ── Record fill + active hedge ───────────────────────────────────────────

    async def _record_fill(self, token_id, side, price, size_usdc, market_name, _skip_hedge=False):
        realized = self.inventory.on_fill(token_id, side, price, size_usdc, market_name)

        # Feature 3: Update inventory aging
        if settings.inventory_aging_enabled:
            inv = self.inventory.get_inventory(token_id)
            self._inventory_ager.update_position(token_id, inv.net_tokens)

        gas_cost = 0.001  # realistic Polygon gas
        taker_fee = 0.0
        total_cost = gas_cost + taker_fee
        realized_net = realized - total_cost
        self.inventory.bankroll -= total_cost
        self._fill_count += 1

        emoji = "🟢" if side == "BUY" else "🔴"
        mode_tag = "[LIVE]" if not settings.paper_trading else "[PAPER]"
        pnl_str = f"pnl=+${realized_net:.4f}" if realized_net >= 0 else f"pnl=-${abs(realized_net):.4f}"
        logger.info("%s [FILL] %s %s %s @ %.4f size=$%.2f | inv=%+.2f tokens %s",
            mode_tag, emoji, side, market_name[:50], price, size_usdc,
            self.inventory.get_inventory(token_id).net_tokens,
            pnl_str if realized != 0 else "")

        await self._persist_trade(token_id, side, price, size_usdc, realized_net, market_name)

        # Feature 8: Telegram alert on consecutive losses
        if realized < 0 and self.inventory.consecutive_losses >= settings.stop_trading_consecutive_losses - 1:
            await alerter.send("warning", "Consecutive Losses Warning",
                f"{self.inventory.consecutive_losses + 1} losses in a row.",
                alert_key="consec_losses")

        # Feature 10: Active Hedge-on-Fill
        if settings.hedging_enabled and settings.hedging_active_enabled and not _skip_hedge:
            try:
                await self._attempt_active_hedge(token_id, side, size_usdc, market_name, filled_price=price)
            except Exception as e:
                logger.debug("[HEDGE-ON-FILL] %s — failed: %s", market_name[:30], e)

    # ── Arbitrage detection ──────────────────────────────────────────────────

    async def _check_arbitrage_opportunities(self) -> None:
        if not settings.arb_detection_enabled:
            return
        for cid, pair in list(self._condition_pairs.items()):
            yes_token = pair.get("yes")
            no_token = pair.get("no")
            if not yes_token or not no_token:
                continue
            yes_book = self.clob.books.get(yes_token)
            no_book = self.clob.books.get(no_token)
            if not yes_book or not no_book:
                continue
            arb = ArbitrageDetector.detect(yes_token, no_token, yes_book, no_book)
            if arb is None:
                continue
            self._arb_opportunities += 1
            logger.info("[ARB] %s — %s Yes@%.4f + No@%.4f = %.4f, profit %.2f¢",
                cid[:12], arb.direction, arb.yes_price, arb.no_price, arb.sum_price, arb.profit_cents)
            yes_inv = self.inventory.get_inventory(yes_token)
            no_inv = self.inventory.get_inventory(no_token)
            if abs(yes_inv.net_tokens) > 5 or abs(no_inv.net_tokens) > 5:
                continue
            try:
                await self._execute_arb(arb)
                self._arb_executed += 1
            except Exception as e:
                logger.warning("[ARB] execution failed: %s", e)

    async def _execute_arb(self, arb) -> None:
        info_yes = self.clob.markets.get(arb.yes_token_id)
        info_no = self.clob.markets.get(arb.no_token_id)
        yes_name = info_yes.question[:40] if info_yes else arb.yes_token_id[:12]
        no_name = info_no.question[:40] if info_no else arb.no_token_id[:12]
        half_size = arb.size_usdc / 2
        if arb.direction == "BUY_BUY":
            await self._record_fill(arb.yes_token_id, "BUY", arb.yes_price, half_size, yes_name, _skip_hedge=True)
            await self._record_fill(arb.no_token_id, "BUY", arb.no_price, half_size, no_name, _skip_hedge=True)
        elif arb.direction == "SELL_SELL":
            await self._record_fill(arb.yes_token_id, "SELL", arb.yes_price, half_size, yes_name, _skip_hedge=True)
            await self._record_fill(arb.no_token_id, "SELL", arb.no_price, half_size, no_name, _skip_hedge=True)

    # ── Daily Telegram summary ───────────────────────────────────────────────

    async def _maybe_send_daily_summary(self) -> None:
        from datetime import datetime, timezone
        now = datetime.now(timezone.utc)
        if now.hour != settings.telegram_daily_summary_hour_utc:
            return
        inv_status = self.inventory.status
        await alerter.send_daily_summary(
            bankroll=inv_status.get("bankroll_usdc", 0),
            daily_pnl=inv_status.get("daily_pnl_usdc", 0),
            total_trades=self._fill_count,
            win_rate=0.0,
            hedge_attempts=self._hedge_attempts,
            hedge_fills=self._hedge_fills,
        )

    # ── Active hedge ─────────────────────────────────────────────────────────

    async def _attempt_active_hedge(self, filled_token_id, filled_side, filled_size_usdc, market_name, filled_price=0.0):
        paired_token = self._get_paired_token(filled_token_id)
        if not paired_token:
            self._hedge_skipped += 1
            return
        paired_book = self.clob.books.get(paired_token)
        if not paired_book or not paired_book.bids or not paired_book.asks:
            self._hedge_skipped += 1
            return
        paired_info = self.clob.markets.get(paired_token)
        paired_name = paired_info.question[:50] if paired_info else paired_token[:12]

        # v9.6: BUY YES → BUY NO, SELL YES → SELL NO
        if filled_side == "BUY":
            hedge_side = "BUY"
            aggressiveness = settings.hedging_active_aggressiveness_cents / 100.0
            hedge_price = paired_book.best_ask + aggressiveness
            hedge_price = min(0.99, hedge_price)
            total_cost = filled_price + paired_book.best_ask
            if total_cost >= 1.0:
                self._hedge_skipped += 1
                return
        else:
            hedge_side = "SELL"
            aggressiveness = settings.hedging_active_aggressiveness_cents / 100.0
            hedge_price = paired_book.best_bid - aggressiveness
            hedge_price = max(0.01, hedge_price)
            total_revenue = filled_price + paired_book.best_bid
            if total_revenue <= 1.0:
                self._hedge_skipped += 1
                return

        # v9.5: Hedge in TOKEN AMOUNT
        if filled_price > 0:
            filled_tokens = filled_size_usdc / filled_price
            hedge_size_usdc = filled_tokens * hedge_price
        else:
            hedge_size_usdc = filled_size_usdc
        if hedge_size_usdc < 1.0:
            self._hedge_skipped += 1
            return
        self._hedge_attempts += 1

        if settings.paper_trading:
            import random
            fill_prob = 0.80 if aggressiveness <= 0.005 else 0.60
            if random.random() < fill_prob:
                actual_price = hedge_price + random.uniform(-0.0005, 0.0005)
                actual_price = max(0.01, min(0.99, actual_price))
                if filled_price > 0:
                    actual_hedge_usd = filled_tokens * actual_price
                else:
                    actual_hedge_usd = hedge_size_usdc
                await self._record_fill(paired_token, hedge_side, actual_price, actual_hedge_usd, paired_name, _skip_hedge=True)
                self._hedge_fills += 1
                logger.info("[HEDGE-ON-FILL] 🛡️ %s %s @ %.4f $%.2f (%.2f tokens) — locked spread",
                    hedge_side, paired_name[:40], actual_price, actual_hedge_usd,
                    filled_tokens if filled_price > 0 else actual_hedge_usd / max(actual_price, 0.001))
            return

        # LIVE MODE
        result = await self.clob.place_order(paired_token, hedge_side, hedge_price, hedge_size_usdc)
        if result:
            order_id = result.get("orderID") or result.get("id", "")
            self._pending_orders[order_id] = {
                "token_id": paired_token, "side": hedge_side, "price": hedge_price,
                "size_usdc": hedge_size_usdc, "placed_at": time.monotonic(),
                "market_name": paired_name, "is_hedge": True,
            }
            logger.info("[HEDGE-ON-FILL] placed %s %s @ %.4f $%.2f", hedge_side, paired_name[:30], hedge_price, hedge_size_usdc)

    # ── DB persistence ───────────────────────────────────────────────────────

    async def _persist_quote(self, token_id, bid, ask, mid, size_usdc):
        try:
            from app.core.db import AsyncSessionLocal
            async with AsyncSessionLocal() as db:
                q = Quote(market_id=token_id, bid_price=bid or 0, ask_price=ask or 1,
                    mid_price=mid, size_usdc=size_usdc, spread_cents=(ask - bid) if bid and ask else 0)
                db.add(q)
                await db.commit()
        except Exception:
            pass

    async def _persist_trade(self, token_id, side, price, size_usdc, pnl, market_name):
        try:
            from app.core.db import AsyncSessionLocal
            async with AsyncSessionLocal() as db:
                t = Trade(market_id=token_id, market_name=market_name,
                    side=Side.BUY if side == "BUY" else Side.SELL, price=price,
                    size_usdc=size_usdc, size_tokens=size_usdc / max(price, 0.001),
                    pnl_usdc=pnl, inventory_after=self.inventory.get_inventory(token_id).net_tokens,
                    paper=settings.paper_trading)
                db.add(t)
                await db.commit()
        except Exception:
            pass

    # ── Status ───────────────────────────────────────────────────────────────

    @property
    def status(self) -> dict:
        return {
            "cycle_count": self._cycle_count,
            "fill_count": self._fill_count,
            "active_quotes": len(self.active_quotes),
            "pending_live_orders": len(self._pending_orders) if not settings.paper_trading else 0,
            "mode": "LIVE" if not settings.paper_trading else "PAPER",
            "hedge_attempts": self._hedge_attempts,
            "hedge_fills": self._hedge_fills,
            "hedge_skipped": self._hedge_skipped,
            "hedge_fill_rate": round(self._hedge_fills / max(self._hedge_attempts, 1) * 100, 1),
            "arb_opportunities": self._arb_opportunities,
            "arb_executed": self._arb_executed,
            "adverse_triggers": self._adverse_triggers,
            "quotes_skipped_fee": self._quotes_skipped_fee,
            "quotes_skipped_corr": self._quotes_skipped_corr,
            "session": SessionQuoting.get_session_name(),
            "gas_estimate_usd": self._gas_estimator.get_gas_usd(),
            "min_profit_cents": self._gas_estimator.min_profit_cents() if settings.fee_awareness_enabled else 0,
            "adverse_global_cooldown": self._adverse_selection.global_cooldown_remaining(),
            "quotes_detail": [
                {
                    "token_id": q.token_id[:12],
                    "bid": round(q.bid_price, 4) if q.bid_price else None,
                    "ask": round(q.ask_price, 4) if q.ask_price else None,
                    "mid": round(q.mid_at_place, 4),
                    "bid_filled": q.bid_filled,
                    "ask_filled": q.ask_filled,
                    "age_sec": round(time.monotonic() - q.placed_at, 1),
                }
                for q in self.active_quotes.values()
            ],
        }
