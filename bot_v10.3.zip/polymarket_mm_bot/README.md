# Polymarket Market Maker Bot 🤖

> **Прибуток на спреді, а не на прогнозі напрямку.**
>
> Цей бот не вгадує куди піде BTC. Він **продає ліквідність** — ставить bid і ask
> навколо mid price, заробляючи 2-5¢ з кожної round-trip угоди.

## Як це працює

```
Ринок: "Will Bitcoin be above $65,000 on June 23?"
Order book:
  Asks: 0.5200, 0.5300, ...
  Mid:  0.5000
  Bids: 0.4800, 0.4700, ...

Бот ставить (spread = 4¢):
  我们的 ASK @ 0.5200  ← продає
  我们的 BID @ 0.4800  ← купує

Сценарій 1: Хтось продає вам по 0.4800 → у вас токен за $0.48
Сценарій 2: Хтось купує у вас по 0.5200 → ви заробили $0.04 на round-trip
```

**Ключова перевага:** вам байдуже, куди йде ціна. Ви заробляєте на спреді.

## Швидкий старт

```bash
cd polymarket_mm_bot
python -m venv .venv
.venv\Scripts\activate        # Windows
# source .venv/bin/activate   # Linux/Mac
pip install -r requirements.txt

# .env вже налаштований для paper mode (старт $200)
# Запустіть:
python -m app.main

# Dashboard: http://127.0.0.1:8000
```

## Режими

### 📄 Paper Mode (за замовчуванням)
- Стартовий баланс: **$200**
- Реальні ринки Polymarket (Binance WS для BTC)
- Симуляція заповнень на основі order book
- Без ризику втрати грошей

### 🔴 Live Mode
Додайте в `.env`:
```env
PAPER_TRADING=false
POLYGON_PRIVATE_KEY=0x...
POLYGON_WALLET_ADDRESS=0x...
CLOB_API_KEY=...
CLOB_API_SECRET=...
CLOB_API_PASSPHRASE=...
```

⚠️ **Почніть з $20 в live режимі!**

## Параметри (налаштовуються через dashboard)

| Параметр | За замовч. | Опис |
|----------|-----------|------|
| `SPREAD_CENTS` | 4¢ | Різниця між bid і ask |
| `ORDER_SIZE_USDC` | $10 | Розмір кожної сторони |
| `MAX_INVENTORY_USDC` | $50 | Макс $ в одній стороні |
| `REQUOTE_INTERVAL_SEC` | 2с | Як часто оновлювати котування |
| `MAX_DAILY_LOSS_USD` | $20 | Зупинка при збитку за день |

## Стратегія

### 1. Симетричні котування
Бот ставить bid (mid - spread/2) і ask (mid + spread/2). Заробляє spread коли обидві сторони заповнюються.

### 2. Динамічний spread
При волатильності (>2¢ рух за 20с) бот розширює spread у 2 рази. Захищає від adverse selection.

### 3. Inventory skewing
Коли позиція росте в один бік (>30% від max), бот зміщує котування на 1¢ протилежно — стимулює розвантаження.

### 4. One-sided quoting
При >80% max inventory бот перестає котувати одну зі сторін. Це запобігає накопиченню.

### 5. Risk controls
- Зупинка при 5 послідовних збитках
- Зупинка при -10% від депозиту за день
- Скасування котувань при різкому русі ціни

## Очікуваний прибуток

| Сценарій | Депозит | Торгівля | Прибуток/міс |
|----------|---------|----------|---------------|
| Консервативний | $200 | 1-2 ринки | $30-60 |
| Помірний | $500 | 2-3 ринки | $100-200 |
| Активний | $1000 | 3-5 ринків | $250-500 |

**Приклад:** $200 депозит, spread 4¢, 50 round-trips/день = $2/день = $60/міс (30%/міс)

## API Endpoints

| Method | Path | Опис |
|--------|------|------|
| GET | `/api/dashboard` | Основні метрики |
| GET | `/api/inventory` | Стан інвентарю |
| GET | `/api/quotes` | Активні котування |
| GET | `/api/trades` | Історія угод |
| GET | `/api/markets` | Ринки, де торгує |
| GET | `/api/config` | Поточні параметри |
| POST | `/api/config` | Оновити параметри |
| POST | `/api/risk/resume` | Відновити після зупинки |
| POST | `/api/paper/reset` | Скинути paper |
| GET | `/api/analytics/by_market` | P&L по ринках |

## Ризики (читати обов'язково!)

### Adverse Selection
Інформовані трейдери купують у вас коли знають щось. Захист: розширений spread при волатильності.

### Inventory Risk
Якщо ціна пішла проти вашої позиції, ви збиткуєте. Захист: max_inventory_usdc + skewing.

### Liquidity Risk
Великі гравці можуть забрати ваш spread. Захист: динамічний spread + cancel_on_major_move.

### Технічний ризик
- WS розрив → бот перестає котувати (захист: poll fallback)
- Latency → спред стає неконкурентним (захист: requote every 2s)

## Структура проекту

```
polymarket_mm_bot/
├── .env                    ← конфігурація
├── requirements.txt        ← залежності
├── README.md
└── app/
    ├── main.py             ← Entry point + lifespan
    ├── core/
    │   ├── config.py       ← Всі налаштування
    │   └── db.py           ← SQLAlchemy engine
    ├── db/
    │   ├── models.py       ← Trade, Quote, Snapshot ORM
    │   └── init_db.py      ← CREATE TABLE
    ├── services/
    │   ├── clob_client.py  ← Polymarket API + WS
    │   ├── inventory_manager.py ← Позиції + bankroll
    │   └── market_maker.py ← Main MM engine
    ├── admin/
    │   └── api.py          ← FastAPI router (10+ endpoints)
    └── static/
        └── index.html      ← Dashboard (vanilla JS)
```

## Перехід в Live

1. **Прогін 7+ днів в paper mode** — переконайтесь що bankroll росте
2. **Стрес-тест**: зменшіть spread до 2¢ — перевірте чи не зливатиме
3. **Live з $20** — 1 тиждень
4. **Live з $50** — 2 тижні
5. **Live з $200** — тільки після стабільного +P&L на $50

## Вимоги до live

- MetaMask гаманець з USDC на Polygon
- ~$5-10 MATIC для gas (на рік)
- Polymarket API key (безкоштовно на polymarket.com)
- Стабільний інтернет + VPS бажано (24/7)

## Чим цей бот кращий за directional bot

| Критерій | Directional (попередній) | Market Maker (цей) |
|----------|--------------------------|---------------------|
| Прогноз напрямку | Потрібен | Не потрібен |
| Заробіток | На русі ціни | На спреді |
| WR потрібно | 60%+ | Не важливо |
| Залежність від волатильності | Висока | Низька (більше вол = більше прибутку) |
| Стабільність | Низька | Висока |
| Складність моделі | Висока (BS, Kelly, momentum) | Низька (spread + inventory) |

---

**⚠️ ВАЖЛИВО:** Навіть MM боти можуть зливати. Починайте з paper mode, потім $20 live. Ніколи не ризикуйте більше ніж готові втратити.
