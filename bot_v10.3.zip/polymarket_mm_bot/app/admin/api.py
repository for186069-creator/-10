"""
app/admin/api.py — Admin endpoints for MM bot
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.db import get_db
from app.db.models import Quote, QuoteStatus, Side, Trade

admin_router = APIRouter(tags=["admin"])

# Injected at startup
_clob_client = None
_inventory = None
_market_maker = None


def inject_services(clob, inventory, mm):
    global _clob_client, _inventory, _market_maker
    _clob_client = clob
    _inventory = inventory
    _market_maker = mm


# ── Dashboard ────────────────────────────────────────────────────────────────

@admin_router.get("/dashboard")
async def dashboard(db: AsyncSession = Depends(get_db)):
    """Main dashboard data."""
    # Recent trades (last 24h)
    cutoff = datetime.utcnow() - timedelta(hours=24)
    result = await db.execute(
        select(Trade).where(Trade.timestamp >= cutoff).order_by(Trade.timestamp.desc()).limit(500)
    )
    recent_trades = list(result.scalars().all())

    # All-time stats
    all_result = await db.execute(select(Trade))
    all_trades = list(all_result.scalars().all())

    buys = [t for t in all_trades if t.side == Side.BUY]
    sells = [t for t in all_trades if t.side == Side.SELL]

    # Realized P&L from closed trades (sum of trade pnl_usdc)
    total_realized_from_trades = sum(t.pnl_usdc or 0 for t in all_trades)
    realized_24h = sum(t.pnl_usdc or 0 for t in recent_trades if t.pnl_usdc)

    # Round-trip detection (buy followed by sell of same market)
    round_trips = min(len(buys), len(sells))

    # ── v9.5: Win rate, avg spread, today's PnL ──────────────────────────
    closed_trades = [t for t in all_trades if t.pnl_usdc is not None and t.pnl_usdc != 0]
    winning_trades = [t for t in closed_trades if t.pnl_usdc > 0]
    win_rate = round(len(winning_trades) / max(len(closed_trades), 1) * 100, 1)

    if winning_trades:
        avg_spread_captured = round(
            sum(t.pnl_usdc for t in winning_trades) / len(winning_trades), 4
        )
    else:
        avg_spread_captured = 0.0

    from datetime import datetime as _dt
    today_start = _dt.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
    today_trades = [t for t in all_trades if t.timestamp and t.timestamp >= today_start]
    today_pnl = round(sum(t.pnl_usdc or 0 for t in today_trades), 4)
    today_trades_count = len(today_trades)

    # Quote stats
    quotes_result = await db.execute(select(Quote))
    all_quotes = list(quotes_result.scalars().all())
    filled_quotes = sum(1 for q in all_quotes if q.status == QuoteStatus.FILLED)

    inv_status = _inventory.status if _inventory else {}
    mm_status = _market_maker.status if _market_maker else {}

    # ── CORRECT P&L CALCULATION ──────────────────────────────────────────
    # The TRUE total P&L = (current bankroll - starting balance) + inventory value
    # This is because bankroll = cash only, and inventory has unrealized value.
    #
    # total_pnl = bankroll_growth + inventory_mark_to_mid
    current_bankroll = inv_status.get("bankroll_usdc", settings.paper_balance_usdc)
    starting_balance = settings.paper_balance_usdc
    bankroll_growth = current_bankroll - starting_balance

    # Calculate unrealized inventory value at current mid prices
    inventory_value = 0.0
    markets_inv = inv_status.get("markets", {})
    if _clob_client:
        for tid, inv_data in markets_inv.items():
            book = _clob_client.books.get(tid)
            if book and inv_data.get("net_tokens", 0) != 0:
                mid = book.mid
                inventory_value += inv_data["net_tokens"] * mid

    # TRUE total P&L = cash growth + inventory value (mark-to-market)
    total_pnl = bankroll_growth + inventory_value

    # Total Equity = cash + inventory market value (the REAL spendable balance)
    total_equity = current_bankroll + inventory_value

    # Daily P&L = same calculation but from today's starting point
    daily_pnl = total_pnl

    return {
        # Total Equity is the REAL balance (cash + inventory value)
        "bankroll_usdc": round(total_equity, 2),
        "cash_usdc": round(current_bankroll, 2),
        "starting_balance": starting_balance,
        # Show TRUE total P&L (cash + inventory), not just realized from trades
        "total_realized_pnl": round(total_pnl, 4),
        "realized_pnl_24h": round(realized_24h, 4),
        # Also expose components for transparency
        "bankroll_growth": round(bankroll_growth, 4),
        "inventory_value_usd": round(inventory_value, 4),
        "daily_pnl_usdc": round(daily_pnl, 4),
        "total_trades": len(all_trades),
        "trades_24h": len(recent_trades),
        "buys": len(buys),
        "sells": len(sells),
        "round_trips": round_trips,
        "total_quotes": len(all_quotes),
        "quote_fill_rate": round(filled_quotes / max(len(all_quotes), 1) * 100, 2),
        "consecutive_losses": inv_status.get("consecutive_losses", 0),
        "halted": inv_status.get("halted", False),
        "halt_reason": inv_status.get("halt_reason", ""),
        "max_inventory_usdc": inv_status.get("max_inventory_usdc", 0),
        "cycle_count": mm_status.get("cycle_count", 0),
        "active_quotes": mm_status.get("active_quotes", 0),
        "paper_trading": settings.paper_trading,
        "spread_cents": settings.spread_cents,
        "order_size_usdc": settings.order_size_usdc,

        # ── v9.5: PnL Panel ──────────────────────────────────────────────
        "win_rate_pct": win_rate,
        "winning_trades": len(winning_trades),
        "closed_trades": len(closed_trades),
        "avg_spread_captured": avg_spread_captured,
        "today_pnl": today_pnl,
        "today_trades": today_trades_count,

        # ── v9.5: Hedge Stats ────────────────────────────────────────────
        "hedge_attempts": mm_status.get("hedge_attempts", 0),
        "hedge_fills": mm_status.get("hedge_fills", 0),
        "hedge_fill_rate": mm_status.get("hedge_fill_rate", 0.0),

        # ── v9.5: Advanced Analytics ─────────────────────────────────────
        "arb_opportunities": mm_status.get("arb_opportunities", 0),
        "arb_executed": mm_status.get("arb_executed", 0),
        "adverse_triggers": mm_status.get("adverse_triggers", 0),
        "quotes_skipped_fee": mm_status.get("quotes_skipped_fee", 0),
        "quotes_skipped_corr": mm_status.get("quotes_skipped_corr", 0),
        "session": mm_status.get("session", "normal"),
        "gas_estimate_usd": mm_status.get("gas_estimate_usd", 0),
        "min_profit_cents": mm_status.get("min_profit_cents", 0),
        "adverse_cooldown_sec": mm_status.get("adverse_global_cooldown", 0),
    }


# ── Inventory ────────────────────────────────────────────────────────────────

@admin_router.get("/inventory")
async def inventory_status():
    if not _inventory:
        return {}
    return _inventory.status


# ── Active quotes ────────────────────────────────────────────────────────────

@admin_router.get("/quotes")
async def active_quotes():
    if not _market_maker:
        return []
    return _market_maker.status.get("quotes_detail", [])


# ── Markets ──────────────────────────────────────────────────────────────────

@admin_router.get("/markets")
async def markets():
    if not _clob_client:
        return []
    result = []
    for tid, book in _clob_client.books.items():
        info = _clob_client.markets.get(tid)
        # Get our active quote for this market if any
        our_bid = None
        our_ask = None
        if _market_maker and tid in _market_maker.active_quotes:
            q = _market_maker.active_quotes[tid]
            our_bid = round(q.bid_price, 4) if q.bid_price else None
            our_ask = round(q.ask_price, 4) if q.ask_price else None

        result.append({
            "token_id": tid[:16] + "...",
            "question": info.question[:80] if info else "Unknown",
            "outcome": info.outcome if info else "",
            "best_bid": round(book.best_bid, 4),
            "best_ask": round(book.best_ask, 4),
            "mid": round(book.mid, 4),
            "spread_cents": round(book.spread * 100, 2),
            "volume_24h": round(info.volume_24h, 2) if info else 0,
            "our_bid": our_bid,
            "our_ask": our_ask,
            "last_update_sec_ago": round(time.monotonic() - book.last_update, 1) if book.last_update else 0,
        })
    return result


@admin_router.post("/markets/add")
async def add_markets(count: int = 2):
    """Dynamically add more markets without restarting the bot.

    Discovers new liquid BTC markets via Gamma API, subscribes to their
    WS feeds, and the market maker will start quoting on them automatically.
    PREFERS markets with wider spreads.
    """
    if not _clob_client:
        raise HTTPException(503, "CLOB client not initialized")

    # Temporarily increase auto_pick_count to discover MORE markets than we have
    from app.core.config import settings
    old_count = settings.auto_pick_count
    settings.auto_pick_count = count + len(_clob_client.books)

    try:
        all_markets = await _clob_client.discover_markets()
    finally:
        settings.auto_pick_count = old_count

    # Filter out markets we're already on
    new_markets = [
        m for m in all_markets
        if m.token_id not in _clob_client.books
    ]

    to_add = new_markets[:count]

    if not to_add:
        return {
            "added": 0,
            "total_markets": len(_clob_client.books),
            "message": "No new markets available (all top markets already active)"
        }

    for info in to_add:
        tid = info.token_id
        from app.services.clob_client import MarketBook
        _clob_client.books[tid] = MarketBook(token_id=tid)
        _clob_client.markets[tid] = info
        _clob_client._subscribed.add(tid)

    await _clob_client._refresh_all_books()

    # Reconnect WS
    if _clob_client._ws_task and not _clob_client._ws_task.done():
        _clob_client._ws_task.cancel()
        try:
            await _clob_client._ws_task
        except Exception:
            pass
    import asyncio
    _clob_client._ws_task = asyncio.create_task(
        _clob_client._ws_loop(), name="clob_ws"
    )

    return {
        "added": len(to_add),
        "total_markets": len(_clob_client.books),
        "new_markets": [
            {"question": m.question[:60], "outcome": m.outcome, "volume": m.volume_24h}
            for m in to_add
        ]
    }


@admin_router.post("/markets/refresh_info")
async def refresh_market_info():
    """Fix 'Unknown' market names by re-fetching market info from Gamma API."""
    if not _clob_client:
        raise HTTPException(503, "CLOB client not initialized")

    token_ids = list(_clob_client.books.keys())
    await _clob_client._fetch_market_info(token_ids)

    unknown_count = sum(
        1 for tid in token_ids
        if tid not in _clob_client.markets or not _clob_client.markets[tid].question
    )

    return {
        "total_markets": len(token_ids),
        "with_info": len(token_ids) - unknown_count,
        "still_unknown": unknown_count
    }


@admin_router.post("/markets/set")
async def set_markets(count: int = 5):
    """Set EXACT number of markets (add or remove to match target count).

    If not enough wide-spread markets found, falls back to any-spread markets.
    v9.15: PERSISTS the new count in settings.auto_pick_count so auto-refill
    doesn't override it back to 6.
    """
    if not _clob_client or not _market_maker:
        raise HTTPException(503, "Bot not initialized")

    # v9.15: Persist the target count so auto-refill respects it
    from app.core.config import settings
    settings.auto_pick_count = count

    current_count = len(_clob_client.books)

    if current_count == count:
        return {
            "success": True,
            "total_markets": current_count,
            "message": f"Already at {count} markets"
        }

    if current_count > count:
        # Need to REMOVE markets
        to_remove = current_count - count
        tids_to_remove = list(_clob_client.books.keys())[:to_remove]
        for tid in tids_to_remove:
            if tid in _market_maker.active_quotes:
                await _market_maker._cancel_quote(tid)
            _clob_client.books.pop(tid, None)
            _clob_client.markets.pop(tid, None)
            _clob_client._subscribed.discard(tid)

    else:
        # Need to ADD markets
        to_add = count - current_count

        # Try with current min_spread filter first
        # v9.15: Discover exactly count markets (not count + current)
        old_min_spread = settings.auto_pick_min_spread_cents
        settings.auto_pick_count = count  # was count + current_count (bug)
        try:
            all_markets = await _clob_client.discover_markets()
        finally:
            settings.auto_pick_count = count  # persist new count

        # Filter out markets we already have
        new_markets = [
            m for m in all_markets
            if m.token_id not in _clob_client.books
        ]
        markets_to_add = new_markets[:to_add]

        # If not enough found, relax the spread filter and try again
        if len(markets_to_add) < to_add:
            settings.auto_pick_min_spread_cents = 0.0  # accept ANY spread
            settings.auto_pick_count = count  # v9.15: was count + current_count
            try:
                all_markets_relaxed = await _clob_client.discover_markets()
            finally:
                settings.auto_pick_count = count  # persist new count
                settings.auto_pick_min_spread_cents = old_min_spread

            # Add additional markets from relaxed search
            existing_tids = set(_clob_client.books.keys()) | {m.token_id for m in markets_to_add}
            for m in all_markets_relaxed:
                if m.token_id not in existing_tids:
                    markets_to_add.append(m)
                    existing_tids.add(m.token_id)
                    if len(markets_to_add) >= to_add:
                        break

        for info in markets_to_add:
            tid = info.token_id
            from app.services.clob_client import MarketBook
            _clob_client.books[tid] = MarketBook(token_id=tid)
            _clob_client.markets[tid] = info
            _clob_client._subscribed.add(tid)

    # Refresh books + reconnect WS
    await _clob_client._refresh_all_books()
    if _clob_client._ws_task and not _clob_client._ws_task.done():
        _clob_client._ws_task.cancel()
        try:
            await _clob_client._ws_task
        except Exception:
            pass
    import asyncio
    _clob_client._ws_task = asyncio.create_task(
        _clob_client._ws_loop(), name="clob_ws"
    )

    final_count = len(_clob_client.books)
    shortfall = count - final_count
    msg = f"Set to {final_count} markets"
    if shortfall > 0:
        msg += f" (requested {count}, only {final_count} available on Polymarket)"
    return {
        "success": True,
        "total_markets": final_count,
        "message": msg
    }


@admin_router.post("/markets/replace")
async def replace_markets(count: int = 5):
    """Replace ALL current markets with NEW ones that have wider spreads.

    Cancels all current quotes, removes all markets, discovers new ones
    preferring wider spreads. Use this when current markets have tiny spreads.
    """
    if not _clob_client or not _market_maker:
        raise HTTPException(503, "Bot not initialized")

    # 1. Cancel all active quotes
    for tid in list(_market_maker.active_quotes.keys()):
        await _market_maker._cancel_quote(tid)

    # 2. Clear all markets
    _clob_client.books.clear()
    _clob_client.markets.clear()
    _clob_client._subscribed.clear()

    # 3. Set auto_pick_count and discover new markets
    from app.core.config import settings
    settings.auto_pick_count = count
    new_markets = await _clob_client.discover_markets()

    if not new_markets:
        return {"success": False, "message": "No markets found"}

    # 4. Add new markets
    for info in new_markets:
        tid = info.token_id
        from app.services.clob_client import MarketBook
        _clob_client.books[tid] = MarketBook(token_id=tid)
        _clob_client.markets[tid] = info
        _clob_client._subscribed.add(tid)

    # 5. Refresh books + reconnect WS
    await _clob_client._refresh_all_books()
    if _clob_client._ws_task and not _clob_client._ws_task.done():
        _clob_client._ws_task.cancel()
        try:
            await _clob_client._ws_task
        except Exception:
            pass
    import asyncio
    _clob_client._ws_task = asyncio.create_task(
        _clob_client._ws_loop(), name="clob_ws"
    )

    return {
        "success": True,
        "total_markets": len(_clob_client.books),
        "markets": [
            {"question": m.question[:60], "outcome": m.outcome, "volume": m.volume_24h}
            for m in new_markets
        ]
    }


# ── Trades ───────────────────────────────────────────────────────────────────

@admin_router.get("/trades")
async def list_trades(limit: int = 100, db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(Trade).order_by(Trade.timestamp.desc()).limit(limit)
    )
    return [
        {
            "id": t.id,
            "market": t.market_name[:60],
            "side": t.side.value,
            "price": t.price,
            "size_usdc": t.size_usdc,
            "pnl_usdc": t.pnl_usdc,
            "inventory_after": t.inventory_after,
            "paper": t.paper,
            "timestamp": t.timestamp.isoformat() if t.timestamp else None,
        }
        for t in result.scalars().all()
    ]


# ── Config ───────────────────────────────────────────────────────────────────

class ConfigUpdate(BaseModel):
    spread_cents: float | None = None
    order_size_usdc: float | None = None
    max_inventory_usdc: float | None = None
    requote_interval_sec: float | None = None


@admin_router.get("/config")
async def get_config():
    return {
        "paper_trading": settings.paper_trading,
        "paper_balance_usdc": settings.paper_balance_usdc,
        "spread_cents": settings.spread_cents,                # in cents (4.0 = 4¢)
        "spread_min_cents": settings.spread_min_cents,
        "spread_max_cents": settings.spread_max_cents,
        "order_size_usdc": settings.order_size_usdc,
        "max_inventory_usdc": settings.max_inventory_usdc,
        "max_inventory_pct_of_bankroll": settings.max_inventory_pct_of_bankroll,
        "requote_interval_sec": settings.requote_interval_sec,
        "auto_pick_markets": settings.auto_pick_markets,
        "auto_pick_count": settings.auto_pick_count,
    }


@admin_router.post("/config")
async def update_config(body: ConfigUpdate):
    if body.spread_cents is not None:
        # spread_cents is in CENTS (2.0-10.0). Validate against min/max.
        if body.spread_cents < settings.spread_min_cents or body.spread_cents > settings.spread_max_cents:
            raise HTTPException(
                400,
                f"Spread must be {settings.spread_min_cents}-{settings.spread_max_cents} cents"
            )
        settings.spread_cents = body.spread_cents
    if body.order_size_usdc is not None:
        if body.order_size_usdc < settings.order_size_min_usdc:
            raise HTTPException(400, f"Min order size is ${settings.order_size_min_usdc}")
        settings.order_size_usdc = body.order_size_usdc
    if body.max_inventory_usdc is not None:
        settings.max_inventory_usdc = body.max_inventory_usdc
    if body.requote_interval_sec is not None:
        if body.requote_interval_sec < 0.5:
            raise HTTPException(400, "Min requote interval is 0.5s")
        settings.requote_interval_sec = body.requote_interval_sec
    return {"ok": True, **get_config_sync()}


def get_config_sync() -> dict:
    return {
        "spread_cents": settings.spread_cents,
        "order_size_usdc": settings.order_size_usdc,
        "max_inventory_usdc": settings.max_inventory_usdc,
        "requote_interval_sec": settings.requote_interval_sec,
    }


# ── Risk controls ────────────────────────────────────────────────────────────

class DepositUpdate(BaseModel):
    deposit_usdc: float


@admin_router.post("/config/deposit")
async def set_deposit(body: DepositUpdate, db: AsyncSession = Depends(get_db)):
    """Set new paper deposit. Resets bankroll + clears trades."""
    if not settings.paper_trading:
        raise HTTPException(403, "Not in paper mode")
    if body.deposit_usdc < 5.0:
        raise HTTPException(400, "Min deposit is $5")
    if body.deposit_usdc > 10000.0:
        raise HTTPException(400, "Max deposit is $10000")

    settings.paper_balance_usdc = body.deposit_usdc
    _inventory.bankroll = body.deposit_usdc

    # Clear trades + inventory for clean start
    from sqlalchemy import delete
    await db.execute(delete(Trade))
    await db.execute(delete(Quote))
    await db.commit()
    _inventory.inventories.clear()
    _inventory.consecutive_losses = 0
    _inventory.daily_pnl = 0.0
    _inventory.halted = False
    _inventory.halt_reason = ""

    return {
        "ok": True,
        "paper_balance_usdc": settings.paper_balance_usdc,
        "bankroll_usdc": _inventory.bankroll,
        "message": f"✅ Deposit set to ${body.deposit_usdc}. Bankroll reset."
    }


@admin_router.post("/risk/resume")
async def resume_trading():
    if not _inventory:
        raise HTTPException(503, "Inventory manager not initialized")
    prev = _inventory.resume()
    return {"resumed": True, "was_halted_for": prev}


@admin_router.post("/paper/reset")
async def reset_paper(db: AsyncSession = Depends(get_db)):
    if not settings.paper_trading:
        raise HTTPException(403, "Not in paper mode")
    # Wipe all trades + quotes
    result = await db.execute(select(Trade))
    for t in result.scalars().all():
        await db.delete(t)
    result = await db.execute(select(Quote))
    for q in result.scalars().all():
        await db.delete(q)
    await db.commit()
    # Reset inventory
    if _inventory:
        _inventory.bankroll = settings.paper_balance_usdc
        _inventory.inventories.clear()
        _inventory.daily_pnl = 0.0
        _inventory.consecutive_losses = 0
        _inventory.halted = False
        _inventory.halt_reason = ""
    return {"reset": True, "new_balance": settings.paper_balance_usdc}


# ── Analytics ────────────────────────────────────────────────────────────────

@admin_router.get("/analytics/by_market")
async def by_market(db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(
            Trade.market_name,
            func.sum(Trade.pnl_usdc),
            func.count(Trade.id),
            func.sum(func.case((Trade.side == Side.BUY, 1), else_=0)),
            func.sum(func.case((Trade.side == Side.SELL, 1), else_=0)),
        )
        .group_by(Trade.market_name)
        .order_by(func.sum(Trade.pnl_usdc).desc())
    )
    return [
        {
            "market_name": r[0],
            "total_pnl": round(r[1] or 0, 4),
            "trade_count": r[2],
            "buys": r[3],
            "sells": r[4],
        }
        for r in result.all()
    ]


# ── Self-Diagnostics ─────────────────────────────────────────────────────────

@admin_router.get("/diagnostics")
async def diagnostics(db: AsyncSession = Depends(get_db)):
    """Self-diagnostic: checks all bot subsystems and reports health status.

    Checks:
      1. WebSocket connection (stale data?)
      2. Market data freshness (books updating?)
      3. Order book quality (bids + asks present?)
      4. Fill rate health (enough fills per cycle?)
      5. Inventory risk (too much exposure?)
      6. P&L trend (profitable or losing?)
      7. Bankroll health (above starting balance?)
      8. Halt status (is bot halted?)
    """
    import time
    from datetime import datetime, timedelta, timezone

    checks = []
    overall_healthy = True

    # 1. WebSocket connection check
    if _clob_client:
        ws_age = time.monotonic() - _clob_client._last_ws_msg
        ws_ok = ws_age < 30
        ws_detail = f"Last message {ws_age:.0f}s ago"
        if ws_age > 60:
            ws_detail += " ⛔ INTERNET DOWN?"
        elif ws_age > 30:
            ws_detail += " ⚠️ STALE"
        checks.append({
            "name": "WebSocket",
            "healthy": ws_ok,
            "detail": ws_detail,
        })
        if not ws_ok: overall_healthy = False
    else:
        checks.append({"name": "WebSocket", "healthy": False, "detail": "Not initialized"})
        overall_healthy = False

    # 2. Market data freshness
    if _clob_client and _clob_client.books:
        stale_books = 0
        total_books = len(_clob_client.books)
        for book in _clob_client.books.values():
            age = time.monotonic() - book.last_update
            if age > 15:
                stale_books += 1
        books_ok = stale_books == 0
        checks.append({
            "name": "Market Data",
            "healthy": books_ok,
            "detail": f"{total_books - stale_books}/{total_books} books fresh" + (f" ({stale_books} STALE!)" if stale_books else ""),
        })
        if not books_ok: overall_healthy = False
    else:
        checks.append({"name": "Market Data", "healthy": False, "detail": "No books"})
        overall_healthy = False

    # 3. Order book quality
    if _clob_client and _clob_client.books:
        good_books = sum(1 for b in _clob_client.books.values() if b.bids and b.asks)
        total_books = len(_clob_client.books)
        quality_ok = good_books >= total_books * 0.8
        checks.append({
            "name": "Book Quality",
            "healthy": quality_ok,
            "detail": f"{good_books}/{total_books} have bid+ask" + (" (some empty!)" if not quality_ok else ""),
        })
        if not quality_ok: overall_healthy = False

    # 4. P&L trend — use TOTAL EQUITY (cash + inventory), not just cash
    if _inventory:
        # Calculate inventory value at current mid prices
        inventory_value = 0.0
        if _clob_client:
            for tid, inv_data in _inventory.inventories.items():
                book = _clob_client.books.get(tid)
                if book and inv_data.net_tokens != 0:
                    inventory_value += inv_data.net_tokens * book.mid

        total_equity = _inventory.bankroll + inventory_value
        pnl = total_equity - settings.paper_balance_usdc
        pnl_ok = pnl > -settings.max_daily_loss_usd
        checks.append({
            "name": "P&L Health",
            "healthy": pnl_ok,
            "detail": f"{'+' if pnl >= 0 else ''}{pnl:.2f} USDC (cash ${_inventory.bankroll:.0f} + inv ${inventory_value:.0f})",
        })
        if not pnl_ok: overall_healthy = False

    # 5. Inventory risk
    if _inventory:
        total_inv = sum(abs(inv.net_usdc_at_entry) for inv in _inventory.inventories.values())
        max_allowed = _inventory.max_inventory_usdc() * len(_inventory.inventories)
        inv_ok = total_inv < max_allowed * 0.9
        checks.append({
            "name": "Inventory Risk",
            "healthy": inv_ok,
            "detail": f"${total_inv:.2f} exposed / ${max_allowed:.2f} max ({total_inv/max(max_allowed,1)*100:.0f}%)",
        })
        if not inv_ok: overall_healthy = False

    # 6. Halt/pause status
    if _inventory and _market_maker:
        halted = _inventory.halted
        paused = _market_maker._trading_paused
        if halted:
            checks.append({
                "name": "Trading Status",
                "healthy": False,
                "detail": f"🛑 HALTED: {_inventory.halt_reason}",
            })
            overall_healthy = False
        elif paused:
            checks.append({
                "name": "Trading Status",
                "healthy": True,
                "detail": "⏸ PAUSED — click 'Start Trading' to begin",
            })
        else:
            checks.append({
                "name": "Trading Status",
                "healthy": True,
                "detail": "▶ Active — placing quotes",
            })

    # 7. Fill rate
    if _market_maker:
        cycle_count = _market_maker._cycle_count
        fill_count = _market_maker._fill_count
        fill_rate = (fill_count / max(cycle_count, 1)) * 100
        fill_ok = fill_rate > 0.5 or cycle_count < 60  # ok if >0.5% or just started
        checks.append({
            "name": "Fill Rate",
            "healthy": fill_ok,
            "detail": f"{fill_count} fills / {cycle_count} cycles ({fill_rate:.1f}%)",
        })
        if not fill_ok: overall_healthy = False

    # 8. Active quotes
    if _market_maker:
        active = len(_market_maker.active_quotes)
        total_markets = len(_clob_client.books) if _clob_client else 0
        quotes_ok = active > 0 or total_markets == 0
        checks.append({
            "name": "Active Quotes",
            "healthy": quotes_ok,
            "detail": f"{active} active / {total_markets} markets",
        })
        if not quotes_ok: overall_healthy = False

    return {
        "overall_healthy": overall_healthy,
        "status": "✅ ALL SYSTEMS OK" if overall_healthy else "⚠️ ISSUES DETECTED",
        "checks": checks,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


# ── Live mode checklist + emergency stop ────────────────────────────────────

@admin_router.get("/live/checklist")
async def live_checklist():
    """Check if bot is ready for LIVE trading. Returns list of checks."""
    checks = []
    ready = True

    # 1. Paper mode off?
    if settings.paper_trading:
        checks.append({"name": "Paper mode OFF", "ok": False, "detail": "PAPER_TRADING=true — set to false for live"})
        ready = False
    else:
        checks.append({"name": "Paper mode OFF", "ok": True, "detail": "Live mode enabled"})

    # 2. Private key set?
    if not settings.polygon_private_key:
        checks.append({"name": "Polygon private key", "ok": False, "detail": "POLYGON_PRIVATE_KEY not set"})
        ready = False
    else:
        checks.append({"name": "Polygon private key", "ok": True, "detail": f"Key set (0x{settings.polygon_private_key[-4:]})"})

    # 3. Wallet address set?
    if not settings.polygon_wallet_address:
        checks.append({"name": "Wallet address", "ok": False, "detail": "POLYGON_WALLET_ADDRESS not set"})
        ready = False
    else:
        checks.append({"name": "Wallet address", "ok": True, "detail": f"0x{settings.polygon_wallet_address[-4:]}"})

    # 4. CLOB API key set?
    if not settings.clob_api_key:
        checks.append({"name": "CLOB API key", "ok": False, "detail": "CLOB_API_KEY not set"})
        ready = False
    else:
        checks.append({"name": "CLOB API key", "ok": True, "detail": f"Key: {settings.clob_api_key[:8]}..."})

    # 5. CLOB API secret set?
    if not settings.clob_api_secret:
        checks.append({"name": "CLOB API secret", "ok": False, "detail": "CLOB_API_SECRET not set"})
        ready = False
    else:
        checks.append({"name": "CLOB API secret", "ok": True, "detail": "Secret set"})

    # 6. CLOB passphrase set?
    if not settings.clob_api_passphrase:
        checks.append({"name": "CLOB passphrase", "ok": False, "detail": "CLOB_API_PASSPHRASE not set"})
        ready = False
    else:
        checks.append({"name": "CLOB passphrase", "ok": True, "detail": "Passphrase set"})

    # 7. Order size reasonable?
    if settings.order_size_usdc > 50:
        checks.append({"name": "Order size safe", "ok": False, "detail": f"Order size ${settings.order_size_usdc} — too high for first live test (max $50)"})
        ready = False
    elif settings.order_size_usdc < 2:
        checks.append({"name": "Order size safe", "ok": False, "detail": f"Order size ${settings.order_size_usdc} — too low (min $5)"})
        ready = False
    else:
        checks.append({"name": "Order size safe", "ok": True, "detail": f"${settings.order_size_usdc} per order"})

    # 8. Max daily loss set?
    if settings.max_daily_loss_usd > 50:
        checks.append({"name": "Daily loss limit", "ok": False, "detail": f"Max daily loss ${settings.max_daily_loss_usd} — too high (recommend $20 for $200 balance)"})
        ready = False
    else:
        checks.append({"name": "Daily loss limit", "ok": True, "detail": f"${settings.max_daily_loss_usd} max daily loss"})

    return {
        "ready": ready,
        "status": "✅ READY FOR LIVE" if ready else "❌ NOT READY — fix issues above",
        "checks": checks,
    }


@admin_router.post("/emergency_stop")
async def emergency_stop():
    """KILL SWITCH: immediately cancel all orders and halt trading."""
    if not _market_maker or not _inventory:
        raise HTTPException(503, "Bot not initialized")

    # 1. Cancel all active quotes
    canceled = 0
    for tid in list(_market_maker.active_quotes.keys()):
        await _market_maker._cancel_quote(tid)
        canceled += 1

    # 2. Halt trading
    _inventory.halt("EMERGENCY STOP — manual kill switch")

    return {
        "stopped": True,
        "orders_canceled": canceled,
        "message": "🛑 EMERGENCY STOP — all orders canceled, trading halted. Click Resume to restart."
    }


@admin_router.post("/pause")
async def pause_trading():
    """Pause: stop placing new orders, cancel existing immediately."""
    if not _market_maker or not _inventory:
        raise HTTPException(503, "Bot not initialized")

    active = len(_market_maker.active_quotes)
    _market_maker.stop_trading()

    return {
        "paused": True,
        "orders_canceled": active,
        "message": f"⏸ Paused — {active} quotes canceled. Bot is idle."
    }


@admin_router.post("/start")
async def start_trading():
    """Start trading: begin placing quotes."""
    if not _market_maker or not _inventory:
        raise HTTPException(503, "Bot not initialized")

    if _market_maker.is_trading:
        return {"started": False, "message": "Already trading"}

    _market_maker.start_trading()

    return {
        "started": True,
        "message": "▶ Trading STARTED — placing quotes now!"
    }


@admin_router.post("/mode/toggle")
async def toggle_mode():
    """Toggle between PAPER and LIVE mode.

    In PAPER → LIVE: requires all live checklist items to pass.
    In LIVE → PAPER: always allowed (safe fallback).
    """
    if not _market_maker or not _inventory:
        raise HTTPException(503, "Bot not initialized")

    import asyncio

    if settings.paper_trading:
        # Switching to LIVE — run checklist first
        checklist = await live_checklist()
        if not checklist["ready"]:
            return {
                "success": False,
                "message": "❌ Cannot switch to LIVE — fix issues first. Click 'Live Check' for details.",
                "checks": checklist["checks"]
            }

        # Pause bot first (cancel all paper orders)
        _inventory.halted = True
        _inventory.halt_reason = "Switching to LIVE mode"
        for tid in list(_market_maker.active_quotes.keys()):
            await _market_maker._cancel_quote(tid)
        await asyncio.sleep(1)

        # Switch mode
        settings.paper_trading = False
        _inventory.halted = False
        _inventory.halt_reason = ""

        return {
            "success": True,
            "mode": "LIVE",
            "message": "🔴 Switched to LIVE mode — bot will place REAL orders now!"
        }
    else:
        # Switching to PAPER — always safe
        _inventory.halted = True
        _inventory.halt_reason = "Switching to PAPER mode"
        for tid in list(_market_maker.active_quotes.keys()):
            await _market_maker._cancel_quote(tid)
        await asyncio.sleep(1)

        settings.paper_trading = True
        _inventory.halted = False
        _inventory.halt_reason = ""

        return {
            "success": True,
            "mode": "PAPER",
            "message": "📄 Switched to PAPER mode — safe simulation."
        }


# ── Helper import ────────────────────────────────────────────────────────────
import time  # for markets endpoint
