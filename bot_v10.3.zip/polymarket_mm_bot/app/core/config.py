"""
app/core/config.py — Market Maker Bot Configuration
═══════════════════════════════════════════════════
All tunable parameters for the Polymarket market maker.

IMPORTANT: All *_cents values are in ACTUAL CENTS (4.0 = 4¢ = $0.04).
"""
from __future__ import annotations

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env", env_file_encoding="utf-8", extra="ignore"
    )

    # ── Mode ──────────────────────────────────────────────────────────────────
    paper_trading: bool = True
    paper_balance_usdc: float = 200.0

    # ── Polymarket API ────────────────────────────────────────────────────────
    clob_base_url: str = "https://clob.polymarket.com"
    ws_url: str = "wss://ws-subscriptions-clob.polymarket.com/ws/market"
    gamma_url: str = "https://gamma-api.polymarket.com"

    # Auth (required for live trading)
    polygon_private_key: str = ""
    polygon_wallet_address: str = ""
    clob_api_key: str = ""
    clob_api_secret: str = ""
    clob_api_passphrase: str = ""

    # ── Market selection ──────────────────────────────────────────────────────
    market_token_ids: str = ""
    auto_pick_markets: bool = True
    auto_pick_min_volume_24h: float = 20_000.0
    auto_pick_min_spread: float = 0.02
    auto_pick_count: int = 6
    # Comma-separated keywords — ONLY sports, politics, news (NO crypto!)
    auto_pick_keywords: str = "NBA,NFL,MLB,NHL,Soccer,League,Match,Game,beat,win,Cup,Championship,Tournament,Election,Trump,President,Senate,Governor,Congress,Parliament,Prime,Minister,Russia,Cabinet,Supreme,Fed,rates,launch,before,July,August,September,announce,reveal,release"
    # Min spread in cents for market to be eligible (0 = no filter)
    auto_pick_min_spread_cents: float = 2.0  # v9.16: 2¢ minimum, was 1.5¢

    # Pre-resolution exit: stop quoting N seconds before market ends
    # Sports markets become volatile near game time — exit early
    pre_resolution_exit_sec: int = 10800  # 3 hours before end → stop quoting

    # ── Quote parameters ──────────────────────────────────────────────────────
    # ALL *_cents values are in ACTUAL CENTS (4.0 = 4¢ = $0.04)
    spread_cents: float = 4.0          # 4¢ spread (2¢ each side of mid)
    spread_min_cents: float = 2.0      # never tighter than 2¢
    spread_max_cents: float = 10.0     # never wider than 10¢
    spread_volatility_mult: float = 2.0

    order_size_usdc: float = 10.0
    order_size_min_usdc: float = 5.0

    requote_interval_sec: float = 2.0
    requote_threshold_cents: float = 1.0  # requote if mid moved >1¢

    # ── Inventory management ──────────────────────────────────────────────────
    max_inventory_usdc: float = 50.0
    max_inventory_pct_of_bankroll: float = 0.25
    inventory_skew_threshold: float = 0.3
    inventory_skew_cents: float = 1.0  # 1¢ shift
    inventory_clear_threshold: float = 0.8

    # ── Risk controls ─────────────────────────────────────────────────────────
    max_daily_loss_usd: float = 20.0
    stop_trading_consecutive_losses: int = 5
    cancel_on_major_move_cents: float = 5.0  # 5¢

    # ── v9.0: Order Book Imbalance ──────────────────────────────────────────
    book_imbalance_enabled: bool = True
    book_imbalance_levels: int = 3
    book_imbalance_max_skew_cents: float = 1.0
    book_imbalance_threshold: float = 1.5

    # ── v9.0: Arbitrage Detection ───────────────────────────────────────────
    arb_detection_enabled: bool = True
    arb_min_profit_cents: float = 0.8
    arb_max_size_usdc: float = 20.0

    # ── v9.0: Inventory Aging ───────────────────────────────────────────────
    inventory_aging_enabled: bool = True
    inventory_aging_threshold_sec: float = 300.0
    inventory_aging_discount_step_cents: float = 0.5
    inventory_aging_max_discount_cents: float = 3.0

    # ── v9.0: Adverse Selection Protection ──────────────────────────────────
    adverse_selection_enabled: bool = True
    adverse_selection_move_cents: float = 3.0
    adverse_selection_window_sec: float = 10.0
    adverse_selection_cooldown_sec: float = 30.0

    # ── v9.5: Correlation Awareness ─────────────────────────────────────────
    correlation_aware_enabled: bool = True
    correlation_max_per_category_usdc: float = 30.0
    correlation_min_markets_in_category: int = 2

    # ── v9.5: Session-Based Quoting ─────────────────────────────────────────
    session_quoting_enabled: bool = True
    session_active_start_utc: int = 14
    session_active_end_utc: int = 22
    session_active_spread_mult: float = 1.2
    session_quiet_spread_mult: float = 0.9

    # ── v9.5: Live Mode Retry ───────────────────────────────────────────────
    live_retry_enabled: bool = True
    live_retry_max_attempts: int = 3
    live_retry_initial_backoff_sec: float = 0.5

    # ── v9.5: Telegram Alerts ───────────────────────────────────────────────
    telegram_enabled: bool = False
    telegram_bot_token: str = ""
    telegram_chat_id: str = ""
    telegram_daily_summary_hour_utc: int = 23

    # ── v9.5: Fee/Gas Awareness ─────────────────────────────────────────────
    fee_awareness_enabled: bool = True
    fee_min_profit_cents: float = 0.5
    fee_estimated_gas_usd: float = 0.001

    # ── v9.5: Hedging ───────────────────────────────────────────────────────
    hedging_enabled: bool = True
    hedging_max_combined_usdc: float = 20.0
    hedging_active_enabled: bool = True
    hedging_active_aggressiveness_cents: float = 0.3
    hedging_active_max_slippage_cents: float = 1.5

    # ── v9.5: Smart Scoring ─────────────────────────────────────────────────
    smart_scoring_enabled: bool = True
    smart_scoring_max_drift_pct: float = 5.0
    smart_scoring_min_score: float = 30.0
    smart_scoring_expiry_penalty_hours: float = 6.0
    smart_scoring_quiet_hours_start: int = 0
    smart_scoring_quiet_hours_end: int = 6

    # ── v9.5: Multi-level ───────────────────────────────────────────────────
    multi_level_enabled: bool = True
    multi_level_1_capture: float = 0.15
    multi_level_1_size_pct: float = 0.45
    multi_level_2_capture: float = 0.30
    multi_level_2_size_pct: float = 0.35
    multi_level_3_capture: float = 0.45
    multi_level_3_size_pct: float = 0.20

    # ── Admin ─────────────────────────────────────────────────────────────────
    admin_host: str = "127.0.0.1"
    admin_port: int = 8000
    database_url: str = "sqlite+aiosqlite:///./mm_bot.db"

    log_level: str = "INFO"


settings = Settings()
