"""
app/db/models.py — ORM models for MM bot

Trade: each fill (buy or sell) of our quote
Quote: each quote we place (for analytics)
Inventory: current net position per market
"""
from __future__ import annotations

import enum
from datetime import datetime

from sqlalchemy import DateTime, Enum, Float, Integer, String, func
from sqlalchemy.orm import Mapped, mapped_column

from app.core.db import Base


class Side(str, enum.Enum):
    BUY = "BUY"      # we bought tokens (someone hit our bid)
    SELL = "SELL"    # we sold tokens (someone hit our ask)


class QuoteStatus(str, enum.Enum):
    PLACED = "PLACED"
    FILLED = "FILLED"
    CANCELED = "CANCELED"
    PARTIAL = "PARTIAL"


class Trade(Base):
    """Each individual fill (one side of a round-trip)."""
    __tablename__ = "mm_trades"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    market_id: Mapped[str] = mapped_column(String, nullable=False, index=True)
    market_name: Mapped[str] = mapped_column(String, nullable=False)
    side: Mapped[Side] = mapped_column(Enum(Side), nullable=False)

    price: Mapped[float] = mapped_column(Float, nullable=False)
    size_usdc: Mapped[float] = mapped_column(Float, nullable=False)
    size_tokens: Mapped[float] = mapped_column(Float, nullable=False)

    # P&L tracking: for SELL trades, pnl is realized vs avg buy price
    pnl_usdc: Mapped[float | None] = mapped_column(Float, nullable=True)

    # Inventory snapshot at fill time
    inventory_after: Mapped[float] = mapped_column(Float, default=0.0)

    order_id: Mapped[str | None] = mapped_column(String, nullable=True)
    paper: Mapped[bool] = mapped_column(default=True)
    timestamp: Mapped[datetime] = mapped_column(
        DateTime, server_default=func.now(), nullable=False
    )


class Quote(Base):
    """Each quote we place (for analytics — to track fill rate)."""
    __tablename__ = "mm_quotes"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    market_id: Mapped[str] = mapped_column(String, nullable=False, index=True)
    bid_price: Mapped[float] = mapped_column(Float, nullable=False)
    ask_price: Mapped[float] = mapped_column(Float, nullable=False)
    mid_price: Mapped[float] = mapped_column(Float, nullable=False)
    size_usdc: Mapped[float] = mapped_column(Float, nullable=False)
    spread_cents: Mapped[float] = mapped_column(Float, nullable=False)

    status: Mapped[QuoteStatus] = mapped_column(
        Enum(QuoteStatus), default=QuoteStatus.PLACED, nullable=False
    )
    timestamp: Mapped[datetime] = mapped_column(
        DateTime, server_default=func.now(), nullable=False
    )


class MarketSnapshot(Base):
    """Periodic snapshots of market state for charts."""
    __tablename__ = "mm_snapshots"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    market_id: Mapped[str] = mapped_column(String, nullable=False, index=True)
    mid_price: Mapped[float] = mapped_column(Float, nullable=False)
    spread: Mapped[float] = mapped_column(Float, nullable=False)
    our_inventory: Mapped[float] = mapped_column(Float, default=0.0)
    bankroll_usdc: Mapped[float] = mapped_column(Float, nullable=False)
    timestamp: Mapped[datetime] = mapped_column(
        DateTime, server_default=func.now(), nullable=False
    )
