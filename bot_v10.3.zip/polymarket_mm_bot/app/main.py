"""app/main.py — Market Maker Bot entry point"""
from __future__ import annotations

import asyncio
import logging
import sys
from contextlib import asynccontextmanager

import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from app.admin.api import admin_router, inject_services
from app.core.config import settings
from app.db.init_db import init_db
from app.services.clob_client import ClobClient
from app.services.inventory_manager import InventoryManager
from app.services.market_maker import MarketMaker

logging.basicConfig(
    level=getattr(logging, settings.log_level.upper(), logging.INFO),
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
logger = logging.getLogger(__name__)

# Globals
clob = ClobClient()
inventory = InventoryManager()
mm = MarketMaker(clob, inventory)


async def _select_markets() -> list[str]:
    """Pick markets to MM on. Returns token IDs."""
    # 1. Explicit list from config
    if settings.market_token_ids:
        ids = [s.strip() for s in settings.market_token_ids.split(",") if s.strip()]
        if ids:
            logger.info("Using configured market token IDs: %d", len(ids))
            return ids

    # 2. Auto-pick from Gamma API
    if settings.auto_pick_markets:
        infos = await clob.discover_markets()
        if infos:
            # IMPORTANT: Store MarketInfo objects BEFORE starting CLOB client
            # so names and volumes are available immediately
            for info in infos:
                clob.markets[info.token_id] = info
            return [info.token_id for info in infos]

    logger.error("No markets selected — set MARKET_TOKEN_IDS or AUTO_PICK_MARKETS=true")
    return []


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("━" * 60)
    logger.info(" Polymarket Market Maker Bot v1.0")
    logger.info(" Mode: %s", "PAPER 📄" if settings.paper_trading else "LIVE 🔴")
    logger.info(" Spread: %.2f¢ | Order size: $%.2f", settings.spread_cents, settings.order_size_usdc)
    logger.info(" Max inventory: $%.2f (%.0f%% of bankroll)",
                settings.max_inventory_usdc,
                settings.max_inventory_pct_of_bankroll * 100)
    logger.info(" Requote interval: %.1fs", settings.requote_interval_sec)
    logger.info("━" * 60)

    await init_db()

    # Select markets
    token_ids = await _select_markets()
    if not token_ids:
        logger.error("No markets to trade — exiting")
        return

    # Start CLOB client (fetches books + WS)
    await clob.start(token_ids)
    inject_services(clob, inventory, mm)

    # Start MM engine
    await mm.start()

    yield

    logger.info("Shutting down…")
    await mm.stop()
    await clob.stop()


app = FastAPI(
    title="Polymarket Market Maker Bot",
    version="1.0.0",
    lifespan=lifespan,
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)
app.include_router(admin_router, prefix="/api")

import os
if os.path.exists("app/static"):
    app.mount("/", StaticFiles(directory="app/static", html=True), name="static")

if __name__ == "__main__":
    uvicorn.run(
        "app.main:app",
        host=settings.admin_host,
        port=settings.admin_port,
        reload=False,
        log_level="info",
    )
