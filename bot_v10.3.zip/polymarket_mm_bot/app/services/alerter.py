"""
app/services/alerter.py — v9.5 Telegram Alerting
"""
from __future__ import annotations

import logging
import time
from collections import deque
from datetime import datetime, timezone
from typing import Optional

from app.core.config import settings

logger = logging.getLogger(__name__)


class Alert:
    def __init__(self, level, title, message):
        self.timestamp = datetime.now(timezone.utc)
        self.level = level
        self.title = title
        self.message = message

    def to_dict(self):
        return {
            "timestamp": self.timestamp.isoformat(),
            "level": self.level,
            "title": self.title,
            "message": self.message,
        }


class Alerter:
    def __init__(self):
        self._alert_log = deque(maxlen=50)
        self._last_daily_summary = None
        self._last_alert_time = {}
        self._min_alert_interval_sec = 60

    async def send(self, level, title, message, alert_key=""):
        if alert_key:
            now = time.monotonic()
            last = self._last_alert_time.get(alert_key, 0)
            if now - last < self._min_alert_interval_sec:
                return
            self._last_alert_time[alert_key] = now
        alert = Alert(level, title, message)
        self._alert_log.append(alert)
        if level == "critical":
            logger.critical("🚨 [%s] %s — %s", title, level, message)
        elif level == "warning":
            logger.warning("⚠️ [%s] %s — %s", title, level, message)
        else:
            logger.info("ℹ️ [%s] %s — %s", title, level, message)
        if settings.telegram_enabled and settings.telegram_bot_token and settings.telegram_chat_id:
            try:
                await self._send_telegram(alert)
            except Exception as e:
                logger.debug("Telegram send failed: %s", e)

    async def _send_telegram(self, alert):
        emoji = {"info": "ℹ️", "warning": "⚠️", "critical": "🚨"}.get(alert.level, "ℹ️")
        text = f"{emoji} *{alert.title}*\n\n{alert.message}\n\n_Time: {alert.timestamp.strftime('%Y-%m-%d %H:%M:%S UTC')}_"
        try:
            import httpx
            url = f"https://api.telegram.org/bot{settings.telegram_bot_token}/sendMessage"
            async with httpx.AsyncClient(timeout=10.0) as client:
                resp = await client.post(url, json={"chat_id": settings.telegram_chat_id, "text": text, "parse_mode": "Markdown"})
        except ImportError:
            pass

    async def send_daily_summary(self, bankroll, daily_pnl, total_trades, win_rate, hedge_attempts, hedge_fills):
        now = datetime.now(timezone.utc)
        if self._last_daily_summary:
            if (now - self._last_daily_summary).total_seconds() < 23 * 3600:
                return
        self._last_daily_summary = now
        pnl_str = f"+${daily_pnl:.2f}" if daily_pnl >= 0 else f"-${abs(daily_pnl):.2f}"
        message = (
            f"📊 *Daily Summary*\n\n"
            f"💰 Bankroll: ${bankroll:.2f}\n"
            f"📈 Daily P&L: {pnl_str}\n"
            f"🔄 Total trades: {total_trades}\n"
            f"🎯 Win rate: {win_rate:.1f}%\n"
            f"🛡️ Hedge: {hedge_fills}/{hedge_attempts} fills\n"
        )
        await self.send("info", "Daily Summary", message, alert_key="daily_summary")

    @property
    def recent_alerts(self):
        return [a.to_dict() for a in reversed(self._alert_log)]


alerter = Alerter()
