"""
app/services/analytics.py — v9.12 Market Analytics
═══════════════════════════════════════════════════
FIX: AdverseSelection infinite loop — after trigger, clear price history
so it doesn't re-trigger on the same price move.
"""
from __future__ import annotations

import logging
import time
from collections import defaultdict, deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional

from app.core.config import settings
from app.services.clob_client import MarketBook

logger = logging.getLogger(__name__)


class OrderBookImbalance:
    @staticmethod
    def compute(book: MarketBook) -> float:
        if not settings.book_imbalance_enabled:
            return 0.0
        if not book.bids or not book.asks:
            return 0.0
        n_levels = settings.book_imbalance_levels
        top_bids = sorted(book.bids, key=lambda x: x.price, reverse=True)[:n_levels]
        top_asks = sorted(book.asks, key=lambda x: x.price)[:n_levels]
        bid_size = sum(l.size for l in top_bids)
        ask_size = sum(l.size for l in top_asks)
        if bid_size <= 0 or ask_size <= 0:
            return 0.0
        ratio = bid_size / ask_size
        threshold = settings.book_imbalance_threshold
        if ratio > threshold:
            magnitude = min(1.0, (ratio - threshold) / threshold)
            return magnitude * settings.book_imbalance_max_skew_cents
        elif ratio < (1.0 / threshold):
            magnitude = min(1.0, ((1.0 / ratio) - threshold) / threshold)
            return -magnitude * settings.book_imbalance_max_skew_cents
        return 0.0


@dataclass
class ArbOpportunity:
    yes_token_id: str
    no_token_id: str
    yes_price: float
    no_price: float
    sum_price: float
    direction: str
    profit_cents: float
    size_usdc: float


class ArbitrageDetector:
    @staticmethod
    def detect(yes_token_id, no_token_id, yes_book, no_book):
        if not settings.arb_detection_enabled:
            return None
        if not yes_book.bids or not yes_book.asks:
            return None
        if not no_book.bids or not no_book.asks:
            return None
        yes_ask = yes_book.best_ask
        no_ask = no_book.best_ask
        buy_buy_sum = yes_ask + no_ask
        buy_buy_profit_cents = (1.00 - buy_buy_sum) * 100
        yes_bid = yes_book.best_bid
        no_bid = no_book.best_bid
        sell_sell_sum = yes_bid + no_bid
        sell_sell_profit_cents = (sell_sell_sum - 1.00) * 100
        if buy_buy_profit_cents > settings.arb_min_profit_cents:
            yes_size_usd = yes_ask * sum(l.size for l in yes_book.asks[:3])
            no_size_usd = no_ask * sum(l.size for l in no_book.asks[:3])
            max_size = min(yes_size_usd, no_size_usd, settings.arb_max_size_usdc)
            if max_size < 1.0:
                return None
            return ArbOpportunity(yes_token_id, no_token_id, yes_ask, no_ask, buy_buy_sum, "BUY_BUY", buy_buy_profit_cents, max_size)
        elif sell_sell_profit_cents > settings.arb_min_profit_cents:
            yes_size_usd = yes_bid * sum(l.size for l in yes_book.bids[:3])
            no_size_usd = no_bid * sum(l.size for l in no_book.bids[:3])
            max_size = min(yes_size_usd, no_size_usd, settings.arb_max_size_usdc)
            if max_size < 1.0:
                return None
            return ArbOpportunity(yes_token_id, no_token_id, yes_bid, no_bid, sell_sell_sum, "SELL_SELL", sell_sell_profit_cents, max_size)
        return None


@dataclass
class PositionTracker:
    token_id: str
    open_time: float = field(default_factory=time.monotonic)
    last_fill_time: float = field(default_factory=time.monotonic)
    net_tokens_at_open: float = 0.0


class InventoryAger:
    def __init__(self):
        self._positions = {}

    def update_position(self, token_id, net_tokens):
        if not settings.inventory_aging_enabled:
            return
        existing = self._positions.get(token_id)
        if existing is None:
            self._positions[token_id] = PositionTracker(token_id=token_id, net_tokens_at_open=net_tokens)
            return
        if existing.net_tokens_at_open != 0:
            if (existing.net_tokens_at_open > 0) != (net_tokens > 0 and net_tokens != 0):
                existing.open_time = time.monotonic()
                existing.net_tokens_at_open = net_tokens
        existing.last_fill_time = time.monotonic()
        if abs(net_tokens) < 0.001:
            self._positions.pop(token_id, None)

    def get_discount_cents(self, token_id):
        if not settings.inventory_aging_enabled:
            return 0.0
        pos = self._positions.get(token_id)
        if pos is None:
            return 0.0
        age_sec = time.monotonic() - pos.open_time
        threshold = settings.inventory_aging_threshold_sec
        if age_sec < threshold:
            return 0.0
        steps_past = int((age_sec - threshold) / 60.0)
        discount = steps_past * settings.inventory_aging_discount_step_cents
        return min(discount, settings.inventory_aging_max_discount_cents)

    def clear(self, token_id):
        self._positions.pop(token_id, None)


class AdverseSelection:
    """v9.12 FIX: Clear price history after trigger to prevent infinite loop."""

    def __init__(self):
        self._price_history = {}
        self._cooldowns = {}
        self._global_cooldown_until = 0.0
        self._last_trigger_time = {}  # token_id → monotonic time of last trigger

    def track(self, token_id, mid):
        if token_id not in self._price_history:
            self._price_history[token_id] = deque(maxlen=120)
        self._price_history[token_id].append((time.monotonic(), mid))

    def check_trigger(self, token_id):
        if not settings.adverse_selection_enabled:
            return False
        history = self._price_history.get(token_id)
        if not history or len(history) < 2:
            return False
        now = time.monotonic()
        # v9.12: Don't re-trigger if already triggered recently for this market
        last_trigger = self._last_trigger_time.get(token_id, 0)
        if now - last_trigger < settings.adverse_selection_cooldown_sec:
            return False
        window = settings.adverse_selection_window_sec
        move_threshold = settings.adverse_selection_move_cents / 100.0
        oldest_in_window = None
        for ts, mid in history:
            if now - ts <= window:
                oldest_in_window = (ts, mid)
                break
        if oldest_in_window is None:
            return False
        _, old_mid = oldest_in_window
        current_mid = history[-1][1]
        move = abs(current_mid - old_mid)
        if move >= move_threshold:
            cooldown_sec = settings.adverse_selection_cooldown_sec
            self._cooldowns[token_id] = now + cooldown_sec
            self._global_cooldown_until = now + min(5.0, cooldown_sec / 2)
            self._last_trigger_time[token_id] = now
            # v9.12 CRITICAL FIX: Clear price history so it doesn't re-trigger
            # on the same price move after global cooldown expires.
            self._price_history[token_id].clear()
            logger.warning(
                "[ADVERSE SELECTION] %s — moved %.2f¢ in %.0fs, cooldown %.0fs",
                token_id[:12], move * 100, window, cooldown_sec
            )
            return True
        return False

    def is_in_cooldown(self, token_id):
        if not settings.adverse_selection_enabled:
            return False
        if time.monotonic() < self._global_cooldown_until:
            return True
        cooldown_until = self._cooldowns.get(token_id, 0.0)
        if time.monotonic() < cooldown_until:
            return True
        if token_id in self._cooldowns and time.monotonic() >= cooldown_until:
            self._cooldowns.pop(token_id, None)
        return False

    def global_cooldown_remaining(self):
        remaining = self._global_cooldown_until - time.monotonic()
        return max(0.0, remaining)


class CorrelationDetector:
    CATEGORY_KEYWORDS = [
        "FIFA", "World Cup", "NBA", "NFL", "MLB", "NHL", "Soccer", "Football",
        "Basketball", "Tennis", "Election", "President", "Senate", "Congress",
        "Trump", "Biden", "Premier League", "Champions League", "UCL",
        "Mbappe", "Messi", "Ronaldo", "Anthropic", "OpenAI", "Google",
        "Bitcoin", "Ethereum", "Fed", "Rate", "CPI",
    ]

    def __init__(self):
        self._categories = defaultdict(list)

    def register_market(self, token_id, question):
        if not settings.correlation_aware_enabled:
            return
        if not question:
            return
        self.unregister_market(token_id)
        for keyword in self.CATEGORY_KEYWORDS:
            if keyword.lower() in question.lower():
                self._categories[keyword].append(token_id)

    def unregister_market(self, token_id):
        for keyword, tokens in list(self._categories.items()):
            if token_id in tokens:
                tokens.remove(token_id)
                if not tokens:
                    self._categories.pop(keyword, None)

    def get_category_exposure(self, token_id, inventory_by_token):
        if not settings.correlation_aware_enabled:
            return {}
        result = {}
        for keyword, tokens in self._categories.items():
            if token_id in tokens and len(tokens) >= settings.correlation_min_markets_in_category:
                total = sum(abs(inventory_by_token.get(t, 0)) for t in tokens)
                result[keyword] = total
        return result

    def is_category_saturated(self, token_id, inventory_by_token):
        if not settings.correlation_aware_enabled:
            return False
        exposures = self.get_category_exposure(token_id, inventory_by_token)
        for category, exposure in exposures.items():
            if exposure >= settings.correlation_max_per_category_usdc:
                return True
        return False


class SessionQuoting:
    @staticmethod
    def get_spread_multiplier():
        if not settings.session_quoting_enabled:
            return 1.0
        hour_utc = datetime.now(timezone.utc).hour
        active_start = settings.session_active_start_utc
        active_end = settings.session_active_end_utc
        if active_start <= hour_utc < active_end:
            return settings.session_active_spread_mult
        else:
            return settings.session_quiet_spread_mult

    @staticmethod
    def get_session_name():
        if not settings.session_quoting_enabled:
            return "normal"
        hour_utc = datetime.now(timezone.utc).hour
        active_start = settings.session_active_start_utc
        active_end = settings.session_active_end_utc
        if active_start <= hour_utc < active_end:
            return "active"
        if 0 <= hour_utc < 6:
            return "quiet"
        return "normal"


class GasEstimator:
    def __init__(self):
        self._cached_gas_usd = settings.fee_estimated_gas_usd
        self._last_update = 0.0

    def get_gas_usd(self):
        if not settings.fee_awareness_enabled:
            return 0.0
        if settings.paper_trading:
            return settings.fee_estimated_gas_usd
        now = time.monotonic()
        if now - self._last_update > 300:
            self._cached_gas_usd = settings.fee_estimated_gas_usd
            self._last_update = now
        return self._cached_gas_usd

    def min_profit_cents(self):
        if not settings.fee_awareness_enabled:
            return 0.0
        gas_cents = self.get_gas_usd() * 100
        return settings.fee_min_profit_cents + gas_cents
