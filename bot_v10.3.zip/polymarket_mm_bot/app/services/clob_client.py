"""
app/services/clob_client.py — Polymarket CLOB API client
═════════════════════════════════════════════════════════
Handles:
  - Market discovery (Gamma API)
  - Order book reading (CLOB REST + WS)
  - Order placement (POST /order with L2 HMAC auth)
  - Order cancellation (POST /order/cancel)
  - Order status polling (GET /order/{id})
"""
from __future__ import annotations

import asyncio
import base64
import hashlib
import hmac
import json
import logging
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

import aiohttp
import websockets

from app.core.config import settings

logger = logging.getLogger(__name__)


@dataclass
class OrderLevel:
    price: float
    size: float


@dataclass
class MarketBook:
    """Current order book for a token."""
    token_id: str
    bids: list[OrderLevel] = field(default_factory=list)
    asks: list[OrderLevel] = field(default_factory=list)
    last_price: float = 0.5
    last_update: float = field(default_factory=time.monotonic)

    @property
    def best_bid(self) -> float:
        return max((l.price for l in self.bids), default=0.0)

    @property
    def best_ask(self) -> float:
        return min((l.price for l in self.asks), default=1.0)

    @property
    def mid(self) -> float:
        if self.best_bid > 0 and self.best_ask < 1:
            return (self.best_bid + self.best_ask) / 2
        return self.last_price

    @property
    def spread(self) -> float:
        return self.best_ask - self.best_bid


@dataclass
class MarketInfo:
    """Static info about a market."""
    token_id: str
    condition_id: str
    question: str
    outcome: str  # "Yes" or "No"
    end_date_ts: float
    volume_24h: float


class ClobClient:
    """Polymarket CLOB API client with paper + live mode support."""

    def __init__(self) -> None:
        self.books: dict[str, MarketBook] = {}
        self.markets: dict[str, MarketInfo] = {}
        self._ws_task: asyncio.Task | None = None
        self._poll_task: asyncio.Task | None = None
        self._running = False
        self._subscribed: set[str] = set()
        self._last_ws_msg = time.monotonic()

    # ── Lifecycle ────────────────────────────────────────────────────────────

    async def start(self, token_ids: list[str]) -> None:
        """Start polling + WS for given token IDs."""
        self._running = True
        for tid in token_ids:
            self._subscribed.add(tid)
            self.books.setdefault(tid, MarketBook(token_id=tid))

        # Fetch market info + initial books
        await self._fetch_market_info(token_ids)
        await self._refresh_all_books()

        # Start background tasks
        self._ws_task = asyncio.create_task(self._ws_loop(), name="clob_ws")
        self._poll_task = asyncio.create_task(self._book_poll_loop(), name="clob_poll")
        logger.info("ClobClient started — %d markets", len(token_ids))

    async def stop(self) -> None:
        self._running = False
        for t in (self._ws_task, self._poll_task):
            if t:
                t.cancel()
                try:
                    await t
                except asyncio.CancelledError:
                    pass

    # ── Market discovery ─────────────────────────────────────────────────────

    async def discover_markets(self) -> list[MarketInfo]:
        """Find liquid markets via Gamma API with WIDER spreads.

        Filter criteria:
          - Active + not closed
          - Ends at least 1h from now
          - Volume 24h >= MIN_VOLUME_24H
          - Token price between 0.10 and 0.90
          - Market spread >= auto_pick_min_spread_cents (default 1.5¢)
          - Title matches ANY keyword from auto_pick_keywords
          - PREFERS markets with WIDER spread (more profit for MM)
        """
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    f"{settings.gamma_url}/events",
                    params={
                        "active": "true",
                        "closed": "false",
                        "limit": "500",  # increased from 200 to find more wide-spread markets
                        "order": "volume24hr",
                        "ascending": "false",
                    },
                    headers={"User-Agent": "PolyMMBot/1.0"},
                    timeout=aiohttp.ClientTimeout(total=20),
                ) as resp:
                    if resp.status != 200:
                        raise ValueError(f"Gamma API status {resp.status}")
                    data = await resp.json()
                events = data if isinstance(data, list) else data.get("data", [])

            now_ts = datetime.now(timezone.utc).timestamp()
            # Parse keywords — match ANY of them
            keywords = [k.strip().lower() for k in settings.auto_pick_keywords.split(",") if k.strip()]
            # EXCLUDE keywords — skip crypto/volatile markets even if they match
            exclude_keywords = ["bitcoin", "btc", "ethereum", "eth", "solana", "sol",
                                "crypto", "dogecoin", "xrp", "cardano", "polygon"]
            min_spread_dollars = settings.auto_pick_min_spread_cents / 100.0
            candidates: list[tuple[float, MarketInfo, float, float]] = []

            for event in events:
                title = (event.get("title", "") + " " + event.get("slug", "")).lower()
                # Match if ANY keyword is in the title
                if keywords and not any(kw in title for kw in keywords):
                    continue
                # EXCLUDE if any crypto keyword is in the title (safety filter)
                if any(ex in title for ex in exclude_keywords):
                    continue

                for m in event.get("markets") or []:
                    if not m.get("active", True) or m.get("closed", False):
                        continue
                    end_ts = self._parse_date(
                        m.get("endDate") or m.get("endDateIso") or ""
                    )
                    if end_ts < now_ts + 3600:
                        continue

                    raw_ids = m.get("clobTokenIds", "[]")
                    try:
                        token_ids = (
                            json.loads(raw_ids) if isinstance(raw_ids, str) else list(raw_ids)
                        )
                    except Exception:
                        continue

                    raw_outcomes = m.get("outcomes", "[]")
                    try:
                        outcomes = (
                            json.loads(raw_outcomes) if isinstance(raw_outcomes, str) else list(raw_outcomes)
                        )
                    except Exception:
                        outcomes = []

                    if len(token_ids) != len(outcomes):
                        continue

                    vol_24h = float(
                        m.get("volume24hr")
                        or m.get("volume24hrClob")
                        or m.get("volumeNum")
                        or 0
                    )
                    if vol_24h < settings.auto_pick_min_volume_24h:
                        continue

                    question = m.get("question", "")
                    condition_id = m.get("conditionId", "")

                    # Parse outcome prices
                    raw_prices = m.get("outcomePrices", "[]")
                    try:
                        prices = (
                            json.loads(raw_prices) if isinstance(raw_prices, str) else list(raw_prices)
                        )
                    except Exception:
                        prices = []

                    if len(prices) != len(token_ids):
                        continue

                    # Get bestBid/bestAsk from Gamma
                    best_bid = float(m.get("bestBid") or 0)
                    best_ask = float(m.get("bestAsk") or 0)
                    market_spread = best_ask - best_bid if best_bid > 0 and best_ask > 0 else 0

                    # ── FILTER: skip markets with tiny spread ─────────────────
                    if market_spread < min_spread_dollars:
                        continue  # skip this market — spread too small to profit

                    for tid, outcome, price_str in zip(token_ids, outcomes, prices):
                        try:
                            price = float(price_str)
                        except (TypeError, ValueError):
                            continue
                        # Skip markets that are already decided
                        if price < 0.10 or price > 0.90:
                            continue

                        info = MarketInfo(
                            token_id=str(tid),
                            condition_id=condition_id,
                            question=question,
                            outcome=str(outcome),
                            end_date_ts=end_ts,
                            volume_24h=vol_24h,
                        )
                        # Score = volume * uncertainty * spread_bonus
                        # Higher spread = higher score (prefer wide-spread markets)
                        uncertainty = 1.0 - abs(price - 0.5) * 2
                        spread_bonus = 1.0 + (market_spread * 50)  # 2¢ spread = 2x bonus
                        score = vol_24h * uncertainty * spread_bonus
                        candidates.append((score, info, price, market_spread))

            # Sort by score desc, take top N
            candidates.sort(key=lambda x: x[0], reverse=True)
            top = candidates[: settings.auto_pick_count]
            result = [info for _, info, _, _ in top]
            logger.info(
                "Discovered %d wide-spread markets (≥%.1f¢), picked top %d",
                len(candidates), settings.auto_pick_min_spread_cents, len(result)
            )
            for score, info, price, spread in top:
                logger.info(
                    "  → %s [%s] price=%.3f spread=%.1f¢ vol=$%.0f",
                    info.question[:55], info.outcome, price, spread * 100, info.volume_24h
                )

            # ── FALLBACK: if no wide-spread markets found, relax the filter ──
            if not result:
                logger.warning(
                    "No markets with spread ≥%.1f¢ found — relaxing to 0.8¢",
                    settings.auto_pick_min_spread_cents
                )
                # Re-scan with lower spread threshold (0.8¢, not 0¢)
                relaxed_min_spread = 0.008  # 0.8¢ minimum even in fallback
                # Re-scan with relaxed spread (0.8¢) but SAME exclude filter
                for event in events:
                    title = (event.get("title", "") + " " + event.get("slug", "")).lower()
                    if keywords and not any(kw in title for kw in keywords):
                        continue
                    # Still exclude crypto!
                    if any(ex in title for ex in exclude_keywords):
                        continue
                    for m in event.get("markets") or []:
                        if not m.get("active", True) or m.get("closed", False):
                            continue
                        end_ts = self._parse_date(m.get("endDate") or m.get("endDateIso") or "")
                        if end_ts < now_ts + 3600:
                            continue
                        raw_ids = m.get("clobTokenIds", "[]")
                        try:
                            token_ids = json.loads(raw_ids) if isinstance(raw_ids, str) else list(raw_ids)
                        except Exception:
                            continue
                        raw_outcomes = m.get("outcomes", "[]")
                        try:
                            outcomes = json.loads(raw_outcomes) if isinstance(raw_outcomes, str) else list(raw_outcomes)
                        except Exception:
                            outcomes = []
                        if len(token_ids) != len(outcomes):
                            continue
                        vol_24h = float(m.get("volume24hr") or m.get("volume24hrClob") or m.get("volumeNum") or 0)
                        if vol_24h < settings.auto_pick_min_volume_24h:
                            continue
                        raw_prices = m.get("outcomePrices", "[]")
                        try:
                            prices = json.loads(raw_prices) if isinstance(raw_prices, str) else list(raw_prices)
                        except Exception:
                            prices = []
                        if len(prices) != len(token_ids):
                            continue
                        best_bid = float(m.get("bestBid") or 0)
                        best_ask = float(m.get("bestAsk") or 0)
                        market_spread = best_ask - best_bid if best_bid > 0 and best_ask > 0 else 0
                        # In fallback: accept spread ≥ 0.8¢ (not 0¢)
                        if market_spread < relaxed_min_spread:
                            continue
                        question = m.get("question", "")
                        condition_id = m.get("conditionId", "")
                        for tid, outcome, price_str in zip(token_ids, outcomes, prices):
                            try:
                                price = float(price_str)
                            except (TypeError, ValueError):
                                continue
                            if price < 0.10 or price > 0.90:
                                continue
                            info = MarketInfo(
                                token_id=str(tid), condition_id=condition_id,
                                question=question, outcome=str(outcome),
                                end_date_ts=end_ts, volume_24h=vol_24h,
                            )
                            uncertainty = 1.0 - abs(price - 0.5) * 2
                            spread_bonus = 1.0 + (market_spread * 50)
                            score = vol_24h * uncertainty * spread_bonus
                            candidates.append((score, info, price, market_spread))

                candidates.sort(key=lambda x: x[0], reverse=True)
                top = candidates[: settings.auto_pick_count]
                result = [info for _, info, _, _ in top]
                logger.info(
                    "Fallback: picked %d markets (any spread)",
                    len(result)
                )
                for score, info, price, spread in top:
                    logger.info(
                        "  → %s [%s] price=%.3f spread=%.1f¢ vol=$%.0f",
                        info.question[:55], info.outcome, price, spread * 100, info.volume_24h
                    )

            return result

        except Exception as e:
            logger.error("Market discovery failed: %s", e)
            return []

    async def _fetch_market_info(self, token_ids: list[str]) -> None:
        """Populate self.markets for given token IDs.

        Tries 2 methods:
        1. Gamma /events API (batch)
        2. Direct CLOB /markets/{token_id} API (per-token fallback)
        """
        if not token_ids:
            return

        # Method 1: Gamma events API (batch)
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    f"{settings.gamma_url}/events",
                    params={"active": "true", "closed": "false", "limit": "500"},
                    headers={"User-Agent": "PolyMMBot/1.0"},
                    timeout=aiohttp.ClientTimeout(total=15),
                ) as resp:
                    if resp.status == 200:
                        events = await resp.json()
                        if isinstance(events, dict):
                            events = events.get("data", [])

                        tid_set = set(str(t) for t in token_ids)
                        for event in events:
                            for m in event.get("markets") or []:
                                raw_ids = m.get("clobTokenIds", "[]")
                                try:
                                    ids = json.loads(raw_ids) if isinstance(raw_ids, str) else list(raw_ids)
                                except Exception:
                                    continue
                                raw_outcomes = m.get("outcomes", "[]")
                                try:
                                    outcomes = json.loads(raw_outcomes) if isinstance(raw_outcomes, str) else list(raw_outcomes)
                                except Exception:
                                    outcomes = []
                                for tid, outcome in zip(ids, outcomes):
                                    if str(tid) in tid_set:
                                        end_ts = self._parse_date(m.get("endDate") or m.get("endDateIso") or "")
                                        self.markets[str(tid)] = MarketInfo(
                                            token_id=str(tid),
                                            condition_id=m.get("conditionId", ""),
                                            question=m.get("question", ""),
                                            outcome=str(outcome),
                                            end_date_ts=end_ts,
                                            volume_24h=float(m.get("volume24hr") or 0),
                                        )
        except Exception as e:
            logger.debug("Market info fetch (gamma) failed: %s", e)

        # Method 2: Direct CLOB API per-token for any still missing
        still_missing = [t for t in token_ids if t not in self.markets or not self.markets.get(t, MarketInfo("", "", "", "", 0, 0)).question]
        if still_missing:
            logger.info("Fetching info for %d unknown markets via CLOB API", len(still_missing))
            async with aiohttp.ClientSession() as session:
                for tid in still_missing:
                    try:
                        async with session.get(
                            f"{settings.clob_base_url}/markets/{tid}",
                            headers={"User-Agent": "PolyMMBot/1.0"},
                            timeout=aiohttp.ClientTimeout(total=5),
                        ) as resp:
                            if resp.status == 200:
                                m = await resp.json()
                                question = m.get("question", "")
                                if question:
                                    end_ts = self._parse_date(m.get("end_date_iso") or m.get("endDate") or "")
                                    outcomes_raw = m.get("outcomes", "[]")
                                    try:
                                        outcomes = json.loads(outcomes_raw) if isinstance(outcomes_raw, str) else list(outcomes_raw)
                                    except Exception:
                                        outcomes = []

                                    # Find which outcome this token is
                                    token_outcome = ""
                                    tokens_raw = m.get("clob_token_ids", m.get("clobTokenIds", "[]"))
                                    try:
                                        token_ids_list = json.loads(tokens_raw) if isinstance(tokens_raw, str) else list(tokens_raw)
                                        for i, t in enumerate(token_ids_list):
                                            if str(t) == str(tid) and i < len(outcomes):
                                                token_outcome = str(outcomes[i])
                                    except Exception:
                                        pass

                                    self.markets[str(tid)] = MarketInfo(
                                        token_id=str(tid),
                                        condition_id=m.get("condition_id", m.get("conditionId", "")),
                                        question=question,
                                        outcome=token_outcome,
                                        end_date_ts=end_ts,
                                        volume_24h=float(m.get("volume24hr") or 0),
                                    )
                                    logger.info("  Fixed: %s → %s [%s]", tid[:12], question[:50], token_outcome)
                    except Exception:
                        pass

    # ── Book polling (REST fallback for WS) ───────────────────────────────────

    async def _book_poll_loop(self) -> None:
        await asyncio.sleep(2)
        while self._running:
            try:
                await self._refresh_all_books()
            except Exception as e:
                logger.debug("Book poll error: %s", e)
            await asyncio.sleep(3)

    async def _refresh_all_books(self) -> None:
        tids = list(self._subscribed)
        if not tids:
            return
        async with aiohttp.ClientSession() as session:
            tasks = [self._fetch_book(session, tid) for tid in tids]
            await asyncio.gather(*tasks, return_exceptions=True)

    async def _fetch_book(self, session: aiohttp.ClientSession, tid: str) -> None:
        try:
            async with session.get(
                f"{settings.clob_base_url}/book",
                params={"token_id": tid},
                timeout=aiohttp.ClientTimeout(total=5),
            ) as resp:
                if resp.status == 200:
                    book_data = await resp.json()
                    self._apply_book(tid, book_data)
        except Exception:
            pass

    def _apply_book(self, tid: str, data: dict) -> None:
        book = self.books.get(tid)
        if not book:
            book = MarketBook(token_id=tid)
            self.books[tid] = book

        def parse(raw: list) -> list[OrderLevel]:
            out = []
            for item in raw:
                try:
                    p = float(item.get("price", 0))
                    s = float(item.get("size", 0))
                    if p > 0 and s > 0:
                        out.append(OrderLevel(p, s))
                except (TypeError, ValueError):
                    pass
            return out

        bids = sorted(parse(data.get("bids", [])), key=lambda x: x.price, reverse=True)
        asks = sorted(parse(data.get("asks", [])), key=lambda x: x.price)

        if bids:
            book.bids = bids
        if asks:
            book.asks = asks
        if bids and asks:
            book.last_price = (bids[0].price + asks[0].price) / 2
        book.last_update = time.monotonic()
        self._last_ws_msg = time.monotonic()

    # ── WebSocket ────────────────────────────────────────────────────────────

    async def _ws_loop(self) -> None:
        """WS loop with aggressive reconnect on failure."""
        reconnect_delay = 3  # start at 3s, grow to max 30s
        while self._running:
            try:
                await self._ws_connect()
                reconnect_delay = 3  # reset on clean disconnect
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.warning("WS error: %s — retry in %ds", e, reconnect_delay)
                # Try REST price refresh while WS is down
                try:
                    await self._refresh_all_books()
                    logger.info("REST fallback: refreshed books while WS down")
                except Exception:
                    pass
                await asyncio.sleep(reconnect_delay)
                reconnect_delay = min(30, reconnect_delay * 2)  # exponential backoff

    async def _ws_connect(self) -> None:
        async with websockets.connect(
            settings.ws_url, ping_interval=15, ping_timeout=10, close_timeout=3
        ) as ws:
            sub = {
                "auth": {},
                "type": "Market",
                "assets_ids": list(self._subscribed),
            }
            await ws.send(json.dumps(sub))
            logger.info("WS connected — %d markets", len(self._subscribed))
            self._last_ws_msg = time.monotonic()
            async for raw in ws:
                try:
                    msgs = json.loads(raw)
                    for msg in (msgs if isinstance(msgs, list) else [msgs]):
                        self._process_ws_event(msg)
                except Exception as e:
                    logger.debug("WS parse error: %s", e)
                self._last_ws_msg = time.monotonic()

    def _process_ws_event(self, event: dict) -> None:
        etype = event.get("event_type", "")
        asset_id = event.get("asset_id", "")
        book = self.books.get(asset_id)
        if not book:
            return

        if etype == "price_change":
            price = float(event.get("price", 0))
            side = event.get("side", "")
            size = float(event.get("size", 0))
            if side == "BUY":
                # Update bids
                book.bids = [OrderLevel(price, size)] + [
                    l for l in book.bids if abs(l.price - price) > 1e-6
                ]
                book.bids = sorted(book.bids, key=lambda x: x.price, reverse=True)[:20]
            elif side == "SELL":
                book.asks = [OrderLevel(price, size)] + [
                    l for l in book.asks if abs(l.price - price) > 1e-6
                ]
                book.asks = sorted(book.asks, key=lambda x: x.price)[:20]
            if book.bids and book.asks:
                book.last_price = (book.best_bid + book.best_ask) / 2
        elif etype == "book":
            self._apply_book(asset_id, {
                "bids": event.get("bids", []),
                "asks": event.get("asks", []),
            })
        elif etype == "trade":
            price = float(event.get("price", book.last_price))
            book.last_price = price

    # ── Order placement ───────────────────────────────────────────────────────

    async def place_order(
        self,
        token_id: str,
        side: str,           # "BUY" or "SELL"
        price: float,
        size_usdc: float,
    ) -> dict | None:
        """Place an order. Returns API response or None on failure."""
        if settings.paper_trading:
            # In paper mode, simulate immediate fill
            return {
                "status": "MATCHED",
                "orderID": f"PAPER-{int(time.time()*1000)}",
                "price": str(price),
                "size": str(size_usdc / price),
                "side": side,
            }

        try:
            order = self._build_order(token_id, side, price, size_usdc)
            signed = self._sign_order(order)
            headers = self._auth_headers()

            async with aiohttp.ClientSession() as session:
                async with session.post(
                    f"{settings.clob_base_url}/order",
                    json=signed,
                    headers=headers,
                    timeout=aiohttp.ClientTimeout(total=8),
                ) as resp:
                    body = await resp.json()

            if resp.status not in (200, 201):
                logger.error("Order rejected %d: %s", resp.status, body)
                return None
            return body

        except Exception as e:
            logger.exception("Order placement failed: %s", e)
            return None

    async def cancel_order(self, order_id: str) -> bool:
        if settings.paper_trading or order_id.startswith("PAPER-"):
            return True
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    f"{settings.clob_base_url}/order/cancel",
                    json={"orderID": order_id},
                    headers=self._auth_headers(),
                    timeout=aiohttp.ClientTimeout(total=5),
                ) as resp:
                    return resp.status in (200, 204)
        except Exception as e:
            logger.warning("Cancel failed: %s", e)
            return False

    # ── Auth & signing ───────────────────────────────────────────────────────

    def _auth_headers(self) -> dict:
        if settings.clob_api_key and settings.clob_api_secret and settings.clob_api_passphrase:
            return self._l2_auth_headers()
        if not settings.polygon_private_key:
            return {}
        try:
            from eth_account import Account
            from eth_account.messages import encode_defunct
            ts = str(int(time.time()))
            msg = encode_defunct(text=ts)
            acc = Account.from_key(settings.polygon_private_key)
            sig = acc.sign_message(msg)
            return {
                "POLY_ADDRESS": settings.polygon_wallet_address,
                "POLY_SIGNATURE": sig.signature.hex(),
                "POLY_TIMESTAMP": ts,
                "POLY_NONCE": "0",
            }
        except Exception as e:
            logger.warning("Auth failed: %s", e)
            return {}

    def _l2_auth_headers(self) -> dict:
        try:
            try:
                secret_bytes = base64.urlsafe_b64decode(settings.clob_api_secret)
            except Exception:
                secret_bytes = settings.clob_api_secret.encode("utf-8")
            ts = str(int(time.time()))
            message = ts + "POST" + "/order"
            signature = base64.urlsafe_b64encode(
                hmac.new(secret_bytes, message.encode("utf-8"), hashlib.sha256).digest()
            ).decode("utf-8")
            return {
                "POLY_ADDRESS": settings.polygon_wallet_address,
                "POLY_SIGNATURE": signature,
                "POLY_TIMESTAMP": ts,
                "POLY_API_KEY": settings.clob_api_key,
                "POLY_PASSPHRASE": settings.clob_api_passphrase,
                "POLY_NONCE": "0",
            }
        except Exception as e:
            logger.warning("L2 auth failed: %s", e)
            return {}

    def _build_order(self, token_id: str, side: str, price: float, size_usdc: float) -> dict:
        return {
            "tokenID": token_id,
            "side": side,
            "price": str(round(price, 4)),
            "size": str(round(size_usdc / max(price, 0.01), 2)),
            "orderType": "GTC",
            "nonce": str(int(time.time() * 1000)),
            "maker": settings.polygon_wallet_address,
            "signer": settings.polygon_wallet_address,
            "expiration": "0",
        }

    def _sign_order(self, order: dict) -> dict:
        if not settings.polygon_private_key:
            return order
        from eth_account import Account
        acc = Account.from_key(settings.polygon_private_key)
        # Simplified — real implementation needs proper EIP-712 domain/types
        # per Polymarket CTF Exchange spec
        return {**order, "signature": "", "signatureType": 0}

    # ── Helpers ───────────────────────────────────────────────────────────────

    @staticmethod
    def _parse_date(date_str: str) -> float:
        if not date_str:
            return 0.0
        try:
            for fmt in ("%Y-%m-%dT%H:%M:%SZ", "%Y-%m-%dT%H:%M:%S.%fZ"):
                try:
                    dt = datetime.strptime(date_str[:26], fmt[:len(date_str)])
                    return dt.replace(tzinfo=timezone.utc).timestamp()
                except ValueError:
                    continue
            return datetime.fromisoformat(date_str.replace("Z", "+00:00")).timestamp()
        except Exception:
            return 0.0
