"""
app/services/market_maker.py — v3.2 LIVE-READY
═══════════════════════════════════════════════
Market maker engine with PAPER + LIVE mode support.

PAPER mode: simulates fills locally (for testing)
LIVE mode: places real orders on Polymarket CLOB API
"""
from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field

from app.core.config import settings
from app.db.models import Quote, QuoteStatus, Side, Trade
from app.services.clob_client import ClobClient, MarketBook, MarketInfo
from app.services.inventory_manager import InventoryManager

logger = logging.getLogger(__name__)


@dataclass
class ActiveQuote:
    """Tracks our currently-placed quote for a market."""
    token_id: str
    bid_price: float
    ask_price: float
    mid_at_place: float
    size_usdc: float
    placed_at: float = field(default_factory=time.monotonic)
    bid_filled: bool = False
    ask_filled: bool = False
    bid_order_id: str | None = None  # live order ID for bid
    ask_order_id: str | None = None  # live order ID for ask
    last_bid_check_mid: float = 0.0
    last_ask_check_mid: float = 0.0


class MarketMaker:
    """Main MM engine. Runs a requote loop."""

    def __init__(
        self,
        clob: ClobClient,
        inventory: InventoryManager,
    ) -> None:
        self.clob = clob
        self.inventory = inventory
        self.active_quotes: dict[str, ActiveQuote] = {}
        self._task: asyncio.Task | None = None
        self._running = False
        self._cycle_count = 0
        self._fill_count = 0

        # ── Trading state: bot starts PAUSED, user must click "Start" ──
        self._trading_paused = True  # Start paused — user clicks Start to begin

        # Volatility tracking per market
        self._price_history: dict[str, list[float]] = {}

        # Live mode: track pending orders for polling
        self._pending_orders: dict[str, dict] = {}  # order_id → {token_id, side, price, size, placed_at}

    # ── Lifecycle ────────────────────────────────────────────────────────────

    async def start(self) -> None:
        self._running = True
        self._task = asyncio.create_task(self._requote_loop(), name="mm_loop")

        # DB cleanup task — removes old quotes/snapshots every 10 min
        asyncio.create_task(self._db_cleanup_loop(), name="db_cleanup")

        # In live mode, also start order polling
        if not settings.paper_trading:
            asyncio.create_task(self._poll_orders_loop(), name="mm_poll")

        logger.info(
            "MarketMaker started — %s mode, interval %.1fs",
            "LIVE" if not settings.paper_trading else "PAPER",
            settings.requote_interval_sec
        )

    async def stop(self) -> None:
        self._running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        # Cancel all active quotes on shutdown
        for tid in list(self.active_quotes.keys()):
            await self._cancel_quote(tid)

    # ── DB cleanup — prevent DB from growing unbounded ────────────────────────

    async def _db_cleanup_loop(self) -> None:
        """Every 10 minutes, delete old quotes and snapshots.

        Without this, mm_bot.db grows by ~700MB/24h at 1s interval with 8 markets.
        We keep only last 1000 quotes and 1000 snapshots for charts.
        Trades are NEVER deleted (they're the P&L history).
        """
        await asyncio.sleep(600)  # first cleanup after 10 min
        while self._running:
            try:
                from app.core.db import AsyncSessionLocal
                from sqlalchemy import text
                async with AsyncSessionLocal() as db:
                    # Delete old quotes (keep last 1000)
                    await db.execute(text(
                        "DELETE FROM mm_quotes WHERE id NOT IN "
                        "(SELECT id FROM mm_quotes ORDER BY id DESC LIMIT 1000)"
                    ))
                    # Delete old snapshots (keep last 1000)
                    await db.execute(text(
                        "DELETE FROM mm_snapshots WHERE id NOT IN "
                        "(SELECT id FROM mm_snapshots ORDER BY id DESC LIMIT 1000)"
                    ))
                    await db.commit()
                    logger.debug("DB cleanup: removed old quotes/snapshots")
            except Exception as e:
                logger.debug("DB cleanup error: %s", e)
            await asyncio.sleep(600)  # every 10 min

    # ── Start/Stop trading (user-controlled) ──────────────────────────────────

    def start_trading(self) -> None:
        """User clicked 'Start Trading' — begin quoting."""
        self._trading_paused = False
        if self.inventory.halted and self.inventory.halt_reason == "Paused by user":
            self.inventory.resume()
        logger.info("▶ Trading STARTED by user")

    def stop_trading(self) -> None:
        """User clicked 'Pause' — stop quoting immediately (no waiting)."""
        self._trading_paused = True
        # Cancel all quotes immediately
        for tid in list(self.active_quotes.keys()):
            asyncio.create_task(self._cancel_quote(tid))
        logger.info("⏸ Trading PAUSED by user — all quotes canceled")

    @property
    def is_trading(self) -> bool:
        return not self._trading_paused and not self.inventory.halted

    # ── Main loop ────────────────────────────────────────────────────────────

    async def _requote_loop(self) -> None:
        while self._running:
            try:
                # If trading is paused, just sleep and skip
                if self._trading_paused:
                    await asyncio.sleep(settings.requote_interval_sec)
                    continue

                # If halted (by risk/stale), cancel quotes and wait
                if self.inventory.halted:
                    for tid in list(self.active_quotes.keys()):
                        await self._cancel_quote(tid)
                    await asyncio.sleep(settings.requote_interval_sec)
                    continue

                await self._cycle()
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.exception("MM cycle error: %s", e)
            await asyncio.sleep(settings.requote_interval_sec)

    async def _cycle(self) -> None:
        self._cycle_count += 1

        # ── AUTO-REFILL MARKETS ───────────────────────────────────────────
        # If markets dropped below user-set count (due to quality filter),
        # find new ones. v9.13: Respect user's auto_pick_count setting,
        # don't override to 6.
        current_markets = len(self.clob.books)
        target_count = settings.auto_pick_count
        if current_markets < min(target_count, 3) and self._cycle_count % 30 == 0:
            logger.info(
                "Only %d markets left (target %d) — auto-discovering new ones",
                current_markets, target_count
            )
            try:
                # v9.13: Use user's auto_pick_count, don't override to 6
                # Just discover enough to fill back to target
                old_count = settings.auto_pick_count
                settings.auto_pick_count = max(1, target_count - current_markets)
                new_markets = await self.clob.discover_markets()
                settings.auto_pick_count = old_count

                added = 0
                for info in new_markets:
                    if info.token_id not in self.clob.books:
                        from app.services.clob_client import MarketBook
                        self.clob.books[info.token_id] = MarketBook(token_id=info.token_id)
                        self.clob.markets[info.token_id] = info
                        self.clob._subscribed.add(info.token_id)
                        added += 1
                if added > 0:
                    await self.clob._refresh_all_books()
                    logger.info("Auto-refill: added %d new markets", added)
            except Exception as e:
                logger.debug("Auto-refill error: %s", e)

        # ── LIVE SAFETY CHECKS ─────────────────────────────────────────────
        if not settings.paper_trading:
            # Check if bot is halted
            if self.inventory.halted:
                for tid in list(self.active_quotes.keys()):
                    await self._cancel_quote(tid)
                return

            # Check minimum balance (stop if < $5)
            if self.inventory.bankroll < 5.0:
                self.inventory.halt("balance below $5 — emergency stop")
                for tid in list(self.active_quotes.keys()):
                    await self._cancel_quote(tid)
                logger.critical("EMERGENCY STOP: balance below $5")
                return

        if self.inventory.halted:
            for tid in list(self.active_quotes.keys()):
                await self._cancel_quote(tid)
            return

        # ── STALE DATA PROTECTION ─────────────────────────────────────────
        # If WebSocket hasn't received data in 30s, STOP quoting.
        # This prevents trading on stale prices when internet drops.
        import time as _time
        ws_age = _time.monotonic() - self.clob._last_ws_msg
        if ws_age > 30:
            if not self.inventory.halted:
                logger.warning(
                    "STALE DATA: WS silent for %.0fs — canceling all quotes & pausing",
                    ws_age
                )
                self.inventory.halt(f"Stale data — WS silent {ws_age:.0f}s (internet down?)")
                for tid in list(self.active_quotes.keys()):
                    await self._cancel_quote(tid)
            return

        # If WS is back online after being stale, auto-resume
        if ws_age < 10 and self.inventory.halted and "Stale data" in (self.inventory.halt_reason or ""):
            self.inventory.resume()
            logger.info("WS recovered — resuming trading")

        for tid, book in list(self.clob.books.items()):
            # ── REAL-TIME MARKET QUALITY FILTER ─────────────────────────────
            # Remove markets that went bad since discovery:
            #   1. Spread dropped below 0.8¢ (too tight)
            #   2. Volume = $0 (dead market, no trades possible)
            #   3. No market info at all (info is None)
            #   4. Still "Unknown" name after 60s (can't get info)
            should_remove = False
            remove_reason = ""

            if book.bids and book.asks:
                current_spread_cents = book.spread * 100
                # v9.16: Skip markets with spread < 2.0¢
                # 1¢ spread barely covers gas, can't profit
                if current_spread_cents < 2.0:
                    # Don't REMOVE (caused infinite refill loop before) — just SKIP quoting
                    if tid in self.active_quotes:
                        await self._cancel_quote(tid)
                    continue

            info = self.clob.markets.get(tid)

            # No info at all → remove after 30 cycles (30s)
            if not info and self._cycle_count > 30:
                should_remove = True
                remove_reason = "no market info"

            # Has info but zero volume → remove after 30 cycles
            if info and info.volume_24h == 0 and self._cycle_count > 30:
                should_remove = True
                remove_reason = "zero volume"

            # Has info but no name → remove after 30 cycles
            if info and not info.question and self._cycle_count > 30:
                should_remove = True
                remove_reason = "unknown name"

            if should_remove:
                logger.info(
                    "[MARKET REMOVED] %s — %s",
                    tid[:12], remove_reason
                )
                if tid in self.active_quotes:
                    await self._cancel_quote(tid)
                self.clob.books.pop(tid, None)
                self.clob.markets.pop(tid, None)
                self.clob._subscribed.discard(tid)
                continue

            await self._process_market(tid, book)

    async def _process_market(self, token_id: str, book: MarketBook) -> None:
        """Update quotes for one market."""
        if not book.bids or not book.asks:
            return

        info = self.clob.markets.get(token_id)
        market_name = info.question[:60] if info else token_id[:12]

        # ── PRE-RESOLUTION EXIT ───────────────────────────────────────────
        # Stop quoting 3 hours before market ends (sports games, elections, etc.)
        # This prevents losses from sudden price swings near resolution.
        if info:
            from datetime import datetime, timezone
            now_ts = datetime.now(timezone.utc).timestamp()
            time_to_resolution = info.end_date_ts - now_ts

            if time_to_resolution < settings.pre_resolution_exit_sec:
                # Market is closing soon — cancel quotes & liquidate
                if token_id in self.active_quotes:
                    logger.warning(
                        "[PRE-RESOLUTION EXIT] %s — TTR=%.1fh, canceling quotes",
                        market_name[:40], time_to_resolution / 3600
                    )
                    await self._cancel_quote(token_id)

                # Try to liquidate inventory at market price
                inv = self.inventory.get_inventory(token_id)
                if abs(inv.net_tokens) > 0.5:
                    mid = book.mid
                    if inv.net_tokens > 0:
                        # Long → sell at bid (take what we can)
                        sell_price = book.best_bid
                        if sell_price > 0:
                            await self._record_fill(
                                token_id, "SELL", sell_price,
                                abs(inv.net_tokens) * sell_price, market_name
                            )
                            logger.warning(
                                "[LIQUIDATE] %s — sold %d tokens @ %.4f (pre-resolution)",
                                market_name[:30], abs(inv.net_tokens), sell_price
                            )
                    elif inv.net_tokens < 0:
                        # Short → buy at ask
                        buy_price = book.best_ask
                        if buy_price < 1:
                            await self._record_fill(
                                token_id, "BUY", buy_price,
                                abs(inv.net_tokens) * buy_price, market_name
                            )
                            logger.warning(
                                "[LIQUIDATE] %s — bought %d tokens @ %.4f (pre-resolution)",
                                market_name[:30], abs(inv.net_tokens), buy_price
                            )
                return  # Don't place new quotes on this market

        # ── Step 1: check for fills on existing quotes ───────────────────────
        existing = self.active_quotes.get(token_id)
        if existing:
            await self._check_fills(token_id, book, existing, market_name)
            existing = self.active_quotes.get(token_id)

        # ── Step 2: cancel if mid moved too much OR quote is getting old ──
        if existing:
            mid_drift = abs(book.mid - existing.mid_at_place)
            age = time.monotonic() - existing.placed_at
            if mid_drift > settings.requote_threshold_cents / 100 or age > 10:
                await self._cancel_quote(token_id)
                existing = None

        # ── Step 3: if no active quote, place a new one ──────────────────────
        if not existing:
            our_spread_cents = self._compute_spread(token_id, book)
            our_spread_dollars = our_spread_cents / 100.0

            skew_cents = self.inventory.quote_skew(token_id)
            skew_dollars = skew_cents / 100.0

            # ── COMPETITIVE QUOTING (always at or inside market) ───────────
            market_bid = book.best_bid
            market_ask = book.best_ask
            market_spread = market_ask - market_bid
            market_mid = (market_bid + market_ask) / 2

            # ALWAYS quote INSIDE the market spread
            if market_spread >= 0.002:  # at least 0.2¢ spread
                capture = 0.20  # 20% inside each side
                target_bid = market_bid + market_spread * capture + skew_dollars
                target_ask = market_ask - market_spread * capture + skew_dollars
            else:
                target_bid = market_bid + 0.0003 + skew_dollars
                target_ask = market_ask - 0.0003 + skew_dollars

            # ── SAFETY: ensure bid < ask AND inside market ──────────────────
            if target_bid >= target_ask:
                target_bid = market_bid + market_spread * 0.1
                target_ask = market_ask - market_spread * 0.1

            if target_bid >= market_ask:
                target_bid = market_mid - 0.001
            if target_ask <= market_bid:
                target_ask = market_mid + 0.001

            # Clamp to valid range
            target_bid = max(0.01, min(0.99, target_bid))
            target_ask = max(0.01, min(0.99, target_ask))

            # ── Inventory-based quoting ─────────────────────────────────────
            quote_bid = self.inventory.should_quote_bid(token_id)
            quote_ask = self.inventory.should_quote_ask(token_id)

            if not quote_bid and not quote_ask:
                return

            # ── AUTO-SCALING order size (capped at 1.5x for safety) ─────────
            # Compound growth: as bankroll grows, size grows proportionally
            # But cap at 1.5x base to prevent over-concentration
            bankroll = self.inventory.bankroll
            base_size = settings.order_size_usdc
            scaling = min(1.5, bankroll / settings.paper_balance_usdc)
            size = base_size * scaling
            size = max(settings.order_size_min_usdc, min(size, base_size * 1.5))

            await self._place_quote(
                token_id=token_id,
                bid_price=target_bid if quote_bid else None,
                ask_price=target_ask if quote_ask else None,
                size_usdc=size,
                mid=market_mid,
                market_name=market_name,
            )

    # ── Spread computation ───────────────────────────────────────────────────

    # ── Market movement tracking for adverse fills ────────────────────────────

    def _get_market_direction(self, token_id: str) -> float:
        """Estimate short-term market direction (-1 to +1).

        Returns a directional bias based on recent price history.
        +1 = price rising (buyers aggressive), -1 = price falling (sellers aggressive).
        Used to make our fills more realistic: when market is falling, our bid fills
        but our ask doesn't (and vice versa).
        """
        history = self._price_history.get(token_id, [])
        if len(history) < 5:
            return 0.0
        # Compare last price to average of 5 periods ago
        recent = history[-1]
        past = history[-5]
        if past == 0:
            return 0.0
        change = (recent - past) / past
        # Clamp to -1..1
        return max(-1.0, min(1.0, change * 50))  # scale up sensitivity

    # ── Spread computation ───────────────────────────────────────────────────

    def _compute_spread(self, token_id: str, book: MarketBook) -> float:
        """Dynamic spread based on volatility."""
        history = self._price_history.setdefault(token_id, [])
        history.append(book.mid)
        if len(history) > 60:
            history.pop(0)

        spread = settings.spread_cents

        if len(history) >= 10:
            recent = history[-10:]
            price_range = max(recent) - min(recent)
            if price_range > 0.02:
                vol_mult = 1.0 + (price_range * settings.spread_volatility_mult)
                spread = settings.spread_cents * vol_mult

        spread = max(settings.spread_min_cents, min(settings.spread_max_cents, spread))
        return spread

    # ── Quote placement ──────────────────────────────────────────────────────

    async def _place_quote(
        self,
        token_id: str,
        bid_price: float | None,
        ask_price: float | None,
        size_usdc: float,
        mid: float,
        market_name: str,
    ) -> None:
        """Place bid and/or ask orders. PAPER = simulate, LIVE = real orders."""
        if bid_price is None and ask_price is None:
            return

        bid_order_id = None
        ask_order_id = None

        # ── LIVE MODE: place real orders ──────────────────────────────────
        if not settings.paper_trading:
            if bid_price is not None:
                result = await self.clob.place_order(token_id, "BUY", bid_price, size_usdc)
                if result:
                    bid_order_id = result.get("orderID") or result.get("id", "")
                    self._pending_orders[bid_order_id] = {
                        "token_id": token_id,
                        "side": "BUY",
                        "price": bid_price,
                        "size_usdc": size_usdc,
                        "market_name": market_name,
                        "placed_at": time.monotonic(),
                    }
                    logger.info("[LIVE ORDER] BUY %s @ %.4f size=$%.2f order=%s",
                               market_name[:30], bid_price, size_usdc, bid_order_id)
                else:
                    logger.warning("[LIVE ORDER FAILED] BUY %s", market_name[:30])

            if ask_price is not None:
                result = await self.clob.place_order(token_id, "SELL", ask_price, size_usdc)
                if result:
                    ask_order_id = result.get("orderID") or result.get("id", "")
                    self._pending_orders[ask_order_id] = {
                        "token_id": token_id,
                        "side": "SELL",
                        "price": ask_price,
                        "size_usdc": size_usdc,
                        "market_name": market_name,
                        "placed_at": time.monotonic(),
                    }
                    logger.info("[LIVE ORDER] SELL %s @ %.4f size=$%.2f order=%s",
                               market_name[:30], ask_price, size_usdc, ask_order_id)
                else:
                    logger.warning("[LIVE ORDER FAILED] SELL %s", market_name[:30])

        # Track active quote
        self.active_quotes[token_id] = ActiveQuote(
            token_id=token_id,
            bid_price=bid_price or 0.0,
            ask_price=ask_price or 1.0,
            mid_at_place=mid,
            size_usdc=size_usdc,
            bid_order_id=bid_order_id,
            ask_order_id=ask_order_id,
        )

        logger.info(
            "[QUOTE] %s | bid=%s ask=%s mid=%.4f spread=%.3f size=$%.0f",
            market_name,
            f"{bid_price:.4f}" if bid_price else "—",
            f"{ask_price:.4f}" if ask_price else "—",
            mid,
            (ask_price - bid_price) if bid_price and ask_price else 0,
            size_usdc,
        )

        # NOTE: Don't persist every quote to DB — causes massive DB growth
        # (8 markets × 1s = 691k records/24h). Only persist fills (trades).
        # await self._persist_quote(token_id, bid_price, ask_price, mid, size_usdc)

    async def _cancel_quote(self, token_id: str) -> None:
        existing = self.active_quotes.pop(token_id, None)
        if not existing:
            return

        # ── LIVE MODE: cancel real orders ─────────────────────────────────
        if not settings.paper_trading:
            if existing.bid_order_id:
                await self.clob.cancel_order(existing.bid_order_id)
                self._pending_orders.pop(existing.bid_order_id, None)
            if existing.ask_order_id:
                await self.clob.cancel_order(existing.ask_order_id)
                self._pending_orders.pop(existing.ask_order_id, None)

        logger.debug("[CANCEL] %s quotes", token_id[:12])

    def _needs_requote(self, existing: ActiveQuote, target_bid: float, target_ask: float) -> bool:
        bid_diff = abs(existing.bid_price - target_bid) if existing.bid_price else 0
        ask_diff = abs(existing.ask_price - target_ask) if existing.ask_price else 0
        threshold = settings.requote_threshold_cents / 100
        return bid_diff > threshold or ask_diff > threshold

    # ── LIVE MODE: Order polling ──────────────────────────────────────────────

    async def _poll_orders_loop(self) -> None:
        """In LIVE mode: poll order status to detect fills."""
        await asyncio.sleep(5)
        while self._running:
            try:
                await self._poll_orders()
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.debug("Poll error: %s", e)
            await asyncio.sleep(3)

    async def _poll_orders(self) -> None:
        """Check status of pending live orders."""
        if not self._pending_orders:
            return

        for order_id in list(self._pending_orders.keys()):
            order_info = self._pending_orders[order_id]
            age = time.monotonic() - order_info["placed_at"]

            # Check order status via CLOB API
            status = await self.clob.poll_order_status(order_id)
            if status:
                order_status = status.get("status", "").upper()
                token_id = order_info["token_id"]
                side = order_info["side"]
                price = order_info["price"]
                size_usdc = order_info["size_usdc"]
                market_name = order_info["market_name"]

                if order_status in ("MATCHED", "FILLED", "FILLED_PARTIAL"):
                    # Order filled! Record the fill
                    filled_size = float(status.get("size_matched", size_usdc))
                    fill_price = float(status.get("price", price))
                    await self._record_fill(token_id, side, fill_price, filled_size, market_name)

                    # Update active quote state
                    existing = self.active_quotes.get(token_id)
                    if existing:
                        if side == "BUY":
                            existing.bid_filled = True
                        else:
                            existing.ask_filled = True
                        if existing.bid_filled and existing.ask_filled:
                            logger.info("[ROUND-TRIP] %s | buy@%.4f sell@%.4f",
                                       market_name[:40],
                                       existing.bid_price, existing.ask_price)
                            self.active_quotes.pop(token_id, None)

                    self._pending_orders.pop(order_id, None)

                elif order_status in ("CANCELED", "CANCELLED"):
                    logger.info("[ORDER CANCELED] %s %s", side, market_name[:30])
                    self._pending_orders.pop(order_id, None)

                elif age > 30 and order_status == "LIVE":
                    # Order has been sitting for 30s without fill — cancel it
                    logger.info("[ORDER TIMEOUT] %s %s — canceling after 30s", side, market_name[:30])
                    await self.clob.cancel_order(order_id)
                    self._pending_orders.pop(order_id, None)

    # ── Fill simulation (paper mode) — ULTRA REALISTIC ────────────────────────

    async def _check_fills(
        self,
        token_id: str,
        book: MarketBook,
        existing: ActiveQuote,
        market_name: str,
    ) -> None:
        """ULTRA REALISTIC paper-mode fill simulation.

        Models real-world MM effects:
        1. FILL RATE: 2.5% base per cycle (real Polymarket frequency)
        2. ADVERSE SELECTION: 30% of fills lose money (informed traders)
        3. DIRECTIONAL BIAS: when market falls, our bid fills but ask doesn't
        4. COMPETITION: 40% of fills taken by other MM
        5. ORDER REJECTION: 15% rejected
        6. PARTIAL FILLS: 20% no fill, 40% partial, 40% full
        7. RESOLUTION RISK: force-close near expiry
        """
        if not settings.paper_trading:
            return  # Live mode uses _poll_orders instead

        import random

        # Get market direction for directional fill bias
        direction = self._get_market_direction(token_id)

        # LATENCY SIMULATION
        latency_noise = random.gauss(0, 0.002)
        perceived_mid = book.mid + latency_noise

        # RESOLUTION RISK
        info = self.clob.markets.get(token_id)
        if info:
            from datetime import datetime, timezone
            now_ts = datetime.now(timezone.utc).timestamp()
            time_to_resolution = info.end_date_ts - now_ts
            if time_to_resolution < 3600 and time_to_resolution > 0:
                if random.random() < 0.05:
                    inv = self.inventory.get_inventory(token_id)
                    if abs(inv.net_tokens) > 0.1:
                        force_price = perceived_mid
                        if inv.net_tokens > 0:
                            await self._record_fill(token_id, "SELL", force_price,
                                abs(inv.net_tokens) * perceived_mid, market_name)
                        else:
                            await self._record_fill(token_id, "BUY", force_price,
                                abs(inv.net_tokens) * perceived_mid, market_name)
                        logger.warning("[RESOLUTION] %s force-closed at %.4f",
                                      market_name[:30], force_price)
                        return

        # ── Bid fill simulation ─────────────────────────────────────────────
        if not existing.bid_filled and existing.bid_price > 0:
            market_bid = book.best_bid
            if market_bid > 0:
                distance = abs(existing.bid_price - market_bid)
                if existing.bid_price >= market_bid - 0.003 and distance <= 0.015:
                    # ORDER REJECTION (15%)
                    if random.random() < 0.15:
                        existing.bid_filled = True
                        if existing.ask_filled or not existing.ask_price:
                            self.active_quotes.pop(token_id, None)
                        return

                    # COMPETITION (40%)
                    if random.random() < 0.40:
                        return

                    # DIRECTIONAL BIAS: when market is FALLING, our bid is more
                    # likely to fill (sellers hitting our bid). When rising, less likely.
                    direction_mult = 1.0 + (direction * -0.5)  # falling market → +50% bid fills

                    # FILL PROBABILITY: 2.5% base (realistic Polymarket frequency)
                    market_spread = book.spread
                    activity_mult = 1.0
                    if market_spread < 0.015:
                        activity_mult = 1.3
                    elif market_spread > 0.04:
                        activity_mult = 0.6

                    closeness = 1.0 - (distance / 0.015)
                    fill_prob = 0.025 * closeness * activity_mult * max(0.3, direction_mult)
                    fill_prob = min(0.08, max(0.005, fill_prob))

                    if random.random() < fill_prob:
                        # ADVERSE SELECTION via directional bias:
                        # Informed traders hit our bid when they know price will FALL.
                        # We don't artificially worsen the fill price — instead,
                        # the loss comes naturally when we later try to sell
                        # into a falling market (our ask won't fill, or fills lower).
                        adverse_drift = random.uniform(0.001, 0.003)  # tiny natural slippage
                        fill_price = min(existing.bid_price + adverse_drift, market_bid + 0.001)

                        # PARTIAL FILLS: 20% none, 40% partial, 40% full
                        partial_roll = random.random()
                        if partial_roll < 0.20:
                            return
                        elif partial_roll < 0.60:
                            fill_pct = random.uniform(0.40, 0.75)
                        else:
                            fill_pct = random.uniform(0.85, 1.0)

                        fill_size = existing.size_usdc * fill_pct
                        if fill_size < 2.0:
                            return

                        # v10.3: Check inventory limit BEFORE recording fill
                        if not self.inventory.should_quote_bid(token_id):
                            logger.info("[INV LIMIT] %s — inventory full, canceling bid quote", market_name[:30])
                            await self._cancel_quote(token_id)
                            return

                        await self._record_fill(token_id, "BUY", fill_price, fill_size, market_name)
                        existing.bid_filled = True

                        # v10.3: After fill, check if we should stop quoting
                        if not self.inventory.should_quote_bid(token_id):
                            await self._cancel_quote(token_id)

        # ── Ask fill simulation ─────────────────────────────────────────────
        if not existing.ask_filled and existing.ask_price < 1:
            market_ask = book.best_ask
            if market_ask < 1:
                distance = abs(existing.ask_price - market_ask)
                if existing.ask_price <= market_ask + 0.003 and distance <= 0.015:
                    # ORDER REJECTION (15%)
                    if random.random() < 0.15:
                        existing.ask_filled = True
                        if existing.bid_filled or not existing.bid_price:
                            self.active_quotes.pop(token_id, None)
                        return

                    # COMPETITION (40%)
                    if random.random() < 0.40:
                        return

                    # DIRECTIONAL BIAS
                    direction_mult = 1.0 + (direction * 0.5)

                    market_spread = book.spread
                    activity_mult = 1.0
                    if market_spread < 0.015:
                        activity_mult = 1.3
                    elif market_spread > 0.04:
                        activity_mult = 0.6

                    closeness = 1.0 - (distance / 0.015)
                    fill_prob = 0.025 * closeness * activity_mult * max(0.3, direction_mult)
                    fill_prob = min(0.08, max(0.005, fill_prob))

                    if random.random() < fill_prob:
                        # ADVERSE SELECTION via directional bias:
                        # Informed traders hit our ask when they know price will RISE.
                        # We don't artificially worsen the fill price — instead,
                        # the loss comes naturally when we later try to buy
                        # back into a rising market (our bid won't fill, or fills higher).
                        adverse_drift = random.uniform(0.001, 0.003)  # tiny natural slippage
                        fill_price = max(existing.ask_price - adverse_drift, market_ask - 0.001)

                        # Clamp to valid range
                        fill_price = max(0.01, min(0.99, fill_price))

                        partial_roll = random.random()
                        if partial_roll < 0.20:
                            return
                        elif partial_roll < 0.60:
                            fill_pct = random.uniform(0.40, 0.75)
                        else:
                            fill_pct = random.uniform(0.85, 1.0)

                        fill_size = existing.size_usdc * fill_pct
                        if fill_size < 2.0:
                            return

                        # v10.3: Check inventory limit BEFORE recording fill
                        if not self.inventory.should_quote_ask(token_id):
                            logger.info("[INV LIMIT] %s — inventory full (short), canceling ask quote", market_name[:30])
                            await self._cancel_quote(token_id)
                            return

                        await self._record_fill(token_id, "SELL", fill_price, fill_size, market_name)
                        existing.ask_filled = True

                        # v10.3: After fill, check if we should stop quoting
                        if not self.inventory.should_quote_ask(token_id):
                            await self._cancel_quote(token_id)

        if existing.bid_filled and existing.ask_filled:
            buy_price = existing.bid_price
            sell_price = existing.ask_price
            spread = sell_price - buy_price
            logger.info("[ROUND-TRIP] %s | buy@%.4f sell@%.4f gross_spread=%.4f",
                        market_name[:40], buy_price, sell_price, spread)
            self.active_quotes.pop(token_id, None)

    async def _record_fill(
        self,
        token_id: str,
        side: str,
        price: float,
        size_usdc: float,
        market_name: str,
        _skip_hedge: bool = False,
    ) -> None:
        """Record a fill in inventory + DB."""
        realized = self.inventory.on_fill(token_id, side, price, size_usdc, market_name)

        # Costs: gas (Polygon cheap) + maker fee 0%
        gas_cost = 0.005 if settings.paper_trading else 0.001  # live gas even cheaper with current MATIC price
        taker_fee = 0.0  # maker = 0%
        total_cost = gas_cost + taker_fee
        realized_net = realized - total_cost

        self.inventory.bankroll -= total_cost
        self._fill_count += 1

        emoji = "🟢" if side == "BUY" else "🔴"
        mode_tag = "[LIVE]" if not settings.paper_trading else "[PAPER]"

        if realized_net >= 0:
            pnl_str = f"pnl=+${realized_net:.4f}"
        else:
            pnl_str = f"pnl=-${abs(realized_net):.4f}"

        logger.info(
            "%s [FILL] %s %s %s @ %.4f size=$%.2f | inv=%+.2f tokens %s",
            mode_tag, emoji, side, market_name[:50], price, size_usdc,
            self.inventory.get_inventory(token_id).net_tokens,
            pnl_str if realized != 0 else "",
        )

        await self._persist_trade(token_id, side, price, size_usdc, realized_net, market_name)

        # ── v10.3: Active Hedge-on-Fill — CAP hedge size! ──
        if settings.hedging_enabled and settings.hedging_active_enabled and not _skip_hedge:
            try:
                await self._attempt_active_hedge(token_id, side, size_usdc, market_name, price)
            except Exception as e:
                logger.debug("[HEDGE] %s — failed: %s", market_name[:30], e)

    async def _attempt_active_hedge(self, filled_token_id, filled_side, filled_size_usdc, market_name, filled_price=0.0):
        """Hedge by buying the PAIRED token (YES+NO=$1, risk-free).
        v10.3: CAP hedge size to filled_size_usdc (was calculating token amount which caused $23 hedges on $5 fills!)
        """
        paired_token = self._get_paired_token(filled_token_id)
        if not paired_token:
            return
        paired_book = self.clob.books.get(paired_token)
        if not paired_book or not paired_book.bids or not paired_book.asks:
            return
        paired_info = self.clob.markets.get(paired_token)
        paired_name = paired_info.question[:50] if paired_info else paired_token[:12]

        # v9.6: BUY YES → BUY NO, SELL YES → SELL NO
        if filled_side == "BUY":
            hedge_side = "BUY"
            hedge_price = paired_book.best_ask + 0.003
            hedge_price = min(0.99, hedge_price)
            # Profitability check: YES_ask + NO_ask must be < $1.00
            if filled_price + paired_book.best_ask >= 1.0:
                return
        else:
            hedge_side = "SELL"
            hedge_price = paired_book.best_bid - 0.003
            hedge_price = max(0.01, hedge_price)
            if filled_price + paired_book.best_bid <= 1.0:
                return

        # v10.3 CRITICAL FIX: Cap hedge size to FILLED SIZE (not token amount!)
        # Old bug: hedge = tokens * hedge_price → $5 fill × 28 tokens × $0.82 = $23 hedge
        # New: hedge = filled_size_usdc (same USD amount)
        hedge_size_usdc = filled_size_usdc
        if hedge_size_usdc < 1.0:
            return

        self._hedge_attempts += 1

        if settings.paper_trading:
            import random
            if random.random() < 0.80:
                actual_price = hedge_price + random.uniform(-0.0005, 0.0005)
                actual_price = max(0.01, min(0.99, actual_price))
                await self._record_fill(paired_token, hedge_side, actual_price, hedge_size_usdc, paired_name, _skip_hedge=True)
                self._hedge_fills += 1
                logger.info("[HEDGE] 🛡️ %s %s @ %.4f $%.2f — locked (capped to fill size)", hedge_side, paired_name[:40], actual_price, hedge_size_usdc)
            return

    # ── DB persistence ───────────────────────────────────────────────────────

    async def _persist_quote(self, token_id, bid, ask, mid, size_usdc):
        try:
            from app.core.db import AsyncSessionLocal
            async with AsyncSessionLocal() as db:
                q = Quote(
                    market_id=token_id,
                    bid_price=bid or 0,
                    ask_price=ask or 1,
                    mid_price=mid,
                    size_usdc=size_usdc,
                    spread_cents=(ask - bid) if bid and ask else 0,
                )
                db.add(q)
                await db.commit()
        except Exception as e:
            logger.debug("Quote persist failed: %s", e)

    async def _persist_trade(self, token_id, side, price, size_usdc, pnl, market_name):
        try:
            from app.core.db import AsyncSessionLocal
            async with AsyncSessionLocal() as db:
                t = Trade(
                    market_id=token_id,
                    market_name=market_name,
                    side=Side.BUY if side == "BUY" else Side.SELL,
                    price=price,
                    size_usdc=size_usdc,
                    size_tokens=size_usdc / max(price, 0.001),
                    pnl_usdc=pnl,
                    inventory_after=self.inventory.get_inventory(token_id).net_tokens,
                    paper=settings.paper_trading,
                )
                db.add(t)
                await db.commit()
        except Exception as e:
            logger.debug("Trade persist failed: %s", e)

    # ── Status ───────────────────────────────────────────────────────────────

    @property
    def status(self) -> dict:
        return {
            "cycle_count": self._cycle_count,
            "fill_count": self._fill_count,
            "active_quotes": len(self.active_quotes),
            "pending_live_orders": len(self._pending_orders) if not settings.paper_trading else 0,
            "mode": "LIVE" if not settings.paper_trading else "PAPER",
            # v9.5 stats
            "hedge_attempts": getattr(self, '_hedge_attempts', 0),
            "hedge_fills": getattr(self, '_hedge_fills', 0),
            "hedge_skipped": getattr(self, '_hedge_skipped', 0),
            "hedge_fill_rate": round(
                getattr(self, '_hedge_fills', 0) / max(getattr(self, '_hedge_attempts', 1), 1) * 100, 1
            ),
            "arb_opportunities": getattr(self, '_arb_opportunities', 0),
            "arb_executed": getattr(self, '_arb_executed', 0),
            "adverse_triggers": getattr(self, '_adverse_triggers', 0),
            "quotes_skipped_fee": getattr(self, '_quotes_skipped_fee', 0),
            "quotes_skipped_corr": getattr(self, '_quotes_skipped_corr', 0),
            "session": getattr(self, '_get_session_name', lambda: 'normal')(),
            "gas_estimate_usd": getattr(self, '_gas_estimator', None).get_gas_usd() if getattr(self, '_gas_estimator', None) else 0,
            "min_profit_cents": getattr(self, '_gas_estimator', None).min_profit_cents() if getattr(self, '_gas_estimator', None) else 0,
            "adverse_global_cooldown": getattr(self, '_adverse_selection', None).global_cooldown_remaining() if getattr(self, '_adverse_selection', None) else 0,
            "quotes_detail": [
                {
                    "token_id": q.token_id[:12],
                    "bid": round(q.bid_price, 4) if q.bid_price else None,
                    "ask": round(q.ask_price, 4) if q.ask_price else None,
                    "mid": round(q.mid_at_place, 4),
                    "bid_filled": q.bid_filled,
                    "ask_filled": q.ask_filled,
                    "age_sec": round(time.monotonic() - q.placed_at, 1),
                }
                for q in self.active_quotes.values()
            ],
        }
