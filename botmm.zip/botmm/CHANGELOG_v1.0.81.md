# CHANGELOG v1.0.81 — PAPER liquidation probabilistic model (BUG-N30)

**Дата:** 2026-07-05
**Попередник:** v1.0.80 (paper_health.py)
**Причина:** хендофф "v1.0.73 (draft)" виявив — PAPER-ліквідація дає нереалістично гарантований fill

---

## Контекст

За 1 годину PAPER-сесії (bot.log, v1.0.80):
- **13 fills, 6 закритих позицій, 0 round_trip подій**
- Усі 6 закриттів мали `liquidation=True` — жодна позиція не була закрита
  природним filled ask (контрагент вдарив по нашій ціні)
- Кожна позиція трималась рівно ~180с (AGGRESSIVE tier), потім форсовано
  продавалась з `pnl_net > 0` у всіх 6 випадках
- Сумарний net P&L: **+$2.09**, повністю зароблений через ліквідаційний шлях

**Коренева причина:** `_liquidate_aged_positions()` PAPER-гілка викликала
`_record_fill()` напряму за ціною `sell_price` (mid-based), минаючи
ймовірнісну модель (`paper_rejection_rate`, `paper_competition_rate`,
`paper_fill_prob_base/max`, `paper_adverse_drift_*`), яку `_check_fills_paper()`
застосовує до звичайних квот. Результат: 100% гарантований fill за mid-ціною,
де в реальному стакані **немає покупця** (mid > best_bid завжди).

## Номер бага: BUG-N30 (не N18)

Хендофф використовував номер "BUG-N18", але N18 вже зайнятий у v1.0.67
(PAPER Level 3 stress-test — інша проблема). Наступний вільний номер після
N29 (v1.0.78) — **N30**.

## Фікс (Варіант A з хендоффу)

**Файл:** `app/services/market_maker.py:1949-2017`

PAPER-гілка `_liquidate_aged_positions()` тепер:

1. **Cap ціну до marketable:** `fillable_price = min(sell_price, market_bid + 0.001)`
   — не вище за bid+0.001 (інакше немає покупця)

2. **Rejection probability:** `if random.random() < paper_rejection_rate: continue`
   — 55% шанс (з .env Level 3) що FAK не заповниться. Позиція залишається
   відкритою, retry через 10с (наступний liquidation cycle).

3. **Partial fill model:**
   - 20%: взагалі не заповнюється (`continue`)
   - 40%: partial 40-75% розміру
   - 40%: partial 85-100% розміру
   - Якщо partial розмір < $1 → `continue` (занадто мало)

4. **Log нові події:** `liquidation_paper_rejected`, `liquidation_paper_no_taker`,
   `liquidation_paper_filled` (з fill_pct, sell_price vs fillable_price)

## Чому фікс безпечний (truth-first перевірки)

1. **`open_time` НЕ ресетиться при невдалій ліквідації.**
   Перевірено в `inventory_manager.py`: `open_time` встановлюється ТІЛЬКИ при:
   - відкритті нової позиції (net_tokens 0 → >0) — рядки 238, 267
   - фліпі позиції (long → short або навпаки) — рядки 248, 261
   `continue` у for-loop не викликає `_record_fill` → `net_tokens` не змінюється
   → `open_time` не ресетиться → `age_sec` продовжує рости → URGENT tier
   (480с) настане навіть після серії невдалих спроб.

2. **`continue` у for-loop коректний.**
   `_liquidate_aged_positions()` ітерує `for token_id, inv in list(self.inventory.inventories.items())`.
   `continue` переходить до наступного token_id. Позиція залишається відкритою.
   Наступний цикл (через `inventory_liquidation_check_sec` = 10с) спробує знову.

3. **Partial fill коректно зменшує позицію.**
   `_record_fill` з `actual_size_usdc < size_usdc` викликає `inventory.on_fill()`,
   який обробляє partial close (рядки 252-270 inventory_manager.py): зменшує
   `net_tokens`, реалізує P&L на закритій частині. `open_time` НЕ ресетиться
   (позиція не фліпнула). Залишок буде ретраїтись наступними циклами.

4. **LIVE-гілка не зачеплена.**
   Код LIVE-ліквідації (рядки 2018+) не змінений — там реальний FAK через
   `place_order()` з перевіркою `result.success`.

## Що очікувати після фіксу (в PAPER)

| Метрика | Було (v1.0.80) | Стане (v1.0.81) |
|---|---|---|
| Ліквідаційний fill-rate | 100% (гарантовано) | ~45% (55% rejection) |
| Середній час виходу з позиції | ~180с (AGGRESSIVE) | 180-480с+ (з retry) |
| `round_trip` події | 0 | > 0 (природні ask-fills матимуть шанс) |
| P&L за 1 год | +$2.09 | **нижчий** (очікувано і правильно) |
| `liquidation_paper_rejected` в логу | — | частіше за `liquidation_paper_filled` |

## Тести

- `py_compile` ✅ OK
- Існуючі 113 тестів — UNVERIFIED (не запускав; зміна ізольована в PAPER-гілці,
  LIVE-логіка не зачеплена, сигнатури не змінились)
- Тест `test_bugN30_liquidation_paper_respects_fill_probability` (з хендоффу) —
  **НЕ додано** (проєктна конвенція: "do not write any test code"). Користувач
  може додати вручну: monkeypatch `random.random` → перевірити, що rejection
  залишає позицію відкритою.

## Не зачеплено

- LIVE-гілка ліквідації (рядки 2018+) — без змін
- `_check_fills_paper()` — без змін
- Ціноутворення mid-based (BUG-N17, v1.0.66) — без змін (fillnaбle_price
  капує вже розрахований sell_price до bid+0.001)
- v1.0.79 order_metrics_logger + v1.0.80 paper_health.py — без змін

## CONFIDENCE: 88%

- Код компілюється (py_compile OK)
- Логіка `open_time` / `continue` / partial-fill перевірена рядок-за-рядком
- UNVERIFIED: 113 тестів не запускав
- UNVERIFIED: PAPER-сесія з фіксом не запущена — очікуваний ефект
  (менший P&L, > 0 round_trips) потребує емпіричного підтвердження

## Рекомендація

1. Перезапустити PAPER-сесію з v1.0.81
2. Через 1 год порівняти з попередньою сесією:
   - `Select-String "round_trip" bot.log | Measure-Object` — має бути > 0
   - `Select-String "liquidation_paper_rejected" bot.log | Measure-Object` —
     має бути > `liquidation_paper_filled`
   - Сумарний P&L — має бути **нижчим** (це правильно)
3. Якщо через 2 год P&L все ще позитивний — фікс працює коректно
4. Якщо P&L став сильно негативним — варто розглянути Варіант B (bid-based
   ціноутворення) як додатковий фікс
