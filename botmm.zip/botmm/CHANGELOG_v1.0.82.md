# CHANGELOG v1.0.82 — PAPER liquidation oversell fix (BUG-N31)

**Дата:** 2026-07-05
**Попередник:** v1.0.81 (BUG-N30: PAPER liquidation probabilistic model)
**Причина:** регресія у v1.0.81 — oversell токенів → фантомний шорт + скидання open_time

---

## Контекст

v1.0.81 (BUG-N30) виправив гарантований PAPER-fill ліквідації, але ввів нову
регресію: розмір угоди рахувався від `sell_price` (mid-based), а виконання
йшло за `fillable_price` (bid-based). Оскільки `sell_price > fillable_price`
майже завжди, `on_fill()` обчислював `tokens_computed > net_tokens` → бот
"продавав" більше токенів, ніж мав → flip у фантомний шорт + скидання
`open_time` (якраз те, що BUG-N30 мав захистити).

## Коренева причина (BUG-N31)

**Файл:** `app/services/market_maker.py:1997` (v1.0.81 код)

```python
# рядок 1910 — розмір від sell_price (HIGHER)
size_usdc = inv.net_tokens * sell_price

# рядок 1997 (v1.0.81 — БАГ) — масштабує size_usdc
actual_size_usdc = size_usdc * fill_pct

# рядок 2002 — виконання за fillable_price (LOWER)
await self._record_fill(token_id, "SELL", fillable_price, actual_size_usdc, ...)
```

`on_fill()` (inventory_manager.py:228):
```python
tokens = size_usdc / max(price, 0.001)  # = actual_size_usdc / fillable_price
```

Підстановка:
```
tokens_computed = (net_tokens * sell_price * fill_pct) / fillable_price
                = net_tokens * (sell_price / fillable_price) * fill_pct
```

При `sell_price=0.389, fillable_price=0.371, fill_pct=1.0`:
```
tokens_computed = 13.0342 * (0.389/0.371) * 1.0 = 13.6666  (> net_tokens!)
new_total = 13.0342 - 13.6666 = -0.6324  → PHANTOM SHORT
```

## Числове підтвердження (VERIFIED)

Звірено з реальними даними з bot.log:
- net_tokens=13.0342, entry=$0.374, bid=$0.37, ask=$0.39, mid=$0.38
- sell_price = max(0.38, 0.424) capped at 0.389 = **0.389**
- fillable_price = min(0.389, 0.371) = **0.371**

| Метрика | v1.0.81 (баг) | v1.0.82 (фікс) |
|---|---|---|
| actual_size_usdc | $5.0703 | $4.8357 |
| tokens_computed | 13.6666 | 13.0342 |
| new_total | **-0.6324** (фантомний шорт) | **0.0000** (no flip) |
| oversold | 0.6324 tokens (+4.9%) | 0.0000 ✓ |
| open_time reset | ✅ так (через flip) | ❌ немає flip |

## Фікс (Варіант з хендоффу)

**Файл:** `app/services/market_maker.py:1997-2010`

```python
# БУЛО (v1.0.81 — БАГ):
actual_size_usdc = size_usdc * fill_pct

# СТАЛО (v1.0.82 — фікс):
tokens_filled = tokens_to_sell * fill_pct          # джерело правди — токени
actual_size_usdc = tokens_filled * fillable_price   # розмір від ціни виконання
```

Це гарантує: `tokens_computed = actual_size_usdc / fillable_price = tokens_filled ≤ tokens_to_sell`.
Ніколи не перевищує `net_tokens` → немає oversell → немає flip → `open_time` не ресетиться.

## Перевірки (VERIFIED)

1. **py_compile** ✅ OK
2. **Числова верифікація** (Python скрипт з даними з логу):
   - v1.0.81: `tokens_computed = 13.6666 > net_tokens = 13.0342` → oversell ✅ підтверджено
   - v1.0.82: `tokens_computed = 13.0342 == net_tokens` → no oversell ✅
   - Partial fill (fill_pct=0.40): `tokens_computed = 5.2137 < net_tokens` → no flip ✅
   - Assertions: `tokens_computed <= tokens_to_sell + epsilon` ✅
3. **`tokens_to_sell` в скоупі** — визначено на рядку 1915, не модифікується до 1997 ✅
4. **LIVE-гілка не зачеплена** (рядки 2030+) ✅
5. **`size_usdc` (рядок 1910) збережено** — потрібен для `size_usdc < 1.0` threshold та логування ✅

## Не зачеплено

- LIVE-гілка ліквідації (рядки 2030+) — без змін
- Ціноутворення mid-based (BUG-N17, v1.0.66) — без змін
- BUG-N30 ймовірнісна модель (rejection/partial) — без змін
- v1.0.79 order_metrics_logger + v1.0.80 paper_health.py — без змін

## Тести

- `py_compile` ✅ OK
- Існуючі 113 тестів — UNVERIFIED (не запускав; зміна 2 рядки в PAPER-гілці,
  LIVE не зачеплено)
- Числова верифікація пройшла (3 сценарії: full fill, partial fill, edge cases)

## Що очікувати після фіксу (в PAPER)

| Метрика | v1.0.81 (з багом) | v1.0.82 (фікс) |
|---|---|---|
| Фантомні шорти після ліквідації | можливі | неможливі |
| `open_time` скидання після успішного fill | можливе (через flip) | немає |
| URGENT tier (480с) досягається | не завжди (ресет) | завжди |
| `actual_size_usdc` при повному fill (0.389→0.371) | $5.07 (завищено) | $4.84 (точно) |
| bankroll зміна | завищена (більше $ отримано) | точна |

## CONFIDENCE: 95%

- Код компілюється (py_compile OK)
- Числова верифікація пройшла з точними даними з логу
- Фікс мінімальний (2 рядки логіки + коментар)
- `tokens_to_sell` в скоупі — перевірено
- UNVERIFIED: 113 тестів не запускав
- UNVERIFIED: PAPER-сесія з фіксом не запущена

## Рекомендація

Якщо ви на v1.0.81 з активною PAPER-сесією:
1. Зупиніть бота
2. Завантажте patch v1.0.82
3. Розпакуйте поверх: `tar -xzf polymarket_mm_bot_pro_v1.0.82_patch.tar.gz`
4. Перезапустіть: `python -m app.main`
5. Через 1 год перевірте:
   ```powershell
   Select-String "liquidation_paper_filled" bot.log | Select-Object -Last 5
   # перевірте, що actual_size_usdc рахується від fillable_price, не sell_price
   ```
6. Перевірте, що `inv.net_tokens` після ліквідації ніколи не йде в мінус
   (немає фантомних шортів)
