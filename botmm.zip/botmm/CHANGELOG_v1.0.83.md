# CHANGELOG v1.0.83 — Stale test fix (BUG-N32)

**Дата:** 2026-07-05
**Попередник:** v1.0.82 (BUG-N31: oversell fix — VERIFIED OK, не чіпати)
**Причина:** технічний борг з v1.0.81 — застарілий тест, не сама логіка бота

---

## Контекст

Не баг у продакшн-коді. `_liquidate_aged_positions()` (BUG-N31, v1.0.82)
перевірено числами — працює коректно, **не трогати**.

Проблема — у `tests/unit/test_market_maker_live.py`, тест
`test_paper_liquidation_uses_record_fill_directly` (рядок 343) досі очікує
поведінку **до** BUG-N30 (v1.0.81): гарантований, миттєвий `_record_fill`.
Після BUG-N30 виклик ймовірнісний (55% rejection + 20% no-taker), тест не
сідує `random` → флакі.

## Фікс (BUG-N32)

**Файл:** `tests/unit/test_market_maker_live.py:355-365`

Додано 2 рядки monkeypatch після існуючих налаштувань тесту:

```python
monkeypatch.setattr(settings, "paper_rejection_rate", 0.0)
monkeypatch.setattr("app.services.market_maker.random.random", lambda: 0.99)
```

**Чому це працює:**
- `random.random() = 0.99` → rejection check (`0.99 < 0.0`) = False ✓
- `partial_roll = 0.99` → не < 0.20 (no taker), не < 0.60 (40-75%) → "85-100%" гілка ✓
- `random.uniform(0.85, 1.0)` — НЕ monkeypatched (викликає `_inst.random()`,
  не модульну функцію), але `fill_pct ∈ [0.85, 1.0]` гарантує
  `actual_size_usdc > 1.0` (не `continue`)

Патерн monkeypatch `random.random` вже використовується в цьому ж тест
файлі (рядок 1080, тест `test_bug10_bid_rejection_still_checks_ask`) —
консистентно з існуючим стилем.

## Чому не `import random`

Хендофф пропонував додати `import random` на початок файлу. Але для
`monkeypatch.setattr("app.services.market_maker.random.random", ...)` це
рядковий шлях — `import random` в тест файлі НЕ потрібен. Додавання
невикористаного імпорту викликало б ruff warning F401.

## Перевірки (VERIFIED емпірично)

Встановив залежності бота в ізольованому venv, запустив тест:

### Без фіксу (5 запусків):
```
run 1: 1 failed
run 2: 1 failed
run 3: 1 failed
run 4: 1 failed
run 5: 1 failed
```
(Хендофф казав 1/5 passed — у мене 0/5, можливо через різні version залежностей,
але суть та ж: тест флакі/падає)

### З фіксом (5 запусків):
```
run 1: 1 passed in 1.12s
run 2: 1 passed in 1.07s
run 3: 1 passed in 1.03s
run 4: 1 passed in 1.06s
run 5: 1 passed in 1.04s
```

**5/5 passed — тест детермінований.**

## Не зачеплено

- Продакшн-код (`app/services/market_maker.py`) — БЕЗ ЗМІН
- BUG-N30 (v1.0.81) + BUG-N31 (v1.0.82) — не трогати
- Інші тести — не зачеплені (monkeypatch відкочується після тесту)
- `test_bug12_gas_cost_settings_exist` — не трогати (застарів, обговорено раніше)

## CONFIDENCE: 95%

- `py_compile` ✅ OK
- 5/5 passed з фіксом (емпірично підтверджено)
- 5/5 failed без фіксу (емпірично підтверджено флакі)
- Патерн monkeypatch консистентний з існуючим (рядок 1080)
- UNVERIFIED: повний набір 113 тестів не запускав (тільки цей один)

## Рекомендація

Низький пріоритет — тестовий борг, не впливає на поведінку бота. Якщо ви
не запускаєте тести локально — фікс не критичний. Але якщо запускаєте
`pytest tests/unit -q` — фікс прибере флакі.

```bash
# перевірка:
pytest tests/unit/test_market_maker_live.py::test_paper_liquidation_uses_record_fill_directly -q
# очікувано: 1 passed
```
