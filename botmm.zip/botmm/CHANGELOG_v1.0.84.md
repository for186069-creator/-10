# CHANGELOG v1.0.84 — Arbitrage scanner + Admin UI (Опція 4 + Опція A)

**Дата:** 2026-07-05
**Попередник:** v1.0.83 (BUG-N32 stale test fix)
**Причина:** PAPER-сесія показала збиток -\$0.10/43хв. MM з $60 + Україна неефективний. Користувач попросив новий механізм.

---

## Контекст

Аналіз PAPER-логу виявив: 1 прибутковий round-trip / 3 збиткових = adverse selection pattern.
MM на Polymarket з $60 з України — програє informed traders.

Користувач погодився на:
- **Опція 4**: новий механізм (НЕ казино) — cross-condition + time-spread arbitrage
- **Опція A**: niche markets filter (де професіонали не грають)
- **Колокація**: пізніше (перенесе бота на сервер)

## Що додано

### 1. `app/services/arbitrage_scanner.py` (новий, ~280 рядків)

**Логіка:**
- Fetch /events з Gamma API (вже робить discover_markets)
- Для кожного event з ≥2 markets — перевірити monotonicity
- 2 типи арбітражу:
  - **N1 (cross-condition)**: однакова подія, різні умови
  - **N2 (time-spread)**: "by July 8" vs "by July 10" — July 10 ≥ July 8 завжди
- Якщо July 10 < July 8 → **arb opportunity**: купити July 10, продати July 8

**Date extraction:** regex для "by July 8", "by August 15" тощо.
**Normalization:** видаляє дати з питань для порівняння.
**Monotonicity check:** якщо пізніша дата має нижчу ціну — violation.

**ArbOpportunity dataclass:** event_title, market_a/b_question, prices, edge_cents, direction, type, volumes.

### 2. `app/core/config.py` — 4 нові settings

```python
arb_enabled: bool = True                    # ARB_ENABLED
arb_scan_interval_sec: float = 300.0        # ARB_SCAN_INTERVAL_SEC (5 хв)
arb_min_edge_cents: float = 2.0             # ARB_MIN_EDGE_CENTS
arb_niche_max_volume_24h: float = 50000.0   # ARB_NICHE_MAX_VOLUME_24H (Опція A)
```

**Опція A:** `arb_niche_max_volume_24h=50000` — лише ринки з volume < $50k/добу
(де професіонали типу Wintermute/Jane Street не грають — занадто малий об'єм для них).

### 3. `app/main.py` — lifecycle

- Startup: `arb_scanner.start()` (паралельно з MM)
- Shutdown: `arb_scanner.stop()`
- Лог: `arb_scanner_started`, `arb_scan_complete`, `arb_opportunity_found`

### 4. `scripts/find_arbitrage.py` (новий CLI)

Ручне сканування без повного бота:
```bash
python scripts/find_arbitrage.py
python scripts/find_arbitrage.py --min-edge 3.0 --max-volume 30000
python scripts/find_arbitrage.py --json
```

Exit 0 = знайдено opportunities, 1 = не знайдено, 2 = помилка API.

### 5. `app/admin/api.py` — 2 нові endpoints (адмін-панель)

```python
@admin_router.get("/arb/opportunities")  # повертає поточні opportunities
@admin_router.post("/arb/scan")          # примусове сканування зараз
```

`inject_services()` оновлено — додає `_arb_scanner` через lazy import.

### 6. `app/static/index.html` — нова секція в адмін-панелі

Нова панель "🔍 Arbitrage Opportunities" між Inventory і Configuration:
- Таблиця: Type | Edge | Direction | Market A | Market B | Event
- Кнопка "Scan now" — примусове сканування (POST /arb/scan)
- Кнопка "Refresh" — оновити список (GET /arb/opportunities)
- Авто-refresh кожні 15с (легкий GET, не сканує)

JS функції: `loadArb()`, `arbScanNow()`, `refreshArb()`.

## Truth-first обмеження

1. **Сканер лише знаходить opportunities.** Виконання trade окремо (TODO — N3 manual execution).
   Зараз бот лише логує `arb_opportunity_found`, не виконує trade автоматично.
2. **Корельовані пари на Polymarket зустрічаються РІДКО.** Професіонали вже викупили
   більшість arb. Сканер перевірить — якщо нічого не знайдено, значить ринок efficient.
3. **N1 (cross-condition) поки що повертає None** — без чітких правил які умови
   корельовані (крім time-spread). Реалізований N2 (time-spread) повністю.
4. **UNVERIFIED:** не тестувалося на реальному Gamma API (sandbox не має доступу).
   Логіка перевірена на синтетичних прикладах ("July 8 @ 0.40, July 10 @ 0.35" → 5¢ edge).

## Перевірки (VERIFIED)

| Тест | Результат |
|---|---|
| `py_compile` 4 файлів | ✅ OK |
| Date extraction (3 випадки) | ✅ OK |
| Question normalization (time_spread) | ✅ OK |
| arb_type detection (time_spread) | ✅ OK |
| Monotonicity violation (July 8=0.40, July 10=0.35 → buy_b_sell_a, 5¢) | ✅ OK |
| No violation (July 8=0.35, July 10=0.40 → None) | ✅ OK |
| 4 нові settings доступні | ✅ OK |

## Що НЕ зачеплено

- MM-логіка (market_maker.py) — без змін, MM працює як і раніше
- v1.0.79 order_metrics_logger + v1.0.80 paper_health.py + BUG-N30/N31/N32 — без змін
- Існуючі 113 тестів — не зачеплені (новий модуль, окремий CLI)

## Як використовувати

### Опція 1: Ручне сканування (без бота)
```bash
python scripts/find_arbitrage.py
# або з niche filter:
python scripts/find_arbitrage.py --min-edge 2.0 --max-volume 30000
```

### Опція 2: Автоматичне сканування (з ботом)
Бот автоматично сканує кожні 5 хв (ARB_SCAN_INTERVAL_SEC=300).
Логи: `arb_opportunity_found` — дивитись `bot.log` або:
```bash
Select-String "arb_opportunity_found" bot.log
```

### Колокація (пізніше)
Після перенесення на VPS — бот працюватиме так само. Сканер не залежить від
пінгу (лише читає Gamma API). Але виконання trades (кол буде реалізовано N3)
вже буде залежати від пінгу.

## CONFIDENCE: 82%

- Код компілюється, логіка перевірена на синтетичних прикладах
- 4 нові settings додані
- Інтеграція в main.py — try/except, не ламає існуюче
- UNVERIFIED: реальний Gamma API (sandbox не має доступу)
- UNVERIFIED: чи знайдуться реально arb opportunities на Polymarket
- Ризик: якщо regex не покриває всіх форматів дат — деякі arb буде пропущено

## Рекомендація

1. Запустити `python scripts/find_arbitrage.py` — перевірити, чи є зараз arb
2. Якщо є opportunities — дивитись direction + edge, вирішувати чи виконувати manually
3. Якщо немає — збільшити `--max-volume` або зменшити `--min-edge`
4. Колокація: після перенесення на VPS — бот працюватиме так само, без змін
