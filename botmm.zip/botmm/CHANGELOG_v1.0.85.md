# CHANGELOG v1.0.85 — N1 inventory-aware pricing + N2 documentation + N3 decline

**Дата:** 2026-07-05
**Попередник:** v1.0.84 (arbitrage scanner)
**Причина:** користувач попросив реалізувати N1+N2+N3 з "Опція 4: нові механізми"

---

## Truth-first статус по N1/N2/N3

| # | Механізм | Статус | Дія |
|---|---|---|---|
| N1 | Inventory-aware pricing (повний A-S з T-t) | ⚠️ Частково існував | **Покращено** — додано реальний time-to-resolution |
| N2 | Toxic flow detection (permanent block) | ✅ Вже реалізовано (v1.0.x) | **Задокументовано** — без змін коду |
| N3 | Funding rate arbitrage | ❌ Неможливо на Polymarket | **Відхилено** з поясненням |

## N1: Inventory-aware pricing (повний Avellaneda-Stoikov)

### Що було (v1.0.84 і раніше)
`app/services/pricing/avellaneda_stoikov.py` використовував **normalized horizon (T-t = 1.0)** завжди:
```python
inventory_penalty = gamma * sigma^2 * q   # T-t = 1.0 implicit
```

### Що сталося (v1.0.85)
Додано реальний **time-to-resolution** (T-t):
```python
# horizon = normalized time to resolution
#   24h to resolution → T-t = 1.0 (max penalty)
#   1h to resolution  → T-t = 0.04 (small penalty)
#   1min to resolution→ T-t = 0.01 (minimal penalty)
inventory_penalty = gamma * sigma^2 * q * horizon
```

### Чому це краще (truth-first)
**A-S оригінал:** penalty scales with (T-t). Біля resolution — менший penalty (менше часу для ціни повернутись). Далеко від resolution — більший penalty (більше inventory risk).

**Старий код:** T-t = 1.0 завжди. Бот надмірно агресивно зсував ціни біля resolution.

**Новий код:** T-t зменшується біля resolution. Бот менше зсуває ціни, коли часу мало — менше adverse selection.

### Файли
- `app/services/pricing/avellaneda_stoikov.py:83-149` — новий параметр `time_to_resolution_sec`
- `app/services/market_maker.py:683-694` — передача `ttr_sec` з `info.end_date_ts`
- `app/core/config.py:97-101` — новий setting `as_use_real_horizon: bool = True`

### Backward compatibility
- `as_use_real_horizon=False` → стара поведінка (T-t = 1.0)
- `time_to_resolution_sec=None` → стара поведінка
- За замовчуванням: `True` + реальний T-t

## N2: Toxic flow detection (вже реалізовано)

### Що вже є (v1.0.x, без змін)
`app/services/risk/adverse_selection.py:121-132`:
```python
# Permanent block if win rate is very poor over enough samples
total = state.win_count + state.loss_count
if total >= 20:
    win_rate = state.win_count / total
    if win_rate < 0.30:
        state.permanently_blocked = True
```

### Логіка
- Кожен fill записується з mid_at_fill
- Через `adverse_selection_window_sec` перевіряється: чи mid пішов проти нас?
- Якщо win_rate < 30% over 20 fills → **permanent block** токена
- `is_in_cooldown()` повертає True для blocked токенів → бот пропускає їх при quoting

### Чому не потрібен новий код
Цей механізм вже працював у вашому тесті (PAPER-сесія). У логу:
- `adverse_selection_triggered`: 2 рази (cooldown 30с)
- Permanent blocks: 0 (не досягли 20 fills з win_rate < 30%)

**Per-trader tracking неможливий** на Polymarket — API не розкриває identity counterparties. Tокен-level block — це максимум.

## N3: Funding rate arbitrage — НЕМОЖЛИВО

### Truth-first відмова
Polymarket — це **prediction markets** з binary outcomes (Yes/No), НЕ perpetual futures.

| Біржа | Тип | Funding rate? |
|---|---|---|
| Polymarket | Prediction markets (binary) | ❌ Немає |
| Binance Futures | Perpetual futures | ✅ Є |
| dydx | Perpetual futures | ✅ Є |
| Kalshi | Event contracts (daily/weekly) | ⚠️ Смислово інший |

Polymarket markets:
- Мають **resolution date** (коли подія вирішується)
- Платять $1 за Yes якщо подія сталась, $0 якщо ні
- НЕ мають funding rate (немає позиції щоб fundувати)

**N3 технічно неможливий на Polymarket.** Реалізувати його = вигадати неіснуючий API.

### Альтернатива (якщо хочете funding arb)
Перенести бота на Binance Futures / dydx — там funding rate arb можливий.
Але це **інший проєкт**, не цей бот.

## Перевірки (VERIFIED)

### N1 smoke tests (4 сценарії)
```
Old (horizon=1.0):     reservation=0.5000, penalty=0.000001
New (24h to res):      reservation=0.5000, penalty=0.000001  ← == old
New (1h to res):       reservation=0.5000, penalty=0.000000  ← smaller
New (1min to res):     reservation=0.5000, penalty=0.000000  ← smallest
```

Assertions:
- ✅ `abs(p1 - p2) < 1e-9` — backward compat (24h == old)
- ✅ `p3 < p2` — 1h penalty < 24h penalty
- ✅ `p4 < p3` — 1min penalty < 1h penalty
- ✅ `p4 < p1 * 0.05` — 1min penalty < 5% of 24h

### N2 verification
- ✅ `permanently_blocked` знайдено в коді
- ✅ `win_rate < 0.30` threshold знайдено
- ✅ Логіка: 20 fills з win_rate < 30% → permanent block

### N3 verification
- ✅ Polymarket API не має `/funding-rate` або `/perpetual` endpoints
- ✅ Market structure: binary outcomes, не perps

## Файли змінені

| Файл | Зміна |
|---|---|
| `app/services/pricing/avellaneda_stoikov.py` | +параметр `time_to_resolution_sec`, формула з (T-t) |
| `app/services/market_maker.py` | передача `ttr_sec` з `info.end_date_ts` |
| `app/core/config.py` | +setting `as_use_real_horizon` |
| `.env` + `.env.example` | +`AS_USE_REAL_HORIZON=true` |

## Не зачеплено

- N2 (`adverse_selection.py`) — без змін, вже працює
- v1.0.84 arbitrage scanner — без змін
- BUG-N30/N31/N32 — без змін
- 113 існуючих тестів — не зачеплені (новий опціональний параметр)

## CONFIDENCE: 90%

- N1: код компілюється, 4 smoke tests пройшли, backward compat збережено
- N2: задокументовано існуючу поведінку, без змін
- N3: відхилено з технічного пояснення (Polymarket = prediction markets)
- UNVERIFIED: реальний вплив N1 на PAPER P&L (потребує тестової сесії)
- UNVERIFIED: 113 тестів не запускав

## Рекомендація

1. Запустити PAPER-сесію з v1.0.85
2. Порівняти P&L з попередньою сесією (v1.0.84):
   - Очікувано: менший inventory penalty біля resolution → менше adverse selection
   - Якщо P&L покращився хоча б на 10-20% — N1 працює
3. N2 вже працював — без змін
4. N3 неможливий — забудьте
