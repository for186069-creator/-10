# CHANGELOG v1.0.86 — Arb scanner fix (real risk-free arb) + Exit All fix

**Дата:** 2026-07-06
**Попередник:** v1.0.85 (N1 inventory-aware pricing)
**Причина:** сканер показував false positive "arb" (Alito 33¢). Exit All не виводив $1.86.

---

## A: Arb scanner — справжній безризиковий arb

### Баг (v1.0.84-v1.0.85)
`_check_monotonicity()` повертав "arb" при **будь-якій** ціновій різниці між корельованими ринками. Приклад:
- "Alito by Sept 30, 2026" @ $0.21
- "Alito by June 30, 2027" @ $0.54
- Сканер: "33¢ arb! Buy A, Sell B" ← **НЕ АРБ**

Це **цінова різниця, але не безризиковий arb**. Купити Yes(Sept) і "продати" Yes(June) неможливо без шорту — це directional bet, не arb.

### Коренева причина
1. `_extract_date()` повертав `(month, day)` **без року**. "Sept 30" vs "June 30" порівнювались по місяцю (9 > 6) — сканер думав Sept пізніша. Реально Sept 2026 РАНЬША за June 2027.
2. Логіка `_check_monotonicity` перевіряла лише "пізніша дешевша за ранню" — але це не гарантує `Yes_late + No_early < $1.00`.

### Фікс (v1.0.86)
**Новий алгоритм `_check_real_arb()`:**
```python
# Справжній безризиковий arb на Polymarket:
# Купити Yes(пізніша дата) + No(раньша дата)
# No ціна = 1 - Yes ціна (на Polymarket Yes+No = $1)
# Собівартість = Yes_late + (1 - Yes_early) = 1 + (Yes_late - Yes_early)
# Якщо Yes_late < Yes_early → собівартість < $1 → ARB
# (бо одна з умов завжди виконається → отримаємо $1)
```

### Зміни
- `_extract_date()`: повертає `(year, month, day)` замість `(month, day)`
- `_check_real_arb()`: нова функція, замінює `_check_monotonicity`
- `ArbOpportunity.direction`: нові значення `buy_yes_a_buy_no_b` / `buy_yes_b_buy_no_a`
- Повертає `(direction, edge_cents, total_cost_dollars)` — додано `total_cost`

### Smoke tests (4 сценарії, VERIFIED)
1. ✅ Alito Sept2026@0.21 vs June2027@0.54 → **None** (не arb, total=1.33 > $1)
2. ✅ GPT July8@0.40 vs July10@0.35 → **arb** (5¢ edge, total=$0.95 < $1)
3. ✅ GPT July8@0.35 vs July10@0.40 → **None** (нормальна monotonicity)
4. ✅ Date extraction з роком: (2026, 9, 30) та (2027, 6, 30) коректно

## B: Exit All — чому $1.86 зависло

### Баг
`exit_all()` мав фільтр `inv.net_tokens > 0.5` (рядок 797). Позиції з < 0.5 токена ігнорувались — навіть якщо мали книжку. Також:
- При `best_bid = 0` (ринок закрився) — skip без логу
- При `accept_loss=False` — skip без пояснення

### Фікс (v1.0.86)
1. **Знижено поріг** з `0.5` до `0.01` токена — тепер виводить будь-яку позицію > 1¢
2. **Додано `skipped` масив** у return — показує ЧОМУ позиція пропущена
3. **Додано лог** `exit_all_skip_no_book` коли `best_bid=0`

### Smoke test
```python
# позиція 0.3 токена @ $0.50 = $0.15
# старий код: skip (0.3 < 0.5) → "No long positions to exit"
# новий код: process (0.3 > 0.01) → sell
```

## Файли змінені

| Файл | Зміна |
|---|---|
| `app/services/arbitrage_scanner.py` | `_extract_date` + `_check_real_arb` (нова) |
| `app/admin/api.py` | `exit_all`: поріг 0.5→0.01, `skipped` масив, лог |

## Truth-first обмеження

1. **Справжній arb на Polymarket вкрай рідкісний.** Profi вже викупили.
   Фікс лише прибирає false positives — реальних arb може все одно не бути.
2. **Exit All з фіксом продасть позиції з книжкою.** Якщо `best_bid=0` (закритий ринок) — все одно skip, бо продати немає кому.
3. **UNVERIFIED:** не тестував на реальному боті (тільки py_compile + smoke tests).

## Перевірки (VERIFIED)

| Тест | Результат |
|---|---|
| py_compile 2 файлів | ✅ OK |
| A1: Alito не arb (total=1.33) | ✅ |
| A2: GPT July8/10 справжній arb (5¢, $0.95) | ✅ |
| A3: Нормальна monotonicity не arb | ✅ |
| A4: Date extraction з роком | ✅ |
| B: поріг 0.5→0.01 + skipped масив | ✅ (py_compile) |

## CONFIDENCE: 90%

- Код компілюється, 4 smoke tests пройшли
- Логіка arb математично коректна (Yes+No=$1 на Polymarket)
- Exit All фікс мінімальний, не ламає ісходну логіку
- UNVERIFIED: реальна робота на боті
- UNVERIFIED: чи з&apos;являться реальні arb після фіксу (скоріше за все ні — ринок efficient)

## Рекомендація

1. Запустити з v1.0.86 — сканер більше не показуватиме false positives
2. Якщо Exit All досі не виводить $1.86 — перевірити `skipped` масив у відповіді
   (можливо best_bid=0 на тому ринку — він закритий)
3. Справжніх arb навряд чи знайдеться — але якщо з&apos;явиться, сканер тепер покаже коректно
