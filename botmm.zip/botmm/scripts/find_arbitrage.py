#!/usr/bin/env python3
"""
scripts/find_arbitrage.py — Ручне сканування arb opportunities.

Запуск без повного бота — лише сканер. Корисно для перевірки, чи є зараз
arb opportunities на Polymarket, перед тим як вирішувати чи запускати бота.

Usage:
    python scripts/find_arbitrage.py
    python scripts/find_arbitrage.py --min-edge 3.0
    python scripts/find_arbitrage.py --max-volume 30000
    python scripts/find_arbitrage.py --json

Exit codes:
    0 — знайдено ≥1 opportunity
    1 — opportunities не знайдено
    2 — помилка API
"""
from __future__ import annotations

import argparse
import asyncio
import os
import sys
from pathlib import Path

_PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

from app.core.config import settings
from app.services.arbitrage_scanner import arb_scanner


async def run_scan(min_edge: float, max_volume: float, json_output: bool) -> int:
    # Override settings for this CLI run
    settings.arb_min_edge_cents = min_edge
    settings.arb_niche_max_volume_24h = max_volume

    if not json_output:
        print(f"Сканування Polymarket (min_edge={min_edge}¢, niche_max_vol=${max_volume:,.0f})...")
        print()

    opps = await arb_scanner.scan_once()

    if not opps:
        if not json_output:
            print("❌ Arb opportunities не знайдено.")
            print()
            print("Можливі причини:")
            print("  - Професіонали вже викупили весь arb (ефективний ринок)")
            print("  - Немає корельованих пар з порушеною monotonicity")
            print("  - Збільште --max-volume або зменште --min-edge")
        else:
            print('{"opportunities": [], "count": 0}')
        return 1

    if json_output:
        import json
        print(json.dumps({
            "opportunities": [o.to_dict() for o in opps],
            "count": len(opps),
        }, indent=2, default=str))
        return 0

    print(f"✅ Знайдено {len(opps)} arb opportunities:\n")
    print(f"{'#':<3} {'тип':<17} {'edge':<7} {'напрямок':<16} {'A':<35} {'B':<35}")
    print(f"{'-' * 3} {'-' * 17} {'-' * 7} {'-' * 16} {'-' * 35} {'-' * 35}")

    for i, opp in enumerate(opps, 1):
        a_short = f"{opp.market_a_question[:30]} @ {opp.market_a_price:.3f}"
        b_short = f"{opp.market_b_question[:30]} @ {opp.market_b_price:.3f}"
        print(f"{i:<3} {opp.arb_type:<17} {opp.edge_cents:>5.1f}¢ {opp.direction:<16} {a_short:<35} {b_short:<35}")

    print()
    print(f"Event: {opps[0].event_title}")
    print()
    print("Деталі першої opportunity:")
    for k, v in opps[0].to_dict().items():
        print(f"  {k}: {v}")

    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Polymarket arbitrage scanner")
    parser.add_argument("--min-edge", type=float, default=2.0,
                        help="Мінімальний edge в cents (за замовч.: 2.0)")
    parser.add_argument("--max-volume", type=float, default=50000.0,
                        help="Опція A: тільки ринки з volume < ця межа (за замовч.: $50000)")
    parser.add_argument("--json", action="store_true",
                        help="JSON вивід")
    args = parser.parse_args()

    try:
        return asyncio.run(run_scan(args.min_edge, args.max_volume, args.json))
    except KeyboardInterrupt:
        return 130
    except Exception as e:
        print(f"FATAL: {type(e).__name__}: {e}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
