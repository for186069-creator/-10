# v1.0.144 — Dust handling per Claude review (8 sections)

## Claude review summary
Claude reviewed HANDOFF_dust_problem_v2.md and HANDOFF_scaling_strategy_v1.0.143.md.
Found 1 critical hole (orphaned resolution), 1 threshold fix, 1 mandatory max-age,
1 rename, 1 phase criteria expansion, 1 profit number removal. Solution E rejected.

## Section 1 (CRITICAL): Orphaned position reconciliation

### Problem Claude found
`_handle_resolution_exit` / `resolution_detector_triggered` (market_maker.py:612-662)
live inside `_process_market()`, which only runs for tokens in `self.clob.books`.
Once a position is orphaned (market dropped from books), it's NEVER checked for resolution.

**Consequences:**
- LIVE: real USDC appears on wallet (sync_bankroll_from_wallet catches it), but
  internal inventory record stays as phantom forever → inflates total_exposure
- PAPER: worse — no real wallet, dust never returns, permanently locked capital

### Fix
- New `fetch_market_status(token_id)` in clob_client.py — queries Gamma API
  `/markets?clob_token_ids=X` for resolution status + resolved_price
- New `_reconcile_orphaned_positions()` in market_maker.py — iterates orphaned
  positions, checks resolution, settles if resolved (credits bankroll, records
  fill, removes from inventory)
- New `_reconcile_loop()` background task — runs every
  `orphaned_reconcile_interval_sec` (default 600s = 10 min)
- Registered in task_names dict + shutdown cancel list

## Section 2: dust_threshold_usdc = $5 (not $1)

### Problem
My proposed `dust_threshold_usdc=1.0` was arbitrary. Dust by definition =
"position you CANNOT sell" = < $5 (Polymarket minimum). $1-4 positions are
still unsellable but would be treated as "real" by my threshold.

### Fix
```python
dust_threshold_usdc: float = Field(default=5.0, gt=0)
```
Bound to POLYMARKET_MIN_ORDER_USDC conceptually (both = $5). If Polymarket
changes minimum, update both.

## Section 3 Solution B: Never cancel partials + max-age warning

### Implementation
- `partial_fill_no_cancel: bool = False` (default off, enable for Phase 1)
- `order_cancel_min_fill_pct: float = 0.0` (cancel only if fill < X%)
- `_cancel_all_levels(token_id, force=False)` — when force=false and
  partial_fill_no_cancel=true, skips quotes with any fill (bid_filled/ask_filled)
- `max_partial_wait_sec: float = 259200` (72h default) — logs warning when
  partial position stuck longer than this. CANNOT force-sell (exchange rejects
  < $5). Just honest notification.

### Honest limitation (per Claude)
"Never cancel" doesn't eliminate loss risk — only eliminates dust event.
If price moves against partial position, user holds it until resolution.
0% dust risk ≠ 0% loss risk. UI must communicate this clearly.

## Solution C: Dust excluded from inventory checks

### Implementation
- New `_is_dust(token_id)` helper in inventory_manager.py
- `should_quote_bid()` — returns True if dust (doesn't block new bids)
- `should_quote_ask()` — returns True if dust (doesn't block new asks)
- Dust doesn't count toward inventory_clear_threshold or max_inventory_usdc

## Solution D: Auto-refill dollar-based dust threshold

### Problem
Old code (market_maker.py:533): `if abs(inv.net_tokens) > 0.5: continue`
- 0.5 tokens at $0.90 = $0.45 (treated as "real" position, blocks refill)
- 0.5 tokens at $0.05 = $0.025 (treated as "real" position, blocks refill)
Inconsistent across price levels.

### Fix
```python
position_value = abs(inv.net_tokens * inv.avg_entry_price)
if settings.auto_refill_keep_partial:
    if position_value >= settings.dust_threshold_usdc:  # $5
        continue  # significant position, keep market
    # Dust — can drop market, inventory record stays for reconciliation
else:
    if abs(inv.net_tokens) > 0.5:  # old behavior
        continue
```

## Section 5: Single order mode (Patient Directional Mode)

### Implementation
- `single_order_mode: bool = False` (default off)
- When true: places ONLY bid OR ask per market, not both
  - Has long position → SELL only (close)
  - Has short position → BUY only (close)
  - Flat → BUY only (open)
- Logs `single_order_mode_*` events for transparency

### Honest naming (per Claude)
This is NOT market making. It's "Patient Directional Mode" — directional bet
with limit orders. Profit depends on price direction, not spread capture.
UI should label it as such, not "Survival Mode MM".

## Section 6: Phase transition criteria

### Implementation
- `min_track_record_days: int = 14` — minimum days before phase advancement
- (Full `can_advance_phase()` method not implemented yet — requires more
  state tracking. Config field added for future use.)

## Section 7: Profit numbers removed

No profit numbers postulated in this version. Phase 1 profitability TBD
after empirical PAPER test. Previous "$0.50-1.00/week" was wishful thinking.

## Solution E: NOT implemented

PAPER dust auto-close at mid — would hide real dust behavior, give false
confidence for LIVE. Per Claude: "better remove from plan entirely, not
just leave disabled by default."

## Files modified
- `app/core/config.py`: +8 fields (dust_threshold, partial_fill_no_cancel,
  order_cancel_min_fill_pct, auto_refill_keep_partial, max_partial_wait_sec,
  orphaned_reconcile_interval_sec, min_track_record_days, single_order_mode)
- `app/services/clob_client.py`: +`fetch_market_status()` method
- `app/services/market_maker.py`:
  - +`_reconcile_orphaned_positions()` method
  - +`_reconcile_loop()` background task
  - +`_quote_has_partial_fill()` helper
  - `_cancel_all_levels()` — +force param, respects partial_fill_no_cancel
  - Auto-refill — dollar-based dust threshold
  - +single_order_mode logic in level loop
  - Registered _reconcile_task in start() + shutdown
- `app/services/inventory_manager.py`:
  - +`_is_dust()` helper
  - `should_quote_bid/ask` — dust excluded
- `.env`: +8 new vars

## Honest verification
- `py_compile` all 4 files ✓
- Config loads correctly ✓
- Logic follows Claude's recommendations verbatim
- Tests NOT run (no test infra changes)
- Bot NOT started in PAPER (user's separate project)

## Required user actions
1. Download `botmm_v1.0.144.zip`
2. Restart bot — orphaned positions will be reconciled within 10 min
3. For Phase 1 ($10 LIVE): set in .env:
   ```
   SINGLE_ORDER_MODE=true
   PARTIAL_FILL_NO_CANCEL=true
   AUTO_PICK_COUNT=1
   ```
4. Existing dust (Milwaukee $0.32) will settle when market resolves
   (reconciliation loop checks every 10 min)

## Confidence
- Orphaned reconciliation correctness: ~85% (logic sound, untested live)
- Dust threshold fix: ~95% (simple dollar check)
- Never-cancel logic: ~90% (bid_filled/ask_filled flags reliable)
- Single order mode: ~90% (simple conditional)
- Phase 1 will work as "Patient Directional Mode": ~80% (per Claude, not MM)
