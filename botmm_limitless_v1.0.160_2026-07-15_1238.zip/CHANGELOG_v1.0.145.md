# v1.0.145 — Restore skip markers on 4 stale tests (Claude review)

## Problem
During v1.0.144 dust-handling work, 4 tests lost their `@pytest.mark.skip`
decorators (originally added in v1.0.132). These tests verify the old
"shorting" mechanism that was removed by BUG-N41 clamp (v1.0.132).

Test run was: `4 failed, 115 passed` instead of `116 passed, 4 skipped`.

## Fix
Restored `@pytest.mark.skip(reason="v1.0.132: stale test — uses shorting which is clamped by BUG-N41")` on:

1. `tests/unit/test_bugN34_loss_cents_realistic.py::test_bugN34_loss_check_passes_when_realistic_loss_under_max`
2. `tests/unit/test_inventory_manager.py::TestInventoryManager::test_consecutive_losses_trigger_halt`
3. `tests/unit/test_inventory_manager.py::TestInventoryManager::test_should_quote_ask_blocks_at_clear_threshold`
4. `tests/unit/test_inventory_manager.py::TestInventoryManager::test_quote_skew_positive_when_short`

## Validation
`pytest -q` should now show:
```
116 passed, 4 skipped in ~9s
```
Not `4 failed, 115 passed`.

## Why this matters (per Claude)
Test hygiene: keeping stale tests explicitly marked `skip` distinguishes
"test reports real problem" from "test is outdated and known". Without
markers, future real regressions get lost in noise of known false positives.

## Files modified
- `tests/unit/test_bugN34_loss_cents_realistic.py`: +1 skip decorator
- `tests/unit/test_inventory_manager.py`: +3 skip decorators

## Verification
- Decorators restored with v1.0.132 reasons (copied verbatim)
- pytest import already present in both files
- Tests NOT run in this env (structlog not installed), but Claude verified
  in his env: `116 passed, 4 skipped`
