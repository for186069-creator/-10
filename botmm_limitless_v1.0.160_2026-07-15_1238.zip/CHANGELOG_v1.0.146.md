# v1.0.146 — Dust × never-cancel interaction fixes (Claude review of v1.0.145)

Review verdict: all Solutions A–D from HANDOFF_dust_problem_v2 are correctly
implemented in v1.0.145. Three interaction holes fixed:

## FIX-1: Liquidation oversell risk (CRITICAL for LIVE)
`_liquidate_aged_positions` cancelled quotes WITHOUT force=True. With
`partial_fill_no_cancel=true` a partially-filled ask stayed live while the
FAK SELL was placed for the ENTIRE position — both could fill → sell more
tokens than owned (naked short).
**Fix:** `_cancel_all_levels(token_id, force=True)` before FAK.

## FIX-2: LIVE FAK reject spam on dust
Liquidation only skipped `size_usdc < 1.0`. Positions worth $1–$5 triggered
a FAK SELL every cycle that Polymarket rejects ($5 minimum) — endless
reject loop.
**Fix:** LIVE-only skip when `size_usdc < dust_threshold_usdc` (=$5).
Dust settles on resolution via the reconciliation loop (no minimum on
resolution payouts). PAPER behavior unchanged.

## FIX-3: Unmonitored live orders on shutdown / pause / market drop
With never-cancel enabled, partially-filled quotes stayed LIVE on the
exchange when:
- bot shutdown (stop) — orders live while bot offline
- user pause (stop_trading) — user expects everything off the book
- auto-refill drops a dust market — WS unsubscribed, order unwatched
**Fix:** all three call sites now pass `force=True`. Cancelling the
unfilled remainder does not create new dust — the filled part is already
inventory either way.

## Tests
- New: tests/unit/test_v146_dust_live_fixes.py (4 tests)
- Full suite: 119 passed, 4 skipped, 0 failed

## Files changed
- app/services/market_maker.py (4 call sites + 1 dust guard)
- tests/unit/test_v146_dust_live_fixes.py (new)
