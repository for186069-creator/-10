# v1.0.148 — HARDCODED SPREAD + Dashboard + .env + log file (Claude, full implementation)

## 1. THE HARDCODED SPREAD LOGIC (Jiji's direct order)
    BUY  = best_bid + 15 points (0.0015)
    SELL = best_ask - 15 points (0.0015)
- NEW module `app/services/spread_invariant.py` — single source of truth.
  Constants are module-level FINAL: not in settings, not in .env, not in DB,
  not changeable from admin API. Nothing can move the price.
- market_maker.py pricing now goes EXCLUSIVELY through hardcoded_quotes():
  L1 = 15 pts, L2 = 30 pts, L3 = 45 pts (hardcoded multiples).
  Removed: adaptive gap (quote_gap_pct / kyle sensitivity) influence on
  PRICE and skew influence on PRICE. Kyle/A-S/skew still control SIZE and
  SIDE — never price.
- Final gate validate_quote() before every placement: quotes strictly
  inside the market spread, buy < sell, ≥15 pts from each edge, [0.01,0.99].
  Violation → quote DROPPED (never "fixed up"), warning logged.
- No room (spread ≤ 2×offset) → market skipped, rule never bent.
- 13 lock-down tests in tests/unit/test_hardcoded_spread.py, including a
  config-sabotage test proving settings cannot alter the price.

## 2. .env — FIXED (was only dust fields from v1.0.144)
Full operational .env: mode, sizing, market selection, risk, dust, auth
placeholders, Phase-1 preset (commented), logging. No more silent defaults.

## 3. Log file (Jiji's order)
- LOG_FILE defaults to logs/botmm.log (dir auto-created)
- Size rotation at LOG_MAX_MB (default 50MB → .1 backup)
- JSON lines, same stream as stdout

## 4. New dashboard (app/static/index.html)
Terminal-style dark UI. Signature element: LIVE SPREAD LADDER — for every
market a rail from best_bid to best_ask with our BUY (+15 pts, green) and
SELL (−15 pts, red) markers, fill indicators, market/our spread in cents.
KPI strip (equity, bankroll, PnL total/24h, unrealized, win rate, fills,
quotes), hardcode-rule card, recent trades, Start/Pause/Exit-all controls,
PAPER/LIVE/PAUSE/HALT badges, 2s auto-refresh, Ukrainian localization.
Old dashboard kept as app/static/index_legacy.html.

## 5. Carried from v1.0.146-147
- Liquidation oversell fix (force=True), LIVE dust FAK-spam guard,
  force-cancel on shutdown/pause/market-drop
- Limitless adapter (app/services/limitless_client.py) + EXCHANGE selector

## Tests
138 passed, 4 skipped, 0 failed.
