# CHANGELOG v1.0.153 — Максимальне витягування профіту (еталон + хардкод)

Вхід: TASK v1.0.153 (Sonnet 5 / Jiji) + аналіз GLM. Виміряна проблема:
снайпер v1.0.150 з порогом 0.5¢ капчурив у середньому 2.05¢ з досяжних
5.6¢ (37%) і платив taker-комісію за кожен ранній вихід (витрати 27.9% PnL).

## Нове

- **app/services/profit_capture.py** — хардкод-модуль виходу (за зразком
  spread_invariant.py; константи module-level, поза config/.env):
  свіжа позиція (≤5 хв) вимагає від біда ≥70% досяжного максимуму
  (hardcode_ask − entry), планка лінійно спадає до 0% на 30-й хвилині,
  абсолютна підлога 0.3¢. Снайпер-тригер: net-профіт від біда (з taker-fee)
  ≥ sniper_threshold_cents(achievable_max, age).
- Лог пострілу: `sniper_fired` з achievable_max_cents, taken_pct, age_sec.
- Метрика **Капчур %** (середній taken_pct) + **частка ask-філів (Path A)**
  серед виходів — у /api/quotes, /api/dashboard і панелі «Витрати»
  (ціль еталону: капчур ≥60%).
- PROFIT_TAKE_MIN_CENTS — deprecated, з логіки видалений (поле в config
  лишилось, щоб старі .env не ламали старт).

## Фікси (GLM P0/P1)

- VERSION → 1.0.153 (був застарілий 1.0.145) + тест
  `version_matches_changelog`.
- PAPER-газ приведено до реальності Base: PAPER_GAS_COST_USDC 0.01 → 0.001
  (.env + дефолт config).
- `sell_fill_skipped_no_tokens`: ask-філ у PAPER більше не «намагається і
  скаржиться» на флеті — guard net_tokens > ε перед спробою.
- Банкрол після рестарту перераховується з першооснов:
  bankroll = starting_balance + Σ realized − Σ fees − Σ(net_tokens×entry)
  (лог `bankroll_recomputed_on_restore` при розходженні) — тепер
  bankroll+позиції == еквіті до рестарту.

## Тести

- 8 нових: планка 70% (не стріляє на 40%, стріляє на 75%), інтерполяція
  ~35% на 15-й хв, вік >30 хв → бере ≥0.3¢, MIN_ABS_PROFIT-підлога,
  sabotage-тест (config не впливає на константи), version-тест,
  банкрол-інваріант при рестарті.
