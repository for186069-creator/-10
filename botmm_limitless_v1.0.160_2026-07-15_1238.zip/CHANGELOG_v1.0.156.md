# CHANGELOG v1.0.156 — Повна прозорість: позиції, ордери, історія

(+ у цьому ж релізі: bid-based фікс drawdown-стопу — див. нижче.)

## Панелі дашборда

1. **«Відкриті позиції»** (над котируваннями): токени, entry, вартість,
   mid, unrealized ($ і ¢/токен), вік, TTR, ціна флор-аска і бейджі стану
   захистів у реальному часі: 🧱floor / ⏸mom / 🚫dd / ⏳pre-res / hedged.
   Підсумковий рядок: Σ вартість, Σ unrealized, % капіталу в позиціях.
2. **«Відкриті ордери»**: КОЖЕН живий ордер окремим рядком — бік, рівень,
   ціна, розмір ($ і токени), fill % (партіали видно одразу — нові поля
   bid_fill_pct/ask_fill_pct на ActiveQuote), вік, тип
   (hardcode-quote / floor-ask), Order ID.
3. **«Всі угоди»**: пагінація 50/стор. по всій mm_trades (старий ліміт
   100 прибрано), нові колонки ¢/токен, Fee $, Gas $, Шлях виходу,
   Тривалість трипа; фільтри (ринок/бік/шлях/збиткові/taker);
   кнопка **CSV** → GET /api/trades/export.csv (вся історія, всі колонки).
4. Хедер: «Позицій: N ($X) · Ордерів: M».

## API

- /api/dashboard: + positions_detail[], open_orders[] (без обрізання).
- GET /api/trades: пагінація + фільтри (page, per_page, market, side,
  loss_only, taker_only, exit_path) + trip_sec для SELL.
- GET /api/trades/export.csv — той самий набір фільтрів.
- mm_trades: нова колонка exit_path (quote_bid / ask_fill / PROFIT_SNIPER /
  AGGRESSIVE / URGENT / CRITICAL / NO_HEDGE / SETTLEMENT) — тегується в
  _record_fill з усіх шляхів виходу.

## Фікс drawdown-стопу (виявлено користувачем на живому скріні)

Умова рахувалась від mid: на розірваній книзі (bid 0.049/ask 0.108)
самотній високий ask завищував mid і присипляв стоп при позиції −4.8¢
до реального виходу. Тепер drawdown міряється від realistic exit
(best_bid + тік) — узгоджено з рештою коду (BUG-N34). Регрес-тест на
живий кейс доданий.

## Тести

182 passed: +4 v156 (бейджі позицій, fill% ордерів, CSV-рядки == COUNT,
loss-фільтр) + 1 регрес drawdown + 7 v155.
