# HANDOFF: Limitless Exchange Adapter — v1.0.147-preview

**From:** Claude (2026-07-11)
**To:** GLM / Codex (implementation) + Jiji (decisions)
**Project:** botmm — Polymarket MM Bot Pro → multi-exchange

---

## 0. TL;DR

Polymarket is blocked in Ukraine (ISP-level block, Jan 2026, PlayCity/NKEK).
**Limitless Exchange (Base) is the best migration target:**

| | Polymarket | Limitless |
|---|---|---|
| Ukraine access | ❌ blocked by Ukraine registry | ✅ not restricted |
| Min order | **$5 hard** (root of dust problem) | **no documented hard minimum** (safety floor $1 in config) |
| Maker fees | ~0 + rewards | **0 — makers pay NOTHING** + maker rebates + LP rewards |
| Taker fees | low | 0.40–3.00% buy / 0.42–1.50% sell (bot is maker → irrelevant) |
| Order model | CTF EIP-712 CLOB | **same CTF EIP-712 CLOB** (official Polymarket migration guide exists!) |
| Market cadence | days-months to resolution | **hourly/daily markets** → fast capital turnover, ideal for $20-30 bankroll |
| Python SDK | py-clob-client (**V1 ARCHIVED May 2026 — botmm uses 0.34.6 = likely broken vs prod!**) | official `limitless-sdk` on PyPI |
| Testnet | none | none — first run = real USDC, start tiny |
| Post-only | yes | yes (GTC), plus STP policies |
| Chain/collateral | Polygon / pUSD (V2) | Base / USDC |

**CRITICAL SIDE FINDING:** per Limitless's migration guide, Polymarket V1
clients (incl. `py-clob-client`) were archived May 2026 and no longer work
against production. botmm pins `py-clob-client==0.34.6`. Even ignoring the
Ukraine block, botmm's LIVE path vs Polymarket needs V2 migration. This
makes the Limitless port MORE attractive, not less.

## 1. What Claude already implemented (in this archive)

1. `app/services/limitless_client.py` — **LimitlessService**, drop-in
   mirror of ClobService's public interface. MM core unchanged.
   - HMAC auth (lmts-* headers) per official docs
   - EIP-712 order signing (domain "Limitless CTF Exchange" v1, Base 8453,
     per-market venue.exchange as verifyingContract)
   - GTC/FAK/FOK + postOnly, stpPolicy=cancel_taker (bid/ask self-trade guard)
   - feeRateBps from profile rank (required on fee-bearing markets)
   - ownerId from /profiles/me (required on every order)
   - REST orderbook polling (WS Socket.IO = later upgrade)
   - 425/503 (receive-window / maintenance) handling
2. `app/core/config.py` — `exchange` selector + limitless_* fields
3. `app/main.py` — adapter selection at startup
4. `tests/unit/test_limitless_adapter.py` — 6 tests (auth format, amount
   math vs docs example, PAPER mode). Full suite: 125 passed.

## 2. What remains (GLM/Codex tasks, priority order)

1. **Live smoke test** (Jiji + GLM, ~$3-5 USDC on Base):
   deposit → discover_markets → verify raw payload field names marked
   UNVERIFIED in code (`feeBearing`, orderbook shape, /portfolio/allowance
   response, user-orders shape) → place 1 post-only GTC far from mid →
   cancel → 1 tiny round trip.
2. **Bankroll sync mapping**: adapt `sync_bankroll_from_wallet()` to
   /portfolio/allowance response (field names TBD from smoke test).
3. **Redeem/resolution**: Limitless resolves hourly/daily — reconcile loop
   must call POST /portfolio/redeem (see docs) or use SDK redeem_all.
   Polymarket relied on on-chain settle; here redemption is an explicit call
   and needs Base ETH for gas (tiny). ADD: gas balance check + alert.
4. **Fill polling**: map `poll_orders` LIVE path to
   POST /orders/status/batch (statuses UNMATCHED/MATCHED/MINED/CONFIRMED/
   FAILED/DELAYED/CANCELED). Treat MINED/CONFIRMED as filled; DELAYED =
   taker-delay hold (postOnly orders are never delayed → mostly N/A for us).
5. **Market picker calibration**: hourly BTC/ETH markets have different
   spread/volatility profile than Polymarket sport niches. A-S params
   (gamma, k), spread_min_cents, TTR filters need PAPER re-calibration
   against real Limitless books (PAPER mode works with the new adapter
   since book polling is exchange-real, fills simulated).
6. **WS upgrade (optional)**: Socket.IO /markets namespace via
   python-socketio, HMAC during handshake. Only after profitable REST v1.
7. **Dust config**: when exchange=limitless set
   `dust_threshold_usdc = limitless_min_order_usdc` (=1.0). The $5 dust
   architecture stays as protection but rarely triggers.

## 3. Predict.fun — evaluated, second choice

- BNB Chain, **USDT collateral, 18 decimals (wei!)** — amount math differs
- **HAS TESTNET** (api-testnet.predict.fun, no API key needed) — the one
  big advantage over Limitless
- API key required for mainnet; JWT for order actions; fees exist for
  makers too (feeRateBps per market)
- Larger volume than Limitless ($579M vs $205M April taker volume)
- Verdict: viable Phase-2 diversification target. Limitless first because:
  zero maker fees, USDC 1e6 math identical to Polymarket, official
  migration guide, and same-shape CTF orders = least code risk.

## 4. Do NOT touch

Everything from previous handoffs: MM core logic, dust logic v1.0.144-146,
liquidation tiers, PnL, bankroll sync architecture. The adapter isolates
100% of exchange differences.

## 5. Suggested rollout

PAPER on Limitless books 3-5 days (calibrate) → LIVE $10-20 post-only,
1-2 markets, partial_fill_no_cancel=true → review logs 48h → scale per
existing phase plan. Maker rebates + LP rewards may add meaningful yield
at small size — investigate qualification thresholds (per-market min size
for rewards, e.g. 100 shares, applies to REWARDS only, not order placement).
