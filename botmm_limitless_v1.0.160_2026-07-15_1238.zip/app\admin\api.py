"""
app/admin/api.py — Admin REST endpoints.

All endpoints are prefixed /api. Includes:
  - Dashboard / inventory / quotes / markets / trades
  - Config get/set
  - Risk control: start/pause/resume/emergency_stop
  - Mode toggle: paper <-> live (with checklist)
  - Diagnostics: 8-point health check
  - Live checklist: 8-point readiness check
  - Analytics: by_market, time_series

Authentication: NONE. This server is intended for local use only (binds to
127.0.0.1 by default). Exposing to internet requires adding auth.
"""
from __future__ import annotations

import time
from datetime import datetime, timedelta, timezone
from typing import Any

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import case, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.db import get_db
from app.core.logging import get_logger
from app.db.models import HaltEvent, Quote, Side, Trade

log = get_logger(__name__)

admin_router = APIRouter(tags=["admin"])
root_router = APIRouter(tags=["root"])

# Injected at startup (main.py)
_clob = None
_inventory = None
_mm = None
_risk = None
_analytics = None
_alerter = None
_arb_scanner = None  # v1.0.84


def inject_services(clob, inventory, mm, risk, analytics, alerter) -> None:
    global _clob, _inventory, _mm, _risk, _analytics, _alerter, _arb_scanner
    _clob = clob
    _inventory = inventory
    _mm = mm
    _risk = risk
    _analytics = analytics
    _alerter = alerter
    # v1.0.84: inject arb_scanner (imported lazily to avoid circular import)
    try:
        from app.services.arbitrage_scanner import arb_scanner
        _arb_scanner = arb_scanner
    except Exception:
        _arb_scanner = None


def _require_services() -> None:
    if not all([_clob, _inventory, _mm, _risk]):
        raise HTTPException(503, "Bot not initialized")


# ═══════════════════════════════════════════════════════════════════════
# Dashboard
# ═══════════════════════════════════════════════════════════════════════


@admin_router.get("/dashboard")
async def dashboard(db: AsyncSession = Depends(get_db)):
    """Main dashboard: P&L, win rate, active quotes, markets.

    v1.0.49 FIX (BUG-16): previously loaded ALL trades from DB just to
    compute summary stats. Now uses SQL aggregates for totals + loads
    only last 500 trades for round-trip analysis (win rate, drawdown).
    This keeps dashboard fast even with thousands of trades.
    """
    _require_services()
    # FIX: use naive UTC for SQLite comparison (SQLite stores naive datetimes;
    # comparing with timezone-aware raises TypeError in Python 3.12)
    cutoff = datetime.utcnow() - timedelta(hours=24)

    # v1.0.49 (BUG-16): SQL aggregates for totals (fast, no ORM loading)
    from sqlalchemy import case as sql_case

    total_row = await db.execute(
        select(func.count(Trade.id), func.sum(Trade.pnl_usdc), func.sum(Trade.fees_usdc))
    )
    total_count, total_pnl, total_fees = total_row.one()
    total_count = total_count or 0
    total_pnl = float(total_pnl or 0.0)
    total_fees = float(total_fees or 0.0)

    # SQL aggregates for 24h
    h24_row = await db.execute(
        select(func.count(Trade.id), func.sum(Trade.pnl_usdc), func.sum(Trade.fees_usdc))
        .where(Trade.timestamp >= cutoff)
    )
    h24_count, h24_pnl, h24_fees = h24_row.one()
    h24_count = h24_count or 0
    h24_pnl = float(h24_pnl or 0.0)
    h24_fees = float(h24_fees or 0.0)

    # Load only last 500 trades for round-trip analysis + recent display
    result = await db.execute(
        select(Trade).where(Trade.timestamp >= cutoff).order_by(Trade.timestamp.desc()).limit(500)
    )
    recent_trades = list(result.scalars().all())

    # Pass limited trades + SQL totals to summary
    summary = _analytics.compute_summary(
        recent_trades,
        total_count_override=total_count,
        total_pnl_override=total_pnl,
        trades_24h_override=h24_count,
        pnl_24h_override=h24_pnl,
    )

    # Inventory value at current mid.
    # v1.0.158 FIX (diagnostic §2): when the book is missing or has no live
    # quotes (dropped market, resolved market, STALE_DATA), the position used
    # to contribute NOTHING to equity — silently understating it by the whole
    # position value (observed: equity $68.77 instead of $75.85, a $7.09 hole
    # from one ETH position whose book went dark). Fall back to avg_entry:
    # conservative (never inflates), and unrealized P&L for that position is
    # then 0 rather than a fabricated loss.
    inventory_value = 0.0
    unrealized_pnl = 0.0
    for tid, inv in _inventory.inventories.items():
        if inv.net_tokens == 0:
            continue
        book = _clob.books.get(tid)
        has_live_mid = book is not None and book.best_bid > 0 and book.mid > 0
        if has_live_mid:
            inventory_value += inv.net_tokens * book.mid
            unrealized_pnl += inv.unrealized_pnl(book.mid)
        else:
            inventory_value += inv.net_tokens * inv.avg_entry_price

    total_equity = _inventory.bankroll + inventory_value

    # v1.0.152: fee/gas split + taker/maker counts for the ВИТРАТИ panel
    cost_row = await db.execute(
        select(
            func.coalesce(func.sum(Trade.fee_usdc), 0.0),
            func.coalesce(func.sum(Trade.gas_usdc), 0.0),
            func.coalesce(func.sum(case((Trade.is_taker == 1, 1), else_=0)), 0),
            func.coalesce(func.sum(case((Trade.is_taker == 0, 1), else_=0)), 0),
        )
    )
    fees_total, gas_total, taker_fills, maker_fills = cost_row.one()
    realized_pnl_total = float(total_pnl or 0.0)
    costs_total = float(fees_total) + float(gas_total)
    costs_vs_pnl_pct = (
        round(costs_total / realized_pnl_total * 100, 1)
        if realized_pnl_total > 0
        else None
    )

    return {
        "mode": "LIVE" if not settings.paper_trading else "PAPER",
        "trading_paused": _mm._trading_paused,
        # v1.0.154: true after a dirty restart until the first clean cycle
        "crash_recovery": getattr(_mm, "_crash_recovery_active", False),
        "halted": _inventory.halted,
        "halt_reason": _inventory.halt_reason,
        "bankroll_usdc": round(_inventory.bankroll, 4),
        "inventory_value_usdc": round(inventory_value, 4),
        "unrealized_pnl_usdc": round(unrealized_pnl, 4),
        "total_equity_usdc": round(total_equity, 4),
        "starting_balance_usdc": round(_inventory.starting_balance, 2),
        "daily_pnl_usdc": round(_inventory.daily_pnl, 4),
        # v1.0.73 (BUG-N24): gas/fees окремо від profit
        "total_fees_usdc": round(total_fees, 4),
        "daily_fees_usdc": round(h24_fees, 4),
        # v1.0.152: витрати — розбивка для панелі ВИТРАТИ
        "fees_total": round(float(fees_total), 4),
        "gas_total": round(float(gas_total), 4),
        "costs_total": round(costs_total, 4),
        "costs_vs_pnl_pct": costs_vs_pnl_pct,
        "taker_fill_count": int(taker_fills),
        "maker_fill_count": int(maker_fills),
        # v1.0.153: якість капчуру (профіт, забраний снайпером, % від
        # досяжного максимуму) + частка безкоштовних maker ask-виходів
        "capture_pct_avg": _mm.status.get("capture_pct_avg"),
        "sniper_fired_count": _mm.status.get("sniper_fired_count", 0),
        "ask_fill_share_pct": _mm.status.get("ask_fill_share_pct"),
        # v1.0.156: панелі прозорості — нічого не обрізаємо
        "positions_detail": _build_positions_detail(_mm, _inventory, _clob),
        "open_orders": _build_open_orders(_mm, _inventory, _clob),
        "consecutive_losses": _inventory.consecutive_losses,
        "max_inventory_usdc": round(_inventory.max_inventory_usdc(), 2),
        "active_markets": len(_clob.books),
        "active_quotes": sum(len(qs) for qs in _mm.active_quotes.values()),
        "cycle_count": _mm._cycle_count,
        "fill_count": _mm._fill_count,
        "round_trip_count": _mm._round_trip_count,
        "liquidation_count": getattr(_mm, "_liquidation_count", 0),  # v1.0.38
        "ws_age_sec": round(_clob.last_ws_msg_age, 1),
        "summary": summary,
        "recent_trades": [
            {
                "id": t.id,
                "market": t.market_name[:40],
                "side": t.side.value,
                "price": t.price,
                "size_usdc": t.size_usdc,
                "pnl": t.pnl_usdc,
                # v1.0.152: per-fill cost (fee + gas) for the trades table
                "fee": round((t.fee_usdc or 0.0) + (t.gas_usdc or 0.0), 4),
                "is_taker": bool(t.is_taker),
                "level": t.level,
                "is_hedge": t.is_hedge,
                "timestamp": t.timestamp.isoformat() if t.timestamp else None,
            }
            for t in recent_trades[:20]
        ],
    }


# ── v1.0.156: transparency panels — pure builders (unit-testable) ────────


def _build_positions_detail(mm, inventory, clob) -> list[dict]:
    """One row per open position with live protection badges."""
    now_ts = datetime.now(timezone.utc).timestamp()
    now_mono = time.monotonic()
    rows: list[dict] = []
    for tid, inv in inventory.inventories.items():
        if abs(inv.net_tokens) < 1e-9:
            continue
        book = clob.books.get(tid)
        mid = book.mid if book and book.best_bid > 0 else None
        info = clob.markets.get(tid)
        ttr_sec = (
            info.end_date_ts - now_ts
            if info and info.end_date_ts > 0
            else None
        )
        entry = inv.avg_entry_price
        floor_px = round(entry + 0.001, 4)
        floor_ask = None
        for q in mm.active_quotes.get(tid, []):
            if q.ask_price is not None and abs(q.ask_price - floor_px) < 1e-9:
                floor_ask = q.ask_price
                break
        unreal = (mid - entry) * inv.net_tokens if mid is not None else None
        rows.append({
            "token_id": tid[:12],
            "market": (info.question[:40] if info else (inv.market_name or tid[:12])),
            "net_tokens": round(inv.net_tokens, 4),
            "avg_entry": round(entry, 4),
            "cost_at_entry": round(inv.net_tokens * entry, 4),
            "mid": round(mid, 4) if mid is not None else None,
            "unrealized_usd": round(unreal, 4) if unreal is not None else None,
            "unrealized_cents_per_token": (
                round((mid - entry) * 100, 2) if mid is not None else None
            ),
            "age_sec": round(now_mono - inv.open_time, 0) if inv.open_time else None,
            "ttr_sec": round(ttr_sec, 0) if ttr_sec is not None else None,
            "floor_ask": floor_ask,
            "badges": {
                "floor": floor_ask is not None,
                "mom": tid in getattr(mm, "_momentum_bid_blocked", set()),
                "dd": tid in getattr(mm, "_drawdown_stopped", set()),
                "pre_res": (
                    ttr_sec is not None
                    and ttr_sec < settings.pre_resolution_exit_sec
                ),
                "hedged": tid in getattr(mm, "_hedged_positions", set()),
            },
        })
    return rows


def _build_open_orders(mm, inventory, clob) -> list[dict]:
    """Every live order (bid/ask of every level) as its own row."""
    now = time.monotonic()
    rows: list[dict] = []
    for tid, quotes in mm.active_quotes.items():
        info = clob.markets.get(tid)
        name = info.question[:40] if info else tid[:12]
        inv = inventory.inventories.get(tid)
        floor_px = (
            round(inv.avg_entry_price + 0.001, 4)
            if inv and inv.net_tokens > 0
            else None
        )
        for q in quotes:
            age = round(now - q.placed_at, 1)
            if q.bid_price is not None:
                rows.append({
                    "market": name, "side": "BUY", "level": q.level,
                    "price": round(q.bid_price, 4),
                    "size_usdc": round(q.size_usdc, 2),
                    "size_tokens": round(q.size_usdc / max(q.bid_price, 0.001), 2),
                    "fill_pct": round(
                        q.bid_fill_pct if q.bid_fill_pct else (1.0 if q.bid_filled else 0.0), 2
                    ),
                    "age_sec": age,
                    "type": "hardcode-quote",
                    "order_id": (q.bid_order_id or "paper")[:12],
                })
            if q.ask_price is not None:
                is_floor = floor_px is not None and abs(q.ask_price - floor_px) < 1e-9
                rows.append({
                    "market": name, "side": "SELL", "level": q.level,
                    "price": round(q.ask_price, 4),
                    "size_usdc": round(q.size_usdc, 2),
                    "size_tokens": round(q.size_usdc / max(q.ask_price, 0.001), 2),
                    "fill_pct": round(
                        q.ask_fill_pct if q.ask_fill_pct else (1.0 if q.ask_filled else 0.0), 2
                    ),
                    "age_sec": age,
                    "type": "floor-ask" if is_floor else "hardcode-quote",
                    "order_id": (q.ask_order_id or "paper")[:12],
                })
    return rows


def _trade_row_passes(row: dict, *, market: str = "", side: str = "",
                      loss_only: bool = False, taker_only: bool = False,
                      exit_path: str = "") -> bool:
    """Shared filter predicate (endpoint + CSV export)."""
    if market and market.lower() not in (row.get("market") or "").lower():
        return False
    if side and row.get("side") != side:
        return False
    if loss_only and not ((row.get("pnl") or 0) < -1e-9):
        return False
    if taker_only and not row.get("is_taker"):
        return False
    if exit_path and row.get("exit_path") != exit_path:
        return False
    return True


def _trades_to_csv(rows: list[dict]) -> str:
    import csv as _csv
    import io as _io

    cols = ["id", "timestamp", "market", "side", "level", "price",
            "size_usdc", "size_tokens", "pnl", "pnl_cents_per_token",
            "fee", "gas", "is_taker", "exit_path", "mode"]
    buf = _io.StringIO()
    w = _csv.DictWriter(buf, fieldnames=cols, extrasaction="ignore")
    w.writeheader()
    for r in rows:
        w.writerow(r)
    return buf.getvalue()


def _serialize_trade(t) -> dict:
    tokens = t.size_tokens or 0.0
    return {
        "id": t.id,
        "timestamp": t.timestamp.isoformat() if t.timestamp else None,
        "market": t.market_name[:40],
        "side": t.side.value,
        "level": t.level,
        "price": t.price,
        "size_usdc": t.size_usdc,
        "size_tokens": round(tokens, 4),
        "pnl": t.pnl_usdc,
        "pnl_cents_per_token": (
            round(t.pnl_usdc / tokens * 100, 2)
            if t.pnl_usdc is not None and tokens > 0 else None
        ),
        "fee": round(t.fee_usdc or 0.0, 4),
        "gas": round(t.gas_usdc or 0.0, 4),
        "is_taker": bool(t.is_taker),
        "exit_path": t.exit_path or "",
        "is_hedge": t.is_hedge,
        "mode": t.mode.value if hasattr(t.mode, "value") else str(t.mode),
        "market_id": t.market_id,
    }


@admin_router.get("/trades")
async def trades_paginated(
    page: int = 1,
    per_page: int = 50,
    market: str = "",
    side: str = "",
    loss_only: bool = False,
    taker_only: bool = False,
    exit_path: str = "",
    db: AsyncSession = Depends(get_db),
):
    """v1.0.156: full trade history — paginated + filterable."""
    per_page = max(1, min(per_page, 200))
    q = select(Trade)
    if market:
        q = q.where(Trade.market_name.ilike(f"%{market}%"))
    if side in ("BUY", "SELL"):
        q = q.where(Trade.side == (Side.BUY if side == "BUY" else Side.SELL))
    if loss_only:
        q = q.where(Trade.pnl_usdc < -1e-9)
    if taker_only:
        q = q.where(Trade.is_taker == 1)
    if exit_path:
        q = q.where(Trade.exit_path == exit_path)
    total = (await db.execute(
        select(func.count()).select_from(q.subquery())
    )).scalar() or 0
    rows_db = (await db.execute(
        q.order_by(Trade.timestamp.desc(), Trade.id.desc())
        .offset((page - 1) * per_page).limit(per_page)
    )).scalars().all()
    rows = [_serialize_trade(t) for t in rows_db]
    # trip duration for SELLs: time since the most recent earlier BUY
    for r, t in zip(rows, rows_db):
        if r["side"] == "SELL":
            prev_buy = (await db.execute(
                select(Trade.timestamp)
                .where(Trade.market_id == t.market_id,
                       Trade.side == Side.BUY,
                       Trade.timestamp <= t.timestamp)
                .order_by(Trade.timestamp.desc()).limit(1)
            )).scalar()
            if prev_buy and t.timestamp:
                r["trip_sec"] = round((t.timestamp - prev_buy).total_seconds(), 0)
    return {"total": total, "page": page, "per_page": per_page, "rows": rows}


@admin_router.get("/trades/export.csv")
async def trades_export_csv(
    market: str = "",
    side: str = "",
    loss_only: bool = False,
    taker_only: bool = False,
    exit_path: str = "",
    db: AsyncSession = Depends(get_db),
):
    """v1.0.156: the entire history as CSV (same filters as /trades)."""
    from fastapi.responses import Response

    rows_db = (await db.execute(
        select(Trade).order_by(Trade.timestamp.asc(), Trade.id.asc())
    )).scalars().all()
    rows = [
        r for r in (_serialize_trade(t) for t in rows_db)
        if _trade_row_passes(r, market=market, side=side, loss_only=loss_only,
                             taker_only=taker_only, exit_path=exit_path)
    ]
    return Response(
        content=_trades_to_csv(rows),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=botmm_trades.csv"},
    )


@admin_router.get("/inventory")
async def inventory_status():
    _require_services()
    # Add unrealized P&L per market
    status = _inventory.status
    for tid, mkt in status["markets"].items():
        book = _clob.books.get(tid)
        if book:
            inv = _inventory.get_inventory(tid)
            mkt["unrealized_pnl"] = round(inv.unrealized_pnl(book.mid), 4)
            mkt["current_mid"] = round(book.mid, 4)
            mkt["inventory_ratio"] = round(
                inv.inventory_ratio(_inventory.max_inventory_usdc()), 3
            )
    return status


@admin_router.get("/quotes")
async def active_quotes():
    _require_services()
    return _mm.status


# ═══════════════════════════════════════════════════════════════════════
# v1.0.84: Arbitrage scanner — endpoints for admin panel
# ═══════════════════════════════════════════════════════════════════════


@admin_router.get("/arb/opportunities")
async def arb_opportunities():
    """Повертає поточні arb opportunities зі сканера.

    Сканер оновлюється кожні ARB_SCAN_INTERVAL_SEC (за замовч. 5 хв).
    Якщо сканер не запущений — повертає порожній список.
    """
    if _arb_scanner is None:
        return {"opportunities": [], "count": 0, "last_scan_at": None, "enabled": False}
    return {
        "opportunities": [o.to_dict() for o in _arb_scanner.opportunities],
        "count": len(_arb_scanner.opportunities),
        "last_scan_at": _arb_scanner._last_scan_at or None,
        "enabled": True,
    }


@admin_router.post("/arb/scan")
async def arb_scan_now():
    """Примусове сканування зараз (не чекаючи інтервалу).

    Корисно для тестування — натиснув кнопку, отримав результат.
    """
    if _arb_scanner is None:
        raise HTTPException(503, "Arbitrage scanner not initialized")
    opps = await _arb_scanner.scan_once()
    return {
        "opportunities": [o.to_dict() for o in opps],
        "count": len(opps),
        "last_scan_at": _arb_scanner._last_scan_at,
    }


@admin_router.get("/markets")
async def markets():
    _require_services()
    now_ts = datetime.now(timezone.utc).timestamp()
    result = []
    for tid, book in _clob.books.items():
        info = _clob.markets.get(tid)
        inv = _inventory.inventories.get(tid)

        # Compute TTR (Time To Resolution) in hours
        ttr_hours = None
        ttr_warning = False
        if info and info.end_date_ts > 0:
            ttr_sec = info.end_date_ts - now_ts
            ttr_hours = round(ttr_sec / 3600, 1)
            # Warning if within pre_resolution_exit window
            ttr_warning = ttr_sec < settings.pre_resolution_exit_sec

        result.append(
            {
                "token_id": tid[:16],
                "question": info.question[:60] if info else "Unknown",
                "outcome": info.outcome if info else "?",
                "best_bid": round(book.best_bid, 4),
                "best_ask": round(book.best_ask, 4),
                "mid": round(book.mid, 4),
                "spread_cents": round(book.spread * 100, 2),
                "volume_24h": round(info.volume_24h, 0) if info else 0,
                "end_date": datetime.fromtimestamp(
                    info.end_date_ts, tz=timezone.utc
                ).isoformat() if info and info.end_date_ts > 0 else None,
                "ttr_hours": ttr_hours,
                "ttr_warning": ttr_warning,
                "neg_risk": book.neg_risk,
                "tick_size": book.tick_size,
                "last_update_age_sec": round(time_now() - book.last_update, 1),
                "our_inventory_tokens": round(inv.net_tokens, 4) if inv else 0,
                "our_inventory_usdc": round(inv.net_usdc_at_entry, 4) if inv else 0,
            }
        )
    return {"markets": result, "count": len(result)}


@admin_router.post("/markets/refresh_info")
async def refresh_market_info():
    _require_services()
    await _clob._fetch_market_info(list(_clob.books.keys()))
    return {"ok": True, "markets": len(_clob.markets)}


@admin_router.post("/markets/replace")
async def replace_markets(count: int = 5, force: bool = False):
    """Replace ALL current markets with new auto-picked ones.

    v1.0.52 FIX: by default, REFUSES to replace markets that have open
    inventory (would orphan positions). Pass force=true to override.
    This prevents the "equity drops to bankroll" surprise when the user
    clicks Apply without realizing it clears all books.
    """
    _require_services()

    # v1.0.52: check for open inventory before clearing
    if not force:
        open_markets = []
        for tid, inv in _inventory.inventories.items():
            if abs(inv.net_tokens) > 0.5:
                name = inv.market_name[:40] if inv.market_name else tid[:12]
                open_markets.append(f"{name} ({round(inv.net_tokens, 1)} tokens)")
        if open_markets:
            raise HTTPException(
                409,
                detail={
                    "error": "open_inventory_exists",
                    "message": (
                        f"Cannot replace markets: {len(open_markets)} market(s) have "
                        f"open positions. Replacing would orphan them (equity would "
                        f"drop to bankroll only). Use /api/markets/add instead, or "
                        f"pass force=true to override."
                    ),
                    "open_markets": open_markets,
                    "suggestion": "Use POST /api/markets/add?count=N to add markets without removing existing ones.",
                },
            )

    # Cancel all quotes
    for tid in list(_mm.active_quotes.keys()):
        await _mm._cancel_all_levels(tid)
    # Stop WS subscriptions for old markets
    old_tids = list(_clob.books.keys())
    for tid in old_tids:
        await _clob._feed.unsubscribe(tid)
    _clob.books.clear()
    _clob.markets.clear()
    _clob._feed._subscribed.clear()
    # Discover new
    old_count = settings.auto_pick_count
    settings.auto_pick_count = max(1, min(count, 20))
    try:
        infos = await _clob.discover_markets()
    finally:
        settings.auto_pick_count = old_count
    # Create fresh books for newly discovered markets
    from app.services.clob_client import MarketBook

    for info in infos:
        _clob.books[info.token_id] = MarketBook(token_id=info.token_id)
        _clob.markets[info.token_id] = info
    # Restart WS
    await _clob._feed.stop()
    await _clob._feed.start([i.token_id for i in infos])
    await _clob._refresh_all_books()
    return {"ok": True, "new_markets": len(infos)}


@admin_router.post("/markets/add")
async def add_markets(count: int = 3):
    """ADD new markets WITHOUT removing existing ones.

    Unlike /markets/replace which clears everything, this endpoint:
    1. Keeps all current markets, positions, and quotes
    2. Discovers new markets via Gamma API
    3. Adds only markets NOT already in books
    4. Subscribes WS for new markets
    5. Refreshes books

    Use this to scale up trading without losing P&L.
    """
    _require_services()
    existing_count = len(_clob.books)
    log.info("markets_add_started", existing=existing_count, requested=count)

    # Discover new markets (temporarily override count)
    old_count = settings.auto_pick_count
    settings.auto_pick_count = max(1, min(count + existing_count, 20))
    try:
        infos = await _clob.discover_markets()
    finally:
        settings.auto_pick_count = old_count

    # Add only markets NOT already in books
    from app.services.clob_client import MarketBook

    added = 0
    new_token_ids = []
    for info in infos:
        if info.token_id not in _clob.books:
            _clob.books[info.token_id] = MarketBook(token_id=info.token_id)
            _clob.markets[info.token_id] = info
            new_token_ids.append(info.token_id)
            added += 1

    if added > 0:
        # Subscribe WS for new markets (without restarting existing)
        for tid in new_token_ids:
            await _clob._feed.subscribe(tid)
        await _clob._refresh_all_books()
        log.info("markets_add_done", added=added, total=len(_clob.books))
    else:
        log.info("markets_add_no_new", existing=existing_count)

    return {
        "ok": True,
        "added": added,
        "total_markets": len(_clob.books),
        "existing_before": existing_count,
        "message": f"Added {added} new markets (total: {len(_clob.books)})" if added > 0
        else f"No new markets found (all {existing_count} already loaded)",
    }


# v1.0.156: the old limit-100 /trades endpoint was superseded by the
# paginated + filterable version above (see trades_paginated).


# ═══════════════════════════════════════════════════════════════════════
# Config
# ═══════════════════════════════════════════════════════════════════════


class ConfigUpdate(BaseModel):
    spread_cents: float | None = None
    spread_min_cents: float | None = None
    spread_max_cents: float | None = None
    order_size_usdc: float | None = None
    order_size_min_usdc: float | None = None
    max_inventory_usdc: float | None = None
    max_inventory_pct_of_bankroll: float | None = None
    requote_interval_sec: float | None = None
    requote_threshold_cents: float | None = None
    max_daily_loss_usd: float | None = None
    stop_trading_consecutive_losses: int | None = None
    as_gamma: float | None = None
    pre_resolution_exit_sec: int | None = None
    auto_pick_count: int | None = None
    auto_pick_min_volume_24h: float | None = None
    auto_pick_min_spread_cents: float | None = None
    multi_level_enabled: bool | None = None
    paper_balance_usdc: float | None = None  # Start balance for Reset Paper


@admin_router.get("/config")
async def get_config():
    return {
        "paper_trading": settings.paper_trading,
        "paper_balance_usdc": settings.paper_balance_usdc,
        "spread_cents": settings.spread_cents,
        "spread_min_cents": settings.spread_min_cents,
        "spread_max_cents": settings.spread_max_cents,
        "order_size_usdc": settings.order_size_usdc,
        "order_size_min_usdc": settings.order_size_min_usdc,
        "max_inventory_usdc": settings.max_inventory_usdc,
        "max_inventory_pct_of_bankroll": settings.max_inventory_pct_of_bankroll,
        "requote_interval_sec": settings.requote_interval_sec,
        "requote_threshold_cents": settings.requote_threshold_cents,
        "max_daily_loss_usd": settings.max_daily_loss_usd,
        "stop_trading_consecutive_losses": settings.stop_trading_consecutive_losses,
        "as_gamma": settings.as_gamma,
        "pre_resolution_exit_sec": settings.pre_resolution_exit_sec,
        "auto_pick_count": settings.auto_pick_count,
        "auto_pick_min_volume_24h": settings.auto_pick_min_volume_24h,
        "auto_pick_min_spread_cents": settings.auto_pick_min_spread_cents,
        "multi_level_enabled": settings.multi_level_enabled,
        "hedging_enabled": settings.hedging_enabled,
        "session_quoting_enabled": settings.session_quoting_enabled,
        "adverse_selection_enabled": settings.adverse_selection_enabled,
    }


@admin_router.post("/config")
async def update_config(body: ConfigUpdate):
    """Update bot configuration at runtime.

    v1.0.50 FIX (BUG-28): added validation for numeric settings. Previously
    any value was accepted (including $0 or negative), which could break
    the bot (e.g. order_size_usdc=0 → every order rejected).
    """
    _require_services()
    data = body.model_dump(exclude_none=True)

    # v1.0.50 (BUG-28): validation rules for numeric settings
    validation_rules = {
        "spread_cents": ("gt", 0, "must be > 0"),
        "spread_min_cents": ("gt", 0, "must be > 0"),
        "spread_max_cents": ("gt", 0, "must be > 0"),
        "order_size_usdc": ("ge", 5.0, "must be >= $5 (Polymarket minimum)"),
        "order_size_min_usdc": ("ge", 5.0, "must be >= $5 (Polymarket minimum)"),
        "max_inventory_usdc": ("gt", 0, "must be > 0"),
        "max_inventory_pct_of_bankroll": ("range", (0, 1), "must be 0..1"),
        "requote_interval_sec": ("gt", 0, "must be > 0"),
        "requote_threshold_cents": ("gt", 0, "must be > 0"),
        "max_daily_loss_usd": ("gt", 0, "must be > 0"),
        "stop_trading_consecutive_losses": ("ge", 1, "must be >= 1"),
        "as_gamma": ("range", (0, 5), "must be 0..5"),
        "pre_resolution_exit_sec": ("ge", 0, "must be >= 0"),
        "auto_pick_count": ("range", (1, 20), "must be 1..20"),
        "auto_pick_min_volume_24h": ("ge", 0, "must be >= 0"),
        "auto_pick_min_spread_cents": ("ge", 0, "must be >= 0"),
    }

    errors = []
    for key, value in data.items():
        if key in validation_rules:
            op, threshold, msg = validation_rules[key]
            if op == "gt" and not (value > threshold):
                errors.append(f"{key}={value}: {msg}")
            elif op == "ge" and not (value >= threshold):
                errors.append(f"{key}={value}: {msg}")
            elif op == "range":
                lo, hi = threshold
                if not (lo <= value <= hi):
                    errors.append(f"{key}={value}: {msg}")

    # Cross-field validation: spread_min <= spread_cents <= spread_max
    new_spread_min = data.get("spread_min_cents", settings.spread_min_cents)
    new_spread = data.get("spread_cents", settings.spread_cents)
    new_spread_max = data.get("spread_max_cents", settings.spread_max_cents)
    if not (new_spread_min <= new_spread <= new_spread_max):
        errors.append(
            f"spread bounds violated: spread_min_cents ({new_spread_min}) "
            f"<= spread_cents ({new_spread}) <= spread_max_cents ({new_spread_max})"
        )

    if errors:
        raise HTTPException(400, detail={"validation_errors": errors})

    for key, value in data.items():
        if hasattr(settings, key):
            setattr(settings, key, value)
            log.info("config_updated", key=key, value=value)
    return {"ok": True, "updated": list(data.keys())}


class DepositUpdate(BaseModel):
    amount_usdc: float = Field(gt=0)


@admin_router.post("/config/save_env")
async def save_config_to_env():
    """v1.0.74 (BUG-N25): Save current RAM settings to .env file.

    UI changes (POST /api/config) only update RAM — lost on restart.
    This endpoint writes current settings back to .env so they persist.

    Writes only the settings that are editable via UI + key trading params.
    Preserves comments and unknown keys in .env (line-by-line update).
    """
    import os
    from pathlib import Path

    env_path = Path(".env")
    if not env_path.exists():
        # Create new .env if missing
        env_path.write_text("# Auto-generated by v1.0.74\n")

    # Settings to persist (key=env_var_name, value=current_value)
    settings_to_save = {
        "PAPER_TRADING": str(settings.paper_trading),
        "PAPER_BALANCE_USDC": str(settings.paper_balance_usdc),
        "ORDER_SIZE_USDC": str(settings.order_size_usdc),
        "ORDER_SIZE_MIN_USDC": str(settings.order_size_min_usdc),
        "ORDER_SIZE_AUTOSCALE_MAX_MULT": str(settings.order_size_autoscale_max_mult),
        "MAX_INVENTORY_USDC": str(settings.max_inventory_usdc),
        "MAX_INVENTORY_PCT_OF_BANKROLL": str(settings.max_inventory_pct_of_bankroll),
        "INVENTORY_CLEAR_THRESHOLD": str(settings.inventory_clear_threshold),
        "SPREAD_CENTS": str(settings.spread_cents),
        "SPREAD_MIN_CENTS": str(settings.spread_min_cents),
        "SPREAD_MAX_CENTS": str(settings.spread_max_cents),
        "MULTI_LEVEL_ENABLED": str(settings.multi_level_enabled),
        "AUTO_PICK_COUNT": str(settings.auto_pick_count),
        "AUTO_PICK_MIN_SPREAD_CENTS": str(settings.auto_pick_min_spread_cents),
        "AUTO_PICK_MIN_VOLUME_24H": str(settings.auto_pick_min_volume_24h),
        "INVENTORY_LIQUIDATION_AGGRESSIVE_AGE_SEC": str(settings.inventory_liquidation_aggressive_age_sec),
        "INVENTORY_LIQUIDATION_URGENT_AGE_SEC": str(settings.inventory_liquidation_urgent_age_sec),
        "PRE_RESOLUTION_EXIT_SEC": str(settings.pre_resolution_exit_sec),
        "STALE_DATA_THRESHOLD_SEC": str(settings.stale_data_threshold_sec),
        "PAPER_REJECTION_RATE": str(settings.paper_rejection_rate),
        "PAPER_COMPETITION_RATE": str(settings.paper_competition_rate),
        "PAPER_FILL_PROB_BASE": str(settings.paper_fill_prob_base),
        "PAPER_FILL_PROB_MAX": str(settings.paper_fill_prob_max),
        "PAPER_ADVERSE_DRIFT_MIN": str(settings.paper_adverse_drift_min),
        "PAPER_ADVERSE_DRIFT_MAX": str(settings.paper_adverse_drift_max),
        "PAPER_GAS_COST_USDC": str(settings.paper_gas_cost_usdc),
        "LIVE_GAS_COST_USDC": str(settings.live_gas_cost_usdc),
    }

    # Read existing .env
    lines = env_path.read_text(encoding="utf-8").splitlines()
    saved_keys: set[str] = set()
    new_lines: list[str] = []

    for line in lines:
        stripped = line.strip()
        # Skip comments and empty lines
        if not stripped or stripped.startswith("#"):
            new_lines.append(line)
            continue
        # Parse KEY=VALUE
        if "=" in stripped:
            key = stripped.split("=", 1)[0].strip()
            if key in settings_to_save:
                new_value = settings_to_save[key]
                new_lines.append(f"{key}={new_value}")
                saved_keys.add(key)
            else:
                # Keep unknown keys (auth, telegram, etc.)
                new_lines.append(line)
        else:
            new_lines.append(line)

    # Add any settings not already in .env
    for key, value in settings_to_save.items():
        if key not in saved_keys:
            new_lines.append(f"{key}={value}")

    # Write back
    env_path.write_text("\n".join(new_lines) + "\n", encoding="utf-8")

    log.info(
        "config_saved_to_env",
        settings_count=len(settings_to_save),
        env_path=str(env_path),
    )
    return {
        "ok": True,
        "saved": len(settings_to_save),
        "message": f"Saved {len(settings_to_save)} settings to .env — will persist on restart",
    }


@admin_router.post("/config/deposit")
async def set_deposit(body: DepositUpdate):
    """Set paper balance (PAPER mode only).

    Updates both:
    1. settings.paper_balance_usdc (so Reset Paper uses new value)
    2. _inventory.bankroll + starting_balance (immediate effect)

    v1.0.46 FIX (BUG-15): also resets daily_pnl + consecutive_losses, so
    the dashboard "Daily P&L" reflects the new session, not the old one.
    Without this, a user depositing from $10 → $50 would see daily_pnl
    that was computed against the old $10 bankroll.
    """
    if not settings.paper_trading:
        raise HTTPException(400, "Cannot set deposit in LIVE mode")
    # Update settings so Reset Paper uses new value
    settings.paper_balance_usdc = body.amount_usdc
    # Update current bankroll immediately
    _inventory.bankroll = body.amount_usdc
    _inventory.starting_balance = body.amount_usdc
    # v1.0.46 (BUG-15): reset risk counters so they reflect the new session
    _inventory.daily_pnl = 0.0
    _inventory.consecutive_losses = 0
    log.info("deposit_set", amount=body.amount_usdc, source="api")
    return {"ok": True, "bankroll": _inventory.bankroll}


# ═══════════════════════════════════════════════════════════════════════
# Trading control
# ═══════════════════════════════════════════════════════════════════════


@admin_router.post("/start")
async def start_trading():
    _require_services()
    if _mm.is_trading:
        return {"started": False, "message": "Already trading"}
    _mm.start_trading()
    return {"started": True, "message": "Trading STARTED — placing quotes"}


@admin_router.post("/pause")
async def pause_trading():
    _require_services()
    active = sum(len(qs) for qs in _mm.active_quotes.values())
    _mm.stop_trading()
    return {"paused": True, "orders_canceled": active}


@admin_router.post("/risk/resume")
async def resume_trading():
    _require_services()
    if not _inventory.halted:
        return {"resumed": False, "message": "Not halted"}
    prev = _risk.resume(preserve_counters=False)
    return {"resumed": True, "previous_reason": prev}


@admin_router.post("/emergency_stop")
async def emergency_stop():
    """v1.0.49 FIX (BUG-20): count actual orders canceled, not markets.

    Previously: `canceled += 1` per market — but each market can have
    up to 6 orders (3 levels × 2 sides). The returned `orders_canceled`
    was actually market count, misleading the user.
    """
    _require_services()
    markets_affected = 0
    orders_canceled = 0
    for tid in list(_mm.active_quotes.keys()):
        quotes = _mm.active_quotes.get(tid, [])
        # Count actual orders (each quote level can have bid + ask)
        level_orders = 0
        for q in quotes:
            if q.bid_order_id:
                level_orders += 1
            if q.ask_order_id:
                level_orders += 1
        orders_canceled += level_orders
        markets_affected += 1
        await _mm._cancel_all_levels(tid)
    _risk.emergency_stop()
    await _alerter.send(
        "critical",
        "EMERGENCY STOP",
        f"Manual kill switch triggered. {orders_canceled} orders canceled across {markets_affected} markets.",
        alert_key="emergency_stop",
    )
    return {
        "stopped": True,
        "orders_canceled": orders_canceled,
        "markets_affected": markets_affected,
        "message": "🛑 EMERGENCY STOP — all orders canceled, trading halted",
    }


@admin_router.post("/exit_all")
async def exit_all(
    min_profit_cents: float = 0.5,
    timeout_sec: int = 60,
    accept_loss: bool = False,
):
    """v1.0.52: Exit all positions — sell tokens, ideally at profit.

    Use case: user wants to stop trading and withdraw funds from wallet.
    This endpoint:
      1. Pauses trading (no new quotes placed)
      2. Cancels all active quotes
      3. For each long position:
         a. If market_bid >= avg_entry + min_profit_cents → SELL at bid (profit)
         b. Else → place SELL limit at avg_entry + min_profit_cents
         c. Wait up to timeout_sec for fill
         d. If not filled and accept_loss=True → SELL at market_bid (loss)
         e. If not filled and accept_loss=False → leave position (skip)
      4. Returns summary of what was sold / what remains

    Args:
        min_profit_cents: minimum profit above entry (default 0.5¢)
        timeout_sec: max wait per position for limit fill (default 60s)
        accept_loss: if True, sell at market_bid when limit doesn't fill
                     (default False — leave position if can't sell in profit)

    Returns:
        {
            "paused": true,
            "positions_to_exit": N,
            "sold": [...],
            "remaining": [...],
            "total_realized": X.XX
        }
    """
    _require_services()
    import asyncio

    # 1. Pause trading
    _mm.stop_trading()
    # Cancel all active quotes
    for tid in list(_mm.active_quotes.keys()):
        await _mm._cancel_all_levels(tid)
    await asyncio.sleep(1)  # let cancels settle

    # 2. Collect positions to exit (only longs — we can only sell what we own)
    positions_to_exit = []
    skipped_positions = []
    for tid, inv in list(_inventory.inventories.items()):
        if inv.net_tokens > 0.01:  # v1.0.86: знижено з 0.5 → 0.01 (раніше $1.86 зависало)
            book = _clob.books.get(tid)
            if not book or book.best_bid <= 0:
                skipped_positions.append({
                    "market": (inv.market_name or tid[:12])[:40],
                    "net_tokens": round(inv.net_tokens, 4),
                    "reason": "no order book or best_bid=0 (market may be closed)",
                })
                log.warning(
                    "exit_all_skip_no_book",
                    token_id=tid[:12],
                    market=(inv.market_name or "")[:40],
                    net_tokens=round(inv.net_tokens, 4),
                    reason="best_bid=0 or no book",
                )
                continue  # no book → can't sell
            positions_to_exit.append({
                "token_id": tid,
                "net_tokens": inv.net_tokens,
                "avg_entry": inv.avg_entry_price,
                "market_bid": book.best_bid,
                "market_ask": book.best_ask,
                "market_name": inv.market_name or tid[:12],
            })

    if not positions_to_exit:
        return {
            "paused": True,
            "positions_to_exit": 0,
            "sold": [],
            "remaining": [],
            "skipped": skipped_positions,  # v1.0.86: показуємо чому skipped
            "total_realized": 0.0,
            "message": (
                "No long positions to exit (or all skipped). Trading paused. "
                f"Skipped: {len(skipped_positions)}."
            ),
        }

    sold = []
    remaining = []
    total_realized = 0.0

    for pos in positions_to_exit:
        tid = pos["token_id"]
        tokens = pos["net_tokens"]
        avg_entry = pos["avg_entry"]
        market_bid = pos["market_bid"]
        market_ask = pos["market_ask"]
        market_name = pos["market_name"]

        # v1.0.65 (BUG-N16): Exit All pricing — A + C priority.
        # OLD (v1.0.64): target_price = entry + 0.5¢ (hardcoded)
        #   → Sold at 0.194 when mid was 0.322 → lost $3.21 unrealized profit.
        # NEW (v1.0.65):
        #   PRIORITY A (mid capture): target = mid (best available price)
        #   PRIORITY C (entry+5¢ floor): target >= entry + 5¢ (was 0.5¢)
        #   Final target = max(mid, entry + 5¢), capped at ask - 0.001
        # This captures unrealized profit when spread is wide.
        mid = (market_bid + market_ask) / 2.0 if market_ask > market_bid else market_bid
        # A: mid-based target (capture unrealized profit)
        target_mid = round(mid, 4)
        # C: entry + 5¢ floor (raised from 0.5¢ — bigger profit buffer)
        target_min = round(avg_entry + 0.05, 4)
        # Take the LARGER of A and C — never sell below entry+5¢
        target_price = max(target_mid, target_min)
        # Clamp: not above ask - 0.001 (would never fill), not below 0.01
        target_price = max(0.01, min(0.99, target_price))
        if market_ask > 0:
            target_price = min(target_price, round(market_ask - 0.001, 4))

        # Decision: can we sell at target right now?
        can_sell_at_profit = market_bid >= target_price

        if can_sell_at_profit:
            # Sell immediately at market_bid (FAK — take what we can)
            sell_price = market_bid
            size_usdc = tokens * sell_price
            log.info(
                "exit_all_sell_at_profit",
                market=market_name[:40],
                tokens=round(tokens, 4),
                avg_entry=round(avg_entry, 4),
                sell_price=round(sell_price, 4),
                profit_cents=round((sell_price - avg_entry) * 100, 2),
                size_usdc=round(size_usdc, 2),
                mid=round(mid, 4),
                target_price=round(target_price, 4),
            )
            if settings.paper_trading:
                await _mm._record_fill(
                    tid, "SELL", sell_price, size_usdc, market_name,
                    level=99, is_liquidation=True,
                )
                realized = (sell_price - avg_entry) * tokens
                total_realized += realized
                sold.append({
                    "market": market_name[:40],
                    "tokens": round(tokens, 4),
                    "sell_price": round(sell_price, 4),
                    "profit_cents": round((sell_price - avg_entry) * 100, 2),
                    "realized": round(realized, 4),
                })
            else:
                result = await _clob.place_order(
                    tid, "SELL", sell_price, size_usdc,
                    order_type="FAK", post_only=False,
                )
                if result.success:
                    await _mm._record_fill(
                        tid, "SELL", sell_price, size_usdc, market_name,
                        level=99, is_liquidation=True,
                    )
                    realized = (sell_price - avg_entry) * tokens
                    total_realized += realized
                    sold.append({
                        "market": market_name[:40],
                        "tokens": round(tokens, 4),
                        "sell_price": round(sell_price, 4),
                        "profit_cents": round((sell_price - avg_entry) * 100, 2),
                        "realized": round(realized, 4),
                    })
                else:
                    remaining.append({
                        "market": market_name[:40],
                        "tokens": round(tokens, 4),
                        "avg_entry": round(avg_entry, 4),
                        "reason": f"FAK sell failed: {result.error}",
                    })
        else:
            # Can't sell at target now — try limit order + wait
            log.info(
                "exit_all_limit_sell_placed",
                market=market_name[:40],
                tokens=round(tokens, 4),
                target_price=round(target_price, 4),
                market_bid=round(market_bid, 4),
                mid=round(mid, 4),
                target_mid=round(target_mid, 4),
                target_min=round(target_min, 4),
                waiting_sec=timeout_sec,
            )
            if settings.paper_trading:
                # PAPER: simulate — check if price moves up to target in timeout
                # For simplicity, just sell at target (assume it fills)
                # In real LIVE, this would be a limit order waiting for fill.
                sell_price = target_price
                size_usdc = tokens * sell_price
                await asyncio.sleep(min(timeout_sec, 2))  # brief sim wait
                await _mm._record_fill(
                    tid, "SELL", sell_price, size_usdc, market_name,
                    level=99, is_liquidation=True,
                )
                realized = (sell_price - avg_entry) * tokens
                total_realized += realized
                sold.append({
                    "market": market_name[:40],
                    "tokens": round(tokens, 4),
                    "sell_price": round(sell_price, 4),
                    "profit_cents": round((sell_price - avg_entry) * 100, 2),
                    "realized": round(realized, 4),
                    "note": "PAPER simulated limit fill (mid+5¢ target)",
                })
            else:
                # LIVE: place limit SELL, wait, check fill
                size_usdc = tokens * target_price
                result = await _clob.place_order(
                    tid, "SELL", target_price, size_usdc,
                    order_type="GTC", post_only=True,
                )
                if not result.success:
                    remaining.append({
                        "market": market_name[:40],
                        "tokens": round(tokens, 4),
                        "avg_entry": round(avg_entry, 4),
                        "reason": f"limit sell failed: {result.error}",
                    })
                    continue

                order_id = result.order_id
                # Wait for fill (poll)
                filled = False
                for _ in range(int(timeout_sec / 3)):
                    await asyncio.sleep(3)
                    inv_now = _inventory.get_inventory(tid)
                    if inv_now.net_tokens < 0.5:
                        filled = True
                        break
                if filled:
                    realized = (target_price - avg_entry) * tokens
                    total_realized += realized
                    sold.append({
                        "market": market_name[:40],
                        "tokens": round(tokens, 4),
                        "sell_price": round(target_price, 4),
                        "profit_cents": round((target_price - avg_entry) * 100, 2),
                        "realized": round(realized, 4),
                    })
                else:
                    # Not filled — cancel limit order
                    await _clob.cancel_order(order_id)
                    if accept_loss:
                        # Sell at market_bid (accept loss)
                        sell_price = market_bid
                        size_usdc = tokens * sell_price
                        log.warning(
                            "exit_all_force_sell_at_loss",
                            market=market_name[:40],
                            sell_price=round(sell_price, 4),
                            loss_cents=round((avg_entry - sell_price) * 100, 2),
                        )
                        result2 = await _clob.place_order(
                            tid, "SELL", sell_price, size_usdc,
                            order_type="FAK", post_only=False,
                        )
                        if result2.success:
                            await _mm._record_fill(
                                tid, "SELL", sell_price, size_usdc, market_name,
                                level=99, is_liquidation=True,
                            )
                            realized = (sell_price - avg_entry) * tokens
                            total_realized += realized
                            sold.append({
                                "market": market_name[:40],
                                "tokens": round(tokens, 4),
                                "sell_price": round(sell_price, 4),
                                "profit_cents": round((sell_price - avg_entry) * 100, 2),
                                "realized": round(realized, 4),
                                "note": "force-sold at loss (accept_loss=true)",
                            })
                        else:
                            remaining.append({
                                "market": market_name[:40],
                                "tokens": round(tokens, 4),
                                "avg_entry": round(avg_entry, 4),
                                "reason": f"force sell also failed: {result2.error}",
                            })
                    else:
                        remaining.append({
                            "market": market_name[:40],
                            "tokens": round(tokens, 4),
                            "avg_entry": round(avg_entry, 4),
                            "reason": f"limit not filled in {timeout_sec}s; position kept (accept_loss=false)",
                        })

    return {
        "paused": True,
        "positions_to_exit": len(positions_to_exit),
        "sold": sold,
        "remaining": remaining,
        "skipped": skipped_positions,  # v1.0.86: показуємо чому пропущено
        "total_realized": round(total_realized, 4),
        "message": (
            f"Exit complete: {len(sold)} sold, {len(remaining)} remaining, "
            f"{len(skipped_positions)} skipped. "
            f"Realized P&L: ${total_realized:+.2f}. Trading paused."
        ),
    }


@admin_router.post("/mode/toggle")
async def toggle_mode():
    """Toggle PAPER <-> LIVE. LIVE requires checklist pass.

    v1.0.39 FIX: when switching PAPER -> LIVE at runtime we must also:
      1. Initialize the py-clob-client ClobClient (creds + signer)
      2. Start the _poll_orders_loop task (it was never created if the bot
         booted in PAPER mode, because start() only creates it when
         paper_trading is already False).
    Without these two steps the bot would place real orders but never
    detect their fills.

    v1.0.46 FIX (BUG-9): previously toggle_mode would overwrite an existing
      risk halt (DAILY_LOSS, CONSECUTIVE_LOSSES, EMERGENCY_STOP) with
      USER_PAUSE and then resume() it — letting the user bypass risk
      halts simply by toggling mode. Now we refuse to toggle if a
      non-USER_PAUSE halt is active, and we don't auto-resume on the
      PAPER->LIVE path — the user must explicitly click Resume.
    """
    _require_services()
    import asyncio

    # v1.0.46 (BUG-9): don't let toggle_mode bypass risk halts.
    # Allowed halt reasons to toggle from: "" (not halted), "USER_PAUSE".
    # Risk halts (DAILY_LOSS, CONSECUTIVE_LOSSES, EMERGENCY_STOP, MIN_BALANCE,
    # STALE_DATA) must be cleared explicitly via /api/risk/resume, not by
    # toggling mode.
    if _inventory.halted:
        halt_reason = (_inventory.halt_reason or "").split(":")[0]
        allowed_to_toggle = {"USER_PAUSE", ""}
        if halt_reason not in allowed_to_toggle:
            return {
                "success": False,
                "message": (
                    f"Cannot toggle mode while halted by risk control "
                    f"({halt_reason}). Use /api/risk/resume to clear it first."
                ),
                "halt_reason": _inventory.halt_reason,
            }

    if settings.paper_trading:
        # PAPER -> LIVE: run checklist
        checklist = await live_checklist()
        if not checklist["ready"]:
            return {
                "success": False,
                "message": "Cannot switch to LIVE — fix issues first",
                "checks": checklist["checks"],
            }
        # Pause bot, cancel all quotes
        _inventory.halt(reason="USER_PAUSE", detail="Switching to LIVE mode")
        for tid in list(_mm.active_quotes.keys()):
            await _mm._cancel_all_levels(tid)
        await asyncio.sleep(1)
        # Switch
        settings.paper_trading = False
        # v1.0.39: initialize LIVE CLOB client + start fill-polling task.
        try:
            await _clob._init_live_client()
        except Exception as e:
            # Roll back to PAPER — don't leave the bot half-switched.
            settings.paper_trading = True
            return {
                "success": False,
                "message": f"LIVE client init failed: {e}. Rolled back to PAPER.",
            }
        await _mm.start_live_polling()
        # v1.0.46 (BUG-9): do NOT auto-resume — user must click Resume.
        # Previously this called _inventory.resume(preserve_counters=True)
        # which cleared the USER_PAUSE halt AND any pre-existing risk halt.
        # Now we leave the bot paused (USER_PAUSE) so the user explicitly
        # starts trading in LIVE mode after verifying everything.
        await _alerter.send("critical", "LIVE MODE", "Bot switched to LIVE — real orders will be placed! Click Resume to start trading.")
        return {
            "success": True,
            "mode": "LIVE",
            "trading_paused": True,
            "message": "🔴 LIVE mode active. Bot is PAUSED — click Resume to start trading.",
        }
    else:
        # LIVE -> PAPER: always safe
        _inventory.halt(reason="USER_PAUSE", detail="Switching to PAPER mode")
        for tid in list(_mm.active_quotes.keys()):
            await _mm._cancel_all_levels(tid)
        await asyncio.sleep(1)
        settings.paper_trading = True
        # v1.0.46 (BUG-9): same — don't auto-resume. Let user explicitly resume.
        await _alerter.send("info", "PAPER MODE", "Bot switched to PAPER — safe simulation. Click Resume to start.")
        return {
            "success": True,
            "mode": "PAPER",
            "trading_paused": True,
            "message": "📄 PAPER mode active. Bot is PAUSED — click Resume to start.",
        }


@admin_router.post("/paper/reset")
async def reset_paper(db: AsyncSession = Depends(get_db)):
    """Reset paper mode: clear inventory, trades, reset bankroll."""
    if not settings.paper_trading:
        raise HTTPException(400, "Not in PAPER mode")
    _require_services()
    # Cancel quotes
    for tid in list(_mm.active_quotes.keys()):
        await _mm._cancel_all_levels(tid)
    # Reset inventory
    _inventory.inventories.clear()
    _inventory.bankroll = settings.paper_balance_usdc
    _inventory.starting_balance = settings.paper_balance_usdc
    _inventory.consecutive_losses = 0
    _inventory.daily_pnl = 0.0
    _inventory.halted = False
    _inventory.halt_reason = ""
    # Reset in-memory counters
    _mm._fill_count = 0
    _mm._round_trip_count = 0
    _mm._cycle_count = 0
    _mm._hedge_attempts = 0
    _mm._hedge_fills = 0
    # v1.0.50 FIX (BUG-24): reset liquidation counter too — was missing,
    # so dashboard showed stale liquidation_count after paper reset.
    _mm._liquidation_count = 0
    # v1.0.150: new exit metrics
    _mm._profit_take_count = 0
    _mm._loss_forced_count = 0
    # v1.0.151
    _mm._no_hedge_count = 0
    _mm._hedged_positions.clear()
    _mm._drawdown_stopped.clear()
    _mm._mid_history.clear()
    _mm._momentum_bid_blocked.clear()
    _mm._momentum_ask_blocked.clear()
    # v1.0.50: clear pending LIVE orders too (in case of partial reset mid-LIVE)
    _mm._pending_orders.clear()
    # v1.0.50: clear active quotes dict (cancel was called but dict entries
    # may persist if cancel failed)
    _mm.active_quotes.clear()
    # Wipe DB trades
    from sqlalchemy import delete

    await db.execute(delete(Trade))
    await db.execute(delete(Quote))
    # v1.0.72 (BUG-N23): Clear saved inventory state on paper reset
    await _inventory.clear_saved_state(db)
    await db.commit()
    log.info("paper_reset_complete")
    return {"ok": True, "new_bankroll": _inventory.bankroll}


# ═══════════════════════════════════════════════════════════════════════
# Analytics
# ═══════════════════════════════════════════════════════════════════════


@admin_router.get("/analytics/by_market")
async def by_market(db: AsyncSession = Depends(get_db)):
    """v1.0.49 FIX (BUG-16): use SQL GROUP BY instead of loading all trades.

    Previously: `select(Trade)` loaded every Trade ORM object into memory,
    then grouped in Python. With thousands of trades this was slow + RAM-heavy.
    Now: single SQL GROUP BY query returns aggregate rows directly.
    """
    _require_services()
    from sqlalchemy import case as sql_case, literal_column

    # SQL GROUP BY market_id — one row per market with aggregates
    result = await db.execute(
        select(
            Trade.market_id,
            func.max(Trade.market_name).label("market_name"),
            func.count(Trade.id).label("trade_count"),
            func.sum(Trade.pnl_usdc).label("realized_pnl"),
            func.sum(sql_case((Trade.side == Side.BUY, 1), else_=0)).label("buys"),
            func.sum(sql_case((Trade.side == Side.SELL, 1), else_=0)).label("sells"),
        ).group_by(Trade.market_id)
    )
    rows = result.all()
    return {"markets": _analytics.by_market_from_rows(rows)}


@admin_router.get("/analytics/time_series")
async def time_series(db: AsyncSession = Depends(get_db)):
    _require_services()
    result = await db.execute(select(Trade).order_by(Trade.timestamp))
    trades = list(result.scalars().all())
    return {"series": _analytics.pnl_time_series(trades)}


# ═══════════════════════════════════════════════════════════════════════
# Diagnostics
# ═══════════════════════════════════════════════════════════════════════


@admin_router.get("/diagnostics")
async def diagnostics(db: AsyncSession = Depends(get_db)):
    """8-point health check."""
    _require_services()
    import time

    checks = []
    overall_healthy = True

    # 1. WebSocket
    ws_age = _clob.last_ws_msg_age
    ws_ok = ws_age < settings.stale_data_threshold_sec
    detail = f"Last message {ws_age:.0f}s ago"
    if ws_age > 60:
        detail += " ⛔ INTERNET DOWN?"
    elif ws_age > 30:
        detail += " ⚠️ STALE"
    checks.append({"name": "WebSocket", "healthy": ws_ok, "detail": detail})
    if not ws_ok:
        overall_healthy = False

    # 2. Market data freshness
    if _clob.books:
        stale = sum(1 for b in _clob.books.values() if time.monotonic() - b.last_update > 15)
        total = len(_clob.books)
        books_ok = stale == 0
        checks.append(
            {
                "name": "Market Data",
                "healthy": books_ok,
                "detail": f"{total - stale}/{total} books fresh" + (f" ({stale} STALE!)" if stale else ""),
            }
        )
        if not books_ok:
            overall_healthy = False
    else:
        checks.append({"name": "Market Data", "healthy": False, "detail": "No books"})
        overall_healthy = False

    # 3. Book quality
    if _clob.books:
        good = sum(1 for b in _clob.books.values() if b.bids and b.asks)
        total = len(_clob.books)
        ok = good >= total * 0.8
        checks.append(
            {
                "name": "Book Quality",
                "healthy": ok,
                "detail": f"{good}/{total} have bid+ask",
            }
        )
        if not ok:
            overall_healthy = False

    # 4. P&L health (total equity)
    inventory_value = 0.0
    for tid, inv in _inventory.inventories.items():
        book = _clob.books.get(tid)
        if book and inv.net_tokens != 0:
            inventory_value += inv.net_tokens * book.mid
    total_equity = _inventory.bankroll + inventory_value
    pnl = total_equity - _inventory.starting_balance
    pnl_ok = pnl > -settings.max_daily_loss_usd
    checks.append(
        {
            "name": "P&L Health",
            "healthy": pnl_ok,
            "detail": f"{'+' if pnl >= 0 else ''}{pnl:.2f} USDC (cash ${_inventory.bankroll:.2f} + inv ${inventory_value:.2f})",
        }
    )
    if not pnl_ok:
        overall_healthy = False

    # 5. Inventory risk
    # Use the LARGER of ($ cap, % of bankroll) so inventory can scale with profits
    # Previously: min($5, 25%×bankroll) = $5 always (cap too restrictive when bankroll grows)
    # Now: max($5, 25%×bankroll) — allows scaling while keeping $5 floor
    total_inv = sum(abs(inv.net_usdc_at_entry) for inv in _inventory.inventories.values())
    pct_cap = _inventory.bankroll * settings.max_inventory_pct_of_bankroll
    effective_max_per_market = max(settings.max_inventory_usdc, pct_cap)
    max_allowed = effective_max_per_market * max(len(_inventory.inventories), 1)
    inv_ok = total_inv < max_allowed * 0.9
    checks.append(
        {
            "name": "Inventory Risk",
            "healthy": inv_ok,
            "detail": f"${total_inv:.2f} / ${max_allowed:.2f} ({total_inv / max(max_allowed, 1) * 100:.0f}%) — {len(_inventory.inventories)} markets × ${effective_max_per_market:.2f}",
        }
    )
    if not inv_ok:
        overall_healthy = False

    # 6. Trading status
    if _inventory.halted:
        checks.append(
            {"name": "Trading Status", "healthy": False, "detail": f"🛑 HALTED: {_inventory.halt_reason}"}
        )
        overall_healthy = False
    elif _mm._trading_paused:
        checks.append({"name": "Trading Status", "healthy": True, "detail": "⏸ PAUSED"})
    else:
        checks.append({"name": "Trading Status", "healthy": True, "detail": "▶ Active"})

    # 7. Fill rate
    fill_rate = (_mm._fill_count / max(_mm._cycle_count, 1)) * 100
    fill_ok = fill_rate > 0.5 or _mm._cycle_count < 60
    checks.append(
        {
            "name": "Fill Rate",
            "healthy": fill_ok,
            "detail": f"{_mm._fill_count} fills / {_mm._cycle_count} cycles ({fill_rate:.1f}%)",
        }
    )
    if not fill_ok:
        overall_healthy = False

    # 8. Adverse selection
    adverse_cooldown = _risk.adverse_selection.global_cooldown_remaining()
    adverse_ok = adverse_cooldown <= 0
    checks.append(
        {
            "name": "Adverse Selection",
            "healthy": adverse_ok,
            "detail": f"Global cooldown: {adverse_cooldown:.1f}s" + (" (active)" if adverse_cooldown > 0 else ""),
        }
    )

    return {
        "overall_healthy": overall_healthy,
        "status": "✅ ALL SYSTEMS OK" if overall_healthy else "⚠️ ISSUES DETECTED",
        "checks": checks,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


# ═══════════════════════════════════════════════════════════════════════
# Live readiness checklist
# ═══════════════════════════════════════════════════════════════════════


@admin_router.get("/live/checklist")
async def live_checklist():
    """8-point readiness check for LIVE mode.

    v1.0.39 FIX:
      - Replaced `< 2` with `< 5` (Polymarket hard minimum order is $5 USDC).
      - get_balance_allowance is now called once (was called twice).
      - Added: py-clob-client import check.
      - Added: MATIC balance check (gas for cancels / order signing).
      - Added: poll-loop liveness check (only meaningful if already LIVE).
      - Added: ClobClient initialized check (only meaningful if already LIVE).
    """
    checks = []
    ready = True

    if settings.paper_trading:
        checks.append({"name": "Paper mode OFF", "ok": False, "detail": "PAPER_TRADING=true"})
        ready = False
    else:
        checks.append({"name": "Paper mode OFF", "ok": True, "detail": "Live mode enabled"})

    if not settings.polygon_private_key:
        checks.append({"name": "Polygon private key", "ok": False, "detail": "POLYGON_PRIVATE_KEY not set"})
        ready = False
    else:
        checks.append(
            {"name": "Polygon private key", "ok": True, "detail": f"Key set (...{settings.polygon_private_key[-4:]})"}
        )

    if not settings.polygon_wallet_address:
        checks.append({"name": "Wallet address", "ok": False, "detail": "POLYGON_WALLET_ADDRESS not set"})
        ready = False
    else:
        checks.append(
            {"name": "Wallet address", "ok": True, "detail": f"0x...{settings.polygon_wallet_address[-4:]}"}
        )

    if settings.signature_type not in (0, 1, 2):
        checks.append(
            {"name": "Signature type", "ok": False, "detail": f"Invalid: {settings.signature_type}"}
        )
        ready = False
    else:
        names = {0: "EOA", 1: "POLY_PROXY", 2: "POLY_GNOSIS_SAFE"}
        checks.append(
            {"name": "Signature type", "ok": True, "detail": f"{names[settings.signature_type]} ({settings.signature_type})"}
        )

    # v1.0.39 FIX: order size validation. Polymarket hard minimum is $5 USDC.
    # Previously the lower bound was 2, which would let a $2-$4 order through
    # the checklist and then get rejected by the Polymarket API at runtime.
    if settings.order_size_usdc > 50:
        checks.append(
            {"name": "Order size safe", "ok": False, "detail": f"${settings.order_size_usdc} — too high (max $50)"}
        )
        ready = False
    elif settings.order_size_usdc < 5:
        checks.append(
            {"name": "Order size safe", "ok": False, "detail": f"${settings.order_size_usdc} — below Polymarket minimum ($5)"}
        )
        ready = False
    else:
        checks.append({"name": "Order size safe", "ok": True, "detail": f"${settings.order_size_usdc} per order"})

    if settings.max_daily_loss_usd > 50:
        checks.append(
            {"name": "Daily loss limit", "ok": False, "detail": f"${settings.max_daily_loss_usd} — too high"}
        )
        ready = False
    else:
        checks.append(
            {"name": "Daily loss limit", "ok": True, "detail": f"${settings.max_daily_loss_usd} max daily loss"}
        )

    # v1.0.39 NEW: py-clob-client must be importable, otherwise every LIVE
    # order placement raises at the import line in ClobService.place_order.
    try:
        from py_clob_client.client import ClobClient as _PC  # noqa: F401

        checks.append({"name": "py-clob-client installed", "ok": True, "detail": "import OK"})
    except Exception as e:
        checks.append(
            {"name": "py-clob-client installed", "ok": False, "detail": f"import failed: {e}"}
        )
        ready = False

    # Single balance+allowance call (was called twice before).
    bal_ok = False
    balance_usd = 0.0
    allowance_usd = 0.0
    try:
        bal = await _clob.get_balance_allowance()
        balance_usd = float(bal.get("balance", 0)) / 1e6  # USDC has 6 decimals
        allowance_usd = float(bal.get("allowance", 0)) / 1e6
        bal_ok = True
    except Exception as e:
        checks.append(
            {"name": "USDC balance", "ok": False, "detail": f"Check failed: {e}"}
        )
        checks.append(
            {"name": "USDC allowance", "ok": False, "detail": f"Check failed: {e}"}
        )
        ready = False

    if bal_ok:
        if balance_usd < 5:
            checks.append(
                {"name": "USDC balance", "ok": False, "detail": f"${balance_usd:.2f} — too low (need ≥$5)"}
            )
            ready = False
        else:
            checks.append(
                {"name": "USDC balance", "ok": True, "detail": f"${balance_usd:.2f} USDC"}
            )
        if allowance_usd < 5:
            checks.append(
                {
                    "name": "USDC allowance",
                    "ok": False,
                    "detail": f"${allowance_usd:.2f} — approve USDC for the exchange contract",
                }
            )
            ready = False
        else:
            checks.append(
                {"name": "USDC allowance", "ok": True, "detail": f"${allowance_usd:.2f} approved"}
            )

    # v1.0.39 NEW: MATIC balance check. Even an EOA wallet needs a small
    # amount of MATIC for gas when signing/cancelling orders on Polygon.
    # We can't read MATIC balance through py-clob-client's get_balance_allowance
    # (that's USDC only). We approximate by attempting a w3 eth_getBalance.
    # If web3 isn't installed or the call fails, we warn but don't block
    # (the user may have MATIC and we just can't verify it here).
    try:
        from web3 import Web3  # type: ignore
        from app.core.config import settings as _s

        rpc = "https://polygon-rpc.com"
        w3 = Web3(Web3.HTTPProvider(rpc))
        matic_wei = w3.eth.get_balance(_s.polygon_wallet_address)
        matic = float(matic_wei) / 1e18
        if matic < 0.05:
            checks.append(
                {
                    "name": "MATIC for gas",
                    "ok": False,
                    "detail": f"{matic:.4f} MATIC — recommend ≥0.05 for cancels/resigns",
                }
            )
            # Don't set ready=False: orders may still go through if the
            # operator tops up MATIC between checklist and first cancel.
            # But the warning is loud.
        else:
            checks.append(
                {"name": "MATIC for gas", "ok": True, "detail": f"{matic:.4f} MATIC"}
            )
    except Exception as e:
        checks.append(
            {
                "name": "MATIC for gas",
                "ok": False,
                "detail": f"Cannot verify (web3? rpc?): {e}",
            }
        )

    # v1.0.39 NEW: if we are ALREADY in LIVE mode, verify the runtime is
    # actually wired: live client initialized and poll loop alive.
    if not settings.paper_trading:
        if _clob._client is None:
            checks.append(
                {"name": "ClobClient initialized", "ok": False, "detail": "LIVE mode but py-clob client is None"}
            )
            ready = False
        else:
            checks.append({"name": "ClobClient initialized", "ok": True, "detail": "client ready"})

        poll_alive = (
            _mm._poll_task is not None and not _mm._poll_task.done()
        )
        if not poll_alive:
            checks.append(
                {"name": "Fill-poll loop alive", "ok": False, "detail": "LIVE mode but _poll_orders_loop not running — call /api/mode/toggle again or restart"}
            )
            ready = False
        else:
            checks.append({"name": "Fill-poll loop alive", "ok": True, "detail": "running"})

    return {
        "ready": ready,
        "status": "✅ READY FOR LIVE" if ready else "❌ NOT READY — fix issues above",
        "checks": checks,
    }


# ═══════════════════════════════════════════════════════════════════════
# Alerts log
# ═══════════════════════════════════════════════════════════════════════


@admin_router.get("/alerts")
async def alerts():
    return {"alerts": _alerter.recent_alerts if _alerter else []}


# ═══════════════════════════════════════════════════════════════════════
# Connectivity diagnostics (v1.0.40)
# ═══════════════════════════════════════════════════════════════════════


@admin_router.get("/connectivity")
async def connectivity():
    """v1.0.40: Test reachability of Polymarket APIs from this host.

    Returns status + latency + actual error for each endpoint, so the user
    can see WHY markets_discovery_failed (was previously logged as error="").
    """
    import aiohttp
    import time as _time

    results = []

    # 1. Gamma REST API
    t0 = _time.monotonic()
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(
                f"{settings.gamma_url}/markets?limit=1",
                timeout=aiohttp.ClientTimeout(total=10),
            ) as resp:
                body = await resp.text()
                results.append({
                    "name": "Gamma REST",
                    "url": f"{settings.gamma_url}/markets?limit=1",
                    "ok": resp.status == 200,
                    "status_code": resp.status,
                    "latency_ms": round((_time.monotonic() - t0) * 1000, 1),
                    "body_preview": body[:200] if body else "",
                })
    except Exception as e:
        results.append({
            "name": "Gamma REST",
            "url": f"{settings.gamma_url}/markets?limit=1",
            "ok": False,
            "error_type": type(e).__name__,
            "error_module": getattr(type(e), "__module__", "?"),
            "error": str(e),
            "latency_ms": round((_time.monotonic() - t0) * 1000, 1),
        })

    # 2. CLOB REST API
    t0 = _time.monotonic()
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(
                f"{settings.clob_base_url}/markets",
                timeout=aiohttp.ClientTimeout(total=10),
            ) as resp:
                body = await resp.text()
                results.append({
                    "name": "CLOB REST",
                    "url": f"{settings.clob_base_url}/markets",
                    "ok": resp.status == 200,
                    "status_code": resp.status,
                    "latency_ms": round((_time.monotonic() - t0) * 1000, 1),
                    "body_preview": body[:200] if body else "",
                })
    except Exception as e:
        results.append({
            "name": "CLOB REST",
            "url": f"{settings.clob_base_url}/markets",
            "ok": False,
            "error_type": type(e).__name__,
            "error_module": getattr(type(e), "__module__", "?"),
            "error": str(e),
            "latency_ms": round((_time.monotonic() - t0) * 1000, 1),
        })

    # 3. WebSocket endpoint (HTTP HEAD as reachability probe)
    t0 = _time.monotonic()
    ws_url_http = settings.ws_url.replace("wss://", "https://")
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(
                ws_url_http,
                timeout=aiohttp.ClientTimeout(total=10),
            ) as resp:
                results.append({
                    "name": "CLOB WS (HTTP probe)",
                    "url": ws_url_http,
                    "ok": resp.status in (200, 404, 400),  # 404/400 = endpoint alive
                    "status_code": resp.status,
                    "latency_ms": round((_time.monotonic() - t0) * 1000, 1),
                    "note": "404 is OK — means WS endpoint reachable, just not via GET",
                })
    except Exception as e:
        results.append({
            "name": "CLOB WS (HTTP probe)",
            "url": ws_url_http,
            "ok": False,
            "error_type": type(e).__name__,
            "error_module": getattr(type(e), "__module__", "?"),
            "error": str(e),
            "latency_ms": round((_time.monotonic() - t0) * 1000, 1),
        })

    # 4. DNS resolution check
    import socket
    t0 = _time.monotonic()
    dns_ok = False
    dns_error = ""
    try:
        for host in ("gamma-api.polymarket.com", "clob.polymarket.com"):
            socket.gethostbyname(host)
        dns_ok = True
    except Exception as e:
        dns_error = f"{type(e).__name__}: {e}"
    results.append({
        "name": "DNS resolution",
        "ok": dns_ok,
        "error": dns_error,
        "latency_ms": round((_time.monotonic() - t0) * 1000, 1),
    })

    # 5. Outbound internet (control check via Cloudflare trace)
    t0 = _time.monotonic()
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(
                "https://www.cloudflare.com/cdn-cgi/trace",
                timeout=aiohttp.ClientTimeout(total=8),
            ) as resp:
                body = await resp.text()
                # Extract IP + country for diagnostic
                ip_line = ""
                loc_line = ""
                for line in body.splitlines():
                    if line.startswith("ip="):
                        ip_line = line
                    elif line.startswith("loc="):
                        loc_line = line
                results.append({
                    "name": "Internet (cloudflare control)",
                    "ok": resp.status == 200,
                    "latency_ms": round((_time.monotonic() - t0) * 1000, 1),
                    "your_ip": ip_line,
                    "your_country": loc_line,
                    "note": "If Polymarket endpoints fail but this works, you're likely geo-blocked by Polymarket (US/UK/sanctioned countries).",
                })
    except Exception as e:
        results.append({
            "name": "Internet (cloudflare control)",
            "ok": False,
            "error_type": type(e).__name__,
            "error": str(e),
            "latency_ms": round((_time.monotonic() - t0) * 1000, 1),
        })

    overall_ok = all(r.get("ok", False) for r in results)
    return {
        "ok": overall_ok,
        "status": "✅ ALL ENDPOINTS REACHABLE" if overall_ok else "❌ SOME ENDPOINTS BLOCKED — see details",
        "results": results,
    }


# ═══════════════════════════════════════════════════════════════════════
# Halt events
# ═══════════════════════════════════════════════════════════════════════


@admin_router.get("/halt_events")
async def halt_events(limit: int = 50, db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(HaltEvent).order_by(HaltEvent.timestamp.desc()).limit(limit)
    )
    events = list(result.scalars().all())
    return {
        "events": [
            {
                "id": e.id,
                "event": e.event,
                "reason": e.reason,
                "detail": e.detail,
                "bankroll_at_event": e.bankroll_at_event,
                "timestamp": e.timestamp.isoformat() if e.timestamp else None,
            }
            for e in events
        ]
    }


# ═══════════════════════════════════════════════════════════════════════
# Helpers
# ═══════════════════════════════════════════════════════════════════════


def time_now() -> float:
    import time

    return time.monotonic()


@root_router.get("/health")
async def health():
    """Simple liveness probe."""
    return {"status": "ok", "timestamp": datetime.now(timezone.utc).isoformat()}


# ═══════════════════════════════════════════════════════════════════════
# v1.0.149 (Claude): DIAGNOSTICS — full PAPER/LIVE readiness panel
# ═══════════════════════════════════════════════════════════════════════

@admin_router.get("/diagnostics/full")
async def diagnostics():
    """Check every operational parameter. Each check: ok / warn / fail."""
    import os
    import time as _t

    from app.core.config import settings as s

    checks: list[dict] = []

    def add(group, name, status, value="", hint=""):
        checks.append({
            "group": group, "name": name, "status": status,
            "value": str(value), "hint": hint,
        })

    live = not s.paper_trading

    # ── Mode & exchange ──────────────────────────────────────────────
    add("Режим", "Режим торгівлі", "ok", "LIVE" if live else "PAPER",
        "" if live else "Симуляція — реальні книги, віртуальні філи")
    add("Режим", "Біржа", "ok", s.exchange)
    add("Режим", "Адаптер завантажено", "ok" if _clob else "fail",
        type(_clob).__name__ if _clob else "—")

    # ── HARDCODED SPREAD self-test ───────────────────────────────────
    try:
        from app.services.spread_invariant import (
            HARDCODED_ENTRY_OFFSET, hardcoded_quotes, validate_quote,
        )
        hq = hardcoded_quotes(0.3200, 0.3400, level=1)
        rule_ok = (
            hq is not None
            and abs(hq.bid - 0.3215) < 1e-9
            and abs(hq.ask - 0.3385) < 1e-9
            and validate_quote(hq.bid, hq.ask, 0.3200, 0.3400)[0]
        )
        add("Хардкод", "Правило 15 пунктів", "ok" if rule_ok else "fail",
            f"bid+{HARDCODED_ENTRY_OFFSET}, ask-{HARDCODED_ENTRY_OFFSET}",
            "0.32/0.34 → 0.3215/0.3385" if rule_ok else "САМОТЕСТ ПРОВАЛЕНО")
        no_room = hardcoded_quotes(0.500, 0.502, level=1) is None
        add("Хардкод", "Захист від тісного спреду", "ok" if no_room else "fail",
            "skip якщо spread ≤ 30 пт")
    except Exception as e:
        add("Хардкод", "Правило 15 пунктів", "fail", str(e)[:60])

    # ── Credentials (LIVE) ───────────────────────────────────────────
    if s.exchange == "limitless":
        creds = {
            "LIMITLESS_PRIVATE_KEY": bool(s.limitless_private_key),
            "LIMITLESS_API_TOKEN_ID": bool(s.limitless_api_token_id),
            "LIMITLESS_API_SECRET": bool(s.limitless_api_secret),
        }
    else:
        creds = {
            "POLYGON_PRIVATE_KEY": bool(getattr(s, "polygon_private_key", "")),
            "CLOB_API_KEY": bool(getattr(s, "clob_api_key", "")),
            "CLOB_API_SECRET": bool(getattr(s, "clob_api_secret", "")),
        }
    for k, present in creds.items():
        st = "ok" if present else ("fail" if live else "warn")
        add("Ключі (LIVE)", k, st, "задано" if present else "порожньо",
            "" if present else ("ОБОВ'ЯЗКОВО для LIVE" if live else "потрібно перед LIVE"))

    # ── Exchange API reachability ────────────────────────────────────
    try:
        t0 = _t.monotonic()
        infos = await _clob.discover_markets()
        dt = round((_t.monotonic() - t0) * 1000)
        add("Зв'язок", "API біржі", "ok" if infos else "warn",
            f"{len(infos)} ринків, {dt}ms",
            "" if infos else "0 ринків — перевір мережу/фільтри")
    except Exception as e:
        add("Зв'язок", "API біржі", "fail", str(e)[:70])
    age = getattr(_clob, "last_ws_msg_age", None)
    if age is not None:
        st = "ok" if age < 10 else ("warn" if age < 60 else "fail")
        add("Зв'язок", "Свіжість книг", st, f"{round(age,1)}с тому")

    # ── Sizing & risk ────────────────────────────────────────────────
    add("Сайзинг", "Розмір ордера", "ok", f"${s.order_size_usdc}")
    min_ok = s.order_size_usdc >= s.order_size_min_usdc
    add("Сайзинг", "Мінімум ордера", "ok" if min_ok else "fail",
        f"${s.order_size_min_usdc}")
    if s.exchange == "polymarket" and s.order_size_min_usdc < 5.0:
        add("Сайзинг", "Polymarket $5 мінімум", "fail",
            f"${s.order_size_min_usdc} < $5", "Біржа відхилить ордери")
    ml = getattr(s, "multi_level_enabled", False)
    add("Сайзинг", "Мульти-рівень", "ok", "увімкнено (L1+L2+L3)" if ml else "вимкнено (тільки L1)",
        "На банкролі <$50 рекомендовано вимкнено")
    # v1.0.152: effective per-side order size after the full chain:
    # base × autoscale(≤1.5, growth-only) × vol(0.25–1.5), then multi-level
    # SPLITS it 45/35/20% per level, each level bumped to the exchange min.
    autoscale_hi = min(
        s.order_size_autoscale_max_mult,
        max(1.0, (_inventory.bankroll / max(_inventory.starting_balance, 1.0)) if _inventory else 1.0),
    )
    base_lo = max(s.order_size_min_usdc, s.order_size_usdc * s.order_size_min_vol_mult)
    base_hi = s.order_size_usdc * autoscale_hi * s.order_size_max_vol_mult
    exch_min = s.limitless_min_order_usdc if s.exchange == "limitless" else 5.0
    if ml:
        pcts = (s.multi_level_1_size_pct, s.multi_level_2_size_pct, s.multi_level_3_size_pct)
        side_lo = sum(max(base_lo * p, exch_min) for p in pcts)
        side_hi = sum(max(base_hi * p, exch_min) for p in pcts)
        detail = "3 рівні ділять базу 45/35/20%, кожен ≥ біржового мін."
    else:
        side_lo, side_hi = max(base_lo, exch_min), max(base_hi, exch_min)
        detail = "один рівень"
    add("Сайзинг", "Ефективний розмір ордера", "ok",
        f"${round(side_lo,2)}–${round(side_hi,2)}/сторона/ринок",
        f"{detail}; партіали можуть філити частину")
    # v1.0.155: adverse-rate ротація
    banned_now = _mm.status.get("adverse_banned_now", 0) if _mm else 0
    add("Ризик", "Adverse-бани ринків", "warn" if banned_now else "ok",
        f"зараз {banned_now} / за сесію {_mm.status.get('adverse_ban_total', 0) if _mm else 0}",
        f"бан {round(s.adverse_market_ban_sec/60)} хв при adverse_rate >30% на 10+ філах")
    add("Ризик", "Макс. інвентар", "ok",
        f"${s.max_inventory_usdc} / {round(s.max_inventory_pct_of_bankroll*100)}% банкролу")
    add("Ризик", "Денний стоп-лос", "ok", f"${s.max_daily_loss_usd}")
    add("Ризик", "Ліквідація", "ok" if s.inventory_liquidation_enabled else "warn",
        f"AGG {round(s.inventory_liquidation_aggressive_age_sec/60)}хв / "
        f"URG {round(s.inventory_liquidation_urgent_age_sec/60)}хв")

    # ── Dust ─────────────────────────────────────────────────────────
    add("Dust", "Поріг dust", "ok", f"${s.dust_threshold_usdc}")
    if s.exchange == "polymarket" and s.dust_threshold_usdc != 5.0:
        add("Dust", "Поріг vs біржа", "warn",
            f"${s.dust_threshold_usdc} ≠ $5", "Polymarket мінімум $5")
    add("Dust", "Не скасовувати партіали", "ok",
        "так" if s.partial_fill_no_cancel else "ні (штатно)",
        "Увімкни для LIVE-старту з малим банкролом")
    add("Dust", "Reconcile резолюцій", "ok",
        f"кожні {round(s.orphaned_reconcile_interval_sec/60)}хв")

    # ── Bankroll ─────────────────────────────────────────────────────
    br = _inventory.bankroll if _inventory else 0.0
    add("Капітал", "Банкрол", "ok" if br > 0 else "fail", f"${round(br,2)}")
    if br > 0 and s.order_size_usdc > br * 0.6:
        add("Капітал", "Ордер vs банкрол", "warn",
            f"ордер ${s.order_size_usdc} > 60% банкролу",
            "1 партіал може заблокувати весь капітал")

    # ── Infra ────────────────────────────────────────────────────────
    try:
        os.makedirs(os.path.dirname(s.log_file) or ".", exist_ok=True)
        with open(s.log_file, "a", encoding="utf-8"):
            pass
        add("Інфра", "Лог-файл", "ok", s.log_file)
    except OSError as e:
        add("Інфра", "Лог-файл", "fail", str(e)[:60])
    add("Інфра", "База даних", "ok" if os.path.exists("mm_bot.db") or True else "warn",
        s.database_url if hasattr(s, "database_url") else "sqlite")
    hb = getattr(_mm, "_running", False) if _mm else False
    add("Інфра", "MM цикл", "ok" if hb else "warn",
        "працює" if hb else "зупинено")

    n_fail = sum(1 for c in checks if c["status"] == "fail")
    n_warn = sum(1 for c in checks if c["status"] == "warn")
    verdict = "fail" if n_fail else ("warn" if n_warn else "ok")
    ready_live = not any(
        c["status"] == "fail" or (c["group"] == "Ключі (LIVE)" and c["status"] != "ok")
        for c in checks
    )
    return {
        "verdict": verdict,
        "ready_for_live": ready_live,
        "fails": n_fail, "warns": n_warn,
        "checks": checks,
    }
