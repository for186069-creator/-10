"""
app/core/logging.py — Structured logging via structlog.

JSON in production (machine-parseable), pretty console in development.
All log records carry: timestamp, level, logger, event, plus contextual fields.
"""
from __future__ import annotations

import logging
import sys
from typing import Any

import structlog

from app.core.config import settings


def configure_logging() -> None:
    """Configure structlog + stdlib logging once at startup.

    v1.0.52: added optional file logging via settings.log_file.
    When set, logs go to BOTH stdout and the file (append mode).
    """
    level = getattr(logging, settings.log_level.upper(), logging.INFO)

    # Stdlib root: everything goes to stdout
    logging.basicConfig(
        level=level,
        format="%(message)s",
        stream=sys.stdout,
        force=True,  # override uvicorn's config
    )

    # v1.0.52: also log to file if configured
    # v1.0.148: log_file defaults to logs/botmm.log; ensure dir exists +
    # simple size-based rotation (file > log_max_mb → rename to .1).
    if settings.log_file:
        import os

        log_dir = os.path.dirname(settings.log_file)
        if log_dir:
            os.makedirs(log_dir, exist_ok=True)
        try:
            max_bytes = int(settings.log_max_mb * 1024 * 1024)
            if (
                os.path.exists(settings.log_file)
                and os.path.getsize(settings.log_file) > max_bytes
            ):
                rotated = settings.log_file + ".1"
                if os.path.exists(rotated):
                    os.remove(rotated)
                os.rename(settings.log_file, rotated)
        except OSError:
            pass  # rotation is best-effort; never block startup
        file_handler = logging.FileHandler(settings.log_file, mode="a", encoding="utf-8")
        file_handler.setLevel(level)
        file_handler.setFormatter(logging.Formatter("%(message)s"))
        logging.getLogger().addHandler(file_handler)

    # Quiet noisy libs
    for noisy in ("uvicorn.access", "uvicorn.error", "websockets", "httpx", "httpcore"):
        logging.getLogger(noisy).setLevel(logging.WARNING)

    # Shared processors
    shared_processors: list[Any] = [
        structlog.contextvars.merge_contextvars,
        structlog.processors.add_log_level,
        structlog.processors.TimeStamper(fmt="iso", utc=True),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        structlog.processors.UnicodeDecoder(),
    ]

    if settings.log_format == "json":
        renderer = structlog.processors.JSONRenderer()
    else:
        renderer = structlog.dev.ConsoleRenderer(colors=True)

    # v1.0.52: if log_file is set, structlog should also write to file
    log_stream = sys.stdout
    if settings.log_file:
        # Use a shared stream that writes to both stdout and file
        import io

        class DualStream:
            """Write to both stdout and a file."""
            def __init__(self, file_path: str):
                import os

                d = os.path.dirname(file_path)
                if d:
                    os.makedirs(d, exist_ok=True)
                self._stdout = sys.stdout
                self._file = open(file_path, "a", encoding="utf-8")

            def write(self, data: str) -> int:
                self._stdout.write(data)
                self._file.write(data)
                self._file.flush()
                return len(data)

            def flush(self) -> None:
                self._stdout.flush()
                self._file.flush()

            def fileno(self) -> int:
                return self._stdout.fileno()

            def isatty(self) -> bool:
                return self._stdout.isatty()

        log_stream = DualStream(settings.log_file)

    structlog.configure(
        processors=shared_processors + [renderer],
        wrapper_class=structlog.make_filtering_bound_logger(level),
        context_class=dict,
        logger_factory=structlog.PrintLoggerFactory(file=log_stream),
        cache_logger_on_first_use=True,
    )

    # Bridging: route stdlib logging through structlog
    structlog.stdlib.ProcessorFormatter(
        processor=renderer,
        foreign_pre_chain=shared_processors,
    )


def get_logger(name: str) -> structlog.stdlib.BoundLogger:
    """Get a bound logger. Use: `log = get_logger(__name__)`."""
    return structlog.get_logger(name)
