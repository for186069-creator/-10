"""
app/main.py — FastAPI entry point with lifespan + graceful shutdown.

Graceful shutdown:
  1. SIGTERM/SIGINT received → stop accepting new HTTP requests
  2. Cancel all active quotes (LIVE: real cancel_order API calls)
  3. Stop MarketMaker + ClobService
  4. Dispose DB engine
  5. Exit

Bot starts PAUSED — user clicks "Start Trading" via /api/start.
"""
from __future__ import annotations

import asyncio
import signal
import sys
from contextlib import asynccontextmanager

import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from prometheus_client import make_asgi_app

from app.admin.api import admin_router, inject_services, root_router
from app.core.config import settings
from app.core.db import engine
from app.core.logging import configure_logging, get_logger
from app.db.init_db import init_db
from app.db import order_metrics_db as mdb
from app.services.alerter import alerter
from app.services.analytics import Analytics
from app.services.arbitrage_scanner import arb_scanner
from app.services.arb_executor import ArbExecutor
from app.services.clob_client import ClobService
from app.services.inventory_manager import InventoryManager
from app.services.market_maker import MarketMaker
from app.services.order_logger import order_logger
from app.services.risk.risk_manager import RiskManager

configure_logging()
log = get_logger(__name__)

# ── Globals (instantiated once) ──────────────────────────────────────────
# v1.0.147-preview (Claude): exchange selector. MM core is adapter-agnostic —
# LimitlessService mirrors ClobService's public interface exactly.
if settings.exchange == "limitless":
    from app.services.limitless_client import LimitlessService

    clob = LimitlessService()
    log.info("exchange_selected", exchange="limitless")
else:
    clob = ClobService()
inventory = InventoryManager()
risk = RiskManager(inventory, clob)
mm = MarketMaker(clob, inventory, risk)
analytics = Analytics()
# v1.0.90 (N3): arb executor — clob injected here (not module-level singleton,
# because ClobService must be constructed first).
arb_executor = ArbExecutor(clob)


async def _select_markets() -> list[str]:
    """Pick markets to MM on. Returns token IDs."""
    # 1. Explicit list from config
    explicit = settings.explicit_token_ids
    if explicit:
        log.info("using_explicit_markets", count=len(explicit))
        return explicit
    # 2. Auto-pick from Gamma API
    if settings.auto_pick_markets:
        # Dynamic market count based on bankroll
        # v1.0.46 FIX (BUG-22): previously this permanently overwrote
        # settings.auto_pick_count without restoring it. Now we only compute
        # the dynamic count locally and pass it to discover_markets via a
        # temporary override that is always restored (try/finally).
        discover_count_override: int | None = None
        if settings.auto_pick_dynamic:
            bankroll = inventory.bankroll
            dynamic_count = max(1, int(bankroll / 10))
            discover_count_override = min(dynamic_count, 20)
            log.info(
                "dynamic_market_count",
                bankroll=round(bankroll, 2),
                calculated_markets=discover_count_override,
                configured=settings.auto_pick_count,
            )
        # Apply override only for the duration of discover_markets()
        if discover_count_override is not None:
            saved_count = settings.auto_pick_count
            settings.auto_pick_count = discover_count_override
            try:
                infos = await clob.discover_markets()
            finally:
                settings.auto_pick_count = saved_count
        else:
            infos = await clob.discover_markets()
        if infos:
            # Store MarketInfo objects BEFORE starting clob
            for info in infos:
                clob.markets[info.token_id] = info
            return [info.token_id for info in infos]
    log.error("no_markets_selected")
    return []


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan: startup + shutdown."""
    log.info(
        "bot_starting",
        mode="PAPER" if settings.paper_trading else "LIVE",
        spread=settings.spread_cents,
        order_size=settings.order_size_usdc,
        max_inventory=settings.max_inventory_usdc,
    )

    # Init DB
    await init_db()
    # v1.0.79: init the order-lifecycle metrics DB (separate file).
    try:
        await mdb.init_metrics_db()
    except Exception as e:
        log.warning("metrics_db_init_failed", error=str(e))

    # Select markets
    token_ids = await _select_markets()
    if not token_ids:
        log.error("no_markets_to_trade_exiting")
        # Don't crash — let user hit /api/markets/replace manually
    else:
        # Start CLOB client (REST + WS + market data)
        await clob.start(token_ids)

    # Inject services into admin router
    inject_services(clob, inventory, mm, risk, analytics, alerter)

    # v1.0.79: start the order-metrics fill-poller (LIVE only — PAPER rows
    # resolve immediately as MATCHED and need no polling).
    if not settings.paper_trading:
        try:
            order_logger.start_poller(clob)
        except Exception as e:
            log.warning("metrics_poller_start_failed", error=str(e))

    # v1.0.84: start the arbitrage scanner (Опція 4 + Опція A niche filter).
    # Runs in parallel with MM — scans Gamma API for monotonicity violations.
    if settings.arb_enabled:
        try:
            arb_scanner.start()
            log.info(
                "arb_scanner_started",
                interval_sec=settings.arb_scan_interval_sec,
                min_edge_cents=settings.arb_min_edge_cents,
                niche_max_volume=settings.arb_niche_max_volume_24h,
            )
        except Exception as e:
            log.warning("arb_scanner_start_failed", error=str(e))

    # v1.0.90 (N3): start the arb executor — buys YES+NO pair on detection,
    # holds to resolution. Default OFF (arb_execution_enabled=False).
    # Requires arb_scanner to be running (reads arb_scanner.opportunities).
    if settings.arb_execution_enabled and settings.arb_enabled:
        try:
            await arb_executor.start()
            log.info(
                "arb_executor_started",
                mode="PAPER" if settings.paper_trading else "LIVE",
                max_concurrent=settings.arb_max_concurrent_positions,
                position_size_usdc=settings.arb_position_size_usdc,
            )
        except Exception as e:
            log.warning("arb_executor_start_failed", error=str(e))
    elif settings.arb_execution_enabled and not settings.arb_enabled:
        log.warning(
            "arb_executor_skipped",
            reason="arb_execution_enabled=True but arb_enabled=False — scanner must run first",
        )

    # Start MM engine (PAUSED — user clicks Start)
    await mm.start()

    # v1.0.119 (Claude audit CRITICAL): sync bankroll from real wallet in LIVE mode.
    # PAPER: no-op. LIVE: initializes bankroll from actual USDC balance + periodic drift check.
    if not settings.paper_trading:
        try:
            await inventory.sync_bankroll_from_wallet(clob)
            log.info("bankroll_live_sync_done", bankroll=round(inventory.bankroll, 2))
        except Exception as e:
            log.warning("bankroll_live_sync_failed_at_startup", error=str(e))

    # Wire up signal handlers
    loop = asyncio.get_running_loop()
    stop_event = asyncio.Event()

    def _signal_handler(sig: int) -> None:
        log.info("signal_received", signal=sig)
        stop_event.set()

    for sig in (signal.SIGTERM, signal.SIGINT):
        try:
            loop.add_signal_handler(sig, _signal_handler, sig)
        except NotImplementedError:
            # Windows fallback
            signal.signal(sig, lambda s, f: _signal_handler(s))

    # Background task: wait for stop signal
    stop_task = asyncio.create_task(stop_event.wait())

    yield

    # ── Shutdown ──
    log.info("shutdown_initiated")
    stop_task.cancel()
    try:
        await stop_task
    except asyncio.CancelledError:
        pass

    # 1. Stop MM (cancels all active quotes)
    await mm.stop()
    # 2. Stop CLOB (closes WS + REST polling)
    await clob.stop()
    # v1.0.79: stop the metrics poller + close the metrics DB
    try:
        await order_logger.stop_poller()
    except Exception as e:
        log.warning("metrics_poller_stop_failed", error=str(e))
    # v1.0.84: stop the arbitrage scanner
    try:
        await arb_scanner.stop()
    except Exception as e:
        log.warning("arb_scanner_stop_failed", error=str(e))
    # v1.0.90 (N3): stop the arb executor
    try:
        await arb_executor.stop()
    except Exception as e:
        log.warning("arb_executor_stop_failed", error=str(e))
    try:
        await mdb.close_metrics_db()
    except Exception as e:
        log.warning("metrics_db_close_failed", error=str(e))
    # 3. Dispose DB engine
    await engine.dispose()
    log.info("shutdown_complete")


app = FastAPI(
    title="Polymarket Professional MM Bot",
    version="1.0.0",
    description="Production-grade market maker with Avellaneda-Stoikov + Kyle's lambda",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Local admin only — tighten in prod if exposed
    allow_methods=["*"],
    allow_headers=["*"],
)

# Routes
app.include_router(admin_router, prefix="/api")
app.include_router(root_router)

# Prometheus metrics at /metrics
metrics_app = make_asgi_app()
app.mount("/metrics", metrics_app)

# Static dashboard at /
import os

if os.path.exists("app/static"):
    app.mount("/", StaticFiles(directory="app/static", html=True), name="static")


if __name__ == "__main__":
    uvicorn.run(
        "app.main:app",
        host=settings.admin_host,
        port=settings.admin_port,
        reload=False,
        log_level=settings.log_level.lower(),
        access_log=False,  # structlog handles our logging
    )
