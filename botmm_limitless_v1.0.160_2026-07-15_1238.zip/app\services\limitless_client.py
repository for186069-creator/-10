"""Limitless Exchange adapter — drop-in replacement for ClobService.

v1.0.147-preview (Claude, 2026-07-11)

Mirrors the public interface of app/services/clob_client.py:ClobService so
the MM core (market_maker.py, inventory_manager.py, risk/*) runs UNCHANGED.

Sources (verified against official docs 2026-07-11):
  - https://docs.limitless.exchange/developers/migrate-from-polymarket
  - https://docs.limitless.exchange/api-reference/trading/create-order
  - https://docs.limitless.exchange/developers/authentication

Key differences vs Polymarket:
  - Chain: Base (8453), collateral USDC (6 decimals) — NOT Polygon/pUSD
  - Single REST host: https://api.limitless.exchange
  - Auth: HMAC-signed scoped API token (lmts-api-key / lmts-timestamp /
    lmts-signature), token generated in UI → profile → Api keys
  - EIP-712 domain: name="Limitless CTF Exchange", version="1",
    verifyingContract = market venue.exchange (PER-MARKET, fetched+cached)
  - Order struct keeps classic CTF fields (taker/expiration/nonce/feeRateBps)
  - feeRateBps MUST equal profile rank.feeRateBps on fee-bearing markets
    (fetched once from GET /profiles/me and cached)
  - ownerId (profile id) required on every POST /orders
  - postOnly supported for GTC — MAKERS PAY ZERO FEES on Limitless
  - Markets keyed by slug; bot core keys by token_id → adapter keeps a map
  - expiration must be "0", nonce must be 0 (non-zero rejected)

STATUS: code-complete, NOT yet run against production (Limitless has no
testnet — first run must be with minimal real USDC). Areas marked
UNVERIFIED need a live smoke test.
"""

from __future__ import annotations

import asyncio
import base64
import hashlib
import hmac as hmac_mod
import json
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

import aiohttp

from app.core.config import settings
from app.core.logging import get_logger

# Reuse the exact same data structures the MM core consumes.
from app.services.clob_client import MarketBook, MarketInfo, OrderLevel, OrderResult

log = get_logger(__name__)

API_BASE = "https://api.limitless.exchange"
CHAIN_ID = 8453  # Base mainnet
ZERO_ADDR = "0x0000000000000000000000000000000000000000"
EIP712_DOMAIN_NAME = "Limitless CTF Exchange"
EIP712_DOMAIN_VERSION = "1"

ORDER_TYPES = {
    "EIP712Domain": [
        {"name": "name", "type": "string"},
        {"name": "version", "type": "string"},
        {"name": "chainId", "type": "uint256"},
        {"name": "verifyingContract", "type": "address"},
    ],
    "Order": [
        {"name": "salt", "type": "uint256"},
        {"name": "maker", "type": "address"},
        {"name": "signer", "type": "address"},
        {"name": "taker", "type": "address"},
        {"name": "tokenId", "type": "uint256"},
        {"name": "makerAmount", "type": "uint256"},
        {"name": "takerAmount", "type": "uint256"},
        {"name": "expiration", "type": "uint256"},
        {"name": "nonce", "type": "uint256"},
        {"name": "feeRateBps", "type": "uint256"},
        {"name": "side", "type": "uint8"},
        {"name": "signatureType", "type": "uint8"},
    ],
}


def _ensure_eth_deps() -> None:
    try:
        from eth_account import Account  # noqa: F401
        from eth_account.messages import encode_typed_data  # noqa: F401
        from web3 import Web3  # noqa: F401
    except ImportError as e:
        raise RuntimeError(
            "Limitless LIVE mode requires eth-account and web3: "
            "pip install eth-account web3"
        ) from e


@dataclass
class _MarketMeta:
    """Per-market data the adapter needs but the MM core doesn't see."""

    slug: str
    venue_exchange: str
    venue_adapter: str
    yes_token: str
    no_token: str
    fee_bearing: bool = False


class LimitlessService:
    """Drop-in replacement for ClobService targeting Limitless Exchange.

    Public interface consumed by the MM core (kept identical):
      .books: dict[token_id, MarketBook]
      .markets: dict[token_id, MarketInfo]
      .start(token_ids) / .stop()
      .discover_markets() -> list[MarketInfo]
      .fetch_market_status(token_id) -> dict | None
      .place_order(token_id, side, price, size_usdc, order_type, post_only)
      .cancel_order(order_id) -> bool
      .cancel_all() -> int
      .get_open_orders() -> list[dict]
      .get_balance_allowance() -> dict
      .last_ws_msg_age -> float
      ._feed.unsubscribe(token_id)  (compat shim)
    """

    def __init__(self) -> None:
        self.books: dict[str, MarketBook] = {}
        self.markets: dict[str, MarketInfo] = {}
        self._meta: dict[str, _MarketMeta] = {}  # token_id -> meta
        self._slug_by_token: dict[str, str] = {}
        # v1.0.157: markets the API reports as inactive (resolved) — skipped
        # by the poll loop until a refill re-discovers them as active.
        self._dead_markets: set[str] = set()
        self._session: aiohttp.ClientSession | None = None
        self._poll_task: asyncio.Task | None = None
        self._running = False
        self._last_book_update = time.monotonic()

        # LIVE credentials (lazy)
        self._owner_id: int | None = None
        self._fee_rate_bps: int = 0
        self._account = None  # eth_account Account

        # Compat shim: MM core calls self.clob._feed.unsubscribe(tid)
        self._feed = _FeedShim(self)

    # ── lifecycle ─────────────────────────────────────────────────────

    async def start(self, token_ids: list[str]) -> None:
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=15)
            )
        if not settings.paper_trading:
            await self._init_live_client()
        for tid in token_ids:
            self._feed._subscribed.add(tid)
            self.books.setdefault(tid, MarketBook(token_id=tid))
        self._ensure_polling()
        log.info("limitless_service_started", markets=len(token_ids))

    def _ensure_polling(self) -> None:
        """Start the REST poll loop if it isn't running.

        v1.0.150: when startup discovery fails (e.g. 429), main.py never
        calls start() — markets added later via auto-refill or the admin
        API were then quoted on a book fetched exactly once, until the
        STALE_DATA breaker halted trading. Any subscribe path now lazily
        (re)arms the loop.
        """
        if self._poll_task is None or self._poll_task.done():
            self._running = True
            self._poll_task = asyncio.create_task(
                self._poll_loop(), name="limitless_book_poll"
            )
            log.info("limitless_poll_loop_started")

    async def stop(self) -> None:
        self._running = False
        if self._poll_task:
            self._poll_task.cancel()
            try:
                await self._poll_task
            except (asyncio.CancelledError, Exception):
                pass
        if self._session:
            await self._session.close()
        log.info("limitless_service_stopped")

    async def _init_live_client(self) -> None:
        """Load wallet + profile (ownerId, feeRateBps)."""
        _ensure_eth_deps()
        from eth_account import Account

        pk = settings.limitless_private_key
        if not pk:
            raise RuntimeError("LIMITLESS_PRIVATE_KEY not set")
        if not settings.limitless_api_token_id or not settings.limitless_api_secret:
            raise RuntimeError(
                "LIMITLESS_API_TOKEN_ID / LIMITLESS_API_SECRET not set "
                "(generate at limitless.exchange → profile → Api keys)"
            )
        self._account = Account.from_key(pk)

        profile = await self._request("GET", "/profiles/me")
        if not profile or "id" not in profile:
            raise RuntimeError(f"Failed to fetch Limitless profile: {profile}")
        self._owner_id = int(profile["id"])
        # rank.feeRateBps — REQUIRED in signed orders on fee-bearing markets.
        # Hardcoding 0 works only on zero-fee markets (per official docs).
        rank = profile.get("rank") or {}
        self._fee_rate_bps = int(rank.get("feeRateBps", 0))
        log.info(
            "limitless_profile_loaded",
            owner_id=self._owner_id,
            fee_rate_bps=self._fee_rate_bps,
            address=self._account.address[:10],
        )

    # ── auth ──────────────────────────────────────────────────────────

    def _sign_request(self, method: str, path: str, body: str = "") -> dict:
        """HMAC-SHA256 per Limitless docs.

        message = "{ISO timestamp}\\n{METHOD}\\n{path+query}\\n{body}"
        Timestamp must be within 30s of server time → keep host NTP-synced.
        """
        timestamp = datetime.now(timezone.utc).isoformat()
        message = f"{timestamp}\n{method}\n{path}\n{body}"
        secret = base64.b64decode(settings.limitless_api_secret)
        signature = base64.b64encode(
            hmac_mod.new(secret, message.encode("utf-8"), hashlib.sha256).digest()
        ).decode("utf-8")
        return {
            "lmts-api-key": settings.limitless_api_token_id,
            "lmts-timestamp": timestamp,
            "lmts-signature": signature,
        }

    async def _request(
        self, method: str, path: str, body: dict | None = None
    ) -> Any:
        # v1.0.149 FIX: main.py calls discover_markets() BEFORE start() —
        # create the session lazily instead of asserting it exists.
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=15)
            )
        body_str = json.dumps(body) if body is not None else ""
        headers = self._sign_request(method, path, body_str)
        if body is not None:
            headers["Content-Type"] = "application/json"
        try:
            async with self._session.request(
                method, f"{API_BASE}{path}",
                data=body_str if body is not None else None,
                headers=headers,
            ) as resp:
                if resp.status == 425:
                    # Receive-window / stale timestamp. Docs: do NOT retry the
                    # same signed payload — caller must rebuild + resign.
                    log.warning("limitless_425_too_early", path=path)
                    return {"error": "425_too_early"}
                if resp.status == 429:
                    # Cloudflare rate limit (error code 1015) — body is plain
                    # text, not JSON. Verified live 2026-07-12: polling too
                    # many books trips this per-IP limit.
                    log.warning(
                        "limitless_rate_limited",
                        path=path,
                        retry_after=resp.headers.get("Retry-After"),
                    )
                    return {"error": "http_429"}
                if resp.status == 503:
                    # Maintenance mode (post_only / cancel_only / disabled)
                    data = await resp.json(content_type=None)
                    log.warning("limitless_maintenance", mode=data.get("mode"))
                    return {"error": "maintenance", **(data or {})}
                data = await resp.json(content_type=None)
                if resp.status >= 400:
                    log.warning(
                        "limitless_http_error",
                        path=path, status=resp.status,
                        message=str(data)[:200],
                    )
                    return {"error": f"http_{resp.status}", "detail": data}
                return data
        except Exception as e:
            log.warning("limitless_request_failed", path=path, error=str(e))
            return None

    # ── market discovery ──────────────────────────────────────────────

    async def discover_markets(self) -> list[MarketInfo]:
        """GET /markets/active → top auto_pick_count MarketInfo (YES token).

        Mirrors ClobService.discover_markets contract: filter by spread band
        [auto_pick_min_spread_cents, 30¢] and mid-price band [0.10, 0.90],
        score candidates, return the top auto_pick_count picks.

        Field mapping verified against the live payload (2026-07-12):
          expirationTimestamp — ms epoch (expirationDate is "Jul 12, 2026",
            NOT ISO — fromisoformat fails → every market fell back to now+24h,
            breaking PRE_RESOLUTION_EXIT on hourly markets);
          volumeFormatted — human USDC ("volume" is a raw 6-decimals string,
            ×1e6 inflated); metadata.fee — per-market fee flag (no
            "feeBearing" key); negRiskRequestId/groupId (no "group" key);
          tradePrices.{sell,buy}.market[0] — best bid/ask for YES.
        """
        data = await self._request("GET", "/markets/active")
        if not data or "error" in (data if isinstance(data, dict) else {}):
            return []
        raw_markets = data if isinstance(data, list) else data.get("data", [])
        min_spread = settings.auto_pick_min_spread_cents / 100.0
        now_ts = time.time()
        # v1.0.150: don't pick a market that will hit PRE_RESOLUTION_EXIT
        # within 5 minutes of being picked (observed live: refill re-picked
        # the expiring daily whose spread ballooned to 30¢ right before
        # resolution, wasting the slot on an emptying book). ClobService
        # uses a flat 1h guard — that would permanently exclude Limitless
        # hourly markets, so the horizon adapts to pre_resolution_exit_sec.
        min_ttr_sec = settings.pre_resolution_exit_sec + 300.0
        candidates: list[tuple[float, MarketInfo, _MarketMeta, float, dict]] = []
        for m in raw_markets:
            try:
                slug = m["slug"]
                tokens = m.get("tokens") or {}
                yes_token = str(tokens.get("yes", ""))
                no_token = str(tokens.get("no", ""))
                if not yes_token:
                    continue
                venue = m.get("venue") or {}
                exp_ms = m.get("expirationTimestamp")
                if exp_ms:
                    end_ts = float(exp_ms) / 1000.0
                else:
                    end_ts = _parse_iso_ts(
                        m.get("deadline") or m.get("expirationDate") or ""
                    )
                if end_ts - now_ts < min_ttr_sec:
                    continue
                try:
                    vol_24h = float(m.get("volumeFormatted") or 0.0)
                except (TypeError, ValueError):
                    vol_24h = 0.0
                # Best bid/ask for YES from tradePrices (index 0 = YES):
                # sell-at-market hits the best bid, buy-at-market lifts the ask.
                tp = m.get("tradePrices") or {}
                try:
                    best_bid = float(((tp.get("sell") or {}).get("market") or [0])[0])
                    best_ask = float(((tp.get("buy") or {}).get("market") or [0])[0])
                except (TypeError, ValueError, IndexError):
                    best_bid = best_ask = 0.0
                spread = (
                    best_ask - best_bid if best_bid > 0 and best_ask > 0 else 0.0
                )
                if spread < min_spread:
                    continue
                # Same guard as ClobService v1.0.44: spread > 30¢ = near-empty
                # book, MM can't operate there.
                if spread > 0.30:
                    continue
                mid = (best_bid + best_ask) / 2.0
                if mid < 0.10 or mid > 0.90:
                    continue
                metadata = m.get("metadata") or {}
                # settings.minSize (fallback metadata.minSize): LP-rewards
                # qualification threshold in shares, raw 6-decimals string.
                raw_min = (m.get("settings") or {}).get("minSize")
                if raw_min is None:
                    raw_min = metadata.get("minSize")
                try:
                    min_size_shares = float(raw_min) / 1e6 if raw_min else 0.0
                except (TypeError, ValueError):
                    min_size_shares = 0.0
                info = MarketInfo(
                    token_id=yes_token,
                    condition_id=slug,  # slug plays the conditionId role
                    question=m.get("title") or m.get("question") or slug,
                    outcome="Yes",
                    end_date_ts=end_ts,
                    volume_24h=vol_24h,
                    tick_size=0.01,
                    neg_risk=bool(
                        m.get("negRiskRequestId") or m.get("groupId")
                    ),
                    min_size=min_size_shares,
                )
                meta = _MarketMeta(
                    slug=slug,
                    venue_exchange=str(venue.get("exchange") or ""),
                    venue_adapter=str(venue.get("adapter") or ""),
                    yes_token=yes_token,
                    no_token=no_token,
                    fee_bearing=bool(metadata.get("fee", False)),
                )
                # v1.0.155 (GLM §3): HARD volume floor — a wide spread on a
                # dead book is a trap, not an edge. No volume → never picked.
                # v1.0.159: …UNLESS the market is simply too YOUNG to have any
                # 24h volume yet (deadlock 2026-07-14: after the 16:00 rollover
                # every fresh daily had <$50k and the bot was left with ZERO
                # markets). Young markets skip the volume check and are judged
                # on book DEPTH instead — checked below, after the cheap
                # spread/price filters, so we only pay for the extra orderbook
                # request on real candidates.
                created_ts = _parse_iso_ts(m.get("createdAt") or "")
                age_sec = now_ts - created_ts if created_ts else 1e9
                is_young = age_sec < settings.auto_pick_young_market_age_sec
                needs_depth_check = vol_24h < settings.auto_pick_min_volume_usd
                if needs_depth_check and not is_young:
                    continue
                if needs_depth_check and is_young:
                    # Young market: volume is excused, DEPTH is not. A thin
                    # book (the ARB/HYPE tail source) must not slip through.
                    if not await self._has_min_depth(slug):
                        log.info(
                            "limitless_young_market_too_thin",
                            slug=slug,
                            age_min=round(age_sec / 60, 0),
                            reason="young market exempt from volume floor but book too thin",
                        )
                        continue
                    log.info(
                        "limitless_young_market_exempt",
                        slug=slug,
                        age_min=round(age_sec / 60, 0),
                        volume_24h=round(vol_24h, 0),
                        reason="too young for 24h volume — passed on spread + depth",
                    )
                # Same scoring shape as ClobService, with 1+vol so brand-new
                # hourly markets (volume 0) still rank by uncertainty×spread.
                uncertainty = 1.0 - abs(mid - 0.5) * 2
                spread_bonus = 1.0 + (spread * 50)
                # v1.0.155: preferred-spread bonus (wide-but-liquid wins)
                preferred_bonus = (
                    1.5
                    if spread * 100.0 >= settings.auto_pick_preferred_spread_cents
                    else 1.0
                )
                volume_score = 1.0 + vol_24h
                score = volume_score * uncertainty * spread_bonus * preferred_bonus
                candidates.append(
                    (score, info, meta, spread,
                     {"spread_score": round(spread_bonus, 2),
                      "volume_score": round(volume_score, 0),
                      "uncertainty": round(uncertainty, 3),
                      "preferred_bonus": preferred_bonus})
                )
            except Exception as e:
                log.warning("limitless_market_parse_failed", error=str(e))
        candidates.sort(key=lambda x: x[0], reverse=True)
        top = candidates[: settings.auto_pick_count]
        out: list[MarketInfo] = []
        for score, info, meta, spread, breakdown in top:
            self._meta[info.token_id] = meta
            self._slug_by_token[info.token_id] = meta.slug
            self.markets[info.token_id] = info
            # v1.0.157: the API just listed it as active → polling allowed again
            self._dead_markets.discard(info.token_id)
            out.append(info)
            log.info(
                "limitless_market_picked",
                question=info.question[:55],
                spread_cents=round(spread * 100, 1),
                volume_24h=round(info.volume_24h, 0),
                score=round(score, 1),
                score_breakdown=breakdown,
                lp_rewards_min_shares=info.min_size,
            )
        log.info(
            "limitless_markets_discovered",
            candidates=len(candidates),
            picked=len(out),
            total_active=len(raw_markets),
            min_spread_cents=settings.auto_pick_min_spread_cents,
        )
        return out

    async def _has_min_depth(self, slug: str) -> bool:
        """v1.0.159: does the book carry real size on BOTH sides?

        Used only for the young-market volume exemption: a fresh market has
        no 24h volume by definition, so we judge its liveness by depth
        instead. Resting notional on each side must cover at least
        auto_pick_young_min_depth_mult × our order size.
        """
        required = (
            settings.order_size_usdc * settings.auto_pick_young_min_depth_mult
        )
        if required <= 0:
            return True
        data = await self._request("GET", f"/markets/{slug}/orderbook")
        if not data or not isinstance(data, dict) or "error" in data:
            return False

        def notional(levels: list) -> float:
            total = 0.0
            for lvl in levels or []:
                try:
                    if isinstance(lvl, dict):
                        price, size = float(lvl["price"]), float(lvl["size"])
                    else:
                        price, size = float(lvl[0]), float(lvl[1])
                    total += price * size
                except (TypeError, ValueError, KeyError, IndexError):
                    continue
            return total

        bid_usd = notional(data.get("bids"))
        ask_usd = notional(data.get("asks"))
        return bid_usd >= required and ask_usd >= required

    async def fetch_market_status(self, token_id: str) -> dict | None:
        slug = self._slug_by_token.get(token_id)
        if not slug:
            return None
        m = await self._request("GET", f"/markets/{slug}")
        if not m or "error" in (m or {}):
            return None
        # Shape compat with ClobService.fetch_market_status consumers:
        status = str(m.get("status", ""))
        return {
            "active": status in ("FUNDED", "FUNDED_FLAGGED"),
            "closed": status in ("RESOLVED", "LOCKED"),
            "raw": m,
        }

    # ── order book polling ────────────────────────────────────────────

    async def _poll_loop(self) -> None:
        """REST polling of orderbooks.

        v1 uses polling (same fallback pattern botmm already has for
        Polymarket). Socket.IO WS (/markets namespace) is a later upgrade —
        python-socketio client needed, see websocket-events docs.
        """
        interval = getattr(settings, "limitless_book_poll_sec", 1.5)
        while self._running:
            try:
                await asyncio.gather(
                    *(self._fetch_book(tid) for tid in list(self.books.keys()))
                )
            except Exception as e:
                log.warning("limitless_poll_error", error=str(e))
            await asyncio.sleep(interval)

    async def _fetch_book(self, token_id: str) -> None:
        slug = self._slug_by_token.get(token_id)
        if not slug:
            # v1.0.150 observability: this and the empty-payload case below
            # were silent — 18 transient STALE_DATA halts on 2026-07-12 gave
            # zero log evidence. Errors are already logged inside _request;
            # here we only log the previously-invisible reasons.
            log.warning("limitless_book_no_slug", token=token_id[:12])
            return
        # v1.0.157 noise cleanup: a resolved market keeps getting polled until
        # the next refill, and every poll returns HTTP 400 "Market is not
        # active" (13,315 such rows in one session). Once seen, mark it dead
        # and stop polling; discover_markets() clears the flag when the market
        # comes back as active.
        if token_id in self._dead_markets:
            return
        data = await self._request("GET", f"/markets/{slug}/orderbook")
        if data is None:
            return  # network/HTTP failure — already logged inside _request
        if isinstance(data, dict) and data.get("error") == "http_400" and (
            "not active" in str(data.get("detail", "")).lower()
        ):
            self._dead_markets.add(token_id)
            log.info(
                "limitless_market_inactive_stop_polling",
                slug=slug,
                reason="market resolved/inactive — no polling until next refill",
            )
            return
        if not data or "error" in data:
            if "error" not in data:
                log.warning(
                    "limitless_book_empty_payload",
                    slug=slug,
                    data_type=type(data).__name__,
                )
            return
        book = self.books.setdefault(token_id, MarketBook(token_id=token_id))

        def parse(raw: list) -> list[OrderLevel]:
            out = []
            for lvl in raw or []:
                try:
                    if isinstance(lvl, dict):
                        out.append(OrderLevel(
                            price=float(lvl["price"]), size=float(lvl["size"])
                        ))
                    else:  # [price, size] pair
                        out.append(OrderLevel(price=float(lvl[0]), size=float(lvl[1])))
                except Exception:
                    continue
            return out

        bids = parse(data.get("bids"))
        asks = parse(data.get("asks"))
        book.bids = sorted(bids, key=lambda x: -x.price)
        book.asks = sorted(asks, key=lambda x: x.price)
        book.last_update = time.monotonic()
        # Limitless has NO $5 exchange minimum — dust logic keys off this.
        book.min_order_size = getattr(settings, "limitless_min_order_usdc", 0.0)
        self._last_book_update = time.monotonic()

    async def _refresh_all_books(self) -> None:
        """One-shot refresh of every tracked book (ClobService compat —
        called by MM auto-refill and /api/markets/replace)."""
        tids = list(self.books.keys())
        if tids:
            await asyncio.gather(
                *(self._fetch_book(tid) for tid in tids),
                return_exceptions=True,
            )

    # ── trading ───────────────────────────────────────────────────────

    async def place_order(
        self,
        token_id: str,
        side: str,  # "BUY" | "SELL"
        price: float,
        size_usdc: float,
        order_type: str = "GTC",  # GTC | FOK | FAK
        post_only: bool = True,
    ) -> OrderResult:
        """Same contract as ClobService.place_order.

        Amount math (per official docs, GTC):
          shares      = size_usdc / price
          BUY : makerAmount = price*shares*1e6, takerAmount = shares*1e6
          SELL: makerAmount = shares*1e6,       takerAmount = price*shares*1e6
        """
        if side not in ("BUY", "SELL"):
            return OrderResult(success=False, error=f"Invalid side: {side}")
        if not (0.01 <= price <= 0.99):
            return OrderResult(success=False, error=f"Price out of range: {price}")

        # PAPER: identical simulation semantics to ClobService
        if settings.paper_trading:
            now_ms = int(time.time() * 1000)
            return OrderResult(
                success=True,
                order_id=f"PAPER-LMTS-{now_ms}-{side[0]}",
                raw={"price": str(price), "size_usdc": size_usdc},
            )

        meta = self._meta.get(token_id)
        if not meta:
            return OrderResult(success=False, error="Unknown market for token")
        if not meta.venue_exchange:
            return OrderResult(success=False, error="Missing venue.exchange")
        if order_type == "GTD":
            order_type = "GTC"  # Limitless has no GTD; expiration must be 0

        from eth_account import Account
        from eth_account.messages import encode_typed_data
        from web3 import Web3

        shares = size_usdc / price
        if side == "BUY":
            maker_amount = int(round(price * shares * 1e6))
            taker_amount = int(round(shares * 1e6))
            side_int = 0
        else:
            maker_amount = int(round(shares * 1e6))
            taker_amount = int(round(price * shares * 1e6))
            side_int = 1

        fee_bps = self._fee_rate_bps if meta.fee_bearing else 0

        order_data = {
            "salt": int(time.time() * 1000),
            "maker": Web3.to_checksum_address(self._account.address),
            "signer": Web3.to_checksum_address(self._account.address),
            "taker": ZERO_ADDR,
            "tokenId": token_id,
            "makerAmount": maker_amount,
            "takerAmount": taker_amount,
            "expiration": 0,   # must be 0 — non-zero rejected
            "nonce": 0,        # must be 0 — non-zero rejected
            "feeRateBps": fee_bps,
            "side": side_int,
            "signatureType": 0,  # EOA
        }
        encoded = encode_typed_data({
            "types": ORDER_TYPES,
            "primaryType": "Order",
            "domain": {
                "name": EIP712_DOMAIN_NAME,
                "version": EIP712_DOMAIN_VERSION,
                "chainId": CHAIN_ID,
                "verifyingContract": Web3.to_checksum_address(meta.venue_exchange),
            },
            "message": order_data,
        })
        sig = Account.sign_message(
            encoded, private_key=settings.limitless_private_key
        ).signature.hex()
        if not sig.startswith("0x"):
            sig = "0x" + sig

        body = {
            "order": {**order_data, "signature": sig},
            "ownerId": self._owner_id,
            "orderType": order_type,
            "marketSlug": meta.slug,
            # Self-trade prevention: cancel_taker = reject incoming order
            # instead of eating our own resting quote. Critical for MM —
            # our bid and ask must never fill against each other.
            "stpPolicy": "cancel_taker",
        }
        if post_only and order_type == "GTC":
            body["postOnly"] = True

        resp = await self._request("POST", "/orders", body)
        if not resp or "error" in (resp or {}):
            return OrderResult(
                success=False,
                error=str((resp or {}).get("error", "no_response")),
                raw=resp,
            )
        order = resp.get("order") or {}
        execution = resp.get("execution") or {}
        settlement = execution.get("settlementStatus", "")
        if settlement in ("FAILED", "CANCELED"):
            return OrderResult(
                success=False,
                error=f"settlement:{settlement}:{execution.get('reason','')}",
                raw=resp,
            )
        return OrderResult(
            success=True,
            order_id=str(order.get("id", "")),
            raw={
                "price": str(price),
                "settlementStatus": settlement,
                "matched": execution.get("matched", False),
                "feeRateBps": execution.get("feeRateBps", 0),
                "effectiveFeeBps": execution.get("effectiveFeeBps", 0),
            },
        )

    async def cancel_order(self, order_id: str) -> bool:
        if settings.paper_trading or order_id.startswith("PAPER"):
            return True
        resp = await self._request("DELETE", f"/orders/{order_id}")
        ok = bool(resp is not None and "error" not in (resp or {}))
        if not ok:
            log.warning("limitless_cancel_failed", order_id=order_id[:16])
        return ok

    async def cancel_all(self) -> int:
        """Cancel all open orders across our markets.

        Limitless cancel-all is PER-MARKET (DELETE /orders/all/:slug),
        so iterate over known slugs.
        """
        if settings.paper_trading:
            return 0
        n = 0
        for slug in set(self._slug_by_token.values()):
            resp = await self._request("DELETE", f"/orders/all/{slug}")
            if resp is not None and "error" not in (resp or {}):
                n += 1
        return n

    async def get_open_orders(self) -> list[dict]:
        """UNVERIFIED shape: GET /markets/:slug/user-orders per market."""
        out: list[dict] = []
        for slug in set(self._slug_by_token.values()):
            resp = await self._request("GET", f"/markets/{slug}/user-orders")
            if isinstance(resp, list):
                out.extend(resp)
            elif isinstance(resp, dict) and isinstance(resp.get("data"), list):
                out.extend(resp["data"])
        return out

    async def get_positions(self) -> list[dict]:
        """v1.0.154: wallet positions for post-crash drift reconciliation.

        GET /portfolio/positions — UNVERIFIED shape (verify on LIVE smoke).
        Returns [{token_id, tokens}] with defensive parsing; [] on failure.
        """
        resp = await self._request("GET", "/portfolio/positions")
        if not resp or "error" in (resp if isinstance(resp, dict) else {}):
            return []
        raw = resp if isinstance(resp, list) else resp.get("data", [])
        out: list[dict] = []
        for p in raw or []:
            try:
                token = str(
                    p.get("tokenId") or p.get("token_id") or p.get("asset") or ""
                )
                tokens = float(
                    p.get("tokens") or p.get("size") or p.get("amount") or 0.0
                )
                if token:
                    out.append({"token_id": token, "tokens": tokens})
            except (TypeError, ValueError):
                continue
        return out

    async def get_balance_allowance(self) -> dict[str, Any]:
        """USDC balance/allowance for bankroll sync (v1.0.119 path).

        GET /portfolio/allowance — used by sync_bankroll_from_wallet().
        UNVERIFIED: exact response field names; log raw on first LIVE run.
        """
        resp = await self._request("GET", "/portfolio/allowance")
        if not resp or "error" in (resp or {}):
            return {}
        return resp

    @property
    def last_ws_msg_age(self) -> float:
        """Compat: MM core treats this as 'book data freshness'."""
        return time.monotonic() - self._last_book_update


class _FeedShim:
    """Compat with ClobService._feed for MM core and admin API.

    Callers (market_maker auto-refill, /api/markets/replace) also use
    _subscribed, start() and stop() — books dict is the source of truth,
    the REST poll loop picks up membership changes on its next tick.
    """

    def __init__(self, svc: LimitlessService) -> None:
        self._svc = svc
        self._subscribed: set[str] = set()

    async def unsubscribe(self, token_id: str) -> None:
        self._subscribed.discard(token_id)
        self._svc.books.pop(token_id, None)

    async def subscribe(self, token_id: str) -> None:
        self._subscribed.add(token_id)
        self._svc.books.setdefault(token_id, MarketBook(token_id=token_id))
        self._svc._ensure_polling()

    async def start(self, token_ids: list[str]) -> None:
        for tid in token_ids:
            await self.subscribe(tid)

    async def stop(self) -> None:
        self._subscribed.clear()


def _parse_iso_ts(s: str) -> float:
    if not s:
        return time.time() + 86400
    try:
        return datetime.fromisoformat(str(s).replace("Z", "+00:00")).timestamp()
    except Exception:
        return time.time() + 86400
