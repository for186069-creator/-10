"""HARDCODED SPREAD LOGIC — THE UNBREAKABLE CORE INVARIANT.

v1.0.148 (Claude, per Jiji's direct order 2026-07-11):

    "бот живе в спреді — купує на 15 пунктів вище бід і продає
     на 15 пунктів нижче аск. ЦЕ МАЄ БУТИ НЕЗЛАМНА ХАРДКОД ЛОГІКА."

    BUY  = best_bid + 15 points (0.0015)
    SELL = best_ask - 15 points (0.0015)

This module is the SINGLE SOURCE OF TRUTH for quote pricing.

DESIGN RULES (do not violate — reviewers, reject any PR that does):
  1. All constants below are Python module-level FINAL values. They are
     NOT read from settings, NOT read from .env, NOT read from the DB,
     NOT changeable from the admin API. No config can alter them.
  2. market_maker.py MUST price Level-1 quotes exclusively through
     hardcoded_quotes(). Any other price path for entry quotes is a bug.
  3. Every quote MUST pass validate_quote() immediately before placement.
     A quote that fails validation is DROPPED, never "fixed up".
  4. Inventory skew, Kyle lambda, A-S optimal spread, adaptive gap —
     these may decide WHICH side to quote and HOW MUCH size, but they
     may NEVER move the PRICE of an entry quote.

The economics this enforces:
    profit per round trip = market_spread - 2 × 0.0015
    → a market needs spread > 0.30¢ just to break even,
    → the AUTO_PICK_MIN_SPREAD_CENTS filter (≥ 2¢) keeps us in markets
      where each round trip nets ≥ 1.7¢ per share.
"""

from __future__ import annotations

from dataclasses import dataclass

# ═══════════════════════════════════════════════════════════════════════
# THE CONSTANTS. HARDCODED. FINAL. NOT CONFIGURABLE.
# ═══════════════════════════════════════════════════════════════════════

#: 15 points = $0.0015. Jiji's spec: buy bid+15pts, sell ask-15pts.
HARDCODED_ENTRY_OFFSET: float = 0.0015

#: Deeper levels stand further from the edges (multi-level mode).
#: Level 1 IS the 15-point rule. Levels 2/3 are 2x/3x — also hardcoded.
HARDCODED_LEVEL_OFFSETS: dict[int, float] = {
    1: 0.0015,  # 15 points — THE rule
    2: 0.0030,  # 30 points
    3: 0.0045,  # 45 points
}

#: v1.0.155 (GLM §6, затверджено Jiji): front-loaded SIZE split across
#: levels. L1 (15pt) fills most often → most capital; L3 rarely → least.
#: Part of the ethalon: module-level, NOT configurable, sums to 1.0.
#: (Sizes only — prices remain governed by the offsets above.)
HARDCODED_LEVEL_SIZE_PCT: dict[int, float] = {
    1: 0.60,
    2: 0.25,
    3: 0.15,
}

#: Absolute price bounds of a prediction market share.
PRICE_FLOOR: float = 0.01
PRICE_CEIL: float = 0.99

#: Minimum room our two quotes need inside the market spread.
#: bid+off and ask-off must not touch or cross: spread > 2*offset.
def _min_spread_for_level(level: int) -> float:
    off = HARDCODED_LEVEL_OFFSETS.get(level, HARDCODED_ENTRY_OFFSET)
    return 2.0 * off


@dataclass(frozen=True)
class HardcodedQuote:
    """Immutable result of the hardcoded pricing rule."""

    bid: float   # our BUY price  = best_bid + offset
    ask: float   # our SELL price = best_ask - offset
    level: int
    offset: float


def hardcoded_quotes(
    best_bid: float, best_ask: float, level: int = 1
) -> HardcodedQuote | None:
    """THE pricing rule. Returns None when the market has no room.

    bid = best_bid + offset(level)
    ask = best_ask - offset(level)

    No skew. No config. No adaptive anything. If you need a different
    price — you don't; re-read the module docstring.
    """
    offset = HARDCODED_LEVEL_OFFSETS.get(level)
    if offset is None:
        return None
    if best_bid <= 0.0 or best_ask >= 1.0 or best_ask <= best_bid:
        return None  # empty/degenerate book
    spread = best_ask - best_bid
    if spread <= _min_spread_for_level(level):
        return None  # no room: our quotes would touch or cross

    bid = round(best_bid + offset, 4)
    ask = round(best_ask - offset, 4)

    # Clamp to exchange price bounds; if clamping breaks the geometry,
    # the market is untradeable at this level — skip, don't bend the rule.
    if bid < PRICE_FLOOR or ask > PRICE_CEIL:
        return None
    if not (best_bid < bid < ask < best_ask):
        return None
    return HardcodedQuote(bid=bid, ask=ask, level=level, offset=offset)


def validate_quote(
    our_bid: float | None,
    our_ask: float | None,
    best_bid: float,
    best_ask: float,
) -> tuple[bool, str]:
    """FINAL GATE before any quote hits the exchange.

    Invariants (any violation → drop the quote, log, do NOT auto-fix):
      I1. BUY strictly INSIDE the spread:  best_bid < our_bid < best_ask
      I2. SELL strictly INSIDE the spread: best_bid < our_ask < best_ask
      I3. BUY below SELL:                  our_bid < our_ask (when both)
      I4. BUY at least 15 points above best_bid  (never join/undercut bid)
      I5. SELL at least 15 points below best_ask (never join/overcut ask)
      I6. Prices within [0.01, 0.99]

    Returns (ok, reason). reason == "" when ok.
    """
    eps = 1e-9
    if our_bid is not None:
        if not (PRICE_FLOOR - eps <= our_bid <= PRICE_CEIL + eps):
            return False, f"I6: bid {our_bid} outside [{PRICE_FLOOR},{PRICE_CEIL}]"
        if our_bid <= best_bid + eps:
            return False, f"I1/I4: bid {our_bid} not above best_bid {best_bid}"
        if our_bid >= best_ask - eps:
            return False, f"I1: bid {our_bid} not below best_ask {best_ask} (would cross)"
        if our_bid < best_bid + HARDCODED_ENTRY_OFFSET - 1e-6:
            return False, (
                f"I4: bid {our_bid} closer than 15 points to best_bid {best_bid}"
            )
    if our_ask is not None:
        if not (PRICE_FLOOR - eps <= our_ask <= PRICE_CEIL + eps):
            return False, f"I6: ask {our_ask} outside [{PRICE_FLOOR},{PRICE_CEIL}]"
        if our_ask >= best_ask - eps:
            return False, f"I2/I5: ask {our_ask} not below best_ask {best_ask}"
        if our_ask <= best_bid + eps:
            return False, f"I2: ask {our_ask} not above best_bid {best_bid} (would cross)"
        if our_ask > best_ask - HARDCODED_ENTRY_OFFSET + 1e-6:
            return False, (
                f"I5: ask {our_ask} closer than 15 points to best_ask {best_ask}"
            )
    if our_bid is not None and our_ask is not None:
        if our_bid >= our_ask - eps:
            return False, f"I3: bid {our_bid} >= ask {our_ask} (buy must be below sell)"
    return True, ""
