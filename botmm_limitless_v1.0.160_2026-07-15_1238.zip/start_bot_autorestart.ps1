# ═══════════════════════════════════════════════════════════════════════
# start_bot_autorestart.ps1 — v1.0.154 автостарт бота після збою/світла
# ═══════════════════════════════════════════════════════════════════════
# Нескінченний цикл: запускає бота; якщо процес умирає (краш, kill,
# повернення живлення після відключення) — чекає 10с і перезапускає.
# Кожен (пере)запуск пише рядок у logs\watchdog.log.
#
# ЯК УВІМКНУТИ АВТОСТАРТ ПІСЛЯ ПОВЕРНЕННЯ СВІТЛА (Планувальник завдань):
#   1. Win+R → taskschd.msc → "Створити завдання..." (не "просте")
#   2. Вкладка "Загальні": ім'я botmm-autostart; ✓ "Виконувати з
#      найвищими правами" НЕ потрібно; "Налаштувати для" = Windows 10/11.
#   3. Вкладка "Тригери" → Створити → "При запуску" (At startup),
#      затримка 1 хв (щоб мережа встигла піднятись).
#   4. Вкладка "Дії" → Створити → "Запуск програми":
#        Програма:  powershell.exe
#        Аргументи: -ExecutionPolicy Bypass -WindowStyle Hidden -File "C:\Users\w\Documents\botmm_limitless_v1_0_149\botmm_limitless\start_bot_autorestart.ps1"
#   5. Вкладка "Параметри": ✓ "Якщо завдання зупинено, перезапустити" — 3 рази.
#   6. Вкладка "Умови": ЗНЯТИ ✓ "Запускати лише при живленні від мережі"
#      залишити (ПК стаціонарний) — за смаком.
#   7. OK. Перевірка: перезавантаж ПК — бот має піднятись сам,
#      logs\watchdog.log отримає новий рядок, а бот у лозі напише
#      unclean_shutdown_detected і зробить cancel-all (v1.0.154).
#
# ЗУПИНИТИ ЦИКЛ: закрити вікно PowerShell / завершити завдання в
# Планувальнику; одиночний kill python-процесу призведе до перезапуску.
# ═══════════════════════════════════════════════════════════════════════

$botDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $botDir
if (-not (Test-Path "$botDir\logs")) { New-Item -ItemType Directory -Path "$botDir\logs" | Out-Null }
$watchLog = "$botDir\logs\watchdog.log"

Add-Content -Path $watchLog -Value "$(Get-Date -Format o) watchdog started (dir=$botDir)"

while ($true) {
    Add-Content -Path $watchLog -Value "$(Get-Date -Format o) starting python -m app.main"
    $p = Start-Process -FilePath "python" -ArgumentList "-m","app.main" `
        -WorkingDirectory $botDir -NoNewWindow -PassThru -Wait
    Add-Content -Path $watchLog -Value "$(Get-Date -Format o) bot exited (code=$($p.ExitCode)) — restart in 10s"
    Start-Sleep -Seconds 10
}
