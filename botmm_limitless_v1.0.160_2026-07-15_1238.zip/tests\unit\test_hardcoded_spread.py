"""v1.0.148: THE HARDCODED SPREAD INVARIANT — lock-down tests.

Jiji's spec: BUY = best_bid + 15 points, SELL = best_ask - 15 points.
UNBREAKABLE. These tests are the contract. If any of them fails after
a change — the change broke the core trading rule. Revert the change,
not the test.
"""

import pytest

from app.core.config import settings
from app.services.spread_invariant import (
    HARDCODED_ENTRY_OFFSET,
    HARDCODED_LEVEL_OFFSETS,
    hardcoded_quotes,
    validate_quote,
)


# ── The rule itself ────────────────────────────────────────────────────


def test_the_15_point_rule_exact():
    """Jiji's example: market 0.3200-0.3400 → our 0.3215-0.3385."""
    hq = hardcoded_quotes(0.3200, 0.3400, level=1)
    assert hq is not None
    assert hq.bid == pytest.approx(0.3215)
    assert hq.ask == pytest.approx(0.3385)


def test_offset_constant_is_15_points():
    assert HARDCODED_ENTRY_OFFSET == pytest.approx(0.0015)
    assert HARDCODED_LEVEL_OFFSETS[1] == pytest.approx(0.0015)


def test_buy_always_below_sell():
    for bid, ask in [(0.10, 0.14), (0.48, 0.52), (0.90, 0.95), (0.30, 0.34)]:
        hq = hardcoded_quotes(bid, ask, level=1)
        assert hq is not None
        assert hq.bid < hq.ask, "buy-low-sell-high must hold ALWAYS"
        # exact geometry
        assert hq.bid == pytest.approx(bid + 0.0015)
        assert hq.ask == pytest.approx(ask - 0.0015)


def test_no_room_returns_none_not_bent_prices():
    """Spread ≤ 30 points → NO quotes. Never squeeze/bend the rule."""
    assert hardcoded_quotes(0.500, 0.503, level=1) is None  # 30 pts — touch
    assert hardcoded_quotes(0.500, 0.502, level=1) is None  # 20 pts — cross
    assert hardcoded_quotes(0.500, 0.501, level=1) is None
    # 40 points → room exists
    hq = hardcoded_quotes(0.500, 0.504, level=1)
    assert hq is not None and hq.bid < hq.ask


def test_degenerate_books_skipped():
    assert hardcoded_quotes(0.0, 0.52) is None      # empty bid side
    assert hardcoded_quotes(0.48, 1.0) is None      # empty ask side
    assert hardcoded_quotes(0.52, 0.48) is None     # crossed book
    assert hardcoded_quotes(0.50, 0.50) is None     # locked book


def test_levels_2_3_hardcoded_multiples():
    hq2 = hardcoded_quotes(0.3200, 0.3400, level=2)
    hq3 = hardcoded_quotes(0.3200, 0.3400, level=3)
    assert hq2.bid == pytest.approx(0.3230) and hq2.ask == pytest.approx(0.3370)
    assert hq3.bid == pytest.approx(0.3245) and hq3.ask == pytest.approx(0.3355)


# ── Config sabotage: NOTHING in settings may move the price ───────────


def test_config_cannot_alter_the_rule(monkeypatch):
    """Set every pricing-adjacent config to insane values → price identical."""
    for name, crazy in [
        ("quote_gap_pct", 5.0),
        ("quote_gap_max_cents", 50.0),
        ("quote_gap_kyle_sensitivity", 100.0),
        ("spread_min_cents", 0.0),
    ]:
        if hasattr(settings, name):
            monkeypatch.setattr(settings, name, crazy)
    hq = hardcoded_quotes(0.3200, 0.3400, level=1)
    assert hq.bid == pytest.approx(0.3215)
    assert hq.ask == pytest.approx(0.3385)


# ── The final gate ─────────────────────────────────────────────────────


def test_validate_accepts_the_rule():
    ok, reason = validate_quote(0.3215, 0.3385, 0.3200, 0.3400)
    assert ok, reason


def test_validate_rejects_joining_the_bid():
    ok, reason = validate_quote(0.3200, None, 0.3200, 0.3400)
    assert not ok and "I1" in reason or "I4" in reason


def test_validate_rejects_closer_than_15_points():
    ok, reason = validate_quote(0.3205, None, 0.3200, 0.3400)  # only 5 pts
    assert not ok and "I4" in reason
    ok, reason = validate_quote(None, 0.3395, 0.3200, 0.3400)  # only 5 pts
    assert not ok and "I5" in reason


def test_validate_rejects_crossed_quotes():
    ok, reason = validate_quote(0.3390, 0.3385, 0.3200, 0.3400)
    assert not ok  # bid >= ask → buy-low-sell-high violated


def test_validate_rejects_outside_market():
    ok, _ = validate_quote(0.3450, None, 0.3200, 0.3400)  # bid above ask
    assert not ok
    ok, _ = validate_quote(None, 0.3150, 0.3200, 0.3400)  # ask below bid
    assert not ok


def test_profit_math_documented():
    """Round trip on a 2¢ market nets exactly 2¢ - 2×0.15¢ = 1.7¢/share."""
    hq = hardcoded_quotes(0.3200, 0.3400, level=1)
    profit_per_share = hq.ask - hq.bid
    assert profit_per_share == pytest.approx(0.0170)
