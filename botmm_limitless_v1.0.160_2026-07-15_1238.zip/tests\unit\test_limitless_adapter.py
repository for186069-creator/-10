"""v1.0.147-preview: Limitless adapter unit tests (no network).

Verifies the deterministic parts: HMAC request signing format, EIP-712
order amount math, config selector. Live API behavior needs a real
smoke test (Limitless has no testnet).
"""

import base64

import pytest

from app.core.config import settings
from app.services.limitless_client import LimitlessService


@pytest.fixture
def svc(monkeypatch):
    monkeypatch.setattr(settings, "limitless_api_token_id", "test-token-id")
    monkeypatch.setattr(
        settings, "limitless_api_secret",
        base64.b64encode(b"super-secret").decode(),
    )
    return LimitlessService()


def test_hmac_headers_shape(svc):
    headers = svc._sign_request("POST", "/orders", '{"a":1}')
    assert headers["lmts-api-key"] == "test-token-id"
    assert "lmts-timestamp" in headers
    # ISO-8601 with timezone
    assert "T" in headers["lmts-timestamp"]
    # base64 signature decodes to 32 bytes (SHA256)
    assert len(base64.b64decode(headers["lmts-signature"])) == 32


def test_hmac_signature_deterministic(svc, monkeypatch):
    """Same timestamp+method+path+body → same signature."""
    import app.services.limitless_client as lc

    class FakeDT:
        @staticmethod
        def now(tz):
            from datetime import datetime, timezone
            return datetime(2026, 7, 11, 12, 0, 0, tzinfo=timezone.utc)

    monkeypatch.setattr(lc, "datetime", FakeDT)
    h1 = svc._sign_request("GET", "/markets/active")
    h2 = svc._sign_request("GET", "/markets/active")
    assert h1["lmts-signature"] == h2["lmts-signature"]


def test_order_amount_math_buy():
    """BUY: makerAmount = price*shares*1e6, takerAmount = shares*1e6.
    shares = size_usdc / price."""
    price, size_usdc = 0.50, 5.0
    shares = size_usdc / price  # 10 shares
    maker = int(round(price * shares * 1e6))
    taker = int(round(shares * 1e6))
    assert maker == 5_000_000   # $5.00
    assert taker == 10_000_000  # 10 shares
    # Matches the official docs example exactly (BUY 10 YES @ $0.50)


def test_order_amount_math_sell():
    """SELL: makerAmount = shares*1e6, takerAmount = price*shares*1e6."""
    price, size_usdc = 0.52, 5.2
    shares = size_usdc / price  # 10 shares
    maker = int(round(shares * 1e6))
    taker = int(round(price * shares * 1e6))
    assert maker == 10_000_000
    assert taker == 5_200_000


@pytest.mark.asyncio
async def test_paper_mode_order(svc, monkeypatch):
    monkeypatch.setattr(settings, "paper_trading", True)
    r = await svc.place_order("tok-x", "BUY", 0.48, 5.0)
    assert r.success
    assert r.order_id.startswith("PAPER-LMTS-")


@pytest.mark.asyncio
async def test_invalid_price_rejected(svc, monkeypatch):
    monkeypatch.setattr(settings, "paper_trading", True)
    r = await svc.place_order("tok-x", "BUY", 0.005, 5.0)
    assert not r.success
