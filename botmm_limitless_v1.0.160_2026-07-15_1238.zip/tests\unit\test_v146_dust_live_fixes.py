"""v1.0.146 (Claude): dust × never-cancel interaction fixes.

Covers three holes found in the v1.0.145 review:

1. LIVE liquidation must SKIP positions below the $5 exchange minimum
   (dust_threshold_usdc) — otherwise the bot spams FAK SELLs that
   Polymarket rejects every cycle.
2. Liquidation must FORCE-cancel resting quotes before placing the FAK
   SELL for the whole position. With partial_fill_no_cancel=true a
   partially-filled ask left live could fill in parallel with the FAK
   → sell more tokens than owned (naked short).
3. Shutdown / pause must FORCE-cancel even partially-filled quotes —
   no unmonitored live orders while the bot is offline.
"""

import time
from unittest.mock import AsyncMock, MagicMock

import pytest

from app.core.config import settings
from app.services.inventory_manager import InventoryManager
from app.services.market_maker import ActiveQuote, MarketMaker
from app.services.risk.risk_manager import RiskManager


def _mk_book(bid=0.48, ask=0.52):
    book = MagicMock()
    book.best_bid = bid
    book.best_ask = ask
    book.mid = (bid + ask) / 2
    return book


def _mk_info(name="Test market?"):
    info = MagicMock()
    info.question = name
    info.end_date_ts = time.time() + 86400
    return info


def _mk_mm(monkeypatch, paper=False):
    monkeypatch.setattr(settings, "paper_trading", paper)
    monkeypatch.setattr(settings, "inventory_liquidation_enabled", True)
    monkeypatch.setattr(settings, "inventory_liquidation_aggressive_age_sec", 0.01)
    monkeypatch.setattr(settings, "inventory_liquidation_urgent_age_sec", 0.02)
    monkeypatch.setattr(settings, "dust_threshold_usdc", 5.0)

    clob = MagicMock()
    clob.books = {"tok-A": _mk_book()}
    clob.markets = {"tok-A": _mk_info()}
    ok = MagicMock()
    ok.success = True
    ok.order_id = "ord-liq"
    ok.raw = {"price": "0.50"}
    clob.place_order = AsyncMock(return_value=ok)
    clob.cancel_order = AsyncMock(return_value=True)
    clob.cancel_all = AsyncMock(return_value=0)
    clob.last_ws_msg_age = 1.0

    inventory = InventoryManager()
    inventory.bankroll = 100.0
    risk = RiskManager(inventory, clob)
    mm = MarketMaker(clob, inventory, risk)
    mm._running = True
    return mm


def _add_position(mm, token_id="tok-A", tokens=4.0, entry=0.45):
    """Insert an aged long position directly into inventory.

    v1.0.150: entry default lowered 0.50 → 0.45. With the no-loss exit
    policy an underwater position (entry above the bid) is HELD, so these
    mechanics tests use a profitable position: bid 0.48 > entry 0.45 →
    the PROFIT_SNIPER/URGENT path executes and the mechanics under test
    (dust skip, $5 gate, force-cancel) are actually exercised.
    """
    from app.services.inventory_manager import Inventory

    inv = Inventory(token_id=token_id)
    inv.net_tokens = tokens
    inv.avg_entry_price = entry
    inv.open_time = time.monotonic() - 10_000  # very aged
    mm.inventory.inventories[token_id] = inv
    return inv


@pytest.mark.asyncio
async def test_live_liquidation_skips_dust_below_5usd(monkeypatch):
    """LIVE: position worth ~$2 (< $5 min) must NOT trigger a FAK SELL."""
    mm = _mk_mm(monkeypatch, paper=False)
    _add_position(mm, tokens=4.0)  # 4 tokens ≈ $1.9 — below $5 dust threshold

    await mm._liquidate_aged_positions()

    assert mm.clob.place_order.await_count == 0, (
        "dust position below $5 must be skipped in LIVE — "
        "Polymarket would reject the FAK SELL every cycle"
    )


@pytest.mark.asyncio
async def test_live_liquidation_still_fires_above_5usd(monkeypatch):
    """LIVE: position worth ~$10 (>= $5 min) must still liquidate."""
    mm = _mk_mm(monkeypatch, paper=False)
    _add_position(mm, tokens=20.0)  # 20 tokens ≈ $9.6 — above $5

    await mm._liquidate_aged_positions()

    assert mm.clob.place_order.await_count == 1


@pytest.mark.asyncio
async def test_liquidation_force_cancels_partial_quotes(monkeypatch):
    """Liquidation must cancel a partially-filled resting ask even when
    partial_fill_no_cancel=true — otherwise resting ask + FAK SELL could
    both fill → oversell."""
    mm = _mk_mm(monkeypatch, paper=False)
    monkeypatch.setattr(settings, "partial_fill_no_cancel", True)
    _add_position(mm, tokens=20.0)

    q = ActiveQuote(
        token_id="tok-A",
        level=1,
        bid_price=None,
        ask_price=0.52,
        mid_at_place=0.50,
        size_usdc=10.0,
        reservation_price=0.50,
        spread_cents=2.0,
        ask_filled=True,  # PARTIAL fill on the ask
        ask_order_id="ask-1",
    )
    mm.active_quotes["tok-A"] = [q]

    await mm._liquidate_aged_positions()

    # The partially-filled ask must be GONE from active quotes
    # (force=True overrides never-cancel), and the exchange cancel called.
    assert "tok-A" not in mm.active_quotes or not mm.active_quotes["tok-A"], (
        "partially-filled ask must be force-cancelled before FAK SELL "
        "to prevent overselling the position"
    )
    mm.clob.cancel_order.assert_any_await("ask-1")


@pytest.mark.asyncio
async def test_pause_force_cancels_partial_quotes(monkeypatch):
    """User pause: partially-filled quotes must not stay live on the book."""
    import asyncio

    mm = _mk_mm(monkeypatch, paper=False)
    monkeypatch.setattr(settings, "partial_fill_no_cancel", True)

    q = ActiveQuote(
        token_id="tok-A",
        level=1,
        bid_price=0.48,
        ask_price=None,
        mid_at_place=0.50,
        size_usdc=5.0,
        reservation_price=0.50,
        spread_cents=2.0,
        bid_filled=True,  # PARTIAL fill on the bid
        bid_order_id="bid-1",
    )
    mm.active_quotes["tok-A"] = [q]

    mm.stop_trading()
    await asyncio.sleep(0.05)  # let created cancel tasks run

    assert "tok-A" not in mm.active_quotes or not mm.active_quotes["tok-A"], (
        "pause must remove ALL quotes, including partially-filled ones"
    )
    mm.clob.cancel_order.assert_any_await("bid-1")
