"""
tests/unit/test_v151_momentum_nohedge.py — v1.0.151 features.

Feature 1 — MOMENTUM FILTER: on a fast-moving market the side that would
get run over is blocked (falling → no bid, rising → no ask); the block
releases when momentum fades. Independent of the drawdown stop.

Feature 2 — NO-HEDGE via merge (emergency brake, disabled by default):
deep-underwater YES position + enough time to resolution + cheap enough
insurance → buy NO to fix a known bounded loss.
"""
from __future__ import annotations

import time
from collections import deque
from unittest.mock import AsyncMock, MagicMock

import pytest


def _book(token_id: str, bid: float, ask: float):
    from app.services.clob_client import MarketBook, OrderLevel

    return MarketBook(
        token_id=token_id,
        bids=[OrderLevel(bid, 100)],
        asks=[OrderLevel(ask, 100)],
        last_price=round((bid + ask) / 2, 4),
    )


def _market_info(token_id: str, end_in_sec: float):
    from app.services.clob_client import MarketInfo

    return MarketInfo(
        token_id=token_id,
        condition_id="cond-x",
        question="v151 market",
        outcome="Yes",
        end_date_ts=time.time() + end_in_sec,
        volume_24h=1000.0,
    )


def _make_mm(monkeypatch, *, entry: float, bid: float, ask: float,
             end_in_sec: float = 86400.0):
    from app.core.config import settings
    from app.services.market_maker import MarketMaker
    from app.services.inventory_manager import InventoryManager, Inventory
    from app.services.risk.risk_manager import RiskManager

    monkeypatch.setattr(settings, "paper_trading", True)
    monkeypatch.setattr(settings, "inventory_liquidation_enabled", True)
    monkeypatch.setattr(settings, "momentum_window_sec", 300.0)
    monkeypatch.setattr(settings, "momentum_bid_block_cents", 3.0)
    monkeypatch.setattr(settings, "momentum_ask_block_cents", 3.0)

    tid = "tok-151"
    clob = MagicMock()
    clob.books = {tid: _book(tid, bid, ask)}
    clob.markets = {tid: _market_info(tid, end_in_sec)}
    clob.last_ws_msg_age = 1.0
    clob._meta = {}

    inventory = InventoryManager()
    inventory.bankroll = 100.0
    inv = Inventory(token_id=tid, market_name="v151 market")
    inv.net_tokens = 10.0
    inv.avg_entry_price = entry
    inv.open_time = time.monotonic() - 60.0
    inventory.inventories[tid] = inv

    risk = RiskManager(inventory, clob)
    mm = MarketMaker(clob, inventory, risk)
    mm._running = True
    mm._record_fill = AsyncMock()
    return mm, tid


def _seed_momentum(mm, tid, mid_then: float, mid_now: float, window_ago: float = 400.0):
    """Ring buffer: one sample beyond the window boundary, one fresh."""
    now = time.monotonic()
    mm._mid_history[tid] = deque([(now - window_ago, mid_then), (now, mid_now)])


def _decision():
    d = MagicMock()
    d.allow_bid = True
    d.allow_ask = True
    return d


# ── Feature 1: momentum filter ────────────────────────────────────────────


def test_momentum_falling_blocks_bid_keeps_ask(monkeypatch):
    mm, tid = _make_mm(monkeypatch, entry=0.50, bid=0.46, ask=0.48)
    _seed_momentum(mm, tid, mid_then=0.50, mid_now=0.47)  # −3¢ over window

    d = _decision()
    mm._apply_momentum_filter(tid, "v151 market", d)

    assert d.allow_bid is False, "falling ≥3¢ must block the bid"
    assert d.allow_ask is True, "the ask must keep working on a falling market"
    assert tid in mm._momentum_bid_blocked


def test_momentum_rising_blocks_ask_keeps_bid(monkeypatch):
    mm, tid = _make_mm(monkeypatch, entry=0.50, bid=0.52, ask=0.54)
    _seed_momentum(mm, tid, mid_then=0.50, mid_now=0.53)  # +3¢

    d = _decision()
    mm._apply_momentum_filter(tid, "v151 market", d)

    assert d.allow_ask is False, "rising ≥3¢ must block the ask"
    assert d.allow_bid is True
    assert tid in mm._momentum_ask_blocked


def test_momentum_below_threshold_allows_both(monkeypatch):
    mm, tid = _make_mm(monkeypatch, entry=0.50, bid=0.49, ask=0.51)
    _seed_momentum(mm, tid, mid_then=0.50, mid_now=0.52)  # +2¢ < 3¢

    d = _decision()
    mm._apply_momentum_filter(tid, "v151 market", d)

    assert d.allow_bid is True and d.allow_ask is True
    assert tid not in mm._momentum_bid_blocked
    assert tid not in mm._momentum_ask_blocked


def test_momentum_block_releases_when_faded(monkeypatch):
    mm, tid = _make_mm(monkeypatch, entry=0.50, bid=0.46, ask=0.48)
    _seed_momentum(mm, tid, mid_then=0.50, mid_now=0.47)  # −3¢ → block
    mm._apply_momentum_filter(tid, "v151 market", _decision())
    assert tid in mm._momentum_bid_blocked

    _seed_momentum(mm, tid, mid_then=0.47, mid_now=0.468)  # −0.2¢ → faded
    d = _decision()
    mm._apply_momentum_filter(tid, "v151 market", d)

    assert d.allow_bid is True, "block must release when momentum fades"
    assert tid not in mm._momentum_bid_blocked


def test_momentum_insufficient_history_allows_both(monkeypatch):
    """Buffer younger than the window → no blocking on thin data."""
    mm, tid = _make_mm(monkeypatch, entry=0.50, bid=0.46, ask=0.48)
    now = time.monotonic()
    mm._mid_history[tid] = deque([(now - 30, 0.50), (now, 0.44)])  # 6¢ drop, 30s

    d = _decision()
    mm._apply_momentum_filter(tid, "v151 market", d)

    assert d.allow_bid is True and d.allow_ask is True


# ── Feature 2: NO-hedge (emergency brake) ─────────────────────────────────


def _enable_hedge(monkeypatch, **overrides):
    from app.core.config import settings

    monkeypatch.setattr(settings, "no_hedge_enabled", True)
    monkeypatch.setattr(settings, "no_hedge_trigger_drawdown_cents",
                        overrides.get("trigger", 15.0))
    monkeypatch.setattr(settings, "no_hedge_min_ttr_sec",
                        overrides.get("min_ttr", 3600.0))
    monkeypatch.setattr(settings, "no_hedge_max_loss_cents",
                        overrides.get("max_loss", 25.0))


@pytest.mark.asyncio
async def test_no_hedge_fires_when_conditions_met(monkeypatch):
    """entry 0.45, mid 0.29 (16¢ drawdown ≥ 15), ttr 2h ≥ 1h,
    fixed_loss = 0.45 + (1−0.28) − 1 = 17¢ ≤ 25 → hedge executes."""
    mm, tid = _make_mm(monkeypatch, entry=0.45, bid=0.28, ask=0.30,
                       end_in_sec=7200.0)
    _enable_hedge(monkeypatch)

    await mm._liquidate_aged_positions()

    assert mm._no_hedge_count == 1
    assert tid in mm._hedged_positions
    assert mm._record_fill.called, "PAPER hedge simulates the equivalent SELL"
    args = mm._record_fill.call_args
    assert args.args[1] == "SELL"
    assert args.args[2] == pytest.approx(0.28, abs=1e-6)  # 1 − P_no_ask


@pytest.mark.asyncio
async def test_no_hedge_skipped_when_too_expensive(monkeypatch):
    """Same setup but max_loss 10¢ < fixed_loss 17¢ → insurance too dear."""
    mm, tid = _make_mm(monkeypatch, entry=0.45, bid=0.28, ask=0.30,
                       end_in_sec=7200.0)
    _enable_hedge(monkeypatch, max_loss=10.0)

    await mm._liquidate_aged_positions()

    assert mm._no_hedge_count == 0
    assert tid not in mm._hedged_positions
    assert not mm._record_fill.called


@pytest.mark.asyncio
async def test_no_hedge_skipped_inside_pre_resolution_zone(monkeypatch):
    """ttr 30 min < no_hedge_min_ttr_sec (1h) → pre-resolution owns it."""
    mm, tid = _make_mm(monkeypatch, entry=0.45, bid=0.28, ask=0.30,
                       end_in_sec=1800.0)
    _enable_hedge(monkeypatch)

    await mm._liquidate_aged_positions()

    assert mm._no_hedge_count == 0
    assert not mm._record_fill.called


@pytest.mark.asyncio
async def test_no_hedge_disabled_by_default(monkeypatch):
    """With the flag at its default (False) the brake must never fire."""
    from app.core.config import settings

    mm, tid = _make_mm(monkeypatch, entry=0.45, bid=0.28, ask=0.30,
                       end_in_sec=7200.0)
    monkeypatch.setattr(settings, "no_hedge_enabled", False)

    await mm._liquidate_aged_positions()

    assert mm._no_hedge_count == 0
    assert not mm._record_fill.called
