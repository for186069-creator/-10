"""
tests/unit/test_v153_profit_capture.py — v1.0.153 leftovers still in force.

The linear decay ladder itself was REPLACED by the corridor model in
v1.0.158 (see test_v158_corridor_and_fixes.py) — its tests moved there.
What remains valid from v1.0.153 are the two GLM P0/P1 fixes:
VERSION consistency and the first-principles bankroll recompute on restore.
"""
from __future__ import annotations

import json
import re
import time
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest


# ── GLM P0: VERSION consistency ───────────────────────────────────────────


def test_version_matches_changelog():
    root = Path(__file__).resolve().parents[2]
    version = (root / "VERSION").read_text(encoding="utf-8").strip().splitlines()[0]
    changelog_versions = []
    for p in root.glob("CHANGELOG_v*.md"):
        m = re.match(r"CHANGELOG_v(\d+\.\d+\.\d+)\.md", p.name)
        if m:
            changelog_versions.append(tuple(int(x) for x in m.group(1).split(".")))
    assert changelog_versions, "no changelogs found"
    latest = ".".join(str(x) for x in max(changelog_versions))
    assert version == latest, (
        f"VERSION ({version}) must match the latest changelog ({latest})"
    )


# ── GLM P1: bankroll recompute on restore ─────────────────────────────────


@pytest.mark.asyncio
async def test_bankroll_recomputed_on_restore(monkeypatch):
    """Restart with an open position: restored bankroll must satisfy
    bankroll + Σ(net_tokens × avg_entry) == starting_balance + Σ realized_net,
    regardless of what the (possibly stale) snapshot said."""
    from app.services.inventory_manager import InventoryManager

    inv_mgr = InventoryManager()

    state = MagicMock()
    state.bankroll = 999.0  # stale/wrong snapshot value
    state.starting_balance = 60.0
    state.daily_pnl = 0.0
    state.consecutive_losses = 0
    state.inventories_json = json.dumps({
        "tok-x": {"market_name": "M", "net_tokens": 10.0,
                  "avg_entry_price": 0.30, "realized_pnl": 0.0},
    })

    res_state = MagicMock()
    res_state.scalar_one_or_none.return_value = state
    res_sums = MagicMock()
    res_sums.one.return_value = (12.0, 1.0)  # Σ pnl_usdc, Σ fees_usdc

    db = MagicMock()
    db.execute = AsyncMock(side_effect=[res_state, res_sums])

    ok = await inv_mgr.load_state_from_db(db)
    assert ok

    open_cost = 10.0 * 0.30
    expected = 60.0 + 12.0 - 1.0 - open_cost  # 68.0
    assert inv_mgr.bankroll == pytest.approx(expected)
    # the equity invariant the fix guarantees:
    assert inv_mgr.bankroll + open_cost == pytest.approx(60.0 + 12.0 - 1.0)
