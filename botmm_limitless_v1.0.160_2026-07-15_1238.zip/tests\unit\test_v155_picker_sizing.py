"""
tests/unit/test_v155_picker_sizing.py — v1.0.155 picker/sizing refinements.

§1 Picker: hard 24h-volume floor (wide spread on a dead book is a trap) +
   ×1.5 preferred-spread bonus for wide-but-liquid markets.
§2 Front-loaded level sizes 60/25/15 — hardcoded in spread_invariant,
   settings cannot alter them.
§3 Adverse-rate rotation: >30% adverse fills over the last 20 (≥10) bans
   the market for adverse_market_ban_sec; the ban expires.
"""
from __future__ import annotations

import time
from collections import deque
from unittest.mock import AsyncMock, MagicMock

import pytest


# ── §1 Picker ─────────────────────────────────────────────────────────────


def _market_payload(slug, bid, ask, vol_fmt, exp_in_sec=86400):
    return {
        "slug": slug,
        "tokens": {"yes": f"yes-{slug}", "no": f"no-{slug}"},
        "venue": {"exchange": "0xE", "adapter": None},
        "expirationTimestamp": (time.time() + exp_in_sec) * 1000,
        "volumeFormatted": str(vol_fmt),
        "tradePrices": {
            "sell": {"market": [bid, 0]},
            "buy": {"market": [ask, 0]},
        },
        "title": slug,
        "metadata": {"fee": True},
        "settings": {"minSize": "100000000"},
    }


async def _discover(monkeypatch, markets, count=4):
    from app.core.config import settings
    from app.services.limitless_client import LimitlessService

    monkeypatch.setattr(settings, "auto_pick_count", count)
    monkeypatch.setattr(settings, "auto_pick_min_spread_cents", 2.0)
    monkeypatch.setattr(settings, "auto_pick_preferred_spread_cents", 5.0)
    monkeypatch.setattr(settings, "auto_pick_min_volume_usd", 50000.0)
    monkeypatch.setattr(settings, "pre_resolution_exit_sec", 300)

    svc = LimitlessService()
    svc._request = AsyncMock(return_value={"data": markets})
    return await svc.discover_markets()


@pytest.mark.asyncio
async def test_picker_volume_floor_rejects_dead_book(monkeypatch):
    """8¢ spread on a $10k book → NOT picked; 5¢ on $100k → picked."""
    picked = await _discover(monkeypatch, [
        _market_payload("dead-wide", bid=0.40, ask=0.48, vol_fmt=10000),
        _market_payload("liquid-ok", bid=0.40, ask=0.45, vol_fmt=100000),
    ])
    slugs = [p.condition_id for p in picked]
    assert "liquid-ok" in slugs
    assert "dead-wide" not in slugs, (
        "wide spread on a dead book must NEVER be picked (hard volume floor)"
    )


@pytest.mark.asyncio
async def test_picker_preferred_bonus_lifts_wide_over_tight(monkeypatch):
    """Equal volume, same mid: 6¢ market must outrank 3¢ (×1.5 bonus)."""
    picked = await _discover(monkeypatch, [
        _market_payload("tight-3c", bid=0.485, ask=0.515, vol_fmt=100000),
        _market_payload("wide-6c", bid=0.47, ask=0.53, vol_fmt=100000),
    ], count=1)
    assert len(picked) == 1
    assert picked[0].condition_id == "wide-6c", (
        "preferred-spread bonus must lift the 6¢ market above the 3¢ one"
    )


# ── §2 Front-loaded hardcoded sizes ───────────────────────────────────────


def test_level_size_pcts_hardcoded_and_sum_to_one(monkeypatch):
    from app.core.config import settings
    from app.services.spread_invariant import HARDCODED_LEVEL_SIZE_PCT
    from app.services.pricing.spread_optimizer import SpreadOptimizer

    assert HARDCODED_LEVEL_SIZE_PCT == {1: 0.60, 2: 0.25, 3: 0.15}
    assert sum(HARDCODED_LEVEL_SIZE_PCT.values()) == pytest.approx(1.0)

    # sabotage: settings must NOT move the split
    monkeypatch.setattr(settings, "multi_level_enabled", True)
    for name in ("multi_level_1_size_pct", "multi_level_2_size_pct", "multi_level_3_size_pct"):
        monkeypatch.setattr(settings, name, 0.99)
    levels = SpreadOptimizer.compute_levels(6.0)
    assert [pct for _, pct in levels] == [0.60, 0.25, 0.15], (
        "size split is part of the ethalon — config cannot alter it"
    )


def test_l1_gets_60pct_of_base(monkeypatch):
    from app.core.config import settings
    from app.services.pricing.spread_optimizer import SpreadOptimizer

    monkeypatch.setattr(settings, "multi_level_enabled", True)
    levels = SpreadOptimizer.compute_levels(6.0)
    base = 10.0
    sizes = [base * pct for _, pct in levels]
    assert sizes[0] == pytest.approx(6.0)   # 60% front-load on L1
    assert sizes[1] == pytest.approx(2.5)
    assert sizes[2] == pytest.approx(1.5)


# ── §3 Adverse-rate rotation ──────────────────────────────────────────────


def _mk_mm(monkeypatch, tmp_path):
    import app.services.market_maker as mm_mod
    from app.core.config import settings
    from app.services.market_maker import MarketMaker
    from app.services.inventory_manager import InventoryManager
    from app.services.risk.risk_manager import RiskManager

    monkeypatch.setattr(mm_mod, "RUNNING_LOCK_PATH", tmp_path / "RUNNING.lock")
    monkeypatch.setattr(settings, "paper_trading", True)
    monkeypatch.setattr(settings, "adverse_market_ban_sec", 3600.0)

    clob = MagicMock()
    clob.books = {}
    clob.markets = {}
    clob.last_ws_msg_age = 1.0
    inventory = InventoryManager()
    inventory.bankroll = 100.0
    risk = RiskManager(inventory, clob)
    return MarketMaker(clob, inventory, risk)


def _feed_probes(mm, tid, n_adverse, n_total, fill_px=0.50):
    """Simulate n_total matured BUY probes, n_adverse of them adverse."""
    now = time.monotonic()
    # mid history: one sample 120s in the future of each probe's t0
    for i in range(n_total):
        t0 = now - 120.0  # matured
        adverse = i < n_adverse
        mid_later = fill_px - 0.01 if adverse else fill_px + 0.01
        mm._mid_history[tid] = deque([(t0 + 60.0, mid_later)])
        mm._adverse_probes = [(tid, fill_px, t0)]
        mm._process_adverse_probes()


def test_adverse_rate_4_of_10_bans_market(monkeypatch, tmp_path):
    mm = _mk_mm(monkeypatch, tmp_path)
    _feed_probes(mm, "tok-a", n_adverse=4, n_total=10)
    assert mm._is_market_banned("tok-a"), "40% adverse over 10 fills → ban"
    assert mm._adverse_ban_count == 1


def test_adverse_rate_2_of_10_no_ban(monkeypatch, tmp_path):
    mm = _mk_mm(monkeypatch, tmp_path)
    _feed_probes(mm, "tok-b", n_adverse=2, n_total=10)
    assert not mm._is_market_banned("tok-b"), "20% adverse → no ban"
    assert mm._adverse_ban_count == 0


def test_ban_expires_after_configured_time(monkeypatch, tmp_path):
    mm = _mk_mm(monkeypatch, tmp_path)
    _feed_probes(mm, "tok-c", n_adverse=5, n_total=10)
    assert mm._is_market_banned("tok-c")
    # rewind the ban expiry into the past
    mm._banned_markets["tok-c"] = time.monotonic() - 1.0
    assert not mm._is_market_banned("tok-c"), "expired ban must lift"
    assert "tok-c" not in mm._banned_markets
    assert "tok-c" not in mm._fill_outcomes, "outcome window resets after ban"


# ── v1.0.157: dead-market polling cleanup ────────────────────────────────


@pytest.mark.asyncio
async def test_inactive_market_stops_being_polled(monkeypatch):
    """A resolved market returns HTTP 400 'Market is not active'. After the
    first such answer the book must never be polled again (13,315 such rows
    in one session), until a refill re-discovers it as active."""
    from unittest.mock import AsyncMock
    from app.services.limitless_client import LimitlessService

    svc = LimitlessService()
    tid = "tok-dead"
    svc._slug_by_token[tid] = "dead-slug"
    svc._request = AsyncMock(
        return_value={"error": "http_400", "detail": {"message": "Market is not active"}}
    )

    await svc._fetch_book(tid)
    assert svc._request.await_count == 1
    assert tid in svc._dead_markets

    await svc._fetch_book(tid)  # second cycle: must not hit the API
    assert svc._request.await_count == 1, "dead market must not be polled again"


@pytest.mark.asyncio
async def test_rediscovery_clears_dead_flag(monkeypatch):
    """discover_markets() listing the market as active lifts the flag."""
    from app.services.limitless_client import LimitlessService

    svc = LimitlessService()
    payload = _market_payload("revived", bid=0.40, ask=0.46, vol_fmt=100000)
    yes = payload["tokens"]["yes"]
    svc._dead_markets.add(yes)

    from app.core.config import settings
    monkeypatch.setattr(settings, "auto_pick_count", 4)
    monkeypatch.setattr(settings, "auto_pick_min_spread_cents", 2.0)
    monkeypatch.setattr(settings, "auto_pick_preferred_spread_cents", 5.0)
    monkeypatch.setattr(settings, "auto_pick_min_volume_usd", 50000.0)
    monkeypatch.setattr(settings, "pre_resolution_exit_sec", 300)
    from unittest.mock import AsyncMock
    svc._request = AsyncMock(return_value={"data": [payload]})

    await svc.discover_markets()

    assert yes not in svc._dead_markets, "re-discovered market must be polled again"
