"""
tests/unit/test_v158_corridor_and_fixes.py — v1.0.158.

§1 Corridor exit model (replaces the linear decay ladder):
   ≥75% → fire immediately at any age; 55-75% → fire after the 3-min
   initial pause; <55% → hold; age ≥ 90 min → emergency valve; the
   0.3¢ commission-noise floor still rules; config cannot move any of it.
§2 PAPER maker ask-fill no longer suffers adverse drift (a resting maker
   order executes at its own price) → an ask parked on the breakeven floor
   can never realize a loss.
§3 A resolved-but-not-orphaned market (book frozen, still in clob.books)
   becomes a reconcile candidate once the book is stale past the threshold.
"""
from __future__ import annotations

import time
from unittest.mock import AsyncMock, MagicMock

import pytest

from app.services.profit_capture import (
    CORRIDOR_LOWER_PCT,
    CORRIDOR_UPPER_PCT,
    INITIAL_PAUSE_SEC,
    MIN_ABS_PROFIT_CENTS,
    VALVE_AGE_SEC,
    should_fire,
)


# ── §1 Corridor model ─────────────────────────────────────────────────────


def test_upper_threshold_fires_immediately_at_any_age():
    """80% of the achievable max on a 1-second-old position → take it now."""
    fire, why = should_fire(achievable_max_cents=10.0,
                            net_bid_profit_cents=8.0, age_sec=1.0)
    assert fire and why == "upper_threshold"


def test_corridor_waits_for_initial_pause_then_fires():
    """60% (inside the 55-75 corridor): held during the pause, fired after."""
    fire, why = should_fire(10.0, 6.0, age_sec=INITIAL_PAUSE_SEC - 1)
    assert not fire and why == "below_corridor", "ask-fill must get its head start"

    fire, why = should_fire(10.0, 6.0, age_sec=INITIAL_PAUSE_SEC + 1)
    assert fire and why == "corridor"


def test_below_corridor_never_fires_before_the_valve():
    """40% — the old ladder's 'dead zone' cheap shot. Never taken now."""
    for age in (60.0, 1800.0, VALVE_AGE_SEC - 1):
        fire, why = should_fire(10.0, 4.0, age_sec=age)
        assert not fire, f"40% of max must not fire at age {age}"
        assert why == "below_corridor"


def test_valve_takes_whatever_is_left_when_position_is_stale():
    """After 90 min the position must not hang forever — take any profit."""
    fire, why = should_fire(10.0, 1.0, age_sec=VALVE_AGE_SEC + 1)
    assert fire and why == "valve_age"


def test_min_abs_profit_floor_beats_everything_including_the_valve():
    """0.2¢ is commission noise: never fire, not even on the valve."""
    fire, why = should_fire(0.25, 0.2, age_sec=VALVE_AGE_SEC + 10_000)
    assert not fire and why == "below_min_abs_profit"


def test_no_achievable_max_only_valve_can_fire():
    """Market sank below entry: the breakeven floor holds the ask; only the
    valve may act (and only above the noise floor)."""
    fire, why = should_fire(-3.0, 0.5, age_sec=60.0)
    assert not fire and why == "no_achievable_max"

    fire, why = should_fire(-3.0, 0.5, age_sec=VALVE_AGE_SEC + 1)
    assert fire and why == "valve_age_no_max"


def test_no_shot_limit_per_window():
    """The model is stateless — every cycle, every position, independently.
    Same inputs → same answer, no 'already fired' bookkeeping."""
    for _ in range(5):
        assert should_fire(10.0, 8.0, 1.0)[0] is True


def test_corridor_constants_not_readable_from_config(monkeypatch):
    """Sabotage: no settings field may move the corridor (hardcode contract)."""
    from app.core.config import settings

    for name in dir(settings):
        low = name.lower()
        if any(k in low for k in ("profit", "sniper", "capture", "corridor",
                                  "pause", "valve", "decay")):
            try:
                monkeypatch.setattr(settings, name, 99999.0)
            except Exception:
                pass

    assert CORRIDOR_UPPER_PCT == 0.75
    assert CORRIDOR_LOWER_PCT == 0.55
    assert INITIAL_PAUSE_SEC == 180.0
    assert VALVE_AGE_SEC == 5400.0
    assert MIN_ABS_PROFIT_CENTS == 0.3
    assert should_fire(10.0, 8.0, 1.0)[0] is True        # upper
    assert should_fire(10.0, 4.0, 600.0)[0] is False     # below corridor
    assert should_fire(10.0, 6.0, 600.0)[0] is True      # corridor


# ── §2 Maker ask-fill: no adverse drift ──────────────────────────────────


@pytest.mark.asyncio
async def test_maker_ask_fill_on_floor_never_loses(monkeypatch):
    """An ask parked on the breakeven floor (entry + tick) must fill at its
    OWN price. Regression: PAPER drift (mid × 0.8-2.0%) dragged the fill
    below entry → −0.52/−0.67/−0.91¢ phantom losses on 2026-07-14."""
    import app.services.market_maker as mm_mod
    from app.core.config import settings
    from app.services.clob_client import MarketBook, OrderLevel
    from app.services.inventory_manager import InventoryManager, Inventory
    from app.services.market_maker import ActiveQuote, MarketMaker
    from app.services.risk.risk_manager import RiskManager

    monkeypatch.setattr(mm_mod, "RUNNING_LOCK_PATH", __import__("pathlib").Path(
        "/tmp/never-written.lock"))
    monkeypatch.setattr(settings, "paper_trading", True)
    monkeypatch.setattr(settings, "paper_rejection_rate", 0.0)
    monkeypatch.setattr(settings, "paper_competition_rate", 0.0)
    monkeypatch.setattr(settings, "paper_fill_prob_base", 1.0)
    monkeypatch.setattr(settings, "paper_fill_prob_max", 1.0)
    # maximal drift — under the old code this guaranteed a loss
    monkeypatch.setattr(settings, "paper_adverse_drift_min", 0.02)
    monkeypatch.setattr(settings, "paper_adverse_drift_max", 0.02)
    monkeypatch.setattr(settings, "inventory_liquidation_enabled", False)

    entry = 0.6300
    floor_ask = round(entry + 0.001, 4)  # 0.6310 — the breakeven floor
    tid = "tok-floor"

    clob = MagicMock()
    clob.books = {tid: MarketBook(
        token_id=tid,
        bids=[OrderLevel(0.6250, 500)],
        asks=[OrderLevel(0.6320, 500)],
        last_price=0.6285,
    )}
    clob.markets = {}
    clob.last_ws_msg_age = 1.0

    inventory = InventoryManager()
    inventory.bankroll = 100.0
    inv = Inventory(token_id=tid, market_name="ETH")
    inv.net_tokens = 20.0
    inv.avg_entry_price = entry
    inv.open_time = time.monotonic() - 600
    inventory.inventories[tid] = inv

    mm = MarketMaker(clob, inventory, RiskManager(inventory, clob))
    mm._running = True
    recorded: list[tuple] = []

    async def spy_fill(token_id, side, price, size_usdc, market_name, **kw):
        recorded.append((side, price, kw.get("exit_path")))

    mm._record_fill = spy_fill

    quote = ActiveQuote(
        token_id=tid, level=1, bid_price=None, ask_price=floor_ask,
        mid_at_place=0.6285, size_usdc=5.0, reservation_price=0.6285,
        spread_cents=0.7, ask_order_id=None,
    )
    mm.active_quotes[tid] = [quote]

    for _ in range(30):  # probabilistic fill model — give it many chances
        if recorded:
            break
        quote.ask_filled = False
        await mm._check_fills(tid, clob.books[tid], [quote], "ETH")

    assert recorded, "the ask on the floor should fill in PAPER"
    for side, price, _path in recorded:
        assert side == "SELL"
        assert price == pytest.approx(floor_ask), (
            f"maker ask must fill at its own price {floor_ask}, got {price} — "
            "adverse drift must NOT apply to resting maker orders"
        )
        assert price > entry, "a fill on the breakeven floor can never lose"


# ── §3 Resolved-but-not-orphaned market ──────────────────────────────────


@pytest.mark.asyncio
async def test_position_on_stale_book_becomes_reconcile_candidate(monkeypatch, tmp_path):
    """XMR case: market resolved, book frozen 2.4h, still in clob.books →
    neither orphan-cleanup nor pre-resolution could act. Now the stale book
    makes it a reconcile candidate."""
    import app.services.market_maker as mm_mod
    from app.core.config import settings
    from app.services.clob_client import MarketBook
    from app.services.inventory_manager import InventoryManager, Inventory
    from app.services.market_maker import MarketMaker
    from app.services.risk.risk_manager import RiskManager

    monkeypatch.setattr(mm_mod, "RUNNING_LOCK_PATH", tmp_path / "RUNNING.lock")
    monkeypatch.setattr(settings, "paper_trading", True)
    monkeypatch.setattr(settings, "orphaned_book_stale_sec", 600.0)
    monkeypatch.setattr(settings, "orphaned_reconcile_interval_sec", 600.0)

    tid = "tok-xmr"
    fresh_tid = "tok-live"

    stale_book = MarketBook(token_id=tid)
    stale_book.last_update = time.monotonic() - 8500  # frozen 2.4 h (XMR case)
    live_book = MarketBook(token_id=fresh_tid)
    live_book.last_update = time.monotonic() - 2      # healthy

    clob = MagicMock()
    # BOTH still in books → neither is a classic orphan
    clob.books = {tid: stale_book, fresh_tid: live_book}
    clob.markets = {}
    clob.last_ws_msg_age = 1.0
    checked: list[str] = []

    async def fake_status(token_id):
        checked.append(token_id)
        return None  # not resolved yet — we only assert it got CHECKED

    clob.fetch_market_status = AsyncMock(side_effect=fake_status)

    inventory = InventoryManager()
    inventory.bankroll = 60.0
    for t, name in ((tid, "XMR Up or Down - Daily"), (fresh_tid, "ETH")):
        inv = Inventory(token_id=t, market_name=name)
        inv.net_tokens = 0.0177
        inv.avg_entry_price = 0.6382
        inventory.inventories[t] = inv

    mm = MarketMaker(clob, inventory, RiskManager(inventory, clob))
    mm._running = True

    await mm._reconcile_orphaned_positions()

    assert tid in checked, (
        "a position on a long-dead book must be reconciled even though the "
        "market is still in clob.books (XMR hung between two handlers)"
    )
    assert fresh_tid not in checked, (
        "a market with a LIVE book must be left to the normal handlers"
    )
