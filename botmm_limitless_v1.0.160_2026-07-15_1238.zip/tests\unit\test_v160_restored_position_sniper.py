"""
tests/unit/test_v160_restored_position_sniper.py — v1.0.160.

BUG: a position restored from DB has open_time == 0 (aging resets on
restart). The old `if inv.open_time == 0: continue` in
_liquidate_aged_positions made it INVISIBLE to the whole liquidation loop —
including the profit sniper, which does not depend on age. Live case: DOGE
2026-07-15 06:33, bid at 61% of the achievable max (inside the corridor),
never evaluated because the position had survived a restart.

FIX: initialize open_time = now on first encounter and fall through — the
sniper/profit-take paths see it immediately, the age-gated tiers
(AGGRESSIVE/URGENT) simply start their countdown from zero.
"""
from __future__ import annotations

import time
from unittest.mock import AsyncMock, MagicMock

import pytest


def _make_mm(monkeypatch, tmp_path, *, entry, bid, ask, open_time):
    import app.services.market_maker as mm_mod
    from app.core.config import settings
    from app.services.clob_client import MarketBook, OrderLevel, MarketInfo
    from app.services.inventory_manager import InventoryManager, Inventory
    from app.services.market_maker import MarketMaker
    from app.services.risk.risk_manager import RiskManager

    monkeypatch.setattr(mm_mod, "RUNNING_LOCK_PATH", tmp_path / "RUNNING.lock")
    monkeypatch.setattr(settings, "paper_trading", True)
    monkeypatch.setattr(settings, "paper_rejection_rate", 0.0)
    monkeypatch.setattr(settings, "inventory_liquidation_enabled", True)
    # generous aging thresholds so an age-0 position is NOWHERE near them
    monkeypatch.setattr(settings, "inventory_liquidation_aggressive_age_sec", 1800.0)
    monkeypatch.setattr(settings, "inventory_liquidation_urgent_age_sec", 3600.0)
    monkeypatch.setattr(settings, "inventory_profit_take_min_age_sec", 0.0)

    tid = "tok-restored"
    clob = MagicMock()
    clob.books = {tid: MarketBook(
        token_id=tid,
        bids=[OrderLevel(bid, 500)],
        asks=[OrderLevel(ask, 500)],
        last_price=round((bid + ask) / 2, 4),
    )}
    clob.markets = {tid: MarketInfo(
        token_id=tid, condition_id="c", question="DOGE", outcome="Yes",
        end_date_ts=time.time() + 86400, volume_24h=70000.0,
    )}
    clob.last_ws_msg_age = 1.0
    clob._meta = {}

    inventory = InventoryManager()
    inventory.bankroll = 100.0
    inv = Inventory(token_id=tid, market_name="DOGE Up or Down - Daily")
    inv.net_tokens = 7.06
    inv.avg_entry_price = entry
    inv.open_time = open_time      # 0 == restored from DB
    inventory.inventories[tid] = inv

    mm = MarketMaker(clob, inventory, RiskManager(inventory, clob))
    mm._running = True
    mm._record_fill = AsyncMock()
    return mm, tid, inv


@pytest.mark.asyncio
async def test_restored_position_in_sniper_zone_fires_same_cycle(monkeypatch, tmp_path):
    """The DOGE case exactly: open_time==0, bid at 61% of the achievable max
    (inside the 55-75 corridor). The sniper MUST fire in this very cycle and
    open_time must be initialized."""
    # entry 0.3864, ask 0.536 → hardcode_ask 0.5345, achievable 14.81¢;
    # bid 0.477 → net 9.06¢ = 61% of max → corridor.
    mm, tid, inv = _make_mm(
        monkeypatch, tmp_path, entry=0.3864, bid=0.477, ask=0.536, open_time=0
    )

    await mm._liquidate_aged_positions()

    assert inv.open_time != 0, "open_time must be initialized on first check"
    assert mm._record_fill.called, (
        "a restored position inside the sniper corridor must fire immediately — "
        "open_time==0 must NOT hide it from the liquidation loop (the DOGE bug), "
        "and the corridor pause counts as already elapsed for a restored position"
    )
    assert mm._record_fill.call_args.args[1] == "SELL"
    assert mm._sniper_fired_count == 1


@pytest.mark.asyncio
async def test_restored_position_below_zone_initializes_but_holds(monkeypatch, tmp_path):
    """Restored position whose bid is BELOW the corridor: no shot, but
    open_time must still be set so later cycles age it correctly."""
    # bid 0.40 → net ~1.4¢ of a ~14¢ max ≈ 10% → below the 55% corridor
    mm, tid, inv = _make_mm(
        monkeypatch, tmp_path, entry=0.3864, bid=0.40, ask=0.536, open_time=0
    )

    await mm._liquidate_aged_positions()

    assert inv.open_time != 0, "open_time must be initialized even without a shot"
    assert not mm._record_fill.called, "bid below the corridor → no sniper shot"
    assert mm._sniper_fired_count == 0


@pytest.mark.asyncio
async def test_aging_tiers_do_not_fire_prematurely_on_fresh_age(monkeypatch, tmp_path):
    """Regression: a just-initialized (age≈0) position that is UNDER WATER
    (bid below entry, so the sniper cannot act) must NOT be liquidated by the
    AGGRESSIVE/URGENT tiers — those still require their real age. The no-loss
    floor holds and nothing is sold."""
    mm, tid, inv = _make_mm(
        monkeypatch, tmp_path, entry=0.50, bid=0.42, ask=0.46, open_time=0
    )

    await mm._liquidate_aged_positions()

    assert inv.open_time != 0, "open_time initialized"
    assert not mm._record_fill.called, (
        "an age-0 underwater position must not be force-liquidated — aging "
        "tiers keep their countdown, and loss exits stay forbidden"
    )
    assert mm._loss_forced_count == 0
