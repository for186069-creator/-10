"""
app/services/market_maker.py — Professional MM engine.

Combines:
  - Avellaneda-Stoikov reservation price (inventory-aware fair price)
  - Kyle's lambda spread multiplier (order-book imbalance aware)
  - Multi-level quoting (3 price levels)
  - Inventory skew + aging discount
  - Circuit breakers + adverse selection
  - Yes/No hedging (condition_id pairs)

Two modes:
  PAPER : realistic fill simulation (with adverse selection, competition, latency)
  LIVE  : real orders via py-clob-client with EIP-712 signing

Bot starts PAUSED. User must click "Start Trading" via /api/start.
"""
from __future__ import annotations

import asyncio
import json as _json
import os
import random
import time
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from app.core.config import settings
from app.core.logging import get_logger
from app.core.metrics import (
    ACTIVE_QUOTES,
    ADVERSE_TRIGGERS,
    BANKROLL_USD,
    CYCLE_LATENCY_SEC,
    CYCLES_TOTAL,
    DAILY_PNL_USD,
    FILLS_TOTAL,
    HALTED,
    INVENTORY_RATIO,
    INVENTORY_USD,
    KYLE_LAMBDA,
    RESERVATION_PRICE,
    ROUND_TRIPS_TOTAL,
    SPREAD_CENTS,
)
from app.db.models import MarketSnapshot, OrderMode, QuoteStatus, Side, Trade
from app.services.clob_client import ClobService, MarketBook, OrderResult
from app.services.inventory_manager import InventoryManager
from app.services.pricing.avellaneda_stoikov import AvellanedaStoikov
from app.services.pricing.kyle_lambda import KyleLambda
from app.services.pricing.spread_optimizer import SpreadOptimizer
from app.services.risk.risk_manager import RiskManager

log = get_logger(__name__)

# v1.0.154: dirty-shutdown marker. Created on MM start, removed on clean
# shutdown (after force-cancel). Present at startup ⇒ the previous run
# died unclean (power cut / kill) — run crash recovery before quoting.
RUNNING_LOCK_PATH = Path("data") / "RUNNING.lock"


@dataclass
class ActiveQuote:
    """Tracks one level of an actively-placed quote for a market."""

    token_id: str
    level: int  # 1, 2, or 3
    bid_price: float | None
    ask_price: float | None
    mid_at_place: float
    size_usdc: float
    reservation_price: float
    spread_cents: float
    placed_at: float = field(default_factory=time.monotonic)
    bid_filled: bool = False
    ask_filled: bool = False
    bid_order_id: str | None = None
    ask_order_id: str | None = None
    # v1.0.156: partial-fill fractions for the open-orders panel (0..1)
    bid_fill_pct: float = 0.0
    ask_fill_pct: float = 0.0


class MarketMaker:
    """Main MM engine. Runs a requote loop."""

    def __init__(
        self,
        clob: ClobService,
        inventory: InventoryManager,
        risk: RiskManager,
    ) -> None:
        self.clob = clob
        self.inventory = inventory
        self.risk = risk

        # active_quotes: token_id → list of ActiveQuote (one per level)
        self.active_quotes: dict[str, list[ActiveQuote]] = {}
        self._task: asyncio.Task | None = None
        self._cleanup_task: asyncio.Task | None = None
        self._poll_task: asyncio.Task | None = None
        self._liquidation_task: asyncio.Task | None = None  # v1.0.38
        self._persistence_task: asyncio.Task | None = None  # v1.0.72
        self._snapshot_task: asyncio.Task | None = None  # v1.0.88 (mm_snapshots logging)
        self._bankroll_sync_task: asyncio.Task | None = None  # v1.0.122 (Claude audit p.1)
        self._running = False
        self._cycle_count = 0
        self._fill_count = 0  # Loaded from DB on start()
        self._round_trip_count = 0
        self._liquidation_count = 0  # v1.0.38: tracks forced liquidations
        # v1.0.150: new headline exit metrics — profit-sniper fills and
        # forced loss liquidations (target: 0 outside pre-resolution).
        self._profit_take_count = 0
        self._loss_forced_count = 0
        # v1.0.150: markets currently under the drawdown stop (BUY blocked).
        # Tracked only to log state TRANSITIONS at INFO (per-cycle repeats
        # would spam the log like ask_lifted did).
        self._drawdown_stopped: set[str] = set()
        # v1.0.151: momentum filter — ring buffers of (monotonic_ts, mid)
        # per market (~10 min depth) and the sides currently blocked.
        self._mid_history: dict[str, deque] = {}
        self._momentum_bid_blocked: set[str] = set()
        self._momentum_ask_blocked: set[str] = set()
        # v1.0.151: NO-hedge — executed hedges + per-token check throttle.
        self._no_hedge_count = 0
        self._hedged_positions: set[str] = set()
        self._no_hedge_last_check: dict[str, float] = {}
        # v1.0.153: capture quality — running mean of taken_pct across
        # sniper exits + maker/taker exit split (Path A share).
        self._sniper_taken_pct_sum = 0.0
        self._sniper_fired_count = 0
        self._exit_maker_count = 0
        self._exit_taker_count = 0
        # v1.0.154: crash protection
        self._crash_recovery_active = False
        self._order_watchdog_task: asyncio.Task | None = None
        # v1.0.155 (GLM §7): adverse-rate market rotation. After each BUY
        # fill we probe the mid 60s later (reusing the v151 _mid_history
        # buffer); a market whose recent fills keep going adverse gets
        # banned from rotation for adverse_market_ban_sec.
        self._adverse_probes: list[tuple[str, float, float]] = []  # (token, fill_px, t)
        self._fill_outcomes: dict[str, deque] = {}  # token -> deque[bool], maxlen 20
        self._banned_markets: dict[str, float] = {}  # token -> ban_until (monotonic)
        self._adverse_ban_count = 0
        # v1.0.120 (Claude audit Task 2b): capital starvation counter.
        # Incremented when bid_blocked_insufficient_balance fires.
        # Reset every 60s. If > threshold → capital is starved →
        # opportunity cost of holding losing positions is high.
        self._capital_starved_count: int = 0
        self._capital_starved_reset_at: float = time.monotonic()
        # v1.0.59 (BUG-N9): monotonic-clock timestamp of last auto-refill.
        # Replaces the old `cycle_count % 30 == 0` throttle (≈30s) which
        # churned markets every 30s. Now throttled by auto_refill_cooldown_sec
        # (default 300s = 5 min). Initialized to -inf so the first refill can
        # happen immediately on startup (gives the bot a chance to populate
        # markets before the cooldown kicks in).
        self._last_auto_refill_mono: float = -float("inf")

        # Bot starts PAUSED. User clicks "Start Trading" to begin.
        self._trading_paused = True

        # Pricing models
        self._as_calc = AvellanedaStoikov()
        self._kyle = KyleLambda()

        # Yes/No hedging pairs: condition_id → {"yes": token_id, "no": token_id}
        self._condition_pairs: dict[str, dict[str, str]] = {}

        # Live mode: pending orders awaiting fill confirmation
        self._pending_orders: dict[str, dict[str, Any]] = {}

        # Stats
        self._hedge_attempts = 0
        self._hedge_fills = 0

    # ── Lifecycle ─────────────────────────────────────────────────────────

    # ── v1.0.154: crash protection ────────────────────────────────────────

    async def _crash_recovery_check(self) -> None:
        """Dirty-shutdown detection. If RUNNING.lock survived from the
        previous run: cancel EVERYTHING on the exchange before any quoting,
        reconcile DB positions vs wallet, and raise the recovery badge.
        Then (re)write the lock for this run."""
        if RUNNING_LOCK_PATH.exists():
            age_sec = None
            prev_pid = None
            try:
                info = _json.loads(RUNNING_LOCK_PATH.read_text(encoding="utf-8"))
                prev_pid = info.get("pid")
                if info.get("ts"):
                    age_sec = round(time.time() - float(info["ts"]), 0)
            except Exception:
                pass
            log.warning(
                "unclean_shutdown_detected",
                marker_age_sec=age_sec,
                previous_pid=prev_pid,
                reason="RUNNING.lock survived — previous run died without clean shutdown",
            )
            self._crash_recovery_active = True
            if settings.paper_trading:
                log.info(
                    "crash_recovery_cancel_all_skipped",
                    reason="PAPER: no live orders exist on the exchange",
                )
            else:
                try:
                    cancelled = await self.clob.cancel_all()
                    log.warning(
                        "crash_recovery_cancel_all_done", cancelled=cancelled
                    )
                except Exception as e:
                    log.error("crash_recovery_cancel_all_failed", error=str(e))
                await self._check_position_drift_after_crash()
        # (re)write the marker for THIS run
        try:
            RUNNING_LOCK_PATH.parent.mkdir(parents=True, exist_ok=True)
            RUNNING_LOCK_PATH.write_text(
                _json.dumps({"pid": os.getpid(), "ts": time.time()}),
                encoding="utf-8",
            )
        except OSError as e:
            log.warning("running_lock_write_failed", error=str(e))

    async def _check_position_drift_after_crash(self) -> None:
        """LIVE: compare DB-restored inventory vs actual wallet balances."""
        get_positions = getattr(self.clob, "get_positions", None)
        if get_positions is None:
            log.debug("position_drift_check_unavailable")
            return
        try:
            positions = await get_positions()
        except Exception as e:
            log.warning("position_drift_check_failed", error=str(e))
            return
        wallet = {
            str(p.get("token_id", "")): float(p.get("tokens", 0.0))
            for p in (positions or [])
        }
        for tid, inv in self.inventory.inventories.items():
            if abs(inv.net_tokens) < 0.5:
                continue
            actual = wallet.pop(tid, 0.0)
            if abs(actual - inv.net_tokens) > 0.5:
                log.warning(
                    "position_drift_after_crash",
                    token=tid[:12],
                    db_tokens=round(inv.net_tokens, 4),
                    wallet_tokens=round(actual, 4),
                    delta=round(actual - inv.net_tokens, 4),
                )
        for tid, tokens in wallet.items():
            if abs(tokens) > 0.5:
                log.warning(
                    "position_drift_after_crash",
                    token=tid[:12],
                    db_tokens=0.0,
                    wallet_tokens=round(tokens, 4),
                    delta=round(tokens, 4),
                    reason="wallet position unknown to DB",
                )

    async def _live_order_watchdog_loop(self) -> None:
        """v1.0.154 LIVE: Limitless has no GTD/TTL (expiration must be "0"),
        so a dead bot leaves naked orders until power returns. This loop
        bounds the exposure window: no order may outlive
        live_requote_max_order_age_sec — it is force-cancelled (and the
        normal cycle re-places it within seconds), and exchange-side stray
        orders unknown to us are cancelled outright."""
        interval = max(10.0, settings.live_requote_max_order_age_sec / 4.0)
        while self._running:
            try:
                await self._sweep_old_live_orders()
            except asyncio.CancelledError:
                raise
            except Exception as e:
                log.warning("order_watchdog_error", error=str(e))
            await asyncio.sleep(interval)

    async def _sweep_old_live_orders(self) -> None:
        if settings.paper_trading:
            return
        max_age = settings.live_requote_max_order_age_sec
        now = time.monotonic()
        for tid, quotes in list(self.active_quotes.items()):
            keep: list[ActiveQuote] = []
            for q in quotes:
                age = now - q.placed_at
                if age > max_age:
                    log.info(
                        "watchdog_requote_old_order",
                        market=tid[:12],
                        level=q.level,
                        age_sec=round(age, 0),
                        max_age_sec=max_age,
                        reason="order outlived max age — cancel; cycle re-places",
                    )
                    await self._cancel_quote_level(tid, q)
                else:
                    keep.append(q)
            if keep:
                self.active_quotes[tid] = keep
            else:
                self.active_quotes.pop(tid, None)
        # Exchange-side sweep: cancel strays we don't track (post-crash
        # leftovers, failed cancels).
        try:
            open_orders = await self.clob.get_open_orders()
        except Exception:
            return
        known: set[str] = set(self._pending_orders.keys())
        for quotes in self.active_quotes.values():
            for q in quotes:
                if q.bid_order_id:
                    known.add(q.bid_order_id)
                if q.ask_order_id:
                    known.add(q.ask_order_id)
        for o in open_orders or []:
            oid = str(o.get("id") or o.get("orderId") or o.get("order_id") or "")
            if oid and oid not in known:
                log.warning(
                    "watchdog_cancel_stray_order",
                    order_id=oid[:16],
                    reason="live order unknown to the bot — cancelling",
                )
                try:
                    await self.clob.cancel_order(oid)
                except Exception as e:
                    log.warning("watchdog_stray_cancel_failed", order_id=oid[:16], error=str(e))

    async def start(self) -> None:
        self._running = True

        # v1.0.154: dirty-shutdown check + this run's marker. MUST run
        # before any quoting task exists: on a dirty restart the exchange
        # is swept clean (cancel-all) before a single new order goes out.
        await self._crash_recovery_check()

        # v1.0.52 FIX: explicitly enforce paused state at startup.
        # Previously _trading_paused was only set in __init__, which could
        # be reset by accident. Now start() forces it based on settings.
        # Default: PAUSED — user must click "Start Trading".
        self._trading_paused = not settings.auto_start_trading
        if self._trading_paused:
            log.warning(
                "bot_started_PAUSED",
                message="Bot is PAUSED. Click 'Start Trading' in the dashboard to begin quoting.",
                auto_start_trading=settings.auto_start_trading,
            )
        else:
            log.warning(
                "bot_started_TRADING",
                message="Bot auto-started (AUTO_START_TRADING=true). Quotes will be placed immediately.",
                auto_start_trading=settings.auto_start_trading,
            )

        # Load fill_count from DB (survives bot restarts)
        try:
            from app.core.db import AsyncSessionLocal
            from sqlalchemy import select, func
            from app.db.models import Trade
            async with AsyncSessionLocal() as db:
                result = await db.execute(select(func.count(Trade.id)))
                self._fill_count = result.scalar() or 0
                log.info("fill_count_loaded_from_db", fill_count=self._fill_count)
        except Exception as e:
            log.debug("fill_count_load_failed", error=str(e))

        # v1.0.72 (BUG-N23): Load inventory state from DB (crash recovery)
        try:
            from app.core.db import AsyncSessionLocal
            async with AsyncSessionLocal() as db:
                restored = await self.inventory.load_state_from_db(db)
                if restored:
                    log.info(
                        "inventory_state_loaded_on_startup",
                        bankroll=round(self.inventory.bankroll, 2),
                        positions=len(self.inventory.inventories),
                    )
        except Exception as e:
            log.warning("inventory_state_load_failed", error=str(e))

        self._task = asyncio.create_task(self._requote_loop(), name="mm_loop")
        self._cleanup_task = asyncio.create_task(self._db_cleanup_loop(), name="db_cleanup")
        if not settings.paper_trading:
            self._poll_task = asyncio.create_task(self._poll_orders_loop(), name="mm_poll")
        # v1.0.38: active inventory liquidation — aggressively clears stuck positions
        if settings.inventory_liquidation_enabled:
            self._liquidation_task = asyncio.create_task(
                self._liquidation_loop(), name="mm_liquidation"
            )
        # v1.0.72 (BUG-N23): State persistence — save every 60s for crash recovery
        self._persistence_task = asyncio.create_task(
            self._state_persistence_loop(), name="mm_persistence"
        )
        # v1.0.88: mm_snapshots logging — populates the price-history table
        # required for backtesting hold-N-minutes / take-profit thresholds.
        # Before this the table was defined but never written.
        self._snapshot_task = asyncio.create_task(
            self._snapshot_loop(), name="mm_snapshot"
        )
        # v1.0.122 (Claude audit p.1): periodic bankroll sync in LIVE mode.
        # PAPER: no-op. LIVE: every 300s, sync bankroll with real wallet + drift check.
        if not settings.paper_trading:
            self._bankroll_sync_task = asyncio.create_task(
                self._bankroll_sync_loop(), name="bankroll_sync"
            )
            # v1.0.154: order-age watchdog — bounds the naked-order window
            # if the process dies suddenly (no GTD/TTL on Limitless).
            self._order_watchdog_task = asyncio.create_task(
                self._live_order_watchdog_loop(), name="order_watchdog"
            )
        # v1.0.144: Orphaned position reconciliation (Claude Section 1).
        # Every orphaned_reconcile_interval_sec, check if orphaned positions resolved.
        # Critical: without this, orphaned positions never settle (resolution monitor
        # only ran for tokens in self.clob.books).
        self._reconcile_task = asyncio.create_task(
            self._reconcile_loop(), name="orphaned_reconcile"
        )
        log.info(
            "market_maker_started",
            mode="LIVE" if not settings.paper_trading else "PAPER",
            interval=settings.requote_interval_sec,
            fill_count=self._fill_count,
            liquidation_enabled=settings.inventory_liquidation_enabled,
            trading_paused=self._trading_paused,
        )

    async def stop(self) -> None:
        """Stop the market maker and all background tasks.

        v1.0.49 FIX (BUG-21): previously `except (CancelledError, Exception):
        pass` silently swallowed ALL exceptions from background tasks. If a
        task crashed with a real error (DB failure, network issue), it was
        never logged — making debugging impossible. Now we separate
        CancelledError (expected during shutdown) from other exceptions
        (logged as warnings).
        """
        log.info("market_maker_stopping")
        self._running = False
        # v1.0.72 (BUG-N23): Save state before shutdown
        try:
            from app.core.db import AsyncSessionLocal
            async with AsyncSessionLocal() as db:
                await self.inventory.save_state_to_db(db)
                log.info("inventory_state_saved_on_shutdown")
        except Exception as e:
            log.warning("inventory_state_save_failed_on_shutdown", error=str(e))
        # Cancel all active quotes
        # v1.0.146 (Claude): force=True — on shutdown partially-filled
        # quotes must NOT stay live on the exchange while the bot is
        # offline (unmonitored real-money orders). The already-filled
        # part stays as inventory either way; cancelling the unfilled
        # remainder does not create additional dust.
        for tid in list(self.active_quotes.keys()):
            await self._cancel_all_levels(tid, force=True)
        # v1.0.154: force-cancel succeeded → this is a CLEAN shutdown.
        # Remove the dirty-shutdown marker.
        try:
            if RUNNING_LOCK_PATH.exists():
                RUNNING_LOCK_PATH.unlink()
                log.info("running_lock_removed", reason="clean shutdown")
        except OSError as e:
            log.warning("running_lock_remove_failed", error=str(e))
        task_names = {
            self._task: "requote_loop",
            self._cleanup_task: "db_cleanup",
            self._poll_task: "poll_orders",
            self._liquidation_task: "liquidation",
            self._persistence_task: "persistence",
            self._snapshot_task: "snapshot",
            self._bankroll_sync_task: "bankroll_sync",
            getattr(self, "_reconcile_task", None): "orphaned_reconcile",
            self._order_watchdog_task: "order_watchdog",
        }
        for task in (self._task, self._cleanup_task, self._poll_task, self._liquidation_task, self._persistence_task, self._snapshot_task, self._bankroll_sync_task, getattr(self, "_reconcile_task", None), self._order_watchdog_task):
            if task:
                task_name = task_names.get(task, "unknown")
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass  # expected during shutdown
                except Exception as e:
                    # v1.0.49 (BUG-21): log unexpected exceptions instead of
                    # silently swallowing them. Helps diagnose crashes.
                    log.warning(
                        "task_stopped_with_error",
                        task=task_name,
                        error=str(e),
                        error_type=type(e).__name__,
                    )
        log.info("market_maker_stopped")

    # ── User control ──────────────────────────────────────────────────────

    def start_trading(self) -> None:
        """User clicked 'Start Trading'."""
        self._trading_paused = False
        if self.inventory.halted and "USER_PAUSE" in (self.inventory.halt_reason or ""):
            self.inventory.resume()
        log.info("trading_started_by_user")

    def stop_trading(self) -> None:
        """User clicked 'Pause' — cancel all quotes immediately."""
        self._trading_paused = True
        # v1.0.146 (Claude): force=True — user pressed Pause, they want
        # ALL orders off the book, including partially-filled ones.
        for tid in list(self.active_quotes.keys()):
            asyncio.create_task(self._cancel_all_levels(tid, force=True))
        log.info("trading_paused_by_user")

    async def start_live_polling(self) -> None:
        """v1.0.39: start the LIVE fill-polling task at runtime.

        Previously _poll_orders_loop was only created in start() when the bot
        booted directly into LIVE mode. If the bot started in PAPER and the
        user toggled to LIVE via /api/mode/toggle, _poll_task was never
        created, so fills were never detected even after PATCH-1.
        This method is idempotent — safe to call multiple times.
        """
        if settings.paper_trading:
            log.warning("start_live_polling_called_in_paper_mode")
            return
        if self._poll_task is not None and not self._poll_task.done():
            return  # already running
        self._poll_task = asyncio.create_task(
            self._poll_orders_loop(), name="mm_poll"
        )
        log.info("live_polling_started_at_runtime")

    @property
    def is_trading(self) -> bool:
        return not self._trading_paused and not self.inventory.halted

    # ── Main loop ─────────────────────────────────────────────────────────

    async def _requote_loop(self) -> None:
        # v1.0.52: track paused cycles to log "waiting" periodically
        _paused_cycle = 0
        while self._running:
            try:
                t0 = time.monotonic()
                if self._trading_paused:
                    # v1.0.52: log every 30 cycles (~30s) so user can see
                    # the bot is alive but waiting for "Start Trading"
                    _paused_cycle += 1
                    if _paused_cycle % 30 == 1:
                        log.info(
                            "waiting_for_start_trading",
                            paused_cycles=_paused_cycle,
                            message="Bot is PAUSED. Click 'Start Trading' to begin.",
                        )
                    await asyncio.sleep(settings.requote_interval_sec)
                    continue
                _paused_cycle = 0  # reset when not paused
                if self.inventory.halted:
                    # Check if halt was due to stale data — auto-resume when WS recovers
                    if "STALE_DATA" in (self.inventory.halt_reason or ""):
                        if self.clob.last_ws_msg_age < 10:
                            # v1.0.50 (BUG-26): pass source="AUTO" so the halt
                            # event is logged correctly (not as "MANUAL").
                            self.inventory.resume(preserve_counters=True, source="AUTO")
                            log.info("ws_recovered_resuming")
                            continue
                    # Cancel all quotes while halted
                    for tid in list(self.active_quotes.keys()):
                        await self._cancel_all_levels(tid)
                    await asyncio.sleep(settings.requote_interval_sec)
                    continue
                await self._cycle()
                CYCLE_LATENCY_SEC.observe(time.monotonic() - t0)
            except asyncio.CancelledError:
                break
            except Exception as e:
                log.exception("mm_cycle_error", error=str(e))
            await asyncio.sleep(settings.requote_interval_sec)

    async def _cycle(self) -> None:
        self._cycle_count += 1
        CYCLES_TOTAL.inc()

        # ── Global halt check ──
        should_halt, reason = self.risk.should_halt()
        if should_halt:
            self.inventory.halt(
                reason=reason.split(":")[0],
                detail=reason.split(":", 1)[1] if ":" in reason else "",
            )
            for tid in list(self.active_quotes.keys()):
                await self._cancel_all_levels(tid)
            HALTED.set(1)
            return

        # Auto-refill markets if too few
        await self._maybe_auto_refill()

        # ── Build hedging pairs every 30 cycles ──
        if self._cycle_count % 30 == 1 and settings.hedging_enabled:
            self._build_hedging_pairs()

        # ── Process each market ──
        for tid, book in list(self.clob.books.items()):
            await self._process_market(tid, book)

        # ── Update metrics ──
        BANKROLL_USD.set(self.inventory.bankroll)
        DAILY_PNL_USD.set(self.inventory.daily_pnl)
        total_inv = sum(inv.net_usdc_at_entry for inv in self.inventory.inventories.values())
        INVENTORY_USD.set(total_inv)
        ACTIVE_QUOTES.set(sum(len(qs) for qs in self.active_quotes.values()))
        HALTED.set(1 if self.inventory.halted else 0)

    async def _maybe_auto_refill(self) -> None:
        """If quotable markets dropped below USER'S target, discover new ones.

        v1.0.42: hard cap = target × 2 (prevented infinite refill, but still
                 allowed 2 markets when user wanted 1).
        v1.0.46 FIX (BUG-1): hard cap = target. If user wants 1 market, the
                 bot keeps at most 1. This means if the single market becomes
                 non-quotable (spread < min), the bot now actively REPLACES it
                 rather than keeping it + adding a buffer.
        v1.0.46 FIX (BUG-7): auto_pick_count is now restored via try/finally
                 even when discover_markets() raises.
        v1.0.59 FIX (BUG-N9): replaced `cycle_count % 30` throttle (≈30s)
                 with monotonic-clock cooldown (settings.auto_refill_cooldown_sec,
                 default 300s = 5 min). Prevents churning when ALL Polymarket
                 markets have tight spreads — old behavior burned 19 refill
                 cycles in 17 min getting back the same non-quotable markets.
        """
        # Count QUOTABLE markets (spread >= min, both sides present)
        quotable = sum(
            1 for book in self.clob.books.values()
            if book.bids and book.asks and book.spread * 100 >= settings.spread_min_cents
        )
        current = len(self.clob.books)
        # Dynamic target: adjust based on current bankroll
        if settings.auto_pick_dynamic:
            target = max(1, int(self.inventory.bankroll / 10))
        else:
            target = settings.auto_pick_count

        # Refill only if quotable < target
        if quotable >= target:
            return

        # v1.0.59 (BUG-N9): time-based throttle replaces cycle_count % 30.
        # First call after startup is allowed immediately (_last_auto_refill_mono
        # initialized to -inf in __init__). Subsequent calls are throttled by
        # auto_refill_cooldown_sec. This gives markets time to naturally widen
        # their spreads before we churn them.
        now_mono = time.monotonic()
        elapsed = now_mono - self._last_auto_refill_mono
        if elapsed < settings.auto_refill_cooldown_sec:
            return

        # v1.0.46 (BUG-1): HARD CAP = target (was target × 2).
        # If user set target=1, allow max 1 market. If the single market
        # becomes non-quotable, we REPLACE it (see replace logic below)
        # rather than keeping it and adding a buffer.
        if current >= target:
            # At cap and still not enough quotable markets → try to replace
            # the worst non-quotable market with a fresh one.
            self._last_auto_refill_mono = now_mono
            log.info(
                "auto_refill_throttle_passed",
                elapsed_sec=round(elapsed, 1) if elapsed != float("inf") else 0,
                cooldown_sec=settings.auto_refill_cooldown_sec,
                path="replace",
                quotable=quotable,
                target=target,
            )
            await self._replace_non_quotable_markets(target)
            return

        self._last_auto_refill_mono = now_mono
        log.info(
            "auto_refill_throttle_passed",
            elapsed_sec=round(elapsed, 1) if elapsed != float("inf") else 0,
            cooldown_sec=settings.auto_refill_cooldown_sec,
            path="add",
            quotable=quotable,
            target=target,
        )

        log.info(
            "auto_refill_started",
            total_markets=current,
            quotable_markets=quotable,
            target=target,
            hard_cap=target,
            bankroll=round(self.inventory.bankroll, 2),
            dynamic=settings.auto_pick_dynamic,
            reason=f"fewer than {target} quotable markets (bankroll-based)",
        )
        # v1.0.46 FIX (BUG-7): try/finally restores auto_pick_count even on
        # exception. Previously discover_markets() raising would leave the
        # setting permanently mutated.
        old_count = settings.auto_pick_count
        settings.auto_pick_count = max(1, target - quotable)
        try:
            new_markets = await self.clob.discover_markets()
        finally:
            settings.auto_pick_count = old_count
        added = 0
        for info in new_markets:
            # v1.0.155: never re-pick a market under an adverse-rate ban
            if self._is_market_banned(info.token_id):
                continue
            if info.token_id not in self.clob.books:
                self.clob.books[info.token_id] = MarketBook(token_id=info.token_id)
                self.clob.markets[info.token_id] = info
                await self.clob._feed.subscribe(info.token_id)
                added += 1
        if added > 0:
            await self.clob._refresh_all_books()
            log.info("auto_refill_done", added=added, quotable_before=quotable)

    async def _replace_non_quotable_markets(self, target: int) -> None:
        """v1.0.46 (BUG-1): replace non-quotable markets when at hard cap.

        When current >= target but quotable < target, we can't add more
        markets (hard cap reached). Instead we identify the WORST
        non-quotable market (widest spread or empty book), drop it, and
        discover a fresh replacement. This prevents the bot from being
        stuck indefinitely on a dead market.
        """
        # Find non-quotable markets (spread < min or missing side)
        non_quotable: list[tuple[str, float]] = []  # (token_id, spread_cents)
        for tid, book in self.clob.books.items():
            if not book.bids or not book.asks:
                # Empty book — worst kind, prioritize for replacement
                non_quotable.append((tid, 0.0))
            elif book.spread * 100 < settings.spread_min_cents:
                non_quotable.append((tid, book.spread * 100))

        if not non_quotable:
            return  # all markets are quotable, nothing to replace

        # Sort: empty books (spread=0) first, then by tightest spread
        non_quotable.sort(key=lambda x: x[1])

        # Replace at most (target - quotable) markets
        quotable = sum(
            1 for book in self.clob.books.values()
            if book.bids and book.asks and book.spread * 100 >= settings.spread_min_cents
        )
        to_replace = min(target - quotable, len(non_quotable))
        if to_replace <= 0:
            return

        log.info(
            "auto_refill_replace_started",
            non_quotable_count=len(non_quotable),
            to_replace=to_replace,
            target=target,
        )

        # Don't replace markets that have open inventory (would orphan it).
        # We only replace flat markets (no net position).
        replaced = 0
        for tid, _spread in non_quotable:
            if replaced >= to_replace:
                break
            inv = self.inventory.get_inventory(tid)
            # v1.0.144: dollar-based dust threshold (Claude Section 2).
            # Old: `if abs(inv.net_tokens) > 0.5` — token count, inconsistent across prices.
            # New: position value in USD. Dust (< $5) can be dropped; real positions kept.
            position_value = abs(inv.net_tokens * inv.avg_entry_price) if inv.avg_entry_price > 0 else 0
            if settings.auto_refill_keep_partial:
                # Only skip markets with SIGNIFICANT positions (>= dust_threshold)
                if position_value >= settings.dust_threshold_usdc:
                    continue  # significant position, keep market
                # Dust — can drop market from quoting.
                # Inventory record stays for resolution reconciliation (v1.0.144).
                if position_value > 0:
                    log.info(
                        "auto_refill_dropping_dust_market",
                        token=tid[:12],
                        position_value=round(position_value, 2),
                        dust_threshold=settings.dust_threshold_usdc,
                        reason="dust position (< $5) — will resolve via reconciliation loop",
                    )
            else:
                # Old behavior: any position blocks refill
                if abs(inv.net_tokens) > 0.5:
                    continue

            # Cancel any quotes on this market
            # v1.0.146 (Claude): force=True — this market is being dropped
            # and WS is unsubscribed right below. A partially-filled quote
            # left live here would be an unmonitored order on a market the
            # bot no longer watches. The dust inventory record stays for
            # the reconciliation loop regardless.
            if tid in self.active_quotes:
                await self._cancel_all_levels(tid, force=True)
            # Unsubscribe WS
            try:
                await self.clob._feed.unsubscribe(tid)
            except Exception:
                pass
            # Remove from books + markets
            self.clob.books.pop(tid, None)
            self.clob.markets.pop(tid, None)
            self.inventory.inventories.pop(tid, None)
            self._as_calc.clear(tid)
            self._kyle.clear(tid)
            self.risk.adverse_selection.clear(tid)
            self.risk.circuit_breakers.clear_token(tid)
            replaced += 1
            log.info("auto_refill_dropped_market", token=tid[:12])

        if replaced == 0:
            return

        # Discover replacements
        old_count = settings.auto_pick_count
        settings.auto_pick_count = replaced
        try:
            new_markets = await self.clob.discover_markets()
        except Exception as e:
            log.debug("auto_refill_replace_discover_error", error=str(e))
            new_markets = []
        finally:
            settings.auto_pick_count = old_count

        added = 0
        for info in new_markets:
            # v1.0.155: never re-pick a market under an adverse-rate ban
            if self._is_market_banned(info.token_id):
                continue
            if info.token_id not in self.clob.books:
                self.clob.books[info.token_id] = MarketBook(token_id=info.token_id)
                self.clob.markets[info.token_id] = info
                await self.clob._feed.subscribe(info.token_id)
                added += 1
        if added > 0:
            await self.clob._refresh_all_books()
            log.info(
                "auto_refill_replace_done",
                replaced=replaced,
                added=added,
                total=len(self.clob.books),
            )

    # ── Per-market processing ─────────────────────────────────────────────

    async def _process_market(self, token_id: str, book: MarketBook) -> None:
        """Update quotes for one market."""
        info = self.clob.markets.get(token_id)
        market_name = info.question[:60] if info else token_id[:12]
        if not book.bids or not book.asks:
            log.info("market_skip_empty_book", token=token_id[:12], market=market_name[:30])
            return

        # v1.0.151: feed the momentum ring buffer every cycle, even for
        # markets that end up skipped below — history must keep flowing.
        self._push_mid(token_id, book.mid)

        # v1.0.155: mature adverse probes; skip banned markets entirely
        # (auto-refill sees them as non-quotable and rotates them out).
        self._process_adverse_probes()
        if self._is_market_banned(token_id):
            if token_id in self.active_quotes:
                await self._cancel_all_levels(token_id)
            return

        # ── Market spread (visible in logs) ──
        market_bid = book.best_bid
        market_ask = book.best_ask
        market_spread_cents = round(book.spread * 100, 2)

        # ── TTR (Time To Resolution) — hours until market ends ──
        ttr_hours = None
        if info and info.end_date_ts > 0:
            now_ts = datetime.now(timezone.utc).timestamp()
            ttr = info.end_date_ts - now_ts
            ttr_hours = round(ttr / 3600, 1)

            # ── Pre-resolution exit ──
            if ttr < settings.pre_resolution_exit_sec:
                log.info(
                    "market_skip_pre_resolution",
                    market=market_name[:40],
                    ttr_hours=ttr_hours,
                    market_spread_cents=market_spread_cents,
                )
                await self._handle_pre_resolution(token_id, book, market_name)
                return

        # ── Market quality filter: skip if spread < spread_min_cents ──
        if market_spread_cents < settings.spread_min_cents:
            log.info(
                "market_skip_tight_spread",
                market=market_name[:40],
                market_spread_cents=market_spread_cents,
                min_required=settings.spread_min_cents,
            )
            if token_id in self.active_quotes:
                await self._cancel_all_levels(token_id)
            return

        # v1.0.71 (BUG-N22): Resolution detector — ринок майже resolved.
        # Якщо mid < 0.05 або mid > 0.95 → ціна майже 0 або 1 → resolution imminent.
        # Продати інвентар негайно (mid-based), поки є ліквідність.
        # Захищає від Australia-сценарію: ціна впала -94%, бот тримав позицію.
        if book.mid < 0.05 or book.mid > 0.95:
            inv_check = self.inventory.get_inventory(token_id)
            if abs(inv_check.net_tokens) > 0.5 and inv_check.net_tokens > 0:
                log.warning(
                    "resolution_detector_triggered",
                    market=market_name[:40],
                    mid=round(book.mid, 4),
                    net_tokens=round(inv_check.net_tokens, 2),
                    avg_entry=round(inv_check.avg_entry_price, 4),
                    reason="mid < 5¢ or > 95¢ — market near resolution, exit now",
                )
                await self._handle_resolution_exit(token_id, book, market_name)
                return
            # No inventory — just skip quoting on near-resolved market
            log.info(
                "market_skip_near_resolution",
                market=market_name[:40],
                mid=round(book.mid, 4),
                reason="mid < 5¢ or > 95¢ — near resolution, no inventory to exit",
            )
            if token_id in self.active_quotes:
                await self._cancel_all_levels(token_id)
            return

        # CRITICAL: Skip very low-priced markets (< 5¢) — token count explodes
        # At $0.004, $5 order = 1250 tokens, tiny price move = huge fake P&L
        if book.mid < 0.05:
            log.info(
                "market_skip_low_price",
                market=market_name[:40],
                mid=round(book.mid, 4),
                reason="price < 5¢ causes token explosion and fake P&L",
            )
            if token_id in self.active_quotes:
                await self._cancel_all_levels(token_id)
            return

        # ── Update A-S pricing ──
        self._as_calc.update(token_id, book.mid)
        self.risk.on_cycle(token_id, book.mid)

        # v1.0.123: portfolio exposure warning (>80% of cap)
        if self._cycle_count % 30 == 0:  # log every ~30s, not every cycle
            exposure_pct = self.inventory.portfolio_exposure_pct()
            cap_pct = settings.max_total_exposure_pct_of_bankroll * 100
            if exposure_pct > cap_pct * 0.8:
                log.warning(
                    "portfolio_exposure_near_cap",
                    exposure_pct=round(exposure_pct, 1),
                    cap_pct=round(cap_pct, 1),
                    total_exposure=round(self.inventory.total_inventory_usdc(), 2),
                    portfolio_cap=round(self.inventory.portfolio_cap_usdc(), 2),
                    bankroll=round(self.inventory.bankroll, 2),
                )

        # v1.0.155: intraday wide-spread guard. The 30¢ rule existed only at
        # DISCOVER time (v1.0.44) — a held market that crashed intraday kept
        # being quoted, and PAPER's fill model harvested fantasy profits on
        # the torn book (SUI 2026-07-13: re-entries at 3¢, 416 tokens,
        # "+$37.5"). Runs AFTER pre-resolution/resolution-detector so exits
        # on held inventory still fire; the liquidation loop keeps handling
        # exits independently — this only stops NEW quoting.
        if market_spread_cents > 30.0:
            log.info(
                "market_skip_wide_spread_intraday",
                market=market_name[:40],
                market_spread_cents=market_spread_cents,
                reason="spread > 30¢ — crashed/empty book, no new quoting",
            )
            if token_id in self.active_quotes:
                await self._cancel_all_levels(token_id)
            return

        # ── Adverse selection trigger check ──
        if self.risk.adverse_selection.check_trigger(token_id):
            ADVERSE_TRIGGERS.inc()
            log.info(
                "market_skip_adverse_selection",
                market=market_name[:40],
                market_spread_cents=market_spread_cents,
            )
            await self._cancel_all_levels(token_id)
            return

        # ── Risk decision ──
        decision = self.risk.should_quote(token_id, book)
        if not decision.allow_any:
            log.info(
                "market_skip_risk",
                market=market_name[:40],
                market_spread_cents=market_spread_cents,
                reasons=decision.reasons,
            )
            if token_id in self.active_quotes:
                await self._cancel_all_levels(token_id)
            return

        # v1.0.151: momentum filter — market-state side blocking (the
        # drawdown stop handles position-state; they compose via OR).
        self._apply_momentum_filter(token_id, market_name, decision)
        if not decision.allow_bid and not decision.allow_ask:
            if token_id in self.active_quotes:
                await self._cancel_all_levels(token_id)
            return

        # ── Compute reservation price + optimal spread ──
        inv = self.inventory.get_inventory(token_id)
        max_inv_tokens = self.inventory.max_inventory_usdc() / max(book.mid, 0.01)
        # v1.0.85 (N1): pass real time-to-resolution for full A-S model
        ttr_sec = None
        if info and info.end_date_ts > 0:
            now_ts = datetime.now(timezone.utc).timestamp()
            ttr_sec = max(0.0, info.end_date_ts - now_ts)
        reservation, sigma, inv_penalty = self._as_calc.compute(
            token_id=token_id,
            current_mid=book.mid,
            inventory_tokens=inv.net_tokens,
            max_inventory_tokens=max_inv_tokens,
            time_to_resolution_sec=ttr_sec,
        )

        # Kyle's lambda spread multiplier
        kyle_lambda_val, kyle_mult = self._kyle.update_and_compute(token_id, book)

        # Session-based multiplier
        session_mult, session_name = SpreadOptimizer.get_session_multiplier()

        # Inventory aging discount (for stale positions)
        aging_discount = self._compute_aging_discount(inv)

        # Final spread
        optimal_spread_cents = SpreadOptimizer.compute(
            base_spread_cents=settings.spread_cents,
            sigma=sigma,
            kyle_mult=kyle_mult,
            session_mult=session_mult,
            aging_discount_cents=aging_discount,
        )

        # ── Update Prometheus gauges ──
        RESERVATION_PRICE.labels(token_id=token_id[:12]).set(reservation)
        KYLE_LAMBDA.labels(token_id=token_id[:12]).set(kyle_lambda_val)
        INVENTORY_RATIO.labels(token_id=token_id[:12]).set(
            inv.inventory_ratio(self.inventory.max_inventory_usdc())
        )
        SPREAD_CENTS.labels(token_id=token_id[:12]).set(optimal_spread_cents)

        # ── Check fills on existing quotes ──
        existing = self.active_quotes.get(token_id)
        if existing:
            await self._check_fills(token_id, book, existing, market_name)
            # Cancel stale quotes (mid drifted or too old)
            # v1.0.117: lowered age 10→3s + drift threshold 1.0→0.3¢ (config).
            # Was keeping stale bids 10s → fills at old high prices + adverse drift.
            # User: "чому ордер лишається а не відміняється з рухом ціни?"
            existing = self.active_quotes.get(token_id, [])
            still_active: list[ActiveQuote] = []
            for q in existing:
                age = time.monotonic() - q.placed_at
                drift = abs(book.mid - q.mid_at_place)
                if age > 3 or drift > settings.requote_threshold_cents / 100:
                    await self._cancel_quote_level(token_id, q)
                else:
                    still_active.append(q)
            if still_active:
                self.active_quotes[token_id] = still_active
            else:
                self.active_quotes.pop(token_id, None)

        # ── Place new quotes if none active ──
        if token_id not in self.active_quotes or not self.active_quotes[token_id]:
            await self._place_multi_level_quotes(
                token_id=token_id,
                book=book,
                market_name=market_name,
                reservation=reservation,
                spread_cents=optimal_spread_cents,
                decision=decision,
                sigma=sigma,
                kyle_lambda=kyle_lambda_val,
                ttr_hours=ttr_hours,
                kyle_mult=kyle_mult,  # v1.0.120 Task 1: adaptive gap
            )

    async def _handle_resolution_exit(
        self, token_id: str, book: MarketBook, market_name: str
    ) -> None:
        """v1.0.71 (BUG-N22): Exit position when market near resolution.

        Triggered by resolution detector: mid < 0.05 or mid > 0.95.
        Sells at max(mid, entry+5¢) capped at ask-0.001 — same A+C logic
        as Exit All (BUG-N16) and liquidations (BUG-N17).

        Difference from _handle_pre_resolution:
        - pre_resolution: time-based (1h before end_date)
        - resolution_exit: price-based (mid near 0 or 1)

        Both protect from holding through resolution (Australia scenario).
        """
        if token_id in self.active_quotes:
            await self._cancel_all_levels(token_id)
        inv = self.inventory.get_inventory(token_id)
        if abs(inv.net_tokens) > 0.5 and inv.net_tokens > 0 and book.best_bid > 0:
            # A+C pricing (same as Exit All / liquidations)
            mid = (book.best_bid + book.best_ask) / 2.0 if book.best_ask > book.best_bid else book.best_bid
            target_mid = round(mid, 4)
            target_min = round(inv.avg_entry_price + 0.05, 4)
            sell_price = max(target_mid, target_min)
            sell_price = max(0.01, min(0.99, sell_price))
            if book.best_ask > 0:
                sell_price = min(sell_price, round(book.best_ask - 0.001, 4))
            size_usdc = abs(inv.net_tokens) * sell_price

            log.warning(
                "resolution_exit_sell",
                market=market_name[:40],
                mid=round(mid, 4),
                sell_price=round(sell_price, 4),
                avg_entry=round(inv.avg_entry_price, 4),
                net_tokens=round(inv.net_tokens, 2),
                size_usdc=round(size_usdc, 2),
                loss_cents=round((inv.avg_entry_price - sell_price) * 100, 2),
            )

            if settings.paper_trading:
                await self._record_fill(
                    token_id, "SELL", sell_price, size_usdc, market_name,
                    is_liquidation=True,
                )
            else:
                result = await self.clob.place_order(
                    token_id, "SELL", sell_price, size_usdc,
                    order_type="FAK", post_only=False,
                )
                if result.success:
                    await self._record_fill(
                        token_id, "SELL", sell_price, size_usdc, market_name,
                        is_liquidation=True,
                    )

    async def _handle_pre_resolution(
        self, token_id: str, book: MarketBook, market_name: str
    ) -> None:
        """Cancel quotes + liquidate inventory before market resolution.

        v1.0.39 FIX: in LIVE mode this must place a real order. Previously
        _record_fill was called directly (no order sent to Polymarket), so
        the bot decremented inventory/bankroll locally while the real
        position stayed open on-chain through resolution.
        """
        if token_id in self.active_quotes:
            log.warning("pre_resolution_exit", market=market_name[:40], ttr_hours=0)
            await self._cancel_all_levels(token_id)
        inv = self.inventory.get_inventory(token_id)
        if abs(inv.net_tokens) > 0.5:
            if inv.net_tokens > 0 and book.best_bid > 0:
                size_usdc = abs(inv.net_tokens) * book.best_bid
                if settings.paper_trading:
                    await self._record_fill(
                        token_id, "SELL", book.best_bid,
                        size_usdc, market_name, is_liquidation=True,
                    )
                else:
                    # LIVE: place a real FAK sell at best_bid (take what we can).
                    result = await self.clob.place_order(
                        token_id, "SELL", book.best_bid, size_usdc,
                        order_type="FAK", post_only=False,
                    )
                    if result.success:
                        raw = result.raw if isinstance(result.raw, dict) else {}
                        actual_price = book.best_bid
                        if raw.get("price"):
                            try:
                                actual_price = float(raw["price"])
                            except (TypeError, ValueError):
                                pass
                        actual_size = size_usdc
                        if raw.get("size_matched"):
                            try:
                                actual_size = float(raw["size_matched"])
                            except (TypeError, ValueError):
                                pass
                        await self._record_fill(
                            token_id, "SELL", actual_price, actual_size,
                            market_name, is_liquidation=True,
                        )
                        log.info(
                            "pre_resolution_liquidation_live",
                            market=market_name[:40],
                            order_id=result.order_id,
                            price=round(actual_price, 4),
                            size_usdc=round(actual_size, 2),
                        )
                    else:
                        log.error(
                            "pre_resolution_liquidation_failed_live",
                            market=market_name[:40],
                            error=result.error,
                            reason="position will go to resolution",
                        )
            elif inv.net_tokens < 0 and book.best_ask < 1:
                size_usdc = abs(inv.net_tokens) * book.best_ask
                if settings.paper_trading:
                    await self._record_fill(
                        token_id, "BUY", book.best_ask,
                        size_usdc, market_name, is_liquidation=True,
                    )
                else:
                    result = await self.clob.place_order(
                        token_id, "BUY", book.best_ask, size_usdc,
                        order_type="FAK", post_only=False,
                    )
                    if result.success:
                        raw = result.raw if isinstance(result.raw, dict) else {}
                        actual_price = book.best_ask
                        if raw.get("price"):
                            try:
                                actual_price = float(raw["price"])
                            except (TypeError, ValueError):
                                pass
                        actual_size = size_usdc
                        if raw.get("size_matched"):
                            try:
                                actual_size = float(raw["size_matched"])
                            except (TypeError, ValueError):
                                pass
                        await self._record_fill(
                            token_id, "BUY", actual_price, actual_size,
                            market_name, is_liquidation=True,
                        )
                        log.info(
                            "pre_resolution_buyback_live",
                            market=market_name[:40],
                            order_id=result.order_id,
                            price=round(actual_price, 4),
                            size_usdc=round(actual_size, 2),
                        )
                    else:
                        log.error(
                            "pre_resolution_buyback_failed_live",
                            market=market_name[:40],
                            error=result.error,
                            reason="short position will go to resolution",
                        )

    def _compute_aging_discount(self, inv) -> float:
        """Discount spread for stale positions to encourage liquidation."""
        if inv.net_tokens == 0 or inv.open_time == 0:
            return 0.0
        age_sec = time.monotonic() - inv.open_time
        if age_sec < settings.inventory_aging_threshold_sec:
            return 0.0
        steps_past = int((age_sec - settings.inventory_aging_threshold_sec) / 60.0)
        discount = steps_past * settings.inventory_aging_discount_step_cents
        return min(discount, settings.inventory_aging_max_discount_cents)

    # ── Multi-level quote placement ───────────────────────────────────────

    async def _place_multi_level_quotes(
        self,
        token_id: str,
        book: MarketBook,
        market_name: str,
        reservation: float,
        spread_cents: float,
        decision,
        sigma: float,
        kyle_lambda: float,
        ttr_hours: float | None = None,
        kyle_mult: float = 1.0,  # v1.0.120 Task 1: for adaptive gap
    ) -> None:
        """Place up to 3 levels of bid/ask quotes around reservation price.

        FIX: exchanges reject live orders below their minimum size. If a
        level's computed size falls below the minimum, we bump it (rather
        than skipping) so the order is accepted. This means total quote size
        can exceed base_size when multi-level is enabled with small base —
        that's expected.

        v1.0.150: the minimum comes from book.min_order_size (Polymarket $5,
        Limitless = LIMITLESS_MIN_ORDER_USDC, default $1) instead of a
        hardcoded Polymarket $5. With a $10 bankroll the $5 bump exceeded
        the $3 portfolio cap and permanently blocked the BUY side.
        """
        # Exchange hard minimum (live orders below this are rejected)
        min_order_usdc = book.min_order_size

        # Inventory skew (shifts center)
        skew_cents = self.inventory.quote_skew(token_id)
        skew_dollars = skew_cents / 100.0

        # Auto-scale size with bankroll (capped)
        scaling = min(
            settings.order_size_autoscale_max_mult,
            self.inventory.bankroll / max(self.inventory.starting_balance, 1.0),
        )
        base_size = settings.order_size_usdc * scaling
        base_size = max(
            settings.order_size_min_usdc,
            min(base_size, settings.order_size_usdc * settings.order_size_autoscale_max_mult),
        )

        # v1.0.63 (BUG-N14): Volatility-scaled sizing.
        # Professional MM scales size INVERSELY to σ: high vol → smaller size,
        # low vol → larger size. This prevents accumulation of large positions
        # in volatile markets (e.g. Switzerland Round of 16, -$166 loss).
        # sigma comes from A-S calculator (avellaneda_stoikov.py:_estimate_sigma).
        if settings.order_size_volatility_scaling and sigma > 0:
            ref_vol = settings.order_size_reference_volatility
            eff_sigma = max(sigma, settings.as_min_volatility)
            vol_mult = ref_vol / eff_sigma
            vol_mult = max(
                settings.order_size_min_vol_mult,
                min(vol_mult, settings.order_size_max_vol_mult),
            )
            scaled_size = base_size * vol_mult
            # Don't shrink below Polymarket $5 minimum
            scaled_size = max(scaled_size, settings.order_size_min_usdc)
            if abs(vol_mult - 1.0) > 0.05:
                log.info(
                    "order_size_volatility_scaled",
                    market=market_name[:30],
                    sigma=round(sigma, 4),
                    vol_mult=round(vol_mult, 3),
                    base_size=round(base_size, 2),
                    scaled_size=round(scaled_size, 2),
                )
            base_size = scaled_size

        # Build levels
        levels = SpreadOptimizer.compute_levels(spread_cents)
        new_quotes: list[ActiveQuote] = []

        # Current inventory for logging
        inv = self.inventory.get_inventory(token_id)
        inventory_usdc = round(inv.net_usdc_at_entry, 2)
        inventory_tokens = round(inv.net_tokens, 4)

        # v1.0.43 FIX: track tokens already committed to asks across levels.
        # Previously each level independently checked `inv.net_tokens > 0`
        # and placed an ask. With 3 levels × ~$5 ask each, total ask tokens
        # could exceed actual holdings (e.g. 30.93 tokens to sell when only
        # 23.94 owned). In PAPER this was a warning; in LIVE Polymarket
        # rejects the 2nd/3rd ask. Now we decrement remaining_tokens as we
        # commit each level's ask.
        remaining_tokens = inv.net_tokens

        for level_idx, (capture_cents, size_pct) in enumerate(levels, start=1):
            level_size = base_size * size_pct
            # FIX: enforce the exchange minimum per level
            if level_size < min_order_usdc:
                level_size = min_order_usdc
                log.info(
                    "level_size_bumped_to_minimum",
                    market=market_name[:30],
                    level=level_idx,
                    original_size=round(base_size * size_pct, 2),
                    bumped_to=min_order_usdc,
                    reason=f"exchange minimum order = ${min_order_usdc}",
                )

            # v1.0.144: Single order mode (Claude Section 5).
            # When enabled: place ONLY bid OR ask, not both.
            # - If has inventory → place SELL only (close position)
            # - If flat → place BUY only (open position)
            # This is "Patient Directional Mode", NOT market making.
            if settings.single_order_mode:
                if inv.net_tokens > 0.5:
                    # Has long position → SELL only (close)
                    bid_price = None
                    log.info(
                        "single_order_mode_sell_only",
                        market=market_name[:30],
                        level=level_idx,
                        net_tokens=round(inv.net_tokens, 4),
                        reason="single_order_mode + has position → close only",
                    )
                elif inv.net_tokens < -0.5:
                    # Has short position → BUY only (close)
                    ask_price = None
                    log.info(
                        "single_order_mode_buy_only",
                        market=market_name[:30],
                        level=level_idx,
                        net_tokens=round(inv.net_tokens, 4),
                        reason="single_order_mode + has short → close only",
                    )
                else:
                    # Flat → BUY only (open)
                    ask_price = None
                    log.info(
                        "single_order_mode_buy_open",
                        market=market_name[:30],
                        level=level_idx,
                        reason="single_order_mode + flat → open long only",
                    )

            # ── JOIN-MARKET LOGIC (fixed v1.0.18) ───────────────────────────
            # Bot places quotes INSIDE the market spread, with FIXED gap from
            # each edge. Gap does NOT scale with optimal_spread — it's a fixed
            # distance that creates the user-requested spread pattern.
            #
            # User request: market 0.3200-0.3400 (2¢) → our 0.3215-0.3385 (1.7¢)
            # So Level 1 gap = 0.15¢ → our_spread = 2¢ - 2×0.15¢ = 1.7¢ ✅
            #
            # Levels (fixed gaps, NOT proportional to optimal spread):
            #   Level 1 (tightest): gap = 0.15¢ → our_spread = market - 0.30¢
            #   Level 2 (middle):   gap = 0.30¢ → our_spread = market - 0.60¢
            #   Level 3 (widest):   gap = 0.45¢ → our_spread = market - 0.90¢
            market_bid = book.best_bid
            market_ask = book.best_ask
            market_spread = market_ask - market_bid

            # ═══════════════════════════════════════════════════════════
            # v1.0.148 (Jiji's direct order): HARDCODED SPREAD LOGIC.
            # BUY = best_bid + 15 points, SELL = best_ask - 15 points.
            # Pricing goes EXCLUSIVELY through spread_invariant module.
            # Kyle lambda / A-S / skew / config may control SIZE and SIDE,
            # NEVER the entry PRICE. quote_gap_pct & friends no longer
            # affect pricing — kept in config only for backward compat.
            # ═══════════════════════════════════════════════════════════
            from app.services.spread_invariant import (
                hardcoded_quotes,
                validate_quote,
            )

            hq = hardcoded_quotes(market_bid, market_ask, level=level_idx)
            if hq is None:
                log.debug(
                    "quote_skipped_no_room_hardcoded",
                    market=market_name[:30],
                    level=level_idx,
                    market_bid=round(market_bid, 4),
                    market_ask=round(market_ask, 4),
                    spread_cents=round(market_spread * 100, 2),
                    reason="market spread too tight for hardcoded 15-point rule",
                )
                continue
            target_bid = hq.bid
            target_ask = hq.ask

            # BUG-N48 (v1.0.109): skip markets where our_spread < 1.0¢.
            # User: "РИНКИ ДЕ МЕНШЕ 1С СПРЕД НЕ ГОДЯТЬСЯ -- 0.4 І ТД..."
            # Market spread can shrink between discover and quote placement.
            # AUTO_PICK_MIN_SPREAD_CENTS=2.0 filters at discover time, but
            # market moves. This check catches it at quote time.
            our_quote_spread_cents = (target_ask - target_bid) * 100
            if our_quote_spread_cents < 1.0:
                log.debug(
                    "quote_skipped_our_spread_too_thin",
                    market=market_name[:30],
                    our_spread_cents=round(our_quote_spread_cents, 2),
                    market_bid=round(market_bid, 4),
                    market_ask=round(market_ask, 4),
                    market_spread_cents=round(market_spread * 100, 2),
                    reason="our spread < 1.0¢ — not profitable for MM",
                )
                continue

            # v1.0.148: NO price clamping — clamping would BEND the hardcoded
            # rule. Prices come from hardcoded_quotes() already inside
            # [0.01, 0.99] or the market was skipped. Final invariant gate:
            ok, reason = validate_quote(target_bid, target_ask, market_bid, market_ask)
            if not ok:
                log.warning(
                    "quote_dropped_invariant_violation",
                    market=market_name[:30],
                    level=level_idx,
                    target_bid=round(target_bid, 4),
                    target_ask=round(target_ask, 4),
                    market_bid=round(market_bid, 4),
                    market_ask=round(market_ask, 4),
                    reason=reason,
                )
                continue

            # Inventory-aware side blocking
            bid_price = target_bid if decision.allow_bid else None
            ask_price = target_ask if decision.allow_ask else None

            # CRITICAL: Don't place bid if bankroll can't cover it
            # (simulates Polymarket API rejecting order if insufficient balance)
            if bid_price is not None and self.inventory.bankroll < level_size:
                log.debug(
                    "bid_blocked_insufficient_balance",
                    market=market_name[:30],
                    level=level_idx,
                    level_size=round(level_size, 2),
                    bankroll=round(self.inventory.bankroll, 2),
                )
                # v1.0.120 (Task 2b): track capital starvation
                self._capital_starved_count += 1
                bid_price = None
            # v1.0.123 (Claude audit — portfolio exposure cap):
            # Check global exposure BEFORE placing bid. Even if bankroll covers
            # this order, total inventory across ALL markets must stay under cap.
            if bid_price is not None and not self.inventory.can_open_new_position(level_size):
                exposure_pct = round(self.inventory.portfolio_exposure_pct(), 1)
                log.info(
                    "bid_blocked_portfolio_cap",
                    market=market_name[:30],
                    level=level_idx,
                    level_size=round(level_size, 2),
                    total_exposure=round(self.inventory.total_inventory_usdc(), 2),
                    portfolio_cap=round(self.inventory.portfolio_cap_usdc(), 2),
                    exposure_pct=exposure_pct,
                    reason="portfolio exposure cap reached — not adding new position",
                )
                bid_price = None
            # v1.0.150: DRAWDOWN STOP — never average down into a falling
            # knife. If the position is underwater and mid has dropped more
            # than drawdown_stop_bid_cents below entry, block new BUYs on
            # this market; the ask keeps working (breakeven floor / sniper).
            # State transitions are logged at INFO, repeats at debug.
            if bid_price is not None:
                inv_dd = self.inventory.get_inventory(token_id)
                dd_limit = settings.drawdown_stop_bid_cents / 100.0
                # v1.0.155 FIX: drawdown is measured against the REALISTIC
                # exit (best_bid + tick), not mid. On a torn book a lone
                # high ask inflates mid and puts the stop to sleep while
                # the position is deep underwater vs the only real exit
                # (live case: entry 0.0971, bid 0.049/ask 0.108 → mid-based
                # drawdown 1.86¢ "OK", bid-based 4.7¢ — must block).
                realistic_exit_dd = book.best_bid + 0.001
                if (
                    inv_dd.net_tokens > 0
                    and inv_dd.avg_entry_price > 0
                    and realistic_exit_dd < inv_dd.avg_entry_price - dd_limit
                ):
                    logger_fn = (
                        log.debug if token_id in self._drawdown_stopped else log.info
                    )
                    self._drawdown_stopped.add(token_id)
                    logger_fn(
                        "bid_blocked_drawdown_stop",
                        market=market_name[:30],
                        level=level_idx,
                        avg_entry=round(inv_dd.avg_entry_price, 4),
                        realistic_exit=round(realistic_exit_dd, 4),
                        mid=round(book.mid, 4),
                        drawdown_cents=round(
                            (inv_dd.avg_entry_price - realistic_exit_dd) * 100, 2
                        ),
                        limit_cents=settings.drawdown_stop_bid_cents,
                        net_tokens=round(inv_dd.net_tokens, 2),
                        reason="position underwater beyond limit (bid-based) — no averaging down",
                    )
                    bid_price = None
                elif token_id in self._drawdown_stopped:
                    self._drawdown_stopped.discard(token_id)
                    log.info(
                        "drawdown_stop_released",
                        market=market_name[:30],
                        avg_entry=round(inv_dd.avg_entry_price, 4),
                        realistic_exit=round(realistic_exit_dd, 4),
                        reason="price recovered or position closed — BUYs re-enabled",
                    )

            # CRITICAL: Don't place ask if not enough tokens to sell
            # In LIVE: Polymarket API rejects SELL if insufficient token balance
            # (no traditional shorting on CTF — can only sell what you own)
            # v1.0.43: use remaining_tokens (decremented across levels) instead
            # of inv.net_tokens, so we don't commit to sell more than we own.
            #
            # BUG-N47 (v1.0.107): PAPER mode — allow ask even when flat (no tokens).
            # MM bot needs two-sided quoting (bid+ask) for round_trips. If ask is
            # blocked when flat, bot only buys, never sells → 0 round_trips.
            # PAPER simulates, so allow ask. When ask fills in PAPER, inventory
            # goes negative (BUG-N41 clamp prevents this — sells only what we have).
            # In PAPER: ask placed, if filled when flat → clamp to 0 (no short).
            # In LIVE: keep original check (API rejects SELL exceeding balance).
            inv = self.inventory.get_inventory(token_id)
            # tokens this level would sell at current ask price
            tokens_needed_for_this_level = level_size / max(ask_price or 0.01, 0.01)
            if ask_price is not None and remaining_tokens <= 0 and not settings.paper_trading:
                # LIVE only: No tokens to sell — block ask (API would reject)
                log.debug(
                    "ask_blocked_no_tokens_live",
                    market=market_name[:30],
                    level=level_idx,
                    net_tokens=round(inv.net_tokens, 4),
                    remaining_tokens=round(remaining_tokens, 4),
                    reason="LIVE: no tokens to sell (API would reject)",
                )
                ask_price = None
            elif ask_price is not None and remaining_tokens < tokens_needed_for_this_level and not settings.paper_trading:
                # LIVE only: Not enough tokens to cover this level's full ask size.
                # Two options: (a) skip this level, (b) reduce size to remaining.
                # We choose (b) — sell what we have, but only if >= the exchange
                # minimum. Otherwise skip (LIVE API rejects orders below it).
                reduced_size = remaining_tokens * (ask_price or 0.01)
                if reduced_size >= min_order_usdc:
                    log.info(
                        "ask_size_reduced_to_remaining_tokens",
                        market=market_name[:30],
                        level=level_idx,
                        original_size_usdc=round(level_size, 2),
                        reduced_size_usdc=round(reduced_size, 2),
                        remaining_tokens=round(remaining_tokens, 4),
                        reason="would exceed available tokens; reduced to remaining",
                    )
                    level_size = reduced_size
                    # Don't decrement remaining_tokens here — will do after place
                else:
                    log.debug(
                        "ask_skipped_insufficient_tokens_live",
                        market=market_name[:30],
                        level=level_idx,
                        remaining_tokens=round(remaining_tokens, 4),
                        tokens_needed=round(tokens_needed_for_this_level, 4),
                        reduced_size_usdc=round(reduced_size, 2),
                        reason="LIVE: remaining tokens below exchange minimum",
                    )
                    ask_price = None

            # v1.0.38: Aggressive ask pricing for aged positions.
            # Previously: bot blocked ALL sells below entry (v1.0.26), then
            # only "allowed" them after aging — but the ask price was still
            # computed from market spread join logic (near market ask), so
            # it never actually filled when price had dropped.
            #
            # NOW: when position is aged, actively LOWER the ask to be near
            # the market bid, ensuring it actually fills and clears inventory.
            if ask_price is not None and inv.net_tokens > 0:
                age_sec = time.monotonic() - inv.open_time if inv.open_time else 0
                is_aged = age_sec > settings.inventory_aging_threshold_sec
                is_very_aged = age_sec >= settings.inventory_liquidation_aggressive_age_sec
                is_urgent_age = age_sec >= settings.inventory_liquidation_urgent_age_sec
                # v1.0.150: loss-realizing asks allowed ONLY pre-resolution or
                # after the daily stop-loss (supersedes BUG-N43's blanket
                # "URGENT may sell at loss"). Maker fee is zero on Limitless,
                # so the breakeven floor for a resting ask is avg_entry.
                loss_ok, loss_why = self._loss_exit_allowed(token_id)

                if is_very_aged and book.best_bid > 0:
                    # Very aged: sell at market_bid + 0.001 (front of queue)
                    aggressive_ask = min(
                        book.best_bid + 0.001,
                        book.best_ask - 0.001,
                    )
                    aggressive_ask = max(0.01, min(0.99, aggressive_ask))
                    if aggressive_ask < inv.avg_entry_price and not (is_urgent_age and loss_ok):
                        aggressive_ask = round(inv.avg_entry_price + 0.001, 4)
                        log.info(
                            "ask_lowering_clamped_to_entry",
                            market=market_name[:30],
                            level=level_idx,
                            age_sec=round(age_sec, 0),
                            avg_entry=round(inv.avg_entry_price, 4),
                            clamped_ask=round(aggressive_ask, 4),
                            reason="v1.0.150: no loss exits outside pre-resolution/daily-stop",
                        )
                    if aggressive_ask < ask_price:
                        log.info(
                            "ask_aggressive_very_aged",
                            market=market_name[:30],
                            level=level_idx,
                            old_ask=round(ask_price, 4),
                            new_ask=round(aggressive_ask, 4),
                            market_bid=round(book.best_bid, 4),
                            age_sec=round(age_sec, 0),
                            reason="position very aged, lowering ask to market bid",
                        )
                        ask_price = aggressive_ask
                elif is_aged and book.best_bid > 0:
                    # Aged: lower ask toward market bid (but not below entry
                    # unless necessary). This encourages fills.
                    target_aggressive = book.best_bid + (book.spread * 0.25)
                    # v1.0.150: breakeven floor unless loss exits are allowed
                    if target_aggressive < inv.avg_entry_price and not (is_urgent_age and loss_ok):
                        target_aggressive = round(inv.avg_entry_price + 0.001, 4)
                    if target_aggressive < ask_price:
                        ask_price = target_aggressive
                        log.debug(
                            "ask_lowered_aged",
                            market=market_name[:30],
                            level=level_idx,
                            new_ask=round(ask_price, 4),
                            age_sec=round(age_sec, 0),
                        )

                # BUG-N42 (restored v1.0.106): prevent CROSSED quotes.
                # If ask would cross bid → RESTORE ask to bid+0.005 (not block).
                # Blocking ask (v1.0.98) left bot with NO ask → 0 round_trips.
                if (
                    ask_price is not None
                    and bid_price is not None
                    and ask_price <= bid_price
                ):
                    restored_ask = round(bid_price + 0.005, 4)
                    if book.best_ask < 1:
                        restored_ask = min(restored_ask, round(book.best_ask - 0.001, 4))
                    if restored_ask > bid_price:
                        log.info(
                            "ask_restored_above_bid",
                            market=market_name[:30],
                            level=level_idx,
                            bid_price=round(bid_price, 4),
                            original_ask=round(ask_price, 4),
                            restored_ask=round(restored_ask, 4),
                            reason="crossed quote avoided: ask restored above bid",
                        )
                        ask_price = restored_ask
                    else:
                        log.warning(
                            "ask_blocked_crossed_quote",
                            market=market_name[:30],
                            level=level_idx,
                            bid_price=round(bid_price, 4),
                            ask_price=round(ask_price, 4),
                            reason="cannot restore ask above bid (market too tight)",
                        )
                        ask_price = None

                # v1.0.150 final gate: an ask below the breakeven floor is
                # never allowed to rest on the book (it WILL fill at a loss),
                # regardless of age — except pre-resolution / daily stop-loss.
                # Instead of dropping the ask entirely, LIFT it to the floor:
                # the exit stays parked at breakeven ("стоїмо і чекаємо") and
                # fills only when the market recovers. PROFIT_SNIPER handles
                # the fast path when the bid comes back above entry.
                if ask_price is not None and ask_price < inv.avg_entry_price:
                    if is_urgent_age and loss_ok:
                        log.warning(
                            "loss_liquidation_forced",
                            market=market_name[:30],
                            level=level_idx,
                            ask_price=round(ask_price, 4),
                            avg_entry=round(inv.avg_entry_price, 4),
                            age_sec=round(age_sec, 0),
                            loss_cents=round((inv.avg_entry_price - ask_price) * 100, 2),
                            reason=f"maker ask below entry allowed: {loss_why}",
                        )
                    else:
                        lifted = round(inv.avg_entry_price + 0.001, 4)
                        if lifted <= 0.99:
                            # debug: fires every cycle for every underwater
                            # position (26k INFO rows/night at INFO level)
                            log.debug(
                                "ask_lifted_to_breakeven_floor",
                                market=market_name[:30],
                                level=level_idx,
                                original_ask=round(ask_price, 4),
                                lifted_ask=lifted,
                                avg_entry=round(inv.avg_entry_price, 4),
                                age_sec=round(age_sec, 0),
                                reason="v1.0.150: park exit at breakeven, wait for recovery",
                            )
                            ask_price = lifted
                        else:
                            ask_price = None  # entry too close to 1.0 — no room

            # v1.0.43: decrement remaining_tokens by the tokens this ask commits.
            # v1.0.150 FIX: the commit now happens AFTER the aggressive-aging
            # reprice above. Previously it used the pre-reprice ask: size was
            # computed at e.g. 0.5185, the reprice then lowered the ask to
            # 0.481, and size/price committed MORE tokens than owned (10.78 vs
            # 10) — LIVE API rejects such a SELL. In LIVE, clamp the size at
            # the FINAL price so committed tokens never exceed what remains.
            if ask_price is not None:
                tokens_committed = level_size / max(ask_price, 0.01)
                if not settings.paper_trading and tokens_committed > remaining_tokens:
                    clamped_size = remaining_tokens * ask_price
                    if clamped_size >= min_order_usdc:
                        log.info(
                            "ask_size_clamped_to_remaining_after_reprice",
                            market=market_name[:30],
                            level=level_idx,
                            original_size_usdc=round(level_size, 2),
                            clamped_size_usdc=round(clamped_size, 2),
                            ask_price=round(ask_price, 4),
                            remaining_tokens=round(remaining_tokens, 4),
                        )
                        level_size = clamped_size
                        tokens_committed = remaining_tokens
                    else:
                        log.debug(
                            "ask_skipped_insufficient_tokens_after_reprice",
                            market=market_name[:30],
                            level=level_idx,
                            remaining_tokens=round(remaining_tokens, 4),
                            reason="LIVE: remaining tokens below exchange minimum",
                        )
                        ask_price = None
                if ask_price is not None:
                    remaining_tokens -= tokens_committed

            if bid_price is None and ask_price is None:
                continue

            # Place the quote
            quote = await self._place_quote_level(
                token_id=token_id,
                level=level_idx,
                bid_price=bid_price,
                ask_price=ask_price,
                size_usdc=level_size,
                mid=book.mid,
                reservation=reservation,
                spread_cents=spread_cents,
                market_name=market_name,
                book=book,
                inventory_usdc=inventory_usdc,
                inventory_tokens=inventory_tokens,
                ttr_hours=ttr_hours,
            )
            if quote:
                new_quotes.append(quote)

        if new_quotes:
            self.active_quotes[token_id] = new_quotes
            # v1.0.154: first clean quoting cycle after a dirty restart —
            # drop the "⚡ Відновлення після збою" badge.
            if self._crash_recovery_active:
                self._crash_recovery_active = False
                log.info("crash_recovery_cleared", reason="first clean quote cycle")

    async def _place_quote_level(
        self,
        token_id: str,
        level: int,
        bid_price: float | None,
        ask_price: float | None,
        size_usdc: float,
        mid: float,
        reservation: float,
        spread_cents: float,
        market_name: str,
        book: MarketBook | None = None,
        inventory_usdc: float = 0.0,
        inventory_tokens: float = 0.0,
        ttr_hours: float | None = None,
    ) -> ActiveQuote | None:
        """Place bid and/or ask for a single level. PAPER=simulate, LIVE=real."""
        if bid_price is None and ask_price is None:
            return None

        bid_order_id = None
        ask_order_id = None

        if not settings.paper_trading:
            # LIVE: place real orders + register them for fill polling.
            # v1.0.39 FIX: previously the order_id returned by place_order was
            # stored ONLY in ActiveQuote.bid/ask_order_id and never added to
            # _pending_orders. As a result _poll_orders() returned early at
            # `if not self._pending_orders: return` and LIVE fills were never
            # detected — bankroll/inventory diverged from reality on the very
            # first fill. We now populate _pending_orders so _poll_orders_loop
            # can detect fills via get_orders / get_order.
            now_mono_place = time.monotonic()
            if bid_price is not None:
                result: OrderResult = await self.clob.place_order(
                    token_id, "BUY", bid_price, size_usdc, post_only=True
                )
                if result.success and result.order_id:
                    bid_order_id = result.order_id
                    self._pending_orders[bid_order_id] = {
                        "token_id": token_id,
                        "side": "BUY",
                        "price": bid_price,
                        "size_usdc": size_usdc,
                        "market_name": market_name,
                        "level": level,
                        "mid_at_place": mid,
                        "placed_at": now_mono_place,
                    }
                else:
                    log.warning(
                        "live_bid_failed",
                        market=market_name[:30],
                        level=level,
                        error=result.error or "no order_id returned",
                    )
                    bid_price = None  # don't track failed order

            if ask_price is not None:
                result = await self.clob.place_order(
                    token_id, "SELL", ask_price, size_usdc, post_only=True
                )
                if result.success and result.order_id:
                    ask_order_id = result.order_id
                    self._pending_orders[ask_order_id] = {
                        "token_id": token_id,
                        "side": "SELL",
                        "price": ask_price,
                        "size_usdc": size_usdc,
                        "market_name": market_name,
                        "level": level,
                        "mid_at_place": mid,
                        "placed_at": now_mono_place,
                    }
                else:
                    log.warning(
                        "live_ask_failed",
                        market=market_name[:30],
                        level=level,
                        error=result.error or "no order_id returned",
                    )
                    ask_price = None

            if bid_price is None and ask_price is None:
                return None

        quote = ActiveQuote(
            token_id=token_id,
            level=level,
            bid_price=bid_price,
            ask_price=ask_price,
            mid_at_place=mid,
            size_usdc=size_usdc,
            reservation_price=reservation,
            spread_cents=spread_cents,
            bid_order_id=bid_order_id,
            ask_order_id=ask_order_id,
        )

        # Compute our actual spread (after clamps) for logging
        our_bid = bid_price if bid_price is not None else None
        our_ask = ask_price if ask_price is not None else None
        our_spread_cents = (
            round((our_ask - our_bid) * 100, 2)
            if (our_bid is not None and our_ask is not None)
            else None
        )

        # Market context (from book, if available)
        market_bid_log = round(book.best_bid, 4) if book and book.best_bid > 0 else None
        market_ask_log = round(book.best_ask, 4) if book and book.best_ask < 1 else None
        market_spread_log = round(book.spread * 100, 2) if book else None

        log.info(
            "quote_placed",
            market=market_name[:30],
            level=level,
            # Market context (what the order book shows)
            market_bid=market_bid_log,
            market_ask=market_ask_log,
            market_spread_cents=market_spread_log,
            # Our quote (inside the market spread)
            our_bid=round(our_bid, 4) if our_bid is not None else None,
            our_ask=round(our_ask, 4) if our_ask is not None else None,
            our_spread_cents=our_spread_cents,
            # Strategy context
            mid=round(mid, 4),
            reservation=round(reservation, 4),
            optimal_spread_cents=round(spread_cents, 2),
            size_usdc=round(size_usdc, 2),
            # Inventory state (per user request)
            inventory_usdc=round(inventory_usdc, 2),
            inventory_tokens=round(inventory_tokens, 4),
            # Time to resolution (per user request — "ttr hours")
            ttr_hours=ttr_hours,
            mode="LIVE" if not settings.paper_trading else "PAPER",
        )
        return quote

    # ── Cancel ────────────────────────────────────────────────────────────

    async def _cancel_all_levels(self, token_id: str, force: bool = False) -> None:
        """Cancel all quote levels for a market.

        v1.0.144: respects partial_fill_no_cancel setting (Claude Section 3 Solution B).
        When partial_fill_no_cancel=true and force=false:
          - Quotes with NO fill → cancel (safe, no dust created)
          - Quotes with ANY fill → DON'T cancel (would create dust)
        When force=true: always cancel (used for shutdown, market drop, etc.)
        """
        quotes = self.active_quotes.pop(token_id, [])
        for q in quotes:
            if not force and settings.partial_fill_no_cancel:
                # Check if this quote has any fill
                if self._quote_has_partial_fill(q):
                    log.info(
                        "cancel_skipped_partial_fill",
                        token=token_id[:12],
                        level=q.level,
                        reason="partial_fill_no_cancel=true — cancelling would create dust",
                    )
                    # Put the quote back (don't cancel it)
                    self.active_quotes.setdefault(token_id, []).append(q)
                    continue
            await self._cancel_quote_level(token_id, q)

    def _quote_has_partial_fill(self, quote: ActiveQuote) -> bool:
        """Check if a quote has any partial fill.
        v1.0.144: used by never-cancel logic.
        """
        # bid_filled / ask_filled flags track if any fill occurred
        if quote.bid_filled or quote.ask_filled:
            return True
        return False

    async def _cancel_quote_level(self, token_id: str, quote: ActiveQuote) -> None:
        if not settings.paper_trading:
            if quote.bid_order_id:
                await self.clob.cancel_order(quote.bid_order_id)
                self._pending_orders.pop(quote.bid_order_id, None)
            if quote.ask_order_id:
                await self.clob.cancel_order(quote.ask_order_id)
                self._pending_orders.pop(quote.ask_order_id, None)

    # ── Fill checking ─────────────────────────────────────────────────────

    async def _check_fills(
        self,
        token_id: str,
        book: MarketBook,
        quotes: list[ActiveQuote],
        market_name: str,
    ) -> None:
        """Check for fills on existing quotes. PAPER=simulate, LIVE=poll."""
        if settings.paper_trading:
            await self._check_fills_paper(token_id, book, quotes, market_name)
        # LIVE mode: fills are detected in _poll_orders_loop

    async def _check_fills_paper(
        self,
        token_id: str,
        book: MarketBook,
        quotes: list[ActiveQuote],
        market_name: str,
    ) -> None:
        """PAPER-mode fill simulation with realistic adverse selection."""
        direction = self._get_market_direction(token_id)

        for quote in quotes:
            # ── Bid fill simulation ──
            # v1.0.48 FIX (BUG-10): previously `continue` here would skip the
            # ask-fill block below for this quote. With 15% rejection + 40%
            # competition + 20% partial-none, ~60% of bid checks skipped ask.
            # Now we use `pass` so the ask block still runs after a bid skip.
            if not quote.bid_filled and quote.bid_price and quote.bid_price > 0:
                market_bid = book.best_bid
                if market_bid > 0:
                    distance = abs(quote.bid_price - market_bid)
                    if quote.bid_price >= market_bid - 0.003 and distance <= 0.015:
                        # v1.0.50 (BUG-2): rejection/competition rates are now
                        # configurable (paper_rejection_rate, paper_competition_rate).
                        # Defaults are more realistic: 20% rejection (was 15%),
                        # 50% competition (was 40%) — closer to real LIVE behavior.
                        if random.random() < settings.paper_rejection_rate:
                            pass  # v1.0.48: was `continue` (skipped ask block)
                        # Competition
                        elif random.random() < settings.paper_competition_rate:
                            pass  # v1.0.48: was `continue`
                        else:
                            # Directional bias (0.3 — informed traders)
                            direction_mult = 1.0 + (direction * -0.3)
                            # Fill probability — now configurable (paper_fill_prob_base/max)
                            market_spread = book.spread
                            activity_mult = 1.3 if market_spread < 0.015 else (0.6 if market_spread > 0.04 else 1.0)
                            closeness = 1.0 - (distance / 0.015)
                            fill_prob = settings.paper_fill_prob_base * closeness * activity_mult * max(0.5, direction_mult)
                            fill_prob = min(settings.paper_fill_prob_max, max(0.005, fill_prob))

                            if random.random() < fill_prob:
                                # Adverse drift — now configurable (paper_adverse_drift_min/max)
                                adverse_drift = book.mid * random.uniform(
                                    settings.paper_adverse_drift_min,
                                    settings.paper_adverse_drift_max,
                                )
                                # v1.0.75 (BUG-N26): Fix adverse drift for BUY.
                                # OLD: fill_price = min(quote.bid_price + adverse_drift, market_bid + 0.001)
                                #      This capped drift at bid+0.001 → drift never applied → 100% win rate.
                                # NEW: Cap at market_ask (can't buy higher than ask). Drift now actually
                                #      makes fill price worse (higher), modeling informed traders.
                                fill_price = min(quote.bid_price + adverse_drift, book.best_ask - 0.001)
                                fill_price = max(0.01, min(0.99, fill_price))
                                # Partial fills (20% none, 40% partial, 40% full — realistic)
                                partial_roll = random.random()
                                if partial_roll < 0.20:
                                    pass  # v1.0.48: was `continue`
                                elif partial_roll < 0.60:
                                    fill_pct = random.uniform(0.40, 0.75)
                                else:
                                    fill_pct = random.uniform(0.85, 1.0)
                                if partial_roll >= 0.20:
                                    fill_size = quote.size_usdc * fill_pct
                                    if fill_size < 1.0:
                                        pass  # v1.0.48: was `continue`
                                    elif not self.inventory.should_quote_bid(token_id):
                                        await self._cancel_all_levels(token_id)
                                        return
                                    # CRITICAL: check bankroll has enough cash for BUY
                                    # (simulates Polymarket API rejecting order if insufficient balance)
                                    elif self.inventory.bankroll < fill_size:
                                        log.warning(
                                            "fill_skipped_insufficient_balance",
                                            side="BUY",
                                            market=market_name[:30],
                                            fill_size=round(fill_size, 2),
                                            bankroll=round(self.inventory.bankroll, 2),
                                            reason="not enough cash to buy (would be rejected in LIVE)",
                                        )
                                        pass  # v1.0.48: was `continue`
                                    else:
                                        await self._record_fill(
                                            token_id, "BUY", fill_price, fill_size, market_name,
                                            level=quote.level, mid_at_fill=quote.mid_at_place,
                                            exit_path="quote_bid",
                                        )
                                        quote.bid_filled = True
                                        quote.bid_fill_pct = fill_pct

            # ── Ask fill simulation ──
            # v1.0.48 FIX (BUG-10): same as bid — `continue` here would skip
            # the round-trip detection below. Now uses `pass`.
            # v1.0.153 (GLM P1): don't even attempt a SELL fill when flat —
            # previously the attempt ran and logged sell_fill_skipped_no_tokens
            # as a warning every time.
            if (
                not quote.ask_filled and quote.ask_price and quote.ask_price < 1
                and self.inventory.get_inventory(token_id).net_tokens > 0.5
            ):
                market_ask = book.best_ask
                if market_ask < 1:
                    distance = abs(quote.ask_price - market_ask)
                    if quote.ask_price <= market_ask + 0.003 and distance <= 0.015:
                        # v1.0.50 (BUG-2): configurable rejection/competition rates
                        if random.random() < settings.paper_rejection_rate:
                            pass  # v1.0.48: was `continue`
                        # Competition
                        elif random.random() < settings.paper_competition_rate:
                            pass  # v1.0.48: was `continue`
                        else:
                            # Directional bias (0.3 — informed traders)
                            direction_mult = 1.0 + (direction * 0.3)
                            market_spread = book.spread
                            activity_mult = 1.3 if market_spread < 0.015 else (0.6 if market_spread > 0.04 else 1.0)
                            closeness = 1.0 - (distance / 0.015)
                            fill_prob = settings.paper_fill_prob_base * closeness * activity_mult * max(0.5, direction_mult)
                            fill_prob = min(settings.paper_fill_prob_max, max(0.005, fill_prob))

                            if random.random() < fill_prob:
                                # Adverse drift — configurable
                                adverse_drift = book.mid * random.uniform(
                                    settings.paper_adverse_drift_min,
                                    settings.paper_adverse_drift_max,
                                )
                                # v1.0.75 (BUG-N26): Fix adverse drift for SELL.
                                # OLD: fill_price = max(quote.ask_price - adverse_drift, market_ask - 0.001)
                                #      This floored drift at ask-0.001 → drift never applied → 100% win rate.
                                # NEW: Floor at market_bid (can't sell lower than bid). Drift now actually
                                #      makes fill price worse (lower), modeling informed traders.
                                fill_price = max(quote.ask_price - adverse_drift, book.best_bid + 0.001)
                                fill_price = max(0.01, min(0.99, fill_price))
                                # Partial fills (20% none, 40% partial, 40% full — realistic)
                                partial_roll = random.random()
                                if partial_roll < 0.20:
                                    pass  # v1.0.48: was `continue`
                                elif partial_roll < 0.60:
                                    fill_pct = random.uniform(0.40, 0.75)
                                else:
                                    fill_pct = random.uniform(0.85, 1.0)
                                if partial_roll >= 0.20:
                                    fill_size = quote.size_usdc * fill_pct
                                    if fill_size < 1.0:
                                        pass  # v1.0.48: was `continue`
                                    else:
                                        # CRITICAL: Check if we have tokens to sell
                                        # In LIVE: Polymarket API rejects SELL if insufficient token balance
                                        inv_now = self.inventory.get_inventory(token_id)
                                        tokens_to_sell = fill_size / max(fill_price, 0.001)
                                        if inv_now.net_tokens < tokens_to_sell:
                                            log.warning(
                                                "sell_fill_skipped_no_tokens",
                                                market=market_name[:30],
                                                net_tokens=round(inv_now.net_tokens, 4),
                                                tokens_to_sell=round(tokens_to_sell, 4),
                                                reason="insufficient tokens (LIVE API would reject)",
                                            )
                                            pass  # v1.0.48: was `continue`
                                        elif not self.inventory.should_quote_ask(token_id):
                                            await self._cancel_all_levels(token_id)
                                            return
                                        else:
                                            await self._record_fill(
                                                token_id, "SELL", fill_price, fill_size, market_name,
                                                level=quote.level, mid_at_fill=quote.mid_at_place,
                                                exit_path="ask_fill",
                                            )
                                            quote.ask_filled = True
                                            quote.ask_fill_pct = fill_pct

            # ── Round-trip detection (per level) ──
            if quote.bid_filled and quote.ask_filled:
                buy_p = quote.bid_price or 0
                sell_p = quote.ask_price or 0
                log.info(
                    "round_trip",
                    market=market_name[:40],
                    level=quote.level,
                    buy=round(buy_p, 4),
                    sell=round(sell_p, 4),
                    gross_spread=round(sell_p - buy_p, 4),
                )
                ROUND_TRIPS_TOTAL.inc()
                self._round_trip_count += 1

        # Remove fully-filled quotes
        self.active_quotes[token_id] = [q for q in quotes if not (q.bid_filled and q.ask_filled)]
        if not self.active_quotes[token_id]:
            self.active_quotes.pop(token_id, None)

    def _get_market_direction(self, token_id: str) -> float:
        """Estimate short-term direction (-1..+1) from price history."""
        state = self._as_calc.get_state(token_id)
        if not state or len(state.price_history) < 5:
            return 0.0
        prices = [p for _, p in state.price_history]
        recent = prices[-1]
        past = prices[-5]
        if past == 0:
            return 0.0
        change = (recent - past) / past
        return max(-1.0, min(1.0, change * 50))

    # ── LIVE mode: order polling ──────────────────────────────────────────

    async def _poll_orders_loop(self) -> None:
        """In LIVE mode: poll order status to detect fills."""
        await asyncio.sleep(5)
        while self._running:
            try:
                await self._poll_orders()
            except asyncio.CancelledError:
                break
            except Exception as e:
                log.debug("poll_error", error=str(e))
            await asyncio.sleep(3)

    async def _poll_orders(self) -> None:
        """v1.0.46 FIX (BUG-5, BUG-6): safer fill detection.
        v1.0.47 FIX: corrected status strings per Polymarket API docs.

        BUG-5: previously `final.get("size_matched", info["size_usdc"])` would
          default to the FULL order size when the API omitted `size_matched`.
          For PARTIALLY_FILLED this recorded a phantom full fill. Now we treat
          a missing size_matched as 0 (no fill recorded) and log a warning.
        BUG-6: previously only MATCHED/FILLED/FILLED_PARTIAL triggered fill
          recording. A CANCELLED order with a partial fill was silently
          dropped. Now we check size_matched for ANY non-open status and
          record whatever partial fill exists.
        v1.0.47: Polymarket API uses `PARTIALLY_FILLED` (not `FILLED_PARTIAL`).
          Status values: LIVE (active on book), PARTIALLY_FILLED, FILLED,
          CANCELLED. `size_matched` is preserved after CANCELLED (partial
          fill kept). After cancel, size_matched does NOT increase further.
        """
        if not self._pending_orders:
            return
        from py_clob_client.clob_types import OpenOrderParams

        try:
            open_orders = self.clob._client.get_orders(OpenOrderParams())
        except Exception as e:
            log.warning("poll_orders_failed", error=str(e))
            return

        open_ids = {o.get("id") for o in open_orders if isinstance(o, dict)}
        now_mono = time.monotonic()

        for order_id in list(self._pending_orders.keys()):
            info = self._pending_orders[order_id]
            age = now_mono - info["placed_at"]

            # If order is no longer in open list → it filled or was canceled
            if order_id not in open_ids:
                # Check final status via get_order
                try:
                    final = self.clob._client.get_order(order_id)
                except Exception as e:
                    log.debug("get_order_failed", order_id=order_id, error=str(e))
                    self._pending_orders.pop(order_id, None)
                    continue

                if not isinstance(final, dict):
                    log.warning(
                        "poll_orders_unexpected_response",
                        order_id=order_id,
                        response_type=type(final).__name__,
                    )
                    self._pending_orders.pop(order_id, None)
                    continue

                status = (final.get("status", "") or "").upper()

                # v1.0.46 (BUG-5): don't assume full fill when size_matched
                # is missing. Read it explicitly; default to 0 (not the
                # original size) so we don't record phantom fills.
                size_matched_raw = final.get("size_matched")
                if size_matched_raw is None:
                    # Some API responses use "size_matched" (USDC) others use
                    # "makingAmount"/"takingAmount" (tokens). Try both.
                    making = final.get("makingAmount")
                    if making is not None:
                        try:
                            # makingAmount is tokens; convert to USDC at price
                            price_for_conv = float(final.get("price", info["price"]))
                            size_matched_usd = float(making) * price_for_conv
                        except (TypeError, ValueError):
                            size_matched_usd = 0.0
                    else:
                        size_matched_usd = 0.0
                        if status in ("MATCHED", "FILLED", "PARTIALLY_FILLED"):
                            log.warning(
                                "poll_orders_size_matched_missing",
                                order_id=order_id,
                                status=status,
                                reason="API reports fill but no size_matched/makingAmount — recording 0",
                            )
                else:
                    try:
                        size_matched_usd = float(size_matched_raw)
                    except (TypeError, ValueError):
                        size_matched_usd = 0.0
                        log.warning(
                            "poll_orders_size_matched_unparseable",
                            order_id=order_id,
                            raw=size_matched_raw,
                        )

                # v1.0.46 (BUG-6): record ANY partial fill, regardless of
                # status (was: only MATCHED/FILLED/FILLED_PARTIAL). A
                # CANCELLED order may still have a partial fill recorded
                # in size_matched (v1.0.47: confirmed by Polymarket API docs
                # — size_matched is preserved after CANCELLED).
                if size_matched_usd > 0:
                    try:
                        fill_price = float(final.get("price", info["price"]))
                    except (TypeError, ValueError):
                        fill_price = info["price"]

                    # Skip tiny dust fills (< $0.01) — likely rounding noise
                    if size_matched_usd >= 0.01:
                        await self._record_fill(
                            info["token_id"], info["side"], fill_price,
                            size_matched_usd, info["market_name"],
                            level=info.get("level", 1),
                            mid_at_fill=info.get("mid_at_place", fill_price),
                        )
                        log.info(
                            "poll_orders_fill_detected",
                            order_id=order_id,
                            status=status,
                            side=info["side"],
                            size_usdc=round(size_matched_usd, 4),
                            price=round(fill_price, 4),
                            market=info["market_name"][:30],
                        )
                    else:
                        log.debug(
                            "poll_orders_dust_fill_skipped",
                            order_id=order_id,
                            size_usdc=size_matched_usd,
                        )
                elif status in ("MATCHED", "FILLED", "PARTIALLY_FILLED"):
                    # API says filled but size_matched=0 — suspicious, log it
                    log.warning(
                        "poll_orders_fill_zero_size",
                        order_id=order_id,
                        status=status,
                        reason="status indicates fill but size_matched=0; no fill recorded",
                    )

                self._pending_orders.pop(order_id, None)
            elif age > 30:
                # Timeout: cancel. Note: the cancelled order may still have
                # a partial fill that we'll detect on the NEXT poll cycle
                # (after it disappears from open_ids). So we don't pop here
                # immediately — we let the next cycle's get_order() read
                # the final status with size_matched.
                await self.clob.cancel_order(order_id)
                # Give the cancel one more cycle to settle before popping,
                # so the partial-fill check above can run on the final state.
                # If the cancel fails silently, the 30s timeout will retry.
                info["placed_at"] = now_mono - 25  # grace period for next cycle
                log.debug(
                    "poll_orders_cancel_sent",
                    order_id=order_id,
                    age_sec=round(age, 1),
                    reason="order timeout, will re-check final status next cycle",
                )

    # ── Active inventory liquidation (v1.0.38) ───────────────────────────
    # Solves the critical "inventory accumulation" problem: bot buys but
    # won't sell below entry, so positions get stuck when price drops.
    # This loop aggressively clears aged positions by placing sell orders
    # at/below market bid, accepting realized losses to free up capital.

    async def _state_persistence_loop(self) -> None:
        """v1.0.72 (BUG-N23): Save inventory state to DB every 60s.

        Enables crash recovery: if bot dies (power loss, kill -9, OOM),
        load_state_from_db() on next startup restores bankroll + positions.
        """
        await asyncio.sleep(10)  # let bot stabilize first
        while self._running:
            try:
                from app.core.db import AsyncSessionLocal
                async with AsyncSessionLocal() as db:
                    await self.inventory.save_state_to_db(db)
            except asyncio.CancelledError:
                break
            except Exception as e:
                log.warning(
                    "state_persistence_error",
                    error=str(e),
                    error_type=type(e).__name__,
                )
            await asyncio.sleep(60)

    async def _liquidation_loop(self) -> None:
        """Background task: aggressively liquidate aged inventory.

        Runs every `inventory_liquidation_check_sec` seconds. For each
        market with a long position older than `aggressive_age_sec`:
          - Cancel existing quotes (so we can place aggressive ones)
          - Place a SELL at market_bid + 0.001 (front of bid queue)
        If older than `urgent_age_sec`:
          - Place a SELL at market_bid (take whatever we can get)
        This ensures stuck positions are cleared, freeing capital.
        """
        await asyncio.sleep(settings.inventory_liquidation_check_sec)
        while self._running:
            try:
                if not self._trading_paused and not self.inventory.halted:
                    await self._liquidate_aged_positions()
                    # v1.0.50 FIX (BUG-3): also clean up orphaned positions.
                    # These are positions on markets that are no longer in
                    # self.clob.books (market was replaced/closed). Without
                    # this, orphaned positions stay in inventory forever
                    # (unless they hit pre-resolution exit, but if the market
                    # was already replaced we don't track end_date).
                    await self._cleanup_orphaned_positions()
            except asyncio.CancelledError:
                break
            except Exception as e:
                log.warning("liquidation_loop_error", error=str(e))
            await asyncio.sleep(settings.inventory_liquidation_check_sec)

    async def _snapshot_loop(self) -> None:
        """v1.0.88: periodically persist mm_snapshots (price history for backtest).

        Before v1.0.88 the MarketSnapshot table was defined in the schema but
        NEVER written (only pruned), making any 'hold N minutes' backtest
        impossible. This loop logs one row per active market every
        mm_snapshot_log_interval_sec. Kyle lambda is read READ-ONLY from the
        existing KyleLambda state (no mutation → no race with the quote loop,
        which calls update_and_compute); volatility is left 0.0 for now
        (A-S sigma is computed inside the quote loop and not cached here).
        Modeled on _liquidation_loop.
        """
        await asyncio.sleep(settings.mm_snapshot_log_interval_sec)
        while self._running:
            try:
                if not self._trading_paused and not self.inventory.halted:
                    await self._log_market_snapshots()
            except asyncio.CancelledError:
                break
            except Exception as e:
                log.warning("snapshot_loop_error", error=str(e))
            await asyncio.sleep(settings.mm_snapshot_log_interval_sec)

    async def _log_market_snapshots(self) -> None:
        """Write one MarketSnapshot row per active market in one DB transaction."""
        try:
            from app.core.db import AsyncSessionLocal

            rows: list[MarketSnapshot] = []
            for token_id, book in self.clob.books.items():
                # Skip markets with no usable quote (best_bid <= 0 means no
                # real market yet — mid/spread would be meaningless).
                if not book or book.best_bid <= 0:
                    continue
                inv = self.inventory.inventories.get(token_id)
                # READ-ONLY: get_state returns the existing KyleState without
                # mutating imbalance_history (unlike update_and_compute).
                kyle_state = self._kyle.get_state(token_id)
                rows.append(
                    MarketSnapshot(
                        market_id=token_id,
                        mid_price=book.mid,
                        spread=book.spread,
                        volatility=0.0,
                        kyle_lambda=kyle_state.last_lambda if kyle_state else 0.0,
                        our_inventory=inv.net_tokens if inv else 0.0,
                        bankroll_usdc=self.inventory.bankroll,
                    )
                )
            if not rows:
                return
            async with AsyncSessionLocal() as db:
                db.add_all(rows)
                await db.commit()
        except Exception as e:
            # Non-fatal: snapshot logging must never break trading.
            log.debug("snapshot_log_failed", error=str(e))

    # v1.0.122 (Claude audit p.1): periodic bankroll sync loop for LIVE mode.
    async def _bankroll_sync_loop(self) -> None:
        """Every 300s, sync internal bankroll with real wallet balance.

        PAPER: no-op (sync_bankroll_from_wallet returns immediately).
        LIVE: detects drift >5% between internal accounting and real wallet.
        """
        await asyncio.sleep(300)  # first sync after 5 min (startup sync already done)
        while self._running:
            try:
                await self.inventory.sync_bankroll_from_wallet(self.clob)
            except asyncio.CancelledError:
                raise
            except Exception as e:
                log.warning("bankroll_sync_loop_error", error=str(e))
            await asyncio.sleep(300)

    # ── v1.0.151: momentum filter ─────────────────────────────────────────

    def _push_mid(self, token_id: str, mid: float) -> None:
        """Append (ts, mid) to the market's ring buffer (~10 min depth)."""
        buf = self._mid_history.setdefault(token_id, deque())
        now = time.monotonic()
        buf.append((now, mid))
        cutoff = now - 600.0
        while buf and buf[0][0] < cutoff:
            buf.popleft()

    def _momentum_cents(self, token_id: str) -> float | None:
        """mid_now − mid_window_ago, in cents. None until the buffer spans
        the full momentum window (no blocking on insufficient data)."""
        buf = self._mid_history.get(token_id)
        if not buf:
            return None
        target = time.monotonic() - settings.momentum_window_sec
        ref = None
        for ts, mid in buf:
            if ts <= target:
                ref = mid  # latest sample at/before the window boundary
            else:
                break
        if ref is None:
            return None
        return (buf[-1][1] - ref) * 100.0

    def _apply_momentum_filter(self, token_id: str, market_name: str, decision) -> None:
        """Block the side a fast market would run over (falling → no bid,
        rising → no ask). Mutates decision in place; transition-only INFO."""
        mom = self._momentum_cents(token_id)
        falling = mom is not None and mom <= -settings.momentum_bid_block_cents
        rising = mom is not None and mom >= settings.momentum_ask_block_cents

        if falling:
            logger_fn = (
                log.debug if token_id in self._momentum_bid_blocked else log.info
            )
            self._momentum_bid_blocked.add(token_id)
            logger_fn(
                "momentum_bid_blocked",
                market=market_name[:30],
                momentum_cents=round(mom, 2),
                window_sec=settings.momentum_window_sec,
                reason="market falling — our bid is a feeding trough for sellers",
            )
            decision.allow_bid = False
        elif token_id in self._momentum_bid_blocked:
            self._momentum_bid_blocked.discard(token_id)
            log.info(
                "momentum_bid_block_released",
                market=market_name[:30],
                momentum_cents=round(mom, 2) if mom is not None else None,
            )

        if rising:
            logger_fn = (
                log.debug if token_id in self._momentum_ask_blocked else log.info
            )
            self._momentum_ask_blocked.add(token_id)
            logger_fn(
                "momentum_ask_blocked",
                market=market_name[:30],
                momentum_cents=round(mom, 2),
                window_sec=settings.momentum_window_sec,
                reason="market rising — our ask is a feeding trough for buyers",
            )
            decision.allow_ask = False
        elif token_id in self._momentum_ask_blocked:
            self._momentum_ask_blocked.discard(token_id)
            log.info(
                "momentum_ask_block_released",
                market=market_name[:30],
                momentum_cents=round(mom, 2) if mom is not None else None,
            )

    # ── v1.0.155: adverse-rate market rotation ────────────────────────────

    def _record_adverse_probe(self, token_id: str, fill_price: float) -> None:
        """Called on every BUY fill: schedule a +60s mid check."""
        self._adverse_probes.append((token_id, fill_price, time.monotonic()))

    def _mid_at_or_after(self, token_id: str, ts: float) -> float | None:
        """Earliest mid sample at/after ts from the v151 ring buffer."""
        buf = self._mid_history.get(token_id)
        if not buf:
            return None
        for sample_ts, mid in buf:
            if sample_ts >= ts:
                return mid
        return None

    def _process_adverse_probes(self) -> None:
        """Mature 60s-old probes into per-market outcome windows; ban a
        market whose adverse_rate > 30% over the last 20 fills (≥10)."""
        if not self._adverse_probes:
            return
        now = time.monotonic()
        remaining: list[tuple[str, float, float]] = []
        for token_id, fill_px, t0 in self._adverse_probes:
            if now - t0 < 60.0:
                remaining.append((token_id, fill_px, t0))
                continue
            mid_later = self._mid_at_or_after(token_id, t0 + 60.0)
            if mid_later is None:
                continue  # market gone / no data — drop the probe
            adverse = mid_later < fill_px - 0.005
            outcomes = self._fill_outcomes.setdefault(token_id, deque(maxlen=20))
            outcomes.append(adverse)
            if len(outcomes) >= 10:
                rate = sum(outcomes) / len(outcomes)
                if rate > 0.30 and token_id not in self._banned_markets:
                    self._banned_markets[token_id] = (
                        now + settings.adverse_market_ban_sec
                    )
                    self._adverse_ban_count += 1
                    info = self.clob.markets.get(token_id)
                    log.warning(
                        "market_banned_adverse_rate",
                        market=(info.question[:40] if info else token_id[:12]),
                        adverse_rate=round(rate, 2),
                        window_fills=len(outcomes),
                        ban_sec=settings.adverse_market_ban_sec,
                        reason="fills keep going adverse — rotate the market out",
                    )
        self._adverse_probes = remaining

    def _is_market_banned(self, token_id: str) -> bool:
        until = self._banned_markets.get(token_id)
        if until is None:
            return False
        if time.monotonic() >= until:
            self._banned_markets.pop(token_id, None)
            self._fill_outcomes.pop(token_id, None)  # fresh slate
            info = self.clob.markets.get(token_id)
            log.info(
                "market_ban_expired",
                market=(info.question[:40] if info else token_id[:12]),
            )
            return False
        return True

    # ── v1.0.150: exit-policy helpers ─────────────────────────────────────

    def _taker_fee_per_token(self, token_id: str, price: float) -> float:
        """Estimated taker fee in $ per token at the given price.

        Limitless: per-market flag metadata.fee (adapter stores it as
        _meta[token].fee_bearing); the actual rate comes from the LIVE
        profile (rank.feeRateBps) and is unknown in PAPER, where the
        conservative taker_fee_bps_assumed is used instead. Non-fee-bearing
        markets (and Polymarket) → 0. Maker fees are zero on Limitless.
        """
        meta_map = getattr(self.clob, "_meta", None)
        meta = meta_map.get(token_id) if isinstance(meta_map, dict) else None
        if meta is None or not getattr(meta, "fee_bearing", False):
            return 0.0
        live_bps = float(getattr(self.clob, "_fee_rate_bps", 0) or 0)
        bps = live_bps if live_bps > 0 else settings.taker_fee_bps_assumed
        return price * bps / 10000.0

    def _loss_exit_allowed(self, token_id: str) -> tuple[bool, str]:
        """Loss-realizing exits are allowed ONLY pre-resolution or after
        the daily stop-loss has tripped. Everywhere else: hold and wait."""
        info = self.clob.markets.get(token_id)
        if info and info.end_date_ts > 0:
            ttr = info.end_date_ts - datetime.now(timezone.utc).timestamp()
            if ttr < settings.pre_resolution_exit_sec:
                return True, f"pre_resolution (ttr={int(max(ttr, 0))}s)"
        if self.inventory.daily_pnl <= -settings.max_daily_loss_usd:
            return True, f"daily_stop_loss (daily_pnl={self.inventory.daily_pnl:.2f})"
        return False, ""

    async def _maybe_no_hedge(self, token_id: str, inv, book, market_name: str) -> bool:
        """v1.0.151 emergency brake (OFF by default, no_hedge_enabled).

        Deeply underwater YES position: buy NO → the YES+NO pair is worth
        exactly $1 (merge, or automatically at resolution), fixing a KNOWN
        bounded loss (entry + P_no − 1 + fee per token) instead of the
        0-or-everything lottery. Fires only when that fixed loss is small
        enough (no_hedge_max_loss_cents) and resolution is far enough away
        (pre-resolution handles the endgame otherwise). Returns True when
        the hedge executed (caller skips other liquidation logic).
        """
        if not settings.no_hedge_enabled:
            return False
        if token_id in self._hedged_positions:
            return False
        now = time.monotonic()
        if now - self._no_hedge_last_check.get(token_id, 0.0) < 60.0:
            return False
        self._no_hedge_last_check[token_id] = now

        drawdown_cents = (inv.avg_entry_price - book.mid) * 100.0
        if drawdown_cents < settings.no_hedge_trigger_drawdown_cents:
            return False
        info = self.clob.markets.get(token_id)
        if not info or info.end_date_ts <= 0:
            return False
        ttr = info.end_date_ts - datetime.now(timezone.utc).timestamp()
        if ttr < settings.no_hedge_min_ttr_sec:
            return False  # pre-resolution exit owns the endgame

        # NO best ask. Binary CTF market: the NO side is the mirror of the
        # YES book, NO_ask = 1 − YES_bid. In PAPER this is an estimate
        # (marked in the log); LIVE should verify against the real NO book
        # on the smoke run.
        p_no_ask = round(1.0 - book.best_bid, 4)
        fee_per_token = self._taker_fee_per_token(token_id, p_no_ask)
        fixed_loss = inv.avg_entry_price + p_no_ask - 1.0 + fee_per_token
        if fixed_loss * 100.0 > settings.no_hedge_max_loss_cents:
            log.info(
                "no_hedge_skipped_too_expensive",
                market=market_name,
                avg_entry=round(inv.avg_entry_price, 4),
                p_no_ask=p_no_ask,
                fixed_loss_cents=round(fixed_loss * 100, 2),
                max_loss_cents=settings.no_hedge_max_loss_cents,
                reason="insurance costs more than the configured cap",
            )
            return False

        tokens = inv.net_tokens
        if settings.paper_trading:
            # Economically identical to selling YES at 1 − P_no_ask
            # (= best_bid): simulate via a SELL fill so inventory and
            # bankroll stay consistent. level 98 = NO-hedge.
            exit_px = round(1.0 - p_no_ask, 4)
            await self._record_fill(
                token_id, "SELL", exit_px, tokens * exit_px, market_name,
                level=98,
                mid_at_fill=book.mid,
                is_liquidation=True,
                exit_path="NO_HEDGE",
            )
        else:
            meta_map = getattr(self.clob, "_meta", None)
            meta = meta_map.get(token_id) if isinstance(meta_map, dict) else None
            no_token = getattr(meta, "no_token", "") if meta else ""
            if not no_token:
                log.warning(
                    "no_hedge_no_token_unknown",
                    market=market_name,
                    reason="adapter has no NO-token id for this market",
                )
                return False
            result = await self.clob.place_order(
                no_token, "BUY", p_no_ask, tokens * p_no_ask,
                order_type="FAK", post_only=False,
            )
            if not result.success:
                log.warning(
                    "no_hedge_order_failed",
                    market=market_name,
                    error=result.error,
                )
                return False
            # merge/redeem call is UNVERIFIED on Limitless — even without
            # it, a held YES+NO pair settles at exactly $1 on resolution,
            # which is economically equivalent to merging now.

        self._no_hedge_count += 1
        self._hedged_positions.add(token_id)
        log.warning(
            "no_hedge_executed",
            market=market_name,
            tokens=round(tokens, 4),
            avg_entry=round(inv.avg_entry_price, 4),
            p_no_ask=p_no_ask,
            p_no_source="estimated_from_yes_bid" if settings.paper_trading else "order",
            fee_per_token=round(fee_per_token, 5),
            fixed_loss_cents=round(fixed_loss * 100, 2),
            drawdown_cents=round(drawdown_cents, 2),
            ttr_sec=round(ttr, 0),
            mode="PAPER" if settings.paper_trading else "LIVE",
        )
        return True

    async def _liquidate_aged_positions(self) -> None:
        """Scan all inventories and liquidate aged ones."""
        now_mono = time.monotonic()
        for token_id, inv in list(self.inventory.inventories.items()):
            # Only liquidate long positions (we can only sell what we own)
            if inv.net_tokens <= 0.5:
                continue
            if inv.open_time == 0:
                continue

            age_sec = now_mono - inv.open_time
            book = self.clob.books.get(token_id)
            if not book or book.best_bid <= 0:
                continue

            info = self.clob.markets.get(token_id)
            market_name = info.question[:40] if info else token_id[:12]

            # v1.0.151: NO-hedge emergency brake (disabled by default).
            if await self._maybe_no_hedge(token_id, inv, book, market_name):
                continue

            # Determine liquidation tier based on age
            market_bid = book.best_bid
            market_ask = book.best_ask
            # v1.0.66 (BUG-N17): mid-based liquidation pricing.
            # OLD: sell at bid+0.001 (ignored mid) → lost $3+ per position
            #      when spread was wide (bid 0.192, mid 0.320, ask 0.449).
            # NEW: target = max(mid, entry+5¢), capped at ask-0.001.
            #      Same A+C priority as Exit All (BUG-N16 fix).
            mid = (market_bid + market_ask) / 2.0 if market_ask > market_bid else market_bid
            target_mid = round(mid, 4)
            target_min = round(inv.avg_entry_price + 0.05, 4)  # entry + 5¢
            tier: str = ""

            # v1.0.153: PROFIT SNIPER now follows the HARDCODED exit ladder
            # (app/services/profit_capture.py, Jiji's ethalon). A fresh
            # position waits for the full spread (free maker ask-fill); the
            # sniper takes early ONLY when the bid delivers ≥70% of the
            # achievable max, the bar decaying linearly 70%→0% between 5 and
            # 30 minutes of age. PROFIT_TAKE_MIN_CENTS from .env no longer
            # participates (deprecated). Trigger and price remain bid-based
            # (BUG-N36 heritage), the v1.0.150 breakeven floor still rules.
            from app.services.profit_capture import (
                MIN_ABS_PROFIT_CENTS,
                sniper_threshold_cents,
            )
            from app.services.spread_invariant import hardcoded_quotes as _hq_now

            realistic_exit_for_trigger = round(market_bid + 0.001, 4)
            taker_fee = self._taker_fee_per_token(token_id, realistic_exit_for_trigger)
            # Achievable max = today's hardcode ask − entry (maker exit, free).
            _hq = _hq_now(market_bid, market_ask, level=1)
            hardcode_ask = _hq.ask if _hq else round(market_ask - 0.0015, 4)
            achievable_max_cents = (hardcode_ask - inv.avg_entry_price) * 100.0
            net_bid_profit_cents = (
                (market_bid - inv.avg_entry_price) - taker_fee
            ) * 100.0
            threshold_cents = sniper_threshold_cents(
                max(achievable_max_cents, 0.0), age_sec
            )
            if net_bid_profit_cents >= threshold_cents:
                tier = "PROFIT_SNIPER"
                is_urgent = False
                # Hit the bid: FAK at (bid + tick), capped below the ask.
                sell_price = min(
                    realistic_exit_for_trigger, round(market_ask - 0.001, 4)
                )
                taken_pct = (
                    round(net_bid_profit_cents / achievable_max_cents * 100.0, 1)
                    if achievable_max_cents > 0
                    else None
                )
                self._sniper_taken_pct_sum += taken_pct or 0.0
                self._sniper_fired_count += 1
                log.info(
                    "sniper_fired",
                    market=market_name,
                    age_sec=round(age_sec, 0),
                    avg_entry=inv.avg_entry_price,
                    market_bid=market_bid,
                    hardcode_ask=hardcode_ask,
                    achievable_max_cents=round(achievable_max_cents, 2),
                    net_bid_profit_cents=round(net_bid_profit_cents, 2),
                    threshold_cents=round(threshold_cents, 2),
                    taken_pct=taken_pct,
                    taker_fee_per_token=round(taker_fee, 5),
                    reason="bid delivers enough of the achievable max — take it",
                )
            elif age_sec < settings.inventory_liquidation_aggressive_age_sec:
                # v1.0.63 (BUG-N13): Critical tier — inventory at 95%+ of max.
                # Professional MM deleverages immediately when at hard cap,
                # regardless of age. Without this, bot can accumulate beyond
                # max_inventory_usdc via rapid fills and get stuck.
                max_usd = self.inventory.max_inventory_usdc()
                position_usd = abs(inv.net_tokens) * market_bid
                if max_usd > 0 and position_usd >= max_usd * 0.95:
                    is_urgent = False
                    tier = "CRITICAL"
                    # v1.0.66: mid-based pricing (was bid+0.001)
                    sell_price = max(target_mid, target_min)
                    sell_price = min(sell_price, round(market_ask - 0.001, 4))
                    log.warning(
                        "critical_tier_liquidation_triggered",
                        market=market_name,
                        age_sec=round(age_sec, 0),
                        position_usd=round(position_usd, 2),
                        max_usd=round(max_usd, 2),
                        ratio=round(position_usd / max_usd, 3),
                        mid=round(mid, 4),
                        target_mid=round(target_mid, 4),
                        target_min=round(target_min, 4),
                        sell_price=round(sell_price, 4),
                        reason="position at 95%+ of hard cap — deleverage now",
                    )
                else:
                    continue  # not aged enough, not at critical cap
            else:
                is_urgent = age_sec >= settings.inventory_liquidation_urgent_age_sec
                if is_urgent:
                    # Urgent: sell at max(mid, entry+5¢), capped at ask-0.001
                    # v1.0.66: was market_bid (any price), now mid-based
                    sell_price = max(target_mid, target_min)
                    sell_price = min(sell_price, round(market_ask - 0.001, 4))
                    tier = "URGENT"
                else:
                    # Aggressive: sell at max(mid, entry+5¢), capped at ask-0.001
                    # v1.0.66: was bid+0.001, now mid-based
                    sell_price = max(target_mid, target_min)
                    sell_price = min(sell_price, round(market_ask - 0.001, 4))
                    tier = "AGGRESSIVE"

            # Clamp to valid range
            sell_price = max(0.01, min(0.99, sell_price))

            # BUG-N34 (v1.0.91): compute the REALISTIC execution price BEFORE
            # the loss-tolerance check. Previously loss_cents was derived from
            # `sell_price` (mid-based, optimistic target), but the actual fill
            # for a taker SELL crossing the book cannot exceed market_bid (+0.001
            # tick improvement). On wide-spread books mid >> bid, so the old
            # loss_cents was systematically understated — the "max loss" guard
            # was partially blind exactly where it matters (AGGRESSIVE /
            # OPPORTUNISTIC_PROFIT tiers, where is_urgent=False makes the guard
            # active). URGENT bypasses the guard by design (unchanged).
            #
            # `realistic_exit_price` is reused below by both PAPER (was
            # `fillable_price`) and LIVE (for consistent logging).
            realistic_exit_price = min(sell_price, round(market_bid + 0.001, 4))

            # Check loss tolerance — now against the realistic fill price.
            loss_cents = (inv.avg_entry_price - realistic_exit_price) * 100
            if loss_cents > settings.inventory_liquidation_max_loss_cents and not is_urgent:
                # Loss too big and not urgent yet — wait
                log.debug(
                    "liquidation_skipped_loss_too_big",
                    market=market_name,
                    age_sec=round(age_sec, 0),
                    loss_cents=round(loss_cents, 2),
                    max_loss_cents=settings.inventory_liquidation_max_loss_cents,
                    sell_price=round(sell_price, 4),
                    realistic_exit_price=round(realistic_exit_price, 4),
                )
                continue

            # v1.0.150: NO-LOSS EXIT POLICY. Any liquidation whose realistic
            # execution price sits below the breakeven floor (entry + taker
            # fee) is FORBIDDEN — for every tier including URGENT — except:
            #   (a) the pre-resolution window (ttr < pre_resolution_exit_sec)
            #   (b) the daily stop-loss has tripped.
            # Supersedes BUG-N39 (AGGRESSIVE no-loss) and REMOVES the
            # v1.0.120 opportunity-cost override (trend / capital-starvation
            # could force loss exits at any time — now banned).
            breakeven_floor = inv.avg_entry_price + self._taker_fee_per_token(
                token_id, realistic_exit_price
            )
            if realistic_exit_price < breakeven_floor:
                allowed, why = self._loss_exit_allowed(token_id)
                if is_urgent and allowed:
                    self._loss_forced_count += 1
                    log.warning(
                        "loss_liquidation_forced",
                        market=market_name,
                        tier=tier,
                        age_sec=round(age_sec, 0),
                        avg_entry=round(inv.avg_entry_price, 4),
                        realistic_exit_price=round(realistic_exit_price, 4),
                        breakeven_floor=round(breakeven_floor, 4),
                        loss_cents=round(loss_cents, 2),
                        reason=why,
                    )
                    # Fall through to execution — forced exit
                else:
                    log.info(
                        "liquidation_skipped_loss_vs_entry",
                        market=market_name,
                        tier=tier,
                        age_sec=round(age_sec, 0),
                        avg_entry=round(inv.avg_entry_price, 4),
                        realistic_exit_price=round(realistic_exit_price, 4),
                        breakeven_floor=round(breakeven_floor, 4),
                        sell_price=round(sell_price, 4),
                        loss_cents=round(loss_cents, 2),
                        reason="v1.0.150: loss exits forbidden outside pre-resolution / daily stop-loss",
                    )
                    continue

            # Size: sell entire position
            size_usdc = inv.net_tokens * sell_price
            if size_usdc < 1.0:
                continue  # too small to bother
            # v1.0.146 (Claude): LIVE — Polymarket rejects SELL < $5.
            # Without this check, a $1-$5 position triggers a FAK SELL
            # every liquidation cycle that the exchange rejects → endless
            # reject spam. Dust waits for resolution (settles in USDC,
            # no minimum) via the reconciliation loop.
            if not settings.paper_trading and size_usdc < settings.dust_threshold_usdc:
                log.debug(
                    "liquidation_skipped_dust_live",
                    market=market_name,
                    size_usdc=round(size_usdc, 2),
                    reason="below $5 exchange minimum — will settle on resolution",
                )
                continue

            # Check we have enough tokens (should always be true here)
            tokens_to_sell = inv.net_tokens
            if tokens_to_sell < 0.5:
                continue

            log.info(
                "liquidation_triggered",
                market=market_name,
                tier=tier,
                age_sec=round(age_sec, 0),
                net_tokens=round(inv.net_tokens, 4),
                avg_entry=round(inv.avg_entry_price, 4),
                sell_price=round(sell_price, 4),
                realistic_exit_price=round(realistic_exit_price, 4),
                market_bid=round(market_bid, 4),
                loss_cents=round(loss_cents, 2),
                size_usdc=round(size_usdc, 2),
            )

            # Cancel existing quotes for this market (so new aggressive
            # order isn't blocked by stale quotes)
            # v1.0.146 (Claude): force=True is REQUIRED here. With
            # partial_fill_no_cancel=true a partially-filled ask would stay
            # live while the FAK SELL below sells the ENTIRE position →
            # both could fill → sell more tokens than owned (naked short).
            # Force-cancel is safe: the FAK covers the whole position, so
            # no dust is created by cancelling the resting remainder.
            if token_id in self.active_quotes:
                await self._cancel_all_levels(token_id, force=True)

            # v1.0.39 FIX: in LIVE mode we must actually PLACE a sell order on
            # Polymarket. Previously _record_fill was called directly, which
            # updated local inventory/bankroll as if the position had been
            # sold — but no real SELL order ever hit the book. Result: the
            # bot believed it had liquidated, while the real position stayed
            # open on-chain and capital remained locked.
            #
            # We use order_type=FAK (Fill-And-Kill, a.k.a. IOC) so the order
            # either fills (partially or fully) immediately or is cancelled.
            # post_only=False is required because post_only orders can never
            # cross the book (they would be rejected when there is a matching
            # bid, which is exactly what we want here).
            if settings.paper_trading:
                # v1.0.81 (BUG-N30): PAPER liquidation now uses the same
                # probabilistic model as normal quotes — NOT a guaranteed
                # fill at mid (which has no buyer on the bid side).
                #
                # Root cause (found in 1h PAPER session): 13 fills, 6 closes,
                # 0 round_trips — all 6 closes were liquidations with
                # pnl_net > 0. The old PAPER branch called _record_fill
                # directly at sell_price (mid-based), bypassing the
                # paper_rejection_rate / paper_competition_rate / partial-fill
                # model that _check_fills_paper() applies to normal quotes.
                # This made PAPER P&L systematically OVERSTATED — the bot
                # "sold" at mid where no real buyer exists.
                #
                # Fix (Variant A from handoff): apply rejection probability +
                # partial-fill model + cap price to marketable (bid+0.001).
                # On rejection/partial-too-small → `continue` (position stays
                # open, retried next cycle; age_sec keeps growing because
                # open_time is only reset on position open/flip, not on
                # failed liquidation — verified in inventory_manager.py).
                #
                # BUG-N34 (v1.0.91): reuse `realistic_exit_price` computed
                # above (before loss-check) instead of re-deriving here.
                # Same formula, same value — just single source of truth.
                fillable_price = realistic_exit_price

                # BUG-N46 (v1.0.105): URGENT tier = "вийти за будь-яку ціну".
                # Previously URGENT went through the SAME probabilistic model
                # as normal quotes (paper_rejection_rate 27%, no_taker 20%,
                # partial fill 40-75%). Result: position dragged 10-30+ min,
                # fillable_price kept dropping with market, realized loss grew.
                # User: "entry 0.3311 → real exit 0.3210, P&L -1.01¢".
                # Fix: URGENT bypasses rejection/partial model entirely.
                # Full fill at fillable_price (realistic_exit_price).
                # This matches LIVE behavior: FAK/IOC order either fills
                # immediately against available depth or is cancelled —
                # but URGENT means we accept the price NOW, not wait.
                # v1.0.150: PROFIT_SNIPER joins the deterministic branch —
                # it sells INTO the resting best bid (real liquidity), so a
                # FAK there fills against available depth just like URGENT.
                if tier in ("URGENT", "PROFIT_SNIPER"):
                    tokens_filled = tokens_to_sell  # full fill
                    actual_size_usdc = tokens_filled * fillable_price
                    if actual_size_usdc < 1.0:
                        continue  # too small after all — skip

                    await self._record_fill(
                        token_id, "SELL", fillable_price, actual_size_usdc, market_name,
                        level=99,  # level 99 = liquidation
                        mid_at_fill=book.mid,
                        is_liquidation=True,
                        exit_path=tier,
                    )
                    self._liquidation_count += 1
                    if tier == "PROFIT_SNIPER":
                        self._profit_take_count += 1
                    log.info(
                        "liquidation_paper_filled_urgent",
                        market=market_name,
                        tier=tier,
                        sell_price=round(sell_price, 4),
                        fillable_price=round(fillable_price, 4),
                        fill_pct=1.0,
                        size_usdc=round(actual_size_usdc, 2),
                        age_sec=round(age_sec, 0),
                        reason=f"{tier}: full fill, bypass rejection/partial model",
                    )
                else:
                    # Non-URGENT (AGGRESSIVE/CRITICAL): keep probabilistic
                    # model — these tiers can wait for better fill conditions.
                    if random.random() < settings.paper_rejection_rate:
                        log.debug(
                            "liquidation_paper_rejected",
                            market=market_name,
                            tier=tier,
                            sell_price=round(sell_price, 4),
                            fillable_price=round(fillable_price, 4),
                            rejection_rate=settings.paper_rejection_rate,
                        )
                        continue  # retry next cycle (age keeps growing)

                    # Partial fill model (Polymarket depth-limited)
                    partial_roll = random.random()
                    if partial_roll < 0.20:
                        # No fill at all this cycle (FAK found no taker)
                        log.debug(
                            "liquidation_paper_no_taker",
                            market=market_name,
                            tier=tier,
                            fillable_price=round(fillable_price, 4),
                        )
                        continue
                    fill_pct = (
                        random.uniform(0.40, 0.75) if partial_roll < 0.60
                        else random.uniform(0.85, 1.0)
                    )
                    # v1.0.82 (BUG-N31): size MUST be computed from tokens, not
                    # from size_usdc (which was derived from sell_price, not
                    # fillable_price). The previous v1.0.81 code did:
                    #     actual_size_usdc = size_usdc * fill_pct
                    # which, when divided by fillable_price in on_fill(), gave
                    #     tokens_computed = net_tokens * (sell_price / fillable_price) * fill_pct
                    # Since sell_price > fillable_price almost always (mid > bid),
                    # tokens_computed > net_tokens → oversell → phantom short +
                    # open_time reset (the very thing BUG-N30 was meant to fix).
                    # Fix: compute tokens first from the source of truth
                    # (tokens_to_sell = inv.net_tokens), then derive USD size
                    # from the execution price (fillable_price).
                    tokens_filled = tokens_to_sell * fill_pct
                    actual_size_usdc = tokens_filled * fillable_price
                    if actual_size_usdc < 1.0:
                        continue  # too small after partial — wait for full attempt

                    await self._record_fill(
                        token_id, "SELL", fillable_price, actual_size_usdc, market_name,
                        level=99,  # level 99 = liquidation
                        mid_at_fill=book.mid,
                        is_liquidation=True,
                        exit_path=tier,
                    )
                    self._liquidation_count += 1
                    log.info(
                        "liquidation_paper_filled",
                        market=market_name,
                        tier=tier,
                        sell_price=round(sell_price, 4),
                        fillable_price=round(fillable_price, 4),
                        fill_pct=round(fill_pct, 3),
                        size_usdc=round(actual_size_usdc, 2),
                        age_sec=round(age_sec, 0),
                    )
            else:
                # LIVE: place a real FAK sell at sell_price.
                from app.services.clob_client import OrderResult as _OR  # noqa: F401
                result = await self.clob.place_order(
                    token_id, "SELL", sell_price, size_usdc,
                    order_type="FAK", post_only=False,
                )
                if result.success:
                    # Try to read actual fill price/size from response.
                    raw = result.raw if isinstance(result.raw, dict) else {}
                    # Polymarket returns "makingAmount" / "takingAmount" or
                    # "price" / "size_matched" depending on endpoint/version.
                    actual_price = sell_price
                    if raw.get("price"):
                        try:
                            actual_price = float(raw["price"])
                        except (TypeError, ValueError):
                            actual_price = sell_price
                    actual_size = size_usdc
                    if raw.get("size_matched"):
                        try:
                            actual_size = float(raw["size_matched"])
                        except (TypeError, ValueError):
                            actual_size = size_usdc
                    elif raw.get("makingAmount"):
                        # makingAmount is in tokens; convert to USDC
                        try:
                            actual_size = float(raw["makingAmount"]) * actual_price
                        except (TypeError, ValueError):
                            actual_size = size_usdc

                    await self._record_fill(
                        token_id, "SELL", actual_price, actual_size, market_name,
                        level=99,
                        mid_at_fill=book.mid,
                        is_liquidation=True,
                        exit_path=tier,
                    )
                    self._liquidation_count += 1
                    if tier == "PROFIT_SNIPER":
                        self._profit_take_count += 1
                    log.info(
                        "liquidation_order_placed_live",
                        market=market_name,
                        tier=tier,
                        order_id=result.order_id,
                        requested_price=round(sell_price, 4),
                        realistic_exit_price=round(realistic_exit_price, 4),
                        actual_price=round(actual_price, 4),
                        requested_size_usdc=round(size_usdc, 2),
                        actual_size_usdc=round(actual_size, 2),
                        loss_cents=round(loss_cents, 2),
                    )
                else:
                    log.warning(
                        "liquidation_order_failed_live",
                        market=market_name,
                        tier=tier,
                        sell_price=round(sell_price, 4),
                        size_usdc=round(size_usdc, 2),
                        error=result.error,
                        reason="FAK sell rejected; position remains open",
                    )

    async def _cleanup_orphaned_positions(self) -> None:
        """v1.0.50 FIX (BUG-3): clean up positions on markets no longer in books.

        When markets are replaced (via _replace_non_quotable_markets or
        manual /markets/replace), old positions may remain in
        inventory.inventories if they had open tokens. These "orphaned"
        positions:
          - Can't be liquidated (no book → no market_bid)
          - Can't hit pre-resolution exit (we don't track end_date after replace)
          - Stay forever, cluttering inventory + falsely inflating inventory_value

        This method:
          1. Finds positions where token_id NOT in self.clob.books
          2. If net_tokens == 0 (flat) → remove from inventory (just cleanup)
          3. If net_tokens != 0 (open position) → log warning, attempt to
             re-fetch book once; if still no book, mark as orphaned and
             leave (can't liquidate without market data).
        """
        orphaned_tids: list[str] = []
        for tid, inv in list(self.inventory.inventories.items()):
            if tid in self.clob.books:
                continue  # not orphaned
            if abs(inv.net_tokens) <= 0.0001:
                # Flat position on orphaned market → safe to remove
                orphaned_tids.append(tid)
                log.info(
                    "orphaned_position_removed_flat",
                    token=tid[:12],
                    market=inv.market_name[:40] if inv.market_name else "?",
                    realized_pnl=round(inv.realized_pnl, 4),
                )
            else:
                # Open position on orphaned market → can't liquidate without book
                log.warning(
                    "orphaned_position_open",
                    token=tid[:12],
                    market=inv.market_name[:40] if inv.market_name else "?",
                    net_tokens=round(inv.net_tokens, 4),
                    avg_entry=round(inv.avg_entry_price, 4),
                    realized_pnl=round(inv.realized_pnl, 4),
                    reason="market no longer in books; position will resolve at market close",
                )

        for tid in orphaned_tids:
            inv = self.inventory.inventories.pop(tid, None)
            if inv:
                # Persist the realized P&L to daily_pnl (already counted in
                # inv.realized_pnl, but we log it for audit)
                log.info(
                    "orphaned_inventory_cleaned",
                    token=tid[:12],
                    final_realized_pnl=round(inv.realized_pnl, 4),
                )
            # Also clean up pricing/risk state for this token
            self._as_calc.clear(tid)
            self._kyle.clear(tid)
            self.risk.adverse_selection.clear(tid)
            self.risk.circuit_breakers.clear_token(tid)
            # Remove from active_quotes if present (shouldn't be, but just in case)
            self.active_quotes.pop(tid, None)

    # v1.0.144: Reconcile orphaned positions (Claude Section 1).
    # Orphaned = positions on markets no longer in self.clob.books.
    # These positions:
    #   - Cannot be liquidated (no book → no market_bid)
    #   - Were NOT being checked for resolution (only _process_market did that)
    #   - Stayed forever as phantom inventory, inflating total_exposure
    # This method checks each orphaned position against Gamma API for resolution.
    # If resolved: settle the position (YES → $1/token credit, NO → $0) and remove.
    async def _reconcile_orphaned_positions(self) -> None:
        """Check orphaned positions for resolution. Settle if resolved."""
        if settings.orphaned_reconcile_interval_sec <= 0:
            return  # disabled
        for tid, inv in list(self.inventory.inventories.items()):
            # Skip non-orphaned (still in books)
            if tid in self.clob.books:
                continue
            # Skip flat positions
            if abs(inv.net_tokens) <= 0.0001:
                continue
            # v1.0.144: check resolution via Gamma API
            market_status = await self.clob.fetch_market_status(tid)
            if not market_status:
                log.debug(
                    "orphaned_reconcile_no_status",
                    token=tid[:12],
                    market=inv.market_name[:30] if inv.market_name else "?",
                )
                continue
            if not market_status.get("is_resolved"):
                # v1.0.144: log max_partial_wait warning (Claude Section 3)
                if settings.max_partial_wait_sec > 0 and inv.last_fill_time > 0:
                    age_sec = time.monotonic() - inv.last_fill_time
                    if age_sec > settings.max_partial_wait_sec:
                        position_value = abs(inv.net_tokens * inv.avg_entry_price)
                        log.warning(
                            "partial_stuck_below_minimum",
                            token=tid[:12],
                            market=inv.market_name[:30] if inv.market_name else "?",
                            age_hours=round(age_sec / 3600, 1),
                            value_usdc=round(position_value, 2),
                            reason="Cannot sell below $5 exchange minimum. "
                                   "Waiting for more fills or market resolution.",
                        )
                continue
            # v1.0.144: Market resolved — settle the position
            resolved_price = market_status.get("resolved_price", 0.0)
            # For YES token: payout = net_tokens × resolved_price (1.0 if YES won)
            # For NO token: payout = net_tokens × (1 - resolved_price) — but we only hold YES
            # Simplification: assume we hold YES (bot always trades YES outcome)
            payout = inv.net_tokens * resolved_price
            # Realize P&L: payout - cost_basis
            cost_basis = abs(inv.net_tokens * inv.avg_entry_price)
            realized_pnl = payout - cost_basis
            log.info(
                "orphaned_position_resolved",
                token=tid[:12],
                market=inv.market_name[:40] if inv.market_name else "?",
                net_tokens=round(inv.net_tokens, 4),
                resolved_price=resolved_price,
                payout=round(payout, 4),
                cost_basis=round(cost_basis, 4),
                realized_pnl=round(realized_pnl, 4),
            )
            # Credit bankroll with payout (simulates on-chain settle)
            self.inventory.bankroll += payout
            # Record the settle as a fill for P&L tracking
            await self._record_fill(
                tid, "SELL", resolved_price, cost_basis,
                inv.market_name or "orphaned",
                level=0, is_liquidation=True,
                exit_path="SETTLEMENT",
            )
            # Remove from inventory
            self.inventory.inventories.pop(tid, None)
            # Clean up pricing/risk state
            self._as_calc.clear(tid)
            self._kyle.clear(tid)
            self.risk.adverse_selection.clear(tid)
            self.risk.circuit_breakers.clear_token(tid)
            self.active_quotes.pop(tid, None)

    # ── Fill recording ────────────────────────────────────────────────────

    async def _record_fill(
        self,
        token_id: str,
        side: str,
        price: float,
        size_usdc: float,
        market_name: str,
        level: int = 1,
        mid_at_fill: float | None = None,
        is_liquidation: bool = False,
        is_hedge: bool = False,
        _skip_hedge: bool = False,
        exit_path: str = "",
    ) -> None:
        """Record a fill in inventory + DB. Triggers hedge if applicable."""
        # CRITICAL: Balance/short checks for hedge fills too
        # Hedge fills bypass the quote-placement checks (they come from _attempt_active_hedge)
        # but still must respect balance and short limits
        if is_hedge:
            inv_check = self.inventory.get_inventory(token_id)
            if side == "BUY":
                # Hedge BUY: check bankroll has enough cash
                if self.inventory.bankroll < size_usdc:
                    log.warning(
                        "hedge_fill_skipped_insufficient_balance",
                        market=market_name[:30],
                        side=side,
                        size_usdc=round(size_usdc, 2),
                        bankroll=round(self.inventory.bankroll, 2),
                    )
                    return
            elif side == "SELL":
                # Hedge SELL: check we have tokens to sell (no shorting allowed)
                tokens_to_sell = size_usdc / max(price, 0.001)
                if inv_check.net_tokens < tokens_to_sell:
                    log.warning(
                        "hedge_fill_skipped_no_tokens",
                        market=market_name[:30],
                        side=side,
                        net_tokens=round(inv_check.net_tokens, 4),
                        tokens_to_sell=round(tokens_to_sell, 4),
                        reason="insufficient tokens for hedge (LIVE API would reject)",
                    )
                    return

        realized = self.inventory.on_fill(token_id, side, price, size_usdc, market_name)

        # Costs
        # v1.0.73 (BUG-N24): Gas separated from profit.
        # v1.0.152: fee/gas split. Taker fills (FAK exits: profit sniper,
        # liquidations, NO-hedge — all arrive with is_liquidation=True) pay
        # the taker fee on fee-bearing markets; maker fills pay zero fee on
        # Limitless. Gas applies to every fill. fees_usdc keeps the TOTAL
        # for backwards compat; the split is persisted separately.
        gas_cost = settings.paper_gas_cost_usdc if settings.paper_trading else settings.live_gas_cost_usdc
        is_taker = bool(is_liquidation)
        # v1.0.153: exit-path split for the Капчур% metric (Path A = maker
        # ask-fill, free; taker = FAK exits: sniper/liquidation/hedge)
        if side == "SELL":
            if is_taker:
                self._exit_taker_count += 1
            else:
                self._exit_maker_count += 1
        elif side == "BUY" and not is_hedge:
            # v1.0.155: schedule the +60s adverse probe for this entry
            self._record_adverse_probe(token_id, price)
        taker_fee = (
            size_usdc / max(price, 0.001) * self._taker_fee_per_token(token_id, price)
            if is_taker
            else 0.0
        )
        fees_usdc = gas_cost + taker_fee
        realized_net = realized - fees_usdc  # kept for backwards-compat logging
        self.inventory.bankroll -= fees_usdc  # costs deducted from cash

        self._fill_count += 1
        FILLS_TOTAL.labels(side=side, mode="LIVE" if not settings.paper_trading else "PAPER").inc()

        if mid_at_fill is None:
            mid_at_fill = price

        log.info(
            "fill",
            market=market_name[:50],
            side=side,
            price=round(price, 4),
            size_usdc=round(size_usdc, 2),
            pnl_net=round(realized_net, 4),
            pnl_gross=round(realized, 4),
            fees=round(fees_usdc, 4),
            inv_after=round(self.inventory.get_inventory(token_id).net_tokens, 4),
            level=level,
            mode="LIVE" if not settings.paper_trading else "PAPER",
            liquidation=is_liquidation,
            hedge=is_hedge,
        )

        # Persist to DB
        # v1.0.73: pnl_usdc = gross realized (no gas), fees_usdc = gas (separate)
        # v1.0.152: + fee/gas split and taker flag
        await self._persist_trade(
            token_id, side, price, size_usdc, realized, fees_usdc, market_name,
            level, is_hedge,
            fee_usdc=taker_fee, gas_usdc=gas_cost, is_taker=is_taker,
            exit_path=exit_path,
        )

        # Update adverse selection tracking
        self.risk.on_fill(token_id, side, price, mid_at_fill)

        # Trigger hedge (Yes/No pair) — only on real fills, not on hedge fills
        if (
            settings.hedging_enabled
            and settings.hedging_active_enabled
            and not _skip_hedge
            and not is_liquidation
        ):
            try:
                await self._attempt_active_hedge(token_id, side, size_usdc, market_name, price)
            except Exception as e:
                log.debug("hedge_failed", error=str(e))

    async def _attempt_active_hedge(
        self,
        filled_token_id: str,
        filled_side: str,
        filled_size_usdc: float,
        market_name: str,
        filled_price: float,
    ) -> None:
        """Hedge by trading the paired Yes/No token (YES+NO=$1, risk-free).

        When we BUY YES at price P_yes, we can also BUY NO at P_no.
        If P_yes + P_no < 1.0, the position is risk-free (one side always pays $1).
        Same for SELL: SELL YES + SELL NO when P_yes_bid + P_no_bid > 1.0.
        """
        paired_token = self._get_paired_token(filled_token_id)
        if not paired_token:
            log.debug(
                "hedge_skipped_no_pair",
                filled_market=market_name[:30],
                filled_side=filled_side,
                reason="no paired Yes/No token found",
            )
            return
        paired_book = self.clob.books.get(paired_token)
        if not paired_book or not paired_book.bids or not paired_book.asks:
            log.debug(
                "hedge_skipped_no_book",
                filled_market=market_name[:30],
                reason="paired token has no order book",
            )
            return
        paired_info = self.clob.markets.get(paired_token)
        paired_name = paired_info.question[:50] if paired_info else paired_token[:12]

        if filled_side == "BUY":
            hedge_side = "BUY"
            hedge_price = paired_book.best_ask + 0.003
            if hedge_price > 0.99:
                log.debug("hedge_skipped_price", reason="hedge_price > 0.99")
                return
            # Profitability check: YES_ask + NO_ask must be < $1.00
            total_cost = filled_price + paired_book.best_ask
            if total_cost >= 1.0:
                log.debug(
                    "hedge_skipped_unprofitable",
                    filled_price=round(filled_price, 4),
                    paired_ask=round(paired_book.best_ask, 4),
                    total=round(total_cost, 4),
                    reason="YES_ask + NO_ask >= $1.00 (no arbitrage)",
                )
                return
            profit_cents = (1.0 - total_cost) * 100
        else:
            hedge_side = "SELL"
            hedge_price = paired_book.best_bid - 0.003
            if hedge_price < 0.01:
                log.debug("hedge_skipped_price", reason="hedge_price < 0.01")
                return
            # Profitability check: YES_bid + NO_bid must be > $1.00
            total_revenue = filled_price + paired_book.best_bid
            if total_revenue <= 1.0:
                log.debug(
                    "hedge_skipped_unprofitable",
                    filled_price=round(filled_price, 4),
                    paired_bid=round(paired_book.best_bid, 4),
                    total=round(total_revenue, 4),
                    reason="YES_bid + NO_bid <= $1.00 (no arbitrage)",
                )
                return
            profit_cents = (total_revenue - 1.0) * 100

        hedge_size = filled_size_usdc
        if hedge_size < 1.0:
            return

        # v1.0.46 FIX (BUG-4): pre-flight check BEFORE placing the LIVE
        # hedge order. Previously the check lived inside _record_fill(),
        # which is called AFTER place_order() — meaning the real SELL
        # order was sent to Polymarket, possibly filled, and then the
        # local inventory update was silently skipped (because we had
        # no tokens to sell). Result: position moved on-chain but the
        # bot's inventory never reflected it — a silent financial leak.
        #
        # v1.0.47 NOTE: Polymarket DOES support shorting (SELL without
        # tokens creates a short with $1 collateral per contract). So
        # the API would NOT reject this order — it would execute and
        # open a short position. However, opening a short via "hedge"
        # logic is NOT a real hedge: shorting the paired token is
        # economically equivalent to going long on the original token
        # (short NO = long YES), so it doubles our risk instead of
        # neutralizing it. We therefore block it: only hedge SELL when
        # we actually own the paired token (closing an existing long).
        #
        # We check BEFORE place_order():
        #   - hedge SELL: need enough tokens on the paired market
        #     (selling without tokens would open an uncontrolled short)
        #   - hedge BUY:  need enough bankroll
        # If the check fails, we DON'T place the order at all.
        if not settings.paper_trading:
            paired_inv_check = self.inventory.get_inventory(paired_token)
            if hedge_side == "SELL":
                tokens_needed = hedge_size / max(hedge_price, 0.001)
                if paired_inv_check.net_tokens < tokens_needed:
                    log.warning(
                        "hedge_skipped_insufficient_tokens_preflight",
                        filled_market=market_name[:30],
                        paired_market=paired_name[:30],
                        hedge_side=hedge_side,
                        paired_net_tokens=round(paired_inv_check.net_tokens, 4),
                        tokens_needed=round(tokens_needed, 4),
                        reason="would open uncontrolled short (Polymarket supports it with $1 collateral, but bot policy blocks shorts via hedge)",
                    )
                    return
            else:  # hedge_side == "BUY"
                if self.inventory.bankroll < hedge_size:
                    log.warning(
                        "hedge_skipped_insufficient_balance_preflight",
                        filled_market=market_name[:30],
                        paired_market=paired_name[:30],
                        hedge_side=hedge_side,
                        hedge_size=round(hedge_size, 2),
                        bankroll=round(self.inventory.bankroll, 2),
                        reason="would send LIVE BUY with insufficient bankroll",
                    )
                    return

        self._hedge_attempts += 1

        log.info(
            "hedge_attempt",
            filled_market=market_name[:30],
            filled_side=filled_side,
            filled_price=round(filled_price, 4),
            paired_market=paired_name[:30],
            hedge_side=hedge_side,
            hedge_price=round(hedge_price, 4),
            profit_cents=round(profit_cents, 2),
            size_usdc=round(hedge_size, 2),
        )

        if settings.paper_trading:
            if random.random() < 0.80:
                actual_price = hedge_price + random.uniform(-0.0005, 0.0005)
                actual_price = max(0.01, min(0.99, actual_price))
                await self._record_fill(
                    paired_token, hedge_side, actual_price, hedge_size, paired_name,
                    _skip_hedge=True, is_hedge=True,
                )
                self._hedge_fills += 1
                log.info(
                    "hedge_filled",
                    paired_market=paired_name[:40],
                    side=hedge_side,
                    price=round(actual_price, 4),
                    size_usdc=round(hedge_size, 2),
                    profit_cents=round(profit_cents, 2),
                )
            else:
                log.debug("hedge_not_filled", reason="20% paper rejection")
        else:
            # v1.0.39 FIX: LIVE hedging was completely missing — the `else`
            # branch simply did not exist. Now we place a real order on the
            # paired token via FAK so the hedge actually executes on-chain.
            # post_only=False because we want immediate fill (this is an
            # arbitrage, not market making).
            result = await self.clob.place_order(
                paired_token, hedge_side, hedge_price, hedge_size,
                order_type="FAK", post_only=False,
            )
            if result.success:
                raw = result.raw if isinstance(result.raw, dict) else {}
                actual_price = hedge_price
                if raw.get("price"):
                    try:
                        actual_price = float(raw["price"])
                    except (TypeError, ValueError):
                        pass
                actual_size = hedge_size
                if raw.get("size_matched"):
                    try:
                        actual_size = float(raw["size_matched"])
                    except (TypeError, ValueError):
                        pass
                # v1.0.46 (BUG-4): the _record_fill pre-check (is_hedge branch)
                # is now redundant because we did the pre-flight check above.
                # But we keep it as a defensive second guard in case the
                # inventory changed between the pre-flight and now (e.g.
                # another concurrent fill). If _record_fill skips, we log
                # a CRITICAL warning because the LIVE order already went
                # through — the position is real but untracked.
                tokens_to_sell_check = actual_size / max(actual_price, 0.001)
                paired_inv_now = self.inventory.get_inventory(paired_token)
                if hedge_side == "SELL" and paired_inv_now.net_tokens < tokens_to_sell_check:
                    log.critical(
                        "hedge_filled_but_untrackable_live",
                        paired_market=paired_name[:40],
                        side=hedge_side,
                        order_id=result.order_id,
                        actual_size=round(actual_size, 4),
                        actual_price=round(actual_price, 4),
                        paired_net_tokens=round(paired_inv_now.net_tokens, 4),
                        reason="LIVE SELL executed on-chain but inventory cannot be updated — MANUAL RECONCILIATION NEEDED",
                    )
                    # Don't call _record_fill (it would skip anyway), but
                    # still count as a hedge attempt so the fill rate metric
                    # reflects the failure.
                    return
                await self._record_fill(
                    paired_token, hedge_side, actual_price, actual_size,
                    paired_name,
                    _skip_hedge=True, is_hedge=True,
                )
                self._hedge_fills += 1
                log.info(
                    "hedge_filled_live",
                    paired_market=paired_name[:40],
                    side=hedge_side,
                    order_id=result.order_id,
                    price=round(actual_price, 4),
                    size_usdc=round(actual_size, 2),
                    profit_cents=round(profit_cents, 2),
                )
            else:
                log.warning(
                    "hedge_failed_live",
                    paired_market=paired_name[:40],
                    side=hedge_side,
                    hedge_price=round(hedge_price, 4),
                    size_usdc=round(hedge_size, 2),
                    error=result.error,
                )

    def _build_hedging_pairs(self) -> None:
        """Link Yes and No tokens sharing the same condition_id.

        Also supports fallback pairing by identical question text when
        condition_id is missing (some markets on Polymarket don't expose it
        via the events API).
        """
        self._condition_pairs.clear()
        by_condition: dict[str, list[str]] = {}
        by_question: dict[str, list[str]] = {}

        for tid, info in self.clob.markets.items():
            cid = info.condition_id
            if cid:
                by_condition.setdefault(cid, []).append(tid)
            # Fallback: group by question text (Yes/No outcomes share question)
            if info.question:
                by_question.setdefault(info.question, []).append(tid)

        # Primary: by condition_id
        for cid, tokens in by_condition.items():
            if len(tokens) == 2:
                self._register_pair(cid, tokens)

        # Fallback: by question text (only add if not already paired via condition_id)
        already_paired = set()
        for pair in self._condition_pairs.values():
            already_paired.add(pair["yes"])
            already_paired.add(pair["no"])

        for q, tokens in by_question.items():
            if len(tokens) == 2 and tokens[0] not in already_paired:
                # Use question hash as key to avoid collisions
                key = f"q:{hash(q)}"
                self._register_pair(key, tokens)

        if self._condition_pairs:
            log.info(
                "hedging_pairs_built",
                pairs=len(self._condition_pairs),
                by_condition=sum(1 for k in self._condition_pairs if not k.startswith("q:")),
                by_question=sum(1 for k in self._condition_pairs if k.startswith("q:")),
            )

    def _register_pair(self, key: str, tokens: list[str]) -> None:
        """Register a Yes/No pair, determining which is Yes by outcome field."""
        info0 = self.clob.markets.get(tokens[0])
        info1 = self.clob.markets.get(tokens[1])
        if not info0 or not info1:
            return
        # Determine Yes/No by outcome field (case-insensitive)
        out0 = (info0.outcome or "").lower().strip()
        out1 = (info1.outcome or "").lower().strip()
        if out0 == "yes" and out1 == "no":
            self._condition_pairs[key] = {"yes": tokens[0], "no": tokens[1]}
        elif out0 == "no" and out1 == "yes":
            self._condition_pairs[key] = {"yes": tokens[1], "no": tokens[0]}
        else:
            # Fallback: token with higher mid price = "Yes" (probability of event)
            if info0 and info1:
                yes_token = tokens[0] if self.clob.books.get(tokens[0]) and self.clob.books[tokens[0]].mid > 0.5 else tokens[1]
                no_token = tokens[1] if yes_token == tokens[0] else tokens[0]
                self._condition_pairs[key] = {"yes": yes_token, "no": no_token}

    def _get_paired_token(self, token_id: str) -> str | None:
        for pair in self._condition_pairs.values():
            if pair["yes"] == token_id:
                return pair["no"]
            if pair["no"] == token_id:
                return pair["yes"]
        return None

    # ── DB persistence ────────────────────────────────────────────────────

    async def _persist_trade(
        self,
        token_id: str,
        side: str,
        price: float,
        size_usdc: float,
        pnl: float,
        fees_usdc: float,
        market_name: str,
        level: int,
        is_hedge: bool,
        fee_usdc: float = 0.0,
        gas_usdc: float = 0.0,
        is_taker: bool = False,
        exit_path: str = "",
    ) -> None:
        try:
            from app.core.db import AsyncSessionLocal

            async with AsyncSessionLocal() as db:
                t = Trade(
                    exit_path=exit_path,
                    market_id=token_id,
                    market_name=market_name,
                    condition_id=self.clob.markets.get(token_id, None).condition_id
                    if self.clob.markets.get(token_id)
                    else "",
                    side=Side.BUY if side == "BUY" else Side.SELL,
                    price=price,
                    size_usdc=size_usdc,
                    size_tokens=size_usdc / max(price, 0.001),
                    pnl_usdc=pnl,
                    fees_usdc=fees_usdc,
                    fee_usdc=fee_usdc,
                    gas_usdc=gas_usdc,
                    is_taker=1 if is_taker else 0,
                    inventory_after=self.inventory.get_inventory(token_id).net_tokens,
                    spread_cents=self._get_active_spread(token_id),
                    level=level,
                    mode=OrderMode.LIVE if not settings.paper_trading else OrderMode.PAPER,
                    is_hedge=is_hedge,
                )
                db.add(t)
                await db.commit()
        except Exception as e:
            log.debug("trade_persist_failed", error=str(e))

    def _get_active_spread(self, token_id: str) -> float | None:
        quotes = self.active_quotes.get(token_id)
        if not quotes:
            return None
        return quotes[0].spread_cents

    async def _db_cleanup_loop(self) -> None:
        """Every 10 minutes, prune old quotes + snapshots (keep last 1000 each)."""
        await asyncio.sleep(600)
        while self._running:
            try:
                from app.core.db import AsyncSessionLocal
                from sqlalchemy import text

                async with AsyncSessionLocal() as db:
                    await db.execute(
                        text(
                            "DELETE FROM mm_quotes WHERE id NOT IN "
                            "(SELECT id FROM mm_quotes ORDER BY id DESC LIMIT 1000)"
                        )
                    )
                    await db.execute(
                        text(
                            "DELETE FROM mm_snapshots WHERE id NOT IN "
                            "(SELECT id FROM mm_snapshots ORDER BY id DESC LIMIT "
                            f"{int(settings.mm_snapshot_keep_rows)})"
                        )
                    )
                    await db.execute(
                        text(
                            "DELETE FROM mm_metric_points WHERE id NOT IN "
                            "(SELECT id FROM mm_metric_points ORDER BY id DESC LIMIT 5000)"
                        )
                    )
                    await db.commit()
            except Exception as e:
                log.debug("db_cleanup_error", error=str(e))
            await asyncio.sleep(600)

    # v1.0.144: Orphaned position reconciliation loop (Claude Section 1).
    async def _reconcile_loop(self) -> None:
        """Periodically check orphaned positions for resolution."""
        interval = max(60.0, settings.orphaned_reconcile_interval_sec)
        await asyncio.sleep(interval)  # initial delay
        while self._running:
            try:
                await self._reconcile_orphaned_positions()
            except asyncio.CancelledError:
                break
            except Exception as e:
                log.warning("reconcile_loop_error", error=str(e))
            await asyncio.sleep(interval)

    # ── Status ────────────────────────────────────────────────────────────

    @property
    def status(self) -> dict:
        return {
            "cycle_count": self._cycle_count,
            "fill_count": self._fill_count,
            "round_trip_count": self._round_trip_count,
            "liquidation_count": self._liquidation_count,  # v1.0.38
            # v1.0.150: headline exit metrics
            "profit_take_count": self._profit_take_count,
            "loss_liquidation_forced_count": self._loss_forced_count,
            # v1.0.151
            "no_hedge_count": self._no_hedge_count,
            # v1.0.155: adverse-rate rotation
            "adverse_banned_now": sum(
                1 for u in self._banned_markets.values() if time.monotonic() < u
            ),
            "adverse_ban_total": self._adverse_ban_count,
            # v1.0.153: capture quality
            "capture_pct_avg": (
                round(self._sniper_taken_pct_sum / self._sniper_fired_count, 1)
                if self._sniper_fired_count > 0
                else None
            ),
            "sniper_fired_count": self._sniper_fired_count,
            "exit_maker_count": self._exit_maker_count,
            "exit_taker_count": self._exit_taker_count,
            "ask_fill_share_pct": (
                round(
                    self._exit_maker_count
                    / (self._exit_maker_count + self._exit_taker_count)
                    * 100.0,
                    1,
                )
                if (self._exit_maker_count + self._exit_taker_count) > 0
                else None
            ),
            "active_quotes": sum(len(qs) for qs in self.active_quotes.values()),
            "pending_live_orders": len(self._pending_orders) if not settings.paper_trading else 0,
            "mode": "LIVE" if not settings.paper_trading else "PAPER",
            "trading_paused": self._trading_paused,
            "halted": self.inventory.halted,
            "halt_reason": self.inventory.halt_reason,
            "hedge_attempts": self._hedge_attempts,
            "hedge_fills": self._hedge_fills,
            "hedge_fill_rate_pct": round(
                self._hedge_fills / max(self._hedge_attempts, 1) * 100, 1
            ),
            "adverse_global_cooldown_sec": round(
                self.risk.adverse_selection.global_cooldown_remaining(), 1
            ),
            "quotes_detail": [
                {
                    "token_id": q.token_id[:12],
                    "market_name": next(
                        (i.question[:30] for i in self.clob.markets.values()
                         if i.token_id == q.token_id),
                        q.token_id[:12]
                    ),
                    "level": q.level,
                    "bid": round(q.bid_price, 4) if q.bid_price is not None else None,
                    "ask": round(q.ask_price, 4) if q.ask_price is not None else None,
                    "mid": round(q.mid_at_place, 4),
                    "reservation": round(q.reservation_price, 4),
                    "optimal_spread_cents": round(q.spread_cents, 2),
                    "our_spread_cents": round(
                        (q.ask_price - q.bid_price) * 100, 2
                    ) if q.bid_price is not None and q.ask_price is not None else None,
                    # v1.0.99 (restored v1.0.110): full transparency fields
                    "market_bid": (
                        round(self.clob.books[q.token_id].best_bid, 4)
                        if q.token_id in self.clob.books and self.clob.books[q.token_id].best_bid > 0
                        else None
                    ),
                    "market_ask": (
                        round(self.clob.books[q.token_id].best_ask, 4)
                        if q.token_id in self.clob.books and self.clob.books[q.token_id].best_ask < 1
                        else None
                    ),
                    "avg_entry_price": (
                        round(self.inventory.get_inventory(q.token_id).avg_entry_price, 4)
                        if self.inventory.get_inventory(q.token_id).net_tokens != 0
                        else None
                    ),
                    "net_tokens": round(
                        self.inventory.get_inventory(q.token_id).net_tokens, 2
                    ),
                    "realistic_exit_price": None,  # computed in frontend
                    "realistic_profit_cents": None,  # computed in frontend
                    "bid_filled": q.bid_filled,
                    "ask_filled": q.ask_filled,
                    # v1.0.151: dashboard markers
                    "bid_mom_blocked": q.token_id in self._momentum_bid_blocked,
                    "ask_mom_blocked": q.token_id in self._momentum_ask_blocked,
                    "hedged": q.token_id in self._hedged_positions,
                    "age_sec": round(time.monotonic() - q.placed_at, 1),
                }
                for qs in self.active_quotes.values()
                for q in qs
            ],
        }
