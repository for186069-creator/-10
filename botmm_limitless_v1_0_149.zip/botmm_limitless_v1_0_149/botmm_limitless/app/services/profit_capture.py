"""PROFIT CAPTURE — THE HARDCODED EXIT LADDER (Jiji's ethalon, v1.0.153).

Максимізація очікуваного профіту: свіжа позиція чекає повний спред
(безкоштовний maker ask-філ), снайпер забирає достроково ТІЛЬКИ якщо
бід дає майже стільки ж; з віком позиції планка плавно спадає, але
ніколи не нижче беззбитковості (флор v1.0.150 діє окремо й завжди).

За зразком spread_invariant.py: константи module-level, НЕ в config,
НЕ в .env, незмінні в рантаймі. Жодне налаштування не може їх посунути.

Досяжний максимум позиції = hardcode_ask − entry − taker_fee_на_виході_0
  (ask-філ = maker = безкоштовний; сама формула НЕ включає fee).
Снайпер-вихід дає: best_bid − entry − taker_fee (платний).
"""
from __future__ import annotations

SNIPER_FRESH_PCT: float = 0.70    # свіжа позиція: бід має дати ≥70% макс
SNIPER_FLOOR_PCT: float = 0.0     # планка в кінці розпаду (беззбиток+fee
                                  #   і так гарантується флором v1.0.150)
SNIPER_DECAY_START_SEC: float = 300.0    # перші 5 хв — повні 70%
# v1.0.157: 1800 → 3600. Емпірика вікна C (13 позицій, daily-крипта):
# бід доростає до 70% від досяжного максимуму медіанно за 101 хв, тож
# 30-хвилинне вікно розпаду майже ніколи не встигало спрацювати — планка
# сповзала до нуля і снайпер бив дешево (3-16% від максимуму).
# Симуляція на тих самих 13 позиціях:
#   END=1800: 11 виходів, медіана 41.1%, Σ 47.6¢
#   END=3600: 11 виходів, медіана 46.3%, Σ 59.8¢  ← обрано
#   END=5400: 10 виходів (застрягло 3), медіана 49.7%, Σ 56.1¢ — сумарний
#             профіт ПАДАЄ, бо один вихід втрачено: це і є межа.
SNIPER_DECAY_END_SEC: float = 3600.0     # до 60 хв планка лінійно → 0%
# Між START і END: лінійна інтерполяція 70% → 0%.
# Після END: снайпер бере будь-який профіт ≥ беззбиток+fee (як раніше).

MIN_ABS_PROFIT_CENTS: float = 0.3  # абсолютна підлога: ніколи не стріляти
                                   # заради < 0.3¢ (комісійний шум)


def sniper_threshold_cents(achievable_max_cents: float, age_sec: float) -> float:
    """Повертає мінімальний профіт (¢), за якого снайпер стріляє зараз."""
    if age_sec <= SNIPER_DECAY_START_SEC:
        pct = SNIPER_FRESH_PCT
    elif age_sec >= SNIPER_DECAY_END_SEC:
        pct = SNIPER_FLOOR_PCT
    else:
        t = (age_sec - SNIPER_DECAY_START_SEC) / (
            SNIPER_DECAY_END_SEC - SNIPER_DECAY_START_SEC
        )
        pct = SNIPER_FRESH_PCT * (1.0 - t)
    return max(achievable_max_cents * pct, MIN_ABS_PROFIT_CENTS)
