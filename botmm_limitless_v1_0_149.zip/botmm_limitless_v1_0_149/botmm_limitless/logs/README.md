# botmm log directory — the bot writes logs/botmm.log here (rotated at 50MB)
