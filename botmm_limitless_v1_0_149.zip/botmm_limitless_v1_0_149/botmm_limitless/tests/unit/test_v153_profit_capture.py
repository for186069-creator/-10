"""
tests/unit/test_v153_profit_capture.py — v1.0.153 hardcoded exit ladder.

profit_capture.py is a HARDCODED module (constants module-level, not in
config): a fresh position demands ≥70% of the achievable max from the bid,
the bar decays linearly to 0% between 5 and 30 minutes, absolute floor
0.3¢. Plus GLM P0/P1 fixes: VERSION consistency and the restored-bankroll
first-principles recompute.
"""
from __future__ import annotations

import json
import re
import time
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest

from app.services.profit_capture import (
    MIN_ABS_PROFIT_CENTS,
    SNIPER_DECAY_END_SEC,
    SNIPER_DECAY_START_SEC,
    SNIPER_FRESH_PCT,
    sniper_threshold_cents,
)


# ── The ladder itself ─────────────────────────────────────────────────────


def test_fresh_position_40pct_does_not_fire():
    """achievable 5.6¢, bid delivers 2.24¢ (40%) → threshold 3.92¢ → hold."""
    thr = sniper_threshold_cents(5.6, age_sec=60.0)
    assert thr == pytest.approx(5.6 * 0.70)
    assert 5.6 * 0.40 < thr, "40% of max must NOT clear the fresh 70% bar"


def test_fresh_position_75pct_fires():
    thr = sniper_threshold_cents(5.6, age_sec=60.0)
    assert 5.6 * 0.75 >= thr, "75% of max must clear the fresh 70% bar"


def test_mid_decay_interpolation():
    """v1.0.157 ladder: linear decay 70%→0% between 5 and 60 min.
    At 15 min: t=(900−300)/3300=0.1818 → 70%×0.818 = 57.3%;
    at the true midpoint (32.5 min) → 35%."""
    assert sniper_threshold_cents(10.0, age_sec=900.0) == pytest.approx(5.7273, abs=1e-3)
    midpoint = (SNIPER_DECAY_START_SEC + SNIPER_DECAY_END_SEC) / 2
    assert sniper_threshold_cents(10.0, age_sec=midpoint) == pytest.approx(3.5)


def test_decay_window_is_60_minutes():
    """The window was recalibrated 30 → 60 min (v1.0.157): the bid needs
    ~101 min (median) to reach 70% of the achievable max on daily crypto,
    so a 30-min decay collapsed the bar to zero before it could fire."""
    assert SNIPER_DECAY_END_SEC == 3600.0
    assert SNIPER_FRESH_PCT == 0.70
    # bar still live at 45 min (was long dead under the old 30-min window)
    assert sniper_threshold_cents(10.0, age_sec=2700.0) > MIN_ABS_PROFIT_CENTS


def test_after_decay_end_takes_any_profit_above_abs_floor():
    thr = sniper_threshold_cents(10.0, age_sec=SNIPER_DECAY_END_SEC + 1)
    assert thr == pytest.approx(MIN_ABS_PROFIT_CENTS)


def test_min_abs_profit_floor_holds_even_at_90pct():
    """Tiny market: achievable max 0.2¢ — even 90% of it (0.18¢) is under
    the 0.3¢ absolute floor → threshold stays 0.3¢ → no shot for noise."""
    thr = sniper_threshold_cents(0.2, age_sec=60.0)
    assert thr == pytest.approx(MIN_ABS_PROFIT_CENTS)
    assert 0.2 * 0.90 < thr


def test_constants_not_readable_from_config(monkeypatch):
    """Sabotage: no settings field may move the ladder (hardcode contract,
    same as spread_invariant)."""
    from app.core.config import settings

    for name in dir(settings):
        low = name.lower()
        if any(k in low for k in ("profit", "sniper", "capture", "decay")):
            try:
                monkeypatch.setattr(settings, name, 99999.0)
            except Exception:
                pass
    assert sniper_threshold_cents(5.6, 60.0) == pytest.approx(5.6 * SNIPER_FRESH_PCT)
    assert sniper_threshold_cents(10.0, 900.0) == pytest.approx(5.7273, abs=1e-3)
    assert sniper_threshold_cents(10.0, 999999.0) == pytest.approx(MIN_ABS_PROFIT_CENTS)


# ── GLM P0: VERSION consistency ───────────────────────────────────────────


def test_version_matches_changelog():
    root = Path(__file__).resolve().parents[2]
    version = (root / "VERSION").read_text(encoding="utf-8").strip().splitlines()[0]
    changelog_versions = []
    for p in root.glob("CHANGELOG_v*.md"):
        m = re.match(r"CHANGELOG_v(\d+\.\d+\.\d+)\.md", p.name)
        if m:
            changelog_versions.append(tuple(int(x) for x in m.group(1).split(".")))
    assert changelog_versions, "no changelogs found"
    latest = ".".join(str(x) for x in max(changelog_versions))
    assert version == latest, (
        f"VERSION ({version}) must match the latest changelog ({latest})"
    )


# ── GLM P1: bankroll recompute on restore ─────────────────────────────────


@pytest.mark.asyncio
async def test_bankroll_recomputed_on_restore(monkeypatch):
    """Restart with an open position: restored bankroll must satisfy
    bankroll + Σ(net_tokens × avg_entry) == starting_balance + Σ realized_net,
    regardless of what the (possibly stale) snapshot said."""
    from app.services.inventory_manager import InventoryManager

    inv_mgr = InventoryManager()

    state = MagicMock()
    state.bankroll = 999.0  # stale/wrong snapshot value
    state.starting_balance = 60.0
    state.daily_pnl = 0.0
    state.consecutive_losses = 0
    state.inventories_json = json.dumps({
        "tok-x": {"market_name": "M", "net_tokens": 10.0,
                  "avg_entry_price": 0.30, "realized_pnl": 0.0},
    })

    res_state = MagicMock()
    res_state.scalar_one_or_none.return_value = state
    res_sums = MagicMock()
    res_sums.one.return_value = (12.0, 1.0)  # Σ pnl_usdc, Σ fees_usdc

    db = MagicMock()
    db.execute = AsyncMock(side_effect=[res_state, res_sums])

    ok = await inv_mgr.load_state_from_db(db)
    assert ok

    open_cost = 10.0 * 0.30
    expected = 60.0 + 12.0 - 1.0 - open_cost  # 68.0
    assert inv_mgr.bankroll == pytest.approx(expected)
    # the equity invariant the fix guarantees:
    assert inv_mgr.bankroll + open_cost == pytest.approx(60.0 + 12.0 - 1.0)
