"""
tests/unit/test_v156_transparency.py — v1.0.156 transparency panels.

Pure-builder tests: positions_detail badges reflect the real protection
state; open_orders exposes every order with its fill fraction; the CSV
export has one line per trade; the shared filter predicate honours
loss_only.
"""
from __future__ import annotations

import time
from unittest.mock import MagicMock

import pytest

from app.admin.api import (
    _build_open_orders,
    _build_positions_detail,
    _trade_row_passes,
    _trades_to_csv,
)
from app.services.market_maker import ActiveQuote


def _mk_state(tmp_path, monkeypatch):
    import app.services.market_maker as mm_mod
    from app.core.config import settings
    from app.services.clob_client import MarketBook, OrderLevel, MarketInfo
    from app.services.inventory_manager import InventoryManager, Inventory
    from app.services.market_maker import MarketMaker
    from app.services.risk.risk_manager import RiskManager

    monkeypatch.setattr(mm_mod, "RUNNING_LOCK_PATH", tmp_path / "RUNNING.lock")
    monkeypatch.setattr(settings, "paper_trading", True)
    monkeypatch.setattr(settings, "pre_resolution_exit_sec", 300)

    tid = "tok-t"
    clob = MagicMock()
    clob.books = {tid: MarketBook(
        token_id=tid,
        bids=[OrderLevel(0.40, 100)],
        asks=[OrderLevel(0.44, 100)],
        last_price=0.42,
    )}
    clob.markets = {tid: MarketInfo(
        token_id=tid, condition_id="c", question="Transparency market",
        outcome="Yes", end_date_ts=time.time() + 7200, volume_24h=1000.0,
    )}
    clob.last_ws_msg_age = 1.0

    inventory = InventoryManager()
    inventory.bankroll = 60.0
    inv = Inventory(token_id=tid, market_name="Transparency market")
    inv.net_tokens = 10.0
    inv.avg_entry_price = 0.45  # underwater vs bid 0.40
    inv.open_time = time.monotonic() - 90.0
    inventory.inventories[tid] = inv

    risk = RiskManager(inventory, clob)
    mm = MarketMaker(clob, inventory, risk)
    return mm, inventory, clob, tid


def test_positions_detail_badges_reflect_protection_state(monkeypatch, tmp_path):
    mm, inventory, clob, tid = _mk_state(tmp_path, monkeypatch)
    # simulate live protection state: dd stop + momentum block + floor ask
    mm._drawdown_stopped.add(tid)
    mm._momentum_bid_blocked.add(tid)
    floor_px = round(0.45 + 0.001, 4)
    mm.active_quotes[tid] = [ActiveQuote(
        token_id=tid, level=1, bid_price=None, ask_price=floor_px,
        mid_at_place=0.42, size_usdc=3.0, reservation_price=0.42,
        spread_cents=4.0,
    )]

    rows = _build_positions_detail(mm, inventory, clob)

    assert len(rows) == 1
    r = rows[0]
    assert r["net_tokens"] == pytest.approx(10.0)
    assert r["avg_entry"] == pytest.approx(0.45)
    assert r["unrealized_cents_per_token"] == pytest.approx(-3.0)  # mid 0.42
    b = r["badges"]
    assert b["dd"] is True and b["mom"] is True and b["floor"] is True
    assert b["pre_res"] is False and b["hedged"] is False
    assert r["floor_ask"] == pytest.approx(floor_px)


def test_open_orders_expose_fill_pct(monkeypatch, tmp_path):
    mm, inventory, clob, tid = _mk_state(tmp_path, monkeypatch)
    q = ActiveQuote(
        token_id=tid, level=2, bid_price=0.4015, ask_price=0.4385,
        mid_at_place=0.42, size_usdc=2.0, reservation_price=0.42,
        spread_cents=4.0, bid_order_id="ord-bid-1",
    )
    q.bid_filled = True
    q.bid_fill_pct = 0.4  # 40% partial
    mm.active_quotes[tid] = [q]

    rows = _build_open_orders(mm, inventory, clob)

    assert len(rows) == 2  # bid row + ask row
    bid_row = next(r for r in rows if r["side"] == "BUY")
    ask_row = next(r for r in rows if r["side"] == "SELL")
    assert bid_row["fill_pct"] == pytest.approx(0.4)
    assert bid_row["order_id"] == "ord-bid-1"[:12]
    assert ask_row["fill_pct"] == pytest.approx(0.0)
    assert ask_row["type"] == "hardcode-quote"


def test_trades_csv_one_line_per_trade():
    rows = [
        {"id": i, "timestamp": "t", "market": "M", "side": "BUY", "level": 1,
         "price": 0.5, "size_usdc": 2.0, "size_tokens": 4.0, "pnl": 0.0,
         "pnl_cents_per_token": 0.0, "fee": 0.0, "gas": 0.001,
         "is_taker": False, "exit_path": "quote_bid", "mode": "PAPER"}
        for i in range(7)
    ]
    csv_text = _trades_to_csv(rows)
    lines = [ln for ln in csv_text.strip().splitlines() if ln]
    assert len(lines) == 1 + 7, "header + one line per trade"


def test_loss_only_filter_passes_only_losses():
    loss = {"market": "M", "side": "SELL", "pnl": -0.5, "is_taker": True, "exit_path": "URGENT"}
    win = {"market": "M", "side": "SELL", "pnl": 0.5, "is_taker": True, "exit_path": "PROFIT_SNIPER"}
    zero = {"market": "M", "side": "BUY", "pnl": 0.0, "is_taker": False, "exit_path": "quote_bid"}
    assert _trade_row_passes(loss, loss_only=True)
    assert not _trade_row_passes(win, loss_only=True)
    assert not _trade_row_passes(zero, loss_only=True)
    # combined with other filters
    assert _trade_row_passes(loss, loss_only=True, taker_only=True, side="SELL")
    assert not _trade_row_passes(loss, loss_only=True, exit_path="PROFIT_SNIPER")
