# CHANGELOG v1.0.100 — Bot застряг на 1 ринку, 0 нових за 13 хв

**Дата:** 2026-07-08
**Попередник:** v1.0.99 (dashboard transparency)
**Автор:** GLM (за діагностикою з логу користувача 05:36-05:50)

---

## Суть проблеми (верифіковано з логу)

### За 13 хв (05:36-05:50):
- **0 fills**
- **0 quote_placed**
- **0 arb_opportunities**
- **1458 разів** `market_skip_tight_spread` для того самого ринку "Will France reach the 2026"
- `markets_discovered candidates=2 picked=2` — лише 2 ринки проходять фільтри

### Коренева причина

`AUTO_PICK_MIN_VOLUME_24H=50000` (v1.0.89 Option B) занадто строга. З 600+ niche ринків $10-50k лише **2** мають volume ≥$50k. Решта відсіяні.

**Мій 600-ринковий аналіз (v1.0.96)** показав: niche ринки $10-50k активні (median interval 214с). Але вони мають volume **$10-50k**, не ≥$50k. Фільтр відсіював саме ті ринки, які треба.

### додатково: `auto_refill` cooldown 1800с (30 хв)

Bot шукає нові ринки раз на 30 хв. Якщо за 30 хв ринок закрився/змінився — бот застряг.

---

## Фікс

| Параметр | Було | Стало | Причина |
|---|---|---|---|
| `AUTO_PICK_MIN_VOLUME_24H` | 50000 | **15000** | Всередині niche range $10-50k з аналізу |
| `AUTO_REFILL_COOLDOWN_SEC` | 1800 (30 хв) | **300 (5 хв)** | Шукати нові ринки частіше |

### Верифікація через Gamma API

```
GET /markets?active=true&closed=false&volume_num_min=15000&limit=200
→ 100 markets returned
→ 50+ з spread >= 2.0¢ (перші 50 перевірені)
```

Тепер bot знайде достатньо ринків для quoting.

---

## Чому v1.0.89 Option B мав 50000

Тоді (до 600-ринкового аналізу) я обрав 50000 як "помірну ліквідність" між:
- 10000 (нішеві, 0% round_trips — діагноз v1.0.87)
- 300000 (ліквідні, спред 0.1-0.2¢ — фінал v1.0.87)

Але 50000 виявилось занадто стриманим — лише 2 ринки. Реальний niche range $10-50k має 600+ ринків з активністю (median 214с interval).

---

## Очікувана поведінка після фіксу

### До (v1.0.99):
- 2 ринки available, 1 skip (tight spread), 1 quoted
- 0 fills за 13 хв
- Bot loop'ить skip 1458 разів

### Після (v1.0.100):
- ~50+ ринків available (volume≥15000, spread≥2¢)
- 6 ринків picked (AUTO_PICK_COUNT=6)
- Кожні 5 хв auto_refill шукає заміни
- Більше шансів на fills + arb opportunities

---

## Чесні перевірки

| Перевірка | Результат |
|---|---|
| `.env` має MIN_VOLUME=15000 | ✅ verified |
| `.env` має REFILL_COOLDOWN=300 | ✅ verified |
| Gamma API: 100 markets volume≥15000 | ✅ verified (curl) |
| Gamma API: 50+ markets spread≥2¢ | ✅ verified |

### Що НЕ перевірено (чесно)
- Реальний PAPER-прогін з v1.0.100
- Чи bot розмістить quotes на нових ринках

---

## POSSIBLE FAILURE POINTS

1. **Auto_pick все ще може не знайти 6 ринків.** Якщо з 50+ ринків з spread≥2¢ більшість мають інші проблеми (closed, no book, etc.) — bot може взяти менше. Але краще ніж 2.
2. **Niche ринки $15-50k менш ліквідні.** Мій аналіз показав median interval 214с — ОК. Але 20% illiquid (median >20 хв). Bot може обрати такий — 0 fills.
3. **Spread ≥2¢ на niche — ОК.** Але на $15-50k ринках спред може бути wide (5-15¢) → менше fills, але більший edge.
4. **Refill кожні 5 хв — більше API calls.** Gamma API може rate-limit. Якщо 429 errors — треба збільшити cooldown.

---

## REQUIRED TESTS (після deploy)

1. **PAPER-сесія 10 хв з v1.0.100:**
   - `markets_discovered candidates=N` — має бути N > 2 (бажано 10+)
   - `quote_placed` — має з'являтись (не 0)
   - `market_skip_tight_spread` — має бути менше (не 1458 разів)
   - Дашборд: 6 ринків в Active Quotes (не 1-2)

2. **Через 5 хв:**
   - `auto_refill_throttle_passed` — має з'являтись (5 хв cooldown пройшов)
   - Нові ринки можуть з'явитись в quotes

3. **Через 30 хв:**
   - Fills мають з'явитись (на активних niche ринках)
   - `arb_opportunity_found` — може з'явитись (arb scanner працює)

---

## Файли змінені

| Файл | Зміна |
|---|---|
| `.env` | AUTO_PICK_MIN_VOLUME 50000→15000, AUTO_REFILL_COOLDOWN 1800→300 |
| `VERSION` | 1.0.99 → 1.0.100 |
| `CHANGELOG_v1.0.100.md` | цей файл |

---

## Confidence

- **Коректність фіксу: ~95%** (верифіковано Gamma API, 100 ринків available)
- **Bot знайде >2 ринків: ~95%** (50+ з spread≥2¢)
- **Fills з'являться: ~70%** (залежить від активності обраних ринків)
- **Arb opportunities: ~50%** (scanner працює, але opportunities rare)

## Признання

Це моя помилка — v1.0.89 Option B мав 50000 без верифікації. Мій 600-ринковий аналіз (v1.0.96) показав реальний niche range $10-50k, але я не оновив MIN_VOLUME. Мав би знизити одразу після аналізу. Вибачаюсь — бот марно циклював 13 хв.
