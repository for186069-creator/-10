# CHANGELOG v1.0.101 — BUG-N41 PAPER shorting + skew/requote tuning

**Дата:** 2026-07-08
**Попередник:** v1.0.100 (AUTO_PICK_MIN_VOLUME fix)
**Автор:** GLM (за скріншотом користувача ц343.png)

---

## Проблема 1: 4 ринки, не 6

**Не баг.** 2 events × 2 quotes (YES bid + NO bid) = 4. `discover_markets` фільтрує за keywords:
- keywords: "NBA,NFL,Soccer,Election,Fed,announce,July,release..."
- exclude: "bitcoin,csgo,dota,lol,valorant,temperature,weather..."

З 100 markets volume≥15000 більшість відсіюється. Залишаються 2 events (Iran announce, England reach).

**Фікс:** розширити keywords або зменшити exclude (не зроблено — потребує вашого рішення які ринки торгувати).

---

## Проблема 2: Entry 0.8143 при спреді 0.8000-0.8200

### Діагноз (верифіковано):
- Mkt Bid=0.8000, Mkt Ask=0.8200, mid=0.810
- target_bid (без skew) = 0.803
- Наш bid = 0.8080 = 0.803 + **0.5¢ skew UP**
- `INVENTORY_SKEW_MAX_CENTS=0.5` → skew UP = short position

### Entry 0.8143 = ціна SELL (не BUY)

Для short position `avg_entry_price` = ціна SELL (inventory_manager.py:274). Бот **продав по 0.8143** (дорого), тепер short, купляє по 0.808 → profit +0.6¢/токен.

**Ваше питання "чому не 0.8015?"** — Entry для short = SELL ціна, не BUY. 0.8143 = ви продали дорого. Це **нормально** (не баг).

### АЛЕ: BUG-N41 — як бот створив short?

Polymarket CTF **не дозволяє shorting YES**. LIVE rejects SELL що перевищує balance. PAPER дозволяв → phantom short positions.

Код `inventory_manager.py:266-282` (on_fill SELL гілка) не перевіряв `new_total < 0` — дозволяв net_tokens стати від'ємним.

---

## Фікс BUG-N41: PAPER shorting prevention

`inventory_manager.py` on_fill SELL гілка (рядки 268-286):

```python
# BUG-N41 (v1.0.101): prevent SHORTING in PAPER mode.
if new_total < 0 and settings.paper_trading:
    log.warning(
        "paper_sell_clamped_to_prevent_short",
        token_id=token_id[:12],
        attempted_tokens=tokens,
        net_tokens=inv.net_tokens,
        new_total_attempted=new_total,
        reason="PAPER clamped: LIVE would reject SELL exceeding balance",
    )
    tokens = inv.net_tokens  # sell only what we have
    new_total = 0
    if tokens <= 0:
        return 0.0  # nothing to sell
```

**Логіка:**
- Якщо SELL створить net_tokens < 0 в PAPER → clamp tokens = net_tokens (продати лише наявні)
- new_total = 0 (не від'ємне)
- Log warning для діагностики
- LIVE: не зачеплено (LIVE і так rejects)

---

## Фікс налаштувань: skew + requote

| Параметр | Було | Стало | Причина |
|---|---|---|---|
| `INVENTORY_SKEW_MAX_CENTS` | 0.5 | **0.2** | Менше зміщення bid (0.5¢ створював 0.808 замість 0.803) |
| `REQUOTE_THRESHOLD_CENTS` | 1.0 | **0.5** | Швидше скасування stale quotes (drift > 0.5¢ → cancel) |

### Чому це допоможе

**Skew 0.5→0.2:**
- Old: short → bid 0.808 (0.5¢ вище target)
- New: short → bid 0.805 (0.2¢ вище target)
- Менше зміщення = менше "купля дорого" ситуацій

**Requote 1.0→0.5:**
- Old: market зрухнувся на 0.9¢ → quote не скасовано (drift < 1¢)
- New: market зрухнувся на 0.6¢ → quote скасовано (drift > 0.5¢)
- Менше stale quotes = менше fill на старих цінах

---

## Чесні перевірки

| Перевірка | Результат |
|---|---|
| `py_compile inventory_manager.py` | ✅ OK |
| `.env` має SKEW_MAX=0.2, REQUOTE=0.5 | ✅ verified |
| PAPER shorting prevention в коді | ✅ рядки 268-286 |

### Що НЕ перевірено (чесно)
- Реальний PAPER-прогін з v1.0.101
- Чи `paper_sell_clamped_to_prevent_short` з'являється в логах

---

## POSSIBLE FAILURE POINTS

1. **PAPER shorting clamp може зламати існуючі short positions.** Якщо бот вже має short (з попередніх PAPER сесій) — новий SELL на цей token буде clamped. Потрібно manually закрити short через `/exit_all` або перезапустити з чистим inventory.
2. **Skew 0.2 може бути занадто малим.** При small inventory ratio skew не зсувне quotes взагалі → bot не заохочується закривати позиції. Але liquidation loop все одно працює.
3. **Requote 0.5 може скасовувати quotes занадто часто.** Кожен market tick > 0.5¢ → cancel + re-place → більше API calls. Може збільшити load.
4. **Keywords фільтр не зачеплено.** 4 ринки замість 6 — через keywords. Розширити require user decision (які ринки торгувати).

---

## REQUIRED TESTS (після deploy)

1. **PAPER-сесія з v1.0.101:**
   - `paper_sell_clamped_to_prevent_short` в логах — якщо бот намагається oversell
   - Дашборд: `net_tokens` завжди ≥ 0 (не від'ємне)
   - Skew: bid зміщення ≤ 0.2¢ (не 0.5¢)
   - Quotes скасовуються швидше (drift > 0.5¢)

2. **Перевірити Iran-подібний сценарій:**
   - Бот купив по X → SELL не може перевищити net_tokens
   - Entry = BUY ціна (для long), не SELL (для short — більше не створюється)

3. **Перевірити к-сть ринків:**
   - Якщо треба 6 — розширити keywords (окремим рішенням)

---

## Файли змінені

| Файл | Зміна |
|---|---|
| `app/services/inventory_manager.py` | +PAPER shorting prevention (рядки 268-286) |
| `.env` | SKEW_MAX 0.5→0.2, REQUOTE 1.0→0.5 |
| `VERSION` | 1.0.100 → 1.0.101 |
| `CHANGELOG_v1.0.101.md` | цей файл |

---

## Confidence

- **BUG-N41 фікс: ~95%** (логіка прозора, py_compile OK)
- **PAPER коротить більше не буде: 100%** (clamp в on_fill)
- **Skew/requote tuning: ~85%** (менше зміщення, але може потребувати further tuning)
- **Keywords фікс: НЕ зроблено** (потребує вашого рішення)

## Признання

Ваше око зловило 2 речі одразу:
1. Entry 0.8143 — я пояснив що це SELL ціна для short (не баг сам по собі)
2. АЛЕ сам short — баг PAPER (LIVE не дозволить). Без вашого скріншота не помітив би.

Також 4 ринки замість 6 — через keywords фільтр, який я не зачепив у v1.0.100. Мав би перевірити keywords коли робив MIN_VOLUME фікс.
