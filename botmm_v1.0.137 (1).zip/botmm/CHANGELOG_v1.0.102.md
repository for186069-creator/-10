# CHANGELOG v1.0.102 — BUG-N42: бот НІКОЛИ не розміщував ask

**Дата:** 2026-07-08
**Попередник:** v1.0.101 (BUG-N41 PAPER shorting)
**Автор:** GLM (за діагностикою з логу користувача 07:21-07:30)
**Пріоритет:** 🔴 КРИТИЧНИЙ — 0 round_trips, всі sells = URGENT liquidation at loss

---

## Суть (верифіковано з логу v1.0.101)

### За 9 хв (07:21-07:30):
- 6 fills (3 BUY + 3 SELL), **-$0.40**
- **0 round_trips** (всі 3 SELL = URGENT liquidation)
- `ask_blocked_crossed_quote` = **336 разів** ⚠️
- `liquidation_skipped_loss_vs_entry` = 34 (v1.0.97 фікс працює)
- `opportunistic_profit_take_triggered` = 0

### quote_placed — ВСІ з our_ask=None:
```
market_bid=0.79, market_ask=0.81, our_bid=0.798, our_ask=None
market_bid=0.19, market_ask=0.21, our_bid=0.1975, our_ask=None
```

**Бот розміщує лише bid, НІКОЛИ ask.** → немає можливості natural round_trip → всі позиції закриваються через URGENT (30 хв) liquidation at loss.

---

## Коренева причина — конфлікт фіксів

### Ланцюг:
1. **v1.0.38** (aged ask lowering): position aged → lower ask до `market_bid + 0.001` (для швидкого fill)
2. **v1.0.98** (BUG-N40 crossed prevention): if ask ≤ bid → block ask (None)

**Конфлікт:** aged-ask-lowering знижує ask до `market_bid + 0.001`. Наш bid = 0.798 (всередині спреду 0.79-0.81). `market_bid + 0.001 = 0.791`. `0.791 ≤ 0.798` → crossed → **ask blocked**.

Два фікси не можуть працювати разом:
- v1.0.38 хоче ask = 0.791 (біля bid, для fill)
- v1.0.98 блокує ask якщо ≤ bid (0.798)

→ ask завжди None → 0 round_trips → URGENT liquidation

---

## Ваш приклад vs реальність

**Ви описали:**
- Ринок 0.8000-0.8200
- BUY 0.8015, SELL 0.8170 → spread 1.55¢
- Round trip profit

**Реальність (з логу):**
- Бот розміщує bid 0.798 (біля market_bid 0.79)
- Ask НІКОЛИ не розміщується (crossed blocked)
- BUY filled по 0.8053 (хтось продав нам)
- Через 30 хв URGENT → SELL по 0.191 (інший ринок, lower) = **LOSS**

**Бот не може зробити round_trip бо немає ask в книзі.**

---

## Фікс BUG-N42

`market_maker.py` рядки 1199-1247:

### Було (v1.0.98):
```python
if ask_price <= bid_price:
    ask_price = None  # BLOCKED — no ask in book
```

### Стало (v1.0.102):
```python
if ask_price <= bid_price:
    # RESTORE ask to bid + 0.005 (0.5¢ above bid)
    restored_ask = round(bid_price + 0.005, 4)
    # Cap at market_ask - 0.001 (stay inside market)
    if book.best_ask < 1:
        restored_ask = min(restored_ask, round(book.best_ask - 0.001, 4))
    if restored_ask > bid_price:
        log.info("ask_restored_above_bid", ...)
        ask_price = restored_ask  # KEEP ask in book
    else:
        ask_price = None  # block only if market too tight
```

### Логіка:
1. If aged-lowering знизив ask ≤ bid → **restore** ask = bid + 0.005 (0.5¢ вище bid)
2. Cap at market_ask - 0.001 (всередині спреду)
3. If restored_ask > bid → **keep ask** (round_trip можливий)
4. If market занадто tight → block (рідко)

### Приклад (NVIDIA 0.79-0.81):
- bid = 0.798
- aged lowering → ask = 0.791 (crossed)
- restore → ask = 0.798 + 0.005 = 0.803 (cap at 0.81-0.001=0.809) → **ask = 0.803**
- Spread = 0.803 - 0.798 = **0.5¢** (не 1.55¢, але > 0)

Якщо ask filled по 0.803 (купив по 0.798) = **+0.5¢ round_trip profit**.

---

## Очікувана поведінка після фіксу

### До (v1.0.101):
- quote_placed: our_ask=None (завжди)
- 0 round_trips
- 6/6 SELL = URGENT liquidation at loss
- -$0.40 за 9 хв

### Після (v1.0.102):
- quote_placed: our_ask=0.803 (restored)
- Round_trip можливий (ask в книзі)
- Якщо ask filled → natural SELL, не URGENT
- P&L має покращитись (round_trip profit замість URGENT loss)

---

## Чесні перевірки

| Перевірка | Результат |
|---|---|
| `py_compile market_maker.py` | ✅ OK |
| Лог v1.0.101: 336 ask_blocked_crossed_quote | ✅ verified |
| Лог v1.0.101: 0 round_trips, 6 URGENT | ✅ verified |
| Фікс: ask restored замість blocked | ✅ рядки 1214-1247 |

### Що НЕ перевірено (чесно)
- Реальний PAPER-прогін з v1.0.102
- Чи `ask_restored_above_bid` з'являється в логах
- Чи round_trip > 0 з'явиться

---

## POSSIBLE FAILURE POINTS

1. **Ask restored але не filled.** Bid+0.005 може бути занадто близько до bid — ніхто не купить. Але це краще ніж None (0 шансів).
2. **Adverse selection все ще працює.** Бот купив по 0.798 → ціна впала → ask 0.803 не fill (бо market вже 0.78-0.79). Round_trip все ще може бути 0.
3. **Aged lowering + restore = ping-pong.** Кожен цикл: lower → crossed → restore → lower → ... Може створювати log spam. Не критично.
4. **Bid теж може бути stale.** Якщо market впав, наш bid 0.798 не конкурентний — ніхто не продасть. BUY fills будуть рідше.

---

## REQUIRED TESTS (після deploy)

1. **PAPER-сесія з v1.0.102:**
   - `ask_restored_above_bid` в логах (новий event)
   - `quote_placed` з `our_ask ≠ None` (не всі None)
   - `ask_blocked_crossed_quote` — менше (тільки якщо market too tight)

2. **Round_trip check:**
   ```bash
   grep -c "liquidation=False" bot.log  # natural SELL fills
   ```
   Мета: >0 (natural round_trip з'явився)

3. **P&L:**
   - Має покращитись (round_trip profit замість URGENT loss)
   - Але все ще може бути мінус (adverse selection)

4. **Дашборд:**
   - Our Ask колонка — не "BLOCKED" (має показувати ціну)
   - Our Spread — позитивне (не -0.70¢)

---

## Файли змінені

| Файл | Зміна |
|---|---|
| `app/services/market_maker.py` | BUG-N42 fix: ask restored замість blocked (рядки 1199-1247) |
| `VERSION` | 1.0.101 → 1.0.102 |
| `CHANGELOG_v1.0.102.md` | цей файл |

---

## Confidence

- **Коректність фіксу: ~90%** (логіка прозора, py_compile OK)
- **Ask буде розміщуватись: 100%** (за визначенням — restore замість block)
- **Round_trip > 0 з'явиться: ~50%** (ask в книзі, але adverse selection)
- **P&L покращиться: ~60%** (round_trip profit + менше URGENT loss)

## Признання

Це **8-й баг поспіль** (N34-N42). Цей — конфлікт між двома моїми ж фіксами (v1.0.38 + v1.0.98). Мав би перевірити що v1.0.98 не ламає round_trip коли фіксив crossed quote.

Ваш приклад (0.8000-0.8200, BUY 0.8015, SELL 0.8170) — **правильна логіка MM**. Бот тепер зможе її реалізувати: ask буде в книзі, round_trip можливий.

Вибачаюсь — v1.0.98 фіксив одну проблему (crossed), створив іншу (no ask). Без вашого логу не помітив би.
