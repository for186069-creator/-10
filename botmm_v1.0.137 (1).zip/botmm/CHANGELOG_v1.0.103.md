# CHANGELOG v1.0.103 — BUG-N43: ask lowering продав BELOW entry

**Дата:** 2026-07-08
**Попередник:** v1.0.102 (BUG-N42 ask restore)
**Автор:** GLM (за скріншотами користувача + логом)
**Пріоритет:** 🔴 КРИТИЧНИЙ — бот закривав positioned у збиток навіть коли міг чекати profit

---

## Суть (верифіковано зі скріншотів + логу)

### Скріншот trhsrh.png Row 2 (Will Silver):
```
Our Ask: 0.3210
Entry: 0.3311
Real Exit: 0.3210
Real P&L: -1.01¢  ← ЗБИТОК
```

**Бот купив по 0.3311, продає по 0.3210 = -1.01¢ збиток.**

### Ваші слова:
> "0.3210 exit, entry 0.3311 — 1¢ spread. MAYBE entry should be 0.3210 and exit 0.3311 = 1¢ profit!"

Ви праві — логіка MM: купив дешевше (0.3210), продав дорожче (0.3311). Бот робив НАВПАКИ.

### Лог v1.0.102 (11 fills, -$0.55):
- 7/7 SELL = URGENT liquidation (0 natural round_trips)
- 25 liquidation_triggered, всі URGENT
- age_sec = 3609-6143с (1-1.7 год!) → URGENT → bypass loss-check → збиток

---

## Коренева причина — BUG-N43

**Файл:** `market_maker.py` ask lowering (v1.0.38)

```python
if is_very_aged:
    aggressive_ask = min(market_bid + 0.001, market_ask - 0.001)
    # ↓ ↓ ↓ ЦЕ БАГ ↓ ↓ ↓
    ask_price = aggressive_ask  # може бути НИЖЧЕ за entry!
```

v1.0.38 коментар: *"aged positions are allowed to sell at a loss — that's the whole point of the aging mechanism"* — НАМІСНО дозволяв sell у збиток для clearing.

**Але ви не хочете clearing у збиток.** Ви хочете: чекати profit, не закривати в мінус.

---

## Фікс BUG-N43

### Code change (market_maker.py рядки 1165-1218):

```python
# BUG-N43: determine if position is URGENT (very stale).
is_urgent_age = age_sec >= settings.inventory_liquidation_urgent_age_sec

if is_very_aged:
    aggressive_ask = min(market_bid + 0.001, market_ask - 0.001)
    # BUG-N43: don't lower ask below entry UNLESS position is URGENT.
    if not is_urgent_age and aggressive_ask < inv.avg_entry_price:
        aggressive_ask = round(inv.avg_entry_price + 0.001, 4)
        log.info("ask_lowering_clamped_to_entry", ...)
```

### Логіка:
- **Non-URGENT** (age < 7200с): ask clamped to `entry + 0.001` (НЕ нижче entry)
- **URGENT** (age ≥ 7200с = 2 год): ask = `market_bid + 0.001` (може бути нижче entry, last resort)

### Config change (.env):
| Параметр | Було | Стало | Причина |
|---|---|---|---|
| `INVENTORY_LIQUIDATION_URGENT_AGE_SEC` | 1800 (30 хв) | **7200 (2 год)** | Більше часу positioned відновитись до profit |

---

## Очікувана поведінка

### Ваш приклад (Will Silver):
**До (v1.0.102):**
- Entry 0.3311, market_bid 0.3200
- aged lowering → ask = 0.3210 (< entry)
- Fill по 0.3210 → **-1.01¢ збиток**

**Після (v1.0.103):**
- Entry 0.3311, market_bid 0.3200
- aged lowering → aggressive_ask = 0.3210
- **clamp**: 0.3210 < 0.3311 → ask = 0.3312 (entry + 0.001)
- Ask в книзі по 0.3312
- Якщо fill → **+0.01¢ profit** (break-even + gas)
- Якщо не fill → positioned чекає до URGENT (2 год)

### Round_trip pattern:
- BUY по 0.3210 (bid filled)
- SELL по 0.3312 (ask = entry + 0.001, якщо entry був 0.3311)
- Wait... це break-even, не profit

**Але якщо market підніметься:**
- Entry 0.3311, market тепер 0.34-0.36
- ask = 0.3312 (clamp) АБО target_ask (вищий)
- Fill по 0.34+ → **profit**

---

## Чесні перевірки

| Перевірка | Результат |
|---|---|
| `py_compile market_maker.py` | ✅ OK |
| `.env` URGENT=7200 | ✅ verified |
| ask_lowering_clamped_to_entry в коді | ✅ рядки 1177-1190 |

### Що НЕ перевірено (чесно)
- Реальний PAPER-прогін з v1.0.103
- Чи `ask_lowering_clamped_to_entry` з'являється в логах
- Чи positioned відновлюється до profit за 2 год

---

## POSSIBLE FAILURE POINTS

1. **Positioned зависає на 2 год.** Non-URGENT не закриває в збиток, чекає profit. Якщо market не відновлюється → positioned 2 год, потім URGENT закриває в збиток. Більше stuck time, але менше збитків (бо не кожен cycle зливає).

2. **Ask = entry + 0.001 = break-even.** Якщо market впав below entry, ask = entry + 0.001 не fill'неться (бо market нижче). Positioned чекає. Це правильно — не продавати в збиток.

3. **Adverse selection все ще працює.** Бот купив по 0.3311 → ціна впала → ask 0.3312 не fill. Через 2 год URGENT по bid (нижче entry) = збиток. Та ж проблема, але відкладена на 2 год.

4. **Bankroll lock.** Positioned 2 год = capital locked. Менше ліквідності для нових trades. Але $60 bankroll, 6 markets — не критично.

---

## REQUIRED TESTS (після deploy)

1. **PAPER-сесія з v1.0.103:**
   - `ask_lowering_clamped_to_entry` в логах (новий event)
   - `quote_placed` з `our_ask ≥ entry` (не нижче)
   - `liquidation_triggered tier=URGENT` — рідше (тільки age > 7200с)

2. **Round_trip check:**
   ```bash
   grep -c "liquidation=False" bot.log  # natural SELL fills
   ```
   Мета: >0 (natural round_trip)

3. **P&L:**
   - Має покращитись (менше URGENT losses)
   - Але може бути 0 (positioned чекають, не закриваються)

4. **Дашборд:**
   - Real Exit ≥ Entry (не нижче)
   - Real P&L ≥ 0 (не від'ємне, крім URGENT)

---

## Файли змінені

| Файл | Зміна |
|---|---|
| `app/services/market_maker.py` | BUG-N43 fix: ask lowering clamped to entry for non-URGENT (рядки 1165-1218) |
| `.env` | URGENT_AGE 1800→7200 |
| `VERSION` | 1.0.102 → 1.0.103 |
| `CHANGELOG_v1.0.103.md` | цей файл |

---

## Confidence

- **Коректність фіксу: ~95%** (логіка прозора)
- **Ask не нижче entry: 100%** (для non-URGENT)
- **Менше URGENT losses: ~90%** (URGENT лише після 2 год)
- **Round_trip > 0: ~40%** (adverse selection все ще працює)
- **P&L profit: ~30%** (adverse selection домінує на niche)

## Признання

Це **9-й баг поспіль** (N34-N43). Ваші слова "MAYBE entry should be 0.3210 and exit 0.3311 = 1¢ profit" — це **правильна MM логіка**. Бот робив навпаки через v1.0.38 design ("aged positions allowed to sell at loss"). Я не перевірив цей design коли фіксив попередні баги.

Вибачаюсь — бот закривав у збиток навіть коли міг чекати profit. Тепер чекатиме.
