# CHANGELOG v1.0.106 — RESTORE 4 втрачених фіксів

**Дата:** 2026-07-09
**Попередник:** v1.0.105 (BUG-N46 URGENT bypass)
**Автор:** GLM
**Пріоритет:** 🔴 КРИТИЧНИЙ — бот злив -$4.37 за 38 хв через відсутні фікси

---

## Що сталося

Під час роботи над v1.0.104-105 файл `market_maker.py` втратив 4 критичних фікси:
- BUG-N36 (opportunistic TP bid-based)
- BUG-N39 (AGGRESSIVE skip if realistic < entry)
- BUG-N42 (ask restored above bid)
- BUG-N43 (ask lowering clamped to entry)

Причина: можливо під час одного з `unzip -o` (overwrite) файл перезаписався, або під час edit випадково видалився блок.

## Наслідок (з логу v1.0.105, 38 хв)

| Метрика | Значення |
|---|---|
| P&L | **-$4.37** |
| AGGRESSIVE liquidations | 149 (всі з loss 0.7-0.8¢) |
| opportunistic TP | 0 (trigger використовував mid, не bid) |
| Natural round_trips | 2 |

Бот зливав бо:
1. AGGRESSIVE виконував збитки до 1.0¢ (BUG-N39 відсутній)
2. TP не спрацьовував (BUG-N36 відсутній — перевіряв mid, не bid)
3. Ask lowering продав нижче entry (BUG-N43 відсутній)
4. Crossed quotes не restored (BUG-N42 відсутній)

## Фікс — RESTORE всі 4

Всі 4 fixes відновлено в коді. Верифіковано:

| Fix | Count | Призначення |
|---|---|---|
| BUG-N34 | 1 | realistic_exit_price calculation |
| BUG-N36 | 3 | TP trigger bid-based |
| BUG-N39 | 1 | AGGRESSIVE skip loss |
| BUG-N42 | 1 | ask restored above bid |
| BUG-N43 | 1 | ask clamped to entry |
| BUG-N46 | 1 | URGENT bypass rejection |

**Всі 6 fixes на місці.** py_compile OK.

## Очікувана поведірка

Повертаємось до стану v1.0.105 + всі fixes:
- AGGRESSIVE skip'ить збитки (чекає profit)
- TP спрацьовує на bid-based profit
- Ask не нижче entry (non-URGENT)
- Crossed quotes restored (не blocked)
- URGENT повний fill (BUG-N46)

## Признання

Це моя помилка — втратив 4 fixes під час роботи. Бот злив -$4.37 через це. Вибачаюсь.
