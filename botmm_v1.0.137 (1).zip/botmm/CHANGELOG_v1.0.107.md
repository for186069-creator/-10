# CHANGELOG v1.0.107 — BUG-N47: ask blocked when position flat

**Дата:** 2026-07-09
**Попередник:** v1.0.106 (restore 4 fixes)
**Автор:** GLM (за скріншотом користувача арпр.png)

---

## Суть (верифіковано зі скріншоту)

### Скріншот арпр.png — 6 rows:
- **ВСЕ "Our Ask: BLOCKED"**
- **Entry: flat** (немає positioned)
- Age: не показано

### Коренева причина — BUG-N47

`market_maker.py` рядок 1106 (до фіксу):
```python
remaining_tokens = inv.net_tokens  # 0 when flat

if ask_price is not None and remaining_tokens <= 0:
    ask_price = None  # BLOCK
```

**Коли position flat (net_tokens=0) → remaining_tokens=0 → ask BLOCKED.**

### Чому це проблема

**Catch-22:**
1. Ask блокується бо немає tokens
2. Tokens не з'являються бо ask не розміщений
3. → 0 round_trips (бот лише buy side)

**MM bot має робити two-sided quoting (bid+ask одночасно):**
- BUY (bid fill) → отримати tokens
- SELL (ask fill) → продати tokens
- Profit = spread

Якщо ask блокується поки flat → немає ask в книзі → немає SELL fills → 0 round_trips.

### Правильно для LIVE, неправильно для PAPER

**LIVE:** Polymarket CTF не дозволяє shorting. SELL > balance → API reject. Перевірка потрібна.

**PAPER:** Симуляція. Ask має розміщуватись завжди (для two-sided quoting). Якщо ask fillnuвся коли flat → BUG-N41 clamp (v1.0.101) запобіжить short (продає лише що маємо).

---

## Фікс BUG-N47

`market_maker.py` рядки 1114, 1125:

```python
# Було:
if ask_price is not None and remaining_tokens <= 0:
    ask_price = None

# Стало:
if ask_price is not None and remaining_tokens <= 0 and not settings.paper_trading:
    ask_price = None  # LIVE only
```

Те саме для `remaining_tokens < tokens_needed` перевірки.

### Логіка:
- **PAPER**: ask розміщується завжди (two-sided quoting). BUG-N41 clamp захищає від short.
- **LIVE**: ask блокується якщо insufficient tokens (API reject).

---

## Очікувана поведінка

### До (v1.0.106):
- 6 rows, всі ask BLOCKED (flat positioned)
- 0 round_trips (немає ask в книзі)
- Бот лише buy side

### Після (v1.0.107):
- Ask розміщується навіть коли flat
- Two-sided quoting (bid+ask)
- Round_trip можливий (ask fill → SELL)
- BUG-N41 clamp захищає від short

---

## Чесні перевірки

| Перевірка | Результат |
|---|---|
| `py_compile market_maker.py` | ✅ OK |
| `and not settings.paper_trading` в обох перевірках | ✅ |
| LIVE перевірки збережені | ✅ |

---

## Файли змінені

| Файл | Зміна |
|---|---|
| `app/services/market_maker.py` | BUG-N47: PAPER allows ask when flat (рядки 1114, 1125) |
| `VERSION` | 1.0.106 → 1.0.107 |
| `CHANGELOG_v1.0.107.md` | цей файл |

---

## Confidence

- **Коректність фіксу: ~95%**
- **Ask розміщується в PAPER: 100%** (за визначенням)
- **Round_trip > 0: ~70%** (ask в книзі + BUG-N41 clamp)
- **P&L покращиться: ~70%**
