# CHANGELOG v1.0.88 — Opportunistic take-profit + mm_snapshots logging + backtest infra

**Дата:** 2026-07-07
**Попередник:** v1.0.87 (arb crash fix + liquidity test config)
**Автор:** GLM (за HANDOFF "Polymarket MM Bot Pro — Opportunistic Take-Profit + Backtest Infra" від Claude)
**База:** v1.0.87 (NOTE: handoff писав "v1.0.86", але у репо вже v1.0.87 — без конфлікту зі змінами)

---

## Попередня верифікація (truth-first)

Усі твердження хендоффа перевірені проти реального коду ДО внесення змін.

### Підтверджено (хендофф точний)
- `MarketSnapshot` існує в `app/db/models.py:123`, prune є (`market_maker.py`), INSERT ніколи не було → бектест неможливий. ✓
- `inventory_liquidation_aggressive_age_sec` у `config.py:149`. ✓
- `_liquidate_aged_positions()` у `market_maker.py`, рядок `if age_sec < ...aggressive_age_sec:` — точна точка вставки. ✓
- `target_mid`/`target_min`/`tier=""` вже обчислюються рядком вище. ✓
- Код нижче (clamp/loss-check/PAPER-LIVE fill) generic — новий тір працює без змін downstream. ✓
- Пасивна квота `_check_fills_paper` у окремому таску `_requote_loop` → паралельно до `_liquidation_loop`. ✓
- Pydantic v2 + `pydantic_settings`. ✓
- `book.mid`, `book.spread` — @property на `MarketBook`. ✓
- `Side` enum: `BUY`/`SELL`; `Trade` schema підтверджено. ✓

### Розбіжності (хендофф помилявся — адаптовано, НЕ вставлено дослівно)
1. **`self.db_session_factory` НЕ існує.** Реальний патерн: `from app.core.db import AsyncSessionLocal` + `async with AsyncSessionLocal() as db:`. → використано.
2. **`InventoryState()` у сніпеті — ПОМИЛКА.** `self.inventory.inventories` це `dict[str, Inventory]` (dataclass з `inventory_manager.py`), а НЕ DB-модель `InventoryState` (`models.py:176`). Хендофф їх змішав. → використано `.get()` + None-обробку.
3. **`self._get_current_volatility` НЕ існує.** → `volatility=0.0`; `kyle_lambda` взято READ-ONLY через `self._kyle.get_state(token_id).last_lambda` (без мутації, без race з quote-loop).

### Нова проблема, яку хендофф ПРОПУСТИВ (блокер)
4. **Prune-ліміт `LIMIT 1000`** для `mm_snapshots` несумісний із метою "3-5 днів даних" (≈25 хв історії). → зроблено конфігуровним: `mm_snapshot_keep_rows` (default 300_000 ≈ 5 днів при 30с × 20 ринків).

---

## A: Новий тір `OPPORTUNISTIC_PROFIT` (opportunistic early take-profit)

### Файл: `app/services/market_maker.py`, функція `_liquidate_aged_positions`

**Без змін до існуючих тірів.** Новий тір вставлено ПЕРЕД існуючим `if age_sec < inventory_liquidation_aggressive_age_sec:` (який став `elif`). Нижній код (clamp/loss-check/PAPER-LIVE fill) не чіпався — він generic.

Логіка: на КОЖНОМУ циклі ліквідації, якщо позиція прожила ≥ `inventory_profit_take_min_age_sec` (15с) і потенційний прибуток ≥ `inventory_profit_take_cents` (3¢), — виходимо одразу через taker-order (mid-based ціна, cap ask-0.001), не чекаючи aging-таймера (240с) чи природного контрагента.

### Паралельність (ключова вимога хендоффа)
Три шляхи виходу НЕЗАЛЕЖНІ, кожен у своєму циклі:
1. **Природний філ** — пасивна резервна квота в `_check_fills_paper`, таск `_requote_loop` (не чіпався).
2. **OPPORTUNISTIC_PROFIT** — новий тір у `_liquidate_aged_positions`, таск `_liquidation_loop`.
3. **AGGRESSIVE/URGENT/CRITICAL** — існуючі aging-тіри (без змін).

Який спрацює першим — той й закриває позицію.

### Нові налаштування (`app/core/config.py`)
```python
inventory_profit_take_cents: float = Field(default=3.0, gt=0)
inventory_profit_take_min_age_sec: float = Field(default=15.0, ge=0)
```
**Це стартові гіпотези**, не фінальні значення. Підбираються бектестом (розділ D) після накопичення даних.

---

## B: `mm_snapshots` тепер реально заповнюється

### Файл: `app/services/market_maker.py`, нові методи `_snapshot_loop` + `_log_market_snapshots`

До v1.0.88 таблиця `mm_snapshots` була визначена в схемі, але НІКОЛИ не заповнювалась (тільки prune). Тепер фоновий таск `_snapshot_task` (запускається в `start()`, скасовується в `stop()`) логує один ряд на активний ринок кожні `mm_snapshot_log_interval_sec` (30с).

Колонки:
- `market_id`, `mid_price` (book.mid), `spread` (book.spread) — з книги.
- `kyle_lambda` — READ-ONLY з `self._kyle.get_state(token_id).last_lambda` (без мутації стану → без race з quote-loop).
- `volatility` — 0.0 (A-S sigma обчислюється в quote-loop і не кешується тут; за потреби можна додати кеш пізніше).
- `our_inventory` — `inv.net_tokens` з `self.inventory.inventories`.
- `bankroll_usdc` — `self.inventory.bankroll`.

Використано реальний патерн БД-сесій коду (`AsyncSessionLocal`, локальний import), а НЕ неіснуючий `self.db_session_factory` з хендоффа.

### Нові налаштування
```python
mm_snapshot_log_interval_sec: float = Field(default=30.0, gt=0)
mm_snapshot_keep_rows: int = Field(default=300_000, gt=0)
```

---

## C: Prune-ліміт `mm_snapshots` став конфігуровним

### Файл: `app/services/market_maker.py`, `_db_cleanup_loop`

Було: `LIMIT 1000` (хардкод) → тримав ≈25 хв історії (фатально для бектесту).
Стало: `LIMIT {int(settings.mm_snapshot_keep_rows)}` (default 300_000 ≈ 5 днів).

Значення — валідований pydantic `int`, інтерпольовано в SQL безпечно (без injection-ризику). `mm_quotes` (1000) та `mm_metric_points` (5000) не чіпались.

---

## D: `scripts/backtest_hold_n_minutes.py` (нова інфраструктура бектесту)

**СТАТУС: UNTESTED** — написано за верифікованою схемою `mm_trades` + `mm_snapshots`, але НЕ МОЖЕ бути валідованим, поки `mm_snapshots` не накопичить ≥ 3-5 днів даних (розділ B). Скрипт сам має охоронця: якщо `mm_snapshots` порожня — abort з exit code 4.

Що робить: для кожного BUY-філу та кожної комбінації `(N_minutes, profit_take_cents)` симулює "продати через N хв АБО одразу при досягненні profit_take (що раніше)", рахує `total_pnl_net`, `win_rate`, `avg_win`/`avg_loss`, `sample_size`. Комбінації з < `--min-sample` (50) філів позначаються як незначущі.

Реалізовано на stdlib `sqlite3` (без SQLAlchemy async, без зайвих залежностей). Проверено: `--help` працює, запуск проти `mm_bot.db` коректно повідомляє про порожню таблицю.

### Спрощення (чесні обмеження)
1. Кожен BUY-філ — незалежний round-trip (не моделює position stacking / avg_entry).
2. Exit-ціна — перший snapshot mid ≥ exit_time (при 30с інтервалі — до ~30с запізнення).
3. Fee model: default 0 (gross); `--fee-bps` для оцінки net.
4. Тільки BUY-opens (бот long-only на ліквідацію).

---

## Послідовність виконання (як у хендоффі, розділ 4)

1. ✅ Розділ 1 (opportunistic take-profit) — впроваджено.
2. ✅ Розділ 2 (snapshot logging) — впроваджено (+ fix prune-ліміту).
3. ⏳ Дати попрацювати 3-5 днів (PAPER) — **не виконано, вимагає часу**.
4. ⏳ Розділ 3 (бектест) — скрипт готовий, запускати тільки після п.3.
5. ⏳ Коригування `inventory_profit_take_cents` / `inventory_liquidation_aggressive_age_sec` за результатами бектесту.

---

## Файли змінені

| Файл | Зміна |
|---|---|
| `app/core/config.py` | +3 поля: `inventory_profit_take_cents`, `inventory_profit_take_min_age_sec`, `mm_snapshot_log_interval_sec`, `mm_snapshot_keep_rows` |
| `app/services/market_maker.py` | import `MarketSnapshot`; +тір `OPPORTUNISTIC_PROFIT`; +`_snapshot_loop`/`_log_market_snapshots`; +`_snapshot_task` в `__init__`/`start`/`stop`; prune-ліміт конфігуровний |
| `scripts/backtest_hold_n_minutes.py` | новий файл (UNTESTED) |
| `VERSION` | 1.0.87 → 1.0.88 |
| `CHANGELOG_v1.0.88.md` | цей файл |

## Перевірки виконані (чесно)

- `python3 -m py_compile` — OK для `config.py`, `market_maker.py`, `backtest_hold_n_minutes.py` (реальна перевірка синтаксису).
- `backtest_hold_n_minutes.py --help` — OK (argparse працює).
- `backtest_hold_n_minutes.py --db mm_bot.db` — коректно повідомляє `mm_snapshots: 0 rows` + abort (exit 4). Охоронець працює.
- **НЕ виконано**: імпорт `Settings` (потребує залежностей + .env), запуск бота, PAPER-сесія, реальний бектест з даними.

## Confidence

- Структурна коректність правок: **~90%** (верифіковано схему, патерни, точку вставки; py_compile чистий).
- Поведінкова коректність (чи спрацює тір як задумано в живому боті): **UNVERIFIED** — потребує PAPER-сесії.
- Оптимальність дефолтів 3¢/15с: **UNVERIFIED** — стартові гіпотези, бектест визначить.
