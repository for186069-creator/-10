# CHANGELOG v1.0.90 — N3 Arbitrage Execution Layer

**Дата:** 2026-07-07
**Попередник:** v1.0.89 (TEMPORARY backtest accumulation config)
**Автор:** GLM (за прямим запитом користувача після діагнозу: "бот зливає PAPER, MM структурно не працює")
**Статус:** ⚠️ НОВИЙ МОДУЛЬ, DEFAULT OFF — увімкнути після рев'ю коду

---

## Контекст

v1.0.89 PAPER-сесія (1 год 44 хв, свіжий bot.log) підтвердила:
- **0 round_trips** (усі 6 SELL = liquidation)
- `opportunistic_profit_take_triggered = 0` (ціна НІКОЛИ не зросла +3¢ від entry)
- -$0.73 збитку за 1 год 44 хв
- adverse selection триває: BUY → ціна падає → SELL нижче entry

Claude писав у v1.0.87: "round_trip = 0 на ліквідних → **серйозно розглянути арбітражний напрямок або колокацію замість подальшого тюнінгу MM-параметрів**". Арбітраж-сканер (v1.0.84) працює і знайшов 1 opportunity за 1 год 44 хв (Graham Platner time_spread, 25% ROI). Але **виконання не було реалізоване** (N3 — TODO).

v1.0.90 реалізує N3.

---

## Що побудовано

### A. `app/services/arb_executor.py` (новий, ~600 рядків)

Клас `ArbExecutor` з двома background loops:

1. **`_execute_loop`** — раз на `arb_scan_interval_sec` читає `arb_scanner.opportunities`. Якщо є opp з `edge ≥ arb_min_edge_cents_execute` (default 3¢, строгіше за detection 2¢) і під concurrency cap — викликає `_execute_arb`.

2. **`_resolution_loop`** — раз на `arb_resolution_check_interval_sec` (default 300с) poll-ить Gamma `/markets?clob_token_ids=...` для всіх OPEN позицій. Якщо ОБИДВІ ноги closed → settle (status=RESOLVED, compute payout). Старі позиції (>14 днів) → EXPIRED.

**`_execute_arb` логіка:**
- `_resolve_tokens(opp)` → (yes_token, no_token) на основі direction
- Купує YES leg: `place_order(token=yes_token, side="BUY", price=yes_price, order_type="FAK", post_only=False)`
- Купує NO leg: `place_order(token=no_token, side="BUY", price=no_price, order_type="FAK", post_only=False)`
- `no_price = 1 - partner_yes_price` (Polymarket invariant)
- Записує `ArbPosition` в БД з status=OPEN
- Якщо YES filled, NO failed → записує FAILED з reason "YES tokens held unhedged — admin review required"

**Ключові архітектурні рішення (truth-first):**
- **НЕ використовує `InventoryManager.on_fill`** — arb втрати не мають тригерити MM halt logic. Окремий accounting через `ArbPosition` таблицю.
- **НЕ через MarketMaker** — напряму через `ClobService.place_order` з FAK + post_only=False (taker orders, як `_handle_resolution_exit` в market_maker.py:810-811).
- **PAPER mode працює** — `place_order` short-circuit-ить до MATCHED, симулюючи fill. Можна тестувати без реальних $.
- **Resolution detection через poll Gamma API** — WebSocket не доставляє resolution events.

### B. `app/services/arbitrage_scanner.py` (модифікація)

`ArbOpportunity` розширено:
```python
market_a_no_token_id: str    # NEW v1.0.90
market_b_no_token_id: str    # NEW v1.0.90
```

`scan_once` тепер зберігає ОБИДВА token_ids (YES + NO) для кожного ринку. Старий код брав лише YES і робив `break`. Новий код ітерує всі outcomes і розкладає по `yes_tid`/`no_tid`.

### C. `app/db/models.py` — нова модель `ArbPosition`

Таблиця `arb_positions`. Поля:
- Detection context: `event_slug`, `event_title`, `arb_type`, `direction`, `detected_at`
- YES leg: `buy_yes_token_id`, `buy_yes_market_question`, `buy_yes_price`, `buy_yes_size_tokens`, `buy_yes_size_usdc`, `buy_yes_order_id`
- NO leg: `buy_no_token_id`, `buy_no_market_question`, `buy_no_price`, `buy_no_size_tokens`, `buy_no_size_usdc`, `buy_no_order_id`
- Economics: `total_cost_usdc`, `expected_payout_usdc`, `edge_cents_at_open`
- Resolution: `status` (OPEN/RESOLVED/EXPIRED/FAILED), `resolved_payout_usdc`, `resolved_at`, `winning_leg`, `failure_reason`

Indexes: `event_slug`, `buy_yes_token_id`, `buy_no_token_id`, `status`, composite `(status, timestamp)`.

### D. `alembic/versions/002_arb_positions.py` (нова міграція)

Revision 002, down_revision 001. Створює таблицю + 5 indexes. `downgrade()` коректно drop-ить все.

### E. `app/core/config.py` — 6 нових полів

```python
arb_execution_enabled: bool = Field(default=False, alias="ARB_EXECUTION_ENABLED")
arb_max_concurrent_positions: int = Field(default=2, ge=1, le=20, alias="ARB_MAX_CONCURRENT_POSITIONS")
arb_position_size_usdc: float = Field(default=5.0, gt=0, le=100.0, alias="ARB_POSITION_SIZE_USDC")
arb_resolution_check_interval_sec: float = Field(default=300.0, ge=60.0, le=3600.0, alias="ARB_RESOLUTION_CHECK_INTERVAL_SEC")
arb_max_position_age_sec: float = Field(default=1209600.0, ge=3600.0, le=7776000.0, alias="ARB_MAX_POSITION_AGE_SEC")  # 14 днів
arb_min_edge_cents_execute: float = Field(default=3.0, ge=0.5, le=50.0, alias="ARB_MIN_EDGE_CENTS_EXECUTE")
```

**Default OFF** — `arb_execution_enabled=False`. Треба свідомо увімкнути в `.env` після рев'ю коду.

### F. `app/main.py` — wire ArbExecutor

- Import `ArbExecutor`
- Global: `arb_executor = ArbExecutor(clob)` (після `clob = ClobService()`)
- Lifespan startup: `if arb_execution_enabled and arb_enabled: await arb_executor.start()`
- Lifespan shutdown: `await arb_executor.stop()`
- Guard: якщо `arb_execution_enabled=True` але `arb_enabled=False` → log warning, skip (scanner must run first)

---

## Як увімкнути (після рев'ю)

Додати в `.env`:
```env
ARB_EXECUTION_ENABLED=true
ARB_MAX_CONCURRENT_POSITIONS=2
ARB_POSITION_SIZE_USDC=5.0
ARB_RESOLUTION_CHECK_INTERVAL_SEC=300
ARB_MAX_POSITION_AGE_SEC=1209600
ARB_MIN_EDGE_CENTS_EXECUTE=3.0
```

Запустити міграцію:
```bash
alembic upgrade head
```

---

## Чесні перевірки виконані

| Перевірка | Інструмент | Результат |
|---|---|---|
| Синтаксис `arb_executor.py` | `py_compile` | ✅ OK |
| Синтаксис `arbitrage_scanner.py` | `py_compile` | ✅ OK |
| Синтаксис `models.py` | `py_compile` | ✅ OK |
| Синтаксис `config.py` | `py_compile` | ✅ OK |
| Синтаксис `main.py` | `py_compile` | ✅ OK |
| Синтаксис `002_arb_positions.py` | `py_compile` | ✅ OK |
| `ArbOpportunity` backward-compat | grep admin/api.py | ✅ Використовує лише `to_dict()` (оновлений, сумісний) |
| Немає інших місць що будують ArbOpportunity | grep | ✅ Тільки scanner + executor |

### Що НЕ перевірено (чесно)
- Імпорт `Settings` (потребує залежностей + .env).
- Запуск бота з `ARB_EXECUTION_ENABLED=true`.
- Реальний arb trade на PAPER.
- Реальний arb trade на LIVE (потребує PRIVATE_KEY).
- Gamma API resolution response shape — **UNVERIFIED** (див. POSSIBLE FAILURE POINTS).

---

## POSSIBLE FAILURE POINTS

1. **Gamma API resolution detection — UNVERIFIED.** Я припускаю, що resolved market має `closed=true` + `outcomePrices=["1","0"]` або `["0","1"]`. Якщо Gamma повертає інший формат (напр. `outcomePrices=["1.0","0.0"]` або числовий тип) — `_fetch_resolution_state` може не розпізнати resolution. Позиції застрягнуть в OPEN. **Тест:** після першого resolved market — перевірити лог `arb_settled` чи `arb_resolution_loop_error`.

2. **FAK order fill в LIVE.** PAPER short-circuit-ить до MATCHED. LIVE FAK (Fill-And-Kill) може partial-fill або взагалі не fill-нути якщо book thin. Якщо YES filled, NO failed → позиція FAILED з unhedged YES tokens. **Mitigation:** `failure_reason` логує це; admin має reviewати FAILED позиції.

3. **Race condition: opportunistic TP vs arb executor.** Якщо bot має MM position на тому ж token, що й arb — два loop-и можуть конфліктувати. Arb executor НЕ перевіряє `_committed_tokens` проти MM inventory. **Mitigation:** arb markets (niche, volume<50k) рідко перетинаються з MM markets (auto_pick). Але якщо перетнуться — bot матиме дубльовані позиції.

4. **`arb_position_size_usdc` min $5.** Polymarket hard floor. Якщо банкрол < $10 — тільки 1 позиція (2 legs × $5 = $10). При $60 bankroll — max 3 одночасних arb (6 legs × $5 = $30), але `arb_max_concurrent_positions=2` (default) обмежує до 2.

5. **Resolution timing.** Arb може тримати позицію до resolution — дні або тижні. `$10` locked на 14 днів = opportunity cost. Якщо `arb_max_position_age_sec=14днів` проходить без resolution → EXPIRED (admin review).

6. **Cross_condition arb mutual exclusivity.** Для time_spread arb: YES_late resolves YES → NO_early resolves NO (гарантовано монотонністю). Для cross_condition — **НЕ завжди**. Executor чекає BOTH legs closed перед settle, що безпечно, але означає довший hold.

7. **NO token price derivation.** `no_price = 1 - partner_yes_price`. Це вірно для Polymarket (Yes + No = $1 на одному ринку). Але partner_yes_price — з моменту scan, може бути stale до execute. Якщо ціна змінилась — FAK order не fill-неться. **Mitigation:** scanner re-scan кожні 5 хв; arb_executor бере свіжі opportunities.

---

## REQUIRED TESTS (після увімкнення)

1. **PAPER smoke test (1 год):**
   ```env
   ARB_EXECUTION_ENABLED=true
   PAPER_TRADING=true
   ```
   Очікування: `arb_executed` в логах при `arb_opportunity_found`. `ArbPosition` рядки в БД з status=OPEN.

2. **Resolution detection test:**
   - Дочекатись resolution першого OPEN arb (може зайняти дні).
   - Перевірити `arb_settled` в логах + `status=RESOLVED` в БД.
   - Якщо `arb_resolution_loop_error` повторюється — Gamma API shape wrong.

3. **LIVE smoke test (після PAPER success):**
   - `$10` на arb, `ARB_MAX_CONCURRENT_POSITIONS=1`.
   - Перевірити реальні ордери на Polymarket.
   - Перевірити `total_cost < expected_payout` (інакше arb втратив сенс).

4. **FAILED position review:**
   - `SELECT * FROM arb_positions WHERE status='FAILED'`
   - Якщо є unhedged YES tokens — вирішити: продати (crystallize loss) чи чекати resolution.

---

## Файли змінені/створені

| Файл | Тип | Зміна |
|---|---|---|
| `app/services/arb_executor.py` | NEW | ~600 рядків, ArbExecutor class |
| `app/services/arbitrage_scanner.py` | MODIFY | +2 поля в ArbOpportunity, scan_once зберігає YES+NO |
| `app/db/models.py` | MODIFY | +ArbPosition model (arb_positions table) |
| `app/core/config.py` | MODIFY | +6 arb_execution_* полів |
| `app/main.py` | MODIFY | +import, +global, +lifespan start/stop |
| `alembic/versions/002_arb_positions.py` | NEW | міграція |
| `VERSION` | MODIFY | 1.0.89 → 1.0.90 |
| `CHANGELOG_v1.0.90.md` | NEW | цей файл |

---

## Confidence

- **Структурна коректність: ~85%** (верифіковано py_compile, grep; architexture відповідає існуючим патернам коду).
- **PAPER mode працюватиме: ~90%** (place_order PAPER short-circuit добре відомий).
- **LIVE mode працюватиме: ~70%** (FAK + post_only=False — стандартний патерн, але real fill залежить від book).
- **Resolution detection: ~60%** (UNVERIFIED Gamma API shape — головний ризик).
- **Arb буде profitable: ~50%** (opportunities rare — 1 за 1 год 44 хв; $0.40 profit на $1.60 cost = 25% ROI, але 14-day hold = opportunity cost).

Головний win: **цей модуль НЕ страждає від adverse selection** (не MM, не квотує — бере готову цінову невідповідність). Якщо resolution detection працює — arb математично гарантований (монотонність time_spread).
