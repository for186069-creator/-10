# CHANGELOG v1.0.91 — BUG-N34: loss_cents рахується від неправильної ціни

**Дата:** 2026-07-07
**Попередник:** v1.0.90 (N3 arb execution layer)
**Автор:** GLM (за HANDOFF від Claude, 2026-07-07)
**Пріоритет:** Середній-високий — впливає на accuracy risk-control

---

## Контекст (з реального PAPER-логу)

```
liquidation_triggered  avg_entry=0.138 loss_cents=-1.1 sell_price=0.149 tier=URGENT
liquidation_paper_filled  fillable_price=0.131
fill  price=0.131 pnl_net=-0.3519   ← РЕАЛЬНИЙ збиток -5.3%
```

Залоговано `loss_cents=-1.1` (від'ємне = "прибуток 1.1¢"), хоча реальний результат — **збиток 5.3%**. Розбіжність ~15¢ між тим, що бот "думав", і тим, що реально сталось.

---

## Коренева причина (верифіковано кодом)

**Файл:** `app/services/market_maker.py`

| Рядок (до фіксу) | Код | Опис |
|---|---|---|
| 1996 | `loss_cents = (inv.avg_entry_price - sell_price) * 100` | loss_cents від **sell_price** (mid-based, оптимістична) |
| 1997 | `if loss_cents > max_loss_cents and not is_urgent: continue` | перевірка збитку |
| 2068 | `fillable_price = min(sell_price, round(market_bid + 0.001, 4))` | реалістична ціна (bid-based) — на 72 рядки нижче |

**Проблема:** рішення "продовжувати чи почекати" приймалось на основі `sell_price` (оптимістична ціль), а реальна ціна виконання (`fillable_price`, capped by `market_bid`) рахувалась лише в PAPER-гілці, **після** перевірки.

---

## Звіт верифікації хендоффа (truth-first)

Усі 9 тверджень хендоффа перевірені проти коду ДО фіксу:

| # | Твердження | Статус |
|---|---|---|
| 1 | рядок 1996: `loss_cents = (entry - sell_price) * 100` | ✅ TRUE |
| 2 | рядок 1997: `if loss_cents > max_loss and not is_urgent: continue` | ✅ TRUE |
| 3 | рядок 2068: `fillable_price = min(sell_price, bid+0.001)` (72 рядки нижче) | ✅ TRUE |
| 4 | `market_bid` в scope на 1996 (призначено на 1911) | ✅ TRUE |
| 5 | URGENT bypass через `not is_urgent` | ✅ TRUE |
| 6 | AGGRESSIVE (`is_urgent=False`) — loss-check активний | ✅ TRUE |
| 7 | OPPORTUNISTIC_PROFIT (мій v1.0.88) теж `is_urgent=False` → loss-check активний | ✅ TRUE (додатково) |
| 8 | LIVE-гілка логує `requested_price=sell_price`, не реалістичний | ✅ TRUE |
| 9 | Приклад з логу: `loss_cents=-1.1` при реальному збитку -5.3% | ✅ TRUE |

---

## Фікс (3 правки)

### 1. `realistic_exit_price` до перевірки loss_cents (рядки 1995-2007)

```python
# Було:
sell_price = max(0.01, min(0.99, sell_price))
loss_cents = (inv.avg_entry_price - sell_price) * 100

# Стало (BUG-N34):
sell_price = max(0.01, min(0.99, sell_price))
realistic_exit_price = min(sell_price, round(market_bid + 0.001, 4))
loss_cents = (inv.avg_entry_price - realistic_exit_price) * 100
```

+ розширений `liquidation_skipped_loss_too_big` лог: додано `sell_price` + `realistic_exit_price` для діагностики.

### 2. PAPER-гілка: переюзати `realistic_exit_price` (рядок 2088)

```python
# Було:
fillable_price = min(sell_price, round(market_bid + 0.001, 4))

# Стало (BUG-N34):
fillable_price = realistic_exit_price  # same value, single source of truth
```

Формула ідентична — просто усунуто дублювання.

### 3. LIVE-гілка: додати `realistic_exit_price` + `loss_cents` до логів (рядок 2188)

```python
log.info(
    "liquidation_order_placed_live",
    ...
    requested_price=round(sell_price, 4),
    realistic_exit_price=round(realistic_exit_price, 4),  # NEW
    actual_price=round(actual_price, 4),
    ...
    loss_cents=round(loss_cents, 2),  # NEW — for log consistency PAPER/LIVE
)
```

Також додано `realistic_exit_price` до `liquidation_triggered` логу (рядок 2042) — для повноти діагностики.

---

## Що НЕ чіплено (як просив хендофф)

- Розрахунок `sell_price` (target для тіру) — без змін, потрібен для "куди цілимось".
- `is_urgent`-логіка (URGENT bypass) — без змін, навмисна поведінка.
- BUG-N30/N31 фікси (ймовірнісна модель, token-count) — не пов'язані.
- OPPORTUNISTIC_PROFIT тір (мій v1.0.88) — тепер коректно перевіряється через `realistic_exit_price` (не вимагалось хендоффом, але фікс автоматично покриває і його).

---

## Юніт-тести (`tests/unit/test_bugN34_loss_cents_realistic.py`)

2 тести, написані за зразком `test_market_maker_live.py` (mocked ClobService, monkeypatch settings):

### Test 1: `test_bugN34_loss_check_passes_when_realistic_loss_under_max`
- max_loss=100¢, realistic loss=0.7¢ → liquidation EXECUTES (`_record_fill.called == True`)
- Сам по собі не відрізняє fixed/buggy (обидва проходять), але фіксує baseline.

### Test 2: `test_bugN34_loss_check_skips_when_realistic_loss_over_max` ⭐ КЛЮЧОВИЙ
- max_loss=0.5¢, realistic loss=0.7¢ → liquidation SKIPPED (`_record_fill.called == False`)
- **З фіксом:** loss_cents=+0.7 > 0.5 → skip → test PASS.
- **Без фіксу:** loss_cents=-1.1 < 0.5 → pass → `_record_fill` called → test FAIL.

Якщо Test 2 проходить — BUG-N34 верифіковано fixed.

### Стратегія тестів
Не парсимо structlog output (крихко). Замість цього перевіряємо **поведінку** — чи викликано `_record_fill` (mock). Два тести з однаковим сценарієм, різниця лише в `max_loss_cents`.

---

## Чесні перевірки виконані

| Перевірка | Інструмент | Результат |
|---|---|---|
| Синтаксис `market_maker.py` | `py_compile` | ✅ OK |
| Синтаксис `test_bugN34_loss_cents_realistic.py` | `py_compile` | ✅ OK |
| Верифікація 9 тверджень хендоффа | grep + read code | ✅ All TRUE |
| `realistic_exit_price` в scope для PAPER/LIVE гілок | read code | ✅ Так (визначено на 2007, обидві гілки нижче) |
| Інші тести не зламані | grep ArbOpportunity usages | ✅ Немає залежності |

### Що НЕ перевірено (чесно)
- `pytest tests/unit -q` — середовище не має fastapi/sqlalchemy залежностей. Тести написані, але UNVERIFIED до запуску в повному env.
- Реальна PAPER-сесія з фіксом — не запущено.

---

## POSSIBLE FAILURE POINTS

1. **Test fixture `Inventory` import.** Я імпортую `from app.services.inventory_manager import InventoryManager, Inventory`. Якщо `Inventory` не експортований (dataclass, можливо приватний) — test зламається. Перевірено: `inventory_manager.py:38` `class Inventory` — public.
2. **`paper_competition_rate` в fixture.** Я додав `monkeypatch.setattr(settings, "paper_competition_rate", 0.0)` — бо PAPER-гілка може використовувати competition model. Якщо ні — не шкодить.
3. **OPPORTUNISTIC_PROFIT disabled в fixture.** `inventory_profit_take_cents=100.0` (вище за будь-який реальний profit) + `min_age=9999.0` — гарантовано вимкнено, щоб тестувався AGGRESSIVE тір.
4. **AGE timing.** `open_time = monotonic() - 300.0` → age=300с. AGGRESSIVE (240с) < 300 < URGENT (480с). Якщо thresholds змінені в settings — тір може бути іншим. Fixture фіксує thresholds.

---

## REQUIRED TESTS (після deploy)

1. **Запустити pytest:**
   ```bash
   pytest tests/unit/test_bugN34_loss_cents_realistic.py -v
   ```
   Очікування: 2/2 passed. Якщо Test 2 failed — регресія.

2. **Повний pytest:**
   ```bash
   pytest tests/unit -q
   ```
   Очікування: 114/115 (112 старих + 2 нових; 1 відомий gas-тест fail).

3. **PAPER-сесія з wide-spread ринком:**
   - Дочекатись AGGRESSIVE liquidation на ринку з mid >> bid.
   - Перевірити лог: `loss_cents` має бути **позитивним** (реалістичний збиток), не від'ємним.
   - `realistic_exit_price` має бути ≤ `market_bid + 0.001`.

---

## Файли змінені/створені

| Файл | Зміна |
|---|---|
| `app/services/market_maker.py` | +`realistic_exit_price` до loss-check; PAPER reuse; LIVE log fields; `liquidation_triggered` log field |
| `tests/unit/test_bugN34_loss_cents_realistic.py` | NEW — 2 юніт-тести |
| `VERSION` | 1.0.90 → 1.0.91 |
| `CHANGELOG_v1.0.91.md` | цей файл |

---

## Confidence

- **Коректність фіксу: ~95%** (верифіковано код, py_compile OK, логіка прозора).
- **Юніт-тести правильні: ~80%** (написані за зразком існуючих, але UNVERIFIED до pytest run).
- **Фікс не ламає існуюче: ~95%** (`realistic_exit_price` = та ж формула що була в `fillable_price`, просто перенесена вище).
- **Покращить accuracy risk-control: ~90%** (для AGGRESSIVE/OPPORTUNISTIC тірів; URGENT не зачеплено за дизайном).
