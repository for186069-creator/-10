# CHANGELOG v1.0.92 — BUG-N35 CRITICAL: невірний розрахунок виплати при резолюції арбітражу

**Дата:** 2026-07-07
**Попередник:** v1.0.91 (BUG-N34 loss_cents fix)
**Автор:** GLM (за HANDOFF від Claude, 2026-07-07 — аудит v1.0.90)
**Пріоритет:** 🔴 КРИТИЧНИЙ — ламає весь сенс arb execution layer (N3)

---

## Суть бага (верифіковано кодом)

**Файл:** `app/services/arb_executor.py`, функція `_maybe_settle`

### До фіксу (рядки 542-544):
```python
yes_payout_per_token = 1.0 if yes_state["outcome"].lower() in ("yes", "1") else 0.0
no_payout_per_token = 1.0 if no_state["outcome"].lower() in ("no", "0") else 0.0
```

### Проблема:
- `yes_state["outcome"]` (рядок 510: `"outcome": str(outcome)`) — це **назва ауткому** з масиву `outcomes` (`["Yes", "No"]`). Для YES-токена ця назва ЗАВЖДИ "Yes", незалежно від результату резолюції.
- Реальний результат зберігається в `yes_state["price"]` (рядок 511: `"price": str(price)`) з масиву `outcomePrices` — "1" = переміг, "0" = програв.

### Числове підтвердження:
```python
# YES-ринок РЕАЛЬНО ПРОГРАВ (price=0):
yes_state = {"outcome": "Yes", "price": "0"}
yes_payout_per_token = 1.0 if "yes" in ("yes", "1") else 0.0
# → 1.0  ← МАЄ БУТИ 0.0 (YES програв!)
```

→ `yes_payout_per_token` і `no_payout_per_token` **ЗАВЖДИ 1.0** для закритого ринку.
→ `total_payout = yes_tokens × 1.0 + no_tokens × 1.0` = **ПОДВОЄНИЙ** фіктивний payout.
→ `net_pnl = total_payout - total_cost` систематично роздутий для КОЖНОЇ резолюції.

---

## Звіт верифікації хендоффа (truth-first)

| # | Твердження хендоффа | Статус |
|---|---|---|
| 1 | рядок 542: `yes_state["outcome"].lower() in ("yes", "1")` | ✅ TRUE (код перевірив) |
| 2 | рядок 510: `"outcome": str(outcome)` з масиву `outcomes` | ✅ TRUE |
| 3 | рядок 511: `"price": str(price)` з масиву `outcomePrices` | ✅ TRUE |
| 4 | `outcome` для YES-токена ЗАВЖДИ "Yes" (незмінний ярлик) | ✅ TRUE (Polymarket API contract) |
| 5 | `price` "1"/"0" — реальний результат | ✅ TRUE |
| 6 | `total_payout` завжди подвоєний | ✅ TRUE (логіка: обидві ноги × 1.0) |
| 7 | Баг НЕ залежить від формату Gamma API | ✅ TRUE (навіть при ідеальному форматі логіка зламана) |

Усі твердження підтвердились. Це баг моєї власної реалізації v1.0.90.

---

## Фікс

### 1. Module-level helper `_price_won` (рядки 80-93):
```python
def _price_won(price_value: Any) -> bool:
    """BUG-N35 (v1.0.92): determine if a Polymarket outcome price means 'won'."""
    try:
        p = float(price_value)
    except (TypeError, ValueError):
        return False
    return p >= 0.99
```

Float-tolerant: обробляє "1", "1.0", "0.999998", 1, 1.0 — усі варіанти Polymarket API (str | int | float, з округленням). Defensive: некоректні значення → False.

### 2. `_maybe_settle` (рядки 540-560):
```python
# Було:
yes_payout_per_token = 1.0 if yes_state["outcome"].lower() in ("yes", "1") else 0.0
no_payout_per_token = 1.0 if no_state["outcome"].lower() in ("no", "0") else 0.0

# Стало (BUG-N35):
yes_payout_per_token = 1.0 if _price_won(yes_state["price"]) else 0.0
no_payout_per_token = 1.0 if _price_won(no_state["price"]) else 0.0
```

### 3. `winning_leg` розширено (рядки 555-560):
```python
# Було: "yes" | "no" | "neither"
# Стало: "yes" | "no" | "both" | "neither"
winning_leg = (
    "yes" if yes_payout > 0 and no_payout == 0
    else "no" if no_payout > 0 and yes_payout == 0
    else "both" if yes_payout > 0 and no_payout > 0
    else "neither"
)
```

"both" — аномальний випадок (обидві ноги виграли), не повинен траплятись для валідного arb, але тепер помітно в логах.

---

## Що НЕ чіплено (за хендоффом)

- `_fetch_resolution_state` — структура збору даних коректна, поле `outcome` теж потрібне для логів.
- `_execute_arb`, `_record_failed`, `_expire_stale` — не пов'язані з багом.

---

## Юніт-тести (`tests/unit/test_bugN35_settlement_price.py`)

4 тести:

### Test 1: `test_bugN35_yes_won_no_lost` — YES виграв, NO програв
- `resolution_map = {"tok-yes-A": {price:"1"}, "tok-no-B": {price:"0"}}`
- Очікування: `resolved_payout_usdc = 50.0` (тільки YES плачить)
- **Без фіксу:** 100.0 (обидві ноги × 1.0) → test FAIL
- З фіксом: 50.0 → test PASS

### Test 2: `test_bugN35_no_won_yes_lost` — NO виграв, YES програв
- `resolution_map = {"tok-yes-A": {price:"0"}, "tok-no-B": {price:"1"}}`
- Очікування: `resolved_payout_usdc = 50.0` (тільки NO плачить)
- Без фіксу: 100.0 → FAIL

### Test 3: `test_bugN35_neither_won_anomalous` — обидві програли (аномалія)
- `resolution_map = {обидві price:"0"}`
- Очікування: `resolved_payout_usdc = 0.0`, `winning_leg = "neither"`
- Defensive код

### Test 4: `test_price_won_helper` — прямий тест helper
- Перевіряє: "1", "1.0", 1, 1.0, "0.999998", "1.000001" → True
- "0", "0.0", 0, 0.0, "0.01", "0.5", None, "", "not-a-number" → False

### Стратегія тестів
Mock `AsyncSessionLocal` через monkeypatch на `app.core.db` (де _maybe_settle робить lazy import). Перевіряємо `pos.resolved_payout_usdc` (встановлюється в коді) замість парсингу логів.

---

## ⚠️ КРИТИЧНЕ ПОПЕРЕДЖЕННЯ для існуючих даних

> Якщо вже є тестові `ArbPosition` записи зі `status=RESOLVED` в БД (з PAPER-тестування v1.0.90) — їхній `resolved_payout_usdc` **недостовірний** (подвоєний). Перерахувати вручну або видалити записи перед новим тестуванням.

SQL для перевірки:
```sql
SELECT id, event_title, total_cost_usdc, resolved_payout_usdc, winning_leg, resolved_at
FROM arb_positions
WHERE status = 'RESOLVED';
```
Якщо `resolved_payout_usdc ≈ 2 × expected_payout_usdc` — це фіктивні дані v1.0.90.

---

## Чесні перевірки виконані

| Перевірка | Інструмент | Результат |
|---|---|---|
| Синтаксис `arb_executor.py` | `py_compile` | ✅ OK |
| Синтаксис `test_bugN35_settlement_price.py` | `py_compile` | ✅ OK |
| Верифікація 7 тверджень хендоффа | grep + read code | ✅ All TRUE |
| `_price_won` обробляє str/int/float | code inspection | ✅ Так |
| Інші тести не зламані | grep ArbOpportunity usages | ✅ Немає залежності |

### Що НЕ перевірено (чесно)
- `pytest tests/unit/test_bugN35_settlement_price.py` — env не має fastapi/sqlalchemy. UNVERIFIED до запуску.
- Реальна PAPER-сесія з resolved arb — не запущено.

---

## POSSIBLE FAILURE POINTS

1. **Mock AsyncSessionLocal в тестах.** _maybe_settle робить lazy import `from app.core.db import AsyncSessionLocal`. Я патчу `app.core.db.AsyncSessionLocal` через monkeypatch — має спрацювати, але якщо import кешується інакше — тести можуть не ізолюватись.
2. **`Any` type hint в `_price_won`.** Імпорт `Any` з `typing` вже є в arb_executor.py (рядок 36) — перевірено.
3. **"both" winning_leg сценарій.** Для валідного time_spread arb — неможливо (монотонність гарантує одна нога YES, інша NO). Але для cross_condition з помилковим direction — може трапитись. Тепер помітно в логах.
4. **Існуючі RESOLVED записи в БД користувача.** Якщо були PAPER-тести v1.0.90 з resolution — їх payout фіктивний. Див. попередження вище.

---

## REQUIRED TESTS (після deploy)

1. **pytest:**
   ```bash
   pytest tests/unit/test_bugN35_settlement_price.py -v
   ```
   Очікування: 4/4 passed. Tests 1-2 — ключові регресій-гарди.

2. **Повний pytest:**
   ```bash
   pytest tests/unit -q
   ```
   Очікування: 118/119 (114 старих + 4 нових; 1 відомий gas-тест fail).

3. **PAPER-сесія з resolved arb:**
   - Дочекатись resolution першого OPEN arb.
   - Перевірити `arb_settled` лог: `payout` має бути ≈ `expected_payout_usdc` (не 2×).
   - SQL: `SELECT resolved_payout_usdc, expected_payout_usdc FROM arb_positions WHERE status='RESOLVED'` — мають бути ≈ рівні.

4. **НЕ вмикати LIVE** до перевірки п.3.

---

## Файли змінені/створені

| Файл | Зміна |
|---|---|
| `app/services/arb_executor.py` | +`_price_won` helper; `_maybe_settle` використовує `price` не `outcome`; `winning_leg` + "both" |
| `tests/unit/test_bugN35_settlement_price.py` | NEW — 4 юніт-тести |
| `VERSION` | 1.0.91 → 1.0.92 |
| `CHANGELOG_v1.0.92.md` | цей файл |

---

## Confidence

- **Коректність фіксу: ~98%** (баг тривіальний, фікс прозорий, верифіковано код).
- **Юніт-тести правильні: ~85%** (UNVERIFIED до pytest; mock AsyncSessionLocal може бути крихким).
- **Фікс не ламає існуюче: ~95%** (helper новий, _maybe_settle єдина точка використання).
- **Покращить accuracy P&L: 100%** (без фіксу P&L завжди фіктивний; з фіксом — коректний за визначенням).

## Признання

Цей баг — моя помилка в v1.0.90. Я написав `outcome.lower() in ("yes", "1")` замість перевірки `price`. Claude знайшов і чітко діагностував. Хендофф повністю коректний — всі 7 тверджень верифіковані. Дякую Claude за аудит.
