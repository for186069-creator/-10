# CHANGELOG v1.0.94 — Arb EXECUTION v2: bankroll split + auto-close + endpoints

**Дата:** 2026-07-07
**Попередник:** v1.0.93 (BUG-N36 opportunistic TP bid-based)
**Автор:** GLM (за запитом користувача: B+C з доповненнями — розділити bankroll, авто-закриття в плюс до resolution, опція лота)

---

## Контекст

Користувач після v1.0.93 (arb execution працює, але тримає до resolution):
> "B дає можливість вийти з arb позиції до resolution через UI. C зробить UI коректним (bankroll відображає arb $). Якщо C робить конфлікт з MM халт логікою — треба розділити. 50% банкролу в MM, 50% в arb. І опція вибрати розмір лота в arb. Бот сам автоматично торгував arb і закривав в плюс до resolution."

v1.0.94 реалізує все це.

---

## Що побудовано

### A. Bankroll split (MM vs Arb) — роздільні пули

**`app/services/inventory_manager.py`:**
- НОВЕ поле `self.arb_bankroll` (окреме від `self.bankroll`)
- На startup: `paper_balance_usdc` розподіляється за `arb_bankroll_allocation_pct` (default 50/50)
- `arb_bankroll` persisted в `InventoryState.inventories_json` з ключем `__arb_bankroll__` (без міграції)
- MM halt logic (`consecutive_losses`, `daily_loss`) використовує `self.bankroll` — **arb втрати НЕ тригерять MM halt**
- ArbExecutor використовує `inventory.arb_bankroll` — **MM втрати НЕ зупиняють arb**

**`app/core/config.py` — нове поле:**
```python
arb_bankroll_allocation_pct: float = Field(default=50.0, ge=0, le=100, alias="ARB_BANKROLL_ALLOCATION_PCT")
```

### B. Auto-close loop — автоматичне закриття в плюс ДО resolution

**`app/services/arb_executor.py` — новий `_auto_close_loop`:**
- Раз на `arb_auto_close_check_interval_sec` (default 60с)
- Для кожної OPEN ArbPosition:
  - Fetch поточна `best_bid` для YES token та NO token
  - `current_value = yes_bid × yes_tokens + no_bid × no_tokens`
  - Якщо `current_value > total_cost + arb_auto_close_min_profit_cents/100` → продати обидві ноги (FAK SELL)
  - Status = CLOSED (не RESOLVED), `winning_leg = "auto_close"`
  - `arb_bankroll += current_value`

**`app/core/config.py` — 3 нові поля:**
```python
arb_auto_close_enabled: bool = Field(default=True, alias="ARB_AUTO_CLOSE_ENABLED")
arb_auto_close_min_profit_cents: float = Field(default=1.0, ge=0.1, le=50, alias="ARB_AUTO_CLOSE_MIN_PROFIT_CENTS")
arb_auto_close_check_interval_sec: float = Field(default=60.0, ge=10, le=3600, alias="ARB_AUTO_CLOSE_CHECK_INTERVAL_SEC")
```

### C. Management endpoints

**`app/admin/api.py` — 4 нові endpoints:**

| Endpoint | Метод | Що робить |
|---|---|---|
| `/api/arb/positions` | GET | Список arb позицій з P&L (filter by status) |
| `/api/arb/exit` | POST | Ручний ранній вихід (position_id або all_open=true) |
| `/api/arb/config` | GET | Поточний конфіг + arb_bankroll/mm_bankroll стан |
| `/api/arb/config` | POST | Runtime зміна конфігу (position_size, min_edge, auto_close, allocation_pct) |

### D. ArbPosition status extended

**`app/db/models.py`:**
- `status`: OPEN | RESOLVED | **CLOSED** | EXPIRED | FAILED (CLOSED = early exit)
- `winning_leg`: 'yes' | 'no' | 'both' | 'neither' | **'auto_close'** | None

### E. Runtime-configurable (через `/arb/config` POST)

Коригувач можна міняти БЕЗ restart:
- `arb_position_size_usdc` (5-100)
- `arb_min_edge_cents_execute` (0.5-50)
- `arb_auto_close_enabled` (true/false)
- `arb_auto_close_min_profit_cents` (0.1-50)
- `arb_bankroll_allocation_pct` (0-100) — **тільки для FUTURE restart** (runtime не rebalances поточні пули)

---

## Архітектурні рішення (truth-first)

### Чому arb_bankroll ОКРЕМЕ від MM bankroll
1. **MM halt logic** (`consecutive_losses >= 5`, `daily_loss <= -max_daily_loss`) — arb не має тригерити це
2. **Arb має НІКОЛИ не мати consecutive_losses** (математично гарантований прибуток) — якщо має, то bug, не halt
3. **Розділення = ізоляція ризиків**: MM злив не зупиняє arb, arb баг не ламає MM accounting

### Чому auto-close через FAK SELL на обидві ноги
1. **FAK** (Fill-And-Kill) = immediate fill або cancel — не чекає
2. **post_only=False** — taker order, перетинає книгу
3. **Sell YES at best_bid + Sell NO at best_bid** — реалістичні ціни (як BUG-N34/N36 fix)
4. Якщо YES sold, NO failed → position FAILED з "unhedged YES exposure" (admin review)

### Чому `__arb_bankroll__` в inventories_json (не окреме поле)
1. **Без міграції** — швидко і безпечно
2. **Idempotent** — pop перед ітерацією inventories
3. **Backward-compat** — старі збережені стани (без `__arb_bankroll__`) → fallback до split на init

---

## Чесні перевірки

| Перевірка | Результат |
|---|---|
| `py_compile` config.py | ✅ OK |
| `py_compile` inventory_manager.py | ✅ OK |
| `py_compile` arb_executor.py | ✅ OK |
| `py_compile` models.py | ✅ OK |
| `py_compile` admin/api.py | ✅ OK |
| `py_compile` main.py | ✅ OK |
| `.env` має всі 13 ARB_* полів | ✅ verified |

### Що НЕ перевірено (чесно)
- `pytest` — env не має залежностей
- Реальний PAPER-запуск з v1.0.94
- `/api/arb/*` endpoints через curl
- Auto-close на реальній OPEN позиції

---

## POSSIBLE FAILURE POINTS

1. **Auto-close race з resolution loop.** Обидва loops можуть спробувати закрити ту саму позицію. Mitigation: `_close_arb_position` re-fetches з `status == "OPEN"` check (як `_maybe_settle`) — другий виклик no-op.

2. **Auto-close FAK partial fill.** PAPER short-circuit = MATCHED. LIVE FAK може partial-fill. Якщо YES partial + NO failed → accounting неточний. Для PAPER ок; для LIVE треба handling (не критично для v1.0.94 PAPER тесту).

3. **`arb_bankroll` negative.** Якщо arb втратить більше ніж має (тобто bugs) — `arb_bankroll` може стати від'ємним. Немає guard. Mitigation: `/arb/config` GET показує стан; user може зупинити.

4. **`/arb/config` POST змінює лише RAM.** Settings не persist в `.env`. Restart → повертаються старі значення. Якщо хочете persist — треба `/api/config/save_env` (вже існує для MM settings, треба розширити для arb).

5. **`bankroll_allocation_pct` runtime не rebalances.** Зміна через `/arb/config` вплине лише на FUTURE restart. Поточні `arb_bankroll`/`mm_bankroll` залишаються. Це навмисно (rebalance = переказ $ між пулами = складно).

6. **Auto-close на wide-spread arb markets.** Якщо YES_bid + NO_bid < total_cost (напр. спред розширився після open) — auto-close не спрацює, позиція чекатиме resolution. Це **правильно** — не продавати в збиток.

---

## REQUIRED TESTS (після deploy)

1. **PAPER smoke (1 год):**
   - `GET /api/arb/config` — має показати `arb_bankroll_usdc=30.0, mm_bankroll_usdc=30.0` (при $60 total, 50/50)
   - `GET /api/arb/positions` — пусто спочатку
   - Дочекатись `arb_executed` в логах → `arb_bankroll` має зменшитись на total_cost

2. **Auto-close test:**
   - Дочекатись OPEN arb позиції
   - Якщо через якийсь час YES_bid + NO_bid > total_cost + 1¢ → `arb_closed_early` в логах
   - `arb_bankroll` має збільшитись на current_value
   - Status = CLOSED

3. **Manual exit test:**
   - `POST /api/arb/exit?position_id=X` — має закрити позицію
   - `POST /api/arb/exit?all_open=true` — закрити всі OPEN

4. **Config runtime change:**
   - `POST /api/arb/config?position_size_usdc=10.0` → наступний arb використає $10/leg
   - `GET /api/arb/config` — має показати оновлене значення

---

## Файли змінені

| Файл | Зміна |
|---|---|
| `app/core/config.py` | +4 поля (arb_bankroll_allocation_pct, arb_auto_close_*) |
| `app/services/inventory_manager.py` | +arb_bankroll поле + persistence (JSON) |
| `app/services/arb_executor.py` | +set_inventory, +_auto_close_loop, +_check_auto_close_candidates, +_close_arb_position, +_mark_position_failed; bankroll checks in execute/settle |
| `app/db/models.py` | ArbPosition status: +CLOSED; winning_leg: +auto_close |
| `app/admin/api.py` | +_arb_executor global + inject; +4 endpoints (/arb/positions, /arb/exit, /arb/config GET/POST) |
| `app/main.py` | +arb_executor.set_inventory(inventory) |
| `.env` | +4 ARB_* поля (50/50 split, auto-close enabled, 1¢ profit, 60s interval) |
| `VERSION` | 1.0.93 → 1.0.94 |
| `CHANGELOG_v1.0.94.md` | цей файл |

---

## Confidence

- **Структурна коректність: ~90%** (py_compile OK, архітектура відповідає патернам)
- **Bankroll split ізоляція: ~95%** (arb_bankroll окреме поле, MM halt не зачеплено)
- **Auto-close логіка: ~85%** (FAK SELL на обидві ноги, race protection через re-fetch)
- **Endpoints: ~90%** (стандартний FastAPI pattern, validation)
- **PAPER mode: ~90%** (place_order short-circuit, ArbPosition DB update)
- **LIVE mode: ~70%** (FAK partial fill ризик, real $, required testing)

## Чесний підсумок

v1.0.94 реалізує ВСЕ, що просив користувач:
1. ✅ B — `/arb/exit` для ручного раннього виходу
2. ✅ C — bankroll синхронізовано з arb (окремий arb_bankroll)
3. ✅ Розділення 50/50 (конфігуровне через ARB_BANKROLL_ALLOCATION_PCT)
4. ✅ Опція лота (ARB_POSITION_SIZE_USDC + runtime через /arb/config)
5. ✅ Авто-закриття в плюс ДО resolution (auto_close_loop, 60s, 1¢ min profit)

MM halt logic більше НЕ конфліктує з arb — вони в різних пули. Arb автоматично закривається в плюс при нагоді (не чекає дні/тижні resolution).
