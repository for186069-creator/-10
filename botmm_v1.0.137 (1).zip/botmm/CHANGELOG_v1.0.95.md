# CHANGELOG v1.0.95 — BUG-N37 + BUG-N38: arb-lifecycle повністю заблокований

**Дата:** 2026-07-08
**Попередник:** v1.0.94 (arb execution v2)
**Автор:** GLM (за HANDOFF від Claude, 2026-07-08 — аудит v1.0.94)
**Пріоритет:** 🔴 КРИТИЧНИЙ, блокуючий — увесь N3/v2 arb execution layer нефункціональний

---

## Суть (верифіковано кодом)

### BUG-N37: `select` не імпортовано у 2 з 5 функцій

**Карта (верифіковано grep):**
```
select() використовується: рядки 193, 480, 622, 683, 794, 838
from sqlalchemy import select є (lokalno): рядки 188, 476, 679, 834, 855

Рядок 622 (_maybe_settle)        — локального імпорту НЕМАЄ ❌
Рядок 794 (_close_arb_position)  — локального імпорту НЕМАЄ ❌
Інші 4 місця                     — імпорт є ✅
```

`_maybe_settle` — єдиний шлях **природної резолюції**.
`_close_arb_position` — єдиний шлях **дострокового закриття** (v1.0.94 auto-close).

**Обидва — єдині способи, якими arb-позиція може перестати бути OPEN.** Обидва кидали `NameError: name 'select' is not defined`, спіймане широким `except Exception` → тихо логувалось як помилка → позиція залишалась OPEN назавжди.

### BUG-N38: `event=` конфліктує з structlog — 5 місць (Claude знайшов 3)

Claude згадав 3: рядки ~638, ~710, ~812 (arb_settled, arb_auto_close_opportunity, arb_closed_early).

**Я знайшов 5** — Claude пропустив 2:
- рядок 245 (`arb_execute_failed`, `_maybe_execute_pending`)
- рядок 392 (`arb_executed`, `_execute_arb`)

Всі 5 — `event=opp.event_title[:40]` або `event=fresh.event_title[:40]` → `TypeError: got multiple values for argument 'event'`.

---

## Звіт верифікації (truth-first)

| # | Твердження Claude | Статус |
|---|---|---|
| 1 | select не імпортовано в _maybe_settle (рядок 622) | ✅ TRUE |
| 2 | select не імпортовано в _close_arb_position (рядок 794) | ✅ TRUE |
| 3 | event= конфліктує з structlog у 3 місцях | ⚠️ Частково TRUE — реально 5 місць (Claude пропустив 245, 392) |
| 4 | Позиції застрягають в OPEN назавжди | ✅ TRUE (логіка: обидва шляхи виходу кидають виняток) |
| 5 | arb_bankroll тільки зменшується, не кредитується | ✅ TRUE (_execute_arb декрементить, _maybe_settle/_close_arb_position не доходять до кредитування) |
| 6 | N35 (payout calc) досі правильний | ✅ TRUE (не займав) |
| 7 | N36 (TP bid-based) досі правильний | ✅ TRUE (не займав) |
| 8 | Це не нова регресія v1.0.94 для N37 в _maybe_settle | ✅ TRUE (існував з v1.0.90) |
| 9 | N37 в _close_arb_position + всі N38 — нові в v1.0.94 | ✅ TRUE |

**Розбіжність:** Claude згадав 3 `event=`, реально 5. Я виправив усі 5.

---

## Фікс (структурний, як Claude рекомендував)

### 1. Module-level sqlalchemy imports (BUG-N37)

**Було:** `from sqlalchemy import select` розкидано по 5 функціях (з 2 пропусками).

**Стало:**
```python
# рядок 70 (module level):
from sqlalchemy import func, select, update
```

Прибрано всі 5 локальних `from sqlalchemy import ...` (рядки 188, 476, 679, 834, 855). Тепер неможливо повторення N37 — select завжди доступний у будь-якій функції модуля.

### 2. `event=` → `event_title=` у всіх 5 викликах (BUG-N38)

| Рядок (до фіксу) | Функція | Лог-подія |
|---|---|---|
| 245 | `_maybe_execute_pending` | `arb_execute_failed` |
| 392 | `_execute_arb` | `arb_executed` |
| 642 | `_maybe_settle` | `arb_settled` |
| 715 | `_check_auto_close_candidates` | `arb_auto_close_opportunity` |
| 818 | `_close_arb_position` | `arb_closed_early` |

Всі перейменовані на `event_title=` (прецедент v1.0.87).

### 3. CODING RULE коментар угорі файлу

```python
# ── CODING RULE (v1.0.95, BUG-N38) ───────────────────────────────────────
# DO NOT use `event=` as a keyword argument in log.info()/log.warning()/
# log.error()/log.debug() calls. `event` is RESERVED by structlog for the
# message text itself (first positional arg) — passing it as a kwarg raises
# TypeError: got multiple values for argument 'event'. Use `event_title=`
# or another name instead. Precedent: v1.0.87 fix for arb_opportunity_found.
```

### 4. Опційний grep-чек (рекомендація Claude)

```bash
grep -rn "log\.\(info\|warning\|error\|debug\)(" app/ | grep "event="
```
Якщо повертає щось — там потенційний баг N38-класу. Зараз повертає 0 (тільки коментар-правило).

---

## Наслідок фіксу

**До:**
- `_execute_arb` працює → гроші витрачаються з arb_bankroll
- `_maybe_settle` кидає NameError → позиція stuck OPEN
- `_close_arb_position` кидає NameError → auto-close не працює
- `arb_bankroll` тільки зменшується, ніколи не кредитується
- `/arb/positions` показує вічно OPEN позиції з фіктивним $0 P&L

**Після:**
- `_maybe_settle` працює → RESOLVED позиції, `arb_bankroll += payout`
- `_close_arb_position` працює → CLOSED позиції (auto-close), `arb_bankroll += current_value`
- Log calls не крашаться → персистенція в БД коректна
- `/arb/positions` показує реальний P&L

---

## Чесні перевірки

| Перевірка | Результат |
|---|---|
| `py_compile arb_executor.py` | ✅ OK |
| Module-level imports: select, func, update | ✅ verified via ast.parse |
| Локальних `from sqlalchemy import` = 0 | ✅ verified via grep |
| `event=` у log викликах = 0 (тільки коментар) | ✅ verified via grep |
| `event_title=` у 5 викликах | ✅ verified |
| `test_bugN35_settlement_price.py` py_compile | ✅ OK |
| `test_bugN34_loss_cents_realistic.py` py_compile | ✅ OK |

### Що НЕ перевірено (чесно)
- `pytest tests/unit/test_bugN35_settlement_price.py` — env не має fastapi/sqlalchemy. Claude каже 3 з 4 тестів падали через N37 — після фіксу мають пройти.
- Реальний PAPER-прогін з v1.0.95.

---

## POSSIBLE FAILURE POINTS

1. **test_bugN35 monkeypatching.** Тест мокає `AsyncSessionLocal` через `app.core.db`, але НЕ мокає `select`. Раніше select був локальним — тепер module-level. `select(ArbPosition).where(...)` поверне MagicMock (бо ArbPosition може бути замоканий), передається в `db.scalar(stmt)` який замоканий. П має працювати. Але якщо pytest показує інше — треба додатково замокати select.
2. **Module-level import psycopg2/sqlalchemy.** Якщо sqlalchemy не встановлено в env — import_fail при завантаженні модуля. Перевіряється: `python3 -c "from sqlalchemy import select, func, update"`.
3. **Коментар-правило не гарантує дотримання.** Розробник (вкл. я) може знову написати `event=`. Grep-чек (пункт 4) — єдина автоматична захист.

---

## REQUIRED TESTS (після deploy)

1. **pytest (якщо env дозволяє):**
   ```bash
   pytest tests/unit/test_bugN35_settlement_price.py -v
   ```
   Очікування: 4/4 passed (Claude каже 3 падали через N37 — тепер мають пройти).

2. **Grep-чек на N38:**
   ```bash
   grep -rn "log\.\(info\|warning\|error\|debug\)(" app/ | grep "event=" | grep -v "^.*#"
   ```
   Очікування: 0 рядків (тільки коментар-правило).

3. **PAPER-прогін з v1.0.95:**
   - Дочекатись `arb_executed` (куплено YES+NO)
   - Дочекатись resolution → `arb_settled` в логах (раніше не з'являлось!)
   - Або дочекатись auto-close → `arb_closed_early` в логах (раніше не з'являлось!)
   - `/api/arb/positions` → статус RESOLVED/CLOSED з реальним payout
   - `arb_bankroll` має ЗРОСТАТИ після resolution/close (раніше тільки зменшувалось)

4. **Перевірити `arb_bankroll` через `/api/arb/config` GET:**
   - Після resolution: `arb_bankroll_usdc` має зрости на ~payout
   - Після auto-close: `arb_bankroll_usdc` має зрости на ~current_value

---

## Файли змінені

| Файл | Зміна |
|---|---|
| `app/services/arb_executor.py` | module-level sqlalchemy import; 5 локальних прибрано; 5 `event=` → `event_title=`; CODING RULE коментар |
| `VERSION` | 1.0.94 → 1.0.95 |
| `CHANGELOG_v1.0.95.md` | цей файл |

---

## Confidence

- **Коректність фіксу: ~98%** (баг тривіальний, фікс прозорий, py_compile OK)
- **N37 повністю усунено: 100%** (module-level import, неможливо повторити)
- **N38 усунено у файлі: 100%** (5/5 event= перейменовано)
- **N38 усунено глобально: ~50%** (коментар + рекомендація grep, але не автоматизовано)
- **Тести пройдуть: ~85%** (UNVERIFIED до pytest; mock select може потребувати допилення)
- **PAPER resolution/close запрацює: ~90%** (структурна логіка не змінена, лише імпорти + імена параметрів)

## Признання

Це 4-й і 5-й баги в моєму arb code (після N35, N36). Клас N38 (`event=`) — мав би знати з v1.0.87 фіксу Claude (arb_opportunity_found). Не перевірив нові log calls. N37 (`select` без імпорту) — класична помилка розкиданих локальних імпортів; Claude правий, що структурне рішення (module-level) краще.

Вибачаюсь за те, що v1.0.90-94 arb execution layer був **нефункціональний** — гроші витрачались, але ніколи не повертались. Без цього фіксу весь arb direction був би зливом bankroll замість прибутку.
