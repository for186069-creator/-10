# CHANGELOG v1.0.97 — BUG-N39: AGGRESSIVE tier виконував sell у збиток

**Дата:** 2026-07-08
**Попередник:** v1.0.96 (conservative PAPER calibration)
**Автор:** GLM (за діагностикою з PAPER-логу користувача v1.0.96)
**Пріоритет:** 🔴 КРИТИЧНИЙ — "ТАК НЕ ПРИЙНЯТНО" (direct user quote)

---

## Суть бага (верифіковано з логу v1.0.96)

### З логу (11.5 хв, 14 fills, -$0.55):
```
liquidation_triggered:
  avg_entry=0.6695
  sell_price=0.679        ← PROFIT target (+0.95¢)!
  realistic_exit_price=0.661  ← LOSS fill (-0.92¢)
  loss_cents=0.85         ← збиток
  tier=AGGRESSIVE

fill: price=0.661, pnl_net=-0.0953  ← РЕАЛЬНИЙ ЗБИТОК
```

**Бот "цілиться" в profit (sell_price=0.679 > entry 0.6695), але виконує на bid (0.661 < entry) = збиток.**

Слова користувача: *"кожна угода була в плюсі а все закриваеться в мінус!"* — точно описує баг.

### 7/7 SELL = liquidation at loss
- 0 natural round_trips (знову)
- Усі 7 SELL через AGGRESSIVE/URGENT tier
- Кожен у збиток (0.7-0.9¢)
- Загалом -$0.55 за 11 хв

---

## Коренева причина

**Файл:** `app/services/market_maker.py`, `_liquidate_aged_positions`

### Ланцюг багів (контекст):
- **BUG-N34 (v1.0.91):** `loss_cents` рахувався від `sell_price` (mid) замість `realistic_exit_price` (bid). Фіксив розрахунок.
- **BUG-N36 (v1.0.93):** opportunistic TP trigger використовував mid замість bid. Фіксив trigger.
- **BUG-N39 (v1.0.97, цей):** AGGRESSIVE tier виконував sell навіть з коректним `loss_cents`, бо `max_loss_cents=4.0` допускав збитки до 4¢. Бот бачив збиток 0.85¢, але `0.85 < 4.0` → пропускав → виконував збиток.

**BUG-N34 фіксив розрахунок, НЕ виконання.** Бот коректно бачив збиток, але все одно його виконував.

---

## Фікс

### 1. Code change: AGGRESSIVE tier skips if realistic_exit < entry

`app/services/market_maker.py` рядки 2040-2061 (новий блок після loss-check):

```python
# BUG-N39 (v1.0.97): AGGRESSIVE tier must NOT execute at a loss.
# Previous code allowed losses up to max_loss_cents (4.0¢ default),
# bleeding ~0.85¢ per round trip.
# Fix: AGGRESSIVE skips if realistic_exit < avg_entry (any loss).
# Only URGENT (very stale) executes at loss as last resort.
if not is_urgent and realistic_exit_price < inv.avg_entry_price:
    log.info(
        "liquidation_skipped_loss_vs_entry",
        market=market_name, tier=tier, age_sec=...,
        avg_entry=..., realistic_exit_price=...,
        sell_price=..., loss_cents=...,
        reason="AGGRESSIVE tier: realistic_exit < entry → skip, wait for profit or URGENT",
    )
    continue
```

**Логіка:**
- AGGRESSIVE tier (age 180-1800с): `realistic_exit < entry` → SKIP, чекай
- URGENT tier (age >1800с): виконує навіть у збиток (last resort, free capital)
- Position чекає або до profit (bid ≥ entry), або до URGENT (30 хв)

### 2. Config changes (.env)

| Параметр | Було | Стало | Причина |
|---|---|---|---|
| `INVENTORY_LIQUIDATION_URGENT_AGE_SEC` | 360 (6 хв) | **1800 (30 хв)** | Більше часу позиції відновитись до forced loss |
| `INVENTORY_LIQUIDATION_MAX_LOSS_CENTS` | 4.0 | **1.0** | Стріше (URGENT bypass, але для edge cases) |

---

## Очікувана поведінка після фіксу

### До (v1.0.96):
- BUY 0.6702 → 180с → AGGRESSIVE → sell at 0.661 → **-$0.09 збиток**
- 7 round trips × -$0.08 = -$0.55

### Після (v1.0.97):
- BUY 0.6702 → 180с → AGGRESSIVE → `realistic_exit=0.661 < entry=0.6702` → **SKIP**
- Чекаємо до 1800с (30 хв):
  - Якщо bid підніметься до ≥0.6702 → AGGRESSIVE виконає в profit
  - Якщо ні → URGENT at 1800с виконає в збиток (last resort)
- Менше round trips, але кожен або profit, або last-resort URGENT

---

## Чесні перевірки

| Перевірка | Результат |
|---|---|
| `py_compile market_maker.py` | ✅ OK |
| `.env` має URGENT=1800, MAX_LOSS=1.0 | ✅ verified |
| AGGRESSIVE skip logic в коді | ✅ verified (рядки 2040-2061) |
| Інші налаштування не зачеплені | ✅ verified |

### Що НЕ перевірено (чесно)
- Реальний PAPER-прогін з v1.0.97
- Чи позиції відновлюються до profit за 30 хв (гіпотеза)

---

## POSSIBLE FAILURE POINTS

1. **URGENT все одно виконує в збиток.** Якщо позиція не відновилась за 30 хв → URGENT змикає у збиток. Це last resort, але збиток буде. Мінімізовано часом (30 хв замість 6 хв).
2. **Stuck positions.** Якщо bid завжди < entry → позиція чекає 30 хв, потім URGENT у збиток. Більше stuck time = більше opportunity cost.
3. **opportunistic_profit_take (v1.0.93) все ще 0.** TP trigger теж перевіряє `realistic_exit ≥ entry + 3¢`. Якщо bid ніколи не дає +3¢ → TP не спрацює. Але це правильно — не "брати прибуток" якого немає.
4. **Arb execution паралельно.** Arb не зачеплений, працює незалежно зі своїм bankroll.
5. **0 round_trips може залишитись.** Природний SELL fill at ASK (89.9% YES BUY активності) все ще не трапляється — adverse selection. Але принаймні AGGRESSIVE не зливатиме 0.85¢ за round trip.

---

## REQUIRED TESTS (після deploy)

1. **PAPER-сесія 1-2 год з v1.0.97:**
   - `liquidation_skipped_loss_vs_entry` — має з'являтись (AGGRESSIVE skip)
   - `liquidation_triggered` з `tier=AGGRESSIVE` — має бути РІДШЕ (тільки profit)
   - `liquidation_triggered` з `tier=URGENT` — може з'являтись (30 хв stale)
   - P&L — має бути **менший збиток** (або навіть profit, якщо bid відновлюється)

2. **Перевірити round_trip count:**
   ```bash
   grep -c "liquidation=False" bot.log  # natural SELL fills
   ```
   Мета: >0 (природний round_trip)

3. **Якщо P&L все ще мінус:**
   - Перевірити чи URGENT домінує (позиції не відновлюються за 30 хв)
   - Можливо треба збільшити URGENT age до 3600с (1 год)
   - Або adverse selection непереборний → arb direction єдиний

---

## Файли змінені

| Файл | Зміна |
|---|---|
| `app/services/market_maker.py` | +AGGRESSIVE skip-if-loss logic (рядки 2040-2061) |
| `.env` | URGENT 360→1800, MAX_LOSS 4.0→1.0 |
| `VERSION` | 1.0.96 → 1.0.97 |
| `CHANGELOG_v1.0.97.md` | цей файл |

---

## Confidence

- **Коректність фіксу: ~95%** (логіка прозора, py_compile OK)
- **Зменшить збиток: ~90%** (AGGRESSIVE більше не зливає 0.85¢/round trip)
- **Round_trip > 0 з'явиться: ~40%** (adverse selection все ще працює)
- **P&L стане profit: ~30%** (adverse selection домінує на niche ринках)

## Признання

Це 6-й баг поспіль у моєму arb/MM code (N34, N35, N36, N37, N38, N39). Усі одного класу: **неконсистентність між "що перевіряємо" (mid/optimistic) і "що реально" (bid/realistic)**. BUG-N34 фіксив розрахунок loss_cents, але не виконання. Мав би побачити N39 одразу при N34. Вибачаюсь.

Ваші слова "ТАК НЕ ПРИЙНЯТНО" — справедливі. Бот не має виконувати sell у збиток, коли цільова ціна profit. Тепер не буде.
