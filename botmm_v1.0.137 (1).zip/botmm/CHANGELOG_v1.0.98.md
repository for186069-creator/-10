# CHANGELOG v1.0.98 — BUG-N40: crossed quotes (bid > ask) на дашборді

**Дата:** 2026-07-08
**Попередник:** v1.0.97 (BUG-N39 AGGRESSIVE skip-at-loss)
**Автор:** GLM (за діагностикою з скріншотів користувача ААА.png, ВВ.png)
**Пріоритет:** 🔴 КРИТИЧНИЙ — бот розміщував quote що купує дорожче ніж продає

---

## Суть бага (верифіковано з скріншотів)

### Зображення користувача (ААА.png, ВВ.png) — Active Quotes дашборду:

VLM (glm-4.6v) прочитав таблицю:
```
Row 1: BID=0.1980 (green) | ASK=0.1910 (red) | OUR=-0.70¢ | OPT=11.00¢ | Active
Row 2: BID=0.7980 (green) | ASK=0.7950 (red) | OUR=-0.30¢ | OPT=12.00¢ | Active
```

**Слова користувача:** *"ЦЕ ШО НАШ СПРЕД -0.7? МІНУС 0.7?"*

`our_spread_cents = (ask_price - bid_price) * 100`
- Row 1: (0.1910 - 0.1980) × 100 = **-0.70¢** ← CROSSED (bid > ask)
- Row 2: (0.7950 - 0.7980) × 100 = **-0.30¢** ← CROSSED

**Crossed quote = бот купує по 0.1980, продає по 0.1910 = гарантований збиток 0.70¢/токен якщо обидві ноги заповняться.**

---

## Коренева причина

**Файл:** `app/services/market_maker.py`, рядки 1166-1197

Код "aged ask lowering" (v1.0.38) знижує `ask_price` для застарілих позицій:
```python
# Very aged: sell at market_bid + 0.001
aggressive_ask = min(book.best_bid + 0.001, book.best_ask - 0.001)
ask_price = aggressive_ask  # рядок 1184

# Aged: lower ask toward market bid
target_aggressive = book.best_bid + (book.spread * 0.25)
ask_price = target_aggressive  # рядок 1190
```

**Проблема:** цей код НЕ перевіряє чи новий `ask_price > bid_price`. Якщо market зрухнувся (bid впав), але наш `bid_price` залишився високим з початкового розрахунку → `ask_price` знижується нижче `bid_price` → CROSSED.

Сценарій:
- Початково: market_bid=0.20, market_ask=0.21 → target_bid=0.198, target_ask=0.202 (не crossed)
- Market зрухнувся: market_bid=0.190, market_ask=0.192
- Position very_aged → aggressive_ask = min(0.191, 0.191) = 0.191
- `ask_price = 0.191`, `bid_price = 0.198` (не змінено) → **CROSSED -0.70¢**

---

## Фікс

`app/services/market_maker.py` рядки 1199-1221 (новий блок після aged lowering):

```python
# BUG-N40 (v1.0.98): prevent CROSSED quotes.
# The aged-ask-lowering logic above can push ask_price below
# bid_price (e.g. market moved, bid stayed at original high).
# Crossed quote = bot buys higher than it sells = guaranteed
# loss if both legs fill. User dashboard showed -0.70¢ spread.
# Fix: if ask ≤ bid after lowering, block the ask entirely.
# Position will be handled by _liquidate_aged_positions (which
# v1.0.97 BUG-N39 fix ensures doesn't execute at loss unless URGENT).
if (
    ask_price is not None
    and bid_price is not None
    and ask_price <= bid_price
):
    log.warning(
        "ask_blocked_crossed_quote",
        market=market_name[:30],
        level=level_idx,
        bid_price=round(bid_price, 4),
        ask_price=round(ask_price, 4),
        crossed_cents=round((bid_price - ask_price) * 100, 2),
        reason="ask lowering would cross bid → block ask, let liquidation loop handle",
    )
    ask_price = None
```

**Логіка:**
- Якщо після lowering `ask_price ≤ bid_price` → `ask_price = None` (не розміщувати ask)
- Position лишається відкритою, обробляється `_liquidate_aged_positions`
- v1.0.97 BUG-N39 гарантує: AGGRESSIVE не виконує sell у збиток (тільки URGENT через 30 хв)

---

## Зв'язок з попередніми фіксами

| Баг | Фікс | Що |
|---|---|---|
| BUG-N34 (v1.0.91) | loss_cents розрахунок від realistic_exit | розрахунок |
| BUG-N36 (v1.0.93) | TP trigger від realistic_exit | trigger |
| BUG-N39 (v1.0.97) | AGGRESSIVE skip if realistic < entry | виконання liquidation |
| **BUG-N40 (v1.0.98)** | **crossed quote prevention** | **quote placement** |

Усі 4 баги одного класу: **неконсистентність між mid-based розрахунком та bid-based реальністю**. BUG-N40 — в черговому місці (quote placement loop, не liquidation loop).

---

## Чесні перевірки

| Перевірка | Результат |
|---|---|
| `py_compile market_maker.py` | ✅ OK |
| VLM читання ААА.png | ✅ crossed -0.70¢ підтверджено |
| VLM читання ВВ.png | ✅ crossed -0.30¢ підтверджено |
| Код crossed-quote check додано | ✅ рядки 1199-1221 |
| Новий log event `ask_blocked_crossed_quote` | ✅ |

### Що НЕ перевірено (чесно)
- Реальний PAPER-прогін з v1.0.98
- Чи `ask_blocked_crossed_quote` з'являється в логах (має, якщо bug тригериться)

---

## Очікувана поведінка після фіксу

### До (v1.0.97):
- Aged position → ask lowering → crossed quote → bot купує 0.198, продає 0.191 → **-0.70¢ збиток**

### Після (v1.0.98):
- Aged position → ask lowering → `ask_price=0.191 ≤ bid_price=0.198` → **ask_price = None** (блок)
- Position лишається, обробляється liquidation loop
- Liquidation loop (v1.0.97): AGGRESSIVE skip if realistic < entry, чекає до URGENT (30 хв)
- Дашборд: OUR покаже "—" (ask blocked), не -0.70¢

---

## POSSIBLE FAILURE POINTS

1. **Ask blocked = позиція не закривається через quote loop.** Position чекає liquidation loop (10с интервал). Якщо liquidation skip (BUG-N39) → position stale до URGENT (30 хв). Більше stuck time, але без crossed quotes.
2. **Bid все ще високий.** Якщо market впав, наш bid 0.198 не конкурентний — ніхто не продасть нам по 0.198. Position не відкриє нові longs (бо bid не fill), але існуюча position застрягла.
3. **Cancel stale quotes.** Quote скасовується при `age > 10` або `drift > threshold`. Тобто через 10с quote буде скасовано, новий quote розміщено з актуальним market. Crossed не повинен тривати довго.
4. **Opportunistic TP (v1.0.93) все ще 0.** TP trigger перевіряє `realistic_exit ≥ entry + 3¢`. Якщо bid ніколи не дає +3¢ → TP не спрацює. Але це правильно.

---

## REQUIRED TESTS (після deploy)

1. **PAPER-сесія з v1.0.98:**
   - `ask_blocked_crossed_quote` в логах — має з'являтись (bug тригериться)
   - Дашборд "OUR" — **НЕ має показувати -0.70¢** (має бути "—" або позитивне)
   - `quote_placed` з `our_spread_cents` — має бути ≥ 0 (не від'ємне)

2. **Перевірити P&L:**
   - Має покращитись (немає crossed quote = немає гарантованого збитку)
   - Але round_trip все ще може бути 0 (adverse selection)

3. **Grep verification:**
   ```bash
   grep "our_spread_cents=-" bot.log  # має бути 0 (не від'ємних)
   ```

---

## Файли змінені

| Файл | Зміна |
|---|---|
| `app/services/market_maker.py` | +crossed quote prevention (рядки 1199-1221) |
| `VERSION` | 1.0.97 → 1.0.98 |
| `CHANGELOG_v1.0.98.md` | цей файл |

---

## Confidence

- **Коректність фіксу: ~95%** (логіка прозора, py_compile OK)
- **Crossed quotes зникнуть: 100%** (за визначенням — ask blocked if ≤ bid)
- **P&L покращиться: ~80%** (немає crossed = немає гарантованого збитку)
- **Round_trip > 0: ~40%** (adverse selection все ще працює)

## Признання

Це **7-й баг поспіль** одного класу (N34/N35/N36/N37/N38/N39/N40): неконсистентність mid vs bid. Цей — в quote placement loop, не liquidation. Ваші скріншоти зловили його прямо. Вибачаюсь — мав би перевіряти quote placement коли фіксив liquidation.

Ваше око зловило баг, який я пропустив у коді. Дякую за скріншоти — без них не знайшов би.
