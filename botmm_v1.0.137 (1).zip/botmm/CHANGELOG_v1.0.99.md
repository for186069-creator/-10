# CHANGELOG v1.0.99 — Dashboard transparency: показати ВСЕ

**Дата:** 2026-07-08
**Попередник:** v1.0.98 (BUG-N40 crossed quote prevention)
**Автор:** GLM (за вимогою користувача: "дашбоард має показувати те що зараз ще і ціну нашого спреду! щоб я бачив усе!")

---

## Що змінилось

### Было (v1.0.98): 8 колонок, "—" приховує інформацію
```
Market | Lvl | Bid | Ask | Our | Opt | Status | Age
Will…  | L1  | 0.1980 | 0.1910 | -0.70¢ | 11.00¢ | Active | 1.6s
Will…  | L1  | 0.7980 | BLOCKED | — | 12.00¢ | Buy only | 5.1s
```
При crossed quote — видно -0.70¢, але при blocked ask — "—" приховує чому.

### Стало (v1.0.99): 13 колонок, повна прозорість
```
Market | Lvl | Our Bid | Our Ask | Our Spread | Mkt Bid | Mkt Ask | Entry | Real Exit | Real P&L | Opt | Status | Age
Will…  | L1  | 0.1980  | 0.1910  | -0.70¢⚠   | 0.1900  | 0.1950  | 0.1870 | 0.1910    | +0.40¢   | 11.00¢ | ⚠ CROSSED | 1.6s
Will…  | L1  | 0.7980  | BLOCKED | —          | 0.7900  | 0.7950  | 0.7990 | —         | —        | 12.00¢ | Buy only  | 5.1s
```

---

## Нові колонки (7 додано)

| Колонка | Колір | Що показує |
|---|---|---|
| **Our Spread** | 🔴 bold red (crossed) / 🟢 green (positive) | (ask - bid) × 100. Від'ємне = CROSSED |
| **Mkt Bid** | cyan | Реальний best_bid з книги (не наш) |
| **Mkt Ask** | cyan | Реальний best_ask з книги (не наш) |
| **Entry** | yellow | avg_entry_price позиції (якщо відкрита) |
| **Real Exit** | cyan | min(our_ask, market_bid+0.001) — реальна ціна виконання |
| **Real P&L** | 🟢 bold green (profit) / 🔴 bold red (loss) | (real_exit - entry) × 100 ¢ |
| **Status** | ⚠ CROSSED (red bold) | Новий статус коли spread < 0 |

---

## Backend changes (`market_maker.py` quotes_detail)

Додано 7 полів в `/quotes` API response:

```python
"market_bid": round(self.clob.books[q.token_id].best_bid, 4) if ... else None,
"market_ask": round(self.clob.books[q.token_id].best_ask, 4) if ... else None,
"market_spread_cents": round(self.clob.books[q.token_id].spread * 100, 2) if ... else None,
"avg_entry_price": round(self.inventory.get_inventory(q.token_id).avg_entry_price, 4) if net_tokens != 0 else None,
"net_tokens": round(self.inventory.get_inventory(q.token_id).net_tokens, 2),
"realistic_exit_price": round(min(q.ask_price, market_bid + 0.001), 4) if ask is not None else None,
"realistic_profit_cents": round((realistic_exit - avg_entry) * 100, 2) if ask is not None and position open else None,
```

## Frontend changes (`index.html`)

- Header: 8 → 13 колонок
- Row template: переписаний з color-coding
- `our_spread_cents < 0` → 🔴 bold red + статус "⚠ CROSSED"
- `realistic_profit_cents > 0` → 🟢 bold green
- `realistic_profit_cents < 0` → 🔴 bold red
- colspan "No active quotes": 8 → 13

---

## Що тепер ВИДИМО (ваші приклади)

### Crossed quote (як на ААА.png):
```
Our Bid=0.1980 | Our Ask=0.1910 | Our Spread=-0.70¢⚠ | ⚠ CROSSED
```
→ Одразу видно: бот купує дорожче ніж продає.

### Blocked ask (v1.0.98 fix спрацював):
```
Our Bid=0.1980 | Our Ask=BLOCKED | Mkt Bid=0.1900 | Real Exit=— | Real P&L=—
```
→ Видно чому blocked: ask would cross bid (0.1900+0.001=0.1910 < bid 0.1980).

### Position in profit:
```
Entry=0.1870 | Real Exit=0.1910 | Real P&L=+0.40¢ (green)
```
→ Видно: якщо sell filled зараз — +0.40¢ profit.

### Position in loss:
```
Entry=0.1990 | Real Exit=0.1910 | Real P&L=-0.80¢ (red)
```
→ Видно: якщо sell filled зараз — -0.80¢ loss. AGGRESSIVE skip (v1.0.97).

---

## Чесні перевірки

| Перевірка | Результат |
|---|---|
| `py_compile market_maker.py` | ✅ OK |
| HTML: 13 th в header | ✅ verified |
| HTML: colspan=13 | ✅ verified |
| HTML: ourSpreadColor × 4 references | ✅ |
| HTML: realistic_exit_price × 3 references | ✅ |
| HTML: market_bid × 3 references | ✅ |

### Що НЕ перевірено (чесно)
- Реальний рендер в браузері (потрібен ваш PAPER-запуск)
- Чи всі кольори видно (залежить від CSS variables — green/red/yellow/cyan мають бути визначені)

---

## POSSIBLE FAILURE POINTS

1. **CSS variables не визначені.** `var(--cyan)`, `var(--yellow)` — перевірити що існують в :root. Якщо ні — текст буде default color.
2. **Таблиця може бути широкою.** 13 колонок —可能 не влізає в мобільний viewport. Горизонтальний scroll має працювати (`.scroll-list`).
3. **Realistic P&L = null коли no position.** Якщо bot не має position на цьому ринку — `avg_entry_price=null` → `realistic_profit_cents=null` → "—". Це правильно (нема позиції = нема P&L).
4. **Market bid/ask може змінюватись між API calls.** Quote може бути розміщена з market_bid=0.20, а через 1с market_bid=0.19. Dashboard показує актуальний market_bid (рефетчиться).

---

## REQUIRED TESTS (після deploy)

1. **Відкрити дашборд:**
   - 13 колонок видимі
   - Кольори: green (bid/profit), red (ask/loss/crossed), yellow (entry), cyan (market)
   - Crossed quote показує "⚠ CROSSED" статус + -0.70¢ bold red

2. **Перевірити при blocked ask:**
   - Our Ask = "BLOCKED"
   - Real Exit = "—"
   - Real P&L = "—"
   - Status = "Buy only" або "⚠ CROSSED" (залежить від причини)

3. **Перевірити при active position:**
   - Entry показує avg_entry_price (yellow)
   - Real Exit показує realistic_exit_price (cyan)
   - Real P&L показує +X.XX¢ (green) або -X.XX¢ (red)

---

## Файли змінені

| Файл | Зміна |
|---|---|
| `app/services/market_maker.py` | +7 полів в quotes_detail response |
| `app/static/index.html` | 13 колонок + color-coding + ⚠ CROSSED status |
| `VERSION` | 1.0.98 → 1.0.99 |
| `CHANGELOG_v1.0.99.md` | цей файл |

---

## Confidence

- **Backend: ~95%** (py_compile OK, поля стандартні)
- **Frontend: ~85%** (HTML structure verified, але рендер в браузері UNVERIFIED)
- **Кольори: ~90%** (CSS variables мають бути визначені — green/red/yellow використовувались раніше)
- **Юзербілність: ~90%** (всі дані видимі, але 13 колонок може бути тісно)

## Признання

Ви праві — "—" приховувало інформацію. Тепер дашборд показує ВСЕ: ціну нашого спреду, ринкові ціни, entry, реальну ціну виходу, реальний P&L. Кольори роблять це читабельним. Якщо crossed quote з'явиться знову — побачите одразу.
