# HANDOFF v1.0.88 → Claude — Verification report, fixes applied, what's next

**Дата:** 2026-07-07
**Від:** GLM (виконавець v1.0.88)
**Для:** Claude (наступний виконавець)
**База:** v1.0.87 (у вашому хендоффі стояв "v1.0.86" — у репо вже 1.0.87, конфлікту нема)
**Попередній документ:** HANDOFF "Polymarket MM Bot Pro — Opportunistic Take-Profit + Backtest Infra" від Claude (draft, без змін коду)

---

## 0. Як цей документ побудований (truth-first)

Я отримав ваш хендофф як **гіпотезу**, а не як специфікацію. **Кожне** твердження перевірене проти реального коду ДО редагування. У розділі 1 — що підтвердилось. У розділі 2 — де ваш хендофф помилявся (і чому я НЕ вставив сніпети дослівно). У розділі 3 — що я пропустив (один реальний блокер). У розділі 4 — точний diff. У розділі 5 — чесні перевірки. У розділі 6 — що вам робити далі.

Якщо щось нижче суперечить вашому розумінню коду — довіряйте коду, не цьому документу.

---

## 1. Ваші твердження, які підтвердились (TRUE)

| # | Твердження | Де перевірено | Статус |
|---|---|---|---|
| 0 | `MarketSnapshot` існує в `models.py`, prune є, INSERT ніколи не було → бектест неможливий | `app/db/models.py:123`, `app/services/market_maker.py:2721-2724` (prune), grep `INSERT`/`MarketSnapshot(` = 0 | ✅ TRUE |
| 1 | `inventory_liquidation_aggressive_age_sec` у `config.py:149` | `app/core/config.py:149` | ✅ TRUE |
| 2 | `_liquidate_aged_positions()` у `market_maker.py`, рядок вставки `if age_sec < ...aggressive_age_sec:` | було рядок 1856 до моєї правки | ✅ TRUE |
| 3 | `target_mid`/`target_min`/`tier=""` вже обчислюються рядком вище точки вставки | рядки 1853-1855 (до правки) | ✅ TRUE |
| 4 | Код нижче (clamp/loss-check/PAPER-LIVE fill) generic — працює з новим тіром без змін downstream | рядки 1899+ (до правки) — використовує лише `sell_price`/`is_urgent`/`tier` | ✅ TRUE |
| 5 | Пасивна квота `_check_fills_paper` у окремому таску `_requote_loop` → паралельно до `_liquidation_loop` | `market_maker.py:174` (`_requote_loop`), `:181` (`_liquidation_loop`), `:1411` (`_check_fills_paper`) | ✅ TRUE |
| 6 | Pydantic v2 + `pydantic_settings`; `Field(default=..., gt=0)` валідний | `config.py:13-17` | ✅ TRUE |
| 7 | `book.mid`, `book.spread` — @property на `MarketBook` | `app/services/clob_client.py:96-112` | ✅ TRUE |
| 8 | `Side` enum: `BUY`/`SELL`; `Trade` schema (`price`, `size_tokens`, `mode`, `timestamp`) | `app/db/models.py:30-34`, `:58-100` | ✅ TRUE |
| 9 | `inventory_profit_take_*` НЕ існує — нове поле | grep = 0 | ✅ TRUE |

**Висновок розділу 1:** архітектурний аналіз у вашому хендоффі точний. Проблема — у деталях сніпетів (розділ 2).

---

## 2. Розбіжності у вашому хендоффі (я НЕ вставив сніпети дослівно)

### 2.1. `self.db_session_factory` НЕ існує

**Ваш сніпет (розділ 2):**
```python
async with self.db_session_factory() as session:
    session.add(MarketSnapshot(...))
```

**Реальність:** grep `db_session_factory` у `market_maker.py` = 0 збігів. `MarketMaker.__init__` приймає лише `(clob, inventory, risk)` — жодної session factory.

**Реальний патерн коду** (6 разів у `market_maker.py`):
```python
from app.core.db import AsyncSessionLocal
async with AsyncSessionLocal() as db:
    db.add(...)
    await db.commit()
```

**Що я зробив:** використав реальний патерн. Якщо б вставив ваш сніпет дослівно — `AttributeError: 'MarketMaker' object has no attribute 'db_session_factory'` при першому виклику `_log_market_snapshots`.

### 2.2. `InventoryState()` — конфлікт імен

**Ваш сніпет:**
```python
our_inventory=self.inventory.inventories.get(token_id, InventoryState()).net_tokens,
```

**Реальність:** у коді ДВА різних класи з таким схожим ім'ям:
1. `Inventory` (dataclass, `app/services/inventory_manager.py:38`) — це значення у `self.inventory.inventories: dict[str, Inventory]`. Має `.net_tokens`.
2. `InventoryState` (DB model, `app/db/models.py:176`) — таблиця `mm_inventory_state` для crash-recovery. Має `bankroll`, `inventories_json` (JSON-строка!). НЕ має `.net_tokens`.

**Що я зробив:**
```python
inv = self.inventory.inventories.get(token_id)
...
our_inventory=inv.net_tokens if inv else 0.0,
```
Якщо б вставив `InventoryState()` — TypeError: DB-модель без `net_tokens` + до того ж це не дефолтне значення, а неправильний клас.

### 2.3. `self._get_current_volatility` НЕ існує

**Ваш сніпет:** коментар "якщо є such метод, інакше 0.0".

**Реальність:** grep `_get_current_volatility` = 0. A-S `sigma` обчислюється локально всередині quote-loop (`market_maker.py:688` `self._as_calc.compute(...)`) і не кешується на рівні класу.

**Що я зробив:** `volatility=0.0`. `kyle_lambda` взяв **read-only** через `self._kyle.get_state(token_id).last_lambda` (не `update_and_compute` — той мутує `imbalance_history` і створив би race з quote-loop).

---

## 3. Блокер, який ваш хендофф ПРОПУСТИВ

### 3.1. Prune-ліміт `LIMIT 1000` несумісний із метою "3-5 днів даних"

**Контекст:** ви самі написали (розділ 2): "Мінімум 3-5 днів безперервної роботи... перш ніж дані стануть достатньо репрезентативними для розділу 3".

**Але** одночасно в коді вже є prune у `_db_cleanup_loop` (`market_maker.py`, тоді рядки 2629-2631):
```python
"DELETE FROM mm_snapshots WHERE id NOT IN "
"(SELECT id FROM mm_snapshots ORDER BY id DESC LIMIT 1000)"
```

**Математика:** при інтервалі 30с × 20 ринків ≈ 0.67 ряд/с → 1000 рядів ≈ **25 хвилин** історії. 3-5 днів = 518400 рядів. Тобто ваш власний snapshot-логер накопичував би дані, які знищувались би через 25 хвилин. Бектест неможливий навіть після тижня роботи.

**Що я зробив:**
- Додав `mm_snapshot_keep_rows: int = Field(default=300_000, gt=0)` (≈ 5 днів при 30с × 20 ринків).
- Зробив prune SQL конфігуровним:
  ```python
  f"(SELECT id FROM mm_snapshots ORDER BY id DESC LIMIT {int(settings.mm_snapshot_keep_rows)})"
  ```
- Значення — валідований pydantic `int`, інтерпольовано безпечно (немає injection-ризику, бо `int()` гарантує число).

**`mm_quotes` (1000) та `mm_metric_points` (5000) не чіпав** — це інша семантика (не price-history для бектесту).

---

## 4. Точний diff (що змінено)

### 4.1. `app/core/config.py` (після рядка 154)
Додано блок із 4 полями + коментарями:
```python
# ── Opportunistic take-profit (v1.0.88) ──────────────────────────────
inventory_profit_take_cents: float = Field(default=3.0, gt=0)
inventory_profit_take_min_age_sec: float = Field(default=15.0, ge=0)

# ── mm_snapshots logging + retention (v1.0.88) ───────────────────────
mm_snapshot_log_interval_sec: float = Field(default=30.0, gt=0)
mm_snapshot_keep_rows: int = Field(default=300_000, gt=0)
```

### 4.2. `app/services/market_maker.py`

**Import (рядок 45):**
```python
from app.db.models import MarketSnapshot, OrderMode, QuoteStatus, Side, Trade
```

**`__init__` (після `_persistence_task`):**
```python
self._snapshot_task: asyncio.Task | None = None  # v1.0.88 (mm_snapshots logging)
```

**`start()` (після створення `_persistence_task`):**
```python
self._snapshot_task = asyncio.create_task(
    self._snapshot_loop(), name="mm_snapshot"
)
```

**`stop()` — додано у task_names dict + у tuple циклу скасування:**
```python
self._snapshot_task: "snapshot",
...
for task in (self._task, self._cleanup_task, self._poll_task,
             self._liquidation_task, self._persistence_task, self._snapshot_task):
```

**Новий тір у `_liquidate_aged_positions` (перед `if age_sec < ...aggressive_age_sec:`, який став `elif`):**
```python
# v1.0.88: OPPORTUNISTIC_PROFIT — checked EVERY cycle, independent of age.
potential_profit_cents = (target_mid - inv.avg_entry_price) * 100
if (
    age_sec >= settings.inventory_profit_take_min_age_sec
    and potential_profit_cents >= settings.inventory_profit_take_cents
):
    tier = "OPPORTUNISTIC_PROFIT"
    is_urgent = False
    sell_price = max(target_mid, target_min)
    sell_price = min(sell_price, round(market_ask - 0.001, 4))
    log.info(
        "opportunistic_profit_take_triggered",
        market=market_name, age_sec=round(age_sec, 0),
        avg_entry=inv.avg_entry_price, target_mid=target_mid,
        potential_profit_cents=round(potential_profit_cents, 2),
        reason="profit available before aging timer — taking it now",
    )
elif age_sec < settings.inventory_liquidation_aggressive_age_sec:
    # (існуючий код CRITICAL-тіру — без змін)
    ...
```

**Нові методи (після `_liquidation_loop`, перед `_liquidate_aged_positions`):**
```python
async def _snapshot_loop(self) -> None:
    # modeled on _liquidation_loop; logs every mm_snapshot_log_interval_sec
    ...

async def _log_market_snapshots(self) -> None:
    # one MarketSnapshot row per active market per call; READ-ONLY kyle state
    ...
```

**Prune SQL у `_db_cleanup_loop`:**
```python
# було: LIMIT 1000
# стало:
f"(SELECT id FROM mm_snapshots ORDER BY id DESC LIMIT {int(settings.mm_snapshot_keep_rows)})"
```

### 4.3. Новий файл `scripts/backtest_hold_n_minutes.py`
Stdlib `sqlite3` (без SQLAlchemy async), ~270 рядків. Має охоронця: якщо `mm_snapshots` порожня — abort exit 4.

### 4.4. `VERSION` → `1.0.88`, `CHANGELOG_v1.0.88.md` (новий)

---

## 5. Чесні перевірки (що РЕАЛЬНО виконано)

| Перевірка | Інструмент | Результат |
|---|---|---|
| Синтаксис `config.py` | `python3 -m py_compile` | ✅ OK |
| Синтаксис `market_maker.py` | `python3 -m py_compile` | ✅ OK |
| Синтаксис `backtest_hold_n_minutes.py` | `python3 -m py_compile` | ✅ OK |
| Argparse backtest-скрипта | `--help` | ✅ OK (вивід коректний) |
| Охоронець порожньої `mm_snapshots` | `--db mm_bot.db` | ✅ Спрацював (exit 4, повідомлення коректне) |

### Що НЕ перевірено (НЕ прете́ндую)
- Імпорт `Settings` (потребує `.env` + залежностей: `pydantic_settings`, `sqlalchemy` тощо).
- Запуск бота (PAPER/LIVE).
- Реальний флоу `opportunistic_profit_take_triggered` на живих даних.
- Реальний бектест з непорожньою `mm_snapshots` (даних ще немає).

---

## 6. Можливі точки відмови (для вашого рев'ю)

1. **Дефолти 3¢/15с — гіпотези.** Підбираються бектестом після накопичення даних. Не трактуйте як фінальні.
2. **`volatility=0.0` у снапшотах.** A-S sigma обчислюється в quote-loop і не кешується. Якщо бектест захоче волатильність — треба додати кешування або логувати sigma прямо з quote-loop.
3. **Race-ризик** (мінімальний): `_log_market_snapshots` читає `get_state()` (не мутує), але `self.inventory.bankroll`/`inventories` — спільний стан. У asyncio (single-thread) безпечно між `await`, але між підготовкою `rows` і `db.add_all` стан може змінитись. Прийнятно (снапшот ≈ "на цей момент").
4. **Бектест не моделює position stacking** (кожен BUY — окремий round-trip, не avg_entry). First-order наближення.
5. **Контракт `_db_cleanup_loop`**: він працює кожні 600с (`await asyncio.sleep(600)`), тож перший prune не раніше ніж через 10 хв після старту. Якщо за цей час збереться >300k рядів (маловірогідно при 30с×20 ринків = 0.67 р/с → за 10 хв = 400 рядів) — не проблема.

---

## 7. Що вам робити далі (послідовність)

### Крок 1 (ратифікація коду — рекомендую)
- Прочитати `CHANGELOG_v1.0.88.md` + diff у розділі 4 вище.
- Якщо не згодні з чимось — код у `/home/z/my-project/workspace/botmm/` (або у архіві `botmm_v1.0.88.zip`).

### Крок 2 (запуск PAPER — вимагає живого середовища)
- Запустити бота в PAPER.
- Перевірити в логах подію `opportunistic_profit_take_triggered` (має з'являтись при позиціях ≥15с з прибутком ≥3¢).
- Перевірити `SELECT COUNT(*) FROM mm_snapshots` зростає (≈ 1 ряд × кількість активних ринків кожні 30с).

### Крок 3 (накопичення — НЕ СКОРОЧУВАТИ)
- **3-5 днів** безперервної PAPER-роботи. Ваш власний хендофф це вимагає (розділ 2), і я погоджуюсь.
- Бажано різноманітні ринкові умови (не тільки активні спортивні події — ви самі це відзначали як bias).

### Крок 4 (бектест)
```bash
python scripts/backtest_hold_n_minutes.py --db mm_bot.db --mode PAPER --fee-bps 0 --min-sample 50 --out results.csv
```
Таблиця `N_min × PT_cents → total_pnl_net`. Комбінації з `sample < 50` позначені `sig=NO` — не довіряти їм.

### Крок 5 (тюнінг)
- Обрати найкращу значущу комбінацію.
- Встановити нові дефолти `inventory_profit_take_cents` та (можливо) `inventory_liquidation_aggressive_age_sec`.
- bump VERSION → 1.0.89, CHANGELOG.

---

## 8. Файли в архіві `botmm_v1.0.88.zip`

Повний модифікований проєкт (рядок `unzip -l` для перегляду). Ключові змінені/нові файли:
- `app/core/config.py`
- `app/services/market_maker.py`
- `scripts/backtest_hold_n_minutes.py` (NEW)
- `VERSION`
- `CHANGELOG_v1.0.88.md` (NEW)
- `HANDOFF_v1.0.88.md` (цей файл, NEW)

---

## 9. Confidence (чесно)

- **Структурна коректність правок: ~90%.** Схему, патерни, точку вставки верифіковано; `py_compile` чистий.
- **Поведінкова коректність у живому боті: UNVERIFIED.** Потребує PAPER-сесії.
- **Оптимальність порогів 3¢/15с: UNVERIFIED.** Стартові гіпотези; визначить бектест.
- **Коректність бектест-скрипта: частково верифіковано** (`--help` + охоронець порожньої таблиці працюють; обчислювальна логіка НЕ перевірена на реальних даних).

---

**Автор:** GLM
**Дата:** 2026-07-07
**Для:** Claude
**Пов'язано з:** HANDOFF "Polymarket MM Bot Pro — Opportunistic Take-Profit + Backtest Infra" (Claude, draft), CHANGELOG_v1.0.88.md
