"""v1.0.90 (N3): arb_positions table for arbitrage execution layer.

Tracks executed arb positions (bought YES of one market + NO of another
correlated market). Holds until resolution, then settles.

Revision ID: 002
Revises: 001
Create Date: 2026-07-07

"""
from __future__ import annotations

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

# revision identifiers
revision: str = "002"
down_revision: Union[str, Sequence[str], None] = "001"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "arb_positions",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("event_slug", sa.String(), nullable=False),
        sa.Column("event_title", sa.String(), nullable=False),
        sa.Column("arb_type", sa.String(), nullable=False),
        sa.Column("direction", sa.String(), nullable=False),
        sa.Column(
            "detected_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=False,
        ),
        # YES leg
        sa.Column("buy_yes_token_id", sa.String(), nullable=False),
        sa.Column("buy_yes_market_question", sa.String(), nullable=False),
        sa.Column("buy_yes_price", sa.Float(), nullable=False),
        sa.Column("buy_yes_size_tokens", sa.Float(), nullable=False),
        sa.Column("buy_yes_size_usdc", sa.Float(), nullable=False),
        sa.Column("buy_yes_order_id", sa.String(), nullable=True),
        # NO leg
        sa.Column("buy_no_token_id", sa.String(), nullable=False),
        sa.Column("buy_no_market_question", sa.String(), nullable=False),
        sa.Column("buy_no_price", sa.Float(), nullable=False),
        sa.Column("buy_no_size_tokens", sa.Float(), nullable=False),
        sa.Column("buy_no_size_usdc", sa.Float(), nullable=False),
        sa.Column("buy_no_order_id", sa.String(), nullable=True),
        # Economics
        sa.Column("total_cost_usdc", sa.Float(), nullable=False),
        sa.Column("expected_payout_usdc", sa.Float(), nullable=False),
        sa.Column("edge_cents_at_open", sa.Float(), nullable=False),
        # Resolution
        sa.Column("status", sa.String(), nullable=False, server_default="OPEN"),
        sa.Column("resolved_payout_usdc", sa.Float(), nullable=False, server_default="0.0"),
        sa.Column("resolved_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("winning_leg", sa.String(), nullable=True),
        sa.Column("failure_reason", sa.String(), server_default=""),
        sa.Column(
            "timestamp",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=False,
        ),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_arb_positions_event_slug", "arb_positions", ["event_slug"])
    op.create_index("ix_arb_positions_buy_yes_token_id", "arb_positions", ["buy_yes_token_id"])
    op.create_index("ix_arb_positions_buy_no_token_id", "arb_positions", ["buy_no_token_id"])
    op.create_index("ix_arb_positions_status", "arb_positions", ["status"])
    op.create_index("ix_arb_status_ts", "arb_positions", ["status", "timestamp"])


def downgrade() -> None:
    op.drop_index("ix_arb_status_ts", table_name="arb_positions")
    op.drop_index("ix_arb_positions_status", table_name="arb_positions")
    op.drop_index("ix_arb_positions_buy_no_token_id", table_name="arb_positions")
    op.drop_index("ix_arb_positions_buy_yes_token_id", table_name="arb_positions")
    op.drop_index("ix_arb_positions_event_slug", table_name="arb_positions")
    op.drop_table("arb_positions")
