"""
app/services/arb_executor.py — Arbitrage execution layer (N3, v1.0.90).

Scanner (arbitrage_scanner.py) only DETECTS opportunities. This module
EXECUTES them: buys YES of one market + NO of another correlated market,
holds both until one resolves, collects $1 payout.

WHY THIS IS NOT MM
------------------
MM profits from bid-ask spread but suffers adverse selection (informed
traders pick off stale quotes). Arb profits from PRICE INCONSISTENCY
between two correlated markets — no opinion on direction needed.

Arb invariant (time_spread, cross_condition with monotonicity):
    Yes_late + No_early < $1.00
    → buy Yes_late + buy No_early → cost < $1
    → at resolution, exactly one resolves YES → that leg pays $1
    → guaranteed profit = $1 - total_cost (per pair of shares)

LIFECYCLE
---------
1. ArbExecutor._execute_loop reads arb_scanner.opportunities every
   arb_scan_interval_sec.
2. For each opp with edge >= arb_min_edge_cents_execute, if under
   arb_max_concurrent_positions, calls _execute_arb().
3. _execute_arb: places 2 BUY orders (YES leg + NO leg), records
   ArbPosition in DB with status=OPEN.
4. _resolution_check_loop polls Gamma /events?closed=true every
   arb_resolution_check_interval_sec. For each OPEN ArbPosition,
   checks if either market resolved → settles (status=RESOLVED,
   computes payout).
5. Positions older than arb_max_position_age_sec → status=EXPIRED.

CRITICAL DESIGN CHOICES (truth-first)
-------------------------------------
- Does NOT touch InventoryManager.on_fill (would trigger MM halt logic
  on arb losses — arb is supposed to NEVER lose, but bugs happen).
  Separate accounting via ArbPosition table.
- Does NOT place orders through MarketMaker. Uses ClobService.place_order
  directly with FAK + post_only=False (taker orders, immediate fill).
- PAPER mode: place_order short-circuits to immediate MATCHED — so arb
  can be tested in PAPER without real $.
- LIVE mode: requires PRIVATE_KEY configured. NOT enabled by default
  (arb_execution_enabled=False).
- Resolution detection: NO WebSocket event for resolution. Must poll
  Gamma API. Polymarket auto-credits USDC on resolution — we only
  DETECT + compute realized P&L for accounting.

UNVERIFIED ASSUMPTIONS (honest)
-------------------------------
1. Polymarket outcomePrices: when a market resolves, outcomePrices
   becomes ["1", "0"] or ["0", "1"]. We poll Gamma /markets/{id} for
   this. NOT yet verified against real resolved market data.
2. Arb pairs are mutually exclusive at resolution: if YES_late resolves
   YES, then NO_early resolves NO (and vice versa). This holds for
   time_spread (later date ⊇ earlier date) but may NOT hold for all
   cross_condition cases. Executor checks both legs independently.
3. Min order size $5 (Polymarket hard floor) — arb_position_size_usdc
   default $5 per leg. If bankroll < $10, only 1 position possible.
"""
from __future__ import annotations

import asyncio
import json
import time
from datetime import datetime, timezone
from typing import Any

import aiohttp
from sqlalchemy import func, select, update

from app.core.config import settings
from app.core.logging import get_logger
from app.db.models import ArbPosition
from app.services.arbitrage_scanner import ArbOpportunity, arb_scanner
from app.services.clob_client import ClobService

log = get_logger(__name__)

# CODING RULE (BUG-N38): DO NOT use `event=` as keyword in log.*() calls.
# `event` is RESERVED by structlog. Use `event_title=` instead.


def _price_won(price_value: Any) -> bool:
    """BUG-N35 (v1.0.92): determine if a Polymarket outcome price means 'won'.

    Polymarket `outcomePrices` values are "1" (won) or "0" (lost) at
    resolution, but may arrive as str | int | float and with rounding
    artifacts ("0.999998", "1.0", "1.000001"). Treat any value >= 0.99 as
    a win, anything <= 0.01 as a loss, and log+return False for ambiguous
    middle values (shouldn't happen for resolved markets, but defensive).
    """
    try:
        p = float(price_value)
    except (TypeError, ValueError):
        return False
    return p >= 0.99


class ArbExecutor:
    """Execute arbitrage opportunities detected by arb_scanner.

    Two background loops:
      - _execute_loop: poll scanner.opportunities, execute new arbs.
      - _resolution_loop: poll Gamma API, settle resolved positions.
    """

    def __init__(self, clob: ClobService) -> None:
        self.clob = clob
        self._execute_task: asyncio.Task | None = None
        self._resolution_task: asyncio.Task | None = None
        self._running = False
        # Tokens already committed to OPEN arb positions (avoid double-buy).
        self._committed_tokens: set[str] = set()

    # ── Lifecycle ────────────────────────────────────────────────────────

    async def start(self) -> None:
        """Start both loops. Idempotent."""
        if self._running:
            return
        self._running = True
        self._execute_task = asyncio.create_task(
            self._execute_loop(), name="arb_execute"
        )
        self._resolution_task = asyncio.create_task(
            self._resolution_loop(), name="arb_resolution"
        )
        log.info(
            "arb_executor_started",
            mode="PAPER" if settings.paper_trading else "LIVE",
            max_concurrent=settings.arb_max_concurrent_positions,
            position_size_usdc=settings.arb_position_size_usdc,
            min_edge_execute=settings.arb_min_edge_cents_execute,
        )

    async def stop(self) -> None:
        """Cancel both loops gracefully."""
        log.info("arb_executor_stopping")
        self._running = False
        for task in (self._execute_task, self._resolution_task):
            if task:
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass
                except Exception as e:
                    log.warning("arb_executor_task_stop_error", error=str(e))
        self._execute_task = None
        self._resolution_task = None

    # ── Execute loop ─────────────────────────────────────────────────────

    async def _execute_loop(self) -> None:
        """Poll scanner opportunities, execute new arbs under concurrency cap."""
        # Wait first scan to complete (scanner starts in parallel).
        await asyncio.sleep(settings.arb_scan_interval_sec)
        while self._running:
            try:
                await self._maybe_execute_pending()
            except asyncio.CancelledError:
                raise
            except Exception as e:
                log.warning("arb_execute_loop_error", error=str(e))
            await asyncio.sleep(settings.arb_scan_interval_sec)

    async def _maybe_execute_pending(self) -> None:
        """Try to execute pending opportunities if under concurrency cap."""
        if not settings.arb_execution_enabled:
            return
        opportunities = list(arb_scanner.opportunities)
        if not opportunities:
            return

        from app.core.db import AsyncSessionLocal
        from sqlalchemy import select, func

        # Count currently OPEN positions
        async with AsyncSessionLocal() as db:
            open_count = await db.scalar(
                select(func.count(ArbPosition.id)).where(
                    ArbPosition.status == "OPEN"
                )
            )
        open_count = int(open_count or 0)
        slots_available = settings.arb_max_concurrent_positions - open_count
        if slots_available <= 0:
            return

        # Filter by execution edge threshold (stricter than detection)
        min_edge = settings.arb_min_edge_cents_execute
        candidates = [
            o for o in opportunities
            if o.edge_cents >= min_edge
            and o.market_a_no_token_id  # need NO token to execute
            and o.market_b_no_token_id
        ]

        executed = 0
        for opp in candidates:
            if executed >= slots_available:
                break
            # Skip if either token already committed to an OPEN position
            yes_token, no_token = self._resolve_tokens(opp)
            if not yes_token or not no_token:
                continue
            if yes_token in self._committed_tokens or no_token in self._committed_tokens:
                continue
            try:
                await self._execute_arb(opp, yes_token, no_token)
                executed += 1
                self._committed_tokens.add(yes_token)
                self._committed_tokens.add(no_token)
            except Exception as e:
                log.warning(
                    "arb_execute_failed",
                    event_title=opp.event_title[:40],
                    error=str(e),
                )

    def _resolve_tokens(
        self, opp: ArbOpportunity
    ) -> tuple[str, str]:
        """Return (yes_token_to_buy, no_token_to_buy) based on direction.

        direction 'buy_yes_a_buy_no_b' → YES of A + NO of B
        direction 'buy_yes_b_buy_no_a' → YES of B + NO of A
        """
        if opp.direction == "buy_yes_a_buy_no_b":
            return opp.market_a_token_id, opp.market_b_no_token_id
        if opp.direction == "buy_yes_b_buy_no_a":
            return opp.market_b_token_id, opp.market_a_no_token_id
        log.warning("arb_unknown_direction", direction=opp.direction)
        return "", ""

    async def _execute_arb(
        self,
        opp: ArbOpportunity,
        yes_token: str,
        no_token: str,
    ) -> None:
        """Place 2 BUY orders (YES leg + NO leg), record ArbPosition.

        Uses FAK (Fill-And-Kill / IOC) + post_only=False → taker orders
        that fill immediately or cancel. Same pattern as _handle_resolution_exit
        in market_maker.py:810-811.

        NO price = 1 - YES price (Polymarket invariant on same market).
        For the NO leg of the partner market, we use its YES price to
        derive: no_price = 1 - partner_yes_price.
        """
        size_usdc = settings.arb_position_size_usdc

        # Determine prices from opp (YES prices stored)
        if opp.direction == "buy_yes_a_buy_no_b":
            yes_price = opp.market_a_price
            no_price = round(1.0 - opp.market_b_price, 4)
            yes_question = opp.market_a_question
            no_question = opp.market_b_question
        else:  # buy_yes_b_buy_no_a
            yes_price = opp.market_b_price
            no_price = round(1.0 - opp.market_a_price, 4)
            yes_question = opp.market_b_question
            no_question = opp.market_a_question

        # Safety: prices must be in valid range
        if not (0.01 <= yes_price <= 0.99) or not (0.01 <= no_price <= 0.99):
            log.warning(
                "arb_execute_price_out_of_range",
                yes_price=yes_price, no_price=no_price,
            )
            return

        # Place YES leg (FAK, taker)
        yes_result = await self.clob.place_order(
            token_id=yes_token,
            side="BUY",
            price=yes_price,
            size_usdc=size_usdc,
            order_type="FAK",
            post_only=False,
        )
        if not yes_result.success:
            log.warning(
                "arb_yes_leg_failed",
                token=yes_token[:12], price=yes_price, error=yes_result.error,
            )
            await self._record_failed(opp, yes_token, no_token, yes_price, no_price,
                                       yes_question, no_question, size_usdc,
                                       f"YES leg: {yes_result.error}")
            return

        # Place NO leg (FAK, taker)
        no_result = await self.clob.place_order(
            token_id=no_token,
            side="BUY",
            price=no_price,
            size_usdc=size_usdc,
            order_type="FAK",
            post_only=False,
        )
        if not no_result.success:
            log.warning(
                "arb_no_leg_failed",
                token=no_token[:12], price=no_price, error=no_result.error,
            )
            # CRITICAL: YES leg filled but NO leg failed. We hold YES tokens
            # without the hedge. Record as FAILED but DO NOT auto-sell YES
            # (would crystallize loss). Admin must review.
            await self._record_failed(opp, yes_token, no_token, yes_price, no_price,
                                       yes_question, no_question, size_usdc,
                                       f"NO leg failed after YES filled: {no_result.error}. "
                                       f"YES tokens held unhedged — admin review required.")
            return

        # Both legs filled. Compute economics.
        yes_tokens = size_usdc / max(yes_price, 0.01)
        no_tokens = size_usdc / max(no_price, 0.01)
        # Expected payout: min(yes_tokens, no_tokens) × $1
        # (one leg resolves YES, pays $1/token; other resolves NO, pays $0)
        # Both legs should have ~equal tokens (since we use same USD size),
        # but prices differ → token counts differ slightly. Conservative:
        # payout = min(yes_tokens, no_tokens) × $1.
        expected_payout = min(yes_tokens, no_tokens) * 1.0
        total_cost = size_usdc + size_usdc  # both legs same USD size
        edge_at_open = (expected_payout - total_cost) / total_cost * 100  # cents per $1

        from app.core.db import AsyncSessionLocal

        try:
            async with AsyncSessionLocal() as db:
                position = ArbPosition(
                    event_slug=opp.event_slug,
                    event_title=opp.event_title,
                    arb_type=opp.arb_type,
                    direction=opp.direction,
                    buy_yes_token_id=yes_token,
                    buy_yes_market_question=yes_question,
                    buy_yes_price=yes_price,
                    buy_yes_size_tokens=yes_tokens,
                    buy_yes_size_usdc=size_usdc,
                    buy_yes_order_id=yes_result.order_id,
                    buy_no_token_id=no_token,
                    buy_no_market_question=no_question,
                    buy_no_price=no_price,
                    buy_no_size_tokens=no_tokens,
                    buy_no_size_usdc=size_usdc,
                    buy_no_order_id=no_result.order_id,
                    total_cost_usdc=total_cost,
                    expected_payout_usdc=expected_payout,
                    edge_cents_at_open=edge_at_open,
                    status="OPEN",
                )
                db.add(position)
                await db.commit()
                log.info(
                    "arb_executed",
                    position_id=position.id,
                    event_title=opp.event_title[:40],
                    yes_token=yes_token[:12],
                    no_token=no_token[:12],
                    yes_price=yes_price,
                    no_price=no_price,
                    total_cost=round(total_cost, 2),
                    expected_payout=round(expected_payout, 2),
                    edge_cents=round(edge_at_open, 2),
                    mode="PAPER" if settings.paper_trading else "LIVE",
                )
        except Exception as e:
            log.error(
                "arb_position_persist_failed",
                error=str(e),
                yes_token=yes_token[:12],
                no_token=no_token[:12],
            )

    async def _record_failed(
        self,
        opp: ArbOpportunity,
        yes_token: str,
        no_token: str,
        yes_price: float,
        no_price: float,
        yes_question: str,
        no_question: str,
        size_usdc: float,
        reason: str,
    ) -> None:
        """Record a FAILED ArbPosition for audit trail."""
        from app.core.db import AsyncSessionLocal

        try:
            async with AsyncSessionLocal() as db:
                position = ArbPosition(
                    event_slug=opp.event_slug,
                    event_title=opp.event_title,
                    arb_type=opp.arb_type,
                    direction=opp.direction,
                    buy_yes_token_id=yes_token,
                    buy_yes_market_question=yes_question,
                    buy_yes_price=yes_price,
                    buy_yes_size_tokens=0.0,
                    buy_yes_size_usdc=size_usdc if "YES leg" not in reason else 0.0,
                    buy_yes_order_id=None,
                    buy_no_token_id=no_token,
                    buy_no_market_question=no_question,
                    buy_no_price=no_price,
                    buy_no_size_tokens=0.0,
                    buy_no_size_usdc=0.0,
                    buy_no_order_id=None,
                    total_cost_usdc=0.0,
                    expected_payout_usdc=0.0,
                    edge_cents_at_open=opp.edge_cents,
                    status="FAILED",
                    failure_reason=reason[:500],
                )
                db.add(position)
                await db.commit()
        except Exception as e:
            log.error("arb_failed_record_persist_error", error=str(e))

    # ── Resolution loop ──────────────────────────────────────────────────

    async def _resolution_loop(self) -> None:
        """Poll Gamma API for resolved markets, settle OPEN positions."""
        await asyncio.sleep(settings.arb_resolution_check_interval_sec)
        while self._running:
            try:
                await self._check_resolutions()
                await self._expire_stale()
            except asyncio.CancelledError:
                raise
            except Exception as e:
                log.warning("arb_resolution_loop_error", error=str(e))
            await asyncio.sleep(settings.arb_resolution_check_interval_sec)

    async def _check_resolutions(self) -> None:
        """For each OPEN ArbPosition, check if either leg's market resolved."""
        from app.core.db import AsyncSessionLocal
        from sqlalchemy import select

        async with AsyncSessionLocal() as db:
            open_positions = await db.scalars(
                select(ArbPosition).where(ArbPosition.status == "OPEN")
            )
            positions = list(open_positions)

        if not positions:
            return

        # Unique token_ids to check (both YES and NO legs)
        tokens_to_check: set[str] = set()
        for p in positions:
            tokens_to_check.add(p.buy_yes_token_id)
            tokens_to_check.add(p.buy_no_token_id)

        # Query Gamma API for each token's market resolution state.
        # Gamma /markets?clob_token_ids=<id1>&clob_token_ids=<id2>...
        resolution_map = await self._fetch_resolution_state(tokens_to_check)
        if not resolution_map:
            return

        for p in positions:
            try:
                await self._maybe_settle(p, resolution_map)
            except Exception as e:
                log.warning(
                    "arb_settle_error",
                    position_id=p.id, error=str(e),
                )

    async def _fetch_resolution_state(
        self, token_ids: set[str]
    ) -> dict[str, dict[str, Any]]:
        """Fetch resolution state from Gamma API for given token_ids.

        Returns {token_id: {"closed": bool, "outcomePrices": ["0"/"1", ...],
                             "outcomes": ["Yes"/"No", ...]}}.

        UNVERIFIED: exact Gamma API response shape for resolved markets.
        Based on arbitrage_scanner.py field usage (outcomePrices, outcomes,
        clobTokenIds). If shape differs, resolution detection will fail
        silently (positions stay OPEN forever).
        """
        result: dict[str, dict[str, Any]] = {}
        if not token_ids:
            return result
        # Gamma API: /markets?clob_token_ids=X&clob_token_ids=Y
        # (limit URL length — batch if too many)
        url = f"{settings.gamma_url}/markets"
        params = [("clob_token_ids", tid) for tid in token_ids]
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    url,
                    params=params,
                    headers={"User-Agent": "PolyMMBotPro-ArbExecutor/1.0"},
                    timeout=aiohttp.ClientTimeout(total=30),
                ) as resp:
                    if resp.status != 200:
                        log.warning("arb_gamma_api_error", status=resp.status)
                        return result
                    data = await resp.json()
                    markets = data if isinstance(data, list) else data.get("data", [])
        except Exception as e:
            log.warning("arb_gamma_fetch_failed", error=str(e))
            return result

        for m in markets:
            raw_ids = m.get("clobTokenIds", "[]")
            try:
                tids = json.loads(raw_ids) if isinstance(raw_ids, str) else list(raw_ids)
            except Exception:
                continue
            raw_prices = m.get("outcomePrices", "[]")
            try:
                prices = json.loads(raw_prices) if isinstance(raw_prices, str) else list(raw_prices)
            except Exception:
                continue
            raw_outcomes = m.get("outcomes", "[]")
            try:
                outcomes = json.loads(raw_outcomes) if isinstance(raw_outcomes, str) else list(raw_outcomes)
            except Exception:
                continue
            closed = bool(m.get("closed", False))
            for tid, outcome, price in zip(tids, outcomes, prices):
                result[str(tid)] = {
                    "closed": closed,
                    "outcome": str(outcome),
                    "price": str(price),
                    "outcomes": outcomes,
                    "outcomePrices": prices,
                }
        return result

    async def _maybe_settle(
        self,
        position: ArbPosition,
        resolution_map: dict[str, dict[str, Any]],
    ) -> None:
        """If either leg resolved, settle the position."""
        yes_state = resolution_map.get(position.buy_yes_token_id)
        no_state = resolution_map.get(position.buy_no_token_id)

        if not yes_state or not no_state:
            return  # one market not found in Gamma response

        if not yes_state["closed"] and not no_state["closed"]:
            return  # neither resolved yet

        # Determine winning leg.
        # If YES leg's market resolved with YES outcome → YES pays $1, NO leg pays $0.
        # If YES leg's market resolved with NO outcome → YES pays $0, NO leg (different
        # market) still needs to resolve. We wait for BOTH to close before settling
        # (conservative — some cross_condition arbs may need both legs resolved).
        if not yes_state["closed"] or not no_state["closed"]:
            return  # wait for both legs

        # Both closed. Determine payouts.
        # BUG-N35 (v1.0.92): MUST use `price` (outcomePrices value, "1"/"0"),
        # NOT `outcome` (label, always "Yes"/"No" for that token).
        # The old code checked `outcome.lower() in ("yes","1")` which is
        # ALWAYS True for a YES token (label never changes) → returned 1.0
        # for both legs → total_payout was doubled/fictitious for every
        # resolution. Now uses `price` with float tolerance for "1.0" /
        # "0.999998" rounding variants.
        yes_payout_per_token = 1.0 if _price_won(yes_state["price"]) else 0.0
        no_payout_per_token = 1.0 if _price_won(no_state["price"]) else 0.0

        yes_payout = yes_payout_per_token * position.buy_yes_size_tokens
        no_payout = no_payout_per_token * position.buy_no_size_tokens
        total_payout = yes_payout + no_payout

        winning_leg = (
            "yes" if yes_payout > 0 and no_payout == 0
            else "no" if no_payout > 0 and yes_payout == 0
            else "both" if yes_payout > 0 and no_payout > 0
            else "neither"
        )

        from app.core.db import AsyncSessionLocal

        try:
            async with AsyncSessionLocal() as db:
                # Re-fetch to avoid stale object
                stmt = select(ArbPosition).where(ArbPosition.id == position.id)
                fresh = await db.scalar(stmt)
                if not fresh or fresh.status != "OPEN":
                    return  # already settled by another path
                fresh.status = "RESOLVED"
                fresh.resolved_payout_usdc = total_payout
                fresh.resolved_at = datetime.now(timezone.utc)
                fresh.winning_leg = winning_leg
                await db.commit()

                net_pnl = total_payout - fresh.total_cost_usdc
                log.info(
                    "arb_settled",
                    position_id=fresh.id,
                    event_title=fresh.event_title[:40],
                    winning_leg=winning_leg,
                    total_cost=round(fresh.total_cost_usdc, 2),
                    payout=round(total_payout, 2),
                    net_pnl=round(net_pnl, 2),
                )
        except Exception as e:
            log.error("arb_settle_persist_error", position_id=position.id, error=str(e))

    async def _expire_stale(self) -> None:
        """Mark OPEN positions older than arb_max_position_age_sec as EXPIRED."""
        from app.core.db import AsyncSessionLocal
        from sqlalchemy import select, update

        cutoff = datetime.now(timezone.utc).timestamp() - settings.arb_max_position_age_sec
        cutoff_dt = datetime.fromtimestamp(cutoff, tz=timezone.utc)

        async with AsyncSessionLocal() as db:
            result = await db.execute(
                update(ArbPosition)
                .where(
                    ArbPosition.status == "OPEN",
                    ArbPosition.timestamp < cutoff_dt,
                )
                .values(status="EXPIRED", failure_reason="max age exceeded without resolution")
            )
            if result.rowcount > 0:
                log.warning("arb_positions_expired", count=result.rowcount)
                await db.commit()


# NOTE: no module-level singleton — ArbExecutor is instantiated in main.py
# after ClobService is constructed (clob must be injected at __init__).

