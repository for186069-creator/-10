"""
app/services/arbitrage_scanner.py — Cross-condition + time-spread arbitrage.

Новий механізм (Опція 4): шукає корельовані ринки на Polymarket, де
математична monotonicity порушена — наприклад:

  "GPT-5.6 released by July 8"  → Yes @ 0.40
  "GPT-5.6 released by July 10" → Yes @ 0.35  ← ПОМИЛКА РИНКУ

Логіка: July 10 ≥ July 8 завжди (більше часу = вища ймовірність).
Якщо July 10 < July 8 → arb: купити July 10, продати July 8.

Два типи арбітражу:
  N1 (cross-condition): однакова подія, різні умови (напр. "by July 8" vs "by July 10")
  N2 (time-spread): однакова подія, різні дати resolution

Це НЕ казино (не вгадуєте напрямок) — це математичний arb.

Truth-first обмеження:
  - Корельовані пари на Polymarket зустрічаються РІДКО (професіонали вже викупили)
  - Цей сканер лише знаходить opportunities; виконання trade окремо (N3 — TODO)
  - Капітал $60 = 1-2 позиції одночасно

Логіка роботи:
  1. Fetch /events з Gamma API (вже робить discover_markets)
  2. Для кожного event з ≥2 markets — перевірити monotonicity
  3. Якщо виявлено violation ≥ MIN_EDGE_CENTS → log + return opportunity
  4. (Опція A) фільтр niche: volume < MAX_VOLUME (де професіонали не грають)
"""
from __future__ import annotations

import asyncio
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

import aiohttp

from app.core.config import settings
from app.core.logging import get_logger

log = get_logger(__name__)


@dataclass
class ArbOpportunity:
    """Знайдена арбітражна можливість.

    v1.0.90 (N3): додано *_no_token_id поля — scanner тепер зберігає ОБИДВА
    token_ids (YES + NO) для кожного ринку, щоб ArbExecutor міг купити
    NO-сторону без додаткового Gamma API call.
    """

    event_title: str
    event_slug: str
    market_a_question: str
    market_b_question: str
    market_a_token_id: str       # YES token of market A
    market_b_token_id: str       # YES token of market B
    market_a_no_token_id: str    # NO token of market A (v1.0.90)
    market_b_no_token_id: str    # NO token of market B (v1.0.90)
    market_a_price: float  # Yes price
    market_b_price: float  # Yes price
    edge_cents: float  # різниця в центах
    arb_type: str  # 'time_spread' | 'cross_condition'
    direction: str  # 'buy_yes_a_buy_no_b' | 'buy_yes_b_buy_no_a'
    volume_a: float
    volume_b: float
    detected_at: str  # ISO timestamp

    def to_dict(self) -> dict[str, Any]:
        return {
            "event_title": self.event_title,
            "event_slug": self.event_slug,
            "market_a_question": self.market_a_question,
            "market_b_question": self.market_b_question,
            "market_a_token_id": self.market_a_token_id,
            "market_b_token_id": self.market_b_token_id,
            "market_a_no_token_id": self.market_a_no_token_id,
            "market_b_no_token_id": self.market_b_no_token_id,
            "market_a_price": self.market_a_price,
            "market_b_price": self.market_b_price,
            "edge_cents": round(self.edge_cents, 2),
            "arb_type": self.arb_type,
            "direction": self.direction,
            "volume_a": self.volume_a,
            "volume_b": self.volume_b,
            "detected_at": self.detected_at,
        }


# ── Дати для time-spread detection ────────────────────────────────────────
# Шаблони для витягування дати з питання (напр. "GPT-5.6 released by July 8")
_DATE_PATTERNS = [
    # "by July 8, 2026" (з роком)
    re.compile(
        r"\bby\s+"
        r"(january|february|march|april|may|june|july|august|september|october|november|december)\s+(\d{1,2}),?\s*(\d{4})",
        re.IGNORECASE,
    ),
    # "by July 8" (без року — припускаємо поточний)
    re.compile(
        r"\bby\s+"
        r"(january|february|march|april|may|june|july|august|september|october|november|december)\s+(\d{1,2})(?!,?\s*\d{4})",
        re.IGNORECASE,
    ),
]

_MONTHS = {
    "january": 1, "february": 2, "march": 3, "april": 4,
    "may": 5, "june": 6, "july": 7, "august": 8,
    "september": 9, "october": 10, "november": 11, "december": 12,
}


def _extract_date(question: str) -> tuple[int, int, int] | None:
    """Витягнути (year, month, day) з питання. Повертає None якщо не знайдено.

    v1.0.86 FIX: раніше повертав (month, day) без року — баг, бо
    "Sept 30, 2026" і "June 30, 2027" порівнювались по місяцю (9 > 6),
    хоча реально Sept 2026 РАНЬША за June 2027.
    """
    import datetime
    current_year = datetime.datetime.now().year
    for pattern in _DATE_PATTERNS:
        m = pattern.search(question)
        if m:
            month_str = m.group(1).lower()
            day = int(m.group(2))
            month = _MONTHS.get(month_str)
            if not (month and 1 <= day <= 31):
                continue
            # Рік: з 3-ї групи якщо є, інакше поточний
            year = current_year
            if m.lastindex >= 3 and m.group(3):
                try:
                    year = int(m.group(3))
                except ValueError:
                    pass
            return (year, month, day)
    return None


def _normalize_question(question: str) -> str:
    """Нормалізувати питання для порівняння (видалити дати)."""
    norm = question.lower()
    for pattern in _DATE_PATTERNS:
        norm = pattern.sub("by DATE", norm)
    return norm.strip()


def _detect_arb_type(q_a: str, q_b: str) -> str | None:
    """Визначити тип арбітражу між двома питаннями.

    Returns 'time_spread' якщо питання відрізняються тільки датою,
    'cross_condition' якщо мають спільну тему але різні умови,
    None якщо не корельовані.
    """
    norm_a = _normalize_question(q_a)
    norm_b = _normalize_question(q_b)

    # Якщо після видалення дат питання однакові → time_spread
    if norm_a == norm_b and q_a != q_b:
        return "time_spread"

    # Cross-condition: перевіримо через спільні ключові слова (4+ слова)
    words_a = set(re.findall(r"\w+", norm_a))
    words_b = set(re.findall(r"\w+", norm_b))
    # Видаляємо stop-words
    stop = {"the", "a", "an", "by", "will", "be", "is", "are", "in", "on", "at", "to", "of", "and", "or"}
    words_a -= stop
    words_b -= stop
    common = words_a & words_b
    if len(common) >= 4:
        return "cross_condition"

    return None


def _check_real_arb(
    q_a: str, q_b: str, price_yes_a: float, price_yes_b: float
) -> tuple[str, float, float] | None:
    """Перевірити СПРАВЖНІЙ безризиковий arb між двома time_spread ринками.

    v1.0.86: повністю перероблено. Старий _check_monotonicity повертав
    "arb" при будь-якій ціновій різниці — але це НЕ безризиковий arb.

    Справжній arb (Polymarket):
        Купити Yes(пізніша дата) + No(раньша дата)
        На Polymarket No ціна = 1 - Yes ціна (на тому ж ринку).
        Собівартість = Yes_late + (1 - Yes_early) = 1 + (Yes_late - Yes_early)
        Якщо Yes_late < Yes_early → собівартість < $1 → ARB
        (бо одна з умов завжди виконається → отримаємо $1)

    Returns:
        (direction, edge_cents, total_cost_dollars) або None
        direction = 'buy_yes_late_buy_no_early' або 'buy_yes_early_buy_no_late'
        edge_cents = (1.00 - total_cost) * 100
        total_cost_dollars = Yes_late + No_early (або симетрично)
    """
    date_a = _extract_date(q_a)
    date_b = _extract_date(q_b)

    if not date_a or not date_b:
        return None
    if date_a == date_b:
        return None

    # Визначити яка дата пізніша
    if date_a > date_b:
        # A пізніша, B раньша
        yes_late = price_yes_a
        yes_early = price_yes_b
        direction = "buy_yes_a_buy_no_b"
    else:
        # B пізніша, A раньша
        yes_late = price_yes_b
        yes_early = price_yes_a
        direction = "buy_yes_b_buy_no_a"

    # No_early = 1 - Yes_early (на Polymarket Yes + No = $1 на одному ринку)
    no_early = 1.0 - yes_early
    total_cost = yes_late + no_early  # собівартість безризикової позиції

    if total_cost < 1.0:
        edge = (1.0 - total_cost) * 100  # cents
        return (direction, edge, total_cost)

    return None


# Backward compat alias (старі тести можуть використовувати)
_check_monotonicity = _check_real_arb


class ArbitrageScanner:
    """Сканер корельованих ринків для виявлення arb opportunities."""

    def __init__(self) -> None:
        self._task: asyncio.Task | None = None
        self.opportunities: list[ArbOpportunity] = []
        self._last_scan_at: str = ""

    async def scan_once(self) -> list[ArbOpportunity]:
        """Одноразове сканування. Повертає знайдені opportunities."""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    f"{settings.gamma_url}/events",
                    params={
                        "active": "true",
                        "closed": "false",
                        "limit": "500",
                        "order": "volume24hr",
                        "ascending": "false",
                    },
                    headers={"User-Agent": "PolyMMBotPro-ArbScanner/1.0"},
                    timeout=aiohttp.ClientTimeout(total=20),
                ) as resp:
                    if resp.status != 200:
                        log.warning("arb_scan_api_error", status=resp.status)
                        return []
                    data = await resp.json()
                events = data if isinstance(data, list) else data.get("data", [])
        except Exception as e:
            log.warning("arb_scan_failed", error=str(e))
            return []

        opportunities: list[ArbOpportunity] = []
        events_scanned = 0
        markets_scanned = 0
        pairs_checked = 0

        min_edge = settings.arb_min_edge_cents
        max_volume = settings.arb_niche_max_volume_24h  # Опція A: niche filter

        for event in events:
            events_scanned += 1
            event_title = event.get("title", "")
            event_slug = event.get("slug", "")

            markets = event.get("markets") or []
            if len(markets) < 2:
                continue  # без пар немає арбітражу

            # Зібрати всі валідні markets з цінами
            valid_markets: list[dict[str, Any]] = []
            for m in markets:
                if not m.get("active", True) or m.get("closed", False):
                    continue

                # Опція A: niche filter — ринки з малим об'ємом (де професіонали не грають)
                vol_24h = float(
                    m.get("volume24hr")
                    or m.get("volume24hrClob")
                    or m.get("volumeNum")
                    or 0
                )
                if max_volume > 0 and vol_24h > max_volume:
                    continue  # skip ринки з великим об'ємом (де професіонали)

                raw_ids = m.get("clobTokenIds", "[]")
                try:
                    token_ids = (
                        json.loads(raw_ids) if isinstance(raw_ids, str) else list(raw_ids)
                    )
                except Exception:
                    continue

                raw_prices = m.get("outcomePrices", "[]")
                try:
                    prices = (
                        json.loads(raw_prices) if isinstance(raw_prices, str) else list(raw_prices)
                    )
                except Exception:
                    continue

                raw_outcomes = m.get("outcomes", "[]")
                try:
                    outcomes = (
                        json.loads(raw_outcomes) if isinstance(raw_outcomes, str) else list(raw_outcomes)
                    )
                except Exception:
                    continue

                if len(token_ids) != len(prices) or len(token_ids) != len(outcomes):
                    continue

                # v1.0.90 (N3): зберегти ОБИДВА token_ids (YES + NO) для
                # кожного ринку, щоб ArbExecutor міг купити NO-сторону без
                # додаткового Gamma API call. Старий код брав лише YES.
                yes_tid: str | None = None
                no_tid: str | None = None
                yes_price: float | None = None
                for tid, outcome, price_str in zip(token_ids, outcomes, prices):
                    outcome_lower = str(outcome).lower()
                    try:
                        p = float(price_str)
                    except (TypeError, ValueError):
                        continue
                    if outcome_lower in ("yes", "1"):
                        yes_tid = str(tid)
                        yes_price = p
                    elif outcome_lower in ("no", "0"):
                        no_tid = str(tid)
                # YES обов'язковий; NO бажаний (деякі ринки можуть не мати)
                if yes_tid is None or yes_price is None:
                    continue
                if not (0.01 <= yes_price <= 0.99):
                    continue
                valid_markets.append({
                    "question": m.get("question", ""),
                    "token_id": yes_tid,            # YES token
                    "no_token_id": no_tid or "",    # NO token (може бути "")
                    "price": yes_price,
                    "volume": vol_24h,
                })
                markets_scanned += 1

            # Перевірити всі пари в межах event
            for i in range(len(valid_markets)):
                for j in range(i + 1, len(valid_markets)):
                    m_a = valid_markets[i]
                    m_b = valid_markets[j]
                    pairs_checked += 1

                    arb_type = _detect_arb_type(m_a["question"], m_b["question"])
                    if arb_type is None:
                        continue

                    result = _check_real_arb(
                        m_a["question"], m_b["question"], m_a["price"], m_b["price"]
                    )
                    if result is None:
                        continue

                    direction, edge, total_cost = result
                    if edge < min_edge:
                        continue

                    opportunities.append(ArbOpportunity(
                        event_title=event_title,
                        event_slug=event_slug,
                        market_a_question=m_a["question"],
                        market_b_question=m_b["question"],
                        market_a_token_id=m_a["token_id"],
                        market_b_token_id=m_b["token_id"],
                        market_a_no_token_id=m_a.get("no_token_id", ""),
                        market_b_no_token_id=m_b.get("no_token_id", ""),
                        market_a_price=m_a["price"],
                        market_b_price=m_b["price"],
                        edge_cents=edge,
                        arb_type=arb_type,
                        direction=direction,
                        volume_a=m_a["volume"],
                        volume_b=m_b["volume"],
                        detected_at=datetime.now(timezone.utc).isoformat(),
                    ))

        self.opportunities = opportunities
        self._last_scan_at = datetime.now(timezone.utc).isoformat()

        log.info(
            "arb_scan_complete",
            events_scanned=events_scanned,
            markets_scanned=markets_scanned,
            pairs_checked=pairs_checked,
            opportunities_found=len(opportunities),
            min_edge_cents=min_edge,
            niche_max_volume=max_volume,
        )

        if opportunities:
            for opp in opportunities[:5]:  # log перші 5
                log.info(
                    "arb_opportunity_found",
                    event_title=opp.event_title[:40],
                    type=opp.arb_type,
                    direction=opp.direction,
                    edge_cents=round(opp.edge_cents, 2),
                    market_a=f"{opp.market_a_question[:30]} @ {opp.market_a_price}",
                    market_b=f"{opp.market_b_question[:30]} @ {opp.market_b_price}",
                )

        return opportunities

    async def scan_loop(self) -> None:
        """Background loop: сканувати кожні arb_scan_interval_sec секунд."""
        interval = settings.arb_scan_interval_sec
        log.info("arb_scanner_started", interval_sec=interval)
        while True:
            try:
                await self.scan_once()
            except asyncio.CancelledError:
                raise
            except Exception as e:
                log.warning("arb_scan_loop_error", error=str(e))
            await asyncio.sleep(interval)

    def start(self) -> None:
        if self._task is None or self._task.done():
            self._task = asyncio.create_task(self.scan_loop(), name="arb_scanner")

    async def stop(self) -> None:
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
            self._task = None


# Module-level singleton
arb_scanner = ArbitrageScanner()


# ── Лінивая імпортація json для сумісності з existing code ─────────────────
import json  # noqa: E402
