"""
app/services/pnl_tracker.py — Aggregated P&L tracking (v1.0.132).

Replaces reliance on `round_trip_count` (which only counts same-Quote
bid+ask fills — near-zero due to active re-quoting) with real aggregated
metrics: total realized PnL, win rate, breakdown by exit type.
"""
from __future__ import annotations

from dataclasses import dataclass

from app.core.logging import get_logger

log = get_logger(__name__)


@dataclass
class PnlSnapshot:
    total_realized_pnl: float = 0.0
    sell_count: int = 0
    sell_wins: int = 0
    sell_losses: int = 0
    pnl_natural: float = 0.0       # non-liquidation sells
    pnl_liquidation: float = 0.0   # liquidation=True sells
    fees_total: float = 0.0


class PnlTracker:
    """Tracks aggregated P&L from all fills.

    Call record_fill() for every fill event.
    Read snapshot() for current state.
    """

    def __init__(self) -> None:
        self._snap = PnlSnapshot()

    def record_fill(self, side: str, pnl_net: float, fees: float, is_liquidation: bool) -> None:
        """Record a fill event.

        Args:
            side: "BUY" or "SELL"
            pnl_net: net P&L of this fill (after fees)
            fees: gas/fees paid on this fill
            is_liquidation: True if this was a forced liquidation sell
        """
        self._snap.fees_total += fees
        self._snap.total_realized_pnl += pnl_net
        if side == "SELL":
            self._snap.sell_count += 1
            if pnl_net > 0:
                self._snap.sell_wins += 1
            elif pnl_net < 0:
                self._snap.sell_losses += 1
            if is_liquidation:
                self._snap.pnl_liquidation += pnl_net
            else:
                self._snap.pnl_natural += pnl_net

    @property
    def sell_win_rate(self) -> float:
        if self._snap.sell_count == 0:
            return 0.0
        return self._snap.sell_wins / self._snap.sell_count

    def snapshot(self) -> PnlSnapshot:
        return self._snap

    def log_summary(self) -> None:
        """Log current P&L summary (call periodically)."""
        s = self._snap
        log.info(
            "pnl_summary",
            total_realized_pnl=round(s.total_realized_pnl, 2),
            sell_win_rate=round(self.sell_win_rate * 100, 1),
            sell_count=s.sell_count,
            sell_wins=s.sell_wins,
            sell_losses=s.sell_losses,
            pnl_natural=round(s.pnl_natural, 2),
            pnl_liquidation=round(s.pnl_liquidation, 2),
            fees_total=round(s.fees_total, 4),
        )
