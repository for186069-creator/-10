"""
app/services/risk/adverse_selection.py — Adverse selection detection.

PROBLEM: When informed traders know something, they hit our quotes before
the mid moves. We end up buying just before price falls, or selling just
before price rises. This is the #1 way MM bots lose money.

DETECTION (v10.13 had this): Monitor price moves after our fills.
  - If mid moves >X cents in Y seconds → likely adverse selection.
  - Trigger cooldown to stop quoting on that token.

NEW (pro version):
  - Track realized adverse selection cost = (mid_at_fill - mid_now) * side
    Aggregated per-token, per-day.
  - If average adverse cost exceeds threshold → permanent block (not just cooldown).
  - Track win rate after fills: if <30% over 20 fills → widen spread permanently.

This is a measurement module — it does NOT place/cancel orders.
The MarketMaker calls `check()` and decides what to do.
"""
from __future__ import annotations

import time
from collections import deque
from dataclasses import dataclass, field

from app.core.config import settings
from app.core.logging import get_logger

log = get_logger(__name__)


@dataclass
class FillRecord:
    """A fill record for adverse-selection tracking."""

    token_id: str
    side: str  # "BUY" or "SELL"
    fill_price: float
    mid_at_fill: float
    timestamp: float


@dataclass
class TokenAdverseState:
    """Per-token adverse selection statistics."""

    fills: deque = field(default_factory=lambda: deque(maxlen=50))
    cooldown_until: float = 0.0
    last_trigger_time: float = 0.0
    adverse_cost_total: float = 0.0  # cumulative adverse cost (cents)
    fill_count: int = 0
    win_count: int = 0  # fills where mid moved in our favor
    loss_count: int = 0  # fills where mid moved against us
    permanently_blocked: bool = False


class AdverseSelection:
    """Detect and track adverse selection per token."""

    def __init__(self) -> None:
        self._states: dict[str, TokenAdverseState] = {}
        self._global_cooldown_until: float = 0.0
        self._price_history: dict[str, deque] = {}

    def record_fill(self, token_id: str, side: str, fill_price: float, mid_at_fill: float) -> None:
        """Record a fill. Later we'll check whether mid moved against us."""
        state = self._states.setdefault(token_id, TokenAdverseState())
        state.fills.append(
            FillRecord(
                token_id=token_id,
                side=side,
                fill_price=fill_price,
                mid_at_fill=mid_at_fill,
                timestamp=time.monotonic(),
            )
        )
        state.fill_count += 1

    def track_price(self, token_id: str, mid: float) -> None:
        """Track mid-price history for trigger detection.

        v1.0.122 (Claude audit p.3): maxlen=300 (was 120) to support
        LIQUIDATION_TREND_WINDOW_SEC=180 with buffer. At ~1 sample/sec,
        300 samples = 5 min history, enough for 180s window.
        """
        if token_id not in self._price_history:
            self._price_history[token_id] = deque(maxlen=300)
        self._price_history[token_id].append((time.monotonic(), mid))

        # Check old fills for adverse selection outcome
        self._update_fill_outcomes(token_id, mid)

    # v1.0.120 (Claude audit Task 2a): price slope for opportunity-cost liquidation.
    # Returns dollars/sec slope over the last `window_sec` seconds.
    # >0 = price recovering, <0 = price still falling, ~0 = stabilized.
    def price_slope(self, token_id: str, window_sec: float = 180.0) -> float:
        """Return price trend (dollars/sec) over the last window_sec.

        Uses existing _price_history deque (no new storage).
        Returns 0.0 if insufficient data (<3 points in window).
        """
        history = self._price_history.get(token_id)
        if not history or len(history) < 3:
            return 0.0
        now = time.monotonic()
        cutoff = now - window_sec
        # Filter points within window
        points = [(ts, p) for ts, p in history if ts >= cutoff]
        if len(points) < 3:
            return 0.0
        # Simple linear regression: slope = Σ(x-x̄)(y-ȳ) / Σ(x-x̄)²
        n = len(points)
        xs = [ts for ts, _ in points]
        ys = [p for _, p in points]
        x_mean = sum(xs) / n
        y_mean = sum(ys) / n
        num = sum((x - x_mean) * (y - y_mean) for x, y in zip(xs, ys))
        den = sum((x - x_mean) ** 2 for x in xs)
        if den == 0:
            return 0.0
        return num / den  # dollars per second

    def _update_fill_outcomes(self, token_id: str, current_mid: float) -> None:
        """Update win/loss stats for fills older than the window."""
        state = self._states.get(token_id)
        if not state:
            return
        window = settings.adverse_selection_window_sec
        now = time.monotonic()
        # Only check fills that have aged past the window
        for fill in list(state.fills):
            if now - fill.timestamp < window:
                continue
            # Determine outcome
            if fill.side == "BUY":
                # We bought — good if mid rose, bad if mid fell
                if current_mid > fill.mid_at_fill:
                    state.win_count += 1
                elif current_mid < fill.mid_at_fill:
                    state.loss_count += 1
                    state.adverse_cost_total += (fill.mid_at_fill - current_mid) * 100
            else:  # SELL
                # We sold — good if mid fell, bad if mid rose
                if current_mid < fill.mid_at_fill:
                    state.win_count += 1
                elif current_mid > fill.mid_at_fill:
                    state.loss_count += 1
                    state.adverse_cost_total += (current_mid - fill.mid_at_fill) * 100
            # Remove processed fill
            try:
                state.fills.remove(fill)
            except ValueError:
                pass

        # Permanent block if win rate is very poor over enough samples
        total = state.win_count + state.loss_count
        if total >= 20:
            win_rate = state.win_count / total
            if win_rate < 0.30:
                state.permanently_blocked = True
                log.warning(
                    "adverse_selection_permanent_block",
                    token_id=token_id[:12],
                    win_rate=round(win_rate * 100, 1),
                    samples=total,
                )

    def check_trigger(self, token_id: str) -> bool:
        """Check if a sharp price move should trigger cooldown.

        Returns True if triggered (caller should cancel quotes).
        """
        if not settings.adverse_selection_enabled:
            return False

        history = self._price_history.get(token_id)
        if not history or len(history) < 2:
            return False

        now = time.monotonic()
        state = self._states.get(token_id)

        # Don't re-trigger if already in cooldown
        if state and now - state.last_trigger_time < settings.adverse_selection_cooldown_sec:
            return False

        window = settings.adverse_selection_window_sec
        move_threshold = settings.adverse_selection_move_cents / 100.0

        # Find oldest sample within the window
        oldest_in_window = None
        for ts, mid in history:
            if now - ts <= window:
                oldest_in_window = (ts, mid)
                break
        if oldest_in_window is None:
            return False

        _, old_mid = oldest_in_window
        current_mid = history[-1][1]
        move = abs(current_mid - old_mid)

        if move >= move_threshold:
            cooldown_sec = settings.adverse_selection_cooldown_sec
            if state is None:
                state = TokenAdverseState()
                self._states[token_id] = state
            state.cooldown_until = now + cooldown_sec
            state.last_trigger_time = now
            # v1.0.127: REMOVED global cooldown — was blocking ALL markets.
            # self._global_cooldown_until = now + min(5.0, cooldown_sec / 2)
            # Clear history to prevent immediate re-trigger (v9.12 fix)
            history.clear()
            log.warning(
                "adverse_selection_triggered",
                token_id=token_id[:12],
                move_cents=round(move * 100, 2),
                window_sec=window,
                cooldown_sec=cooldown_sec,
            )
            return True
        return False

    def is_in_cooldown(self, token_id: str) -> bool:
        """Check if token is in adverse-selection cooldown.

        v1.0.127: global cooldown REMOVED. Was blocking ALL markets when one
        triggered → bot stopped quoting everything for 5-15s. Now per-market
        only: the token that triggered cooldown is blocked, others continue.
        This is correct MM behavior — adverse selection on one market doesn't
        mean all markets are toxic.
        """
        if not settings.adverse_selection_enabled:
            return False
        # v1.0.127: REMOVED global cooldown — was blocking all markets
        # if time.monotonic() < self._global_cooldown_until:
        #     return True
        state = self._states.get(token_id)
        if state is None:
            return False
        if state.permanently_blocked:
            return True
        if time.monotonic() < state.cooldown_until:
            return True
        # Clean up expired cooldown
        if state.cooldown_until > 0 and time.monotonic() >= state.cooldown_until:
            state.cooldown_until = 0.0
        return False

    def global_cooldown_remaining(self) -> float:
        return max(0.0, self._global_cooldown_until - time.monotonic())

    def get_stats(self, token_id: str) -> dict:
        state = self._states.get(token_id)
        if not state:
            return {"tracked": False}
        total = state.win_count + state.loss_count
        return {
            "tracked": True,
            "fills_in_window": len(state.fills),
            "win_count": state.win_count,
            "loss_count": state.loss_count,
            "win_rate": round(state.win_count / total * 100, 1) if total > 0 else 0.0,
            "adverse_cost_cents": round(state.adverse_cost_total, 2),
            "permanently_blocked": state.permanently_blocked,
            "in_cooldown": self.is_in_cooldown(token_id),
        }

    def clear(self, token_id: str) -> None:
        self._states.pop(token_id, None)
        self._price_history.pop(token_id, None)
