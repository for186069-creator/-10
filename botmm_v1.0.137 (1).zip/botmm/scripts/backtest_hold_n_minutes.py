#!/usr/bin/env python3
"""
Backtest: "hold N minutes OR take-profit at X cents (whichever first)".

STATUS: UNTESTED — written against the verified schema of mm_trades and
mm_snapshots, but CANNOT be validated until mm_snapshots has accumulated
>= 3-5 days of data (see CHANGELOG_v1.0.88.md / handoff section 2). Run it
only after the bot has been live (PAPER) long enough to populate rows.

WHAT IT DOES
------------
For every historical BUY fill in mm_trades (an opening position), and for
every (N_minutes, profit_take_cents) combination, simulate:

    exit_time = min(fill_time + N_minutes, first_time_profit_take_hit)
    exit_mid = first mm_snapshots.mid_price at exit_time for that market
    pnl_gross = (exit_mid - fill.price) * fill.size_tokens
    pnl_net   = pnl_gross - fee_estimate

Then aggregate per (N, profit_take) combination:
    total_pnl_net, win_rate, avg_win, avg_loss, sample_size

Combinations with < min_sample (default 50) fills are flagged as
insignificant and printed but not recommended.

DATA SOURCES (verified schema, app/db/models.py)
-------------------------------------------------
  mm_trades:      id, market_id, side ('BUY'/'SELL'), price, size_tokens,
                  size_usdc, fees_usdc, mode ('PAPER'/'LIVE'), timestamp
  mm_snapshots:   id, market_id, mid_price, spread, volatility, kyle_lambda,
                  our_inventory, bankroll_usdc, timestamp

SIMPLIFICATIONS (honest caveats)
--------------------------------
1. Each BUY fill is treated as an independent round-trip. In reality multiple
   buys compound into one position with an avg_entry_price; this script does
   NOT model position stacking. This is a first-order approximation.
2. Exit price is the first snapshot mid at/after exit_time. If snapshots are
   sparse (interval 30s), the realized exit may be up to ~30s later than the
   theoretical exit_time. Acceptable for minute-scale backtests.
3. Fee model: by default fee_bps=0 (gross). Pass --fee-bps to estimate net.
   The real bot's fee depends on maker/taker and Polymarket rules; this script
   does NOT look up the actual fee schedule.
4. Only BUY opens are simulated (the bot is long-only on liquidation per
   _liquidate_aged_positions). SELL fills are ignored as opens.

USAGE
-----
    python scripts/backtest_hold_n_minutes.py --db mm_bot.db
    python scripts/backtest_hold_n_minutes.py --db mm_bot.db --mode PAPER \\
        --fee-bps 0 --min-sample 50 --out results.csv
"""

from __future__ import annotations

import argparse
import sqlite3
import sys
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path


# ── Defaults from the handoff (section 3) ────────────────────────────────
DEFAULT_N_MINUTES = [1, 2, 4, 8, 15, 30]
DEFAULT_PROFIT_TAKE_CENTS = [0.0, 1.0, 2.0, 3.0, 5.0, 8.0]
DEFAULT_MIN_SAMPLE = 50


@dataclass
class BuyFill:
    """One opening BUY fill to simulate a round-trip on."""
    id: int
    market_id: str
    price: float
    size_tokens: float
    timestamp: datetime


@dataclass
class ComboResult:
    n_minutes: int
    profit_take_cents: float
    total_pnl_net: float
    win_rate: float
    avg_win: float
    avg_loss: float
    sample_size: int
    sufficient: bool  # sample_size >= min_sample


def parse_ts(raw: str) -> datetime:
    """Parse a timestamp stored by SQLAlchemy/SQLite.

    Handles both naive and timezone-aware strings. UNVERIFIED against actual
    stored format — the column is DateTime(timezone=True) with
    server_default=func.now(), so SQLite typically stores ISO-8601. If parsing
    fails, the script will raise (do not silently mask).
    """
    # Try a few common formats produced by SQLite/SQLAlchemy.
    for parser in (
        lambda s: datetime.fromisoformat(s),
        lambda s: datetime.strptime(s, "%Y-%m-%d %H:%M:%S.%f%z"),
        lambda s: datetime.strptime(s, "%Y-%m-%d %H:%M:%S%z"),
        lambda s: datetime.strptime(s, "%Y-%m-%d %H:%M:%S.%f"),
        lambda s: datetime.strptime(s, "%Y-%m-%d %H:%M:%S"),
    ):
        try:
            dt = parser(raw)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt
        except (ValueError, TypeError):
            continue
    raise ValueError(f"unparseable timestamp: {raw!r}")


def load_buy_fills(conn: sqlite3.Connection, mode: str | None) -> list[BuyFill]:
    """Load all BUY (opening) fills. pnl_usdc IS NULL filters to opens."""
    sql = (
        "SELECT id, market_id, price, size_tokens, timestamp "
        "FROM mm_trades WHERE side = 'BUY'"
    )
    params: list = []
    if mode:
        sql += " AND mode = ?"
        params.append(mode)
    sql += " ORDER BY timestamp ASC"
    rows = conn.execute(sql, params).fetchall()
    fills: list[BuyFill] = []
    for r in rows:
        try:
            fills.append(
                BuyFill(
                    id=r[0],
                    market_id=r[1],
                    price=float(r[2]),
                    size_tokens=float(r[3]),
                    timestamp=parse_ts(str(r[4])),
                )
            )
        except (ValueError, TypeError) as e:
            print(f"WARN: skipping fill id={r[0]} parse error: {e}", file=sys.stderr)
    return fills


def load_snapshots_by_market(conn: sqlite3.Connection) -> dict[str, list[tuple[datetime, float]]]:
    """Load all (timestamp, mid_price) per market, sorted ascending.

    Returns {market_id: [(ts, mid), ...]}. Memory-heavy for large tables; if
    mm_snapshots has 300k rows this is ~tens of MB — acceptable for a one-off.
    """
    rows = conn.execute(
        "SELECT market_id, timestamp, mid_price FROM mm_snapshots "
        "ORDER BY market_id, timestamp ASC"
    ).fetchall()
    out: dict[str, list[tuple[datetime, float]]] = {}
    for market_id, ts_raw, mid_raw in rows:
        try:
            ts = parse_ts(str(ts_raw))
            mid = float(mid_raw)
        except (ValueError, TypeError):
            continue
        out.setdefault(market_id, []).append((ts, mid))
    return out


def find_exit(
    snaps: list[tuple[datetime, float]],
    fill_ts: datetime,
    entry_price: float,
    n_minutes: int,
    profit_take_cents: float,
) -> tuple[datetime, float] | None:
    """Find (exit_ts, exit_mid) per the 'hold N min OR take-profit' rule.

    - If profit_take_cents > 0: scan snapshots from fill_ts forward; the FIRST
      one where (mid - entry_price)*100 >= profit_take_cents is the TP exit.
    - The N-minute exit is the FIRST snapshot at/after fill_ts + N minutes.
    - Return whichever is earlier. If neither has a snapshot, return None.
    Binary search is avoided for simplicity (lists are ascending; linear scan
    from fill_ts is fine for one-off analysis).
    """
    n_exit_ts = fill_ts + timedelta(minutes=n_minutes)
    tp_threshold = profit_take_cents / 100.0  # cents → dollars

    n_exit: tuple[datetime, float] | None = None
    tp_exit: tuple[datetime, float] | None = None

    for ts, mid in snaps:
        if ts < fill_ts:
            continue
        if n_exit is None and ts >= n_exit_ts:
            n_exit = (ts, mid)
        if (
            tp_exit is None
            and profit_take_cents > 0
            and (mid - entry_price) >= tp_threshold
        ):
            tp_exit = (ts, mid)
        # If both found we can stop early.
        if n_exit is not None and (profit_take_cents <= 0 or tp_exit is not None):
            break

    if profit_take_cents <= 0:
        return n_exit
    if n_exit is None and tp_exit is None:
        return None
    if n_exit is None:
        return tp_exit
    if tp_exit is None:
        return n_exit
    return n_exit if n_exit[0] <= tp_exit[0] else tp_exit


def run_combo(
    fills: list[BuyFill],
    snaps_by_market: dict[str, list[tuple[datetime, float]]],
    n_minutes: int,
    profit_take_cents: float,
    fee_bps: float,
    min_sample: int,
) -> ComboResult:
    pnl_net_list: list[float] = []
    for f in fills:
        snaps = snaps_by_market.get(f.market_id)
        if not snaps:
            continue
        exit_pair = find_exit(snaps, f.timestamp, f.price, n_minutes, profit_take_cents)
        if exit_pair is None:
            continue
        _, exit_mid = exit_pair
        gross = (exit_mid - f.price) * f.size_tokens
        # fee applied to notional of both legs (buy + simulated sell).
        notional = f.price * f.size_tokens + exit_mid * f.size_tokens
        fee = notional * (fee_bps / 10000.0)
        pnl_net_list.append(gross - fee)

    n = len(pnl_net_list)
    if n == 0:
        return ComboResult(n_minutes, profit_take_cents, 0.0, 0.0, 0.0, 0.0, 0, False)
    wins = [p for p in pnl_net_list if p > 0]
    losses = [p for p in pnl_net_list if p < 0]
    total = sum(pnl_net_list)
    win_rate = len(wins) / n
    avg_win = sum(wins) / len(wins) if wins else 0.0
    avg_loss = sum(losses) / len(losses) if losses else 0.0
    return ComboResult(
        n_minutes=n_minutes,
        profit_take_cents=profit_take_cents,
        total_pnl_net=total,
        win_rate=win_rate,
        avg_win=avg_win,
        avg_loss=avg_loss,
        sample_size=n,
        sufficient=n >= min_sample,
    )


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--db", default="mm_bot.db", help="path to SQLite DB (default: mm_bot.db)")
    ap.add_argument("--mode", default="PAPER", choices=["PAPER", "LIVE", "ALL"],
                    help="filter trades by mode (default PAPER; ALL = no filter)")
    ap.add_argument("--fee-bps", type=float, default=0.0,
                    help="estimated round-trip fee in bps applied to notional (default 0 = gross)")
    ap.add_argument("--min-sample", type=int, default=DEFAULT_MIN_SAMPLE,
                    help=f"minimum fills per combo to be 'significant' (default {DEFAULT_MIN_SAMPLE})")
    ap.add_argument("--out", default="", help="optional CSV path to write the full results table")
    args = ap.parse_args()

    db_path = Path(args.db)
    if not db_path.exists():
        print(f"ERROR: DB not found: {db_path}", file=sys.stderr)
        return 2

    conn = sqlite3.connect(str(db_path))

    # Sanity: confirm tables exist + report row counts (so the user sees if
    # mm_snapshots is still empty — the whole point of the v1.0.88 prerequisite).
    for tbl in ("mm_trades", "mm_snapshots"):
        try:
            cnt = conn.execute(f"SELECT COUNT(*) FROM {tbl}").fetchone()[0]
            print(f"[data] {tbl}: {cnt} rows", file=sys.stderr)
        except sqlite3.OperationalError as e:
            print(f"ERROR: table {tbl} missing/unreadable: {e}", file=sys.stderr)
            return 3
    snap_count = conn.execute("SELECT COUNT(*) FROM mm_snapshots").fetchone()[0]
    if snap_count == 0:
        print(
            "WARNING: mm_snapshots is EMPTY. Backtest is meaningless until the "
            "bot (v1.0.88+) has run long enough to accumulate price history "
            "(see CHANGELOG_v1.0.88.md). Aborting.",
            file=sys.stderr,
        )
        return 4

    mode_filter = None if args.mode == "ALL" else args.mode
    fills = load_buy_fills(conn, mode_filter)
    print(f"[data] loaded {len(fills)} BUY fills (mode={args.mode})", file=sys.stderr)
    if not fills:
        print("WARNING: no BUY fills to backtest. Nothing to do.", file=sys.stderr)
        return 0

    snaps_by_market = load_snapshots_by_market(conn)
    print(f"[data] loaded snapshots for {len(snaps_by_market)} markets", file=sys.stderr)
    conn.close()

    results: list[ComboResult] = []
    for n_min in DEFAULT_N_MINUTES:
        for pt_cents in DEFAULT_PROFIT_TAKE_CENTS:
            results.append(
                run_combo(fills, snaps_by_market, n_min, pt_cents,
                          args.fee_bps, args.min_sample)
            )

    # Sort by total_pnl_net desc so the best combos are on top.
    results.sort(key=lambda r: r.total_pnl_net, reverse=True)

    header = f"{'N_min':>6} {'PT_cents':>9} {'total_pnl':>12} {'win_rate':>9} {'avg_win':>9} {'avg_loss':>9} {'sample':>7} {'sig':>4}"
    print(header)
    print("-" * len(header))
    for r in results:
        sig = "yes" if r.sufficient else "NO"
        print(f"{r.n_minutes:>6} {r.profit_take_cents:>9.1f} {r.total_pnl_net:>12.4f} "
              f"{r.win_rate*100:>8.1f}% {r.avg_win:>9.4f} {r.avg_loss:>9.4f} "
              f"{r.sample_size:>7} {sig:>4}")

    if args.out:
        with open(args.out, "w", encoding="utf-8") as fh:
            fh.write("n_minutes,profit_take_cents,total_pnl_net,win_rate,avg_win,avg_loss,sample_size,sufficient\n")
            for r in results:
                fh.write(f"{r.n_minutes},{r.profit_take_cents},{r.total_pnl_net},"
                         f"{r.win_rate},{r.avg_win},{r.avg_loss},{r.sample_size},"
                         f"{int(r.sufficient)}\n")
        print(f"\n[written] {args.out}", file=sys.stderr)

    return 0


if __name__ == "__main__":
    sys.exit(main())
