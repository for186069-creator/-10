"""
tests/unit/test_ask_profit_invariant.py — Structural invariant test.

ІНВАРІАНТ: якщо ринково-оптимальний ask вже прибутковий (>= avg_entry),
aging/liquidation логіка (is_aged/is_very_aged, не URGENT) не повинна
занижувати його нижче оригінального рівня.

Регресія v1.0.128: entry=0.4321, market дозволяє ask=0.4470 (+1.49¢),
але aging знизив до 0.4331 (+0.10¢). Цей тест фіксує що це не повториться.

Honest disclosure: UNVERIFIED until pytest run with deps installed.
"""
from __future__ import annotations

import time
from unittest.mock import AsyncMock, MagicMock

import pytest


@pytest.fixture
def aged_mm(monkeypatch):
    """MarketMaker with a very aged long position."""
    from app.core.config import settings
    from app.services.market_maker import MarketMaker
    from app.services.inventory_manager import InventoryManager, Inventory
    from app.services.risk.risk_manager import RiskManager

    monkeypatch.setattr(settings, "paper_trading", True)
    monkeypatch.setattr(settings, "paper_rejection_rate", 0.0)
    monkeypatch.setattr(settings, "paper_competition_rate", 0.0)
    monkeypatch.setattr(settings, "inventory_liquidation_enabled", True)
    monkeypatch.setattr(settings, "inventory_aging_threshold_sec", 120.0)
    monkeypatch.setattr(settings, "inventory_liquidation_aggressive_age_sec", 180.0)
    monkeypatch.setattr(settings, "inventory_liquidation_urgent_age_sec", 7200.0)
    monkeypatch.setattr(settings, "inventory_profit_take_cents", 100.0)
    monkeypatch.setattr(settings, "inventory_profit_take_min_age_sec", 9999.0)
    monkeypatch.setattr(settings, "multi_level_enabled", False)

    clob = MagicMock()
    clob.books = {}
    clob.markets = {}
    clob.last_ws_msg_age = 1.0

    inventory = InventoryManager()
    inventory.bankroll = 100.0

    # Plant a very aged long position: entry=0.4321, age > 180s (very_aged)
    inv = Inventory(token_id="tok-test", market_name="Test Market")
    inv.net_tokens = 50.0  # enough tokens so ask size clamp doesn't block (v1.0.131 fix)
    inv.avg_entry_price = 0.4321
    inv.open_time = time.monotonic() - 300.0  # 300s ago → very_aged, not URGENT
    inventory.inventories["tok-test"] = inv

    risk = RiskManager(inventory, clob)
    mm = MarketMaker(clob, inventory, risk)
    mm._running = True
    mm._record_fill = AsyncMock()
    return mm


def test_profitable_ask_never_lowered_below_original(aged_mm):
    """ІНВАРІАНТ: profitable ask (>= entry) is NEVER lowered by aging logic.

    Scenario: entry=0.4321, market allows ask=0.4470 (+1.49¢ profit).
    Position is very_aged (300s). Aging logic should NOT lower ask.

    Regression: v1.0.128 lowered to 0.4331 (+0.10¢) — losing 1.39¢ profit.
    This test ensures the structural max() in v1.0.131 prevents that.
    """
    from app.services.clob_client import MarketBook, OrderLevel

    # Market: bid=0.4200, ask=0.4500 → mid=0.4350
    # target_ask = mid + spread/2 - gap = 0.4350 + 0.015 - 0.003 = 0.4470
    book = MarketBook(
        token_id="tok-test",
        bids=[OrderLevel(0.4200, 100)],
        asks=[OrderLevel(0.4500, 100)],
        last_price=0.4350,
    )
    aged_mm.clob.books = {"tok-test": book}

    from app.services.clob_client import MarketInfo
    info = MarketInfo(
        token_id="tok-test",
        condition_id="cond-1",
        question="Test Market",
        outcome="Yes",
        end_date_ts=time.time() + 86400,
        volume_24h=50000.0,
    )
    aged_mm.clob.markets = {"tok-test": info}

    # Capture the quote placed
    placed_quotes = []

    async def fake_place_quote_level(**kwargs):
        placed_quotes.append(kwargs)
        from app.services.market_maker import ActiveQuote
        return ActiveQuote(
            token_id=kwargs["token_id"],
            level=kwargs.get("level", 1),
            bid_price=kwargs.get("bid_price"),
            ask_price=kwargs.get("ask_price"),
            mid_at_place=kwargs.get("mid", 0.4350),
            size_usdc=kwargs.get("size_usdc", 5.0),
            reservation_price=kwargs.get("reservation", 0.4350),
            spread_cents=kwargs.get("spread_cents", 4.0),
        )

    aged_mm._place_quote_level = fake_place_quote_level

    import asyncio
    asyncio.run(aged_mm._process_market("tok-test", book))

    # Assert: ask_price should be ~0.4470 (market optimal), NOT 0.4331 (entry+0.001)
    assert len(placed_quotes) > 0, "Expected at least one quote placed"
    ask_price = placed_quotes[0].get("ask_price")
    assert ask_price is not None, "Ask should be placed (PAPER allows flat)"

    # The invariant: ask >= original market-optimal price (not lowered by aging)
    # original_ask_price ≈ 0.4470 (market ask - gap)
    # If aging lowered it to 0.4331 (entry+0.001) — test FAILS (regression)
    assert ask_price >= 0.4400, (
        f"REGRESSION: ask_price={ask_price} was lowered by aging logic. "
        f"Expected >= 0.4400 (market optimal), got {ask_price}. "
        f"This means the profitable-ask invariant is broken (v1.0.128 regression)."
    )
