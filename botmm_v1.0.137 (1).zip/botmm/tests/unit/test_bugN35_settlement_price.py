"""
tests/unit/test_bugN35_settlement_price.py — Test for BUG-N35 fix (v1.0.92).

Verifies that _maybe_settle uses `price` (outcomePrices value, "1"/"0") to
determine payouts, NOT `outcome` (label "Yes"/"No" which is constant per
token). Without the fix, both legs would ALWAYS pay $1 → doubled/fictitious
payout for every resolution.

Honest disclosure: tests written to be runnable with pytest once deps
installed. UNVERIFIED until executed in proper env.
"""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch
from datetime import datetime, timezone

import pytest


def _make_position(
    yes_tokens: float = 50.0,
    no_tokens: float = 50.0,
    total_cost: float = 9.50,
) -> MagicMock:
    """Build a fake ArbPosition with the fields _maybe_settle touches."""
    pos = MagicMock()
    pos.id = 1
    pos.event_title = "Test Event"
    pos.buy_yes_token_id = "tok-yes-A"
    pos.buy_no_token_id = "tok-no-B"
    pos.buy_yes_size_tokens = yes_tokens
    pos.buy_no_size_tokens = no_tokens
    pos.total_cost_usdc = total_cost
    pos.status = "OPEN"
    return pos


@pytest.mark.asyncio
async def test_bugN35_yes_won_no_lost(monkeypatch):
    """Scenario: YES leg's market resolved YES (YES pays $1), NO leg's market
    resolved YES too (NO token pays $0 — its market resolved YES, not NO).

    Correct: total_payout = 50 × $1 + 50 × $0 = $50.
    BUG (old): total_payout = 50 + 50 = $100 (both always "won").
    """
    from app.services import arb_executor as mod

    pos = _make_position(yes_tokens=50.0, no_tokens=50.0, total_cost=9.50)

    # Mock Gamma API resolution state
    resolution_map = {
        "tok-yes-A": {
            "closed": True,
            "outcome": "Yes",   # label (constant for YES token)
            "price": "1",       # ← actual result: YES won
        },
        "tok-no-B": {
            "closed": True,
            "outcome": "No",    # label (constant for NO token)
            "price": "0",       # ← actual result: NO lost (its market resolved YES)
        },
    }

    # Mock DB session — _maybe_settle re-fetches position
    fake_db = MagicMock()
    fake_stmt_result = MagicMock()
    fake_stmt_result.scalar.return_value = pos  # re-fetched fresh position
    fake_db.scalar = AsyncMock(return_value=pos)
    fake_db.commit = AsyncMock()

    # Patch AsyncSessionLocal to return our fake_db
    class _FakeSession:
        async def __aenter__(self):
            return fake_db
        async def __aexit__(self, *a):
            return False

    monkeypatch.setattr(mod, "AsyncSessionLocal", lambda: _FakeSession(), raising=False)
    # Patch the lazy import inside _maybe_settle (it does `from app.core.db import AsyncSessionLocal`)
    import app.core.db as core_db
    monkeypatch.setattr(core_db, "AsyncSessionLocal", lambda: _FakeSession())

    executor = mod.ArbExecutor(clob=MagicMock())
    await executor._maybe_settle(pos, resolution_map)

    # CORE ASSERTION: payout should be $50 (YES won), NOT $100 (both)
    assert pos.resolved_payout_usdc == 50.0, \
        f"BUG-N35 REGRESSION: payout={pos.resolved_payout_usdc} (expected 50.0). " \
        f"If 100.0, both legs paid — outcome label used instead of price."
    assert pos.status == "RESOLVED"
    assert pos.winning_leg == "yes"


@pytest.mark.asyncio
async def test_bugN35_no_won_yes_lost(monkeypatch):
    """Scenario: YES leg's market resolved NO (YES pays $0), NO leg's market
    resolved NO (NO token pays $1 — its market resolved NO).

    Correct: total_payout = 0 + 50 × $1 = $50.
    BUG (old): total_payout = 50 + 50 = $100.
    """
    from app.services import arb_executor as mod

    pos = _make_position(yes_tokens=50.0, no_tokens=50.0, total_cost=9.50)

    resolution_map = {
        "tok-yes-A": {
            "closed": True,
            "outcome": "Yes",   # constant label
            "price": "0",       # YES lost
        },
        "tok-no-B": {
            "closed": True,
            "outcome": "No",    # constant label
            "price": "1",       # NO won
        },
    }

    fake_db = MagicMock()
    fake_db.scalar = AsyncMock(return_value=pos)
    fake_db.commit = AsyncMock()

    class _FakeSession:
        async def __aenter__(self):
            return fake_db
        async def __aexit__(self, *a):
            return False

    import app.core.db as core_db
    monkeypatch.setattr(core_db, "AsyncSessionLocal", lambda: _FakeSession())

    executor = mod.ArbExecutor(clob=MagicMock())
    await executor._maybe_settle(pos, resolution_map)

    assert pos.resolved_payout_usdc == 50.0, \
        f"BUG-N35 REGRESSION: payout={pos.resolved_payout_usdc} (expected 50.0)."
    assert pos.winning_leg == "no"


@pytest.mark.asyncio
async def test_bugN35_neither_won_anomalous(monkeypatch):
    """Scenario: both legs lost (anomalous — shouldn't happen for valid arb,
    but tests defensive code). Correct: payout $0, winning_leg='neither'.
    """
    from app.services import arb_executor as mod

    pos = _make_position(yes_tokens=50.0, no_tokens=50.0, total_cost=9.50)

    resolution_map = {
        "tok-yes-A": {"closed": True, "outcome": "Yes", "price": "0"},
        "tok-no-B": {"closed": True, "outcome": "No", "price": "0"},
    }

    fake_db = MagicMock()
    fake_db.scalar = AsyncMock(return_value=pos)
    fake_db.commit = AsyncMock()

    class _FakeSession:
        async def __aenter__(self):
            return fake_db
        async def __aexit__(self, *a):
            return False

    import app.core.db as core_db
    monkeypatch.setattr(core_db, "AsyncSessionLocal", lambda: _FakeSession())

    executor = mod.ArbExecutor(clob=MagicMock())
    await executor._maybe_settle(pos, resolution_map)

    assert pos.resolved_payout_usdc == 0.0
    assert pos.winning_leg == "neither"


def test_price_won_helper():
    """Direct test for the _price_won helper."""
    from app.services.arb_executor import _price_won

    assert _price_won("1") is True
    assert _price_won("1.0") is True
    assert _price_won(1) is True
    assert _price_won(1.0) is True
    assert _price_won("0.999998") is True   # rounding artifact
    assert _price_won("1.000001") is True

    assert _price_won("0") is False
    assert _price_won("0.0") is False
    assert _price_won(0) is False
    assert _price_won(0.0) is False
    assert _price_won("0.01") is False
    assert _price_won("0.5") is False   # ambiguous middle → False (defensive)
    assert _price_won(None) is False
    assert _price_won("") is False
    assert _price_won("not-a-number") is False
