# CryptoParser Buyer Onboarding (1-Page)

## 1) What You Bought

CryptoParser is a local token analysis bot + analyst dashboard.

- API + UI: `http://localhost:8080/analyst`
- Decisions: `APPROVE / REJECT / REVIEW_LATER`
- Includes dedicated `Approved` feed in the left menu

## 2) Quick Setup (5-15 min)

1. Install Python 3.11+.
2. Open project folder in terminal.
3. Install dependencies:
   ```powershell
   pip install -r requirements.txt
   ```
4. Create env:
   ```powershell
   Copy-Item .env.example .env
   ```
5. Edit `.env` and set:
   - `ADMIN_API_TOKEN` (required)
   - optional API keys (`BIRDEYE_API_KEY`, `CMC_API_KEY`, etc.)

## 3) Start

Windows:

```powershell
.\start.bat
```

Manual (any OS, 2 terminals):

```bash
python -m app.main scheduler
python -m app.main admin
```

Then open:

- `http://localhost:8080/analyst`
- or `http://localhost:8080/analyst?token=YOUR_ADMIN_API_TOKEN`

## 4) First Use Checklist

1. Press `Connect`.
2. Open `Dashboard` and confirm metrics load.
3. Open `Approved` page to see approved feed.
4. Open `Tokens` page and test filters.

## 5) Stop / Restart

- If started via `start.bat`, close the window.
- If manual, stop both Python processes and start again.

## 6) Troubleshooting

- `auth failed`: wrong `ADMIN_API_TOKEN`.
- UI not opening: check `ADMIN_API_PORT` in `.env` (default `8080`).
- No data: run scheduler and wait 1-3 cycles.

## 7) Important

- Do not share your `.env` file.
- This tool is for analytics and research only, not financial advice.

