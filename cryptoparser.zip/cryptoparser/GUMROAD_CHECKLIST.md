# Gumroad Release Checklist

## 1. Security And Cleanup

- [ ] Verify `.env` is **not** included in the package.
- [ ] Verify `cryptoparser.db` is **not** included.
- [ ] Verify `admin.log` / `scheduler.log` are **not** included.
- [ ] Ensure `ADMIN_API_TOKEN` in docs is placeholder only.
- [ ] Confirm no API keys are hardcoded in source.

## 2. Build Sale Package

- [ ] Run:
  ```powershell
  .\scripts\build_gumroad_package.ps1
  ```
- [ ] Confirm zip exists in `dist/`.
- [ ] Open zip and verify expected files only.

## 3. Buyer Experience

- [ ] `README.md` explains install + run in under 5 minutes.
- [ ] `.env.example` has sane defaults.
- [ ] `start.bat` launches both scheduler + admin API.
- [ ] Dashboard opens on `/analyst` and accepts token.
- [ ] `Approved` feed is visible in the left menu.

## 4. Gumroad Product Page

- [ ] Use `GUMROAD_LISTING.md` as listing draft.
- [ ] Upload the zip from `dist/`.
- [ ] Add support contact email/Telegram.
- [ ] Add update policy (e.g. 30/60/90 days).

## 5. Final QA Before Publish

- [ ] Fresh machine test with only `.env.example`.
- [ ] `pip install -r requirements.txt` succeeds.
- [ ] `python -m app.main admin` starts without tracebacks.
- [ ] `python -m app.main scheduler` starts without tracebacks.

