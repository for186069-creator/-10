# Gumroad Listing Draft

## Product Title

CryptoParser - Local Crypto Token Scanner + Analyst Dashboard (Python)

## Short Description

Production-ready crypto token analysis stack with automated scoring, multi-source ingestion, and a clean analyst dashboard, including a dedicated Approved Tokens feed.

## What Buyers Get

- Full source code
- Analyst web dashboard
- Scheduler-based ingestion pipeline
- Pump.fun / listings integrations
- Risk scoring + decision workflow
- Setup docs and `.env.example`
- Gumroad packaging script

## Core Features

- Multi-source token discovery and filtering
- Decision classes: APPROVE / REJECT / REVIEW_LATER
- Evidence-aware scoring pipeline
- Alerts, reviews, blacklist, and reputation views
- Dedicated Approved feed in UI for quick scanning

## Requirements

- Python 3.11+
- Windows, Linux, or macOS
- Internet connection for external APIs

## Setup Time

5-15 minutes with provided docs.

## Disclaimer

For research and tooling purposes only. Not financial advice.

