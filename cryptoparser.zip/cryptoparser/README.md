# CryptoParser

CryptoParser is a local-first crypto token screening system with an analyst dashboard, multi-source ingestion, and automated risk scoring.

## What It Does

- Ingests token candidates from multiple sources (DexScreener, Pump.fun, listings feeds).
- Applies rule-based checks plus blended scoring.
- Tracks decisions (`APPROVE`, `REJECT`, `REVIEW_LATER`) with evidence.
- Provides an analyst UI at `/analyst` with filters, alerts, reviews, blacklist, and reputation tools.
- Includes a dedicated `Approved` feed in the UI for quickly browsing approved tokens.

## Stack

- Python 3.11+
- FastAPI + Uvicorn
- SQLAlchemy (SQLite by default)
- Optional Redis

## Quick Start (Windows)

1. Install Python 3.11+.
2. Install dependencies:
   ```powershell
   pip install -r requirements.txt
   ```
3. Create config file:
   ```powershell
   Copy-Item .env.example .env
   ```
4. Set your `ADMIN_API_TOKEN` and API keys in `.env`.
5. Start:
   ```powershell
   .\start.bat
   ```
6. Open: `http://localhost:8080/analyst` (or `http://localhost:8080/analyst?token=YOUR_TOKEN`).

## Quick Start (Manual / Any OS)

Run in separate terminals:

```bash
python -m app.main scheduler
python -m app.main admin
```

## Main Entry Points

- Admin API + UI: `python -m app.main admin`
- Scheduler / ingestion loop: `python -m app.main scheduler`
- One-shot pipeline run: `python -m app.main once`

## Configuration

Use `.env.example` as a template. At minimum set:

- `ADMIN_API_TOKEN`
- `ADMIN_API_PORT`
- Optional provider keys (e.g. `BIRDEYE_API_KEY`, `CMC_API_KEY`, `ETHERSCAN_API_KEY`)

## Packaging For Gumroad

- Build clean archive:
  ```powershell
  .\scripts\build_gumroad_package.ps1
  ```
- Checklist: see `GUMROAD_CHECKLIST.md`
- Listing draft: see `GUMROAD_LISTING.md`

## Important

- Do not distribute real `.env`, `cryptoparser.db`, or log files.
- This software is not financial advice.

