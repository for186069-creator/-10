"""initial schema"""

from alembic import op
import sqlalchemy as sa

revision = '0001_initial'
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table('token_candidates',
        sa.Column('id', sa.Integer(), primary_key=True),
        sa.Column('chain', sa.String(length=24), nullable=False),
        sa.Column('token_address', sa.String(length=128), nullable=False),
        sa.Column('pair_address', sa.String(length=128), nullable=True),
        sa.Column('symbol', sa.String(length=64), nullable=True),
        sa.Column('name', sa.String(length=255), nullable=True),
        sa.Column('deployer_address', sa.String(length=128), nullable=True),
        sa.Column('first_seen_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('liquidity_usd', sa.Float(), nullable=True),
        sa.Column('holders', sa.Integer(), nullable=True),
        sa.Column('website', sa.String(length=512), nullable=True),
        sa.Column('x_handle', sa.String(length=128), nullable=True),
        sa.Column('telegram_url', sa.String(length=512), nullable=True),
        sa.Column('raw', sa.JSON(), nullable=False),
        sa.UniqueConstraint('chain', 'token_address', name='uq_chain_token')
    )
    op.create_table('token_decisions',
        sa.Column('id', sa.Integer(), primary_key=True),
        sa.Column('chain', sa.String(length=24), nullable=False),
        sa.Column('token_address', sa.String(length=128), nullable=False),
        sa.Column('status', sa.String(length=32), nullable=False),
        sa.Column('score', sa.Float(), nullable=False),
        sa.Column('reasons', sa.JSON(), nullable=False),
        sa.Column('subscores', sa.JSON(), nullable=False),
        sa.Column('evidence', sa.JSON(), nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    )
    op.create_table('reputation_entities', sa.Column('id', sa.Integer(), primary_key=True), sa.Column('entity_type', sa.String(64), nullable=False), sa.Column('entity_value', sa.String(512), nullable=False), sa.Column('reputation_score', sa.Float(), nullable=False), sa.Column('flagged', sa.Boolean(), nullable=False), sa.Column('reason_code', sa.String(128), nullable=True), sa.Column('evidence', sa.JSON(), nullable=False), sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False), sa.UniqueConstraint('entity_type', 'entity_value', name='uq_entity_reputation'))
    op.create_table('scam_blacklists', sa.Column('id', sa.Integer(), primary_key=True), sa.Column('entity_type', sa.String(64), nullable=False), sa.Column('entity_value', sa.String(512), nullable=False), sa.Column('reason_code', sa.String(128), nullable=False), sa.Column('source', sa.String(128), nullable=True), sa.Column('confidence', sa.Float(), nullable=False), sa.Column('evidence', sa.JSON(), nullable=False), sa.Column('active', sa.Boolean(), nullable=False), sa.Column('created_at', sa.DateTime(timezone=True), nullable=False), sa.UniqueConstraint('entity_type', 'entity_value', name='uq_entity_blacklist'))
    op.create_table('deployer_history', sa.Column('id', sa.Integer(), primary_key=True), sa.Column('chain', sa.String(24), nullable=False), sa.Column('wallet_address', sa.String(128), nullable=False), sa.Column('launches_count', sa.Integer(), nullable=False), sa.Column('dead_tokens_count', sa.Integer(), nullable=False), sa.Column('rugs_count', sa.Integer(), nullable=False), sa.Column('avg_token_lifetime_days', sa.Float(), nullable=True), sa.Column('funding_wallet', sa.String(128), nullable=True), sa.Column('reputation_score', sa.Float(), nullable=False), sa.Column('suspicious_patterns', sa.JSON(), nullable=False), sa.Column('evidence', sa.JSON(), nullable=False), sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False), sa.UniqueConstraint('chain', 'wallet_address', name='uq_deployer_history'))
    op.create_table('contract_fingerprints', sa.Column('id', sa.Integer(), primary_key=True), sa.Column('chain', sa.String(24), nullable=False), sa.Column('token_address', sa.String(128), nullable=False), sa.Column('bytecode_hash', sa.String(128), nullable=True), sa.Column('fingerprint_hash', sa.String(128), nullable=True), sa.Column('selectors', sa.JSON(), nullable=False), sa.Column('suspicious_selectors', sa.JSON(), nullable=False), sa.Column('similarity_score', sa.Float(), nullable=False), sa.Column('matched_template', sa.String(128), nullable=True), sa.Column('reasons', sa.JSON(), nullable=False), sa.Column('created_at', sa.DateTime(timezone=True), nullable=False), sa.UniqueConstraint('chain', 'token_address', name='uq_contract_fingerprint'))
    op.create_table('wallet_clusters', sa.Column('id', sa.Integer(), primary_key=True), sa.Column('cluster_id', sa.String(128), nullable=False), sa.Column('wallets', sa.JSON(), nullable=False), sa.Column('risk_score', sa.Float(), nullable=False), sa.Column('labels', sa.JSON(), nullable=False), sa.Column('evidence', sa.JSON(), nullable=False), sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False), sa.UniqueConstraint('cluster_id', name='uq_cluster_id'))
    op.create_table('manual_reviews', sa.Column('id', sa.Integer(), primary_key=True), sa.Column('chain', sa.String(24), nullable=False), sa.Column('token_address', sa.String(128), nullable=False), sa.Column('status', sa.String(32), nullable=False), sa.Column('assigned_to', sa.String(128), nullable=True), sa.Column('notes', sa.Text(), nullable=False), sa.Column('created_at', sa.DateTime(timezone=True), nullable=False), sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False))
    op.create_table('audit_logs', sa.Column('id', sa.Integer(), primary_key=True), sa.Column('event_type', sa.String(64), nullable=False), sa.Column('token_address', sa.String(128), nullable=True), sa.Column('payload', sa.JSON(), nullable=False), sa.Column('created_at', sa.DateTime(timezone=True), nullable=False))


def downgrade() -> None:
    for table in ['audit_logs', 'manual_reviews', 'wallet_clusters', 'contract_fingerprints', 'deployer_history', 'scam_blacklists', 'reputation_entities', 'token_decisions', 'token_candidates']:
        op.drop_table(table)
