"""graph store and analytics tables"""

from alembic import op
import sqlalchemy as sa

revision = '0002_graph_store'
down_revision = '0001_initial'
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        'wallet_nodes',
        sa.Column('id', sa.Integer(), primary_key=True),
        sa.Column('chain', sa.String(length=24), nullable=False),
        sa.Column('wallet_address', sa.String(length=128), nullable=False),
        sa.Column('labels', sa.JSON(), nullable=False),
        sa.Column('risk_score', sa.Float(), nullable=False),
        sa.Column('metadata', sa.JSON(), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint('chain', 'wallet_address', name='uq_wallet_node'),
    )
    op.create_table(
        'wallet_edges',
        sa.Column('id', sa.Integer(), primary_key=True),
        sa.Column('chain', sa.String(length=24), nullable=False),
        sa.Column('src_wallet', sa.String(length=128), nullable=False),
        sa.Column('dst_wallet', sa.String(length=128), nullable=False),
        sa.Column('edge_type', sa.String(length=32), nullable=False),
        sa.Column('weight', sa.Float(), nullable=False),
        sa.Column('evidence', sa.JSON(), nullable=False),
        sa.Column('last_seen_at', sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint('chain', 'src_wallet', 'dst_wallet', 'edge_type', name='uq_wallet_edge'),
    )


def downgrade() -> None:
    op.drop_table('wallet_edges')
    op.drop_table('wallet_nodes')
