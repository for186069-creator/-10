"""graph score runs

Revision ID: 0003_graph_score_runs
Revises: 0002_graph_store
Create Date: 2026-03-28
"""
from alembic import op
import sqlalchemy as sa

revision = '0003_graph_score_runs'
down_revision = '0002_graph_store'
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        'graph_score_runs',
        sa.Column('id', sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column('chain', sa.String(length=24), nullable=False),
        sa.Column('status', sa.String(length=32), nullable=False),
        sa.Column('nodes_scored', sa.Integer(), nullable=False, server_default='0'),
        sa.Column('clusters_scored', sa.Integer(), nullable=False, server_default='0'),
        sa.Column('summary', sa.JSON(), nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index('ix_graph_score_runs_chain', 'graph_score_runs', ['chain'])
    op.create_index('ix_graph_score_runs_status', 'graph_score_runs', ['status'])


def downgrade() -> None:
    op.drop_index('ix_graph_score_runs_status', table_name='graph_score_runs')
    op.drop_index('ix_graph_score_runs_chain', table_name='graph_score_runs')
    op.drop_table('graph_score_runs')
