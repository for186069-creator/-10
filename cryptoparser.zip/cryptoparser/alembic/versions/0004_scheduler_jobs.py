"""scheduler jobs

Revision ID: 0004_scheduler_jobs
Revises: 0003_graph_score_runs
Create Date: 2026-03-28
"""
from alembic import op
import sqlalchemy as sa

revision = '0004_scheduler_jobs'
down_revision = '0003_graph_score_runs'
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        'scheduled_jobs',
        sa.Column('id', sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column('job_name', sa.String(length=128), nullable=False),
        sa.Column('enabled', sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column('interval_seconds', sa.Integer(), nullable=False, server_default='300'),
        sa.Column('next_run_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('last_run_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('last_error', sa.Text(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint('job_name', name='uq_scheduled_job'),
    )
    op.create_index('ix_scheduled_jobs_job_name', 'scheduled_jobs', ['job_name'])
    op.create_index('ix_scheduled_jobs_next_run_at', 'scheduled_jobs', ['next_run_at'])

    op.create_table(
        'job_runs',
        sa.Column('id', sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column('job_name', sa.String(length=128), nullable=False),
        sa.Column('status', sa.String(length=32), nullable=False, server_default='RUNNING'),
        sa.Column('started_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('finished_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('error_message', sa.Text(), nullable=True),
    )
    op.create_index('ix_job_runs_job_name', 'job_runs', ['job_name'])
    op.create_index('ix_job_runs_status', 'job_runs', ['status'])


def downgrade() -> None:
    op.drop_index('ix_job_runs_status', table_name='job_runs')
    op.drop_index('ix_job_runs_job_name', table_name='job_runs')
    op.drop_table('job_runs')
    op.drop_index('ix_scheduled_jobs_next_run_at', table_name='scheduled_jobs')
    op.drop_index('ix_scheduled_jobs_job_name', table_name='scheduled_jobs')
    op.drop_table('scheduled_jobs')
