"""add intelligence layers tables

Revision ID: 0005_intelligence_layers
Revises: 0004_scheduler_jobs
Create Date: 2026-03-28
"""
from alembic import op
import sqlalchemy as sa


revision = '0005_intelligence_layers'
down_revision = '0004_scheduler_jobs'
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        'historical_tokens',
        sa.Column('id', sa.Integer(), primary_key=True),
        sa.Column('chain', sa.String(length=24), nullable=False),
        sa.Column('token_address', sa.String(length=128), nullable=False),
        sa.Column('first_seen_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('first_decision', sa.String(length=32), nullable=True),
        sa.Column('latest_decision', sa.String(length=32), nullable=True),
        sa.Column('peak_liquidity_usd', sa.Float(), nullable=True),
        sa.Column('latest_liquidity_usd', sa.Float(), nullable=True),
        sa.Column('peak_holders', sa.Integer(), nullable=True),
        sa.Column('latest_holders', sa.Integer(), nullable=True),
        sa.Column('historical_score', sa.Float(), nullable=False, server_default='50'),
        sa.Column('labels', sa.JSON(), nullable=False),
        sa.Column('notes', sa.JSON(), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint('chain', 'token_address', name='uq_historical_token'),
    )
    op.create_table(
        'analyst_labels',
        sa.Column('id', sa.Integer(), primary_key=True),
        sa.Column('chain', sa.String(length=24), nullable=False),
        sa.Column('token_address', sa.String(length=128), nullable=False),
        sa.Column('label', sa.String(length=64), nullable=False),
        sa.Column('value', sa.String(length=64), nullable=False),
        sa.Column('analyst', sa.String(length=128), nullable=True),
        sa.Column('notes', sa.Text(), nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    )
    op.create_table(
        'realtime_alerts',
        sa.Column('id', sa.Integer(), primary_key=True),
        sa.Column('chain', sa.String(length=24), nullable=False),
        sa.Column('token_address', sa.String(length=128), nullable=False),
        sa.Column('event_type', sa.String(length=64), nullable=False),
        sa.Column('severity', sa.String(length=32), nullable=False),
        sa.Column('payload', sa.JSON(), nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index('ix_historical_tokens_chain', 'historical_tokens', ['chain'])
    op.create_index('ix_historical_tokens_token_address', 'historical_tokens', ['token_address'])
    op.create_index('ix_analyst_labels_chain', 'analyst_labels', ['chain'])
    op.create_index('ix_analyst_labels_token_address', 'analyst_labels', ['token_address'])
    op.create_index('ix_analyst_labels_label', 'analyst_labels', ['label'])
    op.create_index('ix_realtime_alerts_chain', 'realtime_alerts', ['chain'])
    op.create_index('ix_realtime_alerts_token_address', 'realtime_alerts', ['token_address'])
    op.create_index('ix_realtime_alerts_event_type', 'realtime_alerts', ['event_type'])


def downgrade() -> None:
    op.drop_index('ix_realtime_alerts_event_type', table_name='realtime_alerts')
    op.drop_index('ix_realtime_alerts_token_address', table_name='realtime_alerts')
    op.drop_index('ix_realtime_alerts_chain', table_name='realtime_alerts')
    op.drop_index('ix_analyst_labels_label', table_name='analyst_labels')
    op.drop_index('ix_analyst_labels_token_address', table_name='analyst_labels')
    op.drop_index('ix_analyst_labels_chain', table_name='analyst_labels')
    op.drop_index('ix_historical_tokens_token_address', table_name='historical_tokens')
    op.drop_index('ix_historical_tokens_chain', table_name='historical_tokens')
    op.drop_table('realtime_alerts')
    op.drop_table('analyst_labels')
    op.drop_table('historical_tokens')
