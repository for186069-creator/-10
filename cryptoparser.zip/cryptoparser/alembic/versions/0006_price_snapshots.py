"""add price_snapshots table

Revision ID: 0006_price_snapshots
Revises: 0005_intelligence_layers
Create Date: 2026-03-29
"""
from alembic import op
import sqlalchemy as sa

revision = '0006_price_snapshots'
down_revision = '0005_intelligence_layers'
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        'price_snapshots',
        sa.Column('id', sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column('chain', sa.String(length=24), nullable=False),
        sa.Column('token_address', sa.String(length=128), nullable=False),
        sa.Column('liquidity_usd', sa.Float(), nullable=False, server_default='0'),
        sa.Column('recorded_at', sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index('ix_price_snapshots_chain_token', 'price_snapshots', ['chain', 'token_address'])
    op.create_index('ix_price_snapshots_recorded_at', 'price_snapshots', ['recorded_at'])


def downgrade() -> None:
    op.drop_index('ix_price_snapshots_recorded_at', table_name='price_snapshots')
    op.drop_index('ix_price_snapshots_chain_token', table_name='price_snapshots')
    op.drop_table('price_snapshots')
