"""add persisted lifecycle fields to token_candidates

Revision ID: 0007_token_candidate_lifecycle
Revises: 0006_price_snapshots
Create Date: 2026-04-05
"""

from alembic import op
import sqlalchemy as sa

revision = '0007_token_candidate_lifecycle'
down_revision = '0006_price_snapshots'
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column('token_candidates', sa.Column('token_family', sa.String(length=64), nullable=True))
    op.add_column('token_candidates', sa.Column('launchpad', sa.String(length=64), nullable=True))
    op.add_column('token_candidates', sa.Column('lifecycle_stage', sa.String(length=64), nullable=True))
    op.add_column('token_candidates', sa.Column('graduated_confirmed', sa.Boolean(), nullable=False, server_default=sa.false()))
    op.create_index('ix_token_candidates_token_family', 'token_candidates', ['token_family'])
    op.create_index('ix_token_candidates_launchpad', 'token_candidates', ['launchpad'])
    op.create_index('ix_token_candidates_lifecycle_stage', 'token_candidates', ['lifecycle_stage'])
    op.create_index('ix_token_candidates_graduated_confirmed', 'token_candidates', ['graduated_confirmed'])


def downgrade() -> None:
    op.drop_index('ix_token_candidates_graduated_confirmed', table_name='token_candidates')
    op.drop_index('ix_token_candidates_lifecycle_stage', table_name='token_candidates')
    op.drop_index('ix_token_candidates_launchpad', table_name='token_candidates')
    op.drop_index('ix_token_candidates_token_family', table_name='token_candidates')
    op.drop_column('token_candidates', 'graduated_confirmed')
    op.drop_column('token_candidates', 'lifecycle_stage')
    op.drop_column('token_candidates', 'launchpad')
    op.drop_column('token_candidates', 'token_family')
