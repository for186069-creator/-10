"""pulse os lifecycle and snapshots

Revision ID: 0008
Revises: 0007
Create Date: 2026-05-07
"""
from alembic import op
import sqlalchemy as sa

revision = '0008'
down_revision = '0007_token_candidate_lifecycle'
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        'token_lifecycle',
        sa.Column('id', sa.Integer, primary_key=True, autoincrement=True),
        sa.Column('chain', sa.String(24), nullable=False),
        sa.Column('token_address', sa.String(128), nullable=False),
        sa.Column('symbol', sa.String(64), nullable=True),
        sa.Column('status', sa.String(32), nullable=False, default='watching'),
        sa.Column('strategy', sa.String(32), nullable=True),
        sa.Column('entry_price', sa.Float, nullable=True),
        sa.Column('current_price', sa.Float, nullable=True),
        sa.Column('peak_price', sa.Float, nullable=True),
        sa.Column('exit_price', sa.Float, nullable=True),
        sa.Column('entry_liquidity_usd', sa.Float, nullable=True),
        sa.Column('peak_liquidity_usd', sa.Float, nullable=True),
        sa.Column('current_liquidity_usd', sa.Float, nullable=True),
        sa.Column('entry_holders', sa.Integer, nullable=True),
        sa.Column('peak_holders', sa.Integer, nullable=True),
        sa.Column('current_holders', sa.Integer, nullable=True),
        sa.Column('paper_size_usd', sa.Float, nullable=False, default=100.0),
        sa.Column('paper_pnl_usd', sa.Float, nullable=False, default=0.0),
        sa.Column('paper_pnl_pct', sa.Float, nullable=False, default=0.0),
        sa.Column('stop_loss_pct', sa.Float, nullable=False, default=-25.0),
        sa.Column('take_profit_pct', sa.Float, nullable=False, default=100.0),
        sa.Column('trailing_stop_pct', sa.Float, nullable=False, default=-15.0),
        sa.Column('time_limit_minutes', sa.Integer, nullable=False, default=60),
        sa.Column('exit_reason', sa.String(64), nullable=True),
        sa.Column('entry_continuation_score', sa.Float, nullable=True),
        sa.Column('entry_risk_score', sa.Float, nullable=True),
        sa.Column('entry_brain_strategy', sa.String(32), nullable=True),
        sa.Column('bundle_severity', sa.String(32), nullable=True),
        sa.Column('bundle_wallet_count', sa.Integer, nullable=True),
        sa.Column('bundle_supply_pct', sa.Float, nullable=True),
        sa.Column('first_seen_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('entry_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('peak_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('exit_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('last_checked_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint('chain', 'token_address', name='uq_lifecycle'),
    )
    op.create_index('ix_token_lifecycle_chain', 'token_lifecycle', ['chain'])
    op.create_index('ix_token_lifecycle_token_address', 'token_lifecycle', ['token_address'])
    op.create_index('ix_token_lifecycle_status', 'token_lifecycle', ['status'])

    op.create_table(
        'price_snapshots_pulse',
        sa.Column('id', sa.Integer, primary_key=True, autoincrement=True),
        sa.Column('chain', sa.String(24), nullable=False),
        sa.Column('token_address', sa.String(128), nullable=False),
        sa.Column('price_usd', sa.Float, nullable=True),
        sa.Column('liquidity_usd', sa.Float, nullable=True),
        sa.Column('holders', sa.Integer, nullable=True),
        sa.Column('market_cap_usd', sa.Float, nullable=True),
        sa.Column('source', sa.String(32), nullable=False, default='dexscreener'),
        sa.Column('captured_at', sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index('ix_price_snapshots_pulse_chain', 'price_snapshots_pulse', ['chain'])
    op.create_index('ix_price_snapshots_pulse_token_address', 'price_snapshots_pulse', ['token_address'])
    op.create_index('ix_price_snapshots_pulse_captured_at', 'price_snapshots_pulse', ['captured_at'])


def downgrade() -> None:
    op.drop_index('ix_price_snapshots_pulse_captured_at', table_name='price_snapshots_pulse')
    op.drop_index('ix_price_snapshots_pulse_token_address', table_name='price_snapshots_pulse')
    op.drop_index('ix_price_snapshots_pulse_chain', table_name='price_snapshots_pulse')
    op.drop_table('price_snapshots_pulse')
    op.drop_index('ix_token_lifecycle_status', table_name='token_lifecycle')
    op.drop_index('ix_token_lifecycle_token_address', table_name='token_lifecycle')
    op.drop_index('ix_token_lifecycle_chain', table_name='token_lifecycle')
    op.drop_table('token_lifecycle')
