"""farm mode positions

Revision ID: 0009
Revises: 0008
Create Date: 2026-05-07
"""
from alembic import op
import sqlalchemy as sa

revision = '0009'
down_revision = '0008'
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        'farm_positions',
        sa.Column('id', sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column('mint', sa.String(128), nullable=False),
        sa.Column('symbol', sa.String(64), nullable=True),
        sa.Column('entry_price', sa.Float(), nullable=False),
        sa.Column('entry_time', sa.DateTime(timezone=True), nullable=True),
        sa.Column('paper_amount_usd', sa.Float(), default=20.0),
        sa.Column('bundle_wallet_count', sa.Integer(), nullable=True),
        sa.Column('bundle_pct', sa.Float(), nullable=True),
        sa.Column('bundle_farm_score', sa.Float(), nullable=True),
        sa.Column('bundle_wallets_json', sa.Text(), nullable=True),
        sa.Column('exit_price', sa.Float(), nullable=True),
        sa.Column('exit_time', sa.DateTime(timezone=True), nullable=True),
        sa.Column('exit_reason', sa.String(64), nullable=True),
        sa.Column('pnl_pct', sa.Float(), nullable=True),
        sa.Column('pnl_usd', sa.Float(), nullable=True),
        sa.Column('current_price', sa.Float(), nullable=True),
        sa.Column('peak_price', sa.Float(), nullable=True),
        sa.Column('last_checked', sa.DateTime(timezone=True), nullable=True),
        sa.Column('status', sa.String(32), default='OPEN'),
        sa.Column('bundle_sold_pct', sa.Float(), default=0.0),
        sa.Column('bundle_danger', sa.Boolean(), default=False),
    )
    op.create_index('ix_farm_positions_mint', 'farm_positions', ['mint'])
    op.create_index('ix_farm_positions_status', 'farm_positions', ['status'])


def downgrade() -> None:
    op.drop_index('ix_farm_positions_status', table_name='farm_positions')
    op.drop_index('ix_farm_positions_mint', table_name='farm_positions')
    op.drop_table('farm_positions')
