"""add taxes_buy_pct and taxes_sell_pct to token_candidates

Revision ID: 0010_tax_fields
Revises: 0009
Create Date: 2026-05-08
"""

from alembic import op
import sqlalchemy as sa

revision = '0010_tax_fields'
down_revision = '0009'
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column('token_candidates', sa.Column('taxes_buy_pct', sa.Float(), nullable=True))
    op.add_column('token_candidates', sa.Column('taxes_sell_pct', sa.Float(), nullable=True))


def downgrade() -> None:
    op.drop_column('token_candidates', 'taxes_sell_pct')
    op.drop_column('token_candidates', 'taxes_buy_pct')
