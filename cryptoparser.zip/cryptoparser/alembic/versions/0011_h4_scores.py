"""add pulse_score and component_scores to token_lifecycle

Revision ID: 0011_h4_scores
Revises: 0010_tax_fields
Create Date: 2026-05-08
"""

from alembic import op
import sqlalchemy as sa

revision = '0011_h4_scores'
down_revision = '0010_tax_fields'
branch_labels = None
depends_on = None


def upgrade() -> None:
    # FIX BUG 7+9: was empty (pass). Now correctly adds H4 brain score fields
    # to token_lifecycle (was broken as PaperPosition monkey-patch in models.py)
    op.add_column('token_lifecycle', sa.Column('pulse_score', sa.Float(), nullable=True))
    op.add_column('token_lifecycle', sa.Column('component_scores_json', sa.Text(), nullable=True))


def downgrade() -> None:
    op.drop_column('token_lifecycle', 'component_scores_json')
    op.drop_column('token_lifecycle', 'pulse_score')
