"""add pulse risk controls, signals and ml fields

Revision ID: 0012_pulse_risk_and_ml_fields
Revises: 0011_h4_scores
Create Date: 2026-05-10
"""

from alembic import op
import sqlalchemy as sa

revision = '0012_pulse_risk_and_ml_fields'
down_revision = '0011_h4_scores'
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column('token_lifecycle', sa.Column('raw_exit_price', sa.Float(), nullable=True))
    op.add_column('token_lifecycle', sa.Column('token_family', sa.String(length=64), nullable=True))
    op.add_column('token_lifecycle', sa.Column('partial_exit_done', sa.Boolean(), nullable=False, server_default=sa.false()))
    op.add_column('token_lifecycle', sa.Column('partial_exit_pct', sa.Float(), nullable=True))
    op.add_column('token_lifecycle', sa.Column('entry_signals', sa.JSON(), nullable=True))
    op.add_column('token_lifecycle', sa.Column('exit_signals', sa.JSON(), nullable=True))


def downgrade() -> None:
    op.drop_column('token_lifecycle', 'exit_signals')
    op.drop_column('token_lifecycle', 'entry_signals')
    op.drop_column('token_lifecycle', 'partial_exit_pct')
    op.drop_column('token_lifecycle', 'partial_exit_done')
    op.drop_column('token_lifecycle', 'token_family')
    op.drop_column('token_lifecycle', 'raw_exit_price')
