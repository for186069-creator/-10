"""add pulse batch timing fields

Revision ID: 0013_handoff5_batch_timing_volume_health
Revises: 0012_pulse_risk_and_ml_fields
Create Date: 2026-05-10
"""

from alembic import op
import sqlalchemy as sa


revision = '0013_handoff5_batch_timing_volume_health'
down_revision = '0012_pulse_risk_and_ml_fields'
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column('token_lifecycle', sa.Column('pair_address', sa.String(length=128), nullable=True))
    op.add_column('token_lifecycle', sa.Column('graduated_at', sa.DateTime(timezone=True), nullable=True))
    op.add_column('token_lifecycle', sa.Column('entry_delay_seconds', sa.Integer(), nullable=True))


def downgrade() -> None:
    op.drop_column('token_lifecycle', 'entry_delay_seconds')
    op.drop_column('token_lifecycle', 'graduated_at')
    op.drop_column('token_lifecycle', 'pair_address')
