"""Handoff #6/#7 execution realism and ML/backtesting

Revision ID: 0014_handoff6_execution_and_ml
Revises: 0013_handoff5_batch_timing_volume_health
Create Date: 2026-05-10 00:00:00.000000
"""

from __future__ import annotations

from alembic import op
import sqlalchemy as sa


revision = '0014_handoff6_execution_and_ml'
down_revision = '0013_handoff5_batch_timing_volume_health'
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column('token_lifecycle', sa.Column('entry_execution_price', sa.Float(), nullable=True))
    op.add_column('token_lifecycle', sa.Column('entry_latency_seconds', sa.Integer(), nullable=True))
    op.add_column('token_lifecycle', sa.Column('exit_latency_seconds', sa.Integer(), nullable=True))
    op.add_column('token_lifecycle', sa.Column('execution_fees_usd', sa.Float(), nullable=False, server_default=sa.text('0')))
    op.add_column('token_lifecycle', sa.Column('remaining_size_usd', sa.Float(), nullable=True))
    op.add_column('token_lifecycle', sa.Column('realized_pnl_usd', sa.Float(), nullable=False, server_default=sa.text('0')))
    op.add_column('token_lifecycle', sa.Column('reentry_count', sa.Integer(), nullable=False, server_default=sa.text('0')))


def downgrade() -> None:
    op.drop_column('token_lifecycle', 'reentry_count')
    op.drop_column('token_lifecycle', 'realized_pnl_usd')
    op.drop_column('token_lifecycle', 'remaining_size_usd')
    op.drop_column('token_lifecycle', 'execution_fees_usd')
    op.drop_column('token_lifecycle', 'exit_latency_seconds')
    op.drop_column('token_lifecycle', 'entry_latency_seconds')
    op.drop_column('token_lifecycle', 'entry_execution_price')
