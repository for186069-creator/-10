"""Handoff #8/#9 execution microstructure and live-ready state machine

Revision ID: 0015_handoff8_execution_microstructure_live_ready
Revises: 0014_handoff6_execution_and_ml
Create Date: 2026-05-10 00:00:00.000000
"""

from __future__ import annotations

from alembic import op
import sqlalchemy as sa


revision = '0015_handoff8_execution_microstructure_live_ready'
down_revision = '0014_handoff6_execution_and_ml'
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column('token_lifecycle', sa.Column('requested_size_usd', sa.Float(), nullable=True))
    op.add_column('token_lifecycle', sa.Column('filled_size_usd', sa.Float(), nullable=True))
    op.add_column('token_lifecycle', sa.Column('fill_pct', sa.Float(), nullable=True))
    op.add_column('token_lifecycle', sa.Column('entry_slippage_pct', sa.Float(), nullable=True))
    op.add_column('token_lifecycle', sa.Column('exit_slippage_pct', sa.Float(), nullable=True))
    op.add_column('token_lifecycle', sa.Column('entry_spread_pct', sa.Float(), nullable=True))
    op.add_column('token_lifecycle', sa.Column('exit_spread_pct', sa.Float(), nullable=True))
    op.add_column('token_lifecycle', sa.Column('entry_impact_pct', sa.Float(), nullable=True))
    op.add_column('token_lifecycle', sa.Column('exit_impact_pct', sa.Float(), nullable=True))
    op.add_column('token_lifecycle', sa.Column('execution_state', sa.String(length=32), nullable=False, server_default='new'))
    op.add_column('token_lifecycle', sa.Column('execution_state_reason', sa.String(length=128), nullable=True))
    op.add_column(
        'token_lifecycle',
        sa.Column('execution_state_updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.text("CURRENT_TIMESTAMP")),
    )
    op.add_column('token_lifecycle', sa.Column('execution_attempts', sa.Integer(), nullable=False, server_default=sa.text('0')))
    op.add_column('token_lifecycle', sa.Column('execution_metadata', sa.JSON(), nullable=True))


def downgrade() -> None:
    op.drop_column('token_lifecycle', 'execution_metadata')
    op.drop_column('token_lifecycle', 'execution_attempts')
    op.drop_column('token_lifecycle', 'execution_state_updated_at')
    op.drop_column('token_lifecycle', 'execution_state_reason')
    op.drop_column('token_lifecycle', 'execution_state')
    op.drop_column('token_lifecycle', 'exit_impact_pct')
    op.drop_column('token_lifecycle', 'entry_impact_pct')
    op.drop_column('token_lifecycle', 'exit_spread_pct')
    op.drop_column('token_lifecycle', 'entry_spread_pct')
    op.drop_column('token_lifecycle', 'exit_slippage_pct')
    op.drop_column('token_lifecycle', 'entry_slippage_pct')
    op.drop_column('token_lifecycle', 'fill_pct')
    op.drop_column('token_lifecycle', 'filled_size_usd')
    op.drop_column('token_lifecycle', 'requested_size_usd')
