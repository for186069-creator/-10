"""live trading dashboard

Revision ID: 0016_live_trading_dashboard
Revises: 0015_handoff8_execution_microstructure_live_ready
Create Date: 2026-05-14 00:00:00.000000
"""

from __future__ import annotations

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '0016_live_trading_dashboard'
down_revision = '0015_handoff8_execution_microstructure_live_ready'
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        'live_positions',
        sa.Column('id', sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column('chain', sa.String(length=24), nullable=False, index=True),
        sa.Column('token_address', sa.String(length=128), nullable=False, index=True),
        sa.Column('symbol', sa.String(length=64), nullable=True),
        sa.Column('wallet_address', sa.String(length=128), nullable=True, index=True),
        sa.Column('strategy', sa.String(length=32), nullable=True, index=True),
        sa.Column('status', sa.String(length=32), nullable=False, server_default=sa.text("'OPEN'"), index=True),
        sa.Column('entry_price', sa.Float(), nullable=True),
        sa.Column('current_price', sa.Float(), nullable=True),
        sa.Column('peak_price', sa.Float(), nullable=True),
        sa.Column('exit_price', sa.Float(), nullable=True),
        sa.Column('entry_size_usd', sa.Float(), nullable=True),
        sa.Column('current_size_usd', sa.Float(), nullable=True),
        sa.Column('realized_pnl_usd', sa.Float(), nullable=True),
        sa.Column('realized_pnl_pct', sa.Float(), nullable=True),
        sa.Column('entry_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('exit_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('last_checked_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('exit_reason', sa.String(length=64), nullable=True),
        sa.Column('tx_signature', sa.String(length=256), nullable=True),
        sa.Column('entry_signature', sa.String(length=256), nullable=True),
        sa.Column('notes', sa.Text(), nullable=True),
        sa.Column('metadata', sa.JSON(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.text('CURRENT_TIMESTAMP')),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.text('CURRENT_TIMESTAMP')),
    )


def downgrade() -> None:
    op.drop_table('live_positions')
