from __future__ import annotations

from typing import Any

from app.core.config import settings
from app.utils.http import HttpClient


class BirdeyeClient:
    def __init__(self) -> None:
        self.http = HttpClient()
        self.base = settings.birdeye_base_url.rstrip('/')

    def _headers(self) -> dict[str, str]:
        headers = {'x-chain': 'solana'}
        if settings.birdeye_api_key:
            headers['X-API-KEY'] = settings.birdeye_api_key
        return headers

    async def new_listings(self, limit: int = 20) -> list[dict[str, Any]]:
        if not settings.enable_birdeye:
            return []
        url = f'{self.base}/defi/v2/tokens/new_listing'
        data = await self.http.get_json(url, headers=self._headers(), params={'limit': limit})
        return data.get('data', {}).get('items', []) if isinstance(data, dict) else []

    async def token_overview(self, address: str) -> dict[str, Any] | None:
        if not settings.enable_birdeye or not address:
            return None
        url = f'{self.base}/defi/token_overview'
        data = await self.http.get_json(url, headers=self._headers(), params={'address': address})
        if not isinstance(data, dict):
            return None
        payload = data.get('data')
        return payload if isinstance(payload, dict) else None
