"""
CoinGecko — Recently Added Tokens

Endpoint: /coins/list/new  (без API ключа, 30 req/min)
Повертає останні ~50 монет доданих на CoinGecko.
Для кожної монети додатково тягнемо /coins/{id} щоб отримати
contract_address, ліквідність, соціалки.
"""
from __future__ import annotations

import logging
from typing import Any

from app.models.token import Chain, TokenCandidate
from app.utils.http import HttpClient
from app.utils.text import normalize_handle, normalize_url

log = logging.getLogger(__name__)

BASE = 'https://api.coingecko.com/api/v3'

_CHAIN_MAP: dict[str, Chain] = {
    'binance-smart-chain': Chain.BSC,
    'base':                Chain.BASE,
    'solana':              Chain.SOLANA,
    'ethereum':            Chain.ETHEREUM,
}

# Один запит /coins/markets з фільтром по платформах — 1 запит замість 50+
_PLATFORM_IDS = 'binance-smart-chain,base,solana,ethereum'


class CoinGeckoClient:
    def __init__(self) -> None:
        self.http = HttpClient()

    async def recently_added(self, limit: int = 100) -> list[TokenCandidate]:
        """
        Використовує /coins/markets?order=id_desc щоб отримати легіт токени
        без масових detail-запитів. Один запит = до 250 монет.
        """
        candidates: list[TokenCandidate] = []

        # Стратегія 1: /coins/markets — отримуємо топ токени з market data
        # Сортуємо по volume_desc щоб бачити активні токени
        for page in [1, 2]:
            try:
                data = await self.http.get_json(
                    f'{BASE}/coins/markets',
                    params={
                        'vs_currency': 'usd',
                        'order': 'volume_desc',
                        'per_page': '100',
                        'page': str(page),
                        'sparkline': 'false',
                        'price_change_percentage': '24h',
                    },
                    headers={'Accept': 'application/json'},
                    timeout=25,
                )
                if not isinstance(data, list):
                    break
                for item in data:
                    c = _parse_market_item(item)
                    if c:
                        candidates.append(c)
                import asyncio
                await asyncio.sleep(2)  # throttle між сторінками
            except Exception as e:
                log.warning('coingecko: /coins/markets page=%s failed: %s', page, e)
                break

        # Стратегія 2: /coins/list/new — нові лістинги (без detail запитів)
        try:
            new_list = await self.http.get_json(
                f'{BASE}/coins/list/new',
                headers={'Accept': 'application/json'},
                timeout=20,
            )
            if isinstance(new_list, list):
                for item in new_list[:20]:
                    # /coins/list/new не має platform info — пропускаємо detail
                    # просто логуємо id для майбутнього збагачення
                    log.debug('coingecko new listing: %s', item.get('id'))
        except Exception as e:
            log.debug('coingecko: /coins/list/new failed: %s', e)

        log.info('coingecko: collected %d candidates', len(candidates))
        return candidates[:limit]

    async def _fetch_coin_detail(self, coin_id: str, summary: dict) -> TokenCandidate | None:
        try:
            detail = await self.http.get_json(
                f'{BASE}/coins/{coin_id}',
                params={
                    'localization': 'false',
                    'tickers': 'false',
                    'market_data': 'true',
                    'community_data': 'false',
                    'developer_data': 'false',
                },
                headers={'Accept': 'application/json'},
                timeout=20,
            )
        except Exception as e:
            log.debug('coingecko: /coins/%s failed: %s', coin_id, e)
            return None

        if not isinstance(detail, dict):
            return None

        # Знаходимо chain + contract
        platforms: dict[str, str] = detail.get('platforms') or {}
        chain, token_address = _best_platform(platforms)
        if not chain or not token_address:
            return None

        market = detail.get('market_data') or {}
        links  = detail.get('links') or {}

        liquidity_usd = _to_float(
            (market.get('total_value_locked') or {}).get('usd')
            or market.get('market_cap', {}).get('usd')
        )
        fdv = _to_float((market.get('fully_diluted_valuation') or {}).get('usd'))

        homepage = next(iter(filter(None, links.get('homepage') or [])), None)
        twitter  = links.get('twitter_screen_name')
        telegram = links.get('telegram_channel_identifier')
        telegram_url = f'https://t.me/{telegram}' if telegram else None

        return TokenCandidate(
            chain=chain,
            token_address=token_address,
            symbol=(detail.get('symbol') or summary.get('symbol') or '').upper(),
            name=detail.get('name') or summary.get('name'),
            liquidity_usd=liquidity_usd,
            fdv_usd=fdv,
            website=normalize_url(homepage),
            x_handle=normalize_handle(twitter),
            telegram_url=normalize_url(telegram_url),
            raw={'coingecko_id': coin_id, 'coingecko': detail, 'source': 'coingecko'},
        )


def _parse_market_item(item: dict) -> TokenCandidate | None:
    """Парсить елемент з /coins/markets."""
    import re
    coin_id = item.get('id', '')
    symbol = (item.get('symbol') or '').upper()
    name = item.get('name') or ''

    # /coins/markets не має platform info — намагаємось вгадати chain по id
    chain = _guess_chain(coin_id, symbol)
    if not chain:
        return None

    # Для адреси контракту — заглушка, буде уточнено через DexScreener
    # Використовуємо coin_id як ідентифікатор поки немає контракту
    token_address = item.get('contract_address') or f'cg:{coin_id}'

    liquidity_usd = _to_float(item.get('total_volume'))
    market_cap = _to_float(item.get('market_cap'))
    fdv = _to_float(item.get('fully_diluted_valuation')) or market_cap

    return TokenCandidate(
        chain=chain,
        token_address=token_address,
        symbol=symbol,
        name=name,
        liquidity_usd=liquidity_usd,
        fdv_usd=fdv,
        raw={'coingecko_id': coin_id, 'coingecko': item, 'source': 'coingecko'},
    )


def _guess_chain(coin_id: str, symbol: str) -> Chain | None:
    """Евристика по coin_id для визначення chain."""
    cid = coin_id.lower()
    if any(x in cid for x in ['solana', '-sol', 'sol-', 'pump', '-solana']):
        return Chain.SOLANA
    if any(x in cid for x in ['bsc', 'bnb', 'binance', '-bsc', 'pancake']):
        return Chain.BSC
    if any(x in cid for x in ['-base', 'base-', 'basechain']):
        return Chain.BASE
    if any(x in cid for x in ['ethereum', '-eth', 'eth-', 'uniswap', 'erc20']):
        return Chain.ETHEREUM
    # Дефолт — BSC
    return Chain.BSC


def _best_platform(platforms: dict[str, str]) -> tuple[Chain | None, str | None]:
    """Вибирає найвищий пріоритет chain з наявних платформ."""
    priority = ['binance-smart-chain', 'base', 'solana', 'ethereum']
    for p in priority:
        addr = platforms.get(p, '').strip()
        if addr:
            chain = _CHAIN_MAP.get(p)
            if chain:
                return chain, addr
    # fallback — будь-яка підтримувана платформа
    for p, addr in platforms.items():
        if addr and p in _CHAIN_MAP:
            return _CHAIN_MAP[p], addr.strip()
    return None, None


def _to_float(v: Any) -> float | None:
    try:
        return float(v) if v is not None else None
    except (TypeError, ValueError):
        return None
