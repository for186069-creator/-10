"""
CoinMarketCap — Recently Added Tokens

Endpoint: /v1/cryptocurrency/listings/latest  (безкоштовний план, 333 req/day)
Сортуємо по date_added DESC щоб отримати нові токени.
API ключ читається з .env: CMC_API_KEY=...

Якщо CMC_API_KEY не встановлено — джерело пропускається (warning в логах).
"""
from __future__ import annotations

import logging
from typing import Any

from app.core.config import settings
from app.models.token import Chain, TokenCandidate
from app.utils.http import HttpClient
from app.utils.text import normalize_handle, normalize_url

log = logging.getLogger(__name__)

BASE = 'https://pro-api.coinmarketcap.com'

_CHAIN_MAP: dict[str, Chain] = {
    'bsc':      Chain.BSC,
    'bnb':      Chain.BSC,
    'base':     Chain.BASE,
    'sol':      Chain.SOLANA,
    'solana':   Chain.SOLANA,
    'eth':      Chain.ETHEREUM,
    'ethereum': Chain.ETHEREUM,
}


class CoinMarketCapClient:
    def __init__(self) -> None:
        self.http  = HttpClient()
        self.key   = getattr(settings, 'cmc_api_key', '') or ''

    async def recently_added(self, limit: int = 50) -> list[TokenCandidate]:
        if not self.key:
            log.warning('coinmarketcap: CMC_API_KEY not set — skipping')
            return []

        try:
            data = await self.http.get_json(
                f'{BASE}/v1/cryptocurrency/listings/latest',
                headers={
                    'X-CMC_PRO_API_KEY': self.key,
                    'Accept': 'application/json',
                },
                params={
                    'start':   '1',
                    'limit':   str(limit),
                    'sort':    'date_added',
                    'sort_dir': 'desc',
                    'cryptocurrency_type': 'tokens',
                    'convert': 'USD',
                },
                timeout=25,
            )
        except Exception as e:
            log.warning('coinmarketcap: listings/latest failed: %s', e)
            return []

        if not isinstance(data, dict) or 'data' not in data:
            return []

        candidates: list[TokenCandidate] = []
        for item in data['data']:
            candidate = _parse_listing(item)
            if candidate:
                candidates.append(candidate)

        log.info('coinmarketcap: collected %d candidates', len(candidates))
        return candidates


def _parse_listing(item: dict) -> TokenCandidate | None:
    platform = item.get('platform') or {}
    platform_slug = (platform.get('slug') or platform.get('symbol') or '').lower()
    token_address = (platform.get('token_address') or '').strip()

    chain = _CHAIN_MAP.get(platform_slug)
    if not chain or not token_address:
        return None

    quote  = (item.get('quote') or {}).get('USD') or {}
    urls   = item.get('urls') or {}

    liquidity_usd = _to_float(quote.get('market_cap')) or _to_float(quote.get('volume_24h'))
    fdv           = _to_float(quote.get('fully_diluted_market_cap'))

    website  = next(iter(urls.get('website') or []), None)
    twitter  = next(iter(urls.get('twitter') or []), None)
    telegram = next(iter(urls.get('chat') or []), None)
    if telegram and 't.me' not in telegram.lower():
        telegram = None

    return TokenCandidate(
        chain=chain,
        token_address=token_address,
        symbol=(item.get('symbol') or '').upper(),
        name=item.get('name'),
        liquidity_usd=liquidity_usd,
        fdv_usd=fdv,
        website=normalize_url(website),
        x_handle=normalize_handle(twitter),
        telegram_url=normalize_url(telegram),
        raw={'cmc_id': item.get('id'), 'cmc': item, 'source': 'coinmarketcap'},
    )


def _to_float(v: Any) -> float | None:
    try:
        return float(v) if v is not None else None
    except (TypeError, ValueError):
        return None
