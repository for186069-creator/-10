from __future__ import annotations

from typing import Any

from app.core.config import settings
from app.utils.cache import GLOBAL_CACHE
from app.utils.http import HttpClient


_DEX_HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/124.0.0.0 Safari/537.36'
    ),
    'Accept': 'application/json, text/plain, */*',
    'Accept-Language': 'en-US,en;q=0.9',
    'Origin': 'https://dexscreener.com',
    'Referer': 'https://dexscreener.com/',
}


class DexScreenerClient:
    def __init__(self) -> None:
        self.http = HttpClient()
        self.base = settings.dexscreener_base_url.rstrip('/')

    async def latest_token_profiles(self) -> list[dict[str, Any]]:
        url = f'{self.base}/token-profiles/latest/v1'
        data = await self.http.get_json(url, headers=_DEX_HEADERS)
        return data if isinstance(data, list) else []

    async def token_pairs(self, chain: str, token_address: str) -> list[dict[str, Any]]:
        cache_key = f'dexscreener:token_pairs:{chain}:{token_address}'
        cached = await GLOBAL_CACHE.get(cache_key)
        if isinstance(cached, list):
            return cached
        pairs: list[dict[str, Any]] = []
        # Спроба 1: новий endpoint /tokens/v1/{chain}/{address}
        try:
            url = f'{self.base}/tokens/v1/{chain}/{token_address}'
            data = await self.http.get_json(url, headers=_DEX_HEADERS)
            if isinstance(data, list):
                pairs = data
        except Exception:
            pass
        # Fallback: legacy endpoint /latest/dex/tokens/{address}
        if not pairs:
            try:
                url2 = f'{self.base}/latest/dex/tokens/{token_address}'
                data2 = await self.http.get_json(url2, headers=_DEX_HEADERS)
                if isinstance(data2, dict):
                    pairs = data2.get('pairs') or []
            except Exception:
                pass
        await GLOBAL_CACHE.set(cache_key, pairs, ttl_seconds=15)
        return pairs

    async def search_pairs(self, query: str) -> list[dict[str, Any]]:
        url = f'{self.base}/latest/dex/search?q={query}'
        data = await self.http.get_json(url, headers=_DEX_HEADERS)
        if isinstance(data, dict):
            return data.get('pairs') or []
        return []

    async def token_pairs_batch(
        self, chain: str, token_addresses: list[str]
    ) -> dict[str, dict[str, Any]]:
        """Batch lookup. При 403 на batch — fallback на single запити."""
        unique = [addr for addr in dict.fromkeys(token_addresses) if addr]
        if not unique:
            return {}
        cache_key = f"dexscreener:token_pairs_batch:{chain}:{','.join(sorted(unique))}"
        cached = await GLOBAL_CACHE.get(cache_key)
        if isinstance(cached, dict):
            return cached

        out: dict[str, dict[str, Any]] = {}

        # Спроба 1: batch endpoint /tokens/v1/{chain}/addr1,addr2,...
        try:
            url = f"{self.base}/tokens/v1/{chain}/{','.join(unique)}"
            data = await self.http.get_json(url, headers=_DEX_HEADERS)
            pairs_list: list[dict[str, Any]] = []
            if isinstance(data, list):
                pairs_list = data
            elif isinstance(data, dict):
                pairs_list = data.get('pairs') or []
            if pairs_list:
                grouped: dict[str, list[dict[str, Any]]] = {}
                for pair in pairs_list:
                    if not isinstance(pair, dict):
                        continue
                    addr = str(
                        (pair.get('baseToken') or {}).get('address') or ''
                    ).lower()
                    if addr:
                        grouped.setdefault(addr, []).append(pair)
                for addr in unique:
                    candidates = grouped.get(addr.lower()) or []
                    if candidates:
                        best = max(
                            candidates,
                            key=lambda p: float(
                                (p.get('liquidity') or {}).get('usd') or 0
                            ),
                        )
                        out[addr] = best
        except Exception:
            pass

        # Fallback: single запит для адрес яких не знайшли
        missing = [addr for addr in unique if addr not in out]
        for addr in missing:
            try:
                url2 = f'{self.base}/latest/dex/tokens/{addr}'
                data2 = await self.http.get_json(url2, headers=_DEX_HEADERS)
                pairs2: list[dict[str, Any]] = []
                if isinstance(data2, dict):
                    pairs2 = data2.get('pairs') or []
                elif isinstance(data2, list):
                    pairs2 = data2
                if pairs2:
                    best2 = max(
                        pairs2,
                        key=lambda p: float(
                            (p.get('liquidity') or {}).get('usd') or 0
                        ),
                    )
                    out[addr] = best2
            except Exception:
                continue

        if out:
            await GLOBAL_CACHE.set(cache_key, out, ttl_seconds=15)
        return out

    async def new_raydium_graduated_pairs(
        self,
        min_liquidity: float = 15_000,
        min_volume_24h: float = 10_000,
        min_txns_24h: int = 100,
        min_age_hours: float = 2.0,
        max_results: int = 80,
    ) -> list[dict[str, Any]]:
        """Знаходить pump.fun токени що graduated на Raydium/PumpSwap."""
        from app.utils.token_classifier import is_valid_solana_pump_suffix
        from datetime import datetime, timezone, timedelta

        merged_pairs: list[dict[str, Any]] = []
        seen_pairs: set[str] = set()
        for query in ('pump', 'pumpswap', 'raydium'):
            for pair in await self.search_pairs(query):
                pair_key = str(pair.get('pairAddress') or '')
                if not pair_key:
                    base = str((pair.get('baseToken') or {}).get('address') or '')
                    dex = str(pair.get('dexId') or '')
                    pair_key = f'{base}:{dex}'
                if pair_key in seen_pairs:
                    continue
                seen_pairs.add(pair_key)
                merged_pairs.append(pair)

        pairs = merged_pairs
        results: list[dict[str, Any]] = []
        now = datetime.now(timezone.utc)
        min_age_cutoff = now - timedelta(hours=min_age_hours)

        for pair in pairs:
            if (pair.get('chainId') or '').lower() != 'solana':
                continue
            dex_id = (pair.get('dexId') or '').lower()
            if 'raydium' not in dex_id and 'pumpswap' not in dex_id:
                continue
            base_addr = (pair.get('baseToken') or {}).get('address') or ''
            if not is_valid_solana_pump_suffix(base_addr):
                continue
            liq = float((pair.get('liquidity') or {}).get('usd') or 0)
            if liq < min_liquidity:
                continue
            vol = float((pair.get('volume') or {}).get('h24') or 0)
            if vol < min_volume_24h:
                continue
            txns = pair.get('txns') or {}
            h24 = txns.get('h24') or {}
            total_txns = int(h24.get('buys') or 0) + int(h24.get('sells') or 0)
            if total_txns < min_txns_24h:
                continue
            pair_created = pair.get('pairCreatedAt')
            if pair_created:
                try:
                    created_dt = datetime.fromtimestamp(pair_created / 1000, tz=timezone.utc)
                    if created_dt > min_age_cutoff:
                        continue
                except Exception:
                    pass
            results.append(pair)
            if len(results) >= max_results:
                break

        return results
