from __future__ import annotations

import time
from typing import Any

from app.core.config import settings
from app.models.token import Chain
from app.utils.cache import GLOBAL_CACHE
from app.utils.http import HttpClient
from app.utils.providers import ProviderRotator
from app.utils.rate_limits import GLOBAL_RATE_BUDGET
from app.observability.spans import async_span

CHAIN_IDS = {
    Chain.ETHEREUM: '1',
    Chain.BASE: '8453',
    Chain.BSC: '56',
}


class EVMExplorerClient:
    def __init__(self) -> None:
        self.http = HttpClient()
        self.base_url = settings.etherscan_base_url.rstrip('/')
        self.api_key = settings.etherscan_api_key
        self._rpc_rotators: dict[Chain, ProviderRotator[str]] = {}
        self._rpc_quotas = settings.evm_provider_quotas
        for chain in CHAIN_IDS:
            urls = settings.rpc_urls_for_chain(chain.value)
            if urls:
                self._rpc_rotators[chain] = ProviderRotator(urls, cooldown_seconds=settings.provider_cooldown_seconds, weights=settings.evm_provider_weights, quotas_per_minute=settings.evm_provider_quotas)

    async def get_contract_creation(self, chain: Chain, address: str) -> dict[str, Any] | None:
        data = await self._api_get(
            chain,
            module='contract',
            action='getcontractcreation',
            contractaddresses=address,
        )
        if isinstance(data, list) and data:
            return data[0]
        return None

    async def get_source_code(self, chain: Chain, address: str) -> dict[str, Any] | None:
        data = await self._api_get(chain, module='contract', action='getsourcecode', address=address)
        if isinstance(data, list) and data:
            return data[0]
        return None

    async def get_balance(self, chain: Chain, address: str) -> int | None:
        data = await self._api_get(chain, module='account', action='balance', address=address, tag='latest')
        if data is None:
            return None
        try:
            return int(data)
        except (TypeError, ValueError):
            return None

    async def get_balances(self, chain: Chain, addresses: list[str]) -> dict[str, int | None]:
        unique = [a for a in dict.fromkeys(addresses) if a]
        if not unique:
            return {}
        if self.api_key:
            data = await self._api_get(
                chain,
                module='account',
                action='balancemulti',
                address=','.join(unique[:20]),
                tag='latest',
            )
            if isinstance(data, list):
                result: dict[str, int | None] = {}
                for row in data:
                    account = str(row.get('account') or '')
                    try:
                        result[account] = int(row.get('balance'))
                    except (TypeError, ValueError):
                        result[account] = None
                return result
        return {addr: await self.get_balance(chain, addr) for addr in unique}

    async def get_normal_transactions(self, chain: Chain, address: str, *, offset: int = 50, sort: str = 'desc') -> list[dict[str, Any]]:
        data = await self._api_get(
            chain,
            module='account',
            action='txlist',
            address=address,
            startblock='0',
            endblock='99999999',
            page='1',
            offset=str(offset),
            sort=sort,
        )
        return data if isinstance(data, list) else []

    async def get_internal_transactions(self, chain: Chain, address: str, *, offset: int = 50, sort: str = 'desc') -> list[dict[str, Any]]:
        data = await self._api_get(
            chain,
            module='account',
            action='txlistinternal',
            address=address,
            startblock='0',
            endblock='99999999',
            page='1',
            offset=str(offset),
            sort=sort,
        )
        return data if isinstance(data, list) else []

    async def get_transaction_receipt_status(self, chain: Chain, txhash: str) -> dict[str, Any] | None:
        data = await self._api_get(chain, module='transaction', action='gettxreceiptstatus', txhash=txhash)
        return data if isinstance(data, dict) else None

    async def get_code(self, chain: Chain, address: str) -> str | None:
        rotator = self._rpc_rotators.get(chain)
        if rotator is None:
            return None
        cache_key = f'evm:getcode:{chain.value}:{address.lower()}'

        async def loader() -> str | None:
            async with async_span('evm.rpc.get_code', chain=chain.value, address=address):
                for rpc_url in await rotator.ordered():
                    quota = int(self._rpc_quotas.get(str(rpc_url), settings.provider_budget_group_quotas.get('evm_rpc', settings.provider_default_quota_per_minute)))
                    budget = await GLOBAL_RATE_BUDGET.consume('evm_rpc', str(rpc_url), quota)
                    if not budget.allowed:
                        continue
                    started = time.perf_counter()
                    try:
                        data = await self.http.post_json(
                            rpc_url,
                            json={'jsonrpc': '2.0', 'id': 1, 'method': 'eth_getCode', 'params': [address, 'latest']},
                        )
                        result = data.get('result') if isinstance(data, dict) else None
                        if isinstance(result, str):
                            await rotator.mark_success(rpc_url, latency_ms=(time.perf_counter() - started) * 1000)
                            return result
                        await rotator.mark_failure(rpc_url)
                    except Exception:
                        await rotator.mark_failure(rpc_url)
                return None

        return await GLOBAL_CACHE.get_or_set(cache_key, loader)

    async def get_codes(self, chain: Chain, addresses: list[str]) -> dict[str, str | None]:
        rotator = self._rpc_rotators.get(chain)
        unique = [a for a in dict.fromkeys(addresses) if a]
        if rotator is None or not unique:
            return {}
        out: dict[str, str | None] = {address: None for address in unique}
        cacheable = {}
        missing = []
        for address in unique:
            key = f'evm:getcode:{chain.value}:{address.lower()}'
            cached = await GLOBAL_CACHE.get(key)
            if cached is not None:
                cacheable[address] = cached
            else:
                missing.append(address)
        out.update(cacheable)
        if not missing:
            return out
        for rpc_url in await rotator.ordered():
            quota = int(self._rpc_quotas.get(str(rpc_url), settings.provider_budget_group_quotas.get('evm_rpc', settings.provider_default_quota_per_minute)))
            budget = await GLOBAL_RATE_BUDGET.consume('evm_rpc', str(rpc_url), quota)
            if not budget.allowed:
                continue
            batch = []
            by_id: dict[int, str] = {}
            for idx, address in enumerate(missing, start=1):
                batch.append({'jsonrpc': '2.0', 'id': idx, 'method': 'eth_getCode', 'params': [address, 'latest']})
                by_id[idx] = address
            started = time.perf_counter()
            try:
                data = await self.http.post_json(rpc_url, json=batch)
                if isinstance(data, list):
                    for row in data:
                        if not isinstance(row, dict):
                            continue
                        address = by_id.get(int(row.get('id') or 0))
                        if address:
                            value = row.get('result') if isinstance(row.get('result'), str) else None
                            out[address] = value
                            if value is not None:
                                await GLOBAL_CACHE.set(f'evm:getcode:{chain.value}:{address.lower()}', value)
                    await rotator.mark_success(rpc_url, latency_ms=(time.perf_counter() - started) * 1000)
                    return out
                await rotator.mark_failure(rpc_url)
            except Exception:
                await rotator.mark_failure(rpc_url)
        return out

    async def provider_health(self, chain: Chain) -> list[dict[str, Any]]:
        rotator = self._rpc_rotators.get(chain)
        return await rotator.snapshot() if rotator else []

    async def _api_get(self, chain: Chain, **params: str) -> Any:
        if not self.api_key:
            return None
        query = {'chainid': CHAIN_IDS[chain], 'apikey': self.api_key, **params}
        key = 'evm:api:' + chain.value + ':' + '|'.join(f'{k}={v}' for k, v in sorted(query.items()))

        async def loader() -> Any:
            quota = settings.provider_budget_group_quotas.get('etherscan', settings.provider_default_quota_per_minute)
            budget = await GLOBAL_RATE_BUDGET.consume('etherscan', self.base_url, quota)
            if not budget.allowed:
                return None
            data = await self.http.get_json(f'{self.base_url}/v2/api', params=query)
            if not isinstance(data, dict):
                return None
            if str(data.get('status')) == '1':
                return data.get('result')
            return None

        return await GLOBAL_CACHE.get_or_set(key, loader)
