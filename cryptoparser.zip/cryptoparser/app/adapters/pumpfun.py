from __future__ import annotations

import re
from typing import Any
from urllib.parse import urljoin

from app.core.config import settings
from app.utils.http import HttpClient
from app.utils.token_classifier import is_valid_solana_pump_suffix


class PumpFunClient:
    """Клієнт для pump.fun — свіжі монети (pump_early) і graduated (pump_graduated).

    Два режими:
    1. discover_new_mints()     — скрейпить pump.fun/live та /new (pump_early)
    2. fetch_graduated_coins()  — pump.fun frontend API, фільтр complete=True
                                  (токени що пройшли bonding curve → Raydium)
    """

    _COIN_URL_RE  = re.compile(r"/coin/([1-9A-HJ-NP-Za-km-z]{32,44})")
    _IMAGE_ALT_RE = re.compile(r"Coin image for ([1-9A-HJ-NP-Za-km-z]{32,44})", re.I)
    _JSON_FIELD_RE = re.compile(
        r'(?:mint|tokenAddress|token_address|address|coinAddress)[\"\'\s:=]+([1-9A-HJ-NP-Za-km-z]{32,44})',
        re.I,
    )
    # pump.fun API також повертає mint у JSON-відповіді
    _JSON_MINT_RE = re.compile(r'"mint"\s*:\s*"([1-9A-HJ-NP-Za-km-z]{32,44})"')
    _OG_TITLE_RE = re.compile(r'<meta[^>]+property=["\']og:title["\'][^>]+content=["\']([^"\']+)["\']', re.I)
    _OG_DESC_RE  = re.compile(r'<meta[^>]+property=["\']og:description["\'][^>]+content=["\']([^"\']+)["\']', re.I)
    _TITLE_RE    = re.compile(r'<title>(.*?)</title>', re.I | re.S)
    _X_LINK_RE   = re.compile(r'href=["\'](https?://(?:www\.)?(?:x\.com|twitter\.com)/[^"\']+)["\']', re.I)
    _WEB_LINK_RE = re.compile(
        r'href=["\'](https?://(?![^"\']*(?:pump\.fun|swap\.pump\.fun|x\.com|twitter\.com|trade\.padre\.gg))[^"\']+)["\']',
        re.I,
    )

    def __init__(self) -> None:
        self.http     = HttpClient()
        self.base     = settings.pumpfun_base_url.rstrip('/')
        self.swap_base = settings.pumpswap_base_url.rstrip('/')
        self.api_base  = 'https://frontend-api.pump.fun'

    # ── Pump Early (нові монети) ────────────────────────────────────────────

    async def discover_new_mints(self, max_items: int | None = None) -> list[dict[str, Any]]:
        """Знаходить свіжі монети з pump.fun/live і /new + frontend API."""
        max_items = max_items or settings.pumpfun_max_candidates_per_cycle
        items: list[dict[str, Any]] = []
        seen: set[str] = set()

        # Спосіб 1: скрейп HTML-сторінок pump.fun
        for path in settings.pumpfun_feed_paths:
            url = self._feed_url(path)
            try:
                html = await self.http.get_text(url, timeout=settings.pumpfun_request_timeout_seconds)
            except Exception:
                continue
            for mint in self._extract_mints(html):
                if mint in seen:
                    continue
                seen.add(mint)
                items.append({
                    'mint': mint,
                    'source': 'pumpfun',
                    'feed_url': url,
                    'coin_url': f'{self.base}/coin/{mint}',
                    'launchpad': 'pump_fun',
                })
                if len(items) >= max_items:
                    return items

        # Спосіб 2: pumpswap
        try:
            html = await self.http.get_text(self.swap_base, timeout=settings.pumpfun_request_timeout_seconds)
        except Exception:
            html = ''
        for mint in self._extract_mints(html):
            if mint in seen:
                continue
            seen.add(mint)
            items.append({
                'mint': mint,
                'source': 'pumpswap',
                'feed_url': self.swap_base,
                'coin_url': f'{self.base}/coin/{mint}',
                'launchpad': 'pump_swap',
            })
            if len(items) >= max_items:
                break

        # Спосіб 3: pump.fun frontend API — нові монети (sortBy=last-reply або created_timestamp)
        if len(items) < max_items:
            try:
                api_items = await self._fetch_api_coins(
                    sort_by='created_timestamp',
                    limit=min(50, max_items - len(items)),
                    complete=False,  # НЕ graduated — тільки нові
                )
                for coin in api_items:
                    mint = str(coin.get('mint') or '')
                    if not mint or mint in seen or not is_valid_solana_pump_suffix(mint):
                        continue
                    seen.add(mint)
                    items.append({
                        'mint': mint,
                        'source': 'pumpfun_api',
                        'feed_url': self.api_base,
                        'coin_url': f'{self.base}/coin/{mint}',
                        'launchpad': 'pump_fun',
                        'title': coin.get('name'),
                        'description': coin.get('description'),
                        'website': coin.get('website'),
                        'x_url': coin.get('twitter'),
                        'telegram': coin.get('telegram'),
                        'image_uri': coin.get('image_uri'),
                        'market_cap_usd': coin.get('usd_market_cap'),
                    })
                    if len(items) >= max_items:
                        break
            except Exception:
                pass

        return items

    # ── Pump Graduated (пройшли bonding curve → Raydium) ──────────────────

    async def fetch_graduated_coins(
        self,
        limit: int = 50,
        min_market_cap_usd: float = 100_000,
    ) -> list[dict[str, Any]]:
        """Повертає токени що пройшли pump.fun bonding curve (complete=True).

        Ознаки graduated:
        - complete = True  (bonding curve заповнена)
        - raydium_pool != None  (є пул на Raydium)
        - usd_market_cap >= min_market_cap_usd

        Повертає нормалізовані dict з полями:
        mint, name, symbol, website, twitter, telegram,
        raydium_pool, market_cap_usd, image_uri
        """
        results: list[dict[str, Any]] = []
        try:
            coins = await self._fetch_api_coins(
                sort_by='market_cap',
                limit=limit,
                complete=True,
            )
        except Exception:
            return []

        for coin in coins:
            mint = str(coin.get('mint') or '')
            if not mint or not is_valid_solana_pump_suffix(mint):
                continue
            if not coin.get('complete'):
                continue
            raydium_pool = coin.get('raydium_pool')
            if not raydium_pool:
                continue
            market_cap = float(coin.get('usd_market_cap') or 0)
            if market_cap < min_market_cap_usd:
                continue
            results.append({
                'mint': mint,
                'source': 'pumpfun_graduated',
                'coin_url': f'{self.base}/coin/{mint}',
                'launchpad': 'pump_fun',
                'complete': True,
                'graduated': True,
                'raydium_pool': raydium_pool,
                'title': coin.get('name'),
                'name': coin.get('name'),
                'symbol': coin.get('symbol'),
                'description': coin.get('description'),
                'website': coin.get('website') or '',
                'x_url': coin.get('twitter') or '',
                'telegram': coin.get('telegram') or '',
                'image_uri': coin.get('image_uri'),
                'market_cap_usd': market_cap,
                'virtual_sol_reserves': coin.get('virtual_sol_reserves'),
                'creator': coin.get('creator'),
            })

        return results

    # ── Внутрішні методи ───────────────────────────────────────────────────

    async def _fetch_api_coins(
        self,
        sort_by: str = 'market_cap',
        limit: int = 50,
        complete: bool | None = None,
        offset: int = 0,
    ) -> list[dict[str, Any]]:
        """Запит до pump.fun frontend API."""
        params = f'sortBy={sort_by}&includeNsfw=false&limit={limit}&offset={offset}'
        if complete is not None:
            params += f'&complete={str(complete).lower()}'
        url = f'{self.api_base}/coins?{params}'
        try:
            data = await self.http.get_json(url, timeout=settings.pumpfun_request_timeout_seconds)
            if isinstance(data, list):
                return data
            if isinstance(data, dict):
                return data.get('coins') or data.get('data') or []
        except Exception:
            pass
        return []

    def _feed_url(self, path: str) -> str:
        if path.startswith('http://') or path.startswith('https://'):
            return path
        return urljoin(self.base + '/', path.lstrip('/'))

    def _extract_mints(self, html: str) -> list[str]:
        found: list[str] = []
        seen: set[str] = set()
        html = html or ''
        for pattern in (self._COIN_URL_RE, self._IMAGE_ALT_RE, self._JSON_FIELD_RE, self._JSON_MINT_RE):
            for mint in pattern.findall(html):
                if not is_valid_solana_pump_suffix(mint):
                    continue
                if mint in seen:
                    continue
                seen.add(mint)
                found.append(mint)
        return found

    def _extract_title(self, html: str) -> str | None:
        for pattern in (self._OG_TITLE_RE, self._TITLE_RE):
            m = pattern.search(html or '')
            if m:
                text = ' '.join((m.group(1) or '').split())
                return text[:180] if text else None
        return None

    def _extract_description(self, html: str) -> str | None:
        m = self._OG_DESC_RE.search(html or '')
        if not m:
            return None
        text = ' '.join((m.group(1) or '').split())
        return text[:300] if text else None

    def _extract_x_url(self, html: str) -> str | None:
        m = self._X_LINK_RE.search(html or '')
        return m.group(1) if m else None

    def _extract_website_url(self, html: str) -> str | None:
        m = self._WEB_LINK_RE.search(html or '')
        return m.group(1) if m else None

    async def fetch_coin_metadata(self, mint: str) -> dict[str, Any]:
        """Мета-дані конкретної монети — спочатку API, потім HTML fallback."""
        # Спроба 1: frontend API
        try:
            url = f'{self.api_base}/coins/{mint}'
            data = await self.http.get_json(url, timeout=settings.pumpfun_request_timeout_seconds)
            if isinstance(data, dict) and data.get('mint'):
                return {
                    'coin_url': f'{self.base}/coin/{mint}',
                    'title': data.get('name'),
                    'description': data.get('description'),
                    'x_url': data.get('twitter'),
                    'website': data.get('website'),
                    'telegram': data.get('telegram'),
                    'image_uri': data.get('image_uri'),
                    'market_cap_usd': data.get('usd_market_cap'),
                    'raydium_pool': data.get('raydium_pool'),
                    'complete': data.get('complete'),
                }
        except Exception:
            pass
        # Fallback: HTML
        url = f'{self.base}/coin/{mint}'
        try:
            html = await self.http.get_text(url, timeout=settings.pumpfun_request_timeout_seconds)
        except Exception:
            return {'coin_url': url}
        return {
            'coin_url': url,
            'title': self._extract_title(html),
            'description': self._extract_description(html),
            'x_url': self._extract_x_url(html),
            'website': self._extract_website_url(html),
        }
