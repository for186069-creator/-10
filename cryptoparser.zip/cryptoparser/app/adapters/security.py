from __future__ import annotations

from typing import Any

from app.core.config import settings
from app.models.token import Chain, SecurityReport, TokenCandidate
from app.utils.http import HttpClient


class SecurityService:
    def __init__(self) -> None:
        self.http = HttpClient()

    async def analyze(self, candidate: TokenCandidate) -> SecurityReport:
        report = SecurityReport(contract_verified=candidate.contract_verified)
        if candidate.chain in {Chain.ETHEREUM, Chain.BASE, Chain.BSC}:
            if settings.enable_goplus:
                await self._apply_goplus_evm(candidate, report)
            if settings.enable_honeypot:
                await self._apply_honeypot(candidate, report)
        else:
            if settings.enable_goplus:
                await self._apply_goplus_solana(candidate, report)
        report.data_complete = bool(report.sources)
        if not report.sources:
            report.reasons.append('missing_security_sources')
        return report

    async def _apply_goplus_evm(self, candidate: TokenCandidate, report: SecurityReport) -> None:
        chain_map = {Chain.ETHEREUM: '1', Chain.BSC: '56', Chain.BASE: '8453'}
        chain_id = chain_map[candidate.chain]
        url = f"{settings.goplus_base_url.rstrip('/')}/api/v1/token_security/{chain_id}"
        headers = {'Authorization': f'Bearer {settings.goplus_access_token}'} if settings.goplus_access_token else None
        try:
            data = await self.http.get_json(url, headers=headers, params={'contract_addresses': candidate.token_address})
            result = data.get('result') or {}
            token = result.get(candidate.token_address.lower()) or result.get(candidate.token_address) or {}
            report.sources.append('goplus_evm')
            report.raw['goplus_evm'] = token
            report.contract_verified = _truthy(token.get('is_open_source'), report.contract_verified)
            owner = token.get('owner_address')
            report.renounced = owner in {'0x0000000000000000000000000000000000000000', '', None}
            report.proxy = _truthy(token.get('is_proxy'))
            report.mint_enabled = _truthy(token.get('is_mintable'))
            report.blacklist_function = _truthy(token.get('is_blacklisted'))
            report.pause_function = _truthy(token.get('is_pause'))
            report.owner_can_change_fee = _truthy(token.get('owner_change_balance'))
            report.owner_can_block_wallets = _truthy(token.get('can_take_back_ownership'))
            report.top10_holder_pct = _parse_top10(token)
        except Exception as exc:
            report.reasons.append(f'goplus_evm_error:{type(exc).__name__}')

    async def _apply_honeypot(self, candidate: TokenCandidate, report: SecurityReport) -> None:
        chain_map = {Chain.ETHEREUM: 1, Chain.BSC: 56, Chain.BASE: 8453}
        url = f"{settings.honeypot_base_url.rstrip('/')}/v2/IsHoneypot"
        try:
            params = {'address': candidate.token_address, 'chainID': chain_map[candidate.chain]}
            if candidate.pair_address:
                params['pair'] = candidate.pair_address
            data = await self.http.get_json(url, params=params)
            summary = data.get('summary', {}) if isinstance(data, dict) else {}
            sim = data.get('simulationResult', {}) if isinstance(data, dict) else {}
            report.sources.append('honeypot')
            report.raw['honeypot'] = data
            hp = summary.get('honeypotResult')
            if hp is not None:
                report.honeypot = bool(hp)
            report.can_sell = sim.get('maxSell') is not None or report.can_sell
            report.lp_locked_days = report.lp_locked_days or _estimate_lp_lock_days(data)
            if candidate.taxes_buy_pct is None and sim.get('buyTax') is not None:
                candidate.taxes_buy_pct = float(sim.get('buyTax') or 0)
            if candidate.taxes_sell_pct is None and sim.get('sellTax') is not None:
                candidate.taxes_sell_pct = float(sim.get('sellTax') or 0)
        except Exception as exc:
            report.reasons.append(f'honeypot_error:{type(exc).__name__}')

    async def _apply_goplus_solana(self, candidate: TokenCandidate, report: SecurityReport) -> None:
        url = f"{settings.goplus_base_url.rstrip('/')}/api/v1/solana/token_security"
        headers = {'Authorization': f'Bearer {settings.goplus_access_token}'} if settings.goplus_access_token else None
        try:
            data = await self.http.get_json(url, headers=headers, params={'contract_addresses': candidate.token_address})
            result = data.get('result') or {}
            token = result.get(candidate.token_address) or {}
            report.sources.append('goplus_solana')
            report.raw['goplus_solana'] = token
            report.mint_authority_none = not bool(token.get('mint_authority'))
            report.freeze_authority_none = not bool(token.get('freeze_authority'))
            report.creator_wallet_malicious = _truthy(token.get('is_malicious_address'))
            report.top10_holder_pct = _parse_float(token.get('holder_distribution_top10'))
            report.contract_verified = True
            # FIX BUG 1: extract transfer_tax from GoPlus Solana response
            _apply_solana_tax(candidate, token)
        except Exception as exc:
            report.reasons.append(f'goplus_solana_error:{type(exc).__name__}')


def _apply_solana_tax(candidate: TokenCandidate, token: dict) -> None:
    """Extract buy/sell tax from GoPlus Solana response.

    GoPlus returns transfer_tax in three formats:
      1. {'buy_tax': '0.5', 'sell_tax': '0.5'}  — dict with separate keys (SPL Token-2022)
      2. '0.5'                                    — single string (symmetric tax)
      3. absent / None                            — no fee extension (old SPL, treat as 0)
    """
    transfer_tax = token.get('transfer_tax')
    buy_tax: float | None = None
    sell_tax: float | None = None

    if isinstance(transfer_tax, dict):
        buy_tax = _parse_float(transfer_tax.get('buy_tax'))
        sell_tax = _parse_float(transfer_tax.get('sell_tax'))
    elif transfer_tax is not None:
        parsed = _parse_float(transfer_tax)
        buy_tax = parsed
        sell_tax = parsed

    # Old SPL tokens have no fee-on-transfer mechanism → treat as 0.0
    if candidate.taxes_buy_pct is None:
        candidate.taxes_buy_pct = buy_tax if buy_tax is not None else 0.0
    if candidate.taxes_sell_pct is None:
        candidate.taxes_sell_pct = sell_tax if sell_tax is not None else 0.0



def _truthy(value: Any, default: bool = False) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    if isinstance(value, str):
        lowered = value.lower().strip()
        if lowered in {'1', 'true', 'yes'}:
            return True
        if lowered in {'0', 'false', 'no', ''}:
            return False
    return default


def _parse_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _parse_top10(token: dict[str, Any]) -> float | None:
    holders = token.get('holders')
    if isinstance(holders, list):
        total = 0.0
        for item in holders[:10]:
            pct = _parse_float(item.get('percent'))
            if pct is not None:
                total += pct
        return round(total, 4) if total else None
    holder_map = token.get('holder_distribution')
    if isinstance(holder_map, dict):
        total = 0.0
        for pct in list(holder_map.values())[:10]:
            parsed = _parse_float(pct)
            if parsed is not None:
                total += parsed
        return round(total, 4) if total else None
    return None


def _estimate_lp_lock_days(data: dict[str, Any]) -> int | None:
    pair = data.get('pair', {}) if isinstance(data, dict) else {}
    lock_days = pair.get('liquidityLockDays') or pair.get('lockDays')
    try:
        return int(lock_days) if lock_days is not None else None
    except (TypeError, ValueError):
        return None
