from __future__ import annotations

import time
from typing import Any

from app.core.config import settings
from app.utils.cache import GLOBAL_CACHE
from app.utils.http import HttpClient
from app.utils.providers import ProviderRotator
from app.utils.rate_limits import GLOBAL_RATE_BUDGET
from app.observability.spans import async_span


class SolanaRpcClient:
    def __init__(self) -> None:
        self.http = HttpClient()
        urls = settings.rpc_urls_for_chain('solana')
        self.rotator = ProviderRotator(urls, cooldown_seconds=settings.provider_cooldown_seconds, weights=settings.solana_provider_weights, quotas_per_minute=settings.solana_provider_quotas) if urls else None
        self._quotas = settings.solana_provider_quotas

    async def get_account_info(self, address: str) -> dict[str, Any] | None:
        data = await self._call('getAccountInfo', [address, {'encoding': 'base64', 'commitment': 'confirmed'}])
        value = data.get('value') if isinstance(data, dict) else None
        return value if isinstance(value, dict) else None

    async def get_token_supply(self, mint: str) -> dict[str, Any] | None:
        data = await self._call('getTokenSupply', [mint, {'commitment': 'confirmed'}])
        value = data.get('value') if isinstance(data, dict) else None
        return value if isinstance(value, dict) else None

    async def get_token_largest_accounts(self, mint: str) -> list[dict[str, Any]]:
        data = await self._call('getTokenLargestAccounts', [mint, {'commitment': 'confirmed'}])
        value = data.get('value') if isinstance(data, dict) else None
        return value if isinstance(value, list) else []

    async def get_signatures_for_address(self, address: str, *, limit: int = 50) -> list[dict[str, Any]]:
        result = await self._call('getSignaturesForAddress', [address, {'limit': limit, 'commitment': 'confirmed'}])
        return result if isinstance(result, list) else []

    async def get_balance(self, address: str) -> int | None:
        data = await self._call('getBalance', [address, {'commitment': 'confirmed'}])
        value = data.get('value') if isinstance(data, dict) else None
        return int(value) if isinstance(value, int) else None

    async def get_transaction(self, signature: str) -> dict[str, Any] | None:
        data = await self._call('getTransaction', [signature, {'encoding': 'jsonParsed', 'maxSupportedTransactionVersion': 0}])
        return data if isinstance(data, dict) else None

    async def get_transactions(self, signatures: list[str]) -> list[dict[str, Any]]:
        if not signatures:
            return []
        cached, missing = [], []
        for sig in signatures:
            key = f'solana:getTransaction:{sig}'
            value = await GLOBAL_CACHE.get(key)
            if value is not None:
                cached.append(value)
            else:
                missing.append(sig)
        results = list(cached)
        if not missing:
            return results
        if self.rotator is None:
            return results
        payload = [
            {'jsonrpc': '2.0', 'id': idx, 'method': 'getTransaction', 'params': [sig, {'encoding': 'jsonParsed', 'maxSupportedTransactionVersion': 0}]}
            for idx, sig in enumerate(missing, start=1)
        ]
        sig_by_id = {idx: sig for idx, sig in enumerate(missing, start=1)}
        for rpc_url in await self.rotator.ordered():
            quota = int(self._quotas.get(str(rpc_url), settings.provider_budget_group_quotas.get('solana_rpc', settings.provider_default_quota_per_minute)))
            budget = await GLOBAL_RATE_BUDGET.consume('solana_rpc', str(rpc_url), quota)
            if not budget.allowed:
                continue
            started = time.perf_counter()
            try:
                data = await self.http.post_json(rpc_url, json=payload)
                if isinstance(data, list):
                    for row in data:
                        if not isinstance(row, dict):
                            continue
                        sig = sig_by_id.get(int(row.get('id') or 0))
                        value = row.get('result') if sig else None
                        if sig and isinstance(value, dict):
                            await GLOBAL_CACHE.set(f'solana:getTransaction:{sig}', value)
                            results.append(value)
                    await self.rotator.mark_success(rpc_url, latency_ms=(time.perf_counter() - started) * 1000)
                    return results
                await self.rotator.mark_failure(rpc_url)
            except Exception:
                await self.rotator.mark_failure(rpc_url)
        return results

    async def decode_mint_authorities(self, mint: str) -> dict[str, bool | None]:
        info = await self.get_account_info(mint)
        if not info:
            return {'mint_authority_none': None, 'freeze_authority_none': None}
        data = info.get('data')
        if not isinstance(data, list) or not data or not isinstance(data[0], str):
            return {'mint_authority_none': None, 'freeze_authority_none': None}
        import base64, struct
        raw = base64.b64decode(data[0])
        if len(raw) < 82:
            return {'mint_authority_none': None, 'freeze_authority_none': None}
        mint_option = struct.unpack_from('<I', raw, 0)[0]
        freeze_option = struct.unpack_from('<I', raw, 46)[0]
        return {'mint_authority_none': mint_option == 0, 'freeze_authority_none': freeze_option == 0}

    async def provider_health(self) -> list[dict[str, Any]]:
        return await self.rotator.snapshot() if self.rotator else []

    async def _call(self, method: str, params: list[Any]) -> Any:
        if self.rotator is None:
            return None
        cache_key = f'solana:{method}:{repr(params)}'

        async def loader() -> Any:
            async with async_span('solana.rpc.call', method=method):
                for rpc_url in await self.rotator.ordered():
                    quota = int(self._quotas.get(str(rpc_url), settings.provider_budget_group_quotas.get('solana_rpc', settings.provider_default_quota_per_minute)))
                    budget = await GLOBAL_RATE_BUDGET.consume('solana_rpc', str(rpc_url), quota)
                    if not budget.allowed:
                        continue
                    started = time.perf_counter()
                    try:
                        data = await self.http.post_json(rpc_url, json={'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params})
                        if isinstance(data, dict) and 'result' in data:
                            await self.rotator.mark_success(rpc_url, latency_ms=(time.perf_counter() - started) * 1000)
                            return data['result']
                        await self.rotator.mark_failure(rpc_url)
                    except Exception:
                        await self.rotator.mark_failure(rpc_url)
                return None

        return await GLOBAL_CACHE.get_or_set(cache_key, loader)



def decode_mint_account(account_info: dict[str, Any] | None) -> dict[str, Any]:
    if not account_info:
        return {}
    value = account_info.get('data')
    if not isinstance(value, list) or len(value) < 1:
        return {}
    try:
        raw = base64.b64decode(value[0])
    except Exception:
        return {}
    if len(raw) < 82:
        return {}

    mint_auth_option = struct.unpack_from('<I', raw, 0)[0]
    mint_authority = raw[4:36].hex() if mint_auth_option else None
    supply = struct.unpack_from('<Q', raw, 36)[0]
    decimals = raw[44]
    is_initialized = bool(raw[45])
    freeze_auth_option = struct.unpack_from('<I', raw, 46)[0]
    freeze_authority = raw[50:82].hex() if freeze_auth_option else None
    return {
        'mint_authority_present': bool(mint_auth_option),
        'freeze_authority_present': bool(freeze_auth_option),
        'mint_authority': mint_authority,
        'freeze_authority': freeze_authority,
        'raw_supply': supply,
        'decimals': decimals,
        'is_initialized': is_initialized,
    }
