from __future__ import annotations

import json
import os
import logging
import math
from datetime import datetime, timedelta, timezone
from html import escape

from pathlib import Path

from fastapi import Request,  Depends, FastAPI, Header, HTTPException
from fastapi.responses import HTMLResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy import func, select

from app.core.config import settings
from app.db.base import AsyncSessionLocal
from app.db.models import (
    AnalystLabelRecord,
    BlacklistRecord,
    HistoricalTokenRecord,
    ManualReviewRecord,
    RealtimeAlertRecord,
    ReputationRecord,
    TokenCandidateRecord,
    TokenDecisionRecord,
    WalletClusterRecord,
)
from app.db.repositories import AnalystLabelRepository, GraphRepository, HistoricalRepository, ManualReviewRepository, RealtimeAlertRepository, ReputationRepository, GraphScoreRunRepository, SchedulerRepository
from app.services.analyst_workflow import AnalystWorkflowService
from app.services.gem_predictor import GemPredictor as _GemPredictor
from app.models.token import TokenCandidate as _TokenCandidate, Chain as _Chain
from app.utils.graduated_quality import (
    extract_graduated_metrics,
    has_quality_social,
    is_valid_telegram_url,
    passes_market_gate,
    passes_quality_gate,
)
from app.utils.token_classifier import classify_decision_profile, classify_token_family
_gem_predictor = _GemPredictor()
from app.observability.metrics import METRICS
from app.observability.tracing import instrument_fastapi
try:
    import redis.asyncio as redis
except Exception:
    redis = None

app = FastAPI(title='cryptoparser-admin')
instrument_fastapi(app)


def _pump_graduated_rank(item: dict) -> float:
    candidate_raw = item.get('candidate_raw') or {}
    metrics = extract_graduated_metrics(candidate_raw, liquidity_fallback=float(item.get('liquidity_usd') or 0.0))
    prefilter = candidate_raw.get('graduated_prefilter') or {}
    pair = candidate_raw.get('pair') or {}
    score = float(item.get('score') or 0.0)
    liquidity = float(metrics['liquidity_usd'] or 0.0)
    holders = float(item.get('holders') or 0.0)
    volume_24h = float(metrics['volume_24h'] or 0.0)
    txns_24h = float(metrics['txns_24h'] or 0.0)
    has_website = bool(item.get('website'))
    if settings.pump_graduated_quality_require_valid_social:
        has_telegram = is_valid_telegram_url(item.get('telegram_url'))
    else:
        has_telegram = bool(item.get('telegram_url'))
    has_social = has_quality_social(
        item.get('x_handle'),
        item.get('telegram_url'),
        require_valid_social=settings.pump_graduated_quality_require_valid_social,
    )
    status = str(item.get('status') or '')
    dex_id = str((pair.get('dexId') or prefilter.get('dex_id') or '')).lower()
    has_known_venue = ('raydium' in dex_id) or ('pumpswap' in dex_id)

    status_bonus = 8.0 if status == 'APPROVE' else 5.0 if status == 'REVIEW_LATER' else 0.0
    venue_bonus = 4.0 if has_known_venue else 0.0
    score_component = min(score * 0.58, 58.0)
    liquidity_component = min((math.log1p(liquidity) / math.log1p(1_000_000.0)) * 18.0, 18.0)
    volume_component = min((math.log1p(volume_24h) / math.log1p(5_000_000.0)) * 14.0, 14.0)
    txns_component = min((math.log1p(txns_24h) / math.log1p(50_000.0)) * 9.0, 9.0)
    holders_component = min((math.log1p(holders) / math.log1p(10_000.0)) * 7.0, 7.0)

    website_bonus = 7.0 if has_website else -8.0
    social_bonus = 7.0 if has_social else -8.0
    telegram_bonus = 2.0 if has_telegram else 0.0
    strong_profile_bonus = 6.0 if has_website and has_social else 0.0

    return round(
        score_component
        + liquidity_component
        + volume_component
        + txns_component
        + holders_component
        + website_bonus
        + social_bonus
        + telegram_bonus
        + strong_profile_bonus
        + venue_bonus
        + status_bonus,
        2,
    )

# Read token directly from .env file with manual parser (handles BOM/encoding issues)
def _read_env_file(path: Path) -> dict:
    result = {}
    try:
        for enc in ('utf-8-sig', 'utf-8', 'utf-16', 'latin-1'):
            try:
                text = path.read_text(encoding=enc)
                for line in text.splitlines():
                    line = line.strip()
                    if line and not line.startswith('#') and '=' in line:
                        k, _, v = line.partition('=')
                        result[k.strip()] = v.strip().strip('"').strip("'")
                break
            except Exception:
                continue
    except Exception as e:
        logging.warning(f'[admin] failed to read env file: {e}')
    return result

_env_file = Path(__file__).resolve().parent.parent.parent / '.env'
_env_vars = _read_env_file(_env_file)
_ADMIN_TOKEN = (
    _env_vars.get('ADMIN_API_TOKEN')
    or os.getenv('ADMIN_API_TOKEN')
    or str(settings.admin_api_token)
).strip()
_token_masked = f'***{_ADMIN_TOKEN[-4:]}' if _ADMIN_TOKEN else '(empty)'
logging.warning('[admin] token loaded: %s (len=%s, env_file=%s)', _token_masked, len(_ADMIN_TOKEN), _env_file)

FEATURE_FLAGS = {'birdeye_solana_enabled': bool(settings.enable_birdeye)}
static_dir = Path(__file__).with_name('static')
if static_dir.exists():
    app.mount('/static', StaticFiles(directory=str(static_dir)), name='static')


async def admin_auth(
    request: Request,
    x_admin_token: str = Header(default=''),
) -> None:
    # Приймаємо токен з трьох місць: заголовок, query param, Authorization Bearer
    token_candidates = [
        x_admin_token.strip(),
        (request.query_params.get('token') or '').strip(),
        (request.headers.get('Authorization') or '').removeprefix('Bearer ').strip(),
    ]
    if _ADMIN_TOKEN not in token_candidates:
        raise HTTPException(status_code=401, detail='invalid admin token')




@app.get('/analyst')
async def analyst_console() -> HTMLResponse:
    if not settings.frontend_enabled:
        raise HTTPException(status_code=404, detail='disabled')
    return HTMLResponse((static_dir / 'index.html').read_text(encoding='utf-8'))
@app.get('/health')
async def health() -> dict[str, str]:
    return {'status': 'ok'}


@app.get('/ready')
async def ready() -> dict[str, str]:
    return {'status': 'ready'}


@app.get('/metrics', dependencies=[Depends(admin_auth)])
async def metrics() -> PlainTextResponse:
    return PlainTextResponse(await METRICS.render_prometheus(), media_type='text/plain; version=0.0.4')




@app.get('/metrics-public')
async def metrics_public() -> PlainTextResponse:
    if not settings.enable_public_metrics:
        raise HTTPException(status_code=404, detail='disabled')
    return PlainTextResponse(await METRICS.render_prometheus(), media_type='text/plain; version=0.0.4')


@app.get('/workers', dependencies=[Depends(admin_auth)])
async def workers() -> dict:
    if redis is None or not settings.use_redis_cache:
        return {'workers': {}}
    try:
        client = redis.from_url(settings.redis_url, decode_responses=True)
        data = {}
        for role in ('worker', 'poller', 'graph-jobs', 'scheduler'):
            data[role] = await client.hkeys(f'cryptoparser:workers:{role}')
        return {'workers': data}
    except Exception:
        return {'workers': {}}


@app.get('/graph/runs', dependencies=[Depends(admin_auth)])
async def graph_runs() -> list[dict]:
    async with AsyncSessionLocal() as session:
        repo = GraphScoreRunRepository(session)
        rows = await repo.latest()
        return [{'chain': r.chain, 'status': r.status, 'nodes_scored': r.nodes_scored, 'clusters_scored': r.clusters_scored, 'summary': r.summary, 'created_at': r.created_at.isoformat()} for r in rows]


def _pct(sorted_values: list[float], percentile: float) -> float | None:
    if not sorted_values:
        return None
    if len(sorted_values) == 1:
        return float(sorted_values[0])
    k = (len(sorted_values) - 1) * percentile
    f = int(math.floor(k))
    c = int(math.ceil(k))
    if f == c:
        return float(sorted_values[f])
    return float(sorted_values[f] + (sorted_values[c] - sorted_values[f]) * (k - f))


def _pair_created_ms_from_raw(raw: dict) -> float | None:
    pre = raw.get('graduated_prefilter') or {}
    pair_data = raw.get('pair') or {}
    pair_created_at = (
        pre.get('pair_created_at')
        or pre.get('pairCreatedAt')
        or pair_data.get('pairCreatedAt')
        or raw.get('pair_created_at')
        or raw.get('pairCreatedAt')
    )
    if pair_created_at is None:
        return None
    try:
        pair_ms = float(pair_created_at)
        if pair_ms < 10_000_000_000:
            pair_ms *= 1000.0
        return pair_ms
    except Exception:
        return None


def _pair_created_iso_from_raw(raw: dict) -> str | None:
    pair_ms = _pair_created_ms_from_raw(raw)
    if pair_ms is None:
        return None
    try:
        return datetime.fromtimestamp(pair_ms / 1000.0, tz=timezone.utc).isoformat()
    except Exception:
        return None


def _latency_seconds_from_candidate(candidate: TokenCandidateRecord) -> float | None:
    raw = candidate.raw or {}
    pair_ms = _pair_created_ms_from_raw(raw)
    if pair_ms is None or candidate.first_seen_at is None:
        return None
    try:
        pair_dt = datetime.fromtimestamp(pair_ms / 1000.0, tz=timezone.utc)
        first_seen = candidate.first_seen_at
        if first_seen.tzinfo is None:
            first_seen = first_seen.replace(tzinfo=timezone.utc)
        else:
            first_seen = first_seen.astimezone(timezone.utc)
        latency = (first_seen - pair_dt).total_seconds()
        if latency < 0:
            return None
        return float(latency)
    except Exception:
        return None


@app.get('/early-catch/health', dependencies=[Depends(admin_auth)])
async def early_catch_health(window_hours: int = 24) -> dict:
    hours = max(1, min(int(window_hours), 168))
    window_start = datetime.now(timezone.utc) - timedelta(hours=hours)

    async with AsyncSessionLocal() as session:
        candidates_q = (
            select(TokenCandidateRecord)
            .where(
                TokenCandidateRecord.chain == 'solana',
                TokenCandidateRecord.first_seen_at >= window_start,
                (TokenCandidateRecord.graduated_confirmed.is_(True)) | (TokenCandidateRecord.lifecycle_stage == 'graduated'),
            )
            .order_by(TokenCandidateRecord.first_seen_at.desc())
            .limit(5000)
        )
        candidates = list((await session.execute(candidates_q)).scalars().all())

        alerts_q = (
            select(RealtimeAlertRecord)
            .where(
                RealtimeAlertRecord.chain == 'solana',
                RealtimeAlertRecord.event_type == 'strong_graduated_candidate',
                RealtimeAlertRecord.created_at >= window_start,
            )
            .order_by(RealtimeAlertRecord.created_at.desc())
            .limit(10000)
        )
        alerts = list((await session.execute(alerts_q)).scalars().all())

    strong_alert_tokens = {str(r.token_address or '').lower() for r in alerts if r.token_address}

    source_stats: dict[str, dict] = {}
    latency_all: list[float] = []
    for c in candidates:
        raw = c.raw or {}
        source = str(raw.get('graduated_via') or raw.get('discovery_source') or 'unknown')
        token_address = str(c.token_address or '').lower()
        stat = source_stats.setdefault(
            source,
            {
                'source': source,
                'candidates': 0,
                'strong_alert_tokens': 0,
                'latencies': [],
            },
        )
        stat['candidates'] += 1
        if token_address in strong_alert_tokens:
            stat['strong_alert_tokens'] += 1
        latency = _latency_seconds_from_candidate(c)
        if latency is not None:
            stat['latencies'].append(latency)
            latency_all.append(latency)

    latency_all.sort()
    overall_candidates = len(candidates)
    overall_hit_tokens = len({str(c.token_address or '').lower() for c in candidates if str(c.token_address or '').lower() in strong_alert_tokens})
    overall_hit_rate = round((overall_hit_tokens / overall_candidates) * 100.0, 2) if overall_candidates else 0.0

    sources: list[dict] = []
    for stat in source_stats.values():
        lat_sorted = sorted(stat['latencies'])
        candidates_count = int(stat['candidates'])
        hits = int(stat['strong_alert_tokens'])
        hit_rate = round((hits / candidates_count) * 100.0, 2) if candidates_count else 0.0
        sources.append(
            {
                'source': stat['source'],
                'candidates': candidates_count,
                'strong_alert_tokens': hits,
                'hit_rate_pct': hit_rate,
                'median_latency_seconds': round(_pct(lat_sorted, 0.5), 2) if lat_sorted else None,
                'p90_latency_seconds': round(_pct(lat_sorted, 0.9), 2) if lat_sorted else None,
            }
        )
    sources.sort(key=lambda x: x['candidates'], reverse=True)

    return {
        'generated_at': datetime.now(timezone.utc).isoformat(),
        'window_hours': hours,
        'totals': {
            'graduated_candidates': overall_candidates,
            'strong_alert_events': len(alerts),
            'strong_alert_tokens': overall_hit_tokens,
            'hit_rate_pct': overall_hit_rate,
        },
        'latency_seconds': {
            'count': len(latency_all),
            'avg': round((sum(latency_all) / len(latency_all)), 2) if latency_all else None,
            'median': round(_pct(latency_all, 0.5), 2) if latency_all else None,
            'p90': round(_pct(latency_all, 0.9), 2) if latency_all else None,
            'min': round(latency_all[0], 2) if latency_all else None,
            'max': round(latency_all[-1], 2) if latency_all else None,
        },
        'sources': sources,
    }

@app.get('/reviews', dependencies=[Depends(admin_auth)])
async def list_reviews() -> list[dict]:
    async with AsyncSessionLocal() as session:
        repo = ManualReviewRepository(session)
        rows = await repo.list_open()
        # token_address повний — фронтенд може обрізати для відображення але копіювати повний
        return [{'id': row.id, 'chain': row.chain, 'token_address': row.token_address, 'notes': row.notes, 'status': row.status} for row in rows]


@app.post('/reviews/{review_id}/{status}', dependencies=[Depends(admin_auth)])
async def update_review(review_id: int, status: str, assigned_to: str | None = None, notes: str | None = None) -> dict[str, str]:
    async with AsyncSessionLocal() as session:
        repo = ManualReviewRepository(session)
        await repo.update_status(review_id, status=status.upper(), assigned_to=assigned_to, notes=notes)

        if status.upper() in ('APPROVE', 'APPROVED'):
            try:
                from app.db.models import ManualReviewRecord, TokenCandidateRecord, TokenDecisionRecord
                q = select(ManualReviewRecord).where(ManualReviewRecord.id == review_id)
                review = (await session.execute(q)).scalar_one_or_none()
                if review:
                    q2 = select(TokenDecisionRecord).where(
                        TokenDecisionRecord.token_address == review.token_address
                    ).order_by(TokenDecisionRecord.created_at.desc())
                    decision_row = (await session.execute(q2)).scalars().first()
                    q3 = select(TokenCandidateRecord).where(
                        TokenCandidateRecord.token_address == review.token_address
                    )
                    candidate_row = (await session.execute(q3)).scalars().first()
                    if settings.enable_telegram and settings.telegram_bot_token and settings.telegram_chat_id:
                        from app.utils.http import HttpClient
                        http = HttpClient()
                        score = decision_row.score if decision_row else '?'
                        symbol = (candidate_row.symbol if candidate_row else None) or review.token_address[:8]
                        liquidity = candidate_row.liquidity_usd if candidate_row else 0
                        text = (
                            f'✅ MANUAL APPROVE | {review.chain.upper()} | {symbol}\n'
                            f'Contract: `{review.token_address}`\n'
                            f'Liquidity: ${liquidity or 0:,.0f}\n'
                            f'Score: {score}'
                        )
                        tg_url = f'https://api.telegram.org/bot{settings.telegram_bot_token}/sendMessage'
                        await http.post_json(tg_url, json={
                            'chat_id': settings.telegram_chat_id,
                            'text': text,
                            'parse_mode': 'Markdown',
                            'disable_web_page_preview': True,
                        })
            except Exception as e:
                logging.warning(f'[admin] TG alert on approve failed: {e}')

        return {'status': 'updated'}


@app.get('/decisions/{token_address}', dependencies=[Depends(admin_auth)])
async def list_decisions(token_address: str) -> list[dict]:
    async with AsyncSessionLocal() as session:
        q = select(TokenDecisionRecord).where(TokenDecisionRecord.token_address == token_address).order_by(TokenDecisionRecord.created_at.desc())
        rows = list((await session.execute(q)).scalars().all())
        return [{'status': row.status, 'score': row.score, 'reasons': row.reasons, 'created_at': row.created_at.isoformat()} for row in rows]


@app.post('/blacklist', dependencies=[Depends(admin_auth)])
async def add_blacklist(entity_type: str, entity_value: str, reason_code: str) -> dict[str, str]:
    async with AsyncSessionLocal() as session:
        repo = ReputationRepository(session)
        await repo.add_blacklist(entity_type, entity_value, reason_code, source='admin_api', confidence=1.0)
        return {'status': 'blacklisted'}


@app.get('/blacklist', dependencies=[Depends(admin_auth)])
async def list_blacklist() -> list[dict]:
    async with AsyncSessionLocal() as session:
        q = select(BlacklistRecord).where(BlacklistRecord.active.is_(True)).order_by(BlacklistRecord.created_at.desc())
        rows = list((await session.execute(q)).scalars().all())
        return [{'entity_type': row.entity_type, 'entity_value': row.entity_value, 'reason_code': row.reason_code} for row in rows]


@app.get('/reputation', dependencies=[Depends(admin_auth)])
async def list_reputation() -> list[dict]:
    async with AsyncSessionLocal() as session:
        q = select(ReputationRecord).order_by(ReputationRecord.updated_at.desc()).limit(100)
        rows = list((await session.execute(q)).scalars().all())
        return [{'entity_type': row.entity_type, 'entity_value': row.entity_value, 'score': row.reputation_score, 'flagged': row.flagged} for row in rows]


@app.get('/graph/{chain}/{wallet_address}', dependencies=[Depends(admin_auth)])
async def graph(chain: str, wallet_address: str) -> dict:
    async with AsyncSessionLocal() as session:
        repo = GraphRepository(session)
        edges = await repo.neighbors(chain, wallet_address)
        return {'chain': chain, 'wallet_address': wallet_address, 'edges': edges}




@app.get('/ui-config', dependencies=[Depends(admin_auth)])
async def ui_config() -> dict:
    common = {
        'chain': str(settings.admin_default_chain or 'all'),
        'status': str(settings.admin_default_status or 'all'),
        'min_liquidity': float(settings.admin_default_min_liquidity or 0),
        'min_score': float(settings.admin_default_min_score or 0),
        'gem_only': bool(settings.admin_default_gem_enabled),
        'gem_min_score': float(settings.admin_default_min_gem or 0),
        'gem_tier': str(settings.admin_default_gem_tier or 'all'),
        'limit': int(settings.admin_default_limit or 100),
    }
    return {
        'common': common,
        'tokens': {
            **common,
            'min_holders': int(settings.admin_default_min_holders or 0),
            'verdict_stage': str(settings.admin_default_tokens_stage or 'all'),
            'projected_x': str(settings.admin_default_tokens_projected_x or 'all'),
        },
        'listings': {
            **common,
            'source': str(settings.admin_default_listings_source or 'all'),
        },
    }


@app.get('/dashboard/summary', dependencies=[Depends(admin_auth)])
async def dashboard_summary(chain: str = 'all') -> dict:
    async with AsyncSessionLocal() as session:
        def _chain_filter(q):
            if chain and chain.lower() != 'all':
                return q.where(TokenDecisionRecord.chain == chain.lower())
            return q
        total        = (await session.execute(_chain_filter(select(func.count()).select_from(TokenDecisionRecord)))).scalar_one()
        approvals    = (await session.execute(_chain_filter(select(func.count()).select_from(TokenDecisionRecord)).where(TokenDecisionRecord.status == 'APPROVE'))).scalar_one()
        rejects      = (await session.execute(_chain_filter(select(func.count()).select_from(TokenDecisionRecord)).where(TokenDecisionRecord.status == 'REJECT'))).scalar_one()
        review_later = (await session.execute(_chain_filter(select(func.count()).select_from(TokenDecisionRecord)).where(TokenDecisionRecord.status == 'REVIEW_LATER'))).scalar_one()
        avg_score    = (await session.execute(_chain_filter(select(func.avg(TokenDecisionRecord.score)).select_from(TokenDecisionRecord)))).scalar_one()
        return {
            'chain': chain,
            'decisions_total': total,
            'approvals': approvals,
            'rejects': rejects,
            'review_later': review_later,
            'avg_score': round(float(avg_score), 2) if avg_score else 0.0,
        }


@app.get('/tokens', dependencies=[Depends(admin_auth)])
async def list_tokens(
    chain: str = 'all',
    status: str = 'all',
    min_liquidity: float = 0.0,
    min_holders: int = 0,
    min_score: float = 0.0,
    gem_only: bool = False,
    gem_min_score: float = 0.0,
    gem_tier: str = 'all',
    projected_x: str = 'all',
    search: str = '',
    search_field: str = 'all',
    verdict_stage: str = 'all',
    source: str = 'all',
    token_family: str = 'all',
    page: int = 1,
    limit: int = 100,
) -> dict:
    limit = max(1, min(limit, 1000))
    page = max(1, page)
    offset = (page - 1) * limit

    async with AsyncSessionLocal() as session:
        candidate_q = select(TokenCandidateRecord)
        if chain and chain.lower() != 'all':
            candidate_q = candidate_q.where(TokenCandidateRecord.chain == chain.lower())
        if min_liquidity > 0:
            candidate_q = candidate_q.where(TokenCandidateRecord.liquidity_usd >= min_liquidity)
        if min_holders > 0:
            candidate_q = candidate_q.where(TokenCandidateRecord.holders >= min_holders)
        candidates = list((await session.execute(candidate_q.order_by(TokenCandidateRecord.first_seen_at.desc()).limit(limit * 20).offset(offset))).scalars().all())
        rows = []
        for candidate in candidates:
            decision_q = select(TokenDecisionRecord).where(
                TokenDecisionRecord.chain == candidate.chain,
                TokenDecisionRecord.token_address == candidate.token_address,
            ).order_by(TokenDecisionRecord.created_at.desc()).limit(1)
            decision = (await session.execute(decision_q)).scalars().first()
            evidence = (decision.evidence or {}) if decision else {}
            candidate_raw = candidate.raw or {}
            fast_verdict = candidate_raw.get('fast_verdict') or evidence.get('fast_verdict') or {}
            gem = evidence.get('gem') or {}
            bundle = candidate_raw.get('bundle') or evidence.get('bundle') or {}
            current_stage = (evidence.get('verdict') or {}).get('stage') or candidate_raw.get('verdict_stage') or (fast_verdict.get('stage') if fast_verdict else 'NONE')
            effective_score = decision.score if decision and decision.score is not None else fast_verdict.get('gem_score')
            effective_gem = gem or fast_verdict or {}

            # Якщо gem даних немає — рахуємо fast score на льоту з кандидата
            if not effective_gem:
                try:
                    _cand = _TokenCandidate(
                        chain=_Chain(candidate.chain.lower()),
                        token_address=candidate.token_address,
                        symbol=candidate.symbol, name=candidate.name,
                        liquidity_usd=candidate.liquidity_usd,
                        holders=candidate.holders,
                        website=candidate.website,
                        x_handle=candidate.x_handle,
                        telegram_url=candidate.telegram_url,
                        raw=candidate.raw or {},
                    )
                    _fast = _gem_predictor.fast(_cand)
                    effective_gem = _fast.to_dict()
                except Exception:
                    effective_gem = {}

            effective_gem_score = effective_gem.get('gem_score')
            effective_gem_tier = str(effective_gem.get('tier') or '').upper()
            effective_projected_x = str(effective_gem.get('projected_x') or '').lower()
            if status and status.lower() != 'all':
                if not decision or decision.status != status.upper():
                    continue
            if verdict_stage and verdict_stage.lower() != 'all' and str(current_stage).upper() != verdict_stage.upper():
                continue
            if min_score > 0 and (effective_score is None or float(effective_score) < min_score):
                continue
            if gem_only and not effective_gem:
                continue
            if source and source.lower() != 'all':
                row_source = candidate_raw.get('source') or 'dexscreener'
                if row_source != source.lower():
                    continue
            if gem_min_score > 0 and (effective_gem_score is None or float(effective_gem_score) < gem_min_score):
                continue
            if gem_tier and gem_tier.lower() != 'all' and effective_gem_tier != gem_tier.upper():
                continue
            if projected_x and projected_x.lower() != 'all' and effective_projected_x != projected_x.lower():
                continue
            family_meta = classify_token_family(candidate.chain, candidate.token_address, candidate_raw)
            profile_meta = classify_decision_profile(candidate.chain, candidate.token_address, candidate_raw, candidate.first_seen_at)
            effective_token_family = str(candidate.token_family or candidate_raw.get('token_family') or family_meta.get('token_family') or 'standard').lower()
            effective_launchpad = candidate.launchpad or candidate_raw.get('launchpad') or family_meta.get('launchpad')
            effective_decision_profile = str(evidence.get('decision_profile') or candidate_raw.get('decision_profile') or profile_meta.get('decision_profile') or 'standard').lower()
            effective_lifecycle_stage = str(candidate.lifecycle_stage or candidate_raw.get('lifecycle_stage') or ('graduated' if effective_decision_profile == 'pump_graduated' else 'early' if effective_decision_profile == 'pump_early' else 'standard')).lower()
            effective_graduated_confirmed = bool(candidate.graduated_confirmed or candidate_raw.get('graduated_confirmed') or profile_meta.get('graduated_confirmed'))
            if token_family and token_family.lower() != 'all' and effective_token_family != token_family.lower():
                continue
            q = (search or '').strip().lower()
            if q:
                field_map = {
                    'contract': str(candidate.token_address or '').lower(),
                    'symbol': str(candidate.symbol or '').lower(),
                    'name': str(candidate.name or '').lower(),
                    'deployer': str(candidate.deployer_address or '').lower(),
                }
                field_map['all'] = ' '.join(field_map.values())
                target = field_map.get((search_field or 'all').lower(), field_map['all'])
                if q not in target:
                    continue
            rows.append({
                'chain': candidate.chain,
                'token_address': candidate.token_address,
                'pair_address': candidate.pair_address,
                'symbol': candidate.symbol,
                'name': candidate.name,
                'liquidity_usd': candidate.liquidity_usd,
                'holders': candidate.holders,
                'website': candidate.website,
                'x_handle': candidate.x_handle,
                'telegram_url': candidate.telegram_url,
                'deployer_address': candidate.deployer_address,
                'first_seen_at': candidate.first_seen_at.isoformat() if candidate.first_seen_at else None,
                'discovered_at': candidate.first_seen_at.isoformat() if candidate.first_seen_at else None,
                'launch_at': _pair_created_iso_from_raw(candidate_raw),
                'status': decision.status if decision else 'PENDING',
                'score': round(decision.score, 2) if decision and decision.score is not None else (round(float(effective_score), 2) if effective_score is not None else None),
                'reasons': decision.reasons if decision else [],
                'subscores': decision.subscores if decision else {},
                'evidence': evidence,
                'candidate_raw': candidate_raw,
                'source': candidate_raw.get('source') or 'dexscreener',
                'token_family': effective_token_family,
                'launchpad': effective_launchpad,
                'lifecycle_stage': effective_lifecycle_stage,
                'graduated_confirmed': effective_graduated_confirmed,
                'fast_verdict': fast_verdict,
                'gem': effective_gem,
                'bundle': bundle,
                'verdict_stage': current_stage,
                'decision_profile': effective_decision_profile,
                'advisory_reasons': evidence.get('advisory_reasons') or [],
                'profile_meta': evidence.get('profile_meta') or profile_meta,
            })
        has_more = len(candidates) == limit * 20
        return {'items': rows[:limit], 'page': page, 'limit': limit, 'returned': len(rows[:limit]), 'has_more': has_more}


@app.get('/tokens/approved', dependencies=[Depends(admin_auth)])
async def list_approved_tokens(
    chain: str = 'all',
    min_liquidity: float = 0.0,
    min_holders: int = 0,
    min_score: float = 0.0,
    gem_only: bool = False,
    gem_min_score: float = 0.0,
    gem_tier: str = 'all',
    projected_x: str = 'all',
    search: str = '',
    search_field: str = 'all',
    verdict_stage: str = 'all',
    source: str = 'all',
    token_family: str = 'all',
    page: int = 1,
    limit: int = 100,
) -> dict:
    return await list_tokens(
        chain=chain,
        status='APPROVE',
        min_liquidity=min_liquidity,
        min_holders=min_holders,
        min_score=min_score,
        gem_only=gem_only,
        gem_min_score=gem_min_score,
        gem_tier=gem_tier,
        projected_x=projected_x,
        search=search,
        search_field=search_field,
        verdict_stage=verdict_stage,
        source=source,
        token_family=token_family,
        page=page,
        limit=limit,
    )

@app.get('/tokens/pump-fun', dependencies=[Depends(admin_auth)])
async def list_pump_fun_tokens(
    status: str = 'all',
    min_liquidity: float = 0.0,
    min_holders: int = 0,
    min_score: float = 0.0,
    page: int = 1,
    limit: int = 100,
    search: str = '',
) -> dict:
    return await list_tokens(
        chain='SOLANA',
        status=status,
        min_liquidity=min_liquidity,
        min_holders=min_holders,
        min_score=min_score,
        gem_only=False,
        gem_min_score=0.0,
        gem_tier='all',
        projected_x='all',
        search=search,
        search_field='all',
        verdict_stage='all',
        source='all',
        token_family='pump_suffix',
        page=page,
        limit=limit,
    )


@app.get('/tokens/pump-graduated', dependencies=[Depends(admin_auth)])
async def list_pump_graduated_tokens(
    status: str = 'APPROVE',
    min_liquidity: float = 0.0,
    min_holders: int = 0,
    min_score: float = 0.0,
    page: int = 1,
    limit: int = 100,
    search: str = '',
) -> dict:
    """Main graduated feed: APPROVE-only + Solana Raydium whitelist."""
    allowed_dex = [str(v).lower() for v in (settings.pump_graduated_main_allowed_dex or ['raydium'])]
    return await _list_pump_graduated_filtered(
        status=status,
        min_liquidity=min_liquidity,
        min_holders=min_holders,
        min_score=min_score,
        page=page,
        limit=limit,
        search=search,
        enforce_approve=True,
        allowed_solana_dex=allowed_dex,
        feed_name='main_raydium',
        social_mode='require_valid',
    )

@app.get('/tokens/pump-graduated-pumpswap', dependencies=[Depends(admin_auth)])
async def list_pump_graduated_pumpswap_tokens(
    status: str = 'all',
    min_liquidity: float = 0.0,
    min_holders: int = 0,
    min_score: float = 0.0,
    page: int = 1,
    limit: int = 100,
    search: str = '',
) -> dict:
    """Separate PumpSwap graduated feed."""
    allowed_dex = [str(v).lower() for v in (settings.pump_graduated_pumpswap_allowed_dex or ['pumpswap'])]
    return await _list_pump_graduated_filtered(
        status=status,
        min_liquidity=min_liquidity,
        min_holders=min_holders,
        min_score=min_score,
        page=page,
        limit=limit,
        search=search,
        enforce_approve=False,
        allowed_solana_dex=allowed_dex,
        feed_name='pumpswap',
        social_mode='require_valid',
    )


@app.get('/tokens/pump-graduated-social-gap', dependencies=[Depends(admin_auth)])
async def list_pump_graduated_social_gap_tokens(
    status: str = 'all',
    min_liquidity: float = 0.0,
    min_holders: int = 0,
    min_score: float = 0.0,
    page: int = 1,
    limit: int = 100,
    search: str = '',
) -> dict:
    """Graduated market-strong tokens with missing/invalid socials."""
    allowed = set(str(v).lower() for v in (settings.pump_graduated_main_allowed_dex or ['raydium']))
    allowed.update(str(v).lower() for v in (settings.pump_graduated_pumpswap_allowed_dex or ['pumpswap']))
    return await _list_pump_graduated_filtered(
        status=status,
        min_liquidity=min_liquidity,
        min_holders=min_holders,
        min_score=min_score,
        page=page,
        limit=limit,
        search=search,
        enforce_approve=False,
        allowed_solana_dex=sorted(allowed),
        feed_name='social_gap',
        social_mode='social_gap',
    )


def _pump_grad_dex_id(item: dict) -> str:
    raw = item.get('candidate_raw') or item.get('raw') or {}
    pair = raw.get('pair') or {}
    pre = raw.get('graduated_prefilter') or {}
    return str(pair.get('dexId') or pre.get('dex_id') or raw.get('dexId') or '').lower()


def _dex_allowed(dex_id: str, allowed: list[str]) -> bool:
    if not allowed:
        return True
    if not dex_id:
        return False
    for marker in allowed:
        marker_norm = str(marker or '').strip().lower()
        if marker_norm and marker_norm in dex_id:
            return True
    return False


async def _list_pump_graduated_filtered(
    *,
    status: str,
    min_liquidity: float,
    min_holders: int,
    min_score: float,
    page: int,
    limit: int,
    search: str,
    enforce_approve: bool,
    allowed_solana_dex: list[str],
    feed_name: str,
    social_mode: str = 'require_valid',
) -> dict:
    effective_status = 'APPROVE' if enforce_approve else status
    result = await list_tokens(
        chain='all',
        status=effective_status,
        min_liquidity=min_liquidity,
        min_holders=min_holders,
        min_score=min_score,
        gem_only=False,
        gem_min_score=0.0,
        gem_tier='all',
        projected_x='all',
        search=search,
        search_field='all',
        verdict_stage='all',
        source='all',
        token_family='all',
        page=page,
        limit=max(limit, 500),
    )

    graduated = []
    now_utc = datetime.now(timezone.utc)
    max_age_seconds = max(1.0, float(settings.pump_graduated_max_launch_age_hours)) * 3600.0
    for item in result.get('items', []):
        dp = str(item.get('decision_profile') or '').lower()
        lifecycle_stage = str(item.get('lifecycle_stage') or '').lower()
        is_confirmed = bool(item.get('graduated_confirmed'))
        has_site = bool(item.get('website'))
        has_social = has_quality_social(
            item.get('x_handle'),
            item.get('telegram_url'),
            require_valid_social=settings.pump_graduated_quality_require_valid_social,
        )
        launch_at = str(item.get('launch_at') or '')
        launch_ok = False
        if launch_at:
            try:
                launch_dt = datetime.fromisoformat(launch_at.replace('Z', '+00:00'))
                if launch_dt.tzinfo is None:
                    launch_dt = launch_dt.replace(tzinfo=timezone.utc)
                else:
                    launch_dt = launch_dt.astimezone(timezone.utc)
                launch_ok = (now_utc - launch_dt).total_seconds() <= max_age_seconds
            except Exception:
                launch_ok = False

        launch_gate_ok = launch_ok or social_mode == 'social_gap'
        if not (dp == 'pump_graduated' and lifecycle_stage == 'graduated' and is_confirmed and has_site and launch_gate_ok):
            continue
        if social_mode == 'require_valid' and not has_social:
            continue
        if social_mode == 'social_gap' and has_social:
            continue

        if str(item.get('chain') or '').upper() == 'SOLANA':
            dex_id = _pump_grad_dex_id(item)
            if not _dex_allowed(dex_id, allowed_solana_dex):
                continue

        if enforce_approve and str(item.get('status') or '').upper() != 'APPROVE':
            continue

        if social_mode == 'social_gap':
            candidate_raw = item.get('candidate_raw') or {}
            metrics = extract_graduated_metrics(candidate_raw, liquidity_fallback=float(item.get('liquidity_usd') or 0.0))
            chain_norm = str(item.get('chain') or 'solana').lower()
            if not passes_market_gate(
                float(metrics.get('liquidity_usd') or 0.0),
                float(metrics.get('volume_24h') or 0.0),
                float(metrics.get('txns_24h') or 0.0),
                settings,
                chain_norm,
            ):
                continue
            item['quality_gate_reason'] = 'social_gap_market_ok'
            item['social_gap'] = True
            item['has_valid_social'] = has_social
        else:
            quality_ok, quality_reason = passes_quality_gate(item, settings)
            if not quality_ok:
                continue
            item['quality_gate_reason'] = quality_reason or 'ok'
        item['pump_grad_rank'] = _pump_graduated_rank(item)
        graduated.append(item)

    graduated.sort(
        key=lambda item: (
            -float(item.get('pump_grad_rank') or 0.0),
            -float(item.get('score') or 0.0),
            -float(item.get('liquidity_usd') or 0.0),
        )
    )
    result['items'] = graduated[:limit]
    result['returned'] = len(graduated[:limit])
    result['launch_window_hours'] = float(settings.pump_graduated_max_launch_age_hours)
    result['feed'] = feed_name
    result['solana_dex_whitelist'] = allowed_solana_dex
    if enforce_approve:
        result['status_enforced'] = 'APPROVE'
    return result


@app.get('/dashboard', dependencies=[Depends(admin_auth)])
async def dashboard() -> HTMLResponse:
    async with AsyncSessionLocal() as session:
        decisions_total = (await session.execute(select(func.count()).select_from(TokenDecisionRecord))).scalar_one()
        approvals = (await session.execute(select(func.count()).select_from(TokenDecisionRecord).where(TokenDecisionRecord.status == 'APPROVE'))).scalar_one()
        rejects = (await session.execute(select(func.count()).select_from(TokenDecisionRecord).where(TokenDecisionRecord.status == 'REJECT'))).scalar_one()
        reviews = (await session.execute(select(func.count()).select_from(ManualReviewRecord).where(ManualReviewRecord.status == 'OPEN'))).scalar_one()
        risky_clusters = list((await session.execute(select(WalletClusterRecord).order_by(WalletClusterRecord.risk_score.desc()).limit(10))).scalars().all())
        rep_rows = list((await session.execute(select(ReputationRecord).order_by(ReputationRecord.reputation_score.asc()).limit(10))).scalars().all())
    metrics = await METRICS.snapshot()
    html = f"""
    <html><head><title>CryptoParser Fraud Analytics</title>
    <style>
    body {{ font-family: Arial, sans-serif; margin: 24px; background:#0b1020; color:#f4f7fb; }}
    .grid {{ display:grid; grid-template-columns: repeat(4, minmax(180px, 1fr)); gap:16px; }}
    .card {{ background:#151d33; padding:18px; border-radius:16px; box-shadow:0 8px 24px rgba(0,0,0,.25); }}
    table {{ width:100%; border-collapse: collapse; margin-top:16px; }}
    th, td {{ border-bottom:1px solid #2a3555; padding:10px; text-align:left; vertical-align:top; }}
    .muted {{ color:#99a8cc; }}
    code {{ color:#99f6e4; }}
    </style></head><body>
    <h1>Fraud Analytics Dashboard</h1>
    <div class='grid'>
      <div class='card'><div class='muted'>Decisions</div><h2>{decisions_total}</h2></div>
      <div class='card'><div class='muted'>Approvals</div><h2>{approvals}</h2></div>
      <div class='card'><div class='muted'>Rejects</div><h2>{rejects}</h2></div>
      <div class='card'><div class='muted'>Open Reviews</div><h2>{reviews}</h2></div>
    </div>
    <div class='card' style='margin-top:20px;'>
      <h2>Runtime Metrics</h2>
      <pre>{escape(str(metrics))}</pre>
    </div>
    <div class='card' style='margin-top:20px;'>
      <h2>Highest Risk Clusters</h2>
      <table><tr><th>Cluster</th><th>Risk</th><th>Labels</th><th>Wallets</th></tr>
      {''.join(f"<tr><td><code>{escape(row.cluster_id)}</code></td><td>{row.risk_score:.2f}</td><td>{escape(', '.join(row.labels or []))}</td><td>{escape(', '.join((row.wallets or [])[:4]))}</td></tr>" for row in risky_clusters)}
      </table>
    </div>
    <div class='card' style='margin-top:20px;'>
      <h2>Lowest Reputation Entities</h2>
      <table><tr><th>Type</th><th>Value</th><th>Score</th><th>Flagged</th></tr>
      {''.join(f"<tr><td>{escape(row.entity_type)}</td><td><code>{escape(row.entity_value)}</code></td><td>{row.reputation_score:.2f}</td><td>{'yes' if row.flagged else 'no'}</td></tr>" for row in rep_rows)}
      </table>
    </div>
    </body></html>
    """
    return HTMLResponse(html)


@app.get('/jobs', dependencies=[Depends(admin_auth)])
async def jobs() -> list[dict]:
    async with AsyncSessionLocal() as session:
        repo = SchedulerRepository(session)
        rows = await repo.jobs()
        return [{'job_name': r.job_name, 'enabled': r.enabled, 'interval_seconds': r.interval_seconds, 'next_run_at': r.next_run_at.isoformat() if r.next_run_at else None, 'last_run_at': r.last_run_at.isoformat() if r.last_run_at else None, 'last_error': r.last_error} for r in rows]


@app.get('/jobs/runs', dependencies=[Depends(admin_auth)])
async def job_runs() -> list[dict]:
    async with AsyncSessionLocal() as session:
        repo = SchedulerRepository(session)
        rows = await repo.latest_runs()
        return [{'job_name': r.job_name, 'status': r.status, 'started_at': r.started_at.isoformat() if r.started_at else None, 'finished_at': r.finished_at.isoformat() if r.finished_at else None, 'error_message': r.error_message} for r in rows]


@app.get('/feature-flags', dependencies=[Depends(admin_auth)])
async def get_feature_flags() -> dict:
    return {
        'birdeye_solana_enabled': bool(FEATURE_FLAGS.get('birdeye_solana_enabled', False)),
        'note': 'Birdeye in this project is Solana-only; this toggle enables or disables Solana Birdeye ingestion.'
    }


@app.post('/feature-flags/birdeye-solana', dependencies=[Depends(admin_auth)])
async def set_birdeye_solana(enabled: bool) -> dict:
    FEATURE_FLAGS['birdeye_solana_enabled'] = bool(enabled)
    settings.enable_birdeye = bool(enabled)
    return {
        'status': 'updated',
        'birdeye_solana_enabled': bool(FEATURE_FLAGS['birdeye_solana_enabled'])
    }


@app.get('/historical/{chain}/{token_address}', dependencies=[Depends(admin_auth)])
async def historical_token(chain: str, token_address: str) -> dict:
    async with AsyncSessionLocal() as session:
        repo = HistoricalRepository(session)
        row = await repo.get(chain, token_address)
        if not row:
            raise HTTPException(status_code=404, detail='not_found')
        return {
            'chain': row.chain,
            'token_address': row.token_address,
            'first_seen_at': row.first_seen_at.isoformat() if row.first_seen_at else None,
            'first_decision': row.first_decision,
            'latest_decision': row.latest_decision,
            'peak_liquidity_usd': row.peak_liquidity_usd,
            'latest_liquidity_usd': row.latest_liquidity_usd,
            'peak_holders': row.peak_holders,
            'latest_holders': row.latest_holders,
            'historical_score': row.historical_score,
            'labels': row.labels,
            'notes': row.notes,
        }


@app.post('/alerts/clear', dependencies=[Depends(admin_auth)])
async def clear_alerts() -> dict:
    async with AsyncSessionLocal() as session:
        await session.execute(__import__('sqlalchemy', fromlist=['text']).text('DELETE FROM realtime_alerts'))
        await session.commit()
        return {'status': 'cleared'}


@app.post('/reviews/clear', dependencies=[Depends(admin_auth)])
async def clear_reviews() -> dict:
    async with AsyncSessionLocal() as session:
        await session.execute(__import__('sqlalchemy', fromlist=['text']).text('DELETE FROM manual_reviews'))
        await session.commit()
        return {'status': 'cleared'}


@app.get('/alerts/realtime', dependencies=[Depends(admin_auth)])
async def realtime_alerts(limit: int = 100) -> list[dict]:
    async with AsyncSessionLocal() as session:
        repo = RealtimeAlertRepository(session)
        rows = await repo.latest(limit=max(1, min(limit, 500)))
        return [{
            'chain': r.chain,
            'token_address': r.token_address,
            'event_type': r.event_type,
            'severity': r.severity,
            'payload': r.payload,
            'created_at': r.created_at.isoformat() if r.created_at else None,
        } for r in rows]


@app.post('/labels', dependencies=[Depends(admin_auth)])
async def create_label(payload: dict) -> dict:
    svc = AnalystWorkflowService()
    label = svc.validate(payload)
    async with AsyncSessionLocal() as session:
        repo = AnalystLabelRepository(session)
        await repo.create(label.chain, label.token_address, label.label, label.value, label.analyst, label.notes or '')
        return {'status': 'created'}


@app.get('/labels/{chain}/{token_address}', dependencies=[Depends(admin_auth)])
async def list_labels(chain: str, token_address: str) -> list[dict]:
    async with AsyncSessionLocal() as session:
        repo = AnalystLabelRepository(session)
        rows = await repo.list_for_token(chain, token_address)
        return [{
            'id': r.id,
            'label': r.label,
            'value': r.value,
            'analyst': r.analyst,
            'notes': r.notes,
            'created_at': r.created_at.isoformat() if r.created_at else None,
        } for r in rows]


# ── calibration & outcomes ────────────────────────────────────────────────────

@app.get('/calibration/report', dependencies=[Depends(admin_auth)])
async def calibration_report() -> dict:
    """Повертає останній звіт ThresholdCalibrator із config/threshold_calibration.json."""
    path = Path('config/threshold_calibration.json')
    if not path.exists():
        raise HTTPException(status_code=404, detail='calibration report not yet generated — run threshold_calibrator job first')
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f'failed to read report: {exc}')


@app.post('/calibration/run', dependencies=[Depends(admin_auth)])
async def run_calibration_now() -> dict:
    """Запускає ThresholdCalibrator негайно (не чекаючи scheduler)."""
    from app.services.threshold_calibrator import run_threshold_calibration
    await run_threshold_calibration(AsyncSessionLocal)
    path = Path('config/threshold_calibration.json')
    if path.exists():
        return json.loads(path.read_text(encoding='utf-8'))
    return {'status': 'completed', 'note': 'insufficient data to generate report'}


@app.get('/outcomes/summary', dependencies=[Depends(admin_auth)])
async def outcomes_summary() -> dict:
    """Статистика outcome-лейблів (rug / dead / alive) від outcome_tracker."""
    async with AsyncSessionLocal() as session:
        from app.db.models import AnalystLabelRecord
        q = select(AnalystLabelRecord).where(AnalystLabelRecord.label == 'outcome')
        rows = list((await session.execute(q)).scalars().all())
    counts: dict[str, int] = {}
    by_chain: dict[str, dict[str, int]] = {}
    for r in rows:
        counts[r.value] = counts.get(r.value, 0) + 1
        by_chain.setdefault(r.chain, {})
        by_chain[r.chain][r.value] = by_chain[r.chain].get(r.value, 0) + 1
    total = len(rows)
    rug_rate = round((counts.get('rug', 0) + counts.get('dead', 0)) / total * 100, 1) if total > 0 else 0.0
    return {
        'total':      total,
        'by_outcome': counts,
        'by_chain':   by_chain,
        'rug_rate_pct': rug_rate,
    }


@app.post('/outcomes/run', dependencies=[Depends(admin_auth)])
async def run_outcome_tracker_now() -> dict:
    """Запускає OutcomeTracker негайно (не чекаючи scheduler)."""
    from app.services.outcome_tracker import run_outcome_tracker
    await run_outcome_tracker(AsyncSessionLocal)
    return {'status': 'completed'}


# ── root redirect ─────────────────────────────────────────────────────────────

@app.get('/')
async def root():
    """Redirect '/' → '/analyst' для зручності."""
    from fastapi.responses import RedirectResponse
    return RedirectResponse(url='/analyst', status_code=302)


# PULSE OS Paper Trading API

def _pulse_position_dict(row) -> dict:
    return {
        'id': row.id,
        'chain': row.chain,
        'token_address': row.token_address,
        'symbol': row.symbol,
        'status': row.status,
        'strategy': row.strategy,
        'entry_price': row.entry_price,
        'current_price': row.current_price,
        'peak_price': row.peak_price,
        'exit_price': row.exit_price,
        'entry_liquidity_usd': row.entry_liquidity_usd,
        'peak_liquidity_usd': row.peak_liquidity_usd,
        'current_liquidity_usd': row.current_liquidity_usd,
        'entry_holders': row.entry_holders,
        'peak_holders': row.peak_holders,
        'current_holders': row.current_holders,
        'paper_size_usd': row.paper_size_usd,
        'paper_pnl_usd': row.paper_pnl_usd,
        'paper_pnl_pct': row.paper_pnl_pct,
        'stop_loss_pct': row.stop_loss_pct,
        'take_profit_pct': row.take_profit_pct,
        'trailing_stop_pct': row.trailing_stop_pct,
        'time_limit_minutes': row.time_limit_minutes,
        'exit_reason': row.exit_reason,
        'entry_continuation_score': row.entry_continuation_score,
        'entry_risk_score': row.entry_risk_score,
        'entry_brain_strategy': row.entry_brain_strategy,
        'bundle_severity': row.bundle_severity,
        'bundle_wallet_count': row.bundle_wallet_count,
        'bundle_supply_pct': row.bundle_supply_pct,
        'first_seen_at': row.first_seen_at.isoformat() if row.first_seen_at else None,
        'entry_at': row.entry_at.isoformat() if row.entry_at else None,
        'peak_at': row.peak_at.isoformat() if row.peak_at else None,
        'exit_at': row.exit_at.isoformat() if row.exit_at else None,
        'last_checked_at': row.last_checked_at.isoformat() if row.last_checked_at else None,
        'updated_at': row.updated_at.isoformat() if row.updated_at else None,
    }


def _pulse_closed_trade_dict(row) -> dict:
    _meta = row.execution_metadata or {}
    _sl   = _meta.get('stop_loss_pct') or getattr(row, 'stop_loss_pct', None)
    _tp   = _meta.get('take_profit_pct') or getattr(row, 'take_profit_pct', None)
    _abc_wave   = _meta.get('abc_wave') or _meta.get('mfv_phase') or _meta.get('abc_phase') or _meta.get('abc_entry_phase')
    _abc_conf   = _meta.get('mfv_confidence') or _meta.get('abc_confidence')
    # Duration
    _dur_min = None
    if row.entry_at and row.exit_at:
        import datetime as _dt
        _ea = row.entry_at.replace(tzinfo=_dt.timezone.utc) if row.entry_at.tzinfo is None else row.entry_at
        _xa = row.exit_at.replace(tzinfo=_dt.timezone.utc) if row.exit_at.tzinfo is None else row.exit_at
        _dur_min = round((_xa - _ea).total_seconds() / 60, 1)
    return {
        'id': row.id,
        'chain': row.chain,
        'token_address': row.token_address,
        'symbol': row.symbol,
        'status': row.status,
        'strategy': row.strategy or _meta.get('strategy_hint') or 'unknown',
        'entry_price': row.entry_price,
        'current_price': row.exit_price,
        'exit_price': row.exit_price,
        'paper_size_usd': row.paper_size_usd,
        'paper_pnl_usd': row.paper_pnl_usd,
        'paper_pnl_pct': row.paper_pnl_pct,
        'stop_loss_pct': _sl,
        'take_profit_pct': _tp,
        'exit_reason': row.exit_reason,
        'entry_continuation_score': row.entry_continuation_score,
        'entry_risk_score': row.entry_risk_score,
        'entry_at': row.entry_at.isoformat() if row.entry_at else None,
        'exit_at': row.exit_at.isoformat() if row.exit_at else None,
        'duration_minutes': _dur_min,
        'abc_wave': _abc_wave,
        'abc_confidence': round(float(_abc_conf), 2) if _abc_conf else None,
        'execution_metadata': _meta,
    }


@app.get('/api/pulse/positions', dependencies=[Depends(admin_auth)])
async def get_pulse_positions(status: str | None = None) -> list[dict]:
    """Paper trading positions. status=open|paper_open|paper_closed|all."""
    from app.db.models import TokenLifecycleRecord
    from app.services.pulse.lifecycle import LifecycleService
    from app.services.pulse.paper_trader import PaperTrader

    async with AsyncSessionLocal() as session:
        svc = LifecycleService(session)
        if status in (None, 'open', 'paper_open'):
            positions = await svc.get_open_positions()
            # Refresh live prices on read so the panel doesn't show stale Entry values.
            trader = PaperTrader(session)
            await trader.refresh_open_position_prices(positions)
            await session.commit()
        elif status == 'paper_closed':
            rows = await svc.get_closed_trades(limit=100)
            return [_pulse_closed_trade_dict(p) for p in rows]
        elif status == 'all':
            q = select(TokenLifecycleRecord).order_by(TokenLifecycleRecord.updated_at.desc()).limit(100)
            positions = list((await session.execute(q)).scalars().all())
            closed_rows = await svc.get_closed_trades(limit=100)
            open_payload = [_pulse_position_dict(p) for p in positions]
            closed_payload = [_pulse_closed_trade_dict(p) for p in closed_rows]

            def _sort_ts(item: dict) -> str:
                return str(
                    item.get('updated_at')
                    or item.get('exit_at')
                    or item.get('last_checked_at')
                    or item.get('entry_at')
                    or item.get('first_seen_at')
                    or ''
                )

            merged = open_payload + closed_payload
            merged.sort(key=_sort_ts, reverse=True)
            return merged
        else:
            q = select(TokenLifecycleRecord).order_by(TokenLifecycleRecord.updated_at.desc()).limit(100)
            if status != 'all':
                q = q.where(TokenLifecycleRecord.status == status)
            positions = list((await session.execute(q)).scalars().all())
        return [_pulse_position_dict(p) for p in positions]




@app.post('/api/pulse/positions/{token_address}/close', dependencies=[Depends(admin_auth)])
async def manual_close_position(token_address: str) -> dict:
    """Manually close an open paper trading position at current market price."""
    from app.services.pulse.lifecycle import LifecycleService
    from app.services.pulse.paper_trader import PaperTrader
    async with AsyncSessionLocal() as session:
        svc = LifecycleService(session)
        positions = await svc.get_open_positions()
        position = next((p for p in positions if p.token_address.lower() == token_address.lower()), None)
        if position is None:
            raise HTTPException(status_code=404, detail='Position not found or already closed')
        trader = PaperTrader(session)
        current_price = await trader.get_price_from_dexscreener(
            position.chain, position.token_address, None
        )
        exit_price = current_price or float(position.current_price or position.entry_price or 0)
        await svc.close_position(position, exit_price, 'manual_close')
        await session.commit()
        return {
            'status': 'closed',
            'token_address': token_address,
            'exit_price': exit_price,
            'pnl_pct': round(float(position.paper_pnl_pct or 0), 2),
        }

@app.get('/api/pulse/stats', dependencies=[Depends(admin_auth)])
async def get_pulse_stats(days: int = 7) -> dict:
    """Aggregated paper trading stats."""
    from app.services.pulse.lifecycle import LifecycleService

    async with AsyncSessionLocal() as session:
        svc = LifecycleService(session)
        return await svc.get_stats(days=days)


@app.get('/api/pulse/backtest', dependencies=[Depends(admin_auth)])
async def run_pulse_backtest(
    days: int = 30,
    sl_pct: float = 8.0,
    tp_pct: float = 20.0,
    trailing_pct: float = 15.0,
    partial_tp_pct: float = 30.0,
    partial_tp_fraction: float = 0.5,
    stagnation_minutes: int = 60,
    min_liquidity_exit_usd: float = 30_000.0,
) -> dict:
    from app.services.pulse.backtester import Backtester

    async with AsyncSessionLocal() as session:
        svc = Backtester(session)
        return await svc.run(
            days=days,
            params={
                'sl_pct': sl_pct,
                'tp_pct': tp_pct,
                'trailing_pct': trailing_pct,
                'partial_tp_pct': partial_tp_pct,
                'partial_tp_fraction': partial_tp_fraction,
                'stagnation_minutes': stagnation_minutes,
                'min_liquidity_exit_usd': min_liquidity_exit_usd,
            },
        )


@app.get('/api/pulse/ml/export', dependencies=[Depends(admin_auth)])
async def export_pulse_ml_dataset(days: int = 180, limit: int = 500) -> dict:
    from app.services.pulse.ml_export import PulseMLExportService

    async with AsyncSessionLocal() as session:
        svc = PulseMLExportService(session)
        rows = await svc.export_rows(days=days, limit=limit)
        return {'rows': rows, 'count': len(rows), 'days': days}


@app.get('/api/pulse/ml/train', dependencies=[Depends(admin_auth)])
async def train_pulse_ml_model(days: int = 180, limit: int = 10_000) -> dict:
    from app.services.pulse.ml_export import PulseMLExportService

    async with AsyncSessionLocal() as session:
        svc = PulseMLExportService(session)
        return await svc.train_baseline(days=days, limit=limit)


@app.get('/api/pulse/feed', dependencies=[Depends(admin_auth)])
async def get_pulse_feed(limit: int = 50) -> list[dict]:
    """Live feed from realtime alerts."""
    async with AsyncSessionLocal() as session:
        alerts = await session.execute(
            select(RealtimeAlertRecord)
            .order_by(RealtimeAlertRecord.created_at.desc())
            .limit(max(1, min(int(limit), 500)))
        )
        items = alerts.scalars().all()
        return [
            {
                'time': a.created_at.isoformat(),
                'event_type': a.event_type,
                'token_address': a.token_address,
                'chain': a.chain,
                'severity': a.severity,
                'payload': a.payload,
            }
            for a in items
        ]


@app.get('/api/pulse/farm/positions', dependencies=[Depends(admin_auth)])
async def farm_positions() -> list[dict]:
    """Open and recently closed Farm Mode positions."""
    from app.db.models import FarmPosition

    async with AsyncSessionLocal() as session:
        positions = list(
            (
                await session.execute(
                    select(FarmPosition).order_by(FarmPosition.entry_time.desc()).limit(50)
                )
            )
            .scalars()
            .all()
        )

    result = []
    for p in positions:
        pnl_pct = None
        if p.current_price and p.entry_price:
            pnl_pct = round((float(p.current_price) - float(p.entry_price)) / float(p.entry_price) * 100.0, 2)
        result.append(
            {
                'id': p.id,
                'mint': p.mint,
                'symbol': p.symbol,
                'status': p.status,
                'entry_price': p.entry_price,
                'current_price': p.current_price,
                'pnl_pct': (p.pnl_pct * 100.0) if p.status == 'CLOSED' and p.pnl_pct is not None else pnl_pct,
                'pnl_usd': p.pnl_usd,
                'exit_reason': p.exit_reason,
                'bundle_wallet_count': p.bundle_wallet_count,
                'bundle_pct': round((p.bundle_pct or 0.0) * 100.0, 1),
                'bundle_farm_score': p.bundle_farm_score,
                'bundle_sold_pct': round((p.bundle_sold_pct or 0.0) * 100.0, 1),
                'bundle_danger': p.bundle_danger,
                'entry_time': p.entry_time.isoformat() if p.entry_time else None,
                'exit_time': p.exit_time.isoformat() if p.exit_time else None,
            }
        )
    return result


@app.get('/api/pulse/farm/stats', dependencies=[Depends(admin_auth)])
async def farm_stats() -> dict:
    """Farm Mode statistics."""
    from app.db.models import FarmPosition

    async with AsyncSessionLocal() as session:
        total = (await session.execute(select(func.count(FarmPosition.id)))).scalar_one()
        open_count = (
            await session.execute(select(func.count(FarmPosition.id)).where(FarmPosition.status == 'OPEN'))
        ).scalar_one()
        closed = list(
            (
                await session.execute(select(FarmPosition).where(FarmPosition.status == 'CLOSED'))
            )
            .scalars()
            .all()
        )

    wins = [p for p in closed if (p.pnl_pct or 0.0) > 0]
    losses = [p for p in closed if (p.pnl_pct or 0.0) <= 0]
    avg_win = sum(float(p.pnl_pct or 0.0) for p in wins) / len(wins) * 100.0 if wins else 0.0
    avg_loss = sum(float(p.pnl_pct or 0.0) for p in losses) / len(losses) * 100.0 if losses else 0.0
    win_rate = len(wins) / len(closed) * 100.0 if closed else 0.0
    exit_reasons: dict[str, int] = {}
    for p in closed:
        reason = p.exit_reason or 'UNKNOWN'
        exit_reasons[reason] = exit_reasons.get(reason, 0) + 1

    return {
        'total_trades': total,
        'open_positions': open_count,
        'closed_trades': len(closed),
        'win_rate': round(win_rate, 1),
        'avg_win_pct': round(avg_win, 1),
        'avg_loss_pct': round(avg_loss, 1),
        'exit_reasons': exit_reasons,
        'total_paper_pnl_usd': round(sum(float(p.pnl_usd or 0.0) for p in closed), 2),
    }
