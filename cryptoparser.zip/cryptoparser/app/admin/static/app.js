const CHAINS = ['SOLANA', 'BSC', 'BASE'];

function setBirdeyeToggle(enabled){
  const btn=document.getElementById('birdeye-toggle');
  btn.dataset.enabled=enabled ? '1' : '0';
  btn.textContent=enabled ? 'ON · Solana only' : 'OFF';
  btn.classList.toggle('on', !!enabled);
  btn.classList.toggle('off', !enabled);
}
async function loadFeatureFlags(){
  const flags=await fetchJson('/feature-flags');
  setBirdeyeToggle(!!flags.birdeye_solana_enabled);
}
async function toggleBirdeye(){
  const btn=document.getElementById('birdeye-toggle');
  btn.disabled=true;
  try{
    const current=btn.dataset.enabled==='1';
    const next=!current;
    const r=await fetch(`/feature-flags/birdeye-solana?enabled=${encodeURIComponent(String(next))}`,{method:'POST',headers:headers()});
    if(!r.ok) throw new Error(`${r.status} ${await r.text()}`);
    const data=await r.json();
    setBirdeyeToggle(!!data.birdeye_solana_enabled);
  }catch(e){
    alert(`Birdeye toggle failed: ${e}`);
  }finally{
    btn.disabled=false;
  }
}

// Авто-заповнення токена з URL при завантаженні
(function(){
  const urlToken = new URLSearchParams(window.location.search).get('token') || '';
  if(urlToken){
    document.addEventListener('DOMContentLoaded', () => {
      const el = document.getElementById('token');
      if(el && !el.value.trim()) el.value = urlToken;
    });
    // Зберігаємо в пам'яті для headers() до DOM ready
    window._urlToken = urlToken;
  }
})();
function headers(){
  const el = document.getElementById('token');
  const t = (el ? el.value.trim() : '') || window._urlToken || '';
  return {'x-admin-token': t};
}
async function fetchText(path){const r=await fetch(path,{headers:headers()});if(!r.ok) throw new Error(`${r.status} ${await r.text()}`);return await r.text();}
async function fetchJson(path){const r=await fetch(path,{headers:headers()});if(!r.ok) throw new Error(`${r.status} ${await r.text()}`);return await r.json();}
function qs(){
  const chain=document.getElementById('chain').value;
  const status=document.getElementById('status').value;
  const minLiquidity=Number(document.getElementById('min-liquidity').value||0);
  const minHolders=Number(document.getElementById('min-holders').value||0);
  const minScore=Number(document.getElementById('min-score').value||0);
  const limit=Number(document.getElementById('limit').value||50);
  return new URLSearchParams({chain,status,min_liquidity:String(minLiquidity),min_holders:String(minHolders),min_score:String(minScore),limit:String(limit)});
}
function fmtMoney(v){ if(v===null||v===undefined) return '—'; return new Intl.NumberFormat('en-US',{maximumFractionDigits:0}).format(v); }
function fmtScore(v){ if(v===null||v===undefined) return '—'; return Number(v).toFixed(1); }
function link(href,label){ return href ? `<a href="${href}" target="_blank" rel="noreferrer">${label}</a>` : '—'; }
function tokenLinks(row){
  const socials=[];
  if(row.website) socials.push(link(row.website,'site'));
  if(row.telegram_url) socials.push(link(row.telegram_url,'tg'));
  if(row.x_handle){
    const href=row.x_handle.startsWith('http') ? row.x_handle : `https://x.com/${row.x_handle.replace(/^@/,'')}`;
    socials.push(link(href,'x'));
  }
  return socials.join(' · ') || '—';
}
function setSummary(summary){
  document.getElementById('summary-decisions').textContent=summary.decisions_total ?? 0;
  document.getElementById('summary-approvals').textContent=summary.approvals ?? 0;
  document.getElementById('summary-rejects').textContent=summary.rejects ?? 0;
  document.getElementById('summary-score').textContent=fmtScore(summary.avg_score ?? 0);
}
function renderChainCards(stats){
  const container=document.getElementById('chain-cards');
  container.innerHTML='';
  for(const chain of CHAINS){
    const data=stats[chain] || {decisions_total:0, approvals:0, rejects:0, avg_score:0};
    const el=document.createElement('article');
    el.className='chain-card';
    el.innerHTML=`<div class="chain-name">${chain}</div>
      <div class="chain-row"><span>Visible</span><strong>${data.decisions_total}</strong></div>
      <div class="chain-row"><span>Approve</span><strong>${data.approvals}</strong></div>
      <div class="chain-row"><span>Reject</span><strong>${data.rejects}</strong></div>
      <div class="chain-row"><span>Avg score</span><strong>${fmtScore(data.avg_score)}</strong></div>`;
    container.appendChild(el);
  }
}
function renderTokens(rows){
  const body=document.getElementById('tokens-body');
  body.innerHTML='';
  for(const row of rows){
    const tr=document.createElement('tr');
    const reasons=(row.reasons||[]).slice(0,3).join(', ');
    tr.innerHTML=`<td><span class="badge chain">${row.chain}</span></td>
      <td><div class="token-name">${row.symbol||'?'}</div><div class="muted small">${row.name||''}</div><div class="mono small">${row.token_address}</div></td>
      <td><span class="badge status status-${(row.status||'unknown').toLowerCase()}">${row.status||'UNKNOWN'}</span></td>
      <td>${fmtScore(row.score)}</td>
      <td>$${fmtMoney(row.liquidity_usd)}</td>
      <td>${row.holders ?? '—'}</td>
      <td>${tokenLinks(row)}</td>
      <td class="small">${reasons || '—'}</td>`;
    body.appendChild(tr);
  }
  if(!rows.length){
    const tr=document.createElement('tr');
    tr.innerHTML='<td colspan="8" class="empty">No rows for current filters.</td>';
    body.appendChild(tr);
  }
}
async function loadSummary(){
  const chain=document.getElementById('chain').value;
  setSummary(await fetchJson(`/dashboard/summary?chain=${encodeURIComponent(chain)}`));
  const stats={};
  await Promise.all(CHAINS.map(async (chainName)=>{ stats[chainName]=await fetchJson(`/dashboard/summary?chain=${encodeURIComponent(chainName)}`); }));
  renderChainCards(stats);
}
async function loadTokens(){
  const rows=await fetchJson(`/tokens?${qs().toString()}`);
  renderTokens(rows);
}
async function loadOps(){
  try{document.getElementById('workers').textContent=JSON.stringify(await fetchJson('/workers'),null,2);}catch(e){document.getElementById('workers').textContent=String(e)}
  try{document.getElementById('jobs').textContent=JSON.stringify(await fetchJson('/jobs'),null,2);}catch(e){document.getElementById('jobs').textContent=String(e)}
  try{document.getElementById('runs').textContent=JSON.stringify(await fetchJson('/jobs/runs'),null,2);}catch(e){document.getElementById('runs').textContent=String(e)}
  try{document.getElementById('reviews').textContent=JSON.stringify(await fetchJson('/reviews'),null,2);}catch(e){document.getElementById('reviews').textContent=String(e)}
}
async function loadAll(){
  await Promise.all([loadFeatureFlags(), loadSummary(), loadTokens(), loadOps()]);
}
window.loadAll=loadAll;
window.addEventListener('DOMContentLoaded',()=>{
  document.getElementById('reload-btn').addEventListener('click', loadAll);
  document.getElementById('birdeye-toggle').addEventListener('click', toggleBirdeye);
  for(const id of ['chain','status','min-liquidity','min-holders','min-score','limit']){
    document.getElementById(id).addEventListener('change', loadAll);
  }
});

// PULSE OS UI
function pulseHeaders(){ return (typeof authHeaders === 'function') ? authHeaders() : headers(); }

async function loadPulsePositions() {
    const status = document.getElementById('positions-status')?.value || 'open';
    const res = await fetch(`/api/pulse/positions?status=${encodeURIComponent(status)}`, { headers: pulseHeaders() });
    const positions = await res.json();
    const container = document.getElementById('positions-container');
    if (!container) return;

    if (positions.length === 0) {
        container.innerHTML = '<p class="empty-state">No positions found.</p>';
        return;
    }

    const isClosed = status === 'paper_closed';

    if (isClosed) {
        // --- Таблиця закритих позицій ---
        const totalPnlUsd = positions.reduce((s, p) => s + (p.paper_pnl_usd || 0), 0);
        const totalPnlPct = positions.reduce((s, p) => s + (p.paper_pnl_pct || 0), 0) / positions.length;
        const wins = positions.filter(p => (p.paper_pnl_pct || 0) >= 0).length;
        const losses = positions.length - wins;
        const pnlSign = totalPnlUsd >= 0 ? '+' : '';
        const summaryColor = totalPnlUsd >= 0 ? '#2ecc71' : '#e74c3c';

        container.innerHTML = `
        <div style="display:flex;gap:16px;margin-bottom:12px;flex-wrap:wrap;">
          <div style="background:#1e2130;border-radius:8px;padding:10px 18px;min-width:120px;">
            <div style="font-size:11px;color:#888;margin-bottom:2px;">TOTAL PnL</div>
            <div style="font-size:18px;font-weight:700;color:${summaryColor};">${pnlSign}$${Math.abs(totalPnlUsd).toFixed(2)}</div>
          </div>
          <div style="background:#1e2130;border-radius:8px;padding:10px 18px;min-width:100px;">
            <div style="font-size:11px;color:#888;margin-bottom:2px;">AVG PnL %</div>
            <div style="font-size:18px;font-weight:700;color:${summaryColor};">${pnlSign}${totalPnlPct.toFixed(1)}%</div>
          </div>
          <div style="background:#1e2130;border-radius:8px;padding:10px 18px;min-width:100px;">
            <div style="font-size:11px;color:#888;margin-bottom:2px;">WIN / LOSS</div>
            <div style="font-size:18px;font-weight:700;"><span style="color:#2ecc71">${wins}</span> / <span style="color:#e74c3c">${losses}</span></div>
          </div>
          <div style="background:#1e2130;border-radius:8px;padding:10px 18px;min-width:80px;">
            <div style="font-size:11px;color:#888;margin-bottom:2px;">TRADES</div>
            <div style="font-size:18px;font-weight:700;">${positions.length}</div>
          </div>
        </div>
        <table style="width:100%;border-collapse:collapse;font-size:13px;">
          <thead>
            <tr style="color:#888;border-bottom:1px solid #2a2d3e;text-align:left;">
              <th style="padding:6px 8px;">Token</th>
              <th style="padding:6px 8px;">Strategy</th>
              <th style="padding:6px 8px;">Entry</th>
              <th style="padding:6px 8px;">Exit</th>
              <th style="padding:6px 8px;">PnL %</th>
              <th style="padding:6px 8px;">PnL $</th>
              <th style="padding:6px 8px;">Exit Reason</th>
              <th style="padding:6px 8px;">Closed</th>
            </tr>
          </thead>
          <tbody>
            ${positions.map(p => {
              const pnlClass = (p.paper_pnl_pct || 0) >= 0 ? '#2ecc71' : '#e74c3c';
              const pnlSign = (p.paper_pnl_pct || 0) >= 0 ? '+' : '';
              const exitAt = p.exit_at ? new Date(p.exit_at).toLocaleString() : '—';
              const reason = p.exit_reason || '—';
              const reasonColor = reason.startsWith('tp') ? '#2ecc71' : reason.startsWith('sl') ? '#e74c3c' : '#aaa';
              return `<tr style="border-bottom:1px solid #1a1c28;">
                <td style="padding:6px 8px;font-weight:600;">${p.symbol || p.token_address.slice(0,8)}</td>
                <td style="padding:6px 8px;color:#888;">${p.strategy || '—'}</td>
                <td style="padding:6px 8px;font-family:monospace;">$${(p.entry_price||0).toFixed(6)}</td>
                <td style="padding:6px 8px;font-family:monospace;">$${(p.exit_price||0).toFixed(6)}</td>
                <td style="padding:6px 8px;font-weight:700;color:${pnlClass};">${pnlSign}${(p.paper_pnl_pct||0).toFixed(2)}%</td>
                <td style="padding:6px 8px;font-weight:700;color:${pnlClass};">${pnlSign}$${Math.abs(p.paper_pnl_usd||0).toFixed(3)}</td>
                <td style="padding:6px 8px;color:${reasonColor};font-size:11px;">${reason}</td>
                <td style="padding:6px 8px;color:#666;font-size:11px;">${exitAt}</td>
              </tr>`;
            }).join('')}
          </tbody>
        </table>`;
    } else {
        // --- Картки відкритих/watching позицій ---
        const isClosed = positions.length > 0 && positions[0].status === 'paper_closed';
        container.innerHTML = positions.map(p => {
            const pnlPct = p.paper_pnl_pct || 0;
            const pnlUsd = p.paper_pnl_usd != null ? p.paper_pnl_usd.toFixed(2) : '—';
            const pnlClass = pnlPct >= 0 ? 'pnl-positive' : 'pnl-negative';
            const pnlSign = pnlPct >= 0 ? '+' : '';
            const strategyLabel = { farm: '🌾 farm', smart_wallet: '💼 smart_wallet', survival: '🛡 survival' }[p.strategy] || `❓ ${p.strategy||'unknown'}`;
            const slVal = p.stop_loss_pct != null ? p.stop_loss_pct.toFixed(2)+'%' : 'null%';
            const tpVal = p.take_profit_pct != null ? '+'+p.take_profit_pct.toFixed(2)+'%' : '+null%';
            const abcLabel = p.abc_wave ? `ABC: ${p.abc_wave}${p.abc_confidence ? ' ('+Math.round(p.abc_confidence*100)+'%)' : ''}` : 'ABC: —';
            const exitReasonLabel = p.exit_reason || 'paper_closed';
            const durLabel = p.duration_minutes != null ? p.duration_minutes+'хв' : '—';
            const fmtTime = iso => iso ? iso.replace('T',' ').slice(0,16) : '—';
            const openTime = fmtTime(p.entry_at);
            const closeTime = fmtTime(p.exit_at);
            const entryP = p.entry_price != null ? '$'+p.entry_price.toFixed(8) : '—';
            const exitP  = p.exit_price  != null ? '$'+p.exit_price.toFixed(8)  : '—';
            const curP   = p.current_price != null ? '$'+p.current_price.toFixed(8) : exitP;

            if (isClosed) {
                return `
                <div class="position-card" style="border-left:3px solid ${pnlPct>=0?'#2ecc71':'#e74c3c'};">
                  <div class="position-header">
                    <span class="token-symbol">${p.symbol || p.token_address.slice(0,8)}</span>
                    <span class="strategy-badge" style="background:${p.strategy==='farm'?'#8e44ad':p.strategy==='smart_wallet'?'#2980b9':'#555'};color:#fff;padding:2px 7px;border-radius:4px;font-size:11px;">${strategyLabel}</span>
                    <span class="${pnlClass} pnl-badge" style="font-size:15px;font-weight:700;">${pnlSign}${pnlPct.toFixed(2)}%</span>
                  </div>
                  <div class="position-details" style="margin-top:6px;display:grid;grid-template-columns:1fr 1fr;gap:3px 12px;font-size:12px;color:#ccc;">
                    <span>📥 Вхід: ${entryP}</span>
                    <span>📤 Вихід: ${exitP}</span>
                    <span>🕐 Відкрито: ${openTime}</span>
                    <span>🕐 Закрито: ${closeTime}</span>
                    <span>⏱ Тривалість: ${durLabel}</span>
                    <span>💰 P&L: ${pnlSign}$${pnlUsd}</span>
                    <span>🛑 SL: ${slVal}</span>
                    <span>🎯 TP: ${tpVal}</span>
                    <span>📊 ${abcLabel}</span>
                    <span>🔚 Причина: ${exitReasonLabel}</span>
                    <span>Risk: ${(p.entry_risk_score||0).toFixed(1)}</span>
                    <span>Cont: ${((p.entry_continuation_score||0)*100).toFixed(0)}%</span>
                  </div>
                  <div class="position-actions" style="margin-top:6px;text-align:right;">
                    <button onclick="closePosition('${p.token_address}','${p.symbol||p.token_address.slice(0,8)}')"
                      style="background:#c0392b;color:#fff;border:none;border-radius:4px;padding:3px 10px;cursor:pointer;font-size:11px;">✕ Close</button>
                  </div>
                </div>`;
            } else {
                return `
                <div class="position-card">
                    <div class="position-header">
                        <span class="token-symbol">${p.symbol || p.token_address.slice(0,8)}</span>
                        <span class="strategy-badge" style="background:${p.strategy==='farm'?'#8e44ad':p.strategy==='smart_wallet'?'#2980b9':'#555'};color:#fff;padding:2px 7px;border-radius:4px;font-size:11px;">${strategyLabel}</span>
                        <span class="${pnlClass} pnl-badge">${pnlSign}${pnlPct.toFixed(1)}%</span>
                    </div>
                    <div class="position-details">
                        <span>Entry: ${entryP}</span>
                        <span>Current: ${curP}</span>
                        <span>SL: ${slVal}</span>
                        <span>TP: ${tpVal}</span>
                    </div>
                    <div class="position-scores">
                        <span>Cont: ${((p.entry_continuation_score||0)*100).toFixed(0)}%</span>
                        <span>Risk: ${(p.entry_risk_score||0).toFixed(1)}</span>
                        <span>${p.status}</span>
                    </div>
                    <div class="position-actions" style="margin-top:8px;text-align:right;">
                        <button onclick="closePosition('${p.token_address}','${p.symbol||p.token_address.slice(0,8)}')"
                          style="background:#c0392b;color:#fff;border:none;border-radius:4px;padding:4px 12px;cursor:pointer;font-size:12px;">✕ Close</button>
                    </div>
                </div>`;
            }
        }).join('');
    }
}


async function closePosition(tokenAddress, symbol) {
    if (!confirm('Close position ' + symbol + '?')) return;
    const res = await fetch('/api/pulse/positions/' + encodeURIComponent(tokenAddress) + '/close', {
        method: 'POST',
        headers: pulseHeaders(),
    });
    const data = await res.json();
    if (res.ok) {
        alert(symbol + ' closed. PnL: ' + (data.pnl_pct >= 0 ? '+' : '') + data.pnl_pct + '%');
        loadPulsePositions();
    } else {
        alert('Error: ' + (data.detail || 'unknown'));
    }
}

async function loadPulseFeed() {
    const limit = document.getElementById('feed-limit')?.value || 50;
    const res = await fetch(`/api/pulse/feed?limit=${encodeURIComponent(limit)}`, { headers: pulseHeaders() });
    const items = await res.json();
    const container = document.getElementById('feed-container');
    if (!container) return;

    const eventIcon = {
        'approve': 'OK', 'reject': 'NO', 'review': 'RV',
        'paper_open': 'OP', 'exit_tp': 'TP', 'exit_sl': 'SL', 'exit_trailing': 'TR',
        'exit_time': 'TM', 'exit_liquidity': 'LQ'
    };

    container.innerHTML = items.map(item => {
        const icon = eventIcon[item.event_type] || '--';
        const time = new Date(item.time).toLocaleTimeString('uk-UA');
        return `
        <div class="feed-item">
            <span class="feed-time">${time}</span>
            <span class="feed-icon">${icon}</span>
            <span class="feed-event">${item.event_type?.toUpperCase()}</span>
            <span class="feed-token">${item.token_address?.slice(0, 8)}</span>
            <span class="feed-chain">${item.chain}</span>
        </div>`;
    }).join('');
}

async function loadPulseAnalytics() {
    const days = document.getElementById('analytics-days')?.value || 7;
    const res = await fetch(`/api/pulse/stats?days=${days}`, { headers: pulseHeaders() });
    const stats = await res.json();
    const container = document.getElementById('analytics-container');
    if (!container) return;

    if(res.status === 401){ container.innerHTML = '<p style="color:red">Auth error — перезавантаж сторінку</p>'; return; }
    const winRatePct = ((stats.win_rate || 0) * 100).toFixed(1);
    const pnlClass = (stats.total_pnl_usd || 0) >= 0 ? 'positive' : 'negative';
    container.innerHTML = `
    <div class="stats-grid">
        <div class="stat-card"><div class="stat-value">${stats.total_trades || 0}</div><div class="stat-label">Closed trades</div></div>
        <div class="stat-card"><div class="stat-value">${stats.open_positions || 0}</div><div class="stat-label">Open now</div></div>
        <div class="stat-card"><div class="stat-value ${stats.win_rate >= 0.5 ? 'positive' : 'negative'}">${winRatePct}%</div><div class="stat-label">Win rate</div></div>
        <div class="stat-card"><div class="stat-value positive">+${(stats.avg_win_pct || 0).toFixed(1)}%</div><div class="stat-label">Avg win</div></div>
        <div class="stat-card"><div class="stat-value negative">${(stats.avg_loss_pct || 0).toFixed(1)}%</div><div class="stat-label">Avg loss</div></div>
        <div class="stat-card"><div class="stat-value ${pnlClass}">$${(stats.total_pnl_usd || 0).toFixed(2)}</div><div class="stat-label">Closed P&L</div></div>
        <div class="stat-card"><div class="stat-value ${(stats.open_pnl_usd||0) >= 0 ? 'positive' : 'negative'}">$${(stats.open_pnl_usd || 0).toFixed(2)}</div><div class="stat-label">Open P&L</div></div>
    </div>
    <div class="strategy-breakdown">
        <h3>By strategy</h3>
        ${Object.entries(stats.by_strategy || {}).map(([name, s]) => `
        <div class="strategy-row">
            <span>${name}</span>
            <span>${s.trades} trades</span>
            <span>${((s.win_rate || 0) * 100).toFixed(0)}% win</span>
            <span>${(s.avg_pnl || 0).toFixed(1)}% avg P&L</span>
        </div>`).join('')}
    </div>`;
}

setInterval(loadPulsePositions, 10_000);
setInterval(loadPulseFeed, 15_000);
