from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from pydantic import Field, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

_ENV_FILE = str(Path(__file__).resolve().parent.parent.parent / '.env')


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=_ENV_FILE, env_file_encoding='utf-8', extra='ignore')

    @model_validator(mode='after')
    def _normalize_database_url(self):
        db = str(self.database_url or '').strip()
        if db.startswith('sqlite') and '///./' in db:
            rel = db.split('///./', 1)[1]
            base = Path(__file__).resolve().parent.parent.parent
            abs_path = (base / rel).resolve()
            self.database_url = f'sqlite+aiosqlite:///{abs_path.as_posix()}'
        return self


    app_name: str = 'cryptoparser'
    env: str = 'dev'
    log_level: str = 'INFO'

    database_url: str = 'sqlite+aiosqlite:///./cryptoparser.db'
    redis_url: str = 'redis://localhost:6379/0'
    use_redis_queue: bool = False
    use_redis_cache: bool = False
    redis_cache_prefix: str = 'cryptoparser:cache'
    cache_ttl_seconds: int = 600
    cache_max_entries: int = 4096
    queue_name_ingest: str = 'cryptoparser:ingest'
    queue_name_ingest_fast: str = 'cryptoparser:ingest:fast'
    queue_name_review: str = 'cryptoparser:review'

    dexscreener_base_url: str = 'https://api.dexscreener.com'
    birdeye_base_url: str = 'https://public-api.birdeye.so'
    birdeye_api_key: str | None = None
    goplus_base_url: str = 'https://api.gopluslabs.io'
    goplus_access_token: str | None = None
    honeypot_base_url: str = 'https://api.honeypot.is'
    etherscan_base_url: str = 'https://api.etherscan.io'
    etherscan_api_key: str | None = None

    ethereum_rpc_url: str | None = None
    base_rpc_url: str | None = None
    bsc_rpc_url: str | None = None
    solana_rpc_url: str | None = None
    ethereum_rpc_urls: list[str] = Field(default_factory=list)
    base_rpc_urls: list[str] = Field(default_factory=list)
    bsc_rpc_urls: list[str] = Field(default_factory=list)
    solana_rpc_urls: list[str] = Field(default_factory=list)

    telegram_bot_token: str | None = None
    telegram_chat_id: str | None = None

    request_timeout_seconds: int = 20
    poll_interval_seconds: int = 120
    pumpfun_poll_interval_seconds: int = 20
    pumpfun_request_timeout_seconds: int = 12
    cooldown_minutes: int = 30
    max_concurrent_requests: int = 12

    enable_pumpfun_intake: bool = True
    pumpfun_base_url: str = 'https://pump.fun'
    pumpswap_base_url: str = 'https://swap.pump.fun'
    pumpfun_feed_paths: list[str] = Field(default_factory=lambda: ['/live', '/new'])
    pumpfun_max_candidates_per_cycle: int = 80
    pumpfun_coin_metadata_limit: int = 12
    pumpfun_dedup_ttl_seconds: int = 900

    pump_early_grace_minutes: int = 720
    pump_early_approve_score: float = 82.0
    pump_early_review_score: float = 40.0
    pump_early_max_top10_holder_pct: float = 60.0
    pump_early_review_queue_min_liquidity: float = 1000.0
    # pump_graduated — pump.fun токени що вийшли з grace-вікна (graduated bonding curve)
    pump_graduated_approve_score: float = 55.0
    pump_graduated_review_score: float = 30.0
    pump_graduated_min_liquidity: float = 20_000.0
    pump_graduated_min_holders: int = 50
    pump_graduated_max_top10_holder_pct: float = 40.0
    # Graduated intake — параметри DexScreener пошуку
    enable_graduated_intake: bool = True
    graduated_poll_interval_seconds: int = 120   # базовий інтервал
    enable_graduated_early_catch: bool = True
    graduated_early_catch_poll_interval_seconds: int = 45
    graduated_job_timeout_seconds: int = 180
    graduated_min_liquidity: float = 15_000.0    # pre-фільтр до pipeline
    graduated_min_volume_24h: float = 10_000.0
    graduated_min_txns_24h: int = 100
    graduated_min_age_hours: float = 2.0         # вижив 2+ год на Raydium
    graduated_max_candidates: int = 80
    graduated_dedup_ttl_seconds: int = 3600      # дедуп 1 год
    graduated_backfill_batch_size: int = 60
    graduated_backfill_cursor_ttl_seconds: int = 21_600
    enable_graduated_strong_alerts: bool = True
    graduated_strong_alert_ttl_seconds: int = 43_200
    enable_graduated_top_telegram_alerts: bool = True
    graduated_top_telegram_count: int = 7
    graduated_top_telegram_ttl_seconds: int = 900
    pump_graduated_max_launch_age_hours: float = 48.0  # 2 дні — оптимально для мем ABC структур
    pump_graduated_main_allowed_dex: list[str] = Field(default_factory=lambda: ['raydium'])
    pump_graduated_pumpswap_allowed_dex: list[str] = Field(default_factory=lambda: ['pumpswap'])
    pump_graduated_quality_mode: bool = True
    pump_graduated_quality_require_non_reject: bool = True
    pump_graduated_quality_require_valid_social: bool = True
    pump_graduated_quality_lock_rejects: bool = True
    pump_graduated_require_holders_refresh_for_approve: bool = True
    pump_graduated_quality_min_score: float = 60.0
    pump_graduated_quality_min_liquidity: float = 15_000.0
    pump_graduated_quality_min_volume_24h: float = 50_000.0
    pump_graduated_quality_min_txns_24h: int = 1_000
    pump_graduated_quality_holders_fallback_txns: int = 1_000
    pump_graduated_min_holders_by_chain: dict[str, int] = Field(
        default_factory=lambda: {'solana': 50, 'bsc': 60, 'base': 60}
    )
    pump_graduated_quality_min_liquidity_by_chain: dict[str, float] = Field(
        default_factory=lambda: {'solana': 15_000.0, 'bsc': 15_000.0, 'base': 15_000.0}
    )
    pump_graduated_quality_min_volume_24h_by_chain: dict[str, float] = Field(
        default_factory=lambda: {'solana': 50_000.0, 'bsc': 50_000.0, 'base': 50_000.0}
    )
    pump_graduated_quality_min_txns_24h_by_chain: dict[str, int] = Field(
        default_factory=lambda: {'solana': 1_000, 'bsc': 1_000, 'base': 1_000}
    )
    pump_graduated_quality_holders_fallback_txns_by_chain: dict[str, int] = Field(
        default_factory=lambda: {'solana': 1_000, 'bsc': 1_000, 'base': 1_000}
    )
    pump_graduated_multichain_enabled: bool = True
    pump_graduated_multichain_chains: list[str] = Field(default_factory=lambda: ['bsc', 'base'])
    pump_graduated_multichain_allowed_dex: dict[str, list[str]] = Field(
        default_factory=lambda: {
            'bsc': ['pancakeswap', 'fourmeme'],
            'base': ['uniswap', 'aerodrome'],
        }
    )
    enable_pump_graduated_evm_fast_lane: bool = True
    pump_graduated_evm_fast_lane_queries: dict[str, list[str]] = Field(
        default_factory=lambda: {
            'bsc': ['pancakeswap', 'fourmeme'],
            'base': ['uniswap', 'aerodrome'],
        }
    )
    pump_graduated_evm_fast_lane_max_pairs_per_query: int = 120
    pump_graduated_evm_fast_lane_max_candidates: int = 120
    pump_graduated_evm_fast_lane_dedup_ttl_seconds: int = 900
    pump_graduated_quality_block_reasons: list[str] = Field(
        default_factory=lambda: [
            'missing_security_data',
            'mint_authority_exists',
            'freeze_authority_exists',
            'creator_wallet_malicious',
            'deployer_reputation_too_low',
            'scam_contract_similarity',
            'malicious_wallet_cluster',
            'wash_trading_detected',
            'missing_website',
            'website_not_reachable',
            'website_not_https',
            'website_missing_contract',
            'website_missing_x',
            'website_missing_telegram',
            'x_not_found',
            'x_missing_contract_mention',
            'low_holders',
            'holder_concentration',
            'bundled_buy_detected',
            'holders_refresh_required',
            'holders_refresh_below_min',
            'website_x_brand_mismatch',
            'website_telegram_brand_mismatch',
            'contract_not_verified',
            'honeypot_or_unknown',
            'cannot_sell_or_unknown',
            'proxy_contract',
            'mint_enabled',
            'blacklist_function_present',
            'owner_can_change_fee',
            'owner_can_block_wallets',
            'lp_not_locked_180d',
        ]
    )
    pump_graduated_quality_block_reason_prefixes: list[str] = Field(
        default_factory=lambda: [
            'bot_signal:',
            'cross_chain_match_risk:',
        ]
    )

    min_liquidity_usd: float = 50_000
    pulse_min_market_cap_usd: float = 20_000.0
    min_holders_evm: int = 150
    min_holders_solana: int = 200

    # ── Окремі пороги по джерелах (0 = використовувати загальний поріг) ────
    dexscreener_min_liquidity: float = 0
    dexscreener_min_holders: int = 0
    birdeye_min_liquidity: float = 0
    birdeye_min_holders: int = 0
    coingecko_min_liquidity: float = 100_000
    coingecko_min_holders: int = 300
    coinmarketcap_min_liquidity: float = 100_000
    coinmarketcap_min_holders: int = 300
    max_tax_pct: float = 0.0  # Non-zero buy/sell tax is rejected
    min_x_age_days: int = 60
    min_x_followers: int = 1000
    min_x_tweets: int = 30
    min_domain_age_days: int = 30

    approve_score: float = 78.0
    review_score: float = 62.0

    enable_birdeye: bool = True
    birdeye_new_listing_limit: int = 100

    # ── CoinGecko / CoinMarketCap ─────────────────────────────────────────
    cmc_api_key: str = Field(default='')
    enable_coingecko: bool = True
    enable_coinmarketcap: bool = True

    # ── GEM Predictor tier thresholds (регулюються через .env) ────────────
    gem_hot_threshold: float = 72.0
    gem_watch_threshold: float = 58.0
    gem_scout_threshold: float = 44.0
    cmc_api_key: str = Field(default='')
    enable_coingecko: bool = True
    enable_coinmarketcap: bool = True
    enable_goplus: bool = True
    enable_honeypot: bool = True
    enable_telegram: bool = False
    enable_playwright_fallback: bool = True
    enable_admin_api: bool = True
    dry_run: bool = True

    nitter_instances: list[str] = Field(
        default_factory=lambda: [
            'https://nitter.net',
            'https://nitter.privacydev.net',
        ]
    )
    domain_age_api_base: str = 'https://rdap.org/domain/'
    http_user_agent: str = Field(default='Mozilla/5.0 (compatible; CryptoParser/3.0; +https://example.local)')

    worker_batch_size: int = 20
    worker_sleep_seconds: float = 1.5
    max_retry_attempts: int = 4
    base_retry_delay_seconds: float = 2.0

    admin_api_host: str = '0.0.0.0'
    admin_api_port: int = 8080
    admin_api_token: str = 'change-me'
    provider_cooldown_seconds: int = 30

    provider_default_quota_per_minute: int = 120
    provider_lock_ttl_seconds: int = 30
    provider_wait_timeout_seconds: int = 5
    nitter_provider_weights: dict[str, float] = Field(default_factory=dict)
    nitter_provider_quotas: dict[str, int] = Field(default_factory=dict)
    evm_provider_weights: dict[str, float] = Field(default_factory=dict)
    evm_provider_quotas: dict[str, int] = Field(default_factory=dict)
    solana_provider_weights: dict[str, float] = Field(default_factory=dict)
    solana_provider_quotas: dict[str, int] = Field(default_factory=dict)

    metrics_namespace: str = 'cryptoparser'

    enable_public_metrics: bool = True
    sentry_dsn: str | None = None
    sentry_traces_sample_rate: float = 0.05
    enable_tracing: bool = False
    otlp_endpoint: str | None = None
    otel_service_name: str = 'cryptoparser'

    worker_coordination_enabled: bool = True
    worker_heartbeat_ttl_seconds: int = 45
    worker_heartbeat_interval_seconds: int = 15
    poller_leader_key: str = 'cryptoparser:leader:poller'
    graph_job_leader_key: str = 'cryptoparser:leader:graph-jobs'
    processing_lock_ttl_seconds: int = 180

    graph_job_interval_seconds: int = 300
    graph_max_depth: int = 3

    # Outcome tracker: перевіряє долю APPROVE-рішень через 2–14 днів
    # Запускається раз на 12 годин — немає сенсу частіше (вікно 2 дні)
    outcome_tracker_interval_seconds: int = 43200  # 12h

    # Threshold calibrator: перераховує оптимальні пороги approve/review
    # Запускається раз на добу — потрібен накопичений масив лейблів
    threshold_calibrator_interval_seconds: int = 86400  # 24h

    # Price monitor: стежить за ліквідністю APPROVE токенів, шле dump/pump алерти
    price_monitor_interval_seconds: int = 300  # 5min

    enable_ml_risk: bool = True
    ml_weights_path: str | None = 'config/ml_weights.json'
    ml_blend_ratio: float = 0.35
    enable_historical_intelligence: bool = True
    enable_realtime_alerts: bool = True
    graph_score_depth: int = 3
    graph_edge_weight_threshold: float = 0.2

    enable_scheduler: bool = True
    scheduler_tick_seconds: int = 10
    ops_alerts_enabled: bool = True
    frontend_enabled: bool = True
    provider_budget_group_quotas: dict[str, int] = Field(default_factory=lambda: {'nitter': 120, 'evm_rpc': 300, 'solana_rpc': 300, 'etherscan': 180})

    # ── Unified admin UI defaults (single source of truth for Tokens/Listings) ──
    admin_default_chain: str = 'all'
    admin_default_status: str = 'all'
    admin_default_min_liquidity: float = 25000
    admin_default_min_holders: int = 120
    admin_default_min_score: float = 70
    admin_default_gem_enabled: bool = True
    admin_default_min_gem: float = 22
    admin_default_gem_tier: str = 'all'
    admin_default_limit: int = 100
    admin_default_tokens_stage: str = 'all'
    admin_default_tokens_projected_x: str = 'all'
    admin_default_listings_source: str = 'all'

    # Paper Trading
    paper_trading_enabled: bool = True
    paper_trading_position_size_usd: float = 100.0
    paper_risk_tier_a_min_score: float = 75.0
    paper_risk_tier_b_min_score: float = 65.0
    paper_risk_tier_b_max_soft_reasons: int = 1
    paper_risk_tier_b_size_multiplier: float = 0.5
    paper_risk_tier_c_size_multiplier: float = 0.25
    paper_hard_block_unknown_holders: bool = True
    paper_trading_tick_seconds: int = 2
    paper_trading_max_open_positions: int = 10
    paper_trading_max_position_usd: float = 50.0
    daily_loss_limit_usd: float = 500.0
    max_positions_per_chain: int = 6
    # approve_watcher — підхоплює старі APPROVE з БД в watching
    approve_watcher_lookback_hours: float = 48.0   # скільки годин назад шукати APPROVE
    approve_watcher_max_per_cycle: int = 20         # макс нових watching за 1 цикл
    approve_watcher_min_score: float = 72.0         # мін score для підхоплення
    paper_simulate_slippage: bool = True
    paper_slippage_entry_pct: float = 2.5
    paper_slippage_exit_pct: float = 2.5
    paper_dynamic_slippage_min_pct: float = 0.3
    paper_dynamic_slippage_max_pct: float = 3.0
    paper_max_order_impact_pct: float = 0.01
    paper_order_split_enabled: bool = True
    paper_order_max_splits: int = 4
    paper_partial_fill_min_pct: float = 0.65
    paper_partial_fill_max_pct: float = 1.0
    paper_price_deviation_abort_pct: float = 1.5
    paper_max_entry_volatility_pct: float = 12.0
    paper_profit_ladder_1_pct: float = 3.0
    paper_profit_ladder_2_pct: float = 6.0
    paper_profit_ladder_fraction: float = 0.30
    paper_profit_lock_win_streak: int = 3
    paper_profit_lock_min_score: float = 85.0
    paper_profit_lock_min_continuation_score: float = 0.60
    paper_profit_lock_high_quality_multiplier: float = 1.25
    paper_profit_lock_low_quality_multiplier: float = 0.75
    paper_min_momentum_score: float = 0.35
    paper_min_ml_score: float = 0.60
    paper_ml_size_floor: float = 0.80
    paper_ml_size_ceiling: float = 1.30
    paper_min_wallet_reputation_score: float = 35.0
    paper_min_mtf_momentum_score: float = 0.45
    paper_break_even_activate_pct: float = 6.0
    paper_break_even_lock_pct: float = 2.0
    paper_max_consecutive_losses: int = 4
    paper_loss_streak_cooldown_minutes: int = 15
    paper_spread_min_pct: float = 0.2
    paper_spread_max_pct: float = 1.0
    paper_entry_delay_min_ticks: int = 1
    paper_entry_delay_max_ticks: int = 2
    paper_gas_fee_usd: float = 0.35
    paper_fail_rate: float = 0.05
    paper_latency_min_seconds: float = 2.0
    paper_latency_max_seconds: float = 6.0
    paper_latency_drift_per_second_pct: float = 0.015
    paper_partial_tp_pct: float = 30.0
    paper_partial_tp_fraction: float = 0.5
    paper_min_liquidity_exit_usd: float = 25_000.0
    paper_stagnation_exit_minutes: int = 60
    paper_stagnation_min_pnl_pct: float = 5.0
    paper_reentry_enabled: bool = True
    paper_reentry_cooldown_minutes: int = 30  # чекати 30 хв між повторними входами
    paper_reentry_max_count: int = 5          # до 5 повторних входів на токен
    paper_reentry_min_continuation_score: float = 0.45
    paper_reentry_min_liquidity_usd: float = 25_000.0
    track_near_misses: bool = True
    near_miss_threshold_pct: float = 50.0
    near_miss_watch_hours: float = 2.0
    pulse_price_batch_enabled: bool = True
    pulse_health_enabled: bool = True
    pulse_health_check_interval_seconds: int = 60
    pulse_health_stale_new_token_minutes: int = 30
    # Watchlist snapshots for MFV pre-accumulation
    watchlist_poll_interval_seconds: int = 30
    watchlist_max_tokens_per_tick: int = 40
    pulse_health_stale_tick_minutes: int = 5
    pulse_health_dex_error_threshold: int = 10
    pulse_health_execution_failure_threshold: int = 5
    pulse_volume_min_ratio: float = 0.5
    pulse_volume_momentum_bonus: float = 0.10
    pulse_volume_accumulation_bonus: float = 0.06
    pulse_dev_wallet_monitor_enabled: bool = True
    pulse_dev_wallet_sell_alert_ttl_seconds: int = 900
    backtest_lookback_days: int = 30
    backtest_default_sl_pct: float = 8.0
    backtest_default_tp_pct: float = 20.0
    backtest_default_trailing_pct: float = 15.0
    backtest_partial_tp_pct: float = 30.0
    backtest_partial_tp_fraction: float = 0.5

    # Live-ready execution controls (disabled by default)
    live_trading_enabled: bool = False
    live_trading_dry_run: bool = True
    live_wallet_address: str = ''
    live_max_open_positions: int = 2
    live_max_total_exposure_usd: float = 500.0
    live_max_position_usd: float = 100.0
    live_trade_lot_sol: float = 0.01
    live_kill_switch_enabled: bool = False
    live_recovery_enabled: bool = True
    live_recovery_stale_minutes: int = 5
    live_state_transition_ttl_seconds: int = 300
    live_entry_timing_window_min_minutes: float = 1.0
    live_entry_timing_window_max_minutes: float = 480.0
    fzr_trade_ready_override_enabled: bool = True
    fzr_trade_ready_override_min_rr_paper: float = 2.0
    fzr_trade_ready_override_min_confidence_paper: float = 0.65
    fzr_trade_ready_override_min_liquidity_usd_paper: float = 50_000.0
    fzr_trade_ready_override_size_multiplier_paper: float = 0.5
    fzr_trade_ready_override_min_rr_live: float = 2.0
    fzr_trade_ready_override_min_confidence_live: float = 0.70
    fzr_trade_ready_override_min_liquidity_usd_live: float = 40_000.0
    fzr_trade_ready_override_size_multiplier_live: float = 0.35

    # Pulse Decision Engine thresholds & weights (previously missing from Settings — read via os.getenv only)
    pulse_threshold_approve: float = 0.62
    pulse_threshold_trade_ready: float = 0.60
    pulse_threshold_review: float = 0.45
    pulse_threshold_farm_approve: float = 0.55
    pulse_min_score_to_trade: float = 68.0
    pulse_trade_pump_early: bool = True
    paper_blacklist_deployers: str = ''
    paper_blacklist_token_families: str = ''
    paper_blacklist_patterns: str = ''
    paper_blacklist_similarity_threshold: float = 0.86
    pulse_w_risk: float = 0.40
    pulse_w_continuation: float = 0.35
    pulse_w_wallet: float = 0.15
    pulse_w_bundle: float = 0.10

    # Pulse Brain thresholds
    pulse_brain_min_continuation_score: float = 0.45
    pulse_farm_min_continuation_score: float = 0.40
    pulse_survival_min_continuation_score: float = 0.55
    pulse_survival_stop_loss_pct: float = -6.0
    pulse_survival_take_profit_pct: float = 8.0
    pulse_smart_wallet_stop_loss_pct: float = -15.0
    pulse_smart_wallet_take_profit_pct: float = 40.0

    # Masterforex-V pattern layer (2s ticks -> 5m/1m/30s/2s)
    abc_enabled: bool = True
    abc_min_confidence: float = 0.60
    abc_min_rr: float = 2.0
    abc_min_swing_pct: float = 0.05
    abc_min_a_size_pct: float = 0.08
    abc_max_a_size_pct: float = 0.40
    abc_min_b_retrace: float = 0.382
    abc_max_b_retrace: float = 0.764
    abc_min_impulse_pct: float = 0.30
    abc_min_dump_pct: float = 0.05
    abc_c_fib_tolerance: float = 0.08
    abc_stop_loss_buffer_pct: float = 0.02
    abc_candle_seconds: int = 60
    abc_signal_candle_seconds: int = 30
    abc_entry_candle_seconds: int = 10
    abc_min_ticks_for_analysis: int = 30
    abc_snapshot_lookback_minutes: int = 480
    abc_snapshot_limit: int = 1200
    mfv_confirmation_enabled: bool = True
    mfv_confirmation_min_score_survival: float = 0.62
    mfv_confirmation_min_score_smart_wallet: float = 0.56
    mfv_confirmation_min_score_farm: float = 0.58
    mfv_confirmation_hard_floor: float = 0.35

    # Farm Mode
    farm_mode_enabled: bool = True
    farm_mode_tick_seconds: int = 30
    farm_mode_paper_usd: float = 20.0
    farm_mode_stop_loss: float = -0.20
    farm_mode_take_profit: float = 2.0
    farm_mode_trailing_activate: float = 0.05
    farm_mode_trailing_distance: float = 0.20
    farm_mode_time_limit_minutes: int = 120
    # Ланцюги для paper trade (BSC виключено через слабкі security checks)
    paper_allowed_chains: str = 'solana,base'  # comma-separated
    farm_mode_min_risk_score: float = 55.0
    farm_mode_min_farm_score: float = 0.45

    def thresholds_for_source(self, source: str) -> tuple[float, int, int]:
        """Повертає (min_liquidity, min_holders_evm, min_holders_solana) для джерела."""
        src = (source or 'dexscreener').lower()
        liq_field     = f'{src}_min_liquidity'
        holders_field = f'{src}_min_holders'
        liq     = getattr(self, liq_field,     0) or self.min_liquidity_usd
        holders = getattr(self, holders_field, 0) or self.min_holders_evm
        sol_holders = getattr(self, holders_field, 0) or self.min_holders_solana
        return liq, holders, sol_holders

    def rpc_urls_for_chain(self, chain: str) -> list[str]:
        mapping = {
            'ethereum': list(self.ethereum_rpc_urls),
            'base': list(self.base_rpc_urls),
            'bsc': list(self.bsc_rpc_urls),
            'solana': list(self.solana_rpc_urls),
        }
        legacy = {
            'ethereum': self.ethereum_rpc_url,
            'base': self.base_rpc_url,
            'bsc': self.bsc_rpc_url,
            'solana': self.solana_rpc_url,
        }
        values = [v for v in mapping.get(chain, []) if v]
        if legacy.get(chain):
            values.append(legacy[chain])
        seen: set[str] = set()
        return [v for v in values if not (v in seen or seen.add(v))]


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
