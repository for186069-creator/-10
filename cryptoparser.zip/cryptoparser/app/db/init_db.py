from __future__ import annotations

from sqlalchemy import inspect, select

from app.db.base import Base, engine
from app.db import models  # noqa: F401
from app.db.base import AsyncSessionLocal
from app.db.models import PaperTradeRecord, TokenCandidateRecord, TokenLifecycleRecord
from app.utils.token_classifier import classify_decision_profile, classify_token_family


async def init_db() -> None:
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
        await conn.run_sync(_sync_token_candidates_schema)
    await _backfill_token_candidate_classification()
    await _backfill_paper_trade_history()


def _sync_token_candidates_schema(conn) -> None:
    inspector = inspect(conn)
    tables = set(inspector.get_table_names())
    if 'token_candidates' not in tables:
        return

    columns = {col['name'] for col in inspector.get_columns('token_candidates')}
    statements = []
    if 'token_family' not in columns:
        statements.append('ALTER TABLE token_candidates ADD COLUMN token_family VARCHAR(64)')
    if 'launchpad' not in columns:
        statements.append('ALTER TABLE token_candidates ADD COLUMN launchpad VARCHAR(64)')
    if 'lifecycle_stage' not in columns:
        statements.append('ALTER TABLE token_candidates ADD COLUMN lifecycle_stage VARCHAR(64)')
    if 'graduated_confirmed' not in columns:
        statements.append('ALTER TABLE token_candidates ADD COLUMN graduated_confirmed BOOLEAN DEFAULT 0 NOT NULL')

    for statement in statements:
        conn.exec_driver_sql(statement)

    indexes = {idx['name'] for idx in inspector.get_indexes('token_candidates')}
    if 'ix_token_candidates_token_family' not in indexes:
        conn.exec_driver_sql('CREATE INDEX IF NOT EXISTS ix_token_candidates_token_family ON token_candidates (token_family)')
    if 'ix_token_candidates_launchpad' not in indexes:
        conn.exec_driver_sql('CREATE INDEX IF NOT EXISTS ix_token_candidates_launchpad ON token_candidates (launchpad)')
    if 'ix_token_candidates_lifecycle_stage' not in indexes:
        conn.exec_driver_sql('CREATE INDEX IF NOT EXISTS ix_token_candidates_lifecycle_stage ON token_candidates (lifecycle_stage)')
    if 'ix_token_candidates_graduated_confirmed' not in indexes:
        conn.exec_driver_sql('CREATE INDEX IF NOT EXISTS ix_token_candidates_graduated_confirmed ON token_candidates (graduated_confirmed)')


async def _backfill_token_candidate_classification() -> None:
    async with AsyncSessionLocal() as session:
        rows = list((await session.execute(select(TokenCandidateRecord))).scalars().all())
        changed = False
        for row in rows:
            raw = dict(row.raw or {})
            family = classify_token_family(row.chain, row.token_address, raw)
            profile = classify_decision_profile(row.chain, row.token_address, raw, row.first_seen_at)

            token_family = str(raw.get('token_family') or family.get('token_family') or 'standard')
            launchpad = raw.get('launchpad') or family.get('launchpad')
            lifecycle_stage = raw.get('lifecycle_stage')
            if not lifecycle_stage:
                dp = str(profile.get('decision_profile') or 'standard')
                lifecycle_stage = 'graduated' if dp == 'pump_graduated' else 'early' if dp == 'pump_early' else 'standard'
            graduated_confirmed = bool(raw.get('graduated_confirmed') or profile.get('graduated_confirmed'))

            if row.token_family != token_family:
                row.token_family = token_family
                changed = True
            if row.launchpad != launchpad:
                row.launchpad = launchpad
                changed = True
            if row.lifecycle_stage != lifecycle_stage:
                row.lifecycle_stage = lifecycle_stage
                changed = True
            if bool(row.graduated_confirmed) != graduated_confirmed:
                row.graduated_confirmed = graduated_confirmed
                changed = True

        if changed:
            await session.commit()


def _paper_trade_key(row: TokenLifecycleRecord) -> str | None:
    if row.entry_at is None or row.exit_at is None:
        return None
    return f'{row.chain}:{row.token_address}:{row.entry_at.isoformat()}:{row.exit_at.isoformat()}'


async def _backfill_paper_trade_history() -> None:
    async with AsyncSessionLocal() as session:
        existing_keys = {
            key for key in (await session.execute(select(PaperTradeRecord.trade_key))).scalars().all() if key
        }
        closed_rows = list(
            (
                await session.execute(
                    select(TokenLifecycleRecord).where(
                        TokenLifecycleRecord.status == 'paper_closed',
                        TokenLifecycleRecord.entry_at.isnot(None),
                        TokenLifecycleRecord.exit_at.isnot(None),
                    )
                )
            ).scalars().all()
        )
        changed = False
        for row in closed_rows:
            trade_key = _paper_trade_key(row)
            if not trade_key or trade_key in existing_keys:
                continue
            session.add(
                PaperTradeRecord(
                    trade_key=trade_key,
                    chain=row.chain,
                    token_address=row.token_address,
                    symbol=row.symbol,
                    strategy=row.strategy,
                    status='paper_closed',
                    entry_price=row.entry_price,
                    entry_execution_price=row.entry_execution_price,
                    exit_price=row.exit_price,
                    raw_exit_price=row.raw_exit_price,
                    requested_size_usd=row.requested_size_usd,
                    filled_size_usd=row.filled_size_usd,
                    fill_pct=row.fill_pct,
                    paper_size_usd=float(row.paper_size_usd or 0.0),
                    execution_fees_usd=float(row.execution_fees_usd or 0.0),
                    realized_pnl_usd=float(row.realized_pnl_usd or 0.0),
                    paper_pnl_usd=float(row.paper_pnl_usd or 0.0),
                    paper_pnl_pct=float(row.paper_pnl_pct or 0.0),
                    entry_delay_seconds=row.entry_delay_seconds,
                    entry_latency_seconds=row.entry_latency_seconds,
                    exit_latency_seconds=row.exit_latency_seconds,
                    graduated_at=row.graduated_at,
                    entry_continuation_score=row.entry_continuation_score,
                    entry_risk_score=row.entry_risk_score,
                    token_family=row.token_family,
                    exit_reason=row.exit_reason,
                    execution_state=row.execution_state,
                    pair_address=row.pair_address,
                    entry_signals=row.entry_signals,
                    exit_signals=row.exit_signals,
                    execution_metadata=row.execution_metadata,
                    lifecycle_id=row.id,
                    entry_at=row.entry_at,
                    exit_at=row.exit_at,
                )
            )
            existing_keys.add(trade_key)
            changed = True
        if changed:
            await session.commit()
