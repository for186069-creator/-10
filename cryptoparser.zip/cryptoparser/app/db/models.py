from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import JSON, Boolean, DateTime, Float, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base


class TokenCandidateRecord(Base):
    __tablename__ = 'token_candidates'
    __table_args__ = (UniqueConstraint('chain', 'token_address', name='uq_chain_token'),)

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    chain: Mapped[str] = mapped_column(String(24), index=True)
    token_address: Mapped[str] = mapped_column(String(128), index=True)
    pair_address: Mapped[str | None] = mapped_column(String(128), nullable=True)
    symbol: Mapped[str | None] = mapped_column(String(64), nullable=True)
    name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    deployer_address: Mapped[str | None] = mapped_column(String(128), nullable=True)
    first_seen_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    liquidity_usd: Mapped[float | None] = mapped_column(Float, nullable=True)
    holders: Mapped[int | None] = mapped_column(Integer, nullable=True)
    website: Mapped[str | None] = mapped_column(String(512), nullable=True)
    x_handle: Mapped[str | None] = mapped_column(String(128), nullable=True)
    telegram_url: Mapped[str | None] = mapped_column(String(512), nullable=True)
    token_family: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
    launchpad: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
    lifecycle_stage: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
    graduated_confirmed: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    # FIX BUG 2: persist tax fields from GoPlus / Honeypot.is
    taxes_buy_pct: Mapped[float | None] = mapped_column(Float, nullable=True)
    taxes_sell_pct: Mapped[float | None] = mapped_column(Float, nullable=True)
    raw: Mapped[dict] = mapped_column(JSON, default=dict)


class TokenDecisionRecord(Base):
    __tablename__ = 'token_decisions'
    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    chain: Mapped[str] = mapped_column(String(24), index=True)
    token_address: Mapped[str] = mapped_column(String(128), index=True)
    status: Mapped[str] = mapped_column(String(32), index=True)
    score: Mapped[float] = mapped_column(Float)
    reasons: Mapped[list] = mapped_column(JSON, default=list)
    subscores: Mapped[dict] = mapped_column(JSON, default=dict)
    evidence: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class ReputationRecord(Base):
    __tablename__ = 'reputation_entities'
    __table_args__ = (UniqueConstraint('entity_type', 'entity_value', name='uq_entity_reputation'),)
    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    entity_type: Mapped[str] = mapped_column(String(64), index=True)
    entity_value: Mapped[str] = mapped_column(String(512), index=True)
    reputation_score: Mapped[float] = mapped_column(Float, default=50.0)
    flagged: Mapped[bool] = mapped_column(Boolean, default=False)
    reason_code: Mapped[str | None] = mapped_column(String(128), nullable=True)
    evidence: Mapped[dict] = mapped_column(JSON, default=dict)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class BlacklistRecord(Base):
    __tablename__ = 'scam_blacklists'
    __table_args__ = (UniqueConstraint('entity_type', 'entity_value', name='uq_entity_blacklist'),)
    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    entity_type: Mapped[str] = mapped_column(String(64), index=True)
    entity_value: Mapped[str] = mapped_column(String(512), index=True)
    reason_code: Mapped[str] = mapped_column(String(128), index=True)
    source: Mapped[str | None] = mapped_column(String(128), nullable=True)
    confidence: Mapped[float] = mapped_column(Float, default=1.0)
    evidence: Mapped[dict] = mapped_column(JSON, default=dict)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class DeployerHistoryRecord(Base):
    __tablename__ = 'deployer_history'
    __table_args__ = (UniqueConstraint('chain', 'wallet_address', name='uq_deployer_history'),)
    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    chain: Mapped[str] = mapped_column(String(24), index=True)
    wallet_address: Mapped[str] = mapped_column(String(128), index=True)
    launches_count: Mapped[int] = mapped_column(Integer, default=0)
    dead_tokens_count: Mapped[int] = mapped_column(Integer, default=0)
    rugs_count: Mapped[int] = mapped_column(Integer, default=0)
    avg_token_lifetime_days: Mapped[float | None] = mapped_column(Float, nullable=True)
    funding_wallet: Mapped[str | None] = mapped_column(String(128), nullable=True)
    reputation_score: Mapped[float] = mapped_column(Float, default=50.0)
    suspicious_patterns: Mapped[list] = mapped_column(JSON, default=list)
    evidence: Mapped[dict] = mapped_column(JSON, default=dict)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class ContractFingerprintRecord(Base):
    __tablename__ = 'contract_fingerprints'
    __table_args__ = (UniqueConstraint('chain', 'token_address', name='uq_contract_fingerprint'),)
    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    chain: Mapped[str] = mapped_column(String(24), index=True)
    token_address: Mapped[str] = mapped_column(String(128), index=True)
    bytecode_hash: Mapped[str | None] = mapped_column(String(128), nullable=True, index=True)
    fingerprint_hash: Mapped[str | None] = mapped_column(String(128), nullable=True, index=True)
    selectors: Mapped[list] = mapped_column(JSON, default=list)
    suspicious_selectors: Mapped[list] = mapped_column(JSON, default=list)
    similarity_score: Mapped[float] = mapped_column(Float, default=0.0)
    matched_template: Mapped[str | None] = mapped_column(String(128), nullable=True)
    reasons: Mapped[list] = mapped_column(JSON, default=list)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class WalletClusterRecord(Base):
    __tablename__ = 'wallet_clusters'
    __table_args__ = (UniqueConstraint('cluster_id', name='uq_cluster_id'),)
    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    cluster_id: Mapped[str] = mapped_column(String(128), index=True)
    wallets: Mapped[list] = mapped_column(JSON, default=list)
    risk_score: Mapped[float] = mapped_column(Float, default=0.0)
    labels: Mapped[list] = mapped_column(JSON, default=list)
    evidence: Mapped[dict] = mapped_column(JSON, default=dict)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class ManualReviewRecord(Base):
    __tablename__ = 'manual_reviews'
    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    chain: Mapped[str] = mapped_column(String(24), index=True)
    token_address: Mapped[str] = mapped_column(String(128), index=True)
    status: Mapped[str] = mapped_column(String(32), default='OPEN', index=True)
    assigned_to: Mapped[str | None] = mapped_column(String(128), nullable=True)
    notes: Mapped[str] = mapped_column(Text, default='')
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class AuditLogRecord(Base):
    __tablename__ = 'audit_logs'
    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    event_type: Mapped[str] = mapped_column(String(64), index=True)
    token_address: Mapped[str | None] = mapped_column(String(128), nullable=True, index=True)
    payload: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class WalletNodeRecord(Base):
    __tablename__ = 'wallet_nodes'
    __table_args__ = (UniqueConstraint('chain', 'wallet_address', name='uq_wallet_node'),)
    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    chain: Mapped[str] = mapped_column(String(24), index=True)
    wallet_address: Mapped[str] = mapped_column(String(128), index=True)
    labels: Mapped[list] = mapped_column(JSON, default=list)
    risk_score: Mapped[float] = mapped_column(Float, default=0.0)
    metadata_json: Mapped[dict] = mapped_column('metadata', JSON, default=dict)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class WalletEdgeRecord(Base):
    __tablename__ = 'wallet_edges'
    __table_args__ = (UniqueConstraint('chain', 'src_wallet', 'dst_wallet', 'edge_type', name='uq_wallet_edge'),)
    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    chain: Mapped[str] = mapped_column(String(24), index=True)
    src_wallet: Mapped[str] = mapped_column(String(128), index=True)
    dst_wallet: Mapped[str] = mapped_column(String(128), index=True)
    edge_type: Mapped[str] = mapped_column(String(32), index=True)
    weight: Mapped[float] = mapped_column(Float, default=1.0)
    evidence: Mapped[dict] = mapped_column(JSON, default=dict)
    last_seen_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class GraphScoreRunRecord(Base):
    __tablename__ = 'graph_score_runs'
    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    chain: Mapped[str] = mapped_column(String(24), index=True)
    status: Mapped[str] = mapped_column(String(32), index=True, default='SUCCESS')
    nodes_scored: Mapped[int] = mapped_column(Integer, default=0)
    clusters_scored: Mapped[int] = mapped_column(Integer, default=0)
    summary: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class ScheduledJobRecord(Base):
    __tablename__ = 'scheduled_jobs'
    __table_args__ = (UniqueConstraint('job_name', name='uq_scheduled_job'),)
    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    job_name: Mapped[str] = mapped_column(String(128), index=True)
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    interval_seconds: Mapped[int] = mapped_column(Integer, default=300)
    next_run_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)
    last_run_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    last_error: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class JobRunRecord(Base):
    __tablename__ = 'job_runs'
    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    job_name: Mapped[str] = mapped_column(String(128), index=True)
    status: Mapped[str] = mapped_column(String(32), index=True, default='RUNNING')
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)


class HistoricalTokenRecord(Base):
    __tablename__ = 'historical_tokens'
    __table_args__ = (UniqueConstraint('chain', 'token_address', name='uq_historical_token'),)
    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    chain: Mapped[str] = mapped_column(String(24), index=True)
    token_address: Mapped[str] = mapped_column(String(128), index=True)
    first_seen_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    first_decision: Mapped[str | None] = mapped_column(String(32), nullable=True)
    latest_decision: Mapped[str | None] = mapped_column(String(32), nullable=True)
    peak_liquidity_usd: Mapped[float | None] = mapped_column(Float, nullable=True)
    latest_liquidity_usd: Mapped[float | None] = mapped_column(Float, nullable=True)
    peak_holders: Mapped[int | None] = mapped_column(Integer, nullable=True)
    latest_holders: Mapped[int | None] = mapped_column(Integer, nullable=True)
    historical_score: Mapped[float] = mapped_column(Float, default=50.0)
    labels: Mapped[list] = mapped_column(JSON, default=list)
    notes: Mapped[dict] = mapped_column(JSON, default=dict)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class AnalystLabelRecord(Base):
    __tablename__ = 'analyst_labels'
    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    chain: Mapped[str] = mapped_column(String(24), index=True)
    token_address: Mapped[str] = mapped_column(String(128), index=True)
    label: Mapped[str] = mapped_column(String(64), index=True)
    value: Mapped[str] = mapped_column(String(64), index=True)
    analyst: Mapped[str | None] = mapped_column(String(128), nullable=True)
    notes: Mapped[str] = mapped_column(Text, default='')
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class RealtimeAlertRecord(Base):
    __tablename__ = 'realtime_alerts'
    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    chain: Mapped[str] = mapped_column(String(24), index=True)
    token_address: Mapped[str] = mapped_column(String(128), index=True)
    event_type: Mapped[str] = mapped_column(String(64), index=True)
    severity: Mapped[str] = mapped_column(String(32), index=True)
    payload: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class TokenLifecycleRecord(Base):
    __tablename__ = 'token_lifecycle'
    __table_args__ = (UniqueConstraint('chain', 'token_address', name='uq_lifecycle'),)

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    chain: Mapped[str] = mapped_column(String(24), index=True)
    token_address: Mapped[str] = mapped_column(String(128), index=True)
    symbol: Mapped[str | None] = mapped_column(String(64), nullable=True)

    status: Mapped[str] = mapped_column(String(32), index=True, default='watching')
    strategy: Mapped[str | None] = mapped_column(String(32), nullable=True)

    entry_price: Mapped[float | None] = mapped_column(Float, nullable=True)
    entry_execution_price: Mapped[float | None] = mapped_column(Float, nullable=True)
    current_price: Mapped[float | None] = mapped_column(Float, nullable=True)
    peak_price: Mapped[float | None] = mapped_column(Float, nullable=True)
    exit_price: Mapped[float | None] = mapped_column(Float, nullable=True)
    raw_exit_price: Mapped[float | None] = mapped_column(Float, nullable=True)

    entry_latency_seconds: Mapped[int | None] = mapped_column(Integer, nullable=True)
    exit_latency_seconds: Mapped[int | None] = mapped_column(Integer, nullable=True)
    execution_fees_usd: Mapped[float] = mapped_column(Float, default=0.0)
    remaining_size_usd: Mapped[float | None] = mapped_column(Float, nullable=True)
    realized_pnl_usd: Mapped[float] = mapped_column(Float, default=0.0)
    reentry_count: Mapped[int] = mapped_column(Integer, default=0)

    entry_liquidity_usd: Mapped[float | None] = mapped_column(Float, nullable=True)
    peak_liquidity_usd: Mapped[float | None] = mapped_column(Float, nullable=True)
    current_liquidity_usd: Mapped[float | None] = mapped_column(Float, nullable=True)
    entry_holders: Mapped[int | None] = mapped_column(Integer, nullable=True)
    peak_holders: Mapped[int | None] = mapped_column(Integer, nullable=True)
    current_holders: Mapped[int | None] = mapped_column(Integer, nullable=True)

    paper_size_usd: Mapped[float] = mapped_column(Float, default=100.0)
    paper_pnl_usd: Mapped[float] = mapped_column(Float, default=0.0)
    paper_pnl_pct: Mapped[float] = mapped_column(Float, default=0.0)

    stop_loss_pct: Mapped[float] = mapped_column(Float, default=-25.0)
    take_profit_pct: Mapped[float] = mapped_column(Float, default=100.0)
    trailing_stop_pct: Mapped[float] = mapped_column(Float, default=-15.0)
    time_limit_minutes: Mapped[int] = mapped_column(Integer, default=60)
    exit_reason: Mapped[str | None] = mapped_column(String(64), nullable=True)

    entry_continuation_score: Mapped[float | None] = mapped_column(Float, nullable=True)
    entry_risk_score: Mapped[float | None] = mapped_column(Float, nullable=True)
    entry_brain_strategy: Mapped[str | None] = mapped_column(String(32), nullable=True)

    bundle_severity: Mapped[str | None] = mapped_column(String(32), nullable=True)
    bundle_wallet_count: Mapped[int | None] = mapped_column(Integer, nullable=True)
    bundle_supply_pct: Mapped[float | None] = mapped_column(Float, nullable=True)
    pair_address: Mapped[str | None] = mapped_column(String(128), nullable=True)
    graduated_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    entry_delay_seconds: Mapped[int | None] = mapped_column(Integer, nullable=True)
    token_family: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
    requested_size_usd: Mapped[float | None] = mapped_column(Float, nullable=True)
    filled_size_usd: Mapped[float | None] = mapped_column(Float, nullable=True)
    fill_pct: Mapped[float | None] = mapped_column(Float, nullable=True)
    entry_slippage_pct: Mapped[float | None] = mapped_column(Float, nullable=True)
    exit_slippage_pct: Mapped[float | None] = mapped_column(Float, nullable=True)
    entry_spread_pct: Mapped[float | None] = mapped_column(Float, nullable=True)
    exit_spread_pct: Mapped[float | None] = mapped_column(Float, nullable=True)
    entry_impact_pct: Mapped[float | None] = mapped_column(Float, nullable=True)
    exit_impact_pct: Mapped[float | None] = mapped_column(Float, nullable=True)
    execution_state: Mapped[str] = mapped_column(String(32), default='new', index=True)
    execution_state_reason: Mapped[str | None] = mapped_column(String(128), nullable=True)
    execution_state_updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    execution_attempts: Mapped[int] = mapped_column(Integer, default=0)
    execution_metadata: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    partial_exit_done: Mapped[bool] = mapped_column(Boolean, default=False)
    partial_exit_pct: Mapped[float | None] = mapped_column(Float, nullable=True)
    entry_signals: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    exit_signals: Mapped[dict | None] = mapped_column(JSON, nullable=True)

    first_seen_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=lambda: datetime.now(timezone.utc)
    )
    entry_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    peak_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    exit_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    last_checked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
    )
    # H4: brain score fields (added via migration 0011)
    pulse_score: Mapped[float | None] = mapped_column(Float, nullable=True)
    component_scores_json: Mapped[str | None] = mapped_column(Text, nullable=True)


class PaperTradeRecord(Base):
    __tablename__ = 'paper_trades'
    __table_args__ = (UniqueConstraint('trade_key', name='uq_paper_trade_key'),)

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    trade_key: Mapped[str] = mapped_column(String(255), index=True)
    chain: Mapped[str] = mapped_column(String(24), index=True)
    token_address: Mapped[str] = mapped_column(String(128), index=True)
    symbol: Mapped[str | None] = mapped_column(String(64), nullable=True)
    strategy: Mapped[str | None] = mapped_column(String(32), nullable=True, index=True)
    status: Mapped[str] = mapped_column(String(32), default='paper_closed', index=True)

    entry_price: Mapped[float | None] = mapped_column(Float, nullable=True)
    entry_execution_price: Mapped[float | None] = mapped_column(Float, nullable=True)
    exit_price: Mapped[float | None] = mapped_column(Float, nullable=True)
    raw_exit_price: Mapped[float | None] = mapped_column(Float, nullable=True)

    requested_size_usd: Mapped[float | None] = mapped_column(Float, nullable=True)
    filled_size_usd: Mapped[float | None] = mapped_column(Float, nullable=True)
    fill_pct: Mapped[float | None] = mapped_column(Float, nullable=True)
    paper_size_usd: Mapped[float] = mapped_column(Float, default=100.0)
    execution_fees_usd: Mapped[float] = mapped_column(Float, default=0.0)
    realized_pnl_usd: Mapped[float] = mapped_column(Float, default=0.0)
    paper_pnl_usd: Mapped[float] = mapped_column(Float, default=0.0)
    paper_pnl_pct: Mapped[float] = mapped_column(Float, default=0.0)

    entry_delay_seconds: Mapped[int | None] = mapped_column(Integer, nullable=True)
    entry_latency_seconds: Mapped[int | None] = mapped_column(Integer, nullable=True)
    exit_latency_seconds: Mapped[int | None] = mapped_column(Integer, nullable=True)
    graduated_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    entry_continuation_score: Mapped[float | None] = mapped_column(Float, nullable=True)
    entry_risk_score: Mapped[float | None] = mapped_column(Float, nullable=True)
    token_family: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
    exit_reason: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
    execution_state: Mapped[str | None] = mapped_column(String(32), nullable=True)
    pair_address: Mapped[str | None] = mapped_column(String(128), nullable=True)

    entry_signals: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    exit_signals: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    execution_metadata: Mapped[dict | None] = mapped_column(JSON, nullable=True)

    lifecycle_id: Mapped[int | None] = mapped_column(Integer, nullable=True, index=True)
    entry_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True, index=True)
    exit_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), index=True)


class PriceSnapshotRecord(Base):
    __tablename__ = 'price_snapshots_pulse'

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    chain: Mapped[str] = mapped_column(String(24), index=True)
    token_address: Mapped[str] = mapped_column(String(128), index=True)
    price_usd: Mapped[float | None] = mapped_column(Float, nullable=True)
    liquidity_usd: Mapped[float | None] = mapped_column(Float, nullable=True)
    holders: Mapped[int | None] = mapped_column(Integer, nullable=True)
    market_cap_usd: Mapped[float | None] = mapped_column(Float, nullable=True)
    source: Mapped[str] = mapped_column(String(32), default='dexscreener')
    captured_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        index=True,
    )


class FarmPosition(Base):
    __tablename__ = 'farm_positions'

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    mint: Mapped[str] = mapped_column(String(128), nullable=False, index=True)
    symbol: Mapped[str | None] = mapped_column(String(64), nullable=True)

    entry_price: Mapped[float] = mapped_column(Float, nullable=False)
    entry_time: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    paper_amount_usd: Mapped[float] = mapped_column(Float, default=20.0)

    bundle_wallet_count: Mapped[int | None] = mapped_column(Integer, nullable=True)
    bundle_pct: Mapped[float | None] = mapped_column(Float, nullable=True)
    bundle_farm_score: Mapped[float | None] = mapped_column(Float, nullable=True)
    bundle_wallets_json: Mapped[str | None] = mapped_column(Text, nullable=True)

    exit_price: Mapped[float | None] = mapped_column(Float, nullable=True)
    raw_exit_price: Mapped[float | None] = mapped_column(Float, nullable=True)
    exit_time: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    exit_reason: Mapped[str | None] = mapped_column(String(64), nullable=True)
    pnl_pct: Mapped[float | None] = mapped_column(Float, nullable=True)
    pnl_usd: Mapped[float | None] = mapped_column(Float, nullable=True)

    current_price: Mapped[float | None] = mapped_column(Float, nullable=True)
    peak_price: Mapped[float | None] = mapped_column(Float, nullable=True)
    last_checked: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    status: Mapped[str] = mapped_column(String(32), default='OPEN', index=True)

    bundle_sold_pct: Mapped[float] = mapped_column(Float, default=0.0)
    bundle_danger: Mapped[bool] = mapped_column(Boolean, default=False)

class LivePositionRecord(Base):
    __tablename__ = 'live_positions'

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    chain: Mapped[str] = mapped_column(String(24), index=True)
    token_address: Mapped[str] = mapped_column(String(128), index=True)
    symbol: Mapped[str | None] = mapped_column(String(64), nullable=True)
    wallet_address: Mapped[str | None] = mapped_column(String(128), nullable=True, index=True)
    strategy: Mapped[str | None] = mapped_column(String(32), nullable=True, index=True)
    status: Mapped[str] = mapped_column(String(32), default='OPEN', index=True)

    entry_price: Mapped[float | None] = mapped_column(Float, nullable=True)
    current_price: Mapped[float | None] = mapped_column(Float, nullable=True)
    peak_price: Mapped[float | None] = mapped_column(Float, nullable=True)
    exit_price: Mapped[float | None] = mapped_column(Float, nullable=True)
    entry_size_usd: Mapped[float | None] = mapped_column(Float, nullable=True)
    current_size_usd: Mapped[float | None] = mapped_column(Float, nullable=True)
    realized_pnl_usd: Mapped[float | None] = mapped_column(Float, nullable=True)
    realized_pnl_pct: Mapped[float | None] = mapped_column(Float, nullable=True)
    entry_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    exit_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    last_checked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    exit_reason: Mapped[str | None] = mapped_column(String(64), nullable=True)
    tx_signature: Mapped[str | None] = mapped_column(String(256), nullable=True)
    entry_signature: Mapped[str | None] = mapped_column(String(256), nullable=True)
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    metadata_json: Mapped[dict | None] = mapped_column('metadata', JSON, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))

