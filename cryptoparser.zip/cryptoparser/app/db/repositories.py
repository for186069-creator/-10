from __future__ import annotations

from sqlalchemy import delete, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.dialects.sqlite import insert

from app.db.models import (
    AuditLogRecord,
    BlacklistRecord,
    ContractFingerprintRecord,
    DeployerHistoryRecord,
    GraphScoreRunRecord,
    HistoricalTokenRecord,
    AnalystLabelRecord,
    RealtimeAlertRecord,
    JobRunRecord,
    ManualReviewRecord,
    ReputationRecord,
    ScheduledJobRecord,
    TokenCandidateRecord,
    TokenDecisionRecord,
    WalletClusterRecord,
    WalletEdgeRecord,
    WalletNodeRecord,
)
from app.models.token import ContractFingerprint, Decision, DeployerProfile, TokenCandidate, WalletClusterProfile


class TokenRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def upsert_candidate(self, candidate: TokenCandidate) -> None:
        stmt = insert(TokenCandidateRecord).values(
            chain=candidate.chain.value,
            token_address=candidate.token_address,
            pair_address=candidate.pair_address,
            symbol=candidate.symbol,
            name=candidate.name,
            deployer_address=candidate.deployer_address,
            first_seen_at=candidate.first_seen_at,
            liquidity_usd=candidate.liquidity_usd,
            holders=candidate.holders,
            website=candidate.website,
            x_handle=candidate.x_handle,
            telegram_url=candidate.telegram_url,
            token_family=(candidate.raw or {}).get('token_family'),
            launchpad=(candidate.raw or {}).get('launchpad'),
            lifecycle_stage=(candidate.raw or {}).get('lifecycle_stage') or (candidate.raw or {}).get('decision_profile'),
            graduated_confirmed=bool((candidate.raw or {}).get('graduated_confirmed')),
            taxes_buy_pct=candidate.taxes_buy_pct,
            taxes_sell_pct=candidate.taxes_sell_pct,
            raw=candidate.raw,
        )
        stmt = stmt.on_conflict_do_update(
            index_elements=[
                TokenCandidateRecord.chain,
                TokenCandidateRecord.token_address,
            ],
            set_={
                "pair_address": stmt.excluded.pair_address,
                "symbol": stmt.excluded.symbol,
                "name": stmt.excluded.name,
                "deployer_address": stmt.excluded.deployer_address,
                "liquidity_usd": stmt.excluded.liquidity_usd,
                "holders": stmt.excluded.holders,
                "website": stmt.excluded.website,
                "x_handle": stmt.excluded.x_handle,
                "telegram_url": stmt.excluded.telegram_url,
                "token_family": stmt.excluded.token_family,
                "launchpad": stmt.excluded.launchpad,
                "lifecycle_stage": stmt.excluded.lifecycle_stage,
                "graduated_confirmed": stmt.excluded.graduated_confirmed,
                "taxes_buy_pct": stmt.excluded.taxes_buy_pct,
                "taxes_sell_pct": stmt.excluded.taxes_sell_pct,
                "raw": stmt.excluded.raw,
            },
        )
        await self.session.execute(stmt)
        await self.session.commit()

    async def save_decision(self, candidate: TokenCandidate, decision: Decision) -> None:
        self.session.add(TokenDecisionRecord(chain=candidate.chain.value, token_address=candidate.token_address, status=decision.status, score=decision.score, reasons=decision.reasons, subscores=decision.subscores, evidence=decision.evidence))
        await self.session.commit()

    async def latest_status(self, chain: str, token_address: str) -> str | None:
        q = select(TokenDecisionRecord.status).where(TokenDecisionRecord.chain == chain, TokenDecisionRecord.token_address == token_address).order_by(TokenDecisionRecord.created_at.desc())
        return (await self.session.execute(q)).scalar_one_or_none()


class ReputationRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def get_reputation(self, entity_type: str, entity_value: str | None) -> ReputationRecord | None:
        if not entity_value:
            return None
        q = select(ReputationRecord).where(ReputationRecord.entity_type == entity_type, ReputationRecord.entity_value == entity_value)
        return (await self.session.execute(q)).scalar_one_or_none()

    async def is_blacklisted(self, entity_type: str, entity_value: str | None) -> bool:
        if not entity_value:
            return False
        q = select(BlacklistRecord).where(BlacklistRecord.entity_type == entity_type, BlacklistRecord.entity_value == entity_value, BlacklistRecord.active.is_(True))
        return (await self.session.execute(q)).scalar_one_or_none() is not None

    async def upsert_reputation(self, entity_type: str, entity_value: str, reputation_score: float, *, flagged: bool = False, reason_code: str | None = None, evidence: dict | None = None) -> None:
        q = select(ReputationRecord).where(ReputationRecord.entity_type == entity_type, ReputationRecord.entity_value == entity_value)
        row = (await self.session.execute(q)).scalar_one_or_none()
        if row:
            row.reputation_score = reputation_score
            row.flagged = flagged
            row.reason_code = reason_code
            row.evidence = evidence or {}
        else:
            self.session.add(ReputationRecord(entity_type=entity_type, entity_value=entity_value, reputation_score=reputation_score, flagged=flagged, reason_code=reason_code, evidence=evidence or {}))
        await self.session.commit()

    async def add_blacklist(self, entity_type: str, entity_value: str, reason_code: str, *, source: str | None = None, confidence: float = 1.0, evidence: dict | None = None) -> None:
        q = select(BlacklistRecord).where(BlacklistRecord.entity_type == entity_type, BlacklistRecord.entity_value == entity_value)
        row = (await self.session.execute(q)).scalar_one_or_none()
        if row:
            row.reason_code = reason_code
            row.source = source
            row.confidence = confidence
            row.evidence = evidence or {}
            row.active = True
        else:
            self.session.add(BlacklistRecord(entity_type=entity_type, entity_value=entity_value, reason_code=reason_code, source=source, confidence=confidence, evidence=evidence or {}))
        await self.session.commit()

    async def clear_blacklist(self, entity_type: str, entity_value: str) -> None:
        await self.session.execute(delete(BlacklistRecord).where(BlacklistRecord.entity_type == entity_type, BlacklistRecord.entity_value == entity_value))
        await self.session.commit()


class DeployerRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def get(self, chain: str, wallet_address: str | None) -> DeployerHistoryRecord | None:
        if not wallet_address:
            return None
        q = select(DeployerHistoryRecord).where(DeployerHistoryRecord.chain == chain, DeployerHistoryRecord.wallet_address == wallet_address)
        return (await self.session.execute(q)).scalar_one_or_none()

    async def upsert(self, profile: DeployerProfile, chain: str) -> None:
        q = select(DeployerHistoryRecord).where(DeployerHistoryRecord.chain == chain, DeployerHistoryRecord.wallet_address == profile.address)
        row = (await self.session.execute(q)).scalar_one_or_none()
        payload = dict(
            launches_count=profile.launches_count,
            dead_tokens_count=profile.dead_tokens_count,
            rugs_count=profile.rugs_count,
            avg_token_lifetime_days=profile.avg_token_lifetime_days,
            funding_wallet=profile.funding_wallet,
            reputation_score=profile.reputation_score,
            suspicious_patterns=profile.suspicious_patterns,
            evidence=profile.evidence,
        )
        if row:
            for key, value in payload.items():
                setattr(row, key, value)
        else:
            self.session.add(DeployerHistoryRecord(chain=chain, wallet_address=profile.address, **payload))
        await self.session.commit()


class FingerprintRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def get_by_hash(self, chain: str, fingerprint_hash: str | None) -> list[ContractFingerprintRecord]:
        if not fingerprint_hash:
            return []
        q = select(ContractFingerprintRecord).where(ContractFingerprintRecord.chain == chain, ContractFingerprintRecord.fingerprint_hash == fingerprint_hash)
        return list((await self.session.execute(q)).scalars().all())

    async def upsert(self, fingerprint: ContractFingerprint) -> None:
        q = select(ContractFingerprintRecord).where(ContractFingerprintRecord.chain == fingerprint.chain.value, ContractFingerprintRecord.token_address == fingerprint.token_address)
        row = (await self.session.execute(q)).scalar_one_or_none()
        payload = dict(
            bytecode_hash=fingerprint.bytecode_hash,
            fingerprint_hash=fingerprint.fingerprint_hash,
            selectors=fingerprint.selectors,
            suspicious_selectors=fingerprint.suspicious_selectors,
            similarity_score=fingerprint.similarity_score,
            matched_template=fingerprint.matched_template,
            reasons=fingerprint.reasons,
        )
        if row:
            for key, value in payload.items():
                setattr(row, key, value)
        else:
            self.session.add(ContractFingerprintRecord(chain=fingerprint.chain.value, token_address=fingerprint.token_address, **payload))
        await self.session.commit()


class ClusterRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def get(self, cluster_id: str) -> WalletClusterRecord | None:
        q = select(WalletClusterRecord).where(WalletClusterRecord.cluster_id == cluster_id)
        return (await self.session.execute(q)).scalar_one_or_none()

    async def upsert(self, profile: WalletClusterProfile) -> None:
        q = select(WalletClusterRecord).where(WalletClusterRecord.cluster_id == profile.cluster_id)
        row = (await self.session.execute(q)).scalar_one_or_none()
        payload = dict(wallets=profile.wallets, risk_score=profile.risk_score, labels=profile.labels, evidence=profile.evidence)
        if row:
            for key, value in payload.items():
                setattr(row, key, value)
        else:
            self.session.add(WalletClusterRecord(cluster_id=profile.cluster_id, **payload))
        await self.session.commit()


class ManualReviewRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def create(self, chain: str, token_address: str, notes: str = '') -> None:
        self.session.add(ManualReviewRecord(chain=chain, token_address=token_address, notes=notes))
        await self.session.commit()

    async def list_open(self) -> list[ManualReviewRecord]:
        q = select(ManualReviewRecord).where(ManualReviewRecord.status == 'OPEN').order_by(ManualReviewRecord.created_at.desc())
        return list((await self.session.execute(q)).scalars().all())

    async def update_status(self, review_id: int, status: str, assigned_to: str | None = None, notes: str | None = None) -> None:
        q = select(ManualReviewRecord).where(ManualReviewRecord.id == review_id)
        row = (await self.session.execute(q)).scalar_one_or_none()
        if not row:
            return
        row.status = status
        if assigned_to is not None:
            row.assigned_to = assigned_to
        if notes is not None:
            row.notes = notes
        await self.session.commit()


class AuditRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def log(self, event_type: str, payload: dict, token_address: str | None = None) -> None:
        self.session.add(AuditLogRecord(event_type=event_type, token_address=token_address, payload=payload))
        await self.session.commit()


class GraphRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def upsert_node(self, chain: str, wallet_address: str, *, labels: list[str] | None = None, risk_score: float = 0.0, metadata: dict | None = None) -> None:
        q = select(WalletNodeRecord).where(WalletNodeRecord.chain == chain, WalletNodeRecord.wallet_address == wallet_address)
        row = (await self.session.execute(q)).scalar_one_or_none()
        payload = dict(labels=labels or [], risk_score=risk_score, metadata_json=metadata or {})
        if row:
            for key, value in payload.items():
                setattr(row, key, value)
        else:
            self.session.add(WalletNodeRecord(chain=chain, wallet_address=wallet_address, **payload))
        await self.session.commit()

    async def upsert_edge(self, chain: str, src_wallet: str, dst_wallet: str, *, edge_type: str, weight: float = 1.0, evidence: dict | None = None) -> None:
        q = select(WalletEdgeRecord).where(
            WalletEdgeRecord.chain == chain,
            WalletEdgeRecord.src_wallet == src_wallet,
            WalletEdgeRecord.dst_wallet == dst_wallet,
            WalletEdgeRecord.edge_type == edge_type,
        )
        row = (await self.session.execute(q)).scalar_one_or_none()
        payload = dict(weight=weight, evidence=evidence or {})
        if row:
            for key, value in payload.items():
                setattr(row, key, value)
        else:
            self.session.add(WalletEdgeRecord(chain=chain, src_wallet=src_wallet, dst_wallet=dst_wallet, edge_type=edge_type, **payload))
        await self.session.commit()

    async def neighbors(self, chain: str, wallet_address: str) -> list[dict]:
        q = select(WalletEdgeRecord).where(
            WalletEdgeRecord.chain == chain,
            (WalletEdgeRecord.src_wallet == wallet_address) | (WalletEdgeRecord.dst_wallet == wallet_address)
        )
        rows = list((await self.session.execute(q)).scalars().all())
        return [
            {
                'src_wallet': row.src_wallet,
                'dst_wallet': row.dst_wallet,
                'edge_type': row.edge_type,
                'weight': row.weight,
                'evidence': row.evidence,
            }
            for row in rows
        ]

    async def top_risky_nodes(self, limit: int = 50) -> list[dict]:
        q = select(WalletNodeRecord).order_by(WalletNodeRecord.risk_score.desc()).limit(limit)
        rows = list((await self.session.execute(q)).scalars().all())
        return [
            {
                'chain': row.chain,
                'wallet_address': row.wallet_address,
                'labels': row.labels,
                'risk_score': row.risk_score,
                'metadata': row.metadata_json,
            }
            for row in rows
        ]

    async def all_edges(self, chain: str | None = None) -> list[WalletEdgeRecord]:
        q = select(WalletEdgeRecord)
        if chain:
            q = q.where(WalletEdgeRecord.chain == chain)
        return list((await self.session.execute(q)).scalars().all())

    async def all_nodes(self, chain: str | None = None) -> list[WalletNodeRecord]:
        q = select(WalletNodeRecord)
        if chain:
            q = q.where(WalletNodeRecord.chain == chain)
        return list((await self.session.execute(q)).scalars().all())

    async def top_clusters(self, limit: int = 50) -> list[WalletClusterRecord]:
        q = select(WalletClusterRecord).order_by(WalletClusterRecord.risk_score.desc()).limit(limit)
        return list((await self.session.execute(q)).scalars().all())


class GraphScoreRunRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def create(self, chain: str, status: str, nodes_scored: int, clusters_scored: int, summary: dict) -> None:
        self.session.add(GraphScoreRunRecord(chain=chain, status=status, nodes_scored=nodes_scored, clusters_scored=clusters_scored, summary=summary))
        await self.session.commit()

    async def latest(self, limit: int = 20) -> list[GraphScoreRunRecord]:
        q = select(GraphScoreRunRecord).order_by(GraphScoreRunRecord.created_at.desc()).limit(limit)
        return list((await self.session.execute(q)).scalars().all())


class SchedulerRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def jobs(self) -> list[ScheduledJobRecord]:
        q = select(ScheduledJobRecord).order_by(ScheduledJobRecord.job_name.asc())
        return list((await self.session.execute(q)).scalars().all())

    async def latest_runs(self, limit: int = 50) -> list[JobRunRecord]:
        q = select(JobRunRecord).order_by(JobRunRecord.started_at.desc()).limit(limit)
        return list((await self.session.execute(q)).scalars().all())


class HistoricalRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def upsert(self, chain: str, token_address: str, payload: dict) -> None:
        q = select(HistoricalTokenRecord).where(HistoricalTokenRecord.chain == chain, HistoricalTokenRecord.token_address == token_address)
        row = (await self.session.execute(q)).scalar_one_or_none()
        if row:
            for key, value in payload.items():
                if hasattr(row, key):
                    setattr(row, key, value)
        else:
            self.session.add(HistoricalTokenRecord(chain=chain, token_address=token_address, **payload))
        await self.session.commit()

    async def get(self, chain: str, token_address: str) -> HistoricalTokenRecord | None:
        q = select(HistoricalTokenRecord).where(HistoricalTokenRecord.chain == chain, HistoricalTokenRecord.token_address == token_address)
        return (await self.session.execute(q)).scalar_one_or_none()


class RealtimeAlertRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def create(self, chain: str, token_address: str, event_type: str, severity: str, payload: dict) -> None:
        self.session.add(RealtimeAlertRecord(chain=chain, token_address=token_address, event_type=event_type, severity=severity, payload=payload))
        await self.session.commit()

    async def latest(self, limit: int = 100) -> list[RealtimeAlertRecord]:
        q = select(RealtimeAlertRecord).order_by(RealtimeAlertRecord.created_at.desc()).limit(limit)
        return list((await self.session.execute(q)).scalars().all())


class AnalystLabelRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def create(self, chain: str, token_address: str, label: str, value: str, analyst: str | None = None, notes: str = '') -> None:
        self.session.add(AnalystLabelRecord(chain=chain, token_address=token_address, label=label, value=value, analyst=analyst, notes=notes))
        await self.session.commit()

    async def list_for_token(self, chain: str, token_address: str) -> list[AnalystLabelRecord]:
        q = select(AnalystLabelRecord).where(AnalystLabelRecord.chain == chain, AnalystLabelRecord.token_address == token_address).order_by(AnalystLabelRecord.created_at.desc())
        return list((await self.session.execute(q)).scalars().all())
