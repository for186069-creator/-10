from __future__ import annotations

import asyncio
import contextlib
import logging
import sys

import uvicorn

from app.core.config import settings
from app.core.logging import configure_logging
from app.db.base import AsyncSessionLocal
from app.db.init_db import init_db
from app.pipeline.runner import run_polling_once, run_pump_polling_once, run_graduated_polling_once
from app.queue.service import QueueService
from app.queue.worker import QueueWorker
from app.services.pipeline import Pipeline
from app.services.graph_jobs import run_graph_jobs_forever, run_graph_jobs_once
from app.services.scheduler import ScheduledJobDefinition, run_scheduler_forever
from app.services.outcome_tracker import run_outcome_tracker
from app.services.threshold_calibrator import run_threshold_calibration
from app.services.gem_calibrator import run_gem_calibration
from app.services.price_monitor import run_price_monitor
from app.services.pulse.farm_mode import run_farm_mode_tick
from app.services.pulse.scheduler_hook import run_paper_trading_tick, run_review_reeval, run_pulse_health_check, run_live_recovery
from app.services.pulse.approve_watcher import run_approve_watcher
from app.services.pulse.watchlist_poller import run_watchlist_snapshot_tick
from app.observability.tracing import init_error_and_tracing

logger = logging.getLogger(__name__)


async def run_once() -> None:
    await init_db()
    async with AsyncSessionLocal() as session:
        pipeline = Pipeline(session)
        results = await pipeline.run_once()
        for item in results:
            print(item)


async def run_worker() -> None:
    await init_db()
    queue = QueueService()
    worker = QueueWorker(queue)
    await worker.run_forever()


def run_admin() -> None:
    uvicorn.run('app.admin.api:app', host=settings.admin_api_host, port=settings.admin_api_port, reload=False)


async def run_graph_jobs() -> None:
    await init_db()
    await run_graph_jobs_forever(AsyncSessionLocal)


async def run_scheduler() -> None:
    await init_db()

    async def _poll_and_evaluate() -> None:
        logger.info('pump_telemetry event=scheduler_job_start job=poller_ingest')
        async with AsyncSessionLocal() as session:
            pipeline = Pipeline(session)
            results = await pipeline.run_once()
            for item in results:
                print(item)
        logger.info('pump_telemetry event=scheduler_job_done job=poller_ingest results=%s', len(results))

    async def _poll_pump_fast_lane() -> None:
        logger.info('pump_telemetry event=scheduler_job_start job=poller_pump_fast')
        async with AsyncSessionLocal() as session:
            pipeline = Pipeline(session)
            results = await pipeline.run_pump_fast_once()
            for item in results:
                print(item)
        logger.info('pump_telemetry event=scheduler_job_done job=poller_pump_fast results=%s', len(results))

    async def _poll_graduated() -> None:
        logger.info('pump_telemetry event=scheduler_job_start job=poller_graduated')
        timeout_seconds = max(30, int(getattr(settings, 'graduated_job_timeout_seconds', 180) or 180))
        async with AsyncSessionLocal() as session:
            pipeline = Pipeline(session)
            try:
                results = await asyncio.wait_for(pipeline.run_graduated_once(), timeout=timeout_seconds)
            except asyncio.TimeoutError:
                logger.warning(
                    'pump_telemetry event=scheduler_job_timeout job=poller_graduated timeout=%s',
                    timeout_seconds,
                )
                raise
            for item in results:
                print(item)
        logger.info('pump_telemetry event=scheduler_job_done job=poller_graduated results=%s', len(results))

    jobs = [
        ScheduledJobDefinition('poller_pump_fast', settings.pumpfun_poll_interval_seconds, _poll_pump_fast_lane),
        ScheduledJobDefinition(
            'poller_graduated',
            settings.graduated_early_catch_poll_interval_seconds if settings.enable_graduated_early_catch else settings.graduated_poll_interval_seconds,
            _poll_graduated,
            enabled=settings.enable_graduated_intake,
        ),
        ScheduledJobDefinition('poller_ingest', settings.poll_interval_seconds, _poll_and_evaluate),
        ScheduledJobDefinition('graph_scoring', settings.graph_job_interval_seconds, lambda: run_graph_jobs_once(AsyncSessionLocal)),
        ScheduledJobDefinition('outcome_tracker', settings.outcome_tracker_interval_seconds, lambda: run_outcome_tracker(AsyncSessionLocal)),
        ScheduledJobDefinition('threshold_calibrator', settings.threshold_calibrator_interval_seconds, lambda: run_threshold_calibration(AsyncSessionLocal)),
        ScheduledJobDefinition('gem_calibrator', settings.threshold_calibrator_interval_seconds, lambda: run_gem_calibration(AsyncSessionLocal)),
        ScheduledJobDefinition('price_monitor', settings.price_monitor_interval_seconds, lambda: run_price_monitor(AsyncSessionLocal)),
        # paper_trading_tick is executed in a dedicated loop below so it is not blocked
        # by long-running polling jobs such as poller_graduated.
        ScheduledJobDefinition(
            'pulse_health_check',
            settings.pulse_health_check_interval_seconds,
            run_pulse_health_check,
            enabled=settings.pulse_health_enabled,
        ),
        ScheduledJobDefinition(
            'live_recovery',
            settings.live_state_transition_ttl_seconds,
            lambda: run_live_recovery(AsyncSessionLocal),
            enabled=settings.live_recovery_enabled or settings.paper_trading_enabled,
        ),
        ScheduledJobDefinition(
            'review_reeval',
            300,
            lambda: run_review_reeval(AsyncSessionLocal),
            enabled=settings.paper_trading_enabled,
        ),
        ScheduledJobDefinition(
            'approve_watcher',
            120,  # кожні 2 хвилини підхоплює нові APPROVE і ставить в watching
            lambda: run_approve_watcher(AsyncSessionLocal),
            enabled=settings.paper_trading_enabled,
        ),
        ScheduledJobDefinition(
            'farm_mode_tick',
            settings.farm_mode_tick_seconds,
            lambda: run_farm_mode_tick(AsyncSessionLocal),
            enabled=settings.farm_mode_enabled,
        ),
    ]
    async def _paper_trading_loop() -> None:
        if not settings.paper_trading_enabled:
            logger.info('pump_telemetry event=scheduler_job_disabled job=paper_trading_tick reason=paper_trading_disabled')
            return
        interval = max(2, int(settings.paper_trading_tick_seconds or 2))
        while True:
            try:
                logger.info('pump_telemetry event=scheduler_job_start job=paper_trading_tick')
                async with AsyncSessionLocal() as session:
                    from app.services.pulse.paper_trader import PaperTrader
                    trader = PaperTrader(session)
                    events = await trader.tick()
                    for event in events:
                        logger.info(
                            'pulse_paper_trade event=%s token=%s reason=%s pnl_pct=%.1f',
                            event.get('action'),
                            event.get('token'),
                            event.get('reason'),
                            float(event.get('pnl_pct', 0.0) or 0.0),
                        )
                    await session.commit()
                logger.info('pump_telemetry event=scheduler_job_done job=paper_trading_tick results=%s', len(events))
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                logger.exception('paper_trading_tick failed: %s', exc)
            await asyncio.sleep(interval)

    async def _watchlist_snapshot_loop() -> None:
        if not settings.paper_trading_enabled:
            logger.info('pump_telemetry event=scheduler_job_disabled job=watchlist_snapshot reason=paper_trading_disabled')
            return
        interval = max(5, int(getattr(settings, 'watchlist_poll_interval_seconds', 30) or 30))
        while True:
            try:
                logger.info('pump_telemetry event=scheduler_job_start job=watchlist_snapshot')
                async with AsyncSessionLocal() as session:
                    saved = await run_watchlist_snapshot_tick(session)
                    await session.commit()
                logger.info('pump_telemetry event=scheduler_job_done job=watchlist_snapshot results=%s', saved)
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                logger.exception('watchlist_snapshot failed: %s', exc)
            await asyncio.sleep(interval)

    paper_trading_task = asyncio.create_task(_paper_trading_loop())
    watchlist_snapshot_task = asyncio.create_task(_watchlist_snapshot_loop())
    try:
        await run_scheduler_forever(jobs)
    finally:
        paper_trading_task.cancel()
        watchlist_snapshot_task.cancel()
        with contextlib.suppress(Exception):
            await paper_trading_task
        with contextlib.suppress(Exception):
            await watchlist_snapshot_task


if __name__ == '__main__':
    configure_logging()
    init_error_and_tracing()
    mode = sys.argv[1] if len(sys.argv) > 1 else 'once'
    if mode == 'once':
        asyncio.run(run_once())
    elif mode == 'worker':
        asyncio.run(run_worker())
    elif mode == 'admin':
        run_admin()
    elif mode == 'poll':
        from app.pipeline.runner import run_polling_forever
        asyncio.run(run_polling_forever())
    elif mode == 'graph-jobs':
        asyncio.run(run_graph_jobs())
    elif mode == 'scheduler':
        asyncio.run(run_scheduler())
    else:
        raise SystemExit(f'unknown mode: {mode}')
