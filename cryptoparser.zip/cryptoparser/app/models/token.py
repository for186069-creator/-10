from __future__ import annotations

from datetime import datetime, timezone
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, Field


class Chain(StrEnum):
    SOLANA = 'solana'
    ETHEREUM = 'ethereum'
    BASE = 'base'
    BSC = 'bsc'


class TokenCandidate(BaseModel):
    chain: Chain
    token_address: str
    pair_address: str | None = None
    symbol: str | None = None
    name: str | None = None
    deployer_address: str | None = None
    creator_address: str | None = None
    first_seen_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    liquidity_usd: float | None = None
    fdv_usd: float | None = None
    market_cap_usd: float | None = None
    holders: int | None = None
    website: str | None = None
    x_handle: str | None = None
    telegram_url: str | None = None
    contract_verified: bool | None = None
    taxes_buy_pct: float | None = None
    taxes_sell_pct: float | None = None
    cooldown_until: datetime | None = None
    links: dict[str, str] = Field(default_factory=dict)
    raw: dict[str, Any] = Field(default_factory=dict)
    early_trades: list[dict[str, Any]] = Field(default_factory=list)


class SecurityReport(BaseModel):
    contract_verified: bool | None = None
    renounced: bool | None = None
    honeypot: bool | None = None
    can_sell: bool | None = None
    proxy: bool | None = None
    mint_enabled: bool | None = None
    blacklist_function: bool | None = None
    pause_function: bool | None = None
    owner_can_change_fee: bool | None = None
    owner_can_block_wallets: bool | None = None
    lp_locked_days: int | None = None
    top10_holder_pct: float | None = None
    mint_authority_none: bool | None = None
    freeze_authority_none: bool | None = None
    creator_wallet_malicious: bool | None = None
    creator_wallet_reputation: float | None = None
    deployer_wallet_reputation: float | None = None
    similarity_risk: float | None = None
    cluster_risk: float | None = None
    wash_trading_risk: float | None = None
    rugpull_risk: float | None = None
    malicious_address: bool | None = None
    bytecode_hash: str | None = None
    fingerprint_hash: str | None = None
    funding_wallet: str | None = None
    data_complete: bool = False
    sources: list[str] = Field(default_factory=list)
    reasons: list[str] = Field(default_factory=list)
    raw: dict[str, Any] = Field(default_factory=dict)


class SocialProfile(BaseModel):
    handle: str | None = None
    exists: bool | None = None
    account_age_days: int | None = None
    followers: int | None = None
    following: int | None = None
    tweets: int | None = None
    bio: str | None = None
    pinned_text: str | None = None
    website_link: str | None = None
    telegram_link: str | None = None
    engagement_rate: float | None = None
    contract_mentioned: bool | None = None
    suspicious: bool = False
    data_complete: bool = False
    source: str | None = None
    reasons: list[str] = Field(default_factory=list)
    raw: dict[str, Any] = Field(default_factory=dict)


class WebsiteProfile(BaseModel):
    url: str | None = None
    exists: bool | None = None
    https_ok: bool | None = None
    domain_age_days: int | None = None
    contains_contract: bool | None = None
    contains_x: bool | None = None
    contains_telegram: bool | None = None
    coherent_branding: bool | None = None
    broken_links: bool | None = None
    x_link: str | None = None
    telegram_link: str | None = None
    contract_mentions: list[str] = Field(default_factory=list)
    data_complete: bool = False
    reasons: list[str] = Field(default_factory=list)
    raw: dict[str, Any] = Field(default_factory=dict)


class BehaviorProfile(BaseModel):
    bundled_buy_detected: bool | None = None
    suspicious_liquidity_move: bool | None = None
    sniper_concentration: float | None = None
    wash_trading_risk: float | None = None
    suspicious: bool = False
    reasons: list[str] = Field(default_factory=list)
    raw: dict[str, Any] = Field(default_factory=dict)


class DeployerProfile(BaseModel):
    address: str
    launches_count: int = 0
    dead_tokens_count: int = 0
    rugs_count: int = 0
    avg_token_lifetime_days: float | None = None
    funding_wallet: str | None = None
    reputation_score: float = 50.0
    suspicious_patterns: list[str] = Field(default_factory=list)
    evidence: dict[str, Any] = Field(default_factory=dict)


class ContractFingerprint(BaseModel):
    chain: Chain
    token_address: str
    bytecode_hash: str | None = None
    fingerprint_hash: str | None = None
    selectors: list[str] = Field(default_factory=list)
    suspicious_selectors: list[str] = Field(default_factory=list)
    similarity_score: float = 0.0
    matched_template: str | None = None
    reasons: list[str] = Field(default_factory=list)


class WalletClusterProfile(BaseModel):
    cluster_id: str
    wallets: list[str] = Field(default_factory=list)
    risk_score: float = 0.0
    labels: list[str] = Field(default_factory=list)
    evidence: dict[str, Any] = Field(default_factory=dict)


class Decision(BaseModel):
    status: str
    score: float
    reasons: list[str] = Field(default_factory=list)
    subscores: dict[str, float] = Field(default_factory=dict)
    evidence: dict[str, Any] = Field(default_factory=dict)


class TokenSnapshot(BaseModel):
    candidate: TokenCandidate
    security: SecurityReport
    social: SocialProfile
    website: WebsiteProfile
    behavior: BehaviorProfile | None = None
    decision: Decision


class QueueMessage(BaseModel):
    chain: Chain
    token_address: str
    payload: dict[str, Any] = Field(default_factory=dict)
    attempts: int = 0
