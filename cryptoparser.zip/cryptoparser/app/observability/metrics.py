from __future__ import annotations

import asyncio
import time
from collections import defaultdict
from contextlib import asynccontextmanager

from app.core.config import settings


class MetricsRegistry:
    def __init__(self) -> None:
        self._counters: dict[str, float] = defaultdict(float)
        self._gauges: dict[str, float] = defaultdict(float)
        self._histograms: dict[str, list[float]] = defaultdict(list)
        self._lock = asyncio.Lock()

    async def incr(self, name: str, value: float = 1.0) -> None:
        async with self._lock:
            self._counters[name] += value

    async def set_gauge(self, name: str, value: float) -> None:
        async with self._lock:
            self._gauges[name] = value

    async def observe(self, name: str, value: float) -> None:
        async with self._lock:
            self._histograms[name].append(value)
            if len(self._histograms[name]) > 1000:
                self._histograms[name] = self._histograms[name][-1000:]

    @asynccontextmanager
    async def timer(self, name: str):
        started = time.perf_counter()
        try:
            yield
        finally:
            await self.observe(name, time.perf_counter() - started)

    async def snapshot(self) -> dict[str, dict[str, float | list[float]]]:
        async with self._lock:
            return {
                'counters': dict(self._counters),
                'gauges': dict(self._gauges),
                'histograms': {k: list(v) for k, v in self._histograms.items()},
            }

    async def render_prometheus(self) -> str:
        snap = await self.snapshot()
        lines: list[str] = []
        for kind in ('counters', 'gauges'):
            for key, value in snap[kind].items():
                metric = _sanitize(f'{settings.metrics_namespace}_{key}')
                metric_type = 'counter' if kind == 'counters' else 'gauge'
                lines.append(f'# TYPE {metric} {metric_type}')
                lines.append(f'{metric} {float(value):.6f}')
        for key, values in snap['histograms'].items():
            metric = _sanitize(f'{settings.metrics_namespace}_{key}_seconds')
            lines.append(f'# TYPE {metric} summary')
            if values:
                total = float(sum(values))
                count = len(values)
                lines.append(f'{metric}_count {count}')
                lines.append(f'{metric}_sum {total:.6f}')
                lines.append(f'{metric}{{quantile="0.5"}} {_quantile(values, 0.5):.6f}')
                lines.append(f'{metric}{{quantile="0.9"}} {_quantile(values, 0.9):.6f}')
                lines.append(f'{metric}{{quantile="0.99"}} {_quantile(values, 0.99):.6f}')
            else:
                lines.append(f'{metric}_count 0')
                lines.append(f'{metric}_sum 0')
        return '\n'.join(lines) + '\n'


def _sanitize(name: str) -> str:
    return ''.join(ch if ch.isalnum() or ch == '_' else '_' for ch in name)


def _quantile(values: list[float], q: float) -> float:
    ordered = sorted(values)
    if not ordered:
        return 0.0
    idx = int((len(ordered) - 1) * q)
    return float(ordered[idx])


METRICS = MetricsRegistry()
