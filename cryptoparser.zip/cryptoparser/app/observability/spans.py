from __future__ import annotations

from contextlib import asynccontextmanager, contextmanager
from typing import Any


def _get_tracer():
    try:  # pragma: no cover
        from opentelemetry import trace
        return trace.get_tracer('cryptoparser')
    except Exception:
        return None


@asynccontextmanager
async def async_span(name: str, **attributes: Any):
    tracer = _get_tracer()
    if tracer is None:
        yield None
        return
    with tracer.start_as_current_span(name) as span:
        for key, value in attributes.items():
            if value is not None:
                span.set_attribute(key, value)
        yield span


@contextmanager
def span(name: str, **attributes: Any):
    tracer = _get_tracer()
    if tracer is None:
        yield None
        return
    with tracer.start_as_current_span(name) as span_obj:
        for key, value in attributes.items():
            if value is not None:
                span_obj.set_attribute(key, value)
        yield span_obj
