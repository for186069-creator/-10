from __future__ import annotations

import logging

from app.core.config import settings

logger = logging.getLogger(__name__)


def init_error_and_tracing() -> None:
    _init_sentry()
    _init_opentelemetry()


def _init_sentry() -> None:
    if not settings.sentry_dsn:
        return
    try:
        import sentry_sdk
        from sentry_sdk.integrations.aiohttp import AioHttpIntegration
        from sentry_sdk.integrations.fastapi import FastApiIntegration
        from sentry_sdk.integrations.logging import LoggingIntegration
        from sentry_sdk.integrations.sqlalchemy import SqlalchemyIntegration
    except Exception as exc:  # pragma: no cover
        logger.warning('sentry_sdk unavailable: %s', exc)
        return
    sentry_sdk.init(
        dsn=settings.sentry_dsn,
        environment=settings.env,
        traces_sample_rate=settings.sentry_traces_sample_rate,
        integrations=[
            LoggingIntegration(level=None, event_level=None),
            AioHttpIntegration(),
            FastApiIntegration(),
            SqlalchemyIntegration(),
        ],
    )
    logger.info('sentry initialized')


def _init_opentelemetry() -> None:
    if not settings.enable_tracing or not settings.otlp_endpoint:
        return
    try:
        from opentelemetry import trace
        from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
        from opentelemetry.instrumentation.aiohttp_client import AioHttpClientInstrumentor
        from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
        from opentelemetry.instrumentation.sqlalchemy import SQLAlchemyInstrumentor
        from opentelemetry.sdk.resources import Resource
        from opentelemetry.sdk.trace import TracerProvider
        from opentelemetry.sdk.trace.export import BatchSpanProcessor
    except Exception as exc:  # pragma: no cover
        logger.warning('opentelemetry unavailable: %s', exc)
        return

    provider = TracerProvider(resource=Resource.create({'service.name': settings.otel_service_name, 'deployment.environment': settings.env}))
    provider.add_span_processor(BatchSpanProcessor(OTLPSpanExporter(endpoint=settings.otlp_endpoint)))
    trace.set_tracer_provider(provider)
    AioHttpClientInstrumentor().instrument()
    globals()['FastAPIInstrumentor'] = FastAPIInstrumentor
    globals()['SQLAlchemyInstrumentor'] = SQLAlchemyInstrumentor
    logger.info('opentelemetry initialized endpoint=%s', settings.otlp_endpoint)


def instrument_fastapi(app) -> None:
    if not settings.enable_tracing or not settings.otlp_endpoint:
        return
    try:  # pragma: no cover
        FastAPIInstrumentor.instrument_app(app)
    except Exception as exc:
        logger.warning('failed to instrument fastapi: %s', exc)


def instrument_sqlalchemy(engine) -> None:
    if not settings.enable_tracing or not settings.otlp_endpoint:
        return
    try:  # pragma: no cover
        SQLAlchemyInstrumentor().instrument(engine=engine.sync_engine)
    except Exception as exc:
        logger.warning('failed to instrument sqlalchemy: %s', exc)
