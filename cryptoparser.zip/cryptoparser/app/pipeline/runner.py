from __future__ import annotations

import asyncio

from app.core.config import settings
from app.db.base import AsyncSessionLocal
from app.db.init_db import init_db
from app.queue.service import QueueService
from app.services.pipeline import Pipeline
from app.queue.coordination import WorkerCoordinator
from app.observability.spans import async_span
from app.services.ops_alerts import OpsAlerter


async def run_polling_once() -> None:
    await init_db()
    queue = QueueService()
    async with AsyncSessionLocal() as session:
        pipeline = Pipeline(session, queue_service=queue)
        await pipeline.poll_and_enqueue()
    await asyncio.sleep(0)


async def run_pump_polling_once() -> None:
    await init_db()
    queue = QueueService()
    async with AsyncSessionLocal() as session:
        pipeline = Pipeline(session, queue_service=queue)
        await pipeline.poll_pump_and_enqueue()
    await asyncio.sleep(0)


async def run_graduated_polling_once() -> None:
    """Поллить pump.fun graduated токени на Raydium через DexScreener."""
    await init_db()
    queue = QueueService()
    async with AsyncSessionLocal() as session:
        pipeline = Pipeline(session, queue_service=queue)
        await pipeline.poll_graduated_and_enqueue()
    await asyncio.sleep(0)


async def run_polling_forever() -> None:
    coordinator = WorkerCoordinator('poller')
    ops_alerts = OpsAlerter()
    await coordinator.start()
    try:
        while True:
            async with coordinator.leader(settings.poller_leader_key) as acquired:
                if acquired:
                    try:
                        async with async_span('poller.run_once'):
                            await run_polling_once()
                    except asyncio.CancelledError:
                        raise
                    except Exception as exc:
                        await ops_alerts.notify_failure('poller', 'polling_failed', {'error': str(exc)})
            await asyncio.sleep(settings.poll_interval_seconds)
    except asyncio.CancelledError:
        pass
    finally:
        await coordinator.stop()
