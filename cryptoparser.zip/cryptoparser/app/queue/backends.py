from __future__ import annotations

import asyncio
import json
from collections import defaultdict
from typing import Protocol

from app.models.token import QueueMessage

try:
    import redis.asyncio as redis
except Exception:  # pragma: no cover
    redis = None


class QueueBackend(Protocol):
    async def push(self, queue_name: str, message: QueueMessage) -> None: ...
    async def pop(self, queue_name: str, timeout: int = 1) -> QueueMessage | None: ...


class InMemoryQueueBackend:
    def __init__(self) -> None:
        self.queues: dict[str, asyncio.Queue[QueueMessage]] = defaultdict(asyncio.Queue)

    async def push(self, queue_name: str, message: QueueMessage) -> None:
        await self.queues[queue_name].put(message)

    async def pop(self, queue_name: str, timeout: int = 1) -> QueueMessage | None:
        queue = self.queues[queue_name]
        if timeout <= 0:
            try:
                return queue.get_nowait()
            except asyncio.QueueEmpty:
                return None
        try:
            return await asyncio.wait_for(queue.get(), timeout=timeout)
        except TimeoutError:
            return None


class RedisQueueBackend:
    def __init__(self, redis_url: str) -> None:
        if redis is None:
            raise RuntimeError('redis package is not installed')
        self.client = redis.from_url(redis_url, decode_responses=True)

    async def push(self, queue_name: str, message: QueueMessage) -> None:
        await self.client.lpush(queue_name, message.model_dump_json())

    async def pop(self, queue_name: str, timeout: int = 1) -> QueueMessage | None:
        if timeout <= 0:
            payload = await self.client.rpop(queue_name)
            return QueueMessage.model_validate(json.loads(payload)) if payload else None
        result = await self.client.brpop(queue_name, timeout=timeout)
        if not result:
            return None
        _, payload = result
        return QueueMessage.model_validate(json.loads(payload))
