from __future__ import annotations

import asyncio
import os
import socket
import time
import uuid
from contextlib import asynccontextmanager

from app.core.config import settings
from app.observability.metrics import METRICS
from app.utils.locks import REDIS_LOCKS

try:  # pragma: no cover
    import redis.asyncio as redis
except Exception:  # pragma: no cover
    redis = None


class WorkerCoordinator:
    def __init__(self, role: str) -> None:
        self.role = role
        self.worker_id = f'{role}:{socket.gethostname()}:{os.getpid()}:{uuid.uuid4().hex[:8]}'
        self._stopped = asyncio.Event()
        self._heartbeat_task: asyncio.Task | None = None
        self._redis = redis.from_url(settings.redis_url, decode_responses=True) if (redis and settings.worker_coordination_enabled) else None

    @property
    def workers_key(self) -> str:
        return f'cryptoparser:workers:{self.role}'

    async def start(self) -> None:
        if settings.worker_coordination_enabled and self._redis is not None:
            self._heartbeat_task = asyncio.create_task(self._heartbeat_loop())

    async def stop(self) -> None:
        self._stopped.set()
        if self._heartbeat_task:
            self._heartbeat_task.cancel()
            try:
                await self._heartbeat_task
            except Exception:
                pass
        if self._redis is not None:
            await self._redis.hdel(self.workers_key, self.worker_id)

    async def _heartbeat_loop(self) -> None:
        while not self._stopped.is_set():
            payload = {'worker_id': self.worker_id, 'ts': str(time.time()), 'role': self.role}
            await self._redis.hset(self.workers_key, self.worker_id, str(payload))
            await self._redis.expire(self.workers_key, settings.worker_heartbeat_ttl_seconds * 2)
            await METRICS.set_gauge(f'{self.role}_worker_heartbeat', time.time())
            try:
                await asyncio.wait_for(self._stopped.wait(), timeout=settings.worker_heartbeat_interval_seconds)
            except asyncio.TimeoutError:
                continue

    async def active_workers(self) -> list[str]:
        if self._redis is None:
            return [self.worker_id]
        data = await self._redis.hkeys(self.workers_key)
        return sorted(data)

    @asynccontextmanager
    async def leader(self, key: str):
        if not settings.worker_coordination_enabled or REDIS_LOCKS is None:
            yield True
            return
        async with REDIS_LOCKS.acquire(key, ttl_seconds=settings.worker_heartbeat_ttl_seconds, wait_timeout=0.25) as acquired:
            yield acquired

    @asynccontextmanager
    async def processing_slot(self, token_key: str):
        lock_key = f'processing:{token_key}'
        if not settings.worker_coordination_enabled or REDIS_LOCKS is None:
            yield True
            return
        async with REDIS_LOCKS.acquire(lock_key, ttl_seconds=settings.processing_lock_ttl_seconds, wait_timeout=0.05) as acquired:
            if not acquired:
                await METRICS.incr('worker_duplicate_skips_total')
            yield acquired
