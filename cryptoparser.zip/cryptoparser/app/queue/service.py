from __future__ import annotations

import logging

from app.core.config import settings
from app.models.token import QueueMessage
from app.queue.backends import InMemoryQueueBackend, QueueBackend, RedisQueueBackend


logger = logging.getLogger(__name__)


class QueueService:
    def __init__(self, backend: QueueBackend | None = None) -> None:
        if backend is not None:
            self.backend = backend
        elif settings.use_redis_queue:
            self.backend = RedisQueueBackend(settings.redis_url)
        else:
            self.backend = InMemoryQueueBackend()

    async def enqueue_ingest(self, message: QueueMessage, *, fast: bool = False) -> None:
        queue_name = settings.queue_name_ingest_fast if fast else settings.queue_name_ingest
        await self.backend.push(queue_name, message)
        family = ((message.payload or {}).get('raw') or {}).get('token_family')
        if message.chain == 'solana' and (family == 'pump_suffix' or str(message.token_address).endswith('pump')):
            logger.info('pump_telemetry event=queue_push mint=%s queue=%s attempts=%s', message.token_address, queue_name, message.attempts)

    async def enqueue_review(self, message: QueueMessage) -> None:
        await self.backend.push(settings.queue_name_review, message)

    async def pop_ingest(self) -> QueueMessage | None:
        msg = await self.backend.pop(settings.queue_name_ingest_fast, timeout=0)
        if msg is not None:
            family = ((msg.payload or {}).get('raw') or {}).get('token_family')
            if msg.chain == 'solana' and (family == 'pump_suffix' or str(msg.token_address).endswith('pump')):
                logger.info('pump_telemetry event=queue_pop mint=%s queue=%s attempts=%s', msg.token_address, settings.queue_name_ingest_fast, msg.attempts)
            return msg
        msg = await self.backend.pop(settings.queue_name_ingest)
        if msg is not None:
            family = ((msg.payload or {}).get('raw') or {}).get('token_family')
            if msg.chain == 'solana' and (family == 'pump_suffix' or str(msg.token_address).endswith('pump')):
                logger.info('pump_telemetry event=queue_pop mint=%s queue=%s attempts=%s', msg.token_address, settings.queue_name_ingest, msg.attempts)
        return msg

    async def pop_review(self) -> QueueMessage | None:
        return await self.backend.pop(settings.queue_name_review)
