from __future__ import annotations

import asyncio
import logging

from app.core.config import settings
from app.db.base import AsyncSessionLocal
from app.models.token import QueueMessage, TokenCandidate
from app.services.orchestrator import Orchestrator
from app.observability.metrics import METRICS
from app.queue.coordination import WorkerCoordinator
from app.observability.spans import async_span
from app.services.ops_alerts import OpsAlerter

logger = logging.getLogger(__name__)


class QueueWorker:
    def __init__(self, queue_service) -> None:
        self.queue = queue_service
        self.coordinator = WorkerCoordinator('worker')
        self.ops_alerts = OpsAlerter()


    @staticmethod
    def _is_pump_message(msg: QueueMessage) -> bool:
        raw = ((msg.payload or {}).get('raw') or {})
        return msg.chain == 'solana' and (raw.get('token_family') == 'pump_suffix' or str(msg.token_address).endswith('pump'))

    async def run_forever(self) -> None:
        await self.coordinator.start()
        try:
            while True:
                msg = await self.queue.pop_ingest()
                if not msg:
                    await asyncio.sleep(settings.worker_sleep_seconds)
                    continue
                async with self.coordinator.processing_slot(f'{msg.chain}:{msg.token_address}') as acquired:
                    if not acquired:
                        continue
                    await self._handle(msg)
        finally:
            await self.coordinator.stop()

    async def _handle(self, msg: QueueMessage) -> None:
        async with AsyncSessionLocal() as session:
            orchestrator = Orchestrator(session)
            try:
                if self._is_pump_message(msg):
                    logger.info('pump_telemetry event=worker_start mint=%s attempts=%s', msg.token_address, msg.attempts)
                async with async_span('worker.handle', chain=msg.chain, token_address=msg.token_address, attempts=msg.attempts):
                    async with METRICS.timer('worker_handle'):
                        candidate = TokenCandidate.model_validate(msg.payload)
                        decision = await orchestrator.evaluate(candidate)
                        if decision is None:
                            # Invalid address filtered at orchestrator entry — skip silently
                            return
                        if self._is_pump_message(msg):
                            logger.info('pump_telemetry event=worker_done mint=%s status=%s score=%s reasons=%s', msg.token_address, decision.status, round(decision.score, 6), ' | '.join(decision.reasons[:6]))
            except Exception as exc:
                await METRICS.incr('worker_failures_total')
                logger.exception('worker_failed token=%s attempts=%s', msg.token_address, msg.attempts)
                if self._is_pump_message(msg):
                    logger.error('pump_telemetry event=worker_error mint=%s attempts=%s error=%s', msg.token_address, msg.attempts, str(exc))
                await self.ops_alerts.notify_failure('worker', 'worker_handle_failed', {'token_address': msg.token_address, 'chain': msg.chain, 'attempts': msg.attempts, 'error': str(exc)})
                if msg.attempts + 1 < settings.max_retry_attempts:
                    retry = QueueMessage(chain=msg.chain, token_address=msg.token_address, payload=msg.payload, attempts=msg.attempts + 1)
                    await asyncio.sleep(settings.base_retry_delay_seconds * (msg.attempts + 1))
                    await self.queue.enqueue_ingest(retry)
                else:
                    raise exc
