from __future__ import annotations

from app.core.config import settings
from app.models.token import BehaviorProfile, Decision, SecurityReport, SocialProfile, TokenCandidate, WebsiteProfile
from app.risk.rules import advisory_reasons, hard_fail, weighted_score
from app.utils.token_classifier import classify_decision_profile


class RiskEngine:
    def evaluate(self, candidate: TokenCandidate, security: SecurityReport, social: SocialProfile, website: WebsiteProfile, behavior: BehaviorProfile | None = None) -> Decision:
        profile_meta = classify_decision_profile(candidate.chain.value, candidate.token_address, candidate.raw, candidate.first_seen_at)
        decision_profile = str(profile_meta.get('decision_profile') or 'standard')
        reasons = hard_fail(candidate, security, social, website, behavior)
        advisory = advisory_reasons(candidate, security, social, website, behavior)
        score, subscores = weighted_score(candidate, security, social, website, behavior)
        if decision_profile == 'pump_early':
            approve_score = settings.pump_early_approve_score
            review_score  = settings.pump_early_review_score
        elif decision_profile == 'pump_graduated':
            approve_score = settings.pump_graduated_approve_score
            review_score  = settings.pump_graduated_review_score
        else:
            approve_score = settings.approve_score
            review_score  = settings.review_score
        evidence = {
            'security_sources': security.sources,
            'security_reasons': security.reasons,
            'social_reasons': social.reasons,
            'website_reasons': website.reasons,
            'behavior_reasons': behavior.reasons if behavior else [],
            'decision_profile': decision_profile,
            'profile_meta': profile_meta,
            'advisory_reasons': advisory,
        }
        if reasons:
            return Decision(status='REJECT', score=score, reasons=reasons, subscores=subscores, evidence=evidence)
        if score >= approve_score:
            return Decision(status='APPROVE', score=score, reasons=[], subscores=subscores, evidence=evidence)
        if score >= review_score:
            if decision_profile == 'pump_early':
                review_reason = 'pump_early_monitor'
            elif decision_profile == 'pump_graduated':
                review_reason = 'pump_graduated_monitor'
            else:
                review_reason = 'score_below_approve'
            return Decision(status='REVIEW_LATER', score=score, reasons=[review_reason], subscores=subscores, evidence=evidence)
        if decision_profile == 'pump_early':
            reject_reason = 'pump_early_score_too_low'
        elif decision_profile == 'pump_graduated':
            reject_reason = 'pump_graduated_score_too_low'
        else:
            reject_reason = 'score_too_low'
        return Decision(status='REJECT', score=score, reasons=[reject_reason], subscores=subscores, evidence=evidence)
