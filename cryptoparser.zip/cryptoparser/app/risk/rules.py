from __future__ import annotations

from app.core.config import settings
from app.models.token import BehaviorProfile, Chain, SecurityReport, SocialProfile, TokenCandidate, WebsiteProfile
from app.utils.graduated_quality import extract_graduated_metrics, has_holders_signal
from app.utils.text import normalize_handle, normalize_url
from app.utils.token_classifier import classify_decision_profile


def _evm_website_social_coherent(candidate: TokenCandidate, website: WebsiteProfile) -> tuple[bool, bool]:
    expected_x = normalize_handle(candidate.x_handle)
    expected_tg = normalize_url(candidate.telegram_url)
    website_x = normalize_handle(website.x_link)
    website_tg = normalize_url(website.telegram_link)
    x_ok = True
    tg_ok = True
    if expected_x:
        x_ok = bool(website_x and website_x.lower() == expected_x.lower())
    if expected_tg:
        tg_ok = bool(website_tg and website_tg.lower() == expected_tg.lower())
    return x_ok, tg_ok


def hard_fail(
    candidate: TokenCandidate,
    security: SecurityReport,
    social: SocialProfile,
    website: WebsiteProfile,
    behavior: BehaviorProfile | None = None,
) -> list[str]:
    reasons: list[str] = []
    profile_meta = classify_decision_profile(candidate.chain.value, candidate.token_address, candidate.raw, candidate.first_seen_at)
    is_pump_early = bool(profile_meta.get('is_pump_early'))
    is_pump_graduated = bool(profile_meta.get('is_pump_graduated'))

    if not security.data_complete and not is_pump_early:
        reasons.append('missing_security_data')

    if candidate.chain in {Chain.ETHEREUM, Chain.BASE, Chain.BSC}:
        if security.contract_verified is not True:
            reasons.append('contract_not_verified')
        if security.honeypot is not False:
            reasons.append('honeypot_or_unknown')
        if security.can_sell is not True:
            reasons.append('cannot_sell_or_unknown')
        if security.renounced is not True:
            reasons.append('owner_not_renounced')
        if security.proxy is True:
            reasons.append('proxy_contract')
        if security.mint_enabled is True:
            reasons.append('mint_enabled')
        if security.blacklist_function is True:
            reasons.append('blacklist_function_present')
        if security.pause_function is True:
            reasons.append('pause_function_present')
        if security.owner_can_change_fee is True:
            reasons.append('owner_can_change_fee')
        if security.owner_can_block_wallets is True:
            reasons.append('owner_can_block_wallets')
        if (candidate.taxes_buy_pct or 0) > settings.max_tax_pct:
            reasons.append('buy_tax_too_high')
        if (candidate.taxes_sell_pct or 0) > settings.max_tax_pct:
            reasons.append('sell_tax_too_high')
        if (security.lp_locked_days or 0) < 180:
            reasons.append('lp_not_locked_180d')
    else:
        # FIX BUG 4: tax check was missing for Solana — added here
        if (candidate.taxes_buy_pct or 0) > settings.max_tax_pct:
            reasons.append('buy_tax_too_high')
        if (candidate.taxes_sell_pct or 0) > settings.max_tax_pct:
            reasons.append('sell_tax_too_high')
        if is_pump_early:
            if security.mint_authority_none is False:
                reasons.append('mint_authority_exists')
            if security.freeze_authority_none is False:
                reasons.append('freeze_authority_exists')
            if security.creator_wallet_malicious is True:
                reasons.append('creator_wallet_malicious')
            if (security.top10_holder_pct or 0) > settings.pump_early_max_top10_holder_pct:
                reasons.append('holder_concentration')
        else:
            if security.mint_authority_none is not True:
                reasons.append('mint_authority_exists')
            if security.freeze_authority_none is not True:
                reasons.append('freeze_authority_exists')
            if security.creator_wallet_malicious is True:
                reasons.append('creator_wallet_malicious')
            top10 = security.top10_holder_pct
            if is_pump_graduated:
                if top10 is not None and float(top10) > float(settings.pump_graduated_max_top10_holder_pct):
                    reasons.append('holder_concentration')
            else:
                if (top10 or 100) > 25:
                    reasons.append('holder_concentration')

    _source = (candidate.raw or {}).get('source') or 'dexscreener'
    _min_liq, _min_h_evm, _min_h_sol = settings.thresholds_for_source(_source)
    if not is_pump_early:
        if is_pump_graduated:
            # Для pump_graduated жорсткі вимоги тільки по security.
            # Соціальні/сайт — advisory (впливають на score, але не REJECT).
            # Токен вже graduated = підтвердив себе liquidity і volume на Raydium.
            if (candidate.liquidity_usd or 0) < settings.pump_graduated_min_liquidity:
                reasons.append('low_liquidity')
            metrics = extract_graduated_metrics(candidate.raw or {}, liquidity_fallback=float(candidate.liquidity_usd or 0.0))
            if not has_holders_signal(candidate.holders, metrics['txns_24h'], settings, candidate.chain.value):
                reasons.append('low_holders')
            # x_not_found / website issues → НЕ hard_fail для graduated
        else:
            if (candidate.liquidity_usd or 0) < _min_liq:
                reasons.append('low_liquidity')
            _min_holders = _min_h_sol if candidate.chain == Chain.SOLANA else _min_h_evm
            if (candidate.holders or 0) < _min_holders:
                reasons.append('low_holders')
            if social.exists is not True:
                reasons.append('x_not_found')
            if not social.data_complete:
                reasons.append('missing_x_data')
            if (social.account_age_days or 0) < settings.min_x_age_days:
                reasons.append('x_too_new')
            if (social.followers or 0) < settings.min_x_followers:
                reasons.append('x_followers_too_low')
            if (social.tweets or 0) < settings.min_x_tweets:
                reasons.append('x_tweets_too_low')
            if social.contract_mentioned is not True:
                reasons.append('x_missing_contract_mention')
            if not candidate.website:
                reasons.append('missing_website')
            if website.exists is not True:
                reasons.append('website_not_reachable')
            if not website.data_complete:
                reasons.append('missing_website_data')
            if website.https_ok is not True:
                reasons.append('website_not_https')
            if (website.domain_age_days or 0) < settings.min_domain_age_days:
                reasons.append('domain_too_new_or_unknown')
            if website.contains_contract is not True:
                reasons.append('website_missing_contract')
            if website.contains_x is not True:
                reasons.append('website_missing_x')
            if website.contains_telegram is not True:
                reasons.append('website_missing_telegram')

        if is_pump_graduated and candidate.chain in {Chain.ETHEREUM, Chain.BASE, Chain.BSC}:
            x_ok, tg_ok = _evm_website_social_coherent(candidate, website)
            if not x_ok:
                reasons.append('website_x_brand_mismatch')
            if not tg_ok:
                reasons.append('website_telegram_brand_mismatch')

    if security.deployer_wallet_reputation is not None and security.deployer_wallet_reputation < 25:
        reasons.append('deployer_reputation_too_low')
    if security.similarity_risk is not None and security.similarity_risk >= 80:
        reasons.append('scam_contract_similarity')
    if security.cluster_risk is not None and security.cluster_risk >= 80:
        reasons.append('malicious_wallet_cluster')
    if security.wash_trading_risk is not None and security.wash_trading_risk >= 80:
        reasons.append('wash_trading_detected')
    if behavior and behavior.bundled_buy_detected:
        reasons.append('bundled_buy_detected')

    return sorted(set(reasons))


def advisory_reasons(
    candidate: TokenCandidate,
    security: SecurityReport,
    social: SocialProfile,
    website: WebsiteProfile,
    behavior: BehaviorProfile | None = None,
) -> list[str]:
    reasons: list[str] = []
    _source = (candidate.raw or {}).get('source') or 'dexscreener'
    _min_liq, _min_h_evm, _min_h_sol = settings.thresholds_for_source(_source)
    if (candidate.liquidity_usd or 0) < _min_liq:
        reasons.append('low_liquidity')
    _min_holders = _min_h_sol if candidate.chain == Chain.SOLANA else _min_h_evm
    if (candidate.holders or 0) < _min_holders:
        reasons.append('low_holders')
    if social.exists is not True:
        reasons.append('x_not_found')
    if not social.data_complete:
        reasons.append('missing_x_data')
    if (social.account_age_days or 0) < settings.min_x_age_days:
        reasons.append('x_too_new')
    if (social.followers or 0) < settings.min_x_followers:
        reasons.append('x_followers_too_low')
    if (social.tweets or 0) < settings.min_x_tweets:
        reasons.append('x_tweets_too_low')
    if social.contract_mentioned is not True:
        reasons.append('x_missing_contract_mention')
    if not candidate.website:
        reasons.append('missing_website')
    if website.exists is not True:
        reasons.append('website_not_reachable')
    if not website.data_complete:
        reasons.append('missing_website_data')
    if website.https_ok is not True:
        reasons.append('website_not_https')
    if (website.domain_age_days or 0) < settings.min_domain_age_days:
        reasons.append('domain_too_new_or_unknown')
    if website.contains_contract is not True:
        reasons.append('website_missing_contract')
    if website.contains_x is not True:
        reasons.append('website_missing_x')
    if website.contains_telegram is not True:
        reasons.append('website_missing_telegram')
    if behavior and behavior.bundled_buy_detected:
        reasons.append('bundled_buy_detected')
    return sorted(set(reasons))


def weighted_score(
    candidate: TokenCandidate,
    security: SecurityReport,
    social: SocialProfile,
    website: WebsiteProfile,
    behavior: BehaviorProfile | None = None,
) -> tuple[float, dict[str, float]]:
    subscores = {
        'contract_security': _score_contract(candidate, security),
        'liquidity': min((candidate.liquidity_usd or 0) / 5000.0, 15.0),
        'holders': min((candidate.holders or 0) / 20.0, 10.0),
        'social': _score_social(social),
        'website': _score_website(website),
        'reputation': 10.0 if (security.deployer_wallet_reputation or 50) >= 70 else max((security.deployer_wallet_reputation or 50) / 10.0, 0),
        'similarity': max(10.0 - ((security.similarity_risk or 0) / 10.0), 0.0),
        'cluster': max(10.0 - ((security.cluster_risk or 0) / 10.0), 0.0),
        'behavior': _score_behavior(behavior),
    }
    return round(sum(subscores.values()), 2), subscores


def _score_contract(candidate: TokenCandidate, security: SecurityReport) -> float:
    if candidate.chain == Chain.SOLANA:
        score = 0.0
        if security.mint_authority_none:
            score += 10
        if security.freeze_authority_none:
            score += 10
        if (security.top10_holder_pct or 100) <= 20:
            score += 5
        return score

    score = 0.0
    if security.contract_verified:
        score += 5
    if security.renounced:
        score += 5
    if security.honeypot is False:
        score += 5
    if security.can_sell is True:
        score += 5
    if security.proxy is False or security.proxy is None:
        score += 3
    if security.mint_enabled is False or security.mint_enabled is None:
        score += 3
    if security.blacklist_function is False or security.blacklist_function is None:
        score += 2
    if security.owner_can_change_fee is False or security.owner_can_change_fee is None:
        score += 2
    return score


def _score_social(social: SocialProfile) -> float:
    score = 0.0
    if (social.account_age_days or 0) >= 180:
        score += 5
    if (social.followers or 0) >= 5000:
        score += 5
    if (social.tweets or 0) >= 100:
        score += 5
    if social.contract_mentioned:
        score += 2
    if social.website_link:
        score += 2
    if social.telegram_link:
        score += 1
    if (social.engagement_rate or 0) >= 1.0:
        score += 5
    return score


def _score_website(website: WebsiteProfile) -> float:
    score = 0.0
    if website.exists:
        score += 4
    if website.https_ok:
        score += 3
    if (website.domain_age_days or 0) >= 60:
        score += 4
    if website.contains_contract:
        score += 3
    if website.contains_x:
        score += 3
    if website.contains_telegram:
        score += 3
    return score


def _score_behavior(behavior: BehaviorProfile | None) -> float:
    if behavior is None:
        return 5.0
    score = 10.0
    if behavior.bundled_buy_detected:
        score -= 6.0
    if behavior.suspicious_liquidity_move:
        score -= 4.0
    if (behavior.wash_trading_risk or 0) >= 80:
        score -= 4.0
    return max(score, 0.0)
