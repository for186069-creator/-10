from __future__ import annotations

import re
from datetime import datetime, timezone
from urllib.parse import urlparse

from bs4 import BeautifulSoup

from app.core.config import settings
from app.models.token import WebsiteProfile
from app.utils.http import HttpClient
from app.utils.text import contains_address, normalize_url


class WebsiteScraper:
    def __init__(self) -> None:
        self.http = HttpClient()

    async def fetch_profile(self, url: str | None, contract_address: str | None) -> WebsiteProfile:
        url = normalize_url(url)
        profile = WebsiteProfile(url=url)
        if not url:
            profile.reasons.append('missing_website_url')
            return profile
        try:
            html = await self.http.get_text(url)
            text = BeautifulSoup(html, 'html.parser').get_text(' ', strip=True)
            profile.exists = True
            profile.https_ok = urlparse(url).scheme == 'https'
            profile.contains_contract = contains_address(text, contract_address)
            profile.x_link = _find(r"https?://(?:x\.com|twitter\.com)/[^\s\"']+", html)
            profile.telegram_link = _find(r"https?://t\.me/[^\s\"']+", html)
            profile.contains_x = bool(profile.x_link)
            profile.contains_telegram = bool(profile.telegram_link)
            profile.coherent_branding = bool(re.search(r'(whitepaper|roadmap|tokenomics|contract|team|faq)', text, flags=re.IGNORECASE))
            profile.broken_links = False
            profile.contract_mentions = _all_contract_mentions(text)
            profile.domain_age_days = await self._domain_age_days(url)
            profile.data_complete = True
            profile.raw = {'title_present': '<title>' in html.lower()}
        except Exception as exc:
            profile.exists = False
            profile.reasons.append(f'website_fetch_error:{type(exc).__name__}')
        return profile

    async def _domain_age_days(self, url: str) -> int | None:
        try:
            parsed = urlparse(url)
            domain = parsed.netloc
            data = await self.http.get_json(f"{settings.domain_age_api_base.rstrip('/')}/{domain}")
            events = data.get('events') or []
            for event in events:
                if event.get('eventAction') in {'registration', 'last changed', 'registration period start'}:
                    date_str = event.get('eventDate')
                    if date_str:
                        dt = datetime.fromisoformat(date_str.replace('Z', '+00:00'))
                        return (datetime.now(timezone.utc) - dt).days
        except Exception:
            return None
        return None


def _find(pattern: str, text: str) -> str | None:
    match = re.search(pattern, text, flags=re.IGNORECASE)
    return match.group(0) if match else None


def _all_contract_mentions(text: str) -> list[str]:
    evm = re.findall(r'0x[a-fA-F0-9]{40}', text)
    sol = re.findall(r'\b[1-9A-HJ-NP-Za-km-z]{32,44}\b', text)
    return list(dict.fromkeys(evm + sol))[:20]
