from __future__ import annotations

import asyncio
import re
import time
from datetime import datetime, timezone

from bs4 import BeautifulSoup

from app.core.config import settings
from app.models.token import SocialProfile
from app.utils.http import HttpClient
from app.utils.providers import ProviderRotator
from app.utils.rate_limits import GLOBAL_RATE_BUDGET
from app.observability.spans import async_span
from app.utils.text import contains_address, normalize_handle

try:  # pragma: no cover
    from playwright.async_api import async_playwright
except Exception:  # pragma: no cover
    async_playwright = None


class XScraper:
    def __init__(self) -> None:
        self.http = HttpClient()
        self.rotator = ProviderRotator(settings.nitter_instances, cooldown_seconds=settings.provider_cooldown_seconds, weights=settings.nitter_provider_weights, quotas_per_minute=settings.nitter_provider_quotas)

    async def fetch_profile(self, handle: str | None, contract_address: str | None = None) -> SocialProfile:
        handle = normalize_handle(handle)
        profile = SocialProfile(handle=handle)
        if not handle:
            profile.reasons.append('missing_x_handle')
            return profile

        async with async_span('x.fetch_profile', handle=handle):
            for base in await self.rotator.ordered():
                quota = int(settings.nitter_provider_quotas.get(str(base), settings.provider_budget_group_quotas.get('nitter', settings.provider_default_quota_per_minute)))
                budget = await GLOBAL_RATE_BUDGET.consume('nitter', str(base), quota)
                if not budget.allowed:
                    continue
                try:
                    started = time.perf_counter()
                    html = await self.http.get_text(f'{base}/{handle}')
                    parsed = self._parse_html(html, handle, contract_address, source='nitter')
                    if parsed.exists:
                        await self.rotator.mark_success(base, latency_ms=(time.perf_counter() - started) * 1000)
                        return parsed
                    await self.rotator.mark_failure(base)
                except Exception as exc:
                    await self.rotator.mark_failure(base)
                    profile.reasons.append(f'nitter_error:{type(exc).__name__}')

        if settings.enable_playwright_fallback:
            playwright_profile = await self._fetch_with_playwright(handle, contract_address)
            if playwright_profile.exists:
                return playwright_profile
            profile.reasons.extend(playwright_profile.reasons)

        profile.exists = False
        return profile

    def _parse_html(self, html: str, handle: str, contract_address: str | None, source: str) -> SocialProfile:
        soup = BeautifulSoup(html, 'html.parser')
        text = soup.get_text(' ', strip=True)
        lower_text = text.lower()
        profile = SocialProfile(handle=handle, source=source)
        if 'not found' in lower_text or 'user has been suspended' in lower_text:
            profile.exists = False
            return profile

        profile.exists = True
        profile.account_age_days = _parse_joined_days(text)
        profile.followers = _search_metric(text, 'Followers')
        profile.following = _search_metric(text, 'Following')
        profile.tweets = _search_metric(text, 'Posts') or _search_metric(text, 'Tweets')
        bio = soup.select_one('.profile-bio')
        profile.bio = bio.get_text(' ', strip=True) if bio else None
        profile.website_link = _find_link(html, r'https?://(?!t\.me)[^\s"\']+')
        profile.telegram_link = _find_link(html, r'https?://t\.me/[^\s"\']+')
        pinned = soup.select_one('.timeline-item .tweet-content')
        profile.pinned_text = pinned.get_text(' ', strip=True) if pinned else None
        composite = ' '.join(filter(None, [profile.bio, profile.pinned_text, text]))
        profile.contract_mentioned = contains_address(composite, contract_address)
        profile.engagement_rate = _estimate_engagement(text, profile.followers)
        profile.data_complete = True
        if (profile.followers or 0) > 5000 and (profile.engagement_rate or 0.0) < 1.0:
            profile.suspicious = True
            profile.reasons.append('low_engagement_vs_followers')
        return profile

    async def _fetch_with_playwright(self, handle: str, contract_address: str | None) -> SocialProfile:
        profile = SocialProfile(handle=handle, source='playwright')
        if async_playwright is None:
            profile.reasons.append('playwright_not_installed')
            return profile
        url = f'https://x.com/{handle}'
        try:  # pragma: no cover
            async with async_playwright() as p:
                browser = await p.chromium.launch(headless=True)
                page = await browser.new_page()
                await page.goto(url, wait_until='domcontentloaded', timeout=20000)
                await asyncio.sleep(2)
                html = await page.content()
                await browser.close()
            parsed = self._parse_html(html, handle, contract_address, source='playwright')
            if parsed.account_age_days is None:
                parsed.reasons.append('playwright_partial_parse')
            return parsed
        except Exception as exc:
            profile.reasons.append(f'playwright_error:{type(exc).__name__}')
            return profile



def _parse_joined_days(text: str) -> int | None:
    match = re.search(r'Joined\s+([A-Za-z]{3,9})\s+(\d{4})', text)
    if not match:
        return None
    month_name, year = match.groups()
    for fmt in ('%d %b %Y', '%d %B %Y'):
        try:
            dt = datetime.strptime(f'1 {month_name} {year}', fmt).replace(tzinfo=timezone.utc)
            return (datetime.now(timezone.utc) - dt).days
        except ValueError:
            continue
    return None



def _search_metric(text: str, label: str) -> int | None:
    match = re.search(rf'([\d.,]+[KM]?)\s+{label}', text, flags=re.IGNORECASE)
    if not match:
        return None
    raw = match.group(1).replace(',', '')
    if raw.endswith('K'):
        return int(float(raw[:-1]) * 1000)
    if raw.endswith('M'):
        return int(float(raw[:-1]) * 1_000_000)
    try:
        return int(float(raw))
    except ValueError:
        return None



def _find_link(html: str, pattern: str) -> str | None:
    match = re.search(pattern, html, flags=re.IGNORECASE)
    return match.group(0) if match else None



def _estimate_engagement(text: str, followers: int | None) -> float | None:
    if not followers:
        return None
    likes = _search_metric(text, 'Likes') or 0
    reposts = _search_metric(text, 'Retweets') or _search_metric(text, 'Reposts') or 0
    replies = _search_metric(text, 'Replies') or 0
    interactions = likes + reposts + replies
    return round((interactions / max(followers, 1)) * 100.0, 4)
