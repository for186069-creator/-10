from __future__ import annotations

from collections import defaultdict, deque
from typing import Any


class AdvancedGraphScoringService:
    """Multi-hop graph scoring without external graph dependencies."""

    def score_wallet(
        self,
        root_wallet: str,
        edges: list[dict[str, Any]],
        node_risks: dict[str, float] | None = None,
        *,
        max_depth: int = 3,
    ) -> dict[str, Any]:
        node_risks = node_risks or {}
        adjacency: dict[str, list[tuple[str, float, str]]] = defaultdict(list)
        for edge in edges:
            src = edge.get('src_wallet')
            dst = edge.get('dst_wallet')
            weight = float(edge.get('weight') or 1.0)
            edge_type = edge.get('edge_type') or 'unknown'
            if src and dst:
                adjacency[src].append((dst, weight, edge_type))
                adjacency[dst].append((src, weight, edge_type))

        visited = {root_wallet}
        q = deque([(root_wallet, 0, 1.0)])
        path_count = 0
        score = 0.0
        suspicious_paths: list[dict[str, Any]] = []
        strongest_links: list[dict[str, Any]] = []

        while q:
            wallet, depth, path_weight = q.popleft()
            if depth >= max_depth:
                continue
            for neighbor, edge_weight, edge_type in adjacency.get(wallet, []):
                blended_weight = path_weight * min(1.0, edge_weight)
                risk = float(node_risks.get(neighbor, 0.0)) / 100.0
                increment = blended_weight * (0.35 + risk)
                score += increment
                path_count += 1
                strongest_links.append({
                    'wallet': neighbor,
                    'edge_type': edge_type,
                    'depth': depth + 1,
                    'weight': round(blended_weight, 4),
                    'neighbor_risk': round(risk * 100.0, 2),
                })
                if risk >= 0.6 or edge_type in {'funded_by', 'clustered_with', 'sniper_bundle'}:
                    suspicious_paths.append({
                        'from': wallet,
                        'to': neighbor,
                        'edge_type': edge_type,
                        'depth': depth + 1,
                        'weight': round(blended_weight, 4),
                    })
                if neighbor not in visited:
                    visited.add(neighbor)
                    q.append((neighbor, depth + 1, blended_weight * 0.8))

        strongest_links.sort(key=lambda item: (item['neighbor_risk'], item['weight']), reverse=True)
        suspicious_paths = suspicious_paths[:20]
        graph_score = min(100.0, round(score * 22.0, 2))
        return {
            'graph_score': graph_score,
            'reachable_wallets': len(visited) - 1,
            'path_count': path_count,
            'suspicious_paths': suspicious_paths,
            'strongest_links': strongest_links[:15],
        }
