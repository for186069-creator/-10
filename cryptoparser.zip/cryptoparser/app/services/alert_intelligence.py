from __future__ import annotations

from typing import Any

from app.models.token import TokenSnapshot


class AlertIntelligenceService:
    """Post-decision alert routing.

    The goal is to emit richer alerts than only APPROVE. This service classifies
    important state changes so operators can watch a token after launch.
    """

    def classify(self, snapshot: TokenSnapshot) -> list[dict[str, Any]]:
        events: list[dict[str, Any]] = []
        c = snapshot.candidate
        d = snapshot.decision
        b = snapshot.behavior
        s = snapshot.security

        if d.status == 'APPROVE' and d.score >= 85:
            events.append({'event': 'high_confidence_approval', 'severity': 'info'})
        if d.status == 'REVIEW_LATER' and d.score >= 70:
            events.append({'event': 'review_priority', 'severity': 'warning'})
        if b and b.suspicious_liquidity_move:
            events.append({'event': 'liquidity_shock', 'severity': 'critical'})
        if b and b.bundled_buy_detected:
            events.append({'event': 'sniper_bundle_detected', 'severity': 'warning'})
        if s.cluster_risk and s.cluster_risk >= 75:
            events.append({'event': 'malicious_cluster_link', 'severity': 'critical'})
        if s.similarity_risk and s.similarity_risk >= 80:
            events.append({'event': 'scam_family_similarity', 'severity': 'critical'})
        if c.liquidity_usd and c.liquidity_usd >= 100_000 and d.status != 'REJECT':
            events.append({'event': 'high_liquidity_new_launch', 'severity': 'info'})
        return events
