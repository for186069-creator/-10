from __future__ import annotations

from app.core.config import settings
from app.models.token import TokenSnapshot
from app.utils.http import HttpClient


class TelegramAlerter:
    def __init__(self) -> None:
        self.http = HttpClient()

    async def send(self, snapshot: TokenSnapshot) -> None:
        if not settings.enable_telegram or not settings.telegram_bot_token or not settings.telegram_chat_id:
            return
        url = f'https://api.telegram.org/bot{settings.telegram_bot_token}/sendMessage'
        await self.http.post_json(url, json={'chat_id': settings.telegram_chat_id, 'text': self._render(snapshot), 'disable_web_page_preview': True})

    def _render(self, snapshot: TokenSnapshot) -> str:
        c, d, s = snapshot.candidate, snapshot.decision, snapshot.security
        contract_status = s.renounced if c.chain.value != 'solana' else s.mint_authority_none
        lines = [
            f'✅ {d.status} | {c.chain.value.upper()} | {c.symbol or c.name or c.token_address}',
            f'Contract: {c.token_address}',
            f'Pair: {c.pair_address or "-"}',
            f'Liquidity: ${c.liquidity_usd or 0:,.0f}',
            f'Holders: {c.holders or 0}',
            f'Score: {d.score:.1f}',
            f'Contract safety: verified={s.contract_verified} renounced/mintNone={contract_status}',
            f'Website: {c.website or "-"}',
            f'X: @{c.x_handle or "-"}',
            f'Reasons: {", ".join(d.reasons[:8]) or "clean"}',
        ]
        return '\n'.join(lines)
