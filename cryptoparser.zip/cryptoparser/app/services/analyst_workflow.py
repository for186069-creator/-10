from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(slots=True)
class AnalystLabel:
    chain: str
    token_address: str
    label: str
    value: str
    analyst: str | None = None
    notes: str | None = None


class AnalystWorkflowService:
    ALLOWED_LABELS = {
        'outcome': {'legit', 'scam', 'needs_more_time', 'unclear'},
        'priority': {'low', 'medium', 'high', 'critical'},
        'action': {'approve_override', 'reject_override', 'watchlist'},
    }

    def validate(self, payload: dict[str, Any]) -> AnalystLabel:
        label = str(payload.get('label') or '').strip().lower()
        value = str(payload.get('value') or '').strip().lower()
        chain = str(payload.get('chain') or '').strip().lower()
        token_address = str(payload.get('token_address') or '').strip()
        analyst = payload.get('analyst')
        notes = payload.get('notes')
        if label not in self.ALLOWED_LABELS:
            raise ValueError('invalid_label')
        if value not in self.ALLOWED_LABELS[label]:
            raise ValueError('invalid_label_value')
        if not chain or not token_address:
            raise ValueError('missing_chain_or_token')
        return AnalystLabel(chain=chain, token_address=token_address, label=label, value=value, analyst=analyst, notes=notes)
