from __future__ import annotations

from app.models.token import BehaviorProfile, SecurityReport, TokenCandidate


class BehaviorService:
    def analyze(self, candidate: TokenCandidate, report: SecurityReport) -> BehaviorProfile:
        profile = BehaviorProfile()
        liquidity = float(candidate.liquidity_usd or 0)
        holders   = int(candidate.holders or 0)
        chain     = str(getattr(candidate, 'chain', '') or '').lower()
        if hasattr(candidate.chain, 'value'):
            chain = str(candidate.chain.value).lower()

        top10 = report.top10_holder_pct  # 0–100 float or None

        # ── 1. Original: high liquidity, almost no holders ───────────────────
        if liquidity >= 50_000 and holders <= 20:
            profile.bundled_buy_detected = True
            profile.suspicious = True
            profile.reasons.append('liquidity_without_holders')

        # ── 2. Solana bundle detection via top10 concentration ───────────────
        # Graduated pump.fun tokens launched via sniper bundles typically have
        # top-10 wallets holding 55-85% right after graduation.
        if top10 is not None and 'solana' in chain:
            if top10 >= 55 and liquidity >= 20_000:
                profile.bundled_buy_detected = True
                profile.reasons.append(f'solana_sniper_bundle top10={top10:.1f}%')
            elif top10 >= 45 and liquidity >= 40_000:
                profile.bundled_buy_detected = True
                profile.reasons.append(f'solana_bundle_high_liq top10={top10:.1f}%')

        # ── 3. Holder/liquidity ratio anomaly (chain-agnostic) ───────────────
        if liquidity >= 25_000 and 0 < holders <= 50 and not profile.bundled_buy_detected:
            profile.bundled_buy_detected = True
            profile.suspicious = True
            profile.reasons.append(f'low_holders_high_liq holders={holders}')

        # ── 4. Top10 concentration metadata (always) ─────────────────────────
        if top10 is not None:
            profile.sniper_concentration = top10
            if top10 > 35:
                profile.suspicious = True
                if f'top10={top10:.1f}%' not in ' '.join(profile.reasons):
                    profile.reasons.append('top10_too_concentrated')

        # ── 5. Wash trading ───────────────────────────────────────────────────
        if report.wash_trading_risk is not None and report.wash_trading_risk >= 80:
            profile.wash_trading_risk = report.wash_trading_risk
            profile.suspicious = True
            profile.reasons.append('wash_trading_risk')

        return profile
