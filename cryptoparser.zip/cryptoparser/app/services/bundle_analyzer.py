from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

def _to_float(v: Any) -> float:
    try:
        return float(v or 0.0)
    except Exception:
        return 0.0

def analyze_bundle(trades: list[dict[str, Any]] | None) -> dict[str, Any]:
    trades = trades or []
    if not trades:
        return {
            'bundle_supply_percent': 0.0,
            'early_wallet_cluster_size': 0,
            'largest_wallet_percent': 0.0,
            'bundle_severity': 'none',
            'wallets': [],
            'wallets_funded_same_source': False,
        }
    wallet_totals: dict[str, float] = {}
    funding_sources: set[str] = set()
    total_pct = 0.0
    for t in trades:
        wallet = str(t.get('wallet') or t.get('buyer') or t.get('owner') or 'unknown')
        pct = _to_float(t.get('supply_percent') or t.get('pct') or t.get('percent'))
        if pct <= 0:
            amount = _to_float(t.get('amount') or t.get('token_amount'))
            supply = _to_float(t.get('total_supply') or t.get('supply'))
            pct = (amount / supply * 100.0) if supply > 0 else 0.0
        total_pct += pct
        wallet_totals[wallet] = wallet_totals.get(wallet, 0.0) + pct
        source = str(t.get('funding_wallet') or t.get('funded_by') or t.get('source_wallet') or '')
        if source:
            funding_sources.add(source)
    largest_wallet_percent = max(wallet_totals.values()) if wallet_totals else 0.0
    cluster_size = len(wallet_totals)
    if total_pct >= 30 or largest_wallet_percent >= 15:
        severity = 'critical'
    elif total_pct >= 15 or cluster_size >= 8:
        severity = 'high'
    elif total_pct >= 7 or cluster_size >= 5:
        severity = 'medium'
    elif total_pct > 0:
        severity = 'low'
    else:
        severity = 'none'
    return {
        'bundle_supply_percent': round(total_pct, 2),
        'early_wallet_cluster_size': cluster_size,
        'largest_wallet_percent': round(largest_wallet_percent, 2),
        'bundle_severity': severity,
        'wallets': [wallet for wallet in wallet_totals if wallet != 'unknown'],
        'wallets_funded_same_source': len(funding_sources) == 1 and cluster_size > 1,
    }


@dataclass
class BundleAnalysis:
    detected: bool
    wallet_count: int
    bundle_pct: float
    wallets_funded_same_source: bool
    wallets: list[str] = field(default_factory=list)
    farm_score: float = 0.0
    farmable: bool = False
    reason: str = ''


class BundleScorer:
    MIN_WALLETS = 5
    MAX_WALLETS = 20
    MAX_BUNDLE_PCT = 0.20
    MIN_BUNDLE_PCT = 0.03

    def score(self, analysis: BundleAnalysis) -> BundleAnalysis:
        score = 1.0
        reasons: list[str] = []

        if analysis.wallet_count < self.MIN_WALLETS:
            analysis.farmable = False
            analysis.reason = f'too_few_wallets: {analysis.wallet_count} < {self.MIN_WALLETS}'
            analysis.farm_score = 0.0
            return analysis

        if analysis.bundle_pct > self.MAX_BUNDLE_PCT:
            analysis.farmable = False
            analysis.reason = f'bundle_pct_too_high: {analysis.bundle_pct:.1%} > {self.MAX_BUNDLE_PCT:.1%}'
            analysis.farm_score = 0.0
            return analysis

        if analysis.wallets_funded_same_source:
            score *= 0.3
            reasons.append('same_source_funding')

        if analysis.bundle_pct < self.MIN_BUNDLE_PCT:
            score *= 0.5
            reasons.append('bundle_pct_too_low')

        if analysis.wallet_count > self.MAX_WALLETS:
            score *= 0.7
            reasons.append('too_many_wallets')

        if 8 <= analysis.wallet_count <= 15:
            score *= 1.2

        if 0.05 <= analysis.bundle_pct <= 0.15:
            score *= 1.1

        score = min(score, 1.0)
        analysis.farm_score = round(score, 3)
        analysis.farmable = score >= 0.45
        analysis.reason = ', '.join(reasons) if reasons else 'ok'
        return analysis


class BundleWalletMonitor:
    async def check_still_holding(
        self,
        mint: str,
        bundle_wallets: list[str],
        rpc_url: str,
    ) -> dict:
        if not rpc_url or not bundle_wallets:
            return {
                'total_wallets': len(bundle_wallets or []),
                'still_holding': 0,
                'sold_wallets': 0,
                'sold_pct': 0.0,
                'danger': False,
            }

        still_holding = 0
        sold_wallets = 0
        checked = 0

        for wallet in bundle_wallets:
            balance = await self._get_token_balance(wallet, mint, rpc_url)
            if balance is None:
                continue
            checked += 1
            if balance > 0:
                still_holding += 1
            else:
                sold_wallets += 1

        if checked == 0:
            return {
                'total_wallets': len(bundle_wallets),
                'still_holding': 0,
                'sold_wallets': 0,
                'sold_pct': 0.0,
                'danger': False,
            }

        sold_pct = sold_wallets / checked
        return {
            'total_wallets': len(bundle_wallets),
            'still_holding': still_holding,
            'sold_wallets': sold_wallets,
            'sold_pct': round(sold_pct, 3),
            'danger': sold_pct > 0.30,
        }

    async def _get_token_balance(self, wallet: str, mint: str, rpc_url: str) -> float | None:
        import aiohttp

        payload = {
            'jsonrpc': '2.0',
            'id': 1,
            'method': 'getTokenAccountsByOwner',
            'params': [
                wallet,
                {'mint': mint},
                {'encoding': 'jsonParsed'},
            ],
        }
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(rpc_url, json=payload, timeout=aiohttp.ClientTimeout(total=5)) as resp:
                    data = await resp.json()
                    accounts = data.get('result', {}).get('value', [])
                    if not accounts:
                        return 0.0
                    amount = accounts[0]['account']['data']['parsed']['info']['tokenAmount']['uiAmount']
                    return float(amount or 0.0)
        except Exception:
            return None


def bundle_analysis_from_metrics(metrics: dict[str, Any] | None) -> BundleAnalysis:
    metrics = metrics or {}
    bundle_percent = _to_float(
        metrics.get('bundle_supply_percent')
        or metrics.get('bundle_pct')
        or metrics.get('bundle_supply_pct')
    )
    bundle_pct = bundle_percent / 100.0 if bundle_percent > 1 else bundle_percent
    wallets = metrics.get('wallets') or []
    if not isinstance(wallets, list):
        wallets = []
    wallet_count = int(metrics.get('early_wallet_cluster_size') or metrics.get('wallet_count') or len(wallets) or 0)
    severity = str(metrics.get('bundle_severity') or metrics.get('severity') or 'none').lower()
    return BundleAnalysis(
        detected=severity not in {'none', ''} or wallet_count > 0 or bundle_pct > 0,
        wallet_count=wallet_count,
        bundle_pct=bundle_pct,
        wallets_funded_same_source=bool(metrics.get('wallets_funded_same_source') or metrics.get('same_source')),
        wallets=[str(wallet) for wallet in wallets],
    )
