from __future__ import annotations

import hashlib
from collections import Counter
from typing import TYPE_CHECKING, Any

from app.models.token import SecurityReport, TokenCandidate, WalletClusterProfile

if TYPE_CHECKING:  # pragma: no cover
    from app.db.repositories import ClusterRepository
else:
    ClusterRepository = Any


class WalletClusteringService:
    def __init__(self, repo: ClusterRepository | None = None) -> None:
        self.repo = repo

    async def apply(self, candidate: TokenCandidate, security: SecurityReport) -> SecurityReport:
        wallets = [value for value in [candidate.deployer_address, candidate.creator_address, security.funding_wallet] if value]
        if not wallets:
            return security
        cluster = self.build_cluster(candidate, wallets)
        if self.repo:
            await self.repo.upsert(cluster)
        security.cluster_risk = max(security.cluster_risk or 0.0, cluster.risk_score)
        if cluster.risk_score >= 80:
            security.reasons.append('wallet_cluster_high_risk')
        security.raw.setdefault('cluster_profile', cluster.model_dump(mode='json'))
        return security

    def build_cluster(self, candidate: TokenCandidate, wallets: list[str]) -> WalletClusterProfile:
        normalized = sorted(set(wallets))
        cluster_id = hashlib.sha256('|'.join(normalized).encode()).hexdigest()[:24]
        labels: list[str] = []
        risk = 12.0

        if len(normalized) <= 2:
            risk += 8
            labels.append('tight_creator_cluster')
        if candidate.raw.get('bundledSnipers'):
            risk += 70
            labels.append('bundled_snipers')
        if candidate.raw.get('sharedFundingSource'):
            risk += 15
            labels.append('shared_funding_source')

        graph = ((candidate.raw.get('explorer') or {}).get('funding_graph') or {})
        graph_score, graph_labels = self._score_graph(graph)
        risk += graph_score
        labels.extend(graph_labels)

        family = (candidate.raw.get('explorer') or {}).get('creation_family_prefixes') or {}
        if family and max(family.values()) >= 3:
            risk += 12
            labels.append('reused_creation_family')

        linked = (candidate.raw.get('explorer') or {}).get('linked_wallets') or []
        if len(set(linked)) >= 3:
            risk += 10
            labels.append('multi_wallet_launch_cluster')

        suspicious_programs = (candidate.raw.get('explorer') or {}).get('suspicious_program_count') or 0
        if suspicious_programs >= 3:
            risk += 8
            labels.append('suspicious_program_overlap')

        return WalletClusterProfile(
            cluster_id=cluster_id,
            wallets=normalized,
            risk_score=min(risk, 99.0),
            labels=sorted(set(labels)),
            evidence={'token': candidate.token_address, 'graph': graph, 'linked_wallets': linked},
        )

    def _score_graph(self, graph: dict[str, Any]) -> tuple[float, list[str]]:
        if not graph:
            return 0.0, []
        labels: list[str] = []
        risk = 0.0
        depth = int(graph.get('depth') or 0)
        edges = graph.get('edges') or []
        if depth >= 3:
            risk += 12.0
            labels.append('deep_funding_chain')
        elif depth == 2:
            risk += 6.0
            labels.append('multi_hop_funding')
        edge_types = Counter(str(edge.get('type') or 'unknown') for edge in edges if isinstance(edge, dict))
        if edge_types.get('internal', 0) >= 1:
            risk += 10.0
            labels.append('internal_funding_path')
        if edge_types.get('external', 0) >= 2:
            risk += 4.0
            labels.append('repeated_external_seed')
        unique_sources = {str(edge.get('from')) for edge in edges if isinstance(edge, dict) and edge.get('from')}
        if len(unique_sources) == 1 and len(edges) >= 2:
            risk += 8.0
            labels.append('single_source_funding')
        return risk, labels
