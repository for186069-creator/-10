"""
Community Signals — модуль 5 з 5.

Агрегує вердикти з публічних скам-баз без платних API ключів:
  1. rugcheck.xyz    — Solana специфічний, дає risk score
  2. honeypot.is     — EVM honeypot detection
  3. tokensniffer.com — contract similarity + known scam patterns
  4. de.fi shield    — multi-chain audit aggregator

Логіка:
  - Запити паралельно з timeout 6s кожен
  - Нема ключів → скіп конкретного провайдера без помилки
  - Aggregate score = зважене середнє тих що відповіли
  - Якщо 2+ провайдери кажуть SCAM → hard signal незалежно від нашого score

Інтегрується в orchestrator як community_risk subscore.
"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field
from typing import Any

from app.models.token import Chain, TokenCandidate
from app.utils.http import HttpClient

log = logging.getLogger(__name__)

TIMEOUT_SECONDS = 6
HIGH_RISK_THRESHOLD = 70   # якщо провайдер дає score > N → вважаємо SCAM


@dataclass
class ProviderVerdict:
    provider: str
    available: bool       = False
    is_scam: bool         = False
    risk_score: float     = 50.0   # 0=safe 100=scam
    label: str            = 'unknown'
    details: dict         = field(default_factory=dict)


@dataclass
class CommunitySignal:
    token_address: str
    chain: str

    verdicts: list[ProviderVerdict]   = field(default_factory=list)
    aggregate_risk: float             = 50.0   # 0–100
    scam_consensus: bool              = False   # 2+ кажуть SCAM
    providers_checked: int            = 0
    providers_available: int          = 0
    reasons: list[str]                = field(default_factory=list)


class CommunitySignalsAggregator:
    def __init__(self) -> None:
        self.http = HttpClient()

    async def analyze(self, candidate: TokenCandidate) -> CommunitySignal:
        signal = CommunitySignal(
            token_address=candidate.token_address,
            chain=candidate.chain.value,
        )

        # Запускаємо всіх провайдерів паралельно
        tasks = []
        if candidate.chain == Chain.SOLANA:
            tasks.append(self._check_rugcheck(candidate))
        else:
            tasks.append(self._check_honeypot(candidate))
            tasks.append(self._check_tokensniffer(candidate))

        tasks.append(self._check_defi_shield(candidate))

        results = await asyncio.gather(*tasks, return_exceptions=True)
        verdicts: list[ProviderVerdict] = []

        for r in results:
            if isinstance(r, ProviderVerdict):
                verdicts.append(r)
            elif isinstance(r, Exception):
                log.debug('community_signals provider error: %s', r)

        signal.verdicts           = verdicts
        signal.providers_checked  = len(verdicts)
        signal.providers_available = sum(1 for v in verdicts if v.available)

        if not verdicts or signal.providers_available == 0:
            signal.aggregate_risk = 50.0  # невідомо
            return signal

        available = [v for v in verdicts if v.available]
        # Зважене середнє (провайдери з is_scam мають вдвічі більшу вагу)
        total_weight = sum(2.0 if v.is_scam else 1.0 for v in available)
        weighted_sum = sum((2.0 if v.is_scam else 1.0) * v.risk_score for v in available)
        signal.aggregate_risk = round(weighted_sum / total_weight, 1) if total_weight > 0 else 50.0

        scam_votes = sum(1 for v in available if v.is_scam or v.risk_score >= HIGH_RISK_THRESHOLD)
        signal.scam_consensus = scam_votes >= 2

        if signal.scam_consensus:
            signal.reasons.append(f'community_scam_consensus:{scam_votes}_providers')
        for v in available:
            if v.is_scam:
                signal.reasons.append(f'{v.provider}_flagged_scam')

        log.info(
            'community_signals: %s@%s aggregate=%.1f consensus=%s providers=%d/%d',
            candidate.token_address[:12], candidate.chain.value,
            signal.aggregate_risk, signal.scam_consensus,
            signal.providers_available, signal.providers_checked,
        )
        return signal

    # ── провайдери ────────────────────────────────────────────────────────────

    async def _check_rugcheck(self, candidate: TokenCandidate) -> ProviderVerdict:
        """rugcheck.xyz — Solana only, публічний API без ключа."""
        v = ProviderVerdict(provider='rugcheck')
        try:
            url  = f'https://api.rugcheck.xyz/v1/tokens/{candidate.token_address}/report/summary'
            data = await self.http.get_json(url, timeout=TIMEOUT_SECONDS)
            if not isinstance(data, dict):
                return v
            v.available  = True
            score        = data.get('score', 0) or 0       # rugcheck: lower = safer
            risks        = data.get('risks', []) or []
            # rugcheck score: 0=good, up to 1000=bad — нормалізуємо до 0-100
            v.risk_score = min(100.0, float(score) / 10.0)
            v.is_scam    = v.risk_score >= HIGH_RISK_THRESHOLD
            v.label      = data.get('score_label', 'unknown')
            v.details    = {'risks': [r.get('name') for r in risks[:5]], 'raw_score': score}
        except Exception as exc:
            log.debug('rugcheck error: %s', exc)
        return v

    async def _check_honeypot(self, candidate: TokenCandidate) -> ProviderVerdict:
        """honeypot.is — EVM, публічний API без ключа."""
        v = ProviderVerdict(provider='honeypot')
        chain_id_map = {'ethereum': 1, 'bsc': 56, 'base': 8453}
        chain_id = chain_id_map.get(candidate.chain.value)
        if not chain_id:
            return v
        try:
            url  = f'https://api.honeypot.is/v2/IsHoneypot?address={candidate.token_address}&chainID={chain_id}'
            data = await self.http.get_json(url, timeout=TIMEOUT_SECONDS)
            if not isinstance(data, dict):
                return v
            v.available = True
            token_data  = data.get('token', {}) or {}
            sim_data    = data.get('simulationResult', {}) or {}
            honeypot    = data.get('honeypotResult', {}) or {}

            is_hp = honeypot.get('isHoneypot', False)
            v.is_scam    = bool(is_hp)
            v.risk_score = 95.0 if is_hp else 10.0
            v.label      = 'honeypot' if is_hp else 'safe'
            v.details    = {
                'buy_tax':  sim_data.get('buyTax', 0),
                'sell_tax': sim_data.get('sellTax', 0),
                'reason':   honeypot.get('honeypotReason', ''),
            }
        except Exception as exc:
            log.debug('honeypot.is error: %s', exc)
        return v

    async def _check_tokensniffer(self, candidate: TokenCandidate) -> ProviderVerdict:
        """
        tokensniffer.com — scraping публічної сторінки.
        Офіційний API платний, але score видно на сторінці.
        """
        v = ProviderVerdict(provider='tokensniffer')
        chain_slug_map = {'ethereum': 'eth', 'bsc': 'bsc', 'base': 'base'}
        chain_slug = chain_slug_map.get(candidate.chain.value)
        if not chain_slug:
            return v
        try:
            url  = f'https://tokensniffer.com/token/{chain_slug}/{candidate.token_address}'
            html = await self.http.get_text(url, timeout=TIMEOUT_SECONDS)
            if not html:
                return v
            v.available = True
            # Парсимо score з HTML — шукаємо "Sniffer Score: N" або data-score атрибут
            import re
            score_match = re.search(r'[Ss]niffer\s+[Ss]core[^\d]*(\d+)', html)
            if score_match:
                raw = int(score_match.group(1))
                # tokensniffer: 100=safe, 0=scam → інвертуємо
                v.risk_score = max(0.0, 100.0 - float(raw))
                v.is_scam    = v.risk_score >= HIGH_RISK_THRESHOLD
                v.label      = f'score_{raw}'
            # Шукаємо explicit SCAM label
            if re.search(r'\bSCAM\b|\bRUG\b|\bHONEYPOT\b', html, re.IGNORECASE):
                v.is_scam    = True
                v.risk_score = max(v.risk_score, 90.0)
                v.label      = 'scam_label_found'
        except Exception as exc:
            log.debug('tokensniffer error: %s', exc)
        return v

    async def _check_defi_shield(self, candidate: TokenCandidate) -> ProviderVerdict:
        """de.fi Shield — multi-chain, публічний endpoint."""
        v = ProviderVerdict(provider='defi_shield')
        chain_map = {'ethereum': 'ethereum', 'bsc': 'binance-smart-chain', 'base': 'base', 'solana': 'solana'}
        chain_name = chain_map.get(candidate.chain.value)
        if not chain_name:
            return v
        try:
            url  = f'https://public-api.de.fi/v1/scanner/analyze/{chain_name}/{candidate.token_address}'
            data = await self.http.get_json(url, timeout=TIMEOUT_SECONDS)
            if not isinstance(data, dict):
                return v
            v.available  = True
            score        = data.get('score', 50) or 50    # 0=danger 100=safe
            v.risk_score = max(0.0, 100.0 - float(score))
            v.is_scam    = v.risk_score >= HIGH_RISK_THRESHOLD
            v.label      = data.get('verdict', 'unknown')
            issues       = data.get('issues', []) or []
            v.details    = {'issues': [i.get('name') for i in issues[:5]]}
        except Exception as exc:
            log.debug('defi_shield error: %s', exc)
        return v
