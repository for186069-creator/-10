"""
Cross-Chain Fingerprinter — модуль 3 з 5.

Будує behavioral fingerprint deployer гаманця і порівнює між чейнами.
Якщо новий deployer на Base поводиться ідентично відомому скамеру з BSC —
отримує high risk score навіть з чистою репутацією на Base.

Fingerprint = набір поведінкових ознак:
  - deploy_hour_pattern    — в яку годину доби деплоїть (UTC bucket 0–23)
  - token_name_style       — шаблон назв (all_caps, animal, meme, random)
  - lp_lock_style          — зазвичай 180d, 365d, або взагалі не локає
  - typical_launch_liquidity — розмір ліквідності при лістингу
  - abandonment_speed_days — через скільки днів токен помирає
  - social_pattern         — Twitter є/немає/куплений

Fingerprint зберігається в deployer_history.evidence['fingerprint'].
При новому токені — порівнюємо з усіма відомими fingerprints всіх чейнів.
Similarity > threshold → cross_chain_risk підвищується.

Без зовнішнього API, тільки наші власні дані з БД.
"""

from __future__ import annotations

import hashlib
import json
import logging
import math
from dataclasses import asdict, dataclass, field
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.models import DeployerHistoryRecord, TokenCandidateRecord, TokenDecisionRecord
from app.models.token import SecurityReport, TokenCandidate

log = logging.getLogger(__name__)

SIMILARITY_THRESHOLD = 0.72     # > N = вважаємо схожим deployer
TOP_K_COMPARE        = 50       # порівнюємо з топ-50 відомих скамерів


@dataclass
class DeployerFingerprint:
    wallet_address: str
    chain: str

    # Поведінкові ознаки (0–1 нормалізовані)
    deploy_hour_bucket: int      = -1      # 0-5/6-11/12-17/18-23 → 0/1/2/3
    token_name_style: str        = 'unknown'  # all_caps / animal / meme / generic
    lp_lock_style: str           = 'unknown'  # none / short(<180d) / standard / long
    typical_liquidity_bucket: int = -1     # 0:<5k 1:5-20k 2:20-100k 3:>100k
    avg_lifetime_bucket: int     = -1      # 0:<1d 1:1-7d 2:7-30d 3:>30d
    launches_count: int          = 0
    rugs_count: int              = 0
    rug_rate: float              = 0.0
    has_social: bool             = True
    funding_wallet_known: bool   = False

    def to_vector(self) -> list[float]:
        """Числовий вектор для cosine similarity."""
        return [
            float(self.deploy_hour_bucket) / 3.0 if self.deploy_hour_bucket >= 0 else 0.5,
            {'unknown': 0.5, 'all_caps': 0.2, 'animal': 0.4, 'meme': 0.6, 'generic': 0.3}.get(self.token_name_style, 0.5),
            {'unknown': 0.5, 'none': 0.0, 'short': 0.2, 'standard': 0.7, 'long': 1.0}.get(self.lp_lock_style, 0.5),
            float(self.typical_liquidity_bucket) / 3.0 if self.typical_liquidity_bucket >= 0 else 0.5,
            float(self.avg_lifetime_bucket) / 3.0 if self.avg_lifetime_bucket >= 0 else 0.5,
            min(float(self.launches_count) / 20.0, 1.0),
            self.rug_rate,
            1.0 if self.has_social else 0.0,
            1.0 if self.funding_wallet_known else 0.0,
        ]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @staticmethod
    def from_dict(d: dict) -> 'DeployerFingerprint':
        return DeployerFingerprint(**{k: v for k, v in d.items() if k in DeployerFingerprint.__dataclass_fields__})


@dataclass
class CrossChainMatch:
    matched_chain: str
    matched_wallet: str
    similarity: float
    matched_rug_rate: float
    matched_launches: int
    risk_score: float          # 0–100


class CrossChainFingerprinter:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    # ── публічний API ─────────────────────────────────────────────────────────

    async def analyze(
        self,
        candidate: TokenCandidate,
        security: SecurityReport,
    ) -> tuple[float, list[CrossChainMatch]]:
        """
        Returns:
            (cross_chain_risk_score 0–100, list of matches)
        """
        deployer = candidate.deployer_address or security.funding_wallet
        if not deployer:
            return 0.0, []

        # Будуємо fingerprint для поточного deployer
        fp = await self._build_fingerprint(candidate, security)
        if fp is None:
            return 0.0, []

        # Зберігаємо/оновлюємо fingerprint
        await self._save_fingerprint(deployer, candidate.chain.value, fp)

        # Шукаємо схожі fingerprints в інших чейнах
        matches = await self._find_matches(fp, exclude_chain=candidate.chain.value)
        if not matches:
            return 0.0, []

        # Risk = max similarity * rug_rate of matched deployer
        best = max(matches, key=lambda m: m.similarity * m.matched_rug_rate)
        risk = round(best.similarity * best.matched_rug_rate * 100.0, 1)

        log.info(
            'cross_chain_fingerprint: %s@%s → match %s@%s sim=%.2f rug_rate=%.2f risk=%.1f',
            deployer[:10], candidate.chain.value,
            best.matched_wallet[:10], best.matched_chain,
            best.similarity, best.matched_rug_rate, risk,
        )
        return risk, matches

    # ── fingerprint builder ──────────────────────────────────────────────────

    async def _build_fingerprint(
        self,
        candidate: TokenCandidate,
        security: SecurityReport,
    ) -> DeployerFingerprint | None:
        deployer = candidate.deployer_address or security.funding_wallet
        if not deployer:
            return None

        # Беремо попередні токени цього deployer
        q = (
            select(TokenCandidateRecord)
            .where(TokenCandidateRecord.deployer_address == deployer)
            .order_by(TokenCandidateRecord.first_seen_at.desc())
            .limit(20)
        )
        prev_tokens = list((await self.session.execute(q)).scalars().all())

        # Беремо deployer history
        deployer_row = await self._get_deployer_row(deployer, candidate.chain.value)

        fp = DeployerFingerprint(
            wallet_address=deployer,
            chain=candidate.chain.value,
        )

        # deploy_hour_bucket — з поточного токену
        if candidate.first_seen_at:
            hour = candidate.first_seen_at.hour
            fp.deploy_hour_bucket = hour // 6  # 0=0-5, 1=6-11, 2=12-17, 3=18-23

        # token_name_style
        name = (candidate.name or candidate.symbol or '').upper()
        fp.token_name_style = _classify_name(name)

        # lp_lock_style
        lp_days = security.lp_locked_days or 0
        if lp_days == 0:
            fp.lp_lock_style = 'none'
        elif lp_days < 180:
            fp.lp_lock_style = 'short'
        elif lp_days < 400:
            fp.lp_lock_style = 'standard'
        else:
            fp.lp_lock_style = 'long'

        # typical_liquidity_bucket
        liq = candidate.liquidity_usd or 0
        if liq < 5000:
            fp.typical_liquidity_bucket = 0
        elif liq < 20000:
            fp.typical_liquidity_bucket = 1
        elif liq < 100000:
            fp.typical_liquidity_bucket = 2
        else:
            fp.typical_liquidity_bucket = 3

        # avg_lifetime від deployer history
        if deployer_row:
            lt = deployer_row.avg_token_lifetime_days or 0
            if lt < 1:
                fp.avg_lifetime_bucket = 0
            elif lt < 7:
                fp.avg_lifetime_bucket = 1
            elif lt < 30:
                fp.avg_lifetime_bucket = 2
            else:
                fp.avg_lifetime_bucket = 3
            fp.launches_count    = deployer_row.launches_count or 0
            fp.rugs_count        = deployer_row.rugs_count or 0
            fp.rug_rate          = (fp.rugs_count / fp.launches_count) if fp.launches_count > 0 else 0.0
            fp.funding_wallet_known = bool(deployer_row.funding_wallet)

        fp.has_social = bool(candidate.x_handle)
        return fp

    # ── match search ─────────────────────────────────────────────────────────

    async def _find_matches(
        self,
        fp: DeployerFingerprint,
        exclude_chain: str,
    ) -> list[CrossChainMatch]:
        # Завантажуємо всіх deployers з інших чейнів що мали rugs
        q = (
            select(DeployerHistoryRecord)
            .where(
                DeployerHistoryRecord.chain != exclude_chain,
                DeployerHistoryRecord.rugs_count > 0,
            )
            .order_by(DeployerHistoryRecord.rugs_count.desc())
            .limit(TOP_K_COMPARE)
        )
        candidates = list((await self.session.execute(q)).scalars().all())

        matches: list[CrossChainMatch] = []
        fp_vec = fp.to_vector()

        for row in candidates:
            stored_fp_dict = (row.evidence or {}).get('fingerprint')
            if not stored_fp_dict:
                continue
            try:
                stored_fp = DeployerFingerprint.from_dict(stored_fp_dict)
            except Exception:
                continue

            sim = _cosine_similarity(fp_vec, stored_fp.to_vector())
            if sim >= SIMILARITY_THRESHOLD:
                rug_rate = (row.rugs_count / row.launches_count) if row.launches_count > 0 else 0.0
                matches.append(CrossChainMatch(
                    matched_chain   = row.chain,
                    matched_wallet  = row.wallet_address,
                    similarity      = round(sim, 3),
                    matched_rug_rate= round(rug_rate, 3),
                    matched_launches= row.launches_count,
                    risk_score      = round(sim * rug_rate * 100, 1),
                ))

        matches.sort(key=lambda m: m.risk_score, reverse=True)
        return matches

    # ── persistence ──────────────────────────────────────────────────────────

    async def _save_fingerprint(
        self, wallet: str, chain: str, fp: DeployerFingerprint
    ) -> None:
        row = await self._get_deployer_row(wallet, chain)
        if row:
            evidence = dict(row.evidence or {})
            evidence['fingerprint'] = fp.to_dict()
            row.evidence = evidence
            await self.session.commit()

    async def _get_deployer_row(
        self, wallet: str, chain: str
    ) -> DeployerHistoryRecord | None:
        q = select(DeployerHistoryRecord).where(
            DeployerHistoryRecord.wallet_address == wallet,
            DeployerHistoryRecord.chain == chain,
        )
        return (await self.session.execute(q)).scalar_one_or_none()


# ── утиліти ───────────────────────────────────────────────────────────────────

_ANIMAL_WORDS = {'dog', 'cat', 'shib', 'pepe', 'frog', 'rat', 'wolf', 'bear', 'bull', 'ape', 'monkey', 'panda'}
_MEME_WORDS   = {'moon', 'elon', 'musk', 'trump', 'doge', 'chad', 'based', 'giga', 'wagmi', 'wen', 'ngmi', 'pump'}

def _classify_name(name: str) -> str:
    lower = name.lower()
    if any(w in lower for w in _ANIMAL_WORDS):
        return 'animal'
    if any(w in lower for w in _MEME_WORDS):
        return 'meme'
    if name == name.upper() and len(name) <= 5:
        return 'all_caps'
    return 'generic'


def _cosine_similarity(a: list[float], b: list[float]) -> float:
    if len(a) != len(b):
        return 0.0
    dot   = sum(x * y for x, y in zip(a, b))
    mag_a = math.sqrt(sum(x * x for x in a))
    mag_b = math.sqrt(sum(x * x for x in b))
    if mag_a == 0 or mag_b == 0:
        return 0.0
    return dot / (mag_a * mag_b)
