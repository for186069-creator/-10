from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

from app.models.token import TokenCandidate


@dataclass(slots=True)
class DecayResult:
    penalty: float
    age_minutes: int
    age_hours: float
    liquidity_drop_pct: float
    holders_drop_pct: float
    activity_silence_hours: float
    reasons: list[str]

    def to_dict(self) -> dict[str, Any]:
        return {
            'penalty': round(self.penalty, 2),
            'age_minutes': self.age_minutes,
            'age_hours': round(self.age_hours, 2),
            'liquidity_drop_pct': round(self.liquidity_drop_pct, 2),
            'holders_drop_pct': round(self.holders_drop_pct, 2),
            'activity_silence_hours': round(self.activity_silence_hours, 2),
            'reasons': self.reasons,
        }


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def analyze_decay(candidate: TokenCandidate, historical_row: Any | None = None) -> DecayResult:
    now = _utc_now()
    first_seen = candidate.first_seen_at or now
    if first_seen.tzinfo is None:
        first_seen = first_seen.replace(tzinfo=timezone.utc)
    age_seconds = max(0.0, (now - first_seen).total_seconds())
    age_hours = age_seconds / 3600.0
    age_minutes = int(age_seconds // 60)

    penalty = 0.0
    reasons: list[str] = []

    # Time decay: starts after 1h, every 6h adds 0.8, capped at 20
    if age_hours > 1:
        time_penalty = min(20.0, ((age_hours - 1.0) / 6.0) * 0.8)
        penalty += time_penalty
        if time_penalty >= 0.5:
            reasons.append('time_decay')

    peak_liq = float(getattr(historical_row, 'peak_liquidity_usd', 0.0) or 0.0)
    latest_liq = float(candidate.liquidity_usd or getattr(historical_row, 'latest_liquidity_usd', 0.0) or 0.0)
    liquidity_drop_pct = 0.0
    if peak_liq > 0 and latest_liq >= 0:
        liquidity_drop_pct = max(0.0, ((peak_liq - latest_liq) / peak_liq) * 100.0)
        if liquidity_drop_pct >= 70:
            penalty += 20.0; reasons.append('liquidity_decay_critical')
        elif liquidity_drop_pct >= 50:
            penalty += 12.0; reasons.append('liquidity_decay_high')
        elif liquidity_drop_pct >= 30:
            penalty += 6.0; reasons.append('liquidity_decay_medium')

    peak_holders = int(getattr(historical_row, 'peak_holders', 0) or 0)
    latest_holders = int(candidate.holders or getattr(historical_row, 'latest_holders', 0) or 0)
    holders_drop_pct = 0.0
    if peak_holders > 0 and latest_holders >= 0:
        holders_drop_pct = max(0.0, ((peak_holders - latest_holders) / peak_holders) * 100.0)
        if holders_drop_pct >= 40:
            penalty += 10.0; reasons.append('holders_decay_high')
        elif holders_drop_pct >= 20:
            penalty += 5.0; reasons.append('holders_decay_medium')

    # Activity silence: use raw timestamp if present, else age proxy
    last_activity_at = None
    raw = getattr(candidate, 'raw', {}) or {}
    for key in ('last_activity_at', 'last_trade_at', 'last_signal_at'):
        if raw.get(key):
            try:
                value = raw[key]
                if isinstance(value, datetime):
                    last_activity_at = value if value.tzinfo else value.replace(tzinfo=timezone.utc)
                else:
                    txt = str(value).replace('Z', '+00:00')
                    last_activity_at = datetime.fromisoformat(txt)
                    if last_activity_at.tzinfo is None:
                        last_activity_at = last_activity_at.replace(tzinfo=timezone.utc)
                break
            except Exception:
                pass
    silence_hours = age_hours
    if last_activity_at is not None:
        silence_hours = max(0.0, (now - last_activity_at).total_seconds() / 3600.0)
    if silence_hours >= 12:
        penalty += 15.0; reasons.append('activity_decay_critical')
    elif silence_hours >= 6:
        penalty += 7.0; reasons.append('activity_decay_high')
    elif silence_hours >= 2:
        penalty += 3.0; reasons.append('activity_decay_low')

    return DecayResult(
        penalty=round(penalty, 2),
        age_minutes=age_minutes,
        age_hours=age_hours,
        liquidity_drop_pct=liquidity_drop_pct,
        holders_drop_pct=holders_drop_pct,
        activity_silence_hours=silence_hours,
        reasons=reasons,
    )
