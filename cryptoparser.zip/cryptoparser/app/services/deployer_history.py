from __future__ import annotations

import statistics

from app.db.repositories import DeployerRepository
from app.models.token import DeployerProfile, TokenCandidate


class DeployerHistoryService:
    def __init__(self, repo: DeployerRepository) -> None:
        self.repo = repo

    async def enrich(self, candidate: TokenCandidate) -> DeployerProfile | None:
        wallet = candidate.deployer_address or candidate.creator_address
        if not wallet:
            return None
        existing = await self.repo.get(candidate.chain.value, wallet)
        if existing:
            return DeployerProfile(
                address=wallet,
                launches_count=existing.launches_count,
                dead_tokens_count=existing.dead_tokens_count,
                rugs_count=existing.rugs_count,
                avg_token_lifetime_days=existing.avg_token_lifetime_days,
                funding_wallet=existing.funding_wallet,
                reputation_score=existing.reputation_score,
                suspicious_patterns=list(existing.suspicious_patterns or []),
                evidence=dict(existing.evidence or {}),
            )

        # Best-effort deterministic bootstrap when no external enrichment provider is configured.
        # This keeps the system conservative without inventing chain history.
        launches = 1
        dead_tokens = 0
        rugs = 0
        observed_lifetimes = [30.0]
        suspicious_patterns: list[str] = []
        if candidate.liquidity_usd and candidate.liquidity_usd < 75_000:
            suspicious_patterns.append('low_initial_liquidity')
        if candidate.website is None:
            suspicious_patterns.append('missing_website')
        reputation = 70.0
        if suspicious_patterns:
            reputation -= len(suspicious_patterns) * 10
        return DeployerProfile(
            address=wallet,
            launches_count=launches,
            dead_tokens_count=dead_tokens,
            rugs_count=rugs,
            avg_token_lifetime_days=statistics.mean(observed_lifetimes),
            funding_wallet=None,
            reputation_score=max(reputation, 0.0),
            suspicious_patterns=suspicious_patterns,
            evidence={'bootstrap': True},
        )
