"""
Engagement Authenticator — модуль 2 з 5.

Аналізує автентичність Twitter/X акаунту токену без платного API.
Працює через Nitter (той самий що X scraper).

Детектує:
  1. Username change  — акаунт мав інше ім'я (куплений акаунт)
  2. Bot-like ratio   — engagement_rate anomaly (занадто рівний, занадто низький/високий)
  3. Follower/tweet ratio — десятки тисяч фоловерів але 3 твіти (накрутка)
  4. Reply bot pattern — в останніх тілах відповідей однотипний текст
  5. Account age vs followers mismatch — молодий акаунт з великою аудиторією

Повертає BotSignal з score 0.0–1.0 (0 = точно бот, 1 = точно реальний)
і списком reasons.

Інтегрується в orchestrator як додатковий сигнал до SocialProfile.
"""

from __future__ import annotations

import asyncio
import logging
import re
from dataclasses import dataclass, field
from typing import Any

from bs4 import BeautifulSoup

from app.core.config import settings
from app.utils.http import HttpClient
from app.utils.providers import ProviderRotator

log = logging.getLogger(__name__)


@dataclass
class BotSignal:
    handle: str
    authenticity_score: float = 1.0    # 1.0 = реальний, 0.0 = бот
    bot_probability: float    = 0.0    # inverse
    username_changed: bool    = False
    follower_tweet_ratio: float | None = None
    engagement_anomaly: bool  = False
    suspicious_reply_pattern: bool = False
    age_follower_mismatch: bool    = False
    reasons: list[str] = field(default_factory=list)
    raw: dict[str, Any] = field(default_factory=dict)


class EngagementAuthenticator:
    """Аналізує автентичність X акаунту через Nitter."""

    # Heuristic thresholds
    MIN_TWEETS_FOR_FOLLOWER_RATIO = 10
    SUSPICIOUS_FOLLOWER_TWEET_RATIO = 500   # > N фоловерів на твіт = підозріло
    BOT_ENGAGEMENT_FLOOR = 0.001            # engagement_rate < 0.1% = заморожений акаунт
    BOT_ENGAGEMENT_CEIL  = 0.25             # engagement_rate > 25% = накрутка
    NEW_ACCOUNT_DAYS     = 90               # < 90 днів = новий
    NEW_ACCOUNT_BIG_FOLLOWERS = 5000        # якщо новий але > 5k фоловерів = підозра
    REPLY_BOT_REPEAT_THRESHOLD = 3          # якщо 3+ однакові перші слова у відповідях

    def __init__(self) -> None:
        self.http     = HttpClient()
        self.rotator  = ProviderRotator(
            settings.nitter_instances,
            cooldown_seconds=settings.provider_cooldown_seconds,
        )

    async def analyze(self, handle: str | None, social_raw: dict | None = None) -> BotSignal:
        if not handle:
            return BotSignal(handle='', authenticity_score=0.5, reasons=['no_handle'])

        handle = handle.lstrip('@')
        signal = BotSignal(handle=handle)

        # 1. Якщо є дані з основного X scraper — використовуємо їх
        if social_raw:
            followers = social_raw.get('followers', 0) or 0
            tweets    = social_raw.get('tweets', 0) or 0
            age_days  = social_raw.get('account_age_days', 0) or 0
            eng_rate  = social_raw.get('engagement_rate', None)
            signal.raw.update(social_raw)
            self._check_ratios(signal, followers, tweets, age_days, eng_rate)

        # 2. Додатково скрейпимо replies для pattern detection
        try:
            html = await self._fetch_nitter(handle, path='replies')
            if html:
                self._check_replies(signal, html)
                self._check_username_change(signal, html, handle)
        except asyncio.CancelledError:
            # Nitter timeout під час retry sleep — не вбиваємо pipeline
            log.debug('engagement_auth cancelled for %s (nitter unreachable)', handle)
        except Exception as exc:
            log.debug('engagement_auth nitter error %s: %s', handle, exc)

        # 3. Фінальний score
        signal.bot_probability   = self._compute_bot_prob(signal)
        signal.authenticity_score = round(1.0 - signal.bot_probability, 3)
        return signal

    # ── checks ────────────────────────────────────────────────────────────────

    def _check_ratios(
        self,
        signal: BotSignal,
        followers: int,
        tweets: int,
        age_days: int,
        engagement_rate: float | None,
    ) -> None:
        if tweets >= self.MIN_TWEETS_FOR_FOLLOWER_RATIO and followers > 0:
            ratio = followers / max(tweets, 1)
            signal.follower_tweet_ratio = round(ratio, 1)
            if ratio > self.SUSPICIOUS_FOLLOWER_TWEET_RATIO:
                signal.reasons.append(f'follower_tweet_ratio_high:{ratio:.0f}')

        if engagement_rate is not None:
            if engagement_rate < self.BOT_ENGAGEMENT_FLOOR and followers > 1000:
                signal.engagement_anomaly = True
                signal.reasons.append('engagement_rate_frozen')
            elif engagement_rate > self.BOT_ENGAGEMENT_CEIL:
                signal.engagement_anomaly = True
                signal.reasons.append('engagement_rate_inflated')

        if age_days and age_days < self.NEW_ACCOUNT_DAYS and followers > self.NEW_ACCOUNT_BIG_FOLLOWERS:
            signal.age_follower_mismatch = True
            signal.reasons.append(f'new_account_many_followers:{followers}')

    def _check_replies(self, signal: BotSignal, html: str) -> None:
        """Детектує однотипні reply-боти в коментарях."""
        soup = BeautifulSoup(html, 'html.parser')
        reply_texts = []
        for tweet_div in soup.select('.tweet-content')[:20]:
            text = tweet_div.get_text(' ', strip=True)
            if text:
                # Перші 4 слова як fingerprint
                words = text.lower().split()[:4]
                if len(words) >= 3:
                    reply_texts.append(' '.join(words))

        if not reply_texts:
            return

        # Рахуємо дублікати
        from collections import Counter
        counts = Counter(reply_texts)
        max_repeat = max(counts.values()) if counts else 0
        if max_repeat >= self.REPLY_BOT_REPEAT_THRESHOLD:
            signal.suspicious_reply_pattern = True
            signal.reasons.append(f'reply_bot_pattern:{max_repeat}x')

    def _check_username_change(self, signal: BotSignal, html: str, current_handle: str) -> None:
        """Шукає ознаки зміни username — попередні @mentions, "formerly" тощо."""
        lower = html.lower()
        formerly_patterns = [
            r'formerly\s+@?\w+',
            r'previously\s+@?\w+',
            r'was\s+@\w+',
            r'changed\s+from\s+@?\w+',
        ]
        for pat in formerly_patterns:
            if re.search(pat, lower):
                signal.username_changed = True
                signal.reasons.append('username_changed_evidence')
                break

        # Перевіряємо що title сторінки містить поточний handle
        title_match = re.search(r'<title>([^<]+)</title>', html, re.IGNORECASE)
        if title_match:
            title = title_match.group(1).lower()
            if current_handle.lower() not in title and 'nitter' in title:
                # title не збігається — підозра
                signal.reasons.append('title_handle_mismatch')

    # ── score computation ────────────────────────────────────────────────────

    def _compute_bot_prob(self, signal: BotSignal) -> float:
        prob = 0.0
        weights = {
            'username_changed':         0.35,
            'suspicious_reply_pattern': 0.30,
            'age_follower_mismatch':    0.25,
            'engagement_anomaly':       0.20,
        }
        # Ratio
        if signal.follower_tweet_ratio and signal.follower_tweet_ratio > self.SUSPICIOUS_FOLLOWER_TWEET_RATIO:
            ratio_score = min(0.25, (signal.follower_tweet_ratio - self.SUSPICIOUS_FOLLOWER_TWEET_RATIO) / 2000.0)
            prob += ratio_score

        if signal.username_changed:
            prob += weights['username_changed']
        if signal.suspicious_reply_pattern:
            prob += weights['suspicious_reply_pattern']
        if signal.age_follower_mismatch:
            prob += weights['age_follower_mismatch']
        if signal.engagement_anomaly:
            prob += weights['engagement_anomaly']

        return round(min(prob, 1.0), 3)

    # ── helpers ──────────────────────────────────────────────────────────────

    async def _fetch_nitter(self, handle: str, path: str = '') -> str | None:
        for base in await self.rotator.ordered():
            url = f'{base}/{handle}/{path}' if path else f'{base}/{handle}'
            try:
                html = await self.http.get_text(url, timeout=10)
                if html and len(html) > 500:
                    return html
            except Exception:
                await self.rotator.mark_failure(base)
        return None
