from __future__ import annotations

from collections import Counter
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any

from app.adapters.evm_explorer import EVMExplorerClient
from app.adapters.solana_rpc import SolanaRpcClient, decode_mint_account
from app.models.token import Chain, DeployerProfile, SecurityReport, TokenCandidate


if TYPE_CHECKING:  # pragma: no cover
    from app.db.repositories import DeployerRepository, GraphRepository
else:
    DeployerRepository = Any
    GraphRepository = Any


class ExplorerEnrichmentService:
    def __init__(self, deployers: DeployerRepository | None = None, graph_repo: GraphRepository | None = None) -> None:
        self.deployers = deployers
        self.graph_repo = graph_repo
        self.evm = EVMExplorerClient()
        self.solana = SolanaRpcClient()

    async def enrich(self, candidate: TokenCandidate, security: SecurityReport) -> tuple[TokenCandidate, SecurityReport, DeployerProfile | None]:
        if candidate.chain in {Chain.ETHEREUM, Chain.BASE, Chain.BSC}:
            return await self._enrich_evm(candidate, security)
        return await self._enrich_solana(candidate, security)

    async def _enrich_evm(self, candidate: TokenCandidate, security: SecurityReport) -> tuple[TokenCandidate, SecurityReport, DeployerProfile | None]:
        explorer_raw: dict[str, Any] = {}
        deployer_profile: DeployerProfile | None = None

        creation = await self.evm.get_contract_creation(candidate.chain, candidate.token_address)
        if creation:
            explorer_raw['creation'] = creation
            candidate.deployer_address = candidate.deployer_address or creation.get('contractCreator')
            candidate.raw.setdefault('creation_tx_hash', creation.get('txHash'))
            if creation.get('creationBytecode'):
                candidate.raw.setdefault('bytecode', creation.get('creationBytecode'))
            ts = _parse_ts(creation.get('timestamp'))
            if ts and ts < candidate.first_seen_at:
                candidate.first_seen_at = ts
            security.sources.append('etherscan_creation')

        source = await self.evm.get_source_code(candidate.chain, candidate.token_address)
        if source:
            explorer_raw['source'] = {
                'ContractName': source.get('ContractName'),
                'CompilerVersion': source.get('CompilerVersion'),
                'Proxy': source.get('Proxy'),
                'Implementation': source.get('Implementation'),
                'LicenseType': source.get('LicenseType'),
            }
            source_code = source.get('SourceCode') or ''
            if source_code:
                candidate.raw.setdefault('sourceCode', source_code)
                security.contract_verified = True
            elif security.contract_verified is None:
                security.contract_verified = False
            if security.proxy is None and source.get('Proxy') is not None:
                security.proxy = str(source.get('Proxy')).strip() == '1'
            if source.get('Implementation'):
                candidate.raw.setdefault('implementation', source.get('Implementation'))
            security.sources.append('etherscan_source')

        addresses_for_code = [candidate.token_address]
        if candidate.raw.get('implementation'):
            addresses_for_code.append(candidate.raw['implementation'])
        codes = await self.evm.get_codes(candidate.chain, addresses_for_code)
        if codes.get(candidate.token_address):
            candidate.raw.setdefault('bytecode', codes[candidate.token_address])
            security.sources.append('evm_rpc_code')
        if candidate.raw.get('implementation') and codes.get(candidate.raw['implementation']):
            explorer_raw['implementation_code'] = codes[candidate.raw['implementation']]
            security.sources.append('evm_rpc_implementation_code')

        wallet = candidate.deployer_address or candidate.creator_address
        if wallet:
            txs = await self.evm.get_normal_transactions(candidate.chain, wallet, offset=100, sort='desc')
            internal_txs = await self.evm.get_internal_transactions(candidate.chain, wallet, offset=100, sort='desc')
            balance_map = await self.evm.get_balances(candidate.chain, [wallet])
            deployer_profile = self._build_evm_deployer_profile(candidate.chain, wallet, txs, internal_txs, balance_map.get(wallet))
            explorer_raw['deployer_analysis'] = deployer_profile.evidence if deployer_profile else {}
            if self.deployers and deployer_profile:
                await self.deployers.upsert(deployer_profile, candidate.chain.value)
            if self.graph_repo and deployer_profile:
                await self._persist_graph(candidate.chain.value, wallet, deployer_profile)
            if deployer_profile:
                security.funding_wallet = deployer_profile.funding_wallet
                security.sources.append('etherscan_account')

        explorer_raw['graph_score'] = deployer_profile.evidence.get('graph_score') if deployer_profile else None
        explorer_raw['linked_wallets'] = deployer_profile.evidence.get('linked_wallets', []) if deployer_profile else []
        candidate.raw['explorer'] = explorer_raw
        security.raw['explorer'] = explorer_raw
        security.data_complete = bool(security.sources)
        return candidate, security, deployer_profile

    async def _enrich_solana(self, candidate: TokenCandidate, security: SecurityReport) -> tuple[TokenCandidate, SecurityReport, DeployerProfile | None]:
        explorer_raw: dict[str, Any] = {}
        deployer_profile: DeployerProfile | None = None

        account_info = await self.solana.get_account_info(candidate.token_address)
        mint_info = decode_mint_account(account_info)
        if mint_info:
            explorer_raw['mint'] = mint_info
            security.mint_authority_none = not mint_info.get('mint_authority_present')
            security.freeze_authority_none = not mint_info.get('freeze_authority_present')
            security.sources.append('solana_rpc_account_info')

        supply = await self.solana.get_token_supply(candidate.token_address)
        if supply:
            explorer_raw['token_supply'] = supply
            security.sources.append('solana_rpc_token_supply')

        largest = await self.solana.get_token_largest_accounts(candidate.token_address)
        if largest:
            explorer_raw['largest_accounts'] = largest[:10]
            top10 = _compute_top10_pct(largest[:10], supply)
            if top10 > 0:
                security.top10_holder_pct = round(top10, 4)
            security.sources.append('solana_rpc_largest_accounts')

        wallet = candidate.creator_address or candidate.deployer_address
        if wallet:
            signatures = await self.solana.get_signatures_for_address(wallet, limit=40)
            txs = await self.solana.get_transactions([row.get('signature') for row in signatures[:15] if row.get('signature')])
            balance = await self.solana.get_balance(wallet)
            deployer_profile = self._build_solana_deployer_profile(wallet, signatures, txs, balance)
            explorer_raw['wallet_tx_analysis'] = deployer_profile.evidence if deployer_profile else {}
            if self.deployers and deployer_profile:
                await self.deployers.upsert(deployer_profile, candidate.chain.value)
            if self.graph_repo and deployer_profile:
                await self._persist_graph(candidate.chain.value, wallet, deployer_profile)
            if deployer_profile:
                security.funding_wallet = deployer_profile.funding_wallet
            security.sources.append('solana_rpc_wallet')

        explorer_raw['graph_score'] = deployer_profile.evidence.get('graph_score') if deployer_profile else None
        explorer_raw['linked_wallets'] = deployer_profile.evidence.get('linked_wallets', []) if deployer_profile else []
        candidate.raw['explorer'] = explorer_raw
        security.raw['explorer'] = explorer_raw
        security.data_complete = bool(security.sources)
        return candidate, security, deployer_profile

    def _build_evm_deployer_profile(
        self,
        chain: Chain,
        wallet: str,
        txs: list[dict[str, Any]],
        internal_txs: list[dict[str, Any]],
        balance_wei: int | None,
    ) -> DeployerProfile:
        launches = 0
        suspicious_patterns: list[str] = []
        funding_wallet = None
        oldest_ts = None
        newest_ts = None
        inbound_candidates: list[tuple[int, str, str]] = []
        creation_inputs: list[str] = []
        family_counter: Counter[str] = Counter()

        for tx in txs:
            to_value = str(tx.get('to') or '').strip()
            input_data = str(tx.get('input') or '')
            if not to_value:
                launches += 1
                creation_inputs.append(input_data)
                family_counter[_family_signature(input_data)] += 1
            ts = _parse_ts(tx.get('timeStamp'))
            if ts:
                if oldest_ts is None or ts < oldest_ts:
                    oldest_ts = ts
                if newest_ts is None or ts > newest_ts:
                    newest_ts = ts
            if to_value.lower() == wallet.lower() and tx.get('from'):
                ts_int = int(tx.get('timeStamp') or 0)
                inbound_candidates.append((ts_int, str(tx['from']), 'external'))

        for tx in internal_txs:
            if str(tx.get('to') or '').lower() == wallet.lower() and tx.get('from'):
                inbound_candidates.append((int(tx.get('timeStamp') or 0), str(tx['from']), 'internal'))

        inbound_candidates.sort(key=lambda item: item[0])
        if inbound_candidates:
            funding_wallet = inbound_candidates[0][1]

        reputation = 85.0
        repeated_family_count = max(family_counter.values()) if family_counter else 0
        if launches >= 8:
            reputation -= 25.0
            suspicious_patterns.append('many_contract_creations')
        elif launches >= 4:
            reputation -= 12.0
            suspicious_patterns.append('repeat_contract_creator')
        if repeated_family_count >= 3:
            reputation -= 15.0
            suspicious_patterns.append('reused_creation_family')
        balance_native = (balance_wei or 0) / 1e18
        if balance_wei is not None and balance_native < 0.01:
            reputation -= 10.0
            suspicious_patterns.append('very_low_native_balance')
        if len(txs) >= 90:
            reputation -= 8.0
            suspicious_patterns.append('heavy_recent_tx_activity')

        funding_graph = self._build_funding_graph(wallet, inbound_candidates)
        if funding_graph['depth'] >= 2:
            suspicious_patterns.append('multi_hop_funding')
            reputation -= 5.0
        if any(edge.get('type') == 'internal' for edge in funding_graph['edges']):
            suspicious_patterns.append('internal_funding_path')
            reputation -= 8.0

        lifetime = None
        if oldest_ts and newest_ts:
            lifetime = max((newest_ts - oldest_ts).days, 0)

        linked_wallets = [src for _, src, _ in inbound_candidates[:5]]
        graph_score = 0.0
        if funding_graph['depth'] >= 3:
            graph_score += 18.0
        elif funding_graph['depth'] == 2:
            graph_score += 10.0
        if any(edge.get('type') == 'internal' for edge in funding_graph['edges']):
            graph_score += 12.0
        if repeated_family_count >= 3:
            graph_score += 10.0
        evidence = {
            'chain': chain.value,
            'recent_tx_count': len(txs),
            'internal_tx_count': len(internal_txs),
            'observed_contract_creations': launches,
            'balance_wei': balance_wei,
            'creation_family_prefixes': dict(family_counter),
            'funding_graph': funding_graph,
            'graph_score': graph_score,
            'linked_wallets': linked_wallets,
        }
        return DeployerProfile(
            address=wallet,
            launches_count=launches,
            dead_tokens_count=0,
            rugs_count=0,
            avg_token_lifetime_days=float(lifetime) if lifetime is not None else None,
            funding_wallet=funding_wallet,
            reputation_score=max(min(reputation, 99.0), 0.0),
            suspicious_patterns=suspicious_patterns,
            evidence=evidence,
        )

    def _build_solana_deployer_profile(
        self,
        wallet: str,
        signatures: list[dict[str, Any]],
        txs: list[dict[str, Any]],
        balance_lamports: int | None,
    ) -> DeployerProfile:
        suspicious_patterns: list[str] = []
        reputation = 82.0
        if len(signatures) >= 90:
            reputation -= 12.0
            suspicious_patterns.append('heavy_recent_signature_activity')
        if balance_lamports is not None and balance_lamports < 10_000_000:
            reputation -= 10.0
            suspicious_patterns.append('low_sol_balance')

        oldest = None
        newest = None
        program_counter: Counter[str] = Counter()
        funding_sources: Counter[str] = Counter()
        for row in signatures:
            block_time = row.get('blockTime')
            if block_time is None:
                continue
            ts = datetime.fromtimestamp(int(block_time), tz=timezone.utc)
            if oldest is None or ts < oldest:
                oldest = ts
            if newest is None or ts > newest:
                newest = ts
        for tx in txs:
            for key in _extract_solana_programs_and_funders(tx)['programs']:
                program_counter[key] += 1
            for src in _extract_solana_programs_and_funders(tx)['funders']:
                funding_sources[src] += 1

        if program_counter.get('spl-token', 0) >= 8:
            suspicious_patterns.append('heavy_token_instruction_activity')
            reputation -= 6.0
        if program_counter.get('unknown', 0) >= 5:
            suspicious_patterns.append('unknown_program_activity')
            reputation -= 6.0
        funding_wallet = funding_sources.most_common(1)[0][0] if funding_sources else None

        lifetime = None
        if oldest and newest:
            lifetime = max((newest - oldest).days, 0)

        suspicious_program_count = sum(1 for name, count in program_counter.items() if name == 'unknown' and count >= 1)
        evidence = {
            'recent_signature_count': len(signatures),
            'program_counter': dict(program_counter),
            'funding_sources': dict(funding_sources),
            'tx_sample_count': len(txs),
            'graph_score': 8.0 if funding_wallet else 0.0,
            'linked_wallets': list(funding_sources.keys())[:5],
            'suspicious_program_count': suspicious_program_count,
        }
        return DeployerProfile(
            address=wallet,
            launches_count=max(program_counter.get('spl-token', 0) // 2, 0),
            dead_tokens_count=0,
            rugs_count=0,
            avg_token_lifetime_days=float(lifetime) if lifetime is not None else None,
            funding_wallet=funding_wallet,
            reputation_score=max(min(reputation, 99.0), 0.0),
            suspicious_patterns=suspicious_patterns,
            evidence=evidence,
        )

    def _build_funding_graph(self, wallet: str, inbound_candidates: list[tuple[int, str, str]]) -> dict[str, Any]:
        if not inbound_candidates:
            return {'root': wallet, 'depth': 0, 'edges': []}
        edges = []
        seen = set()
        previous = wallet
        depth = 0
        for _, funder, tx_type in inbound_candidates[:3]:
            if funder in seen:
                continue
            seen.add(funder)
            edges.append({'from': funder, 'to': previous, 'type': tx_type})
            previous = funder
            depth += 1
        return {'root': wallet, 'depth': depth, 'edges': edges}


    async def _persist_graph(self, chain: str, wallet: str, profile: DeployerProfile) -> None:
        if not self.graph_repo:
            return
        labels = list(profile.suspicious_patterns)
        await self.graph_repo.upsert_node(chain, wallet, labels=labels, risk_score=max(100.0 - profile.reputation_score, 0.0), metadata=profile.evidence)
        funding_wallet = profile.funding_wallet
        if funding_wallet:
            await self.graph_repo.upsert_node(chain, funding_wallet, labels=['funding_wallet'], risk_score=profile.evidence.get('graph_score', 0.0), metadata={})
            edge_type = 'funding'
            if (profile.evidence.get('funding_graph') or {}).get('edges'):
                edge_type = str((profile.evidence['funding_graph']['edges'][0].get('type') or 'funding'))
            await self.graph_repo.upsert_edge(chain, funding_wallet, wallet, edge_type=edge_type, weight=1.0 + float(profile.evidence.get('graph_score', 0.0) or 0.0) / 100.0, evidence=profile.evidence)
        for linked in profile.evidence.get('linked_wallets', [])[:8]:
            if linked and linked != wallet:
                await self.graph_repo.upsert_node(chain, linked, labels=['linked_wallet'], risk_score=float(profile.evidence.get('graph_score', 0.0) or 0.0), metadata={})
                await self.graph_repo.upsert_edge(chain, linked, wallet, edge_type='linked', weight=0.5, evidence={'source': 'explorer_enrichment'})


def _family_signature(input_data: str) -> str:
    raw = (input_data or '0x')[:74]
    return raw if raw else '0x'


def _parse_ts(value: Any) -> datetime | None:
    if value is None:
        return None
    try:
        return datetime.fromtimestamp(int(value), tz=timezone.utc)
    except (TypeError, ValueError, OSError):
        return None


def _safe_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _compute_top10_pct(largest: list[dict[str, Any]], supply: dict[str, Any] | None) -> float:
    top10 = 0.0
    for row in largest[:10]:
        ui_amount = _safe_float(row.get('uiAmount'))
        total_amount = _safe_float(supply.get('uiAmount')) if supply else None
        if ui_amount is not None and total_amount and total_amount > 0:
            top10 += (ui_amount / total_amount) * 100.0
        elif row.get('uiAmountString') and supply and supply.get('uiAmountString'):
            try:
                top10 += (float(row['uiAmountString']) / float(supply['uiAmountString'])) * 100.0
            except (TypeError, ValueError, ZeroDivisionError):
                pass
    return top10


def _extract_solana_programs_and_funders(tx: dict[str, Any]) -> dict[str, list[str]]:
    programs: list[str] = []
    funders: list[str] = []
    message = (((tx.get('transaction') or {}).get('message')) or {})
    instructions = message.get('instructions') or []
    account_keys = message.get('accountKeys') or []
    key_lookup: list[str] = []
    for row in account_keys:
        if isinstance(row, dict):
            key_lookup.append(str(row.get('pubkey') or ''))
        else:
            key_lookup.append(str(row))
    for ix in instructions:
        if not isinstance(ix, dict):
            continue
        program = str(ix.get('program') or ix.get('programId') or 'unknown').lower()
        programs.append(program)
        parsed = ix.get('parsed') or {}
        info = parsed.get('info') if isinstance(parsed, dict) else {}
        source = info.get('source') if isinstance(info, dict) else None
        authority = info.get('authority') if isinstance(info, dict) else None
        if source:
            funders.append(str(source))
        elif authority:
            funders.append(str(authority))
        elif key_lookup:
            funders.append(key_lookup[0])
    return {'programs': programs, 'funders': funders}
