"""
GEM Calibrator — feedback loop для GemPredictor.

Алгоритм:
  1. Завантажує outcome-лейбли (alive / rug / dead) з analyst_labels
  2. Для кожного токену бере збережений evidence['gem']['breakdown'] і tier thresholds
  3. Аналізує які sub-score компоненти передбачали правильно / неправильно
  4. Коригує:
       a) ваги sub-score компонентів (pattern / momentum / social / smart_money)
       b) tier thresholds (HOT / WATCH / SCOUT)
  5. Зберігає результат у config/gem_weights.json

GemPredictor автоматично підхоплює новий файл при наступному старті.

Мінімальна кількість лейблів для запуску: MIN_SAMPLES = 15
Швидкість навчання: LEARNING_RATE = 0.05 (консервативна)
"""

from __future__ import annotations

import asyncio
import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.base import AsyncSessionLocal
from app.db.models import AnalystLabelRecord, TokenDecisionRecord

log = logging.getLogger(__name__)

GEM_WEIGHTS_PATH  = Path('config/gem_weights.json')
MIN_SAMPLES       = 15
LEARNING_RATE     = 0.05   # консервативне оновлення ваг за ітерацію
MAX_WEIGHT_CHANGE = 0.20   # максимальна зміна будь-якої ваги за раз

# Дефолтні ваги компонентів та пороги тірів
DEFAULT_WEIGHTS: dict[str, Any] = {
    'component_weights': {
        'pattern':     1.0,
        'momentum':    1.0,
        'social':      1.0,
        'smart_money': 1.0,
        # full-stage
        'social_enriched':       0.55,
        'smart_money_enriched':  0.80,
    },
    'tier_thresholds': {
        'HOT':   82.0,
        'WATCH': 68.0,
        'SCOUT': 52.0,
    },
    'version':      0,
    'updated_at':   None,
    'sample_count': 0,
}


def load_gem_weights() -> dict[str, Any]:
    """Завантажує ваги з файлу або повертає дефолт."""
    if GEM_WEIGHTS_PATH.exists():
        try:
            data = json.loads(GEM_WEIGHTS_PATH.read_text(encoding='utf-8'))
            # Мержимо з дефолтом на випадок нових полів
            merged = dict(DEFAULT_WEIGHTS)
            merged['component_weights'] = {**DEFAULT_WEIGHTS['component_weights'], **data.get('component_weights', {})}
            merged['tier_thresholds']   = {**DEFAULT_WEIGHTS['tier_thresholds'],   **data.get('tier_thresholds', {})}
            merged['version']      = data.get('version', 0)
            merged['updated_at']   = data.get('updated_at')
            merged['sample_count'] = data.get('sample_count', 0)
            return merged
        except Exception as e:
            log.warning('gem_calibrator: cannot load weights: %s', e)
    return dict(DEFAULT_WEIGHTS)


class GemCalibrator:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def run(self) -> dict[str, Any]:
        samples = await self._load_samples()

        if len(samples) < MIN_SAMPLES:
            log.info(
                'gem_calibrator: %d samples < MIN_SAMPLES=%d, skipping',
                len(samples), MIN_SAMPLES,
            )
            return {
                'status':       'skipped',
                'reason':       'insufficient_data',
                'sample_count': len(samples),
                'required':     MIN_SAMPLES,
            }

        weights = load_gem_weights()
        weights, report = self._calibrate(samples, weights)
        _save_weights(weights)

        log.info(
            'gem_calibrator: calibrated on %d samples, version=%d, '
            'HOT=%.1f WATCH=%.1f SCOUT=%.1f',
            len(samples),
            weights['version'],
            weights['tier_thresholds']['HOT'],
            weights['tier_thresholds']['WATCH'],
            weights['tier_thresholds']['SCOUT'],
        )
        return report

    # ── завантаження даних ────────────────────────────────────────────────────

    async def _load_samples(self) -> list[dict[str, Any]]:
        """Повертає список {outcome, gem_score, breakdown, tier} для кожного токену."""
        q_labels = select(AnalystLabelRecord).where(AnalystLabelRecord.label == 'outcome')
        label_rows = list((await self.session.execute(q_labels)).scalars().all())

        # Найсвіжіший лейбл на токен
        outcome_map: dict[tuple[str, str], str] = {}
        for lbl in sorted(label_rows, key=lambda x: x.created_at):
            key = (lbl.chain, lbl.token_address)
            if key not in outcome_map or lbl.analyst == 'outcome_tracker':
                outcome_map[key] = lbl.value

        samples: list[dict[str, Any]] = []
        for (chain, token_address), outcome in outcome_map.items():
            q = (
                select(TokenDecisionRecord)
                .where(
                    TokenDecisionRecord.chain         == chain,
                    TokenDecisionRecord.token_address == token_address,
                )
                .order_by(TokenDecisionRecord.created_at.asc())
                .limit(1)
            )
            decision = (await self.session.execute(q)).scalar_one_or_none()
            if decision is None:
                continue

            evidence  = decision.evidence or {}
            gem       = evidence.get('gem') or {}
            breakdown = gem.get('breakdown') or {}

            if not gem or not breakdown:
                continue  # немає gem даних — пропускаємо

            samples.append({
                'outcome':    outcome,                          # alive / rug / dead
                'is_good':    outcome == 'alive',
                'gem_score':  float(gem.get('gem_score') or 0),
                'tier':       str(gem.get('tier') or 'SKIP'),
                'breakdown':  breakdown,
                'score':      float(decision.score),
            })

        log.info('gem_calibrator: loaded %d samples with gem data', len(samples))
        return samples

    # ── калібровка ────────────────────────────────────────────────────────────

    def _calibrate(
        self,
        samples: list[dict[str, Any]],
        weights: dict[str, Any],
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        """
        Градієнтне оновлення ваг компонентів та tier thresholds.
        """
        cw = dict(weights['component_weights'])
        tt = dict(weights['tier_thresholds'])

        # ── 1. Коригуємо ваги компонентів ──────────────────────────────────
        # Для кожного компонента рахуємо кореляцію зі "score was good/bad"
        components = ['pattern', 'momentum', 'social', 'smart_money']
        for comp in components:
            values_good = [s['breakdown'].get(comp, 0) for s in samples if s['is_good']]
            values_bad  = [s['breakdown'].get(comp, 0) for s in samples if not s['is_good']]

            if not values_good or not values_bad:
                continue

            avg_good = sum(values_good) / len(values_good)
            avg_bad  = sum(values_bad)  / len(values_bad)

            # Якщо компонент вищий у good — він корисний, збільшуємо вагу
            # Якщо вищий у bad — він шкідливий, зменшуємо вагу
            delta = (avg_good - avg_bad) / max(abs(avg_good) + abs(avg_bad) + 1e-9, 10.0)
            adjustment = max(-MAX_WEIGHT_CHANGE, min(LEARNING_RATE * delta, MAX_WEIGHT_CHANGE))
            cw[comp] = round(max(0.2, min(cw.get(comp, 1.0) + adjustment, 3.0)), 4)

        # ── 2. Tier threshold grid search ────────────────────────────────────
        # Знаходимо оптимальний HOT-поріг (мінімум FP на HOT = rug що отримав HOT)
        best_hot   = tt['HOT']
        best_watch = tt['WATCH']
        best_scout = tt['SCOUT']
        best_fbeta = -1.0

        for hot_t in range(70, 96, 2):
            for watch_t in range(55, hot_t - 5, 2):
                for scout_t in range(40, watch_t - 5, 2):
                    fbeta = _tier_fbeta(samples, float(hot_t), float(watch_t), float(scout_t))
                    if fbeta > best_fbeta:
                        best_fbeta = fbeta
                        best_hot   = float(hot_t)
                        best_watch = float(watch_t)
                        best_scout = float(scout_t)

        # Плавне оновлення — не стрибаємо різко
        tt['HOT']   = round(_smooth(tt['HOT'],   best_hot,   LEARNING_RATE * 3), 1)
        tt['WATCH'] = round(_smooth(tt['WATCH'], best_watch, LEARNING_RATE * 3), 1)
        tt['SCOUT'] = round(_smooth(tt['SCOUT'], best_scout, LEARNING_RATE * 3), 1)

        # ── 3. Статистика ────────────────────────────────────────────────────
        n_good = sum(1 for s in samples if s['is_good'])
        n_bad  = len(samples) - n_good

        hot_precision, hot_recall = _tier_precision_recall(samples, tt['HOT'])

        weights['component_weights'] = cw
        weights['tier_thresholds']   = tt
        weights['version']           = weights.get('version', 0) + 1
        weights['updated_at']        = datetime.now(timezone.utc).isoformat()
        weights['sample_count']      = len(samples)

        report = {
            'status':         'calibrated',
            'sample_count':   len(samples),
            'good_count':     n_good,
            'bad_count':      n_bad,
            'rug_rate_pct':   round(n_bad / len(samples) * 100, 1),
            'version':        weights['version'],
            'tier_thresholds': tt,
            'component_weights': cw,
            'hot_precision':  round(hot_precision, 3),
            'hot_recall':     round(hot_recall, 3),
            'best_fbeta':     round(best_fbeta, 4),
        }
        return weights, report


# ── утиліти ───────────────────────────────────────────────────────────────────

def _tier_fbeta(
    samples: list[dict],
    hot_t: float,
    watch_t: float,
    scout_t: float,
) -> float:
    """F-beta (beta=1.5, penalty на FP) для HOT tier."""
    tp = fp = fn = 0
    for s in samples:
        predicted_hot = s['gem_score'] >= hot_t
        if predicted_hot and s['is_good']:
            tp += 1
        elif predicted_hot and not s['is_good']:
            fp += 1
        elif not predicted_hot and s['is_good']:
            fn += 1
    precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    recall    = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    b2 = 1.5 ** 2
    return (1 + b2) * precision * recall / (b2 * precision + recall) if (b2 * precision + recall) > 0 else 0.0


def _tier_precision_recall(samples: list[dict], hot_t: float) -> tuple[float, float]:
    tp = fp = fn = 0
    for s in samples:
        if s['gem_score'] >= hot_t:
            if s['is_good']:  tp += 1
            else:             fp += 1
        elif s['is_good']:    fn += 1
    precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    recall    = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    return precision, recall


def _smooth(current: float, target: float, rate: float) -> float:
    """Плавне наближення до target."""
    return current + rate * (target - current)


def _save_weights(weights: dict[str, Any]) -> None:
    GEM_WEIGHTS_PATH.parent.mkdir(parents=True, exist_ok=True)
    GEM_WEIGHTS_PATH.write_text(
        json.dumps(weights, indent=2, ensure_ascii=False),
        encoding='utf-8',
    )
    log.info('gem_calibrator: weights saved to %s (v%d)', GEM_WEIGHTS_PATH, weights['version'])


# ── scheduler entry-point ─────────────────────────────────────────────────────

async def run_gem_calibration(session_factory) -> None:
    async with session_factory() as session:
        calibrator = GemCalibrator(session)
        await calibrator.run()


# ── standalone ────────────────────────────────────────────────────────────────

if __name__ == '__main__':
    from app.core.logging import configure_logging
    configure_logging()

    async def _main() -> None:
        async with AsyncSessionLocal() as session:
            report = await GemCalibrator(session).run()
            print(json.dumps(report, indent=2, ensure_ascii=False))

    asyncio.run(_main())
