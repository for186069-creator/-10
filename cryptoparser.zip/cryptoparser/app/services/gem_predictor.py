from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from app.models.token import (
    BehaviorProfile,
    SecurityReport,
    SocialProfile,
    TokenCandidate,
    WebsiteProfile,
)

from app.services.momentum_tracker import MomentumTracker
from app.services.pattern_library import match_pattern
from app.services.smart_money_tracker import SmartMoneyTracker
from app.services.social_velocity import SocialVelocity
from app.services.gem_calibrator import load_gem_weights


@dataclass(slots=True)
class GemPrediction:
    gem_score: float
    tier: str
    projected_x: str
    confidence: float
    matched_pattern: str
    signals: list[str]
    breakdown: dict[str, float]
    stage: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "gem_score": self.gem_score,
            "tier": self.tier,
            "projected_x": self.projected_x,
            "confidence": self.confidence,
            "matched_pattern": self.matched_pattern,
            "signals": self.signals,
            "breakdown": self.breakdown,
            "stage": self.stage,
        }


class GemPredictor:
    def __init__(self) -> None:
        self.momentum = MomentumTracker()
        self.social = SocialVelocity()
        self.smart_money = SmartMoneyTracker()
        self._reload_weights()

    def _reload_weights(self) -> None:
        from app.core.config import settings as _s
        w = load_gem_weights()
        self._cw = w["component_weights"]
        saved = w["tier_thresholds"]
        # .env перекриває збережені значення (дефолти config != 72/58/44 = явно задані)
        self._tt = {
            "HOT":   _s.gem_hot_threshold   if _s.gem_hot_threshold   != 82.0 else saved.get("HOT",   72.0),
            "WATCH": _s.gem_watch_threshold if _s.gem_watch_threshold != 68.0 else saved.get("WATCH", 58.0),
            "SCOUT": _s.gem_scout_threshold if _s.gem_scout_threshold != 52.0 else saved.get("SCOUT", 44.0),
        }

    def _tier(self, score: float) -> tuple[str, str, float]:
        if score >= self._tt["HOT"]:
            return "HOT", "x1000", 0.88
        if score >= self._tt["WATCH"]:
            return "WATCH", "x100", 0.74
        if score >= self._tt["SCOUT"]:
            return "SCOUT", "x10", 0.58
        return "SKIP", "---", 0.36

    def fast(self, candidate: TokenCandidate) -> GemPrediction:

        pattern = match_pattern(
            candidate.symbol,
            candidate.name,
            candidate.holders,
            candidate.liquidity_usd,
            [
                candidate.website,
                candidate.telegram_url,
                candidate.x_handle,
            ],
        )

        momentum = self.momentum.analyze(candidate)
        social = self.social.fast(candidate)
        money = self.smart_money.fast(candidate)

        cw = self._cw

        score = max(
            0.0,
            min(
                pattern.score * cw.get("pattern", 1.0)
                + momentum.score * cw.get("momentum", 1.0)
                + social.score * cw.get("social", 1.0)
                + money.score * cw.get("smart_money", 1.0),
                100.0,
            ),
        )

        tier, projected_x, confidence = self._tier(score)

        signals = (
            pattern.reasons
            + momentum.reasons
            + social.reasons
            + money.reasons
        )

        return GemPrediction(
            gem_score=round(score, 2),
            tier=tier,
            projected_x=projected_x,
            confidence=confidence,
            matched_pattern=pattern.name,
            signals=signals[:12],
            breakdown={
                "pattern": round(pattern.score, 2),
                "momentum": round(momentum.score, 2),
                "social": round(social.score, 2),
                "smart_money": round(money.score, 2),
            },
            stage="FAST",
        )

    def full(
        self,
        candidate: TokenCandidate,
        security: SecurityReport,
        social: SocialProfile | None,
        website: WebsiteProfile | None,
        behavior: BehaviorProfile | None,
        extras: dict[str, Any] | None = None,
    ) -> GemPrediction:

        extras = extras or {}

        fast = self.fast(candidate)

        full_social = self.social.full(social, website)
        full_money = self.smart_money.full(security, behavior)

        bonus = 0.0

        signals = (
            list(fast.signals)
            + full_social.reasons
            + full_money.reasons
        )

        # --------------------------
        # SOFTENED BUNDLE PENALTY
        # --------------------------

        bundle = extras.get("bundle", {}) or {}

        bundle_pct = float(
            bundle.get("bundle_supply_percent", 0) or 0
        )

        cluster = int(
            bundle.get("early_wallet_cluster_size", 0) or 0
        )

        largest_wallet = float(
            bundle.get("largest_wallet_percent", 0) or 0
        )

        # було -40 → стало -25
        if bundle_pct >= 40:
            bonus -= 25
            signals.append("bundle_supply_critical")

        elif bundle_pct >= 30:
            bonus -= 18
            signals.append("bundle_supply_high")

        elif bundle_pct >= 20:
            bonus -= 10
            signals.append("bundle_supply_medium")

        elif bundle_pct >= 10:
            bonus -= 5
            signals.append("bundle_supply_low")

        # cluster soften
        if cluster >= 12:
            bonus -= 10
            signals.append("bundle_cluster_critical")

        elif cluster >= 8:
            bonus -= 6
            signals.append("bundle_cluster_large")

        elif cluster >= 5:
            bonus -= 3
            signals.append("bundle_cluster_medium")

        # wallet soften
        if largest_wallet >= 20:
            bonus -= 10
            signals.append("largest_wallet_critical")

        elif largest_wallet >= 12:
            bonus -= 6
            signals.append("largest_wallet_dominant")

        elif largest_wallet >= 8:
            bonus -= 3
            signals.append("largest_wallet_medium")

        # --------------------------
        # DECAY
        # --------------------------

        decay = extras.get("decay", {}) or {}

        decay_penalty = float(
            decay.get("penalty", 0) or 0
        )

        decay_age_hours = float(
            decay.get("age_hours", 0) or 0
        )

        if decay_penalty > 0:
            bonus -= decay_penalty
            signals.extend(
                list(decay.get("reasons", []))[:6]
            )

        cw = self._cw

        score = max(
            0.0,
            min(
                fast.gem_score
                + full_social.score
                * cw.get("social_enriched", 0.55)
                + full_money.score
                * cw.get("smart_money_enriched", 0.80)
                + bonus,
                100.0,
            ),
        )

        tier, projected_x, confidence = self._tier(score)

        # --------------------------
        # SOFT AGING
        # --------------------------

        aging_downgrade = None

        if tier == "HOT" and decay_age_hours >= 8:
            tier = "WATCH"
            projected_x = "x100"
            aging_downgrade = "hot_aged_to_watch"

        elif tier == "WATCH" and decay_age_hours >= 12:
            tier = "SCOUT"
            projected_x = "x10"
            aging_downgrade = "watch_aged_to_scout"

        elif tier == "SCOUT" and decay_age_hours >= 18:
            tier = "SKIP"
            projected_x = "---"
            aging_downgrade = "scout_aged_to_skip"

        if aging_downgrade:
            signals.append(aging_downgrade)

        return GemPrediction(
            gem_score=round(score, 2),
            tier=tier,
            projected_x=projected_x,
            confidence=round(min(0.98, confidence), 2),
            matched_pattern=fast.matched_pattern,
            signals=signals[:16],
            breakdown={
                **fast.breakdown,
                "social_enriched": round(
                    full_social.score, 2
                ),
                "smart_money_enriched": round(
                    full_money.score, 2
                ),
                "enrichment_adjustment": round(
                    bonus, 2
                ),
                "decay_age_hours": round(
                    decay_age_hours, 2
                ),
            },
            stage="FULL",
        )