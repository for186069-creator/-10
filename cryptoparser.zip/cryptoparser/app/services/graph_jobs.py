from __future__ import annotations

import asyncio
from collections import defaultdict
from dataclasses import dataclass

from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.db.repositories import ClusterRepository, GraphRepository, GraphScoreRunRepository
from app.models.token import WalletClusterProfile
from app.observability.metrics import METRICS
from app.queue.coordination import WorkerCoordinator
from app.observability.spans import async_span
from app.services.ops_alerts import OpsAlerter


@dataclass
class GraphJobResult:
    chain: str
    nodes_scored: int
    clusters_scored: int
    summary: dict


class GraphScoringService:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session
        self.graph_repo = GraphRepository(session)
        self.cluster_repo = ClusterRepository(session)
        self.run_repo = GraphScoreRunRepository(session)

    async def score_chain(self, chain: str) -> GraphJobResult:
        nodes = await self.graph_repo.all_nodes(chain)
        edges = await self.graph_repo.all_edges(chain)
        adj: dict[str, set[str]] = defaultdict(set)
        weighted_degree: dict[str, float] = defaultdict(float)
        suspicious_degree: dict[str, float] = defaultdict(float)

        for edge in edges:
            if edge.weight < settings.graph_edge_weight_threshold:
                continue
            adj[edge.src_wallet].add(edge.dst_wallet)
            adj[edge.dst_wallet].add(edge.src_wallet)
            weighted_degree[edge.src_wallet] += edge.weight
            weighted_degree[edge.dst_wallet] += edge.weight
            if edge.edge_type in {'funding', 'sniper', 'wash_trade', 'insider'}:
                suspicious_degree[edge.src_wallet] += edge.weight
                suspicious_degree[edge.dst_wallet] += edge.weight

        node_count = 0
        for node in nodes:
            degree = len(adj.get(node.wallet_address, set()))
            risk = min(
                100.0,
                node.risk_score
                + weighted_degree.get(node.wallet_address, 0.0) * 8
                + suspicious_degree.get(node.wallet_address, 0.0) * 12
                + degree * 3,
            )
            await self.graph_repo.upsert_node(chain, node.wallet_address, labels=node.labels, risk_score=risk, metadata=node.metadata_json)
            node_count += 1

        visited: set[str] = set()
        clusters_scored = 0
        for start in list(adj.keys()):
            if start in visited:
                continue
            stack = [start]
            component: list[str] = []
            while stack:
                wallet = stack.pop()
                if wallet in visited:
                    continue
                visited.add(wallet)
                component.append(wallet)
                for nxt in adj.get(wallet, set()):
                    if nxt not in visited:
                        stack.append(nxt)
            if not component:
                continue
            component_sorted = sorted(component)
            score = min(100.0, sum(weighted_degree.get(w, 0.0) for w in component_sorted) * 6 + len(component_sorted) * 4)
            labels = ['graph_cluster']
            if score >= 75:
                labels.append('high_risk_graph')
            cluster_head = '|'.join(component_sorted[:3])
            profile = WalletClusterProfile(
                cluster_id=f'{chain}:{cluster_head}',
                wallets=component_sorted,
                risk_score=score,
                labels=labels,
                evidence={'weighted_degree': {w: weighted_degree.get(w, 0.0) for w in component_sorted}},
            )
            await self.cluster_repo.upsert(profile)
            clusters_scored += 1

        summary = {
            'edges': len(edges),
            'active_nodes': len(adj),
            'high_degree_nodes': sum(1 for v in weighted_degree.values() if v >= 2.0),
        }
        await self.run_repo.create(chain, 'SUCCESS', node_count, clusters_scored, summary)
        await METRICS.set_gauge(f'graph_nodes_{chain}', node_count)
        await METRICS.set_gauge(f'graph_clusters_{chain}', clusters_scored)
        return GraphJobResult(chain=chain, nodes_scored=node_count, clusters_scored=clusters_scored, summary=summary)


async def run_graph_jobs_once(session_factory, chains: list[str] | None = None) -> None:
    chains = chains or ['ethereum', 'base', 'bsc', 'solana']
    async with session_factory() as session:
        service = GraphScoringService(session)
        for chain in chains:
            async with async_span('graph.score_chain', chain=chain):
                await service.score_chain(chain)


async def run_graph_jobs_forever(session_factory, chains: list[str] | None = None) -> None:
    coordinator = WorkerCoordinator('graph-jobs')
    await coordinator.start()
    ops_alerts = OpsAlerter()
    chains = chains or ['ethereum', 'base', 'bsc', 'solana']
    try:
        while True:
            async with coordinator.leader(settings.graph_job_leader_key) as acquired:
                if acquired:
                    async with session_factory() as session:
                        service = GraphScoringService(session)
                        for chain in chains:
                            try:
                                async with async_span('graph.score_chain', chain=chain):
                                    async with METRICS.timer(f'graph_job_{chain}'):
                                        await service.score_chain(chain)
                            except Exception as exc:
                                await service.run_repo.create(chain, 'FAILED', 0, 0, {'error': 'graph scoring failed', 'message': str(exc)})
                                await METRICS.incr('graph_job_failures_total')
                                await ops_alerts.notify_failure('graph-jobs', 'graph_scoring_failed', {'chain': chain, 'error': str(exc)})
            await asyncio.sleep(settings.graph_job_interval_seconds)
    finally:
        await coordinator.stop()
