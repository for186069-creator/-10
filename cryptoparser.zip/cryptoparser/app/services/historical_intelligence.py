from __future__ import annotations

from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from typing import Any


@dataclass(slots=True)
class HistoricalRiskSnapshot:
    chain: str
    token_address: str
    launched_at: str | None
    first_decision: str | None
    latest_decision: str | None
    survival_hours: float | None
    peak_liquidity_usd: float | None
    latest_liquidity_usd: float | None
    peak_holders: int | None
    latest_holders: int | None
    rug_flag: bool
    dead_flag: bool
    score: float
    labels: list[str]
    notes: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class HistoricalIntelligenceService:
    """Best-effort historical labeling and survival analysis.

    This layer does not try to prove fraud. It produces machine-readable labels
    that can later be used by the workflow UI and a future ML model.
    """

    def build_snapshot(
        self,
        *,
        chain: str,
        token_address: str,
        first_seen_at: datetime | None,
        first_decision: str | None,
        latest_decision: str | None,
        peak_liquidity_usd: float | None,
        latest_liquidity_usd: float | None,
        peak_holders: int | None,
        latest_holders: int | None,
        reasons: list[str] | None = None,
    ) -> HistoricalRiskSnapshot:
        now = datetime.now(timezone.utc)
        survival_hours = None
        if first_seen_at is not None:
            survival_hours = round((now - first_seen_at).total_seconds() / 3600.0, 2)
        drop_ratio = None
        if peak_liquidity_usd and latest_liquidity_usd is not None and peak_liquidity_usd > 0:
            drop_ratio = latest_liquidity_usd / peak_liquidity_usd
        holder_ratio = None
        if peak_holders and latest_holders is not None and peak_holders > 0:
            holder_ratio = latest_holders / peak_holders

        rug_flag = bool(drop_ratio is not None and drop_ratio < 0.15)
        dead_flag = bool(holder_ratio is not None and holder_ratio < 0.2 and (latest_decision or '') != 'APPROVE')
        labels: list[str] = []
        score = 50.0

        if rug_flag:
            labels.append('historical_rug_pattern')
            score -= 35
        if dead_flag:
            labels.append('historical_dead_pattern')
            score -= 20
        if survival_hours is not None and survival_hours > 168:
            labels.append('survived_7d')
            score += 8
        if latest_decision == 'APPROVE':
            score += 6
        if first_decision == 'REJECT' and latest_decision == 'APPROVE':
            labels.append('recovered_after_review')
            score += 2
        if reasons:
            if 'score_too_low' in reasons:
                score -= 5
            if 'missing_critical_data' in reasons:
                labels.append('incomplete_history')

        score = max(0.0, min(100.0, score))
        return HistoricalRiskSnapshot(
            chain=chain,
            token_address=token_address,
            launched_at=first_seen_at.isoformat() if first_seen_at else None,
            first_decision=first_decision,
            latest_decision=latest_decision,
            survival_hours=survival_hours,
            peak_liquidity_usd=peak_liquidity_usd,
            latest_liquidity_usd=latest_liquidity_usd,
            peak_holders=peak_holders,
            latest_holders=latest_holders,
            rug_flag=rug_flag,
            dead_flag=dead_flag,
            score=score,
            labels=labels,
            notes={
                'drop_ratio': drop_ratio,
                'holder_ratio': holder_ratio,
                'computed_at': now.isoformat(),
            },
        )
