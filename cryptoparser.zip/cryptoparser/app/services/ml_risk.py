from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Any

from app.models.token import BehaviorProfile, SecurityReport, SocialProfile, TokenCandidate, WebsiteProfile


class MLRiskEngine:
    """Lightweight ML-ready scorer.

    This is intentionally transparent. It behaves like a logistic model fed by a
    small set of features and weights stored in JSON. Later this file can be
    replaced by a real model artifact without changing the rest of the pipeline.
    """

    DEFAULT_WEIGHTS = {
        'bias': -0.2,
        'liquidity_log': 0.35,
        'holders_log': 0.25,
        'verified': 0.4,
        'renounced': 0.4,
        'honeypot': -1.2,
        'proxy': -0.7,
        'mint_enabled': -0.8,
        'top10_holder_pct': -0.02,
        'followers_log': 0.15,
        'tweets_log': 0.12,
        'engagement_rate': 0.3,
        'website_ok': 0.2,
        'domain_age_bucket': 0.15,
        'cluster_risk': -0.5,
        'similarity_risk': -0.7,
        'wash_trading_risk': -0.8,
        'bundled_buy': 0.0,  # neutral — FARM path handles it in orchestrator
        'sniper_concentration': -0.4,
        'historical_score': 0.35,
    }

    def __init__(self, weights_path: str | None = None) -> None:
        self.weights = dict(self.DEFAULT_WEIGHTS)
        if weights_path:
            self._load_weights(weights_path)

    def _load_weights(self, weights_path: str) -> None:
        path = Path(weights_path)
        if not path.exists():
            return
        try:
            payload = json.loads(path.read_text(encoding='utf-8'))
            if isinstance(payload, dict):
                self.weights.update({k: float(v) for k, v in payload.items()})
        except Exception:
            return

    @staticmethod
    def _log1p(value: float | int | None) -> float:
        if value is None or value <= 0:
            return 0.0
        return math.log1p(float(value))

    @staticmethod
    def _sigmoid(value: float) -> float:
        return 1.0 / (1.0 + math.exp(-value))

    def build_features(
        self,
        candidate: TokenCandidate,
        security: SecurityReport,
        social: SocialProfile,
        website: WebsiteProfile,
        behavior: BehaviorProfile | None,
        *,
        historical_score: float | None = None,
    ) -> dict[str, float]:
        return {
            'liquidity_log': self._log1p(candidate.liquidity_usd),
            'holders_log': self._log1p(candidate.holders),
            'verified': 1.0 if security.contract_verified else 0.0,
            'renounced': 1.0 if security.renounced or security.mint_authority_none else 0.0,
            'honeypot': 1.0 if security.honeypot else 0.0,
            'proxy': 1.0 if security.proxy else 0.0,
            'mint_enabled': 1.0 if security.mint_enabled else 0.0,
            'top10_holder_pct': float(security.top10_holder_pct or 0.0),
            'followers_log': self._log1p(social.followers),
            'tweets_log': self._log1p(social.tweets),
            'engagement_rate': float(social.engagement_rate or 0.0),
            'website_ok': 1.0 if website.exists and website.https_ok else 0.0,
            'domain_age_bucket': min(1.0, float((website.domain_age_days or 0) / 180.0)),
            'cluster_risk': float(security.cluster_risk or 0.0) / 100.0,
            'similarity_risk': float(security.similarity_risk or 0.0) / 100.0,
            'wash_trading_risk': float((behavior.wash_trading_risk if behavior else 0.0) or 0.0) / 100.0,
            'bundled_buy': 1.0 if behavior and behavior.bundled_buy_detected else 0.0,
            'sniper_concentration': float((behavior.sniper_concentration if behavior else 0.0) or 0.0),
            'historical_score': float(historical_score or 0.0) / 100.0,
        }

    def score(
        self,
        candidate: TokenCandidate,
        security: SecurityReport,
        social: SocialProfile,
        website: WebsiteProfile,
        behavior: BehaviorProfile | None,
        *,
        historical_score: float | None = None,
    ) -> tuple[float, dict[str, float]]:
        feats = self.build_features(candidate, security, social, website, behavior, historical_score=historical_score)
        linear = self.weights['bias']
        contributions: dict[str, float] = {}
        for key, value in feats.items():
            w = self.weights.get(key, 0.0)
            contrib = w * value
            linear += contrib
            contributions[key] = round(contrib, 4)
        probability = self._sigmoid(linear)
        return round(probability * 100.0, 2), contributions
