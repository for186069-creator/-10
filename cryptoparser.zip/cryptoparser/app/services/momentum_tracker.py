from __future__ import annotations
from dataclasses import dataclass, field
from app.models.token import TokenCandidate


@dataclass
class MomentumResult:
    score: float = 0.0
    reasons: list[str] = field(default_factory=list)


class MomentumTracker:
    def analyze(self, candidate: TokenCandidate) -> MomentumResult:
        score = 0.0
        reasons: list[str] = []

        liq = candidate.liquidity_usd or 0
        if liq >= 50_000:
            score += 20; reasons.append('liquidity_strong')
        elif liq >= 10_000:
            score += 10; reasons.append('liquidity_ok')
        elif liq < 1_000:
            score -= 10; reasons.append('liquidity_low')

        holders = candidate.holders or 0
        if holders >= 1000:
            score += 15; reasons.append('holders_high')
        elif holders >= 200:
            score += 8; reasons.append('holders_growing')
        elif holders < 50:
            score -= 8; reasons.append('holders_low')

        fdv = candidate.fdv_usd or 0
        if 0 < fdv <= 5_000_000:
            score += 10; reasons.append('fdv_micro_cap')
        elif fdv > 100_000_000:
            score -= 5; reasons.append('fdv_large_cap')

        return MomentumResult(score=max(-30.0, min(score, 40.0)), reasons=reasons)
