from __future__ import annotations

from app.models.token import Chain, TokenCandidate
from app.utils.text import normalize_handle, normalize_url
from app.utils.token_classifier import classify_token_family


class Normalizer:
    @staticmethod
    def from_dex_profile(profile: dict) -> TokenCandidate | None:
        chain = _chain_from_dex(profile.get('chainId'))
        token_address = profile.get('tokenAddress')
        if not chain or not token_address:
            return None
        raw = dict(profile)
        raw.setdefault('source', 'dexscreener')
        raw.update({k: v for k, v in classify_token_family(chain.value, token_address, raw).items() if v is not None})
        return TokenCandidate(
            chain=chain,
            token_address=token_address,
            website=normalize_url(_extract_link(profile, 'website')),
            x_handle=normalize_handle(_extract_link(profile, 'twitter')),
            telegram_url=normalize_url(_extract_link(profile, 'telegram')),
            raw=raw,
        )

    @staticmethod
    def from_dex_pair(pair: dict) -> 'TokenCandidate | None':
        """Будує TokenCandidate прямо з DexScreener pair об'єкта.
        Використовується для graduated intake де пара вже містить всі дані.
        """
        from datetime import datetime, timezone
        base_token = pair.get('baseToken') or {}
        token_address = base_token.get('address') or ''
        chain = _chain_from_dex(pair.get('chainId'))
        if not chain or not token_address:
            return None

        info = pair.get('info') or {}
        website = normalize_url(_extract_info_link(info, 'website'))
        x_handle = normalize_handle(_extract_info_link(info, 'twitter'))
        telegram_url = normalize_url(_extract_info_link(info, 'telegram'))

        # Час створення пари
        pair_created_at = pair.get('pairCreatedAt')
        first_seen: datetime | None = None
        if pair_created_at:
            try:
                first_seen = datetime.fromtimestamp(pair_created_at / 1000, tz=timezone.utc)
            except Exception:
                pass

        raw = {
            'source': 'dexscreener_graduated',
            'pair': pair,
            'chainId': pair.get('chainId'),
            'dexId': pair.get('dexId'),
            'volume_h24': float((pair.get('volume') or {}).get('h24') or 0),
            'txns_h24': int((pair.get('txns') or {}).get('h24', {}).get('buys') or 0) + int((pair.get('txns') or {}).get('h24', {}).get('sells') or 0),
            'price_change_h24': (pair.get('priceChange') or {}).get('h24'),
        }
        raw.update({k: v for k, v in classify_token_family(chain.value, token_address, raw).items() if v is not None})

        links: dict = {}
        if website: links['website'] = website
        if x_handle: links['x'] = x_handle
        if telegram_url: links['telegram'] = telegram_url

        return TokenCandidate(
            chain=chain,
            token_address=token_address,
            pair_address=pair.get('pairAddress'),
            symbol=base_token.get('symbol'),
            name=base_token.get('name'),
            liquidity_usd=float((pair.get('liquidity') or {}).get('usd') or 0) or None,
            fdv_usd=float(pair.get('fdv') or 0) or None,
            website=website,
            x_handle=x_handle,
            telegram_url=telegram_url,
            links=links,
            first_seen_at=first_seen,
            raw=raw,
        )

    @staticmethod
    def enrich_from_pair(candidate: TokenCandidate, pair: dict) -> TokenCandidate:
        from datetime import datetime, timezone

        base_token = pair.get('baseToken') or {}
        candidate.pair_address = pair.get('pairAddress') or candidate.pair_address
        candidate.symbol = base_token.get('symbol') or candidate.symbol
        candidate.name = base_token.get('name') or candidate.name
        candidate.liquidity_usd = _to_float((pair.get('liquidity') or {}).get('usd')) or candidate.liquidity_usd
        candidate.fdv_usd = _to_float(pair.get('fdv')) or candidate.fdv_usd
        candidate.market_cap_usd = _to_float(pair.get('marketCap')) or candidate.market_cap_usd
        info = pair.get('info') or {}
        candidate.website = candidate.website or normalize_url(_extract_info_link(info, 'website'))
        candidate.x_handle = candidate.x_handle or normalize_handle(_extract_info_link(info, 'twitter'))
        candidate.telegram_url = candidate.telegram_url or normalize_url(_extract_info_link(info, 'telegram'))
        candidate.links.update({k: v for k, v in {'website': candidate.website, 'x': candidate.x_handle or '', 'telegram': candidate.telegram_url or ''}.items() if v})
        candidate.raw['pair'] = pair
        pair_created_at = pair.get('pairCreatedAt')
        if pair_created_at:
            try:
                pair_dt = datetime.fromtimestamp(pair_created_at / 1000, tz=timezone.utc)
                candidate.raw['pair_created_at'] = pair_dt.isoformat()
                if pair_dt < candidate.first_seen_at:
                    candidate.first_seen_at = pair_dt
            except Exception:
                pass
        candidate.raw.update({k: v for k, v in classify_token_family(candidate.chain.value, candidate.token_address, candidate.raw).items() if v is not None})
        return candidate


    @staticmethod
    def from_pumpfun_intake(item: dict) -> TokenCandidate | None:
        address = item.get('mint') or item.get('token_address')
        if not address:
            return None
        raw = dict(item)
        raw.setdefault('source', str(item.get('source') or 'pumpfun').lower())
        raw.setdefault('website', item.get('coin_url'))
        raw.update({k: v for k, v in classify_token_family('solana', address, raw).items() if v is not None})
        title = str(item.get('title') or '').strip()
        symbol = None
        name = None
        if title:
            head = title.split(' on SOLANA')[0].split(' | Pump')[0].strip()
            if "$" in head:
                name, _, maybe_symbol = head.partition("$")
                name = name.strip() or None
                symbol = maybe_symbol.strip() or None
            else:
                name = head or None
        website = normalize_url(item.get('website') or item.get('coin_url'))
        x_handle = normalize_handle(item.get('x_url'))
        links = {}
        if website:
            links['website'] = website
        if x_handle:
            links['x'] = x_handle
        return TokenCandidate(
            chain=Chain.SOLANA,
            token_address=address,
            symbol=symbol,
            name=name,
            website=website,
            x_handle=x_handle,
            links=links,
            raw=raw,
        )

    @staticmethod
    def from_birdeye_listing(item: dict) -> TokenCandidate | None:
        address = item.get('address') or item.get('mint')
        if not address:
            return None
        ext = item.get('extensions', {})
        raw = dict(item)
        raw.setdefault('source', 'birdeye')
        raw.update({k: v for k, v in classify_token_family('solana', address, raw).items() if v is not None})
        return TokenCandidate(
            chain=Chain.SOLANA,
            token_address=address,
            symbol=item.get('symbol'),
            name=item.get('name'),
            liquidity_usd=_to_float(item.get('liquidity')),
            holders=item.get('holder') or item.get('holders'),
            website=normalize_url(ext.get('website')),
            x_handle=normalize_handle(ext.get('twitter')),
            telegram_url=normalize_url(ext.get('telegram')),
            raw=raw,
        )


def _chain_from_dex(chain_id: str | None) -> Chain | None:
    mapping = {'solana': Chain.SOLANA, 'ethereum': Chain.ETHEREUM, 'bsc': Chain.BSC, 'base': Chain.BASE}
    return mapping.get((chain_id or '').lower())


def _extract_link(profile: dict, link_type: str) -> str | None:
    for link in profile.get('links') or []:
        if (link.get('type') or '').lower() == link_type:
            return link.get('url')
    return None


def _extract_info_link(info: dict, label: str) -> str | None:
    for website in info.get('websites') or []:
        if label == 'website':
            return website.get('url')
    for social in info.get('socials') or []:
        if (social.get('type') or '').lower() == label:
            return social.get('url')
    return None


def _to_float(value: object) -> float | None:
    try:
        return float(value) if value is not None else None
    except (TypeError, ValueError):
        return None
