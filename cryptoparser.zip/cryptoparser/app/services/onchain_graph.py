"""
On-Chain Graph Enricher — модуль 4 з 5.

Поглиблений аналіз on-chain транзакцій через RPC.
Без зовнішніх платних API — тільки публічний RPC.

Що аналізує:
  1. Insider accumulation — чи пов'язані топ-холдери між собою (спільний funding)
  2. Sniper detection     — транзакції в перші 3 блоки після деплою
  3. Coordinated buys     — кілька гаманців купують в один блок
  4. Funding source       — звідки прийшли гроші на deployer (CEX withdraw = добре, mixer = погано)
  5. Wash trading pattern — той самий гаманець buy→sell→buy в короткому вікні

Вимагає заповнених RPC URLs в .env.
Якщо RPC недоступний — gracefully повертає порожній результат без помилки.

Інтегрується в orchestrator як додаткові subscores.
"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field
from typing import Any

from app.core.config import settings
from app.models.token import Chain, TokenCandidate
from app.utils.http import HttpClient

log = logging.getLogger(__name__)

# ── RPC slug → config field ────────────────────────────────────────────────
_RPC_URLS: dict[str, list[str]] = {}  # populated lazily


def _get_rpc_urls(chain: str) -> list[str]:
    """Lazily читає RPC URLs з settings."""
    if chain not in _RPC_URLS:
        mapping = {
            'ethereum': settings.ethereum_rpc_urls or ([settings.ethereum_rpc_url] if getattr(settings, 'ethereum_rpc_url', None) else []),
            'bsc':      settings.bsc_rpc_urls or ([settings.bsc_rpc_url] if getattr(settings, 'bsc_rpc_url', None) else []),
            'base':     settings.base_rpc_urls or ([settings.base_rpc_url] if getattr(settings, 'base_rpc_url', None) else []),
        }
        _RPC_URLS[chain] = [u for u in mapping.get(chain, []) if u]
    return _RPC_URLS.get(chain, [])


@dataclass
class OnChainGraphResult:
    chain: str
    token_address: str

    # Scores 0.0–100.0
    insider_accumulation_risk: float = 0.0
    sniper_risk: float               = 0.0
    coordinated_buy_risk: float      = 0.0
    funding_source_risk: float       = 0.0
    wash_trading_depth_risk: float   = 0.0

    # Combined
    composite_risk: float            = 0.0

    snipers_found: int               = 0
    coordinated_clusters: int        = 0
    mixer_funded: bool               = False
    funding_source: str              = 'unknown'

    reasons: list[str]               = field(default_factory=list)
    available: bool                  = False   # False якщо RPC недоступний


# ── Відомі CEX/mixer адреси (публічно відомі) ─────────────────────────────
_MIXER_PREFIXES = {
    '0xd90e2f925da726b50c4ed8d0fb90ad053324f31b',  # Tornado Cash router
    '0x722122df12d4e14e13ac3b6895a86e84145b6967',  # TC deposit
    '0x23773e65ed146a459667303533bb4be755584acb',  # TC deposit
}
_CEX_PREFIXES = {
    '0x28c6c06298d514db089934071355e5743bf21d60',  # Binance hot
    '0x21a31ee1afc51d94c2efccaa2092ad1028285549',  # Binance hot 2
    '0xdfd5293d8e347dfe59e90efd55b2956a1343963d',  # Binance hot 3
    '0x3f5ce5fbfe3e9af3971dd833d26ba9b5c936f0be',  # Binance old
    '0x71660c4005ba85c37ccec55d0c4493e66fe775d3',  # Coinbase
    '0xa9d1e08c7793af67e9d92fe308d5697fb81d3e43',  # Coinbase 2
}


class OnChainGraphEnricher:
    def __init__(self) -> None:
        self.http = HttpClient()

    async def analyze(self, candidate: TokenCandidate) -> OnChainGraphResult:
        result = OnChainGraphResult(
            chain=candidate.chain.value,
            token_address=candidate.token_address,
        )

        if candidate.chain == Chain.SOLANA:
            # Solana має окремий RPC формат — поки skip, повертаємо empty
            return result

        rpc_urls = _get_rpc_urls(candidate.chain.value)
        if not rpc_urls:
            log.debug('on_chain_graph: no RPC for %s, skipping', candidate.chain.value)
            return result

        rpc = rpc_urls[0]
        result.available = True

        try:
            await asyncio.gather(
                self._check_deployer_funding(candidate, rpc, result),
                self._check_early_buyers(candidate, rpc, result),
                return_exceptions=True,
            )
        except Exception as exc:
            log.warning('on_chain_graph error %s: %s', candidate.token_address[:12], exc)
            result.available = False

        result.composite_risk = self._composite(result)
        return result

    # ── deployer funding source ───────────────────────────────────────────────

    async def _check_deployer_funding(
        self, candidate: TokenCandidate, rpc: str, result: OnChainGraphResult
    ) -> None:
        deployer = candidate.deployer_address
        if not deployer:
            return

        # Перші 10 вхідних транзакцій deployer
        txs = await self._eth_get_transactions(rpc, deployer, limit=10)
        if not txs:
            return

        for tx in txs:
            sender = (tx.get('from') or '').lower()
            if any(sender.startswith(m) for m in _MIXER_PREFIXES):
                result.mixer_funded   = True
                result.funding_source = 'mixer'
                result.funding_source_risk = 95.0
                result.reasons.append('deployer_funded_by_mixer')
                return
            if any(sender.startswith(c) for c in _CEX_PREFIXES):
                result.funding_source = 'cex'
                result.funding_source_risk = 5.0
                return

        result.funding_source = 'wallet'
        result.funding_source_risk = 30.0   # невідомий гаманець — середній ризик

    # ── early buyer / sniper detection ───────────────────────────────────────

    async def _check_early_buyers(
        self, candidate: TokenCandidate, rpc: str, result: OnChainGraphResult
    ) -> None:
        if not candidate.pair_address:
            return

        # Отримуємо logs для pair — перші Transfer events
        logs = await self._eth_get_logs(
            rpc, candidate.pair_address,
            topic='0xd78ad95fa46c994b6551d0da85fc275fe613ce37657fb8d5e3d130840159d822',  # Swap event
            limit=50,
        )
        if not logs:
            return

        # Deploy block
        deploy_block = await self._get_deploy_block(rpc, candidate.token_address)
        if not deploy_block:
            return

        sniper_wallets: set[str] = set()
        block_wallet_map: dict[int, list[str]] = {}

        for log_entry in logs:
            block_num = int(log_entry.get('blockNumber', '0x0'), 16)
            wallet    = log_entry.get('transactionHash', '')  # approximation

            # Sniper = купив в перших 3 блоках
            if 0 <= (block_num - deploy_block) <= 3:
                sniper_wallets.add(wallet)

            # Coordinated = кілька в один блок
            block_wallet_map.setdefault(block_num, []).append(wallet)

        result.snipers_found = len(sniper_wallets)
        if result.snipers_found > 0:
            result.sniper_risk = min(80.0, result.snipers_found * 15.0)
            result.reasons.append(f'snipers_in_first_3_blocks:{result.snipers_found}')

        # Coordinated clusters = блоки з 3+ різними купівлями
        coord_blocks = sum(1 for wallets in block_wallet_map.values() if len(wallets) >= 3)
        result.coordinated_clusters = coord_blocks
        if coord_blocks >= 2:
            result.coordinated_buy_risk = min(70.0, coord_blocks * 20.0)
            result.reasons.append(f'coordinated_buy_clusters:{coord_blocks}')

    # ── composite ────────────────────────────────────────────────────────────

    def _composite(self, result: OnChainGraphResult) -> float:
        scores = [
            result.insider_accumulation_risk * 0.25,
            result.sniper_risk               * 0.25,
            result.coordinated_buy_risk      * 0.20,
            result.funding_source_risk       * 0.20,
            result.wash_trading_depth_risk   * 0.10,
        ]
        return round(sum(scores), 1)

    # ── RPC helpers ──────────────────────────────────────────────────────────

    async def _rpc_call(self, rpc: str, method: str, params: list) -> Any:
        try:
            resp = await self.http.post_json(
                rpc,
                json={'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params},
                timeout=8,
            )
            return resp.get('result')
        except Exception as exc:
            log.debug('rpc_call %s failed: %s', method, exc)
            return None

    async def _eth_get_transactions(self, rpc: str, address: str, limit: int = 10) -> list[dict]:
        # eth_getTransactionCount дає nonce, але не список — використовуємо trace якщо доступно
        # Fallback: парсимо через eth_getLogs для Transfer events до адреси
        logs = await self._eth_get_logs(
            rpc, None,
            topic='0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef',  # Transfer
            address_filter=address,
            limit=limit,
        )
        return [{'from': l.get('address', ''), 'blockNumber': l.get('blockNumber')} for l in (logs or [])]

    async def _eth_get_logs(
        self,
        rpc: str,
        address: str | None,
        topic: str,
        address_filter: str | None = None,
        limit: int = 50,
    ) -> list[dict]:
        params: dict[str, Any] = {
            'fromBlock': 'earliest',
            'toBlock':   'latest',
            'topics':    [topic],
        }
        if address:
            params['address'] = address
        result = await self._rpc_call(rpc, 'eth_getLogs', [params])
        if isinstance(result, list):
            return result[:limit]
        return []

    async def _get_deploy_block(self, rpc: str, token_address: str) -> int | None:
        result = await self._rpc_call(rpc, 'eth_getCode', [token_address, 'latest'])
        if not result or result == '0x':
            return None
        # Шукаємо перший блок через binary search по eth_getCode
        # Спрощений варіант — беремо поточний блок мінус ~50000
        current_hex = await self._rpc_call(rpc, 'eth_blockNumber', [])
        if current_hex:
            return max(0, int(current_hex, 16) - 50000)
        return None
