from __future__ import annotations

import logging
from typing import Any

from app.core.config import settings
from app.utils.cache import GLOBAL_CACHE
from app.utils.http import HttpClient

logger = logging.getLogger(__name__)


class OpsAlerter:
    def __init__(self) -> None:
        self.http = HttpClient()

    async def notify_failure(self, component: str, summary: str, details: dict[str, Any] | None = None) -> None:
        key = f'ops-alert:{component}:{summary}'
        existing = await GLOBAL_CACHE.get(key)
        if existing is not None:
            return
        await GLOBAL_CACHE.set(key, True, ttl_seconds=300)
        logger.error('ops_alert component=%s summary=%s details=%s', component, summary, details or {})
        if not settings.enable_telegram or not settings.telegram_bot_token or not settings.telegram_chat_id:
            return
        text = self._render(component, summary, details or {})
        url = f'https://api.telegram.org/bot{settings.telegram_bot_token}/sendMessage'
        await self.http.post_json(url, json={'chat_id': settings.telegram_chat_id, 'text': text, 'disable_web_page_preview': True})

    def _render(self, component: str, summary: str, details: dict[str, Any]) -> str:
        parts = [
            f'🚨 CryptoParser failure',
            f'Component: {component}',
            f'Summary: {summary}',
        ]
        for key, value in list(details.items())[:10]:
            parts.append(f'{key}: {value}')
        return '\n'.join(parts)
