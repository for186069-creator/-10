from __future__ import annotations

import asyncio
import logging
import os
from datetime import datetime
from sqlalchemy.ext.asyncio import AsyncSession

from app.adapters.birdeye import BirdeyeClient
from app.adapters.security import SecurityService
from app.db.repositories import (
    AuditRepository,
    ClusterRepository,
    DeployerRepository,
    FingerprintRepository,
    GraphRepository,
    HistoricalRepository,
    RealtimeAlertRepository,
    AnalystLabelRepository,
    ManualReviewRepository,
    ReputationRepository,
    TokenRepository,
)
from app.models.token import TokenCandidate, TokenSnapshot
from app.observability.metrics import METRICS
from app.risk.engine import RiskEngine
from app.scrapers.website_scraper import WebsiteScraper
from app.scrapers.x_scraper import XScraper
from app.services.alerts import TelegramAlerter
from app.services.behavior import BehaviorService
from app.services.advanced_graph import AdvancedGraphScoringService
from app.services.alert_intelligence import AlertIntelligenceService
from app.services.historical_intelligence import HistoricalIntelligenceService
from app.services.ml_risk import MLRiskEngine
from app.services.clustering import WalletClusteringService
from app.services.deployer_history import DeployerHistoryService
from app.services.explorer_enrichment import ExplorerEnrichmentService
from app.services.reputation import ReputationService
from app.services.similarity import ContractSimilarityService
from app.services.engagement_auth import EngagementAuthenticator
from app.services.cross_chain_fingerprint import CrossChainFingerprinter
from app.services.community_signals import CommunitySignalsAggregator
from app.services.onchain_graph import OnChainGraphEnricher
from app.observability.spans import async_span
from app.core.config import settings
from app.services.bundle_analyzer import analyze_bundle, bundle_analysis_from_metrics
from app.services.gem_predictor import GemPredictor
from app.services.decay_engine import analyze_decay
from app.services.pulse.lifecycle import extract_price_from_candidate
from app.services.pulse.decision_engine import DecisionEngine, SignalBundle
from app.services.pulse.risk_guard import collect_signal_reasons, hard_block_reason, risk_tier, risk_size_multiplier
from app.utils.token_classifier import classify_decision_profile


logger = logging.getLogger(__name__)


class Orchestrator:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session
        self.security = SecurityService()
        self.birdeye = BirdeyeClient()
        self.x_scraper = XScraper()
        self.website_scraper = WebsiteScraper()
        self.engine = RiskEngine()
        self.tokens = TokenRepository(session)
        self.audit = AuditRepository(session)
        self.reputation_repo = ReputationRepository(session)
        self.reputation = ReputationService(self.reputation_repo, DeployerRepository(session))
        self.similarity = ContractSimilarityService(FingerprintRepository(session))
        self.behavior = BehaviorService()
        self.alerts = TelegramAlerter()
        self.deployer_history = DeployerHistoryService(DeployerRepository(session))
        self.explorer = ExplorerEnrichmentService(DeployerRepository(session), GraphRepository(session))
        self.clustering = WalletClusteringService(ClusterRepository(session))
        self.manual_reviews = ManualReviewRepository(session)
        self.historical = HistoricalRepository(session)
        self.alert_events = RealtimeAlertRepository(session)
        self.analyst_labels = AnalystLabelRepository(session)
        self.historical_service = HistoricalIntelligenceService()
        self.ml_risk = MLRiskEngine()
        self.advanced_graph = AdvancedGraphScoringService()
        self.alert_intelligence = AlertIntelligenceService()
        self.engagement_auth = EngagementAuthenticator()
        self.cross_chain_fp  = CrossChainFingerprinter(session)
        self.community       = CommunitySignalsAggregator()
        self.onchain_graph   = OnChainGraphEnricher()
        self.gem_predictor   = GemPredictor()
        self.decision_engine = DecisionEngine()

    @staticmethod
    def _extract_solana_holder_count(security: object) -> int | None:
        try:
            token = (getattr(security, 'raw', {}) or {}).get('goplus_solana') or {}
            value = token.get('holder_count')
            if value is None:
                return None
            count = int(value)
            return count if count >= 0 else None
        except Exception:
            return None

    @staticmethod
    def _extract_holder_count_from_security(candidate: TokenCandidate, security: object) -> int | None:
        try:
            raw = getattr(security, 'raw', {}) or {}
            if candidate.chain.value == 'solana':
                token = raw.get('goplus_solana') or {}
                value = token.get('holder_count')
            else:
                token = raw.get('goplus_evm') or {}
                value = token.get('holder_count')
                if value is None:
                    value = token.get('holders')
                if value is None:
                    value = token.get('holder')
            if value is None:
                return None
            count = int(value)
            return count if count >= 0 else None
        except Exception:
            return None

    @staticmethod
    def _parse_holder_count_from_birdeye(payload: dict | None) -> int | None:
        if not isinstance(payload, dict):
            return None
        for key in ('holder', 'holders', 'holder_count'):
            value = payload.get(key)
            if value is None:
                continue
            try:
                count = int(value)
            except Exception:
                continue
            if count >= 0:
                return count
        return None

    @staticmethod
    def _pump_graduated_min_holders(chain_value: str) -> int:
        try:
            by_chain = getattr(settings, 'pump_graduated_min_holders_by_chain', {}) or {}
            chain_key = str(chain_value or '').lower()
            if chain_key in by_chain and by_chain.get(chain_key) is not None:
                return int(by_chain.get(chain_key))
        except Exception:
            pass
        return int(getattr(settings, 'pump_graduated_min_holders', 0) or 0)

    async def _enforce_graduated_holders_refresh(self, candidate: TokenCandidate, security: object) -> tuple[bool, str | None]:
        if not bool(getattr(settings, 'pump_graduated_require_holders_refresh_for_approve', True)):
            return True, None

        source = None
        holders = self._extract_holder_count_from_security(candidate, security)
        if holders is not None and holders > 0:
            source = 'goplus'
        elif candidate.chain.value == 'solana':
            try:
                overview = await self.birdeye.token_overview(candidate.token_address)
            except Exception:
                overview = None
            holders = self._parse_holder_count_from_birdeye(overview)
            if holders is not None and holders > 0:
                source = 'birdeye'

        if holders is None or holders <= 0:
            return False, 'holders_refresh_required'

        candidate.holders = int(holders)
        candidate.raw = dict(candidate.raw or {})
        candidate.raw['holders_source'] = source or 'refresh'
        candidate.raw['holders_refresh_at'] = datetime.utcnow().isoformat()

        min_holders = self._pump_graduated_min_holders(candidate.chain.value)
        if int(candidate.holders) < int(min_holders):
            return False, 'holders_refresh_below_min'
        return True, None

    async def evaluate(self, candidate: TokenCandidate):
        # ── GUARD: reject non-real token addresses (cg:xxx CoinGecko slugs etc) ──
        _addr  = str(candidate.token_address or '')
        _chain = str(getattr(candidate.chain, 'value', candidate.chain) or '').lower()
        _is_evm = _chain in ('bsc', 'base', 'ethereum')
        _is_sol = _chain == 'solana'
        _bad = (
            _addr.startswith('cg:') or _addr.startswith('cmc:') or
            (_is_evm and (not _addr.startswith('0x') or len(_addr) != 42)) or
            (_is_sol and len(_addr) < 32) or ' ' in _addr
        )
        if _bad:
            logger.debug('skip invalid addr %s chain=%s', _addr, _chain)
            return None  # caller must check for None
        # ─────────────────────────────────────────────────────────────────────
        async with async_span('orchestrator.evaluate', chain=candidate.chain.value, token_address=candidate.token_address):
            async with METRICS.timer('orchestrator_evaluate'):
                await METRICS.incr('tokens_seen_total')
                await self.tokens.upsert_candidate(candidate)
                fast_gem = self.gem_predictor.fast(candidate)
                candidate.raw = dict(candidate.raw or {})
                candidate.raw['fast_verdict'] = fast_gem.to_dict()
                candidate.raw['verdict_stage'] = 'FAST'
                await self.tokens.upsert_candidate(candidate)
                import logging as _log
                _olog = _log.getLogger(__name__)
                from app.models.token import SecurityReport as _SR, SocialProfile as _SP, WebsiteProfile as _WP
                try:
                    security = await self.security.analyze(candidate)
                except Exception as _e:
                    _olog.warning('security.analyze failed: %s', _e)
                    security = _SR()
                if candidate.chain.value == 'solana' and (candidate.holders is None or int(candidate.holders or 0) <= 0):
                    holder_count = self._extract_solana_holder_count(security)
                    if holder_count is not None and holder_count > 0:
                        candidate.holders = holder_count
                        candidate.raw = dict(candidate.raw or {})
                        candidate.raw['holders_source'] = 'goplus_solana'
                        candidate.raw['holders_refresh_at'] = datetime.utcnow().isoformat()
                try:
                    candidate, security, explorer_profile = await self.explorer.enrich(candidate, security)
                except Exception as _e:
                    _olog.warning('explorer.enrich failed: %s', _e)
                    explorer_profile = None
                try:
                    security = await self.reputation.apply(candidate, security)
                    deployer_profile = explorer_profile or await self.deployer_history.enrich(candidate)
                    if deployer_profile:
                        security = await self.reputation.apply_deployer_profile(candidate.chain.value, deployer_profile, security)
                    security = await self.similarity.apply(candidate, security)
                    security = await self.clustering.apply(candidate, security)
                except Exception as _e:
                    _olog.warning('enrichment chain failed: %s', _e)
                try:
                    social = await self.x_scraper.fetch_profile(candidate.x_handle, candidate.token_address)
                except Exception as _e:
                    _olog.warning('x_scraper failed: %s', _e)
                    social = _SP()
                try:
                    website = await self.website_scraper.fetch_profile(candidate.website, candidate.token_address)
                except Exception as _e:
                    _olog.warning('website_scraper failed: %s', _e)
                    website = _WP()
                behavior = self.behavior.analyze(candidate, security)
                early_trades = getattr(candidate, 'early_trades', None) or (candidate.raw or {}).get('early_trades') or []
                bundle_metrics = analyze_bundle(early_trades)
                candidate.raw = dict(candidate.raw or {})
                candidate.raw['bundle'] = bundle_metrics

                # â”€â”€ 4 Ð½Ð¾Ð²Ð¸Ñ… Ð¼Ð¾Ð´ÑƒÐ»Ñ– Ð¿Ð°Ñ€Ð°Ð»ÐµÐ»ÑŒÐ½Ð¾ â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
                _gather_results = await asyncio.gather(
                    self.engagement_auth.analyze(candidate.x_handle, social.raw if social else {}),
                    self.community.analyze(candidate),
                    self.onchain_graph.analyze(candidate),
                    self.cross_chain_fp.analyze(candidate, security),
                    return_exceptions=True,
                )

                # Ð‘ÐµÐ·Ð¿ÐµÑ‡Ð½Ð¸Ð¹ Ñ€Ð¾Ð·Ð¿Ð°ÐºÑƒÐ²Ð°Ð½Ð½Ñ â€” ÑÐºÑ‰Ð¾ Ð¼Ð¾Ð´ÑƒÐ»ÑŒ Ð²Ð¿Ð°Ð², Ð²Ð¸ÐºÐ¾Ñ€Ð¸ÑÑ‚Ð¾Ð²ÑƒÑ”Ð¼Ð¾ Ð´ÐµÑ„Ð¾Ð»Ñ‚
                from app.services.engagement_auth import BotSignal
                from app.services.community_signals import CommunitySignal
                from app.services.onchain_graph import OnChainGraphResult

                def _safe(result, default):
                    if isinstance(result, BaseException):
                        import logging as _log
                        _log.getLogger(__name__).warning('gather module failed: %s', result)
                        return default
                    return result

                engagement_signal = _safe(_gather_results[0], BotSignal(handle=candidate.x_handle or ''))
                community_signal  = _safe(_gather_results[1], CommunitySignal(token_address=candidate.token_address, chain=candidate.chain.value))
                onchain_result    = _safe(_gather_results[2], OnChainGraphResult(chain=candidate.chain.value, token_address=candidate.token_address))
                _cross = _safe(_gather_results[3], (0.0, []))
                cross_chain_risk, cross_chain_matches = _cross

                # Engagement: bot signal â†’ Ð¿Ñ–Ð´Ð²Ð¸Ñ‰ÑƒÑ”Ð¼Ð¾ Ñ€Ð¸Ð·Ð¸Ðº
                if engagement_signal.bot_probability > 0.5:
                    social.suspicious = True
                    social.reasons.append(f'bot_probability:{engagement_signal.bot_probability:.2f}')
                    social.reasons.extend(engagement_signal.reasons)

                # Community consensus â†’ honeypot override
                if community_signal.scam_consensus:
                    security.honeypot = True
                    security.reasons = list(getattr(security, 'reasons', [])) + community_signal.reasons
                neighbor_edges = []
                node_risks = {}
                if security.funding_wallet:
                    neighbor_edges = await self.explorer.graph_repo.neighbors(candidate.chain.value, security.funding_wallet)
                graph_meta = self.advanced_graph.score_wallet(security.funding_wallet or candidate.deployer_address or candidate.token_address, neighbor_edges, node_risks)
                security.cluster_risk = max(float(security.cluster_risk or 0.0), float(graph_meta.get('graph_score', 0.0)))

                historical_row = await self.historical.get(candidate.chain.value, candidate.token_address)
                historical_score = float(historical_row.historical_score) if historical_row else None
                decay_metrics = analyze_decay(candidate, historical_row)
                candidate.raw = dict(candidate.raw or {})
                candidate.raw['decay'] = decay_metrics.to_dict()
                decision = self.engine.evaluate(candidate, security, social, website, behavior)

                # ── SAFETY FLAGS: built from risk engine output for PULSE gate ──
                # Field names match actual SecurityReport / TokenCandidate / BehaviorProfile models.

                # Pre-graduation bundle check: якщо watchlist_poller вже бачив
                # high/medium bundle ДО graduation — рахуємо як bundled_buy
                _pre_grad_bundle = False
                try:
                    from app.services.pulse.lifecycle import LifecycleService
                    _lc_svc = LifecycleService(self.session)
                    _existing_lc = await _lc_svc.get_lifecycle(
                        str(getattr(candidate.chain, 'value', candidate.chain)),
                        candidate.token_address
                    )
                    if _existing_lc and _existing_lc.bundle_severity in ('high', 'medium'):
                        _pre_grad_bundle = True
                        logger.info(
                            'orchestrator pre_graduation_bundle_confirmed token=%s severity=%s supply_pct=%.1f',
                            candidate.token_address[:12],
                            _existing_lc.bundle_severity,
                            float(_existing_lc.bundle_supply_pct or 0)
                        )
                except Exception as _lc_err:
                    logger.debug('pre_grad_bundle_check failed: %s', _lc_err)

                _behavior_bundle = bool(behavior and getattr(behavior, 'bundled_buy_detected', False))

                # Pre-graduation smart_wallet check: якщо watchlist_poller вже бачив
                # trusted dev (wallet_rep >= 70) ДО graduation
                _pre_grad_wallet_rep = 0.0
                try:
                    if _existing_lc:
                        _meta = _existing_lc.execution_metadata or {}
                        _pre_grad_wallet_rep = float(_meta.get('pre_grad_wallet_rep') or 0)
                        if _pre_grad_wallet_rep >= 70:
                            logger.info(
                                'orchestrator pre_graduation_trusted_dev token=%s wallet_rep=%.1f',
                                candidate.token_address[:12], _pre_grad_wallet_rep
                            )
                except Exception:
                    pass

                risk_result = {
                    "flags": {
                        "honeypot":             bool(getattr(security, 'honeypot', False)),
                        "rug_risk":             bool(getattr(security, 'rugpull_risk', False)),      # SecurityReport.rugpull_risk
                        "blacklist":            bool(getattr(security, 'blacklist_function', False)),# SecurityReport.blacklist_function
                        "buy_tax":              float(getattr(candidate, 'taxes_buy_pct', 0) or 0), # TokenCandidate.taxes_buy_pct
                        "sell_tax":             float(getattr(candidate, 'taxes_sell_pct', 0) or 0),# TokenCandidate.taxes_sell_pct
                        "bundled_buy_detected": _behavior_bundle or _pre_grad_bundle,
                    }
                }
                if True:  # ML score Ñ€Ð°Ñ…ÑƒÑ”Ñ‚ÑŒÑÑ Ð·Ð°Ð²Ð¶Ð´Ð¸; historical_score Ð¿ÐµÑ€ÐµÐ´Ð°Ñ”Ñ‚ÑŒÑÑ ÑÐº optional feature
                    ml_score, ml_contrib = self.ml_risk.score(candidate, security, social, website, behavior, historical_score=historical_score)
                    decision.evidence['ml_risk'] = {'score': ml_score, 'contributions': ml_contrib}
                    blended = round((decision.score * (1.0 - 0.35)) + (ml_score * 0.35), 2)

                    # Community penalty â€” ÑÐºÑ‰Ð¾ Ð¿Ñ€Ð¾Ð²Ð°Ð¹Ð´ÐµÑ€Ð¸ ÐºÐ°Ð¶ÑƒÑ‚ÑŒ SCAM, Ñ‚ÑÐ³Ð½ÐµÐ¼Ð¾ score Ð²Ð½Ð¸Ð·
                    community_penalty = 0.0
                    if community_signal.providers_available > 0:
                        # community aggregate_risk 0-100 â†’ penalty 0-20 Ð±Ð°Ð»Ñ–Ð²
                        community_penalty = round((community_signal.aggregate_risk / 100.0) * 20.0, 2)
                        blended = round(blended - community_penalty, 2)

                    # Onchain penalty â€” mixer funding Ð°Ð±Ð¾ snipers
                    onchain_penalty = 0.0
                    if onchain_result.available:
                        onchain_penalty = round((onchain_result.composite_risk / 100.0) * 15.0, 2)
                        blended = round(blended - onchain_penalty, 2)

                    # Cross-chain penalty
                    if cross_chain_risk > 60:
                        xchain_penalty = round((cross_chain_risk / 100.0) * 10.0, 2)
                        blended = round(blended - xchain_penalty, 2)
                        decision.reasons.append(f'cross_chain_match_risk:{cross_chain_risk:.0f}')

                    # Engagement bot penalty
                    if engagement_signal.bot_probability > 0.6:
                        bot_penalty = round(engagement_signal.bot_probability * 10.0, 2)
                        blended = round(blended - bot_penalty, 2)
                        decision.reasons.append(f'bot_signal:{engagement_signal.bot_probability:.2f}')

                    blended = max(0.0, min(100.0, blended))
                    decision.score = blended
                    decision.subscores['ml_risk'] = ml_score
                    decision_profile = str((decision.evidence or {}).get('decision_profile') or '')
                    # NOTE: ml_approve_score / ml_review_score kept for evidence only;
                    # final status is determined exclusively by PULSE gate below.
                    if decision_profile == 'pump_early':
                        ml_approve_score = float(settings.pump_early_approve_score)
                        ml_review_score  = float(settings.pump_early_review_score)
                    elif decision_profile == 'pump_graduated':
                        ml_approve_score = float(settings.pump_graduated_approve_score)
                        ml_review_score  = float(settings.pump_graduated_review_score)
                    else:
                        ml_approve_score = float(settings.approve_score)
                        ml_review_score  = float(settings.review_score)
                    decision.evidence['ml_thresholds'] = {
                        'approve': ml_approve_score,
                        'review':  ml_review_score,
                        'blended': blended,
                    }

                # GEM prediction — зберігаємо в evidence
                try:
                    gem_result = self.gem_predictor.full(
                        candidate, security,
                        social if isinstance(social, type(social)) else None,
                        website if isinstance(website, type(website)) else None,
                        behavior,
                        extras={
                            'community_risk': community_signal.aggregate_risk,
                            'cross_chain_risk': cross_chain_risk,
                            'engagement_bot_probability': engagement_signal.bot_probability,
                            'bundle': bundle_metrics,
                            'decay': decay_metrics.to_dict(),
                        },
                    )
                    decision.evidence['gem'] = gem_result.to_dict()
                    decision.evidence['fast_verdict'] = fast_gem.to_dict()
                    decision.evidence['verdict'] = {
                        'stage': 'FULL',
                        'fast_gem_score': fast_gem.gem_score,
                        'final_gem_score': gem_result.gem_score,
                        'changed': round(gem_result.gem_score - fast_gem.gem_score, 2),
                    }
                    decision.subscores['gem_score'] = gem_result.gem_score
                    decision.subscores['gem_fast'] = fast_gem.gem_score
                    decision.subscores['gem_full'] = gem_result.gem_score
                    decision.evidence['decay'] = decay_metrics.to_dict()
                    decision.subscores['decay_penalty'] = decay_metrics.penalty
                    candidate.raw['full_verdict_ready'] = True
                    candidate.raw['verdict_stage'] = 'FULL'
                    candidate.raw['fast_verdict'] = fast_gem.to_dict()
                except Exception as _gem_err:
                    import logging as _lg
                    _lg.getLogger(__name__).warning('gem_predictor failed: %s', _gem_err)

                # ── PRE-GATE FILTERS ─────────────────────────────────────────────────────
                _profile_meta = classify_decision_profile(
                    candidate.chain.value,
                    candidate.token_address,
                    candidate.raw,
                    candidate.first_seen_at,
                )
                decision_profile = str((_profile_meta or {}).get('decision_profile') or 'standard')
                decision.evidence['decision_profile'] = decision_profile
                _olog.info(
                    'pulse_decision_flow mint=%s profile=%s score=%.1f status=%s reasons=%s',
                    getattr(candidate, 'token_address', '')[:16],
                    decision_profile,
                    float(getattr(decision, 'score', 0.0) or 0.0),
                    getattr(decision, 'status', ''),
                    '|'.join((getattr(decision, 'reasons', []) or [])[-3:]),
                )

                _holders_count = int(candidate.holders or 0)
                _vol_24h = float((candidate.raw.get('volume') or {}).get('h24') or 0)
                _liquidity = float(candidate.liquidity_usd or 0)
                _pair = (candidate.raw or {}).get('pair') if isinstance(candidate.raw, dict) else {}
                _market_cap = float(
                    candidate.market_cap_usd
                    or (_pair.get('marketCap') if isinstance(_pair, dict) else 0)
                    or (_pair.get('fdv') if isinstance(_pair, dict) else 0)
                    or 0
                )
                _min_mcap = float(getattr(settings, 'pulse_min_market_cap_usd', 0.0) or 0.0)

                # Глобальний minimum market cap для всіх стратегій (single source of truth)
                if _min_mcap > 0 and _market_cap > 0 and _market_cap < _min_mcap:
                    decision.status = 'REJECT'
                    decision.reasons.append(f'pre_gate:market_cap_too_low ${_market_cap:.0f}<{_min_mcap:.0f}')

                # Мінімальна ліквідність — $0 = мертвий токен або rug
                elif _liquidity < 15_000:
                    decision.status = 'REJECT'
                    decision.reasons.append(f'pre_gate:liquidity_too_low ${_liquidity:.0f}<15000')

                # Graduated токени мають значно нижчий мінімум holders, ніж сирі pump/мікро-ланчі
                elif _holders_count > 0:
                    if decision_profile == 'pump_graduated':
                        _min_holders = int(getattr(settings, 'pump_graduated_min_holders', 50) or 50)
                    elif candidate.chain.value == 'solana':
                        _min_holders = int(getattr(settings, 'min_holders_solana', 200) or 200)
                    else:
                        _min_holders = int(getattr(settings, 'min_holders_evm', 150) or 150)

                    if _min_holders > 0 and _holders_count < _min_holders:
                        decision.status = 'REJECT'
                        decision.reasons.append(f'pre_gate:holders_too_low {_holders_count}<{_min_holders}')

                # ── PULSE STATUS GATE (single source of truth for final status) ──────────
                # GEM / risk_engine = SAFETY signals only. PULSE = sole decision maker.
                # Valid outputs: APPROVE | FARM_APPROVE | REJECT  (REVIEW_LATER abolished)
                # IMPORTANT: if pre_gate already set REJECT — skip pulse gate entirely.
                # pre_gate wins: holders_too_low, low_liquidity, price_missing are hard stops.
                _flags    = risk_result.get("flags", {})
                # bundled_buy завжди отримує шанс на FARM_APPROVE — risk engine не може блокувати
                _has_bundled_buy = bool(_flags.get("bundled_buy_detected"))
                _pre_gate_reject = any(str(r).startswith('pre_gate:') for r in (decision.reasons or []))
                if decision.status != 'REJECT':
                    _run_pulse_gate = True
                elif _has_bundled_buy and not _pre_gate_reject:
                    # Скидаємо REJECT від risk engine — bundled_buy = FARM candidate
                    decision.status = 'REVIEW'
                    _run_pulse_gate = True
                else:
                    _run_pulse_gate = False
                _buy_tax  = _flags.get("buy_tax", 0)
                _sell_tax = _flags.get("sell_tax", 0)

                # HARD SAFETY FILTER — honeypot / rug / blacklisted never reach PULSE
                if not _run_pulse_gate:
                    pass  # pre_gate REJECT — pulse gate skipped
                elif _flags.get("honeypot") or _flags.get("rug_risk") or _flags.get("blacklist"):
                    decision.status = "REJECT"
                    decision.reasons.append("pulse_gate:hard_safety_block")

                # GLOBAL TAX FILTER (zero-tax only)
                elif _buy_tax > 0 or _sell_tax > 0:
                    decision.status = "REJECT"
                    decision.reasons.append(f"pulse_gate:tax_too_high buy={_buy_tax} sell={_sell_tax}")

                # FARM MODE — bundled buy detected; only 0/0 tax + min $300k volume qualifies
                elif _flags.get("bundled_buy_detected"):
                    if _buy_tax == 0 and _sell_tax == 0:
                        # Volume filter тільки для EVM (Solana не передає vol в raw)
                        _chain_lower = str(getattr(candidate.chain, 'value', candidate.chain) or '').lower()
                        _evm_chain = _chain_lower in ('bsc', 'base', 'ethereum')
                        if _evm_chain and _vol_24h > 0 and _vol_24h < 300_000:
                            decision.status = "REJECT"
                            decision.reasons.append(f"pulse_gate:farm_rejected low_volume vol={_vol_24h:.0f}<300000")
                        else:
                            decision.status = "FARM_APPROVE"
                            decision.reasons.append("pulse_gate:farm_approved 0pct_tax")
                    else:
                        decision.status = "REJECT"
                        decision.reasons.append(f"pulse_gate:farm_rejected non_zero_tax buy={_buy_tax} sell={_sell_tax}")

                # PULSE DECISION — clean token handed to DecisionEngine
                else:
                    # Volume filter — мінімум $300k за 24h для graduated токенів.
                    # pump_early токени свіжі (vol=0 бо немає 24h history) — не фільтруємо.
                    # Volume filter тільки для EVM (Solana не передає vol в raw)
                    _chain_lower = str(getattr(candidate.chain, 'value', candidate.chain) or '').lower()
                    _evm_chain = _chain_lower in ('bsc', 'base', 'ethereum')
                    if _evm_chain and _vol_24h > 0 and _vol_24h < 300_000:
                        decision.status = "REJECT"
                        decision.reasons.append(f"pulse_gate:rejected low_volume vol={_vol_24h:.0f}<300000")
                    else:
                        try:
                            # ── Compute brain scores for continuation/wallet subscores ──
                            # This ensures decision_engine._grad_override and trade_ready use real scores
                            try:
                                from app.services.pulse.brain import PulseBrain
                                _orch_brain = PulseBrain()
                                _orch_brain_result = _orch_brain.analyze(
                                    candidate, security, social, website, behavior,
                                    bundle_data=bundle_metrics,
                                    decision_profile=decision_profile,
                                )
                                decision.subscores['continuation'] = float(_orch_brain_result.continuation_score or 0.5)
                                decision.subscores['wallet'] = float(_orch_brain_result.wallet_score or 0.5)
                                decision.subscores['ml_score'] = float(_orch_brain_result.ml_score or 0.5)
                                decision.evidence['brain'] = {
                                    'continuation_score': _orch_brain_result.continuation_score,
                                    'survival_score': _orch_brain_result.survival_score,
                                    'momentum_score': _orch_brain_result.momentum_score,
                                    'quality_score': _orch_brain_result.quality_score,
                                    'ml_score': _orch_brain_result.ml_score,
                                    'strategy_hint': _orch_brain_result.strategy_hint,
                                }
                            except Exception as _brain_err:
                                import logging as _brlg
                                _brlg.getLogger(__name__).debug('orch_brain_prefetch failed: %s', _brain_err)
                            _pulse_signals = SignalBundle(
                                mint=candidate.token_address,
                                symbol=candidate.symbol or '',
                                current_price=float(getattr(candidate, 'price_usd', 0) or 0),
                                risk_score=float(decision.score or 0),
                                risk_flags=_flags,
                                continuation_score=float(decision.subscores.get('continuation', 0.5)),
                                continuation_available='continuation' in decision.subscores,
                                wallet_score=float(decision.subscores.get('wallet', 0.5)),
                                wallet_available='wallet' in decision.subscores,
                                bundle_score=float(decision.subscores.get('bundle', 0.5)),
                                bundle_detected=bool(_flags.get('bundled_buy_detected')),
                                liquidity_usd=float(candidate.liquidity_usd or 0),
                            )
                            pulse = self.decision_engine.evaluate(_pulse_signals)
                            if pulse.decision == "APPROVE":
                                decision.status = "APPROVE"
                                decision.reasons.append("pulse_gate:approved")
                            else:
                                decision.status = "REJECT"
                                _pulse_reject_reason = (pulse.rejection_reasons[0] if getattr(pulse, 'rejection_reasons', None) else 'score_too_low')
                                decision.reasons.append(f"pulse_gate:rejected reason={_pulse_reject_reason}")
                            decision.evidence['pulse'] = {
                                'decision':    pulse.decision,
                                'final_score': getattr(pulse, 'final_score', None),
                                'paper_usd':   getattr(pulse, 'paper_usd', None),
                                'trade_ready': bool(getattr(pulse, 'trade_ready', False)),
                                'trade_ready_score': float(getattr(pulse, 'trade_ready_score', 0.0) or 0.0),
                                'trade_ready_reason': str(getattr(pulse, 'trade_ready_reason', '') or ''),
                            }
                            decision.evidence['trade_ready'] = bool(getattr(pulse, 'trade_ready', False))
                            decision.evidence['trade_ready_score'] = float(getattr(pulse, 'trade_ready_score', 0.0) or 0.0)
                            decision.evidence['trade_ready_reason'] = str(getattr(pulse, 'trade_ready_reason', '') or '')
                        except Exception as _pulse_err:
                            import traceback as _traceback
                            _olog.warning(
                                'decision_engine.evaluate failed token=%s error=%s\n%s',
                                getattr(candidate, 'token_address', '')[:16],
                                _pulse_err,
                                _traceback.format_exc(),
                            )
                            decision.status = "REJECT"
                            decision.reasons.append("pulse_gate:engine_error → fallback REJECT")

                _signal_reasons = collect_signal_reasons(decision)
                _hard_block_reason = hard_block_reason(_signal_reasons, _flags, _holders_count)
                _risk_tier = risk_tier(float(decision.score or 0.0), _signal_reasons, _hard_block_reason)
                _graduated_override = (
                    decision_profile == 'pump_graduated'
                    and float(decision.score or 0.0) >= float(getattr(settings, 'pump_graduated_approve_score', 55.0))
                )
                decision.evidence['risk_tier'] = _risk_tier
                decision.evidence['safety_gate'] = {
                    'allowed': bool(
                        decision.status in ('APPROVE', 'FARM_APPROVE')
                        and _hard_block_reason is None
                        and (_risk_tier != 'C' or _graduated_override)
                    ),
                    'reason': _hard_block_reason or ('tier_c_rejected' if (_risk_tier == 'C' and not _graduated_override) else None),
                    'holders': _holders_count,
                }
                if _hard_block_reason is not None:
                    decision.status = 'REJECT'
                    decision.reasons.append(f'safety_gate:{_hard_block_reason}')
                elif decision.status in ('APPROVE', 'FARM_APPROVE') and _risk_tier == 'C' and not _graduated_override:
                    # Tier C = зменшений розмір позиції (x0.25), але НЕ блокуємо
                    decision.reasons.append('safety_gate:risk_tier_c_reduced_size')
                elif decision.status in ('APPROVE', 'FARM_APPROVE') and _risk_tier == 'C' and _graduated_override:
                    decision.reasons.append('safety_gate:risk_tier_c_soft_pump_graduated')

                decision.evidence['risk_flags'] = _flags
                # ─────────────────────────────────────────────────────────────────────────

                snapshot = TokenSnapshot(candidate=candidate, security=security, social=social, website=website, behavior=behavior, decision=decision)
                await self.tokens.upsert_candidate(candidate)
                await self.tokens.save_decision(candidate, decision)
                hist = self.historical_service.build_snapshot(
                    chain=candidate.chain.value,
                    token_address=candidate.token_address,
                    first_seen_at=candidate.first_seen_at,
                    first_decision=historical_row.first_decision if historical_row else decision.status,
                    latest_decision=decision.status,
                    peak_liquidity_usd=max(float(historical_row.peak_liquidity_usd or 0.0), float(candidate.liquidity_usd or 0.0)) if historical_row else candidate.liquidity_usd,
                    latest_liquidity_usd=candidate.liquidity_usd,
                    peak_holders=max(int(historical_row.peak_holders or 0), int(candidate.holders or 0)) if historical_row else candidate.holders,
                    latest_holders=candidate.holders,
                    reasons=decision.reasons,
                )
                await self.historical.upsert(candidate.chain.value, candidate.token_address, {
                    'first_seen_at': candidate.first_seen_at,
                    'first_decision': historical_row.first_decision if historical_row and historical_row.first_decision else decision.status,
                    'latest_decision': decision.status,
                    'peak_liquidity_usd': hist.peak_liquidity_usd,
                    'latest_liquidity_usd': hist.latest_liquidity_usd,
                    'peak_holders': hist.peak_holders,
                    'latest_holders': hist.latest_holders,
                    'historical_score': hist.score,
                    'labels': hist.labels,
                    'notes': hist.notes,
                })
                decision.evidence['historical'] = hist.to_dict()
                decision.evidence['advanced_graph'] = graph_meta
                decision.evidence['engagement'] = {
                    'authenticity_score': engagement_signal.authenticity_score,
                    'bot_probability':    engagement_signal.bot_probability,
                    'reasons':            engagement_signal.reasons,
                    'username_changed':   engagement_signal.username_changed,
                }
                decision.evidence['community'] = {
                    'aggregate_risk':      community_signal.aggregate_risk,
                    'scam_consensus':      community_signal.scam_consensus,
                    'providers_available': community_signal.providers_available,
                    'reasons':             community_signal.reasons,
                    'verdicts': [
                        {'provider': v.provider, 'risk_score': v.risk_score, 'is_scam': v.is_scam, 'label': v.label}
                        for v in community_signal.verdicts if v.available
                    ],
                }
                decision.evidence['onchain_graph'] = {
                    'composite_risk':     onchain_result.composite_risk,
                    'sniper_risk':        onchain_result.sniper_risk,
                    'coordinated_risk':   onchain_result.coordinated_buy_risk,
                    'funding_source':     onchain_result.funding_source,
                    'mixer_funded':       onchain_result.mixer_funded,
                    'available':          onchain_result.available,
                    'reasons':            onchain_result.reasons,
                }
                decision.evidence['bundle'] = bundle_metrics
                decision.evidence['decay'] = decay_metrics.to_dict()
                decision.evidence['cross_chain'] = {
                    'risk_score': cross_chain_risk,
                    'matches': [
                        {'chain': m.matched_chain, 'wallet': m.matched_wallet[:12],
                         'similarity': m.similarity, 'rug_rate': m.matched_rug_rate}
                        for m in cross_chain_matches[:3]
                    ],
                }
                decision.subscores['community_risk']   = community_signal.aggregate_risk
                decision.subscores['engagement_auth']  = round(engagement_signal.bot_probability * 100, 1)
                decision.subscores['onchain_graph']    = onchain_result.composite_risk
                decision.subscores['cross_chain_risk'] = cross_chain_risk
                await self.audit.log('token_evaluated', snapshot.model_dump(mode='json'), candidate.token_address)
                await METRICS.incr(f'tokens_decision_{decision.status.lower()}_total')
                await METRICS.set_gauge('last_decision_score', decision.score)
                events = self.alert_intelligence.classify(snapshot)
                for evt in events:
                    await self.alert_events.create(candidate.chain.value, candidate.token_address, evt['event'], evt['severity'], {'decision_score': decision.score, 'status': decision.status})
                if decision.status in ('APPROVE', 'FARM_APPROVE'):
                    # Перевіряємо decision_profile — надійніше ніж reasons
                    # reasons не містить pump_early_monitor коли score >= approve_score
                    _dp = str((decision.evidence or {}).get('decision_profile') or '')
                    _is_pump_early = (_dp == 'pump_early')
                    _pump_early_allowed = bool(settings.pulse_trade_pump_early)
                    if _is_pump_early and not _pump_early_allowed:
                        decision.status = 'REJECT'
                        decision.reasons.append('pre_gate:pump_early_trading_disabled')

                if decision.status in ('REJECT', 'SKIP') and settings.paper_trading_enabled and float(decision.score or 0.0) >= 40.0:
                    try:
                        from app.services.pulse.lifecycle import LifecycleService
                        svc = LifecycleService(self.session)
                        await svc.open_watching(candidate=candidate, skip_reason=decision.status, entry_score=decision.score)
                    except Exception as _watch_err:
                        logger.warning('pulse watching failed: %s', _watch_err)

                if decision.status in ('APPROVE', 'FARM_APPROVE'):
                    if settings.paper_trading_enabled:
                        try:
                            from app.services.pulse.paper_trader import PaperTrader
                            trader = PaperTrader(self.session)
                            await trader.on_approve(
                                candidate=candidate,
                                decision=decision,
                                security=security,
                                social=social,
                                website=website,
                                behavior=behavior,
                                bundle_data=bundle_metrics,
                            )
                        except Exception as _pulse_err:
                            logger.warning('pulse paper trader failed: %s', _pulse_err)
                    await self.alerts.send(snapshot)
                return decision

# H4 note: integrate DecisionEngine manually if needed
