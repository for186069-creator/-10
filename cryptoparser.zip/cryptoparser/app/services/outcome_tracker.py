"""
Outcome Tracker — перевіряє долю кожного APPROVE-рішення через 2–14 днів.

Алгоритм:
  1. Беремо всі APPROVE з вікна [now-14d .. now-2d] без outcome-лейблу
  2. Запитуємо поточну ліквідність через DexScreener (безкоштовно, без ключа)
  3. Класифікуємо:
       rug  — ліквідність впала >90% від оригінальної АБО пар нема зовсім
       dead — ліквідність впала 50–90%
       alive — ліквідність залишилась >50%
  4. Пишемо в analyst_labels (label='outcome', analyst='outcome_tracker')
  5. Оновлюємо historical_tokens

Ці лейбли потім підхоплює ThresholdCalibrator для розрахунку оптимальних порогів.

Запуск через scheduler (job_name='outcome_tracker'),
або вручну: python -m app.services.outcome_tracker
"""

from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timedelta, timezone
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.adapters.dexscreener import DexScreenerClient
from app.db.base import AsyncSessionLocal
from app.db.models import AnalystLabelRecord, TokenCandidateRecord, TokenDecisionRecord
from app.db.repositories import AnalystLabelRepository, HistoricalRepository

log = logging.getLogger(__name__)

# ── вікно перевірки ──────────────────────────────────────────────────────────
MIN_DAYS = 2    # раніше — надто рано для висновку
MAX_DAYS = 14   # пізніше — депріоритет, але все одно лейблимо

# ── пороги класифікації ───────────────────────────────────────────────────────
RUG_DROP_PCT  = 90.0   # падіння ліквідності → rug
DEAD_DROP_PCT = 50.0   # часткова просадка  → dead

# ── Mapping внутрішніх chain → DexScreener slug ───────────────────────────────
_CHAIN_SLUG: dict[str, str] = {
    'ethereum': 'ethereum',
    'bsc':      'bsc',
    'base':     'base',
    'solana':   'solana',
}


class OutcomeTracker:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session
        self.dex     = DexScreenerClient()
        self.labels  = AnalystLabelRepository(session)
        self.hist    = HistoricalRepository(session)

    # ── публічний entry-point ────────────────────────────────────────────────

    async def run(self) -> dict[str, int]:
        """Сканує approve-рішення у вікні та ставить outcome-лейбл.

        Returns:
            dict з counters: scanned / labeled / already_labeled / errors
        """
        stats: dict[str, int] = {
            'scanned':         0,
            'labeled':         0,
            'already_labeled': 0,
            'errors':          0,
        }

        cutoff_min = datetime.now(timezone.utc) - timedelta(days=MAX_DAYS)
        cutoff_max = datetime.now(timezone.utc) - timedelta(days=MIN_DAYS)

        q = (
            select(TokenDecisionRecord)
            .where(
                TokenDecisionRecord.status == 'APPROVE',
                TokenDecisionRecord.created_at >= cutoff_min,
                TokenDecisionRecord.created_at <= cutoff_max,
            )
            .order_by(TokenDecisionRecord.created_at.asc())
        )
        decisions = list((await self.session.execute(q)).scalars().all())
        log.info('outcome_tracker: found %d approve decisions in window', len(decisions))

        for decision in decisions:
            stats['scanned'] += 1
            try:
                if await self._already_labeled(decision.chain, decision.token_address):
                    stats['already_labeled'] += 1
                    continue

                outcome, evidence = await self._classify(decision)
                await self._write_label(decision, outcome, evidence)
                stats['labeled'] += 1

                log.info(
                    'outcome_labeled chain=%s token=%.12s outcome=%s liq_now=%.0f liq_orig=%.0f',
                    decision.chain,
                    decision.token_address,
                    outcome,
                    evidence.get('current_liquidity_usd', 0),
                    evidence.get('original_liquidity_usd', 0),
                )

            except Exception as exc:
                log.warning(
                    'outcome_tracker error chain=%s token=%.12s: %s',
                    decision.chain, decision.token_address, exc,
                )
                stats['errors'] += 1

        log.info('outcome_tracker run complete: %s', stats)
        return stats

    # ── внутрішні методи ─────────────────────────────────────────────────────

    async def _already_labeled(self, chain: str, token_address: str) -> bool:
        q = select(AnalystLabelRecord).where(
            AnalystLabelRecord.chain         == chain,
            AnalystLabelRecord.token_address == token_address,
            AnalystLabelRecord.label         == 'outcome',
        )
        return (await self.session.execute(q)).scalar_one_or_none() is not None

    async def _classify(
        self, decision: TokenDecisionRecord
    ) -> tuple[str, dict[str, Any]]:
        original_liquidity = await self._original_liquidity(decision)

        dex_chain = _CHAIN_SLUG.get(decision.chain.lower(), decision.chain.lower())
        pairs = await self.dex.token_pairs(dex_chain, decision.token_address)
        current_liquidity = _sum_liquidity(pairs)

        evidence: dict[str, Any] = {
            'original_liquidity_usd': original_liquidity,
            'current_liquidity_usd':  current_liquidity,
            'pairs_found':            len(pairs),
            'checked_at':             datetime.now(timezone.utc).isoformat(),
            'decision_score':         decision.score,
            'decision_date':          decision.created_at.isoformat() if decision.created_at else None,
        }

        # Нема пар або ліквідність нульова — rug
        if not pairs or current_liquidity == 0.0:
            evidence['reason'] = 'no_pairs_or_zero_liquidity'
            return 'rug', evidence

        # Є базова ліквідність для порівняння
        if original_liquidity > 0:
            drop_pct = (original_liquidity - current_liquidity) / original_liquidity * 100.0
            evidence['drop_pct'] = round(drop_pct, 2)

            if drop_pct >= RUG_DROP_PCT:
                evidence['reason'] = f'liquidity_dropped_{drop_pct:.0f}pct'
                return 'rug', evidence

            if drop_pct >= DEAD_DROP_PCT:
                evidence['reason'] = f'liquidity_dropped_{drop_pct:.0f}pct'
                return 'dead', evidence

        evidence['reason'] = 'liquidity_sustained'
        return 'alive', evidence

    async def _original_liquidity(self, decision: TokenDecisionRecord) -> float:
        q = select(TokenCandidateRecord).where(
            TokenCandidateRecord.chain         == decision.chain,
            TokenCandidateRecord.token_address == decision.token_address,
        )
        row = (await self.session.execute(q)).scalar_one_or_none()
        return float(row.liquidity_usd or 0.0) if row else 0.0

    async def _write_label(
        self,
        decision: TokenDecisionRecord,
        outcome: str,
        evidence: dict[str, Any],
    ) -> None:
        await self.labels.create(
            chain=decision.chain,
            token_address=decision.token_address,
            label='outcome',
            value=outcome,
            analyst='outcome_tracker',
            notes=str(evidence),
        )
        # Оновлюємо historical record щоб ML-шар враховував результат
        update: dict[str, Any] = {'updated_at': datetime.now(timezone.utc)}
        if outcome in ('rug', 'dead'):
            update['latest_decision'] = outcome.upper()
        await self.hist.upsert(decision.chain, decision.token_address, update)


# ── утиліти ───────────────────────────────────────────────────────────────────

def _sum_liquidity(pairs: list[dict]) -> float:
    total = 0.0
    for pair in pairs:
        liq = pair.get('liquidity', {})
        if isinstance(liq, dict):
            total += float(liq.get('usd', 0.0) or 0.0)
    return total


# ── scheduler entry-point ────────────────────────────────────────────────────

async def run_outcome_tracker(session_factory) -> None:
    async with session_factory() as session:
        tracker = OutcomeTracker(session)
        await tracker.run()


# ── standalone ───────────────────────────────────────────────────────────────

if __name__ == '__main__':
    import sys
    from app.core.logging import configure_logging
    configure_logging()

    async def _main() -> None:
        async with AsyncSessionLocal() as session:
            stats = await OutcomeTracker(session).run()
            print(stats)

    asyncio.run(_main())
