from __future__ import annotations
from dataclasses import dataclass, field


@dataclass
class PatternMatch:
    name: str
    score: float
    reasons: list[str] = field(default_factory=list)


_MEME_KEYWORDS = {'pepe', 'doge', 'inu', 'shib', 'cat', 'moon', 'elon', 'baby', 'safe', 'floki', 'chad', 'wojak'}
_DEFI_KEYWORDS = {'swap', 'fi', 'finance', 'yield', 'stake', 'vault', 'farm', 'liquid'}


def match_pattern(
    symbol: str | None,
    name: str | None,
    holders: int | None,
    liquidity_usd: float | None,
    links: list[str | None],
) -> PatternMatch:
    sym = (symbol or '').lower()
    nm = (name or '').lower()
    score = 0.0
    reasons: list[str] = []
    pattern_name = 'generic'

    if any(k in sym or k in nm for k in _MEME_KEYWORDS):
        pattern_name = 'meme'
        score += 5
        reasons.append('meme_pattern')

    if any(k in nm for k in _DEFI_KEYWORDS):
        pattern_name = 'defi'
        score += 8
        reasons.append('defi_pattern')

    valid_links = [l for l in links if l]
    if len(valid_links) >= 2:
        score += 12; reasons.append('multi_social')
    elif len(valid_links) == 1:
        score += 5; reasons.append('single_social')
    else:
        score -= 5; reasons.append('no_social_links')

    liq = liquidity_usd or 0
    h = holders or 0
    if liq >= 20_000 and h >= 300:
        score += 15; reasons.append('traction_early')

    return PatternMatch(name=pattern_name, score=max(-20.0, min(score, 35.0)), reasons=reasons)
