from __future__ import annotations

import logging
from typing import Any
from datetime import datetime, timezone

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.adapters.birdeye import BirdeyeClient
from app.adapters.pumpfun import PumpFunClient
from app.adapters.security import SecurityService
from app.core.config import settings
from app.adapters.coingecko import CoinGeckoClient
from app.adapters.coinmarketcap import CoinMarketCapClient
from app.adapters.dexscreener import DexScreenerClient
from app.db.models import TokenCandidateRecord
from app.db.repositories import RealtimeAlertRepository
from app.models.token import Chain, QueueMessage, TokenCandidate
from app.queue.service import QueueService
from app.services.normalizer import Normalizer
from app.services.orchestrator import Orchestrator
from app.utils.cache import GLOBAL_TTL_CACHE
from app.utils.graduated_quality import (
    extract_graduated_metrics,
    has_holders_signal,
    has_quality_social,
    is_multichain_graduated_signal,
    is_valid_telegram_url,
    is_valid_x_handle,
    passes_market_gate,
)
from app.utils.http import HttpClient
from app.utils.token_classifier import is_valid_solana_pump_suffix
from app.utils.token_classifier import classify_decision_profile, classify_token_family

logger = logging.getLogger(__name__)

MONITORED_CHAINS: set[Chain] = {Chain.BSC, Chain.BASE, Chain.SOLANA}
BOOSTED_CHAINS = ['bsc', 'base', 'solana']


class Pipeline:
    def __init__(self, session: AsyncSession, queue_service: QueueService | None = None) -> None:
        self.session = session
        self.dex = DexScreenerClient()
        self.birdeye = BirdeyeClient()
        self.security = SecurityService()
        self.pumpfun = PumpFunClient()
        self.coingecko = CoinGeckoClient()
        self.coinmarketcap = CoinMarketCapClient()
        self.orchestrator = Orchestrator(session)
        self.realtime_alerts = RealtimeAlertRepository(session)
        self.http = HttpClient()
        self.queue = queue_service


    def _telemetry(self, event: str, **fields: Any) -> None:
        clean: dict[str, Any] = {}
        for key, value in fields.items():
            if value is None:
                continue
            if isinstance(value, float):
                clean[key] = round(value, 6)
            elif isinstance(value, (list, tuple, set)):
                clean[key] = ','.join(str(v) for v in value)
            else:
                clean[key] = value
        payload = ' '.join(f'{k}={clean[k]}' for k in sorted(clean))
        logger.info('pump_telemetry event=%s %s', event, payload)

    @staticmethod
    def _dex_matches(dex_id: str, allowed: list[str]) -> bool:
        if not allowed:
            return True
        dex_norm = str(dex_id or '').lower()
        if not dex_norm:
            return False
        for marker in allowed:
            marker_norm = str(marker or '').strip().lower()
            if marker_norm and marker_norm in dex_norm:
                return True
        return False

    def _is_pump_candidate(self, candidate: TokenCandidate | None) -> bool:
        if not candidate:
            return False
        raw = candidate.raw or {}
        return (
            (
                candidate.chain == Chain.SOLANA
                and (raw.get('token_family') == 'pump_suffix' or raw.get('launchpad') in {'pump_fun', 'pump_swap'})
            )
            or bool(raw.get('multichain_graduated'))
        )

    async def collect_candidates(self) -> list[TokenCandidate]:
        candidates: list[TokenCandidate] = []
        candidates.extend(await self.collect_pump_candidates())
        candidates.extend(await self.collect_graduated_candidates())
        candidates.extend(await self._collect_multichain_graduated_fast_lane())
        candidates.extend(await self._collect_dex_candidates())
        candidates.extend(await self._collect_birdeye_candidates())
        candidates.extend(await self._collect_market_candidates())
        return self._dedup_candidates(candidates)

    async def collect_pump_candidates(self) -> list[TokenCandidate]:
        if not settings.enable_pumpfun_intake:
            self._telemetry('pump_cycle_disabled')
            return []
        candidates: list[TokenCandidate] = []
        discovered = await self.pumpfun.discover_new_mints(settings.pumpfun_max_candidates_per_cycle)
        self._telemetry(
            'pump_cycle_start',
            discovered=len(discovered),
            max_candidates=settings.pumpfun_max_candidates_per_cycle,
            metadata_limit=settings.pumpfun_coin_metadata_limit,
            dedup_ttl=settings.pumpfun_dedup_ttl_seconds,
        )
        if discovered:
            logger.info('pipeline: pumpfun discovered=%s', len(discovered))
        for idx, item in enumerate(discovered):
            mint = item.get('mint')
            if not mint:
                self._telemetry('reject_missing_mint', index=idx, source=item.get('source'))
                continue
            self._telemetry('discover', mint=mint, index=idx, source=item.get('source'), feed_url=item.get('feed_url'))
            key = f'pumpfun:seen:{mint}'
            if await GLOBAL_TTL_CACHE.get(key):
                self._telemetry('dedup_skip', mint=mint, source=item.get('source'), cache_key=key)
                continue
            await GLOBAL_TTL_CACHE.set(key, {'seen': True}, ttl_seconds=settings.pumpfun_dedup_ttl_seconds)
            self._telemetry('dedup_mark', mint=mint, source=item.get('source'), ttl_seconds=settings.pumpfun_dedup_ttl_seconds)
            if idx < settings.pumpfun_coin_metadata_limit:
                meta = await self.pumpfun.fetch_coin_metadata(mint)
                item = {**item, **meta}
                self._telemetry(
                    'metadata',
                    mint=mint,
                    title=bool(item.get('title')),
                    description=bool(item.get('description')),
                    x_url=bool(item.get('x_url')),
                    website=bool(item.get('website')),
                    coin_url=item.get('coin_url'),
                )
            else:
                self._telemetry('metadata_skipped', mint=mint, reason='metadata_limit_reached', index=idx)
            candidate = Normalizer.from_pumpfun_intake(item)
            if not candidate:
                self._telemetry('reject_normalizer_none', mint=mint, source=item.get('source'))
                continue
            candidate.raw['fast_lane'] = True
            candidate.raw['intake_priority'] = 'fast'
            candidate.raw['discovery_source'] = item.get('source') or 'pumpfun'
            tagged = self._tag_candidate(candidate)
            self._telemetry(
                'normalized',
                mint=mint,
                symbol=tagged.symbol,
                name=tagged.name,
                family=(tagged.raw or {}).get('token_family'),
                launchpad=(tagged.raw or {}).get('launchpad'),
                website=bool(tagged.website),
                x_handle=bool(tagged.x_handle),
            )
            enriched = await self._enrich_from_pairs(tagged)
            self._telemetry(
                'enriched',
                mint=mint,
                pair=enriched.pair_address,
                liquidity_usd=enriched.liquidity_usd,
                holders=enriched.holders,
                source=(enriched.raw or {}).get('source'),
            )
            candidates.append(enriched)
            self._telemetry('candidate_ready', mint=mint, fast_lane=True, queue='ingest_fast')
        self._telemetry('pump_cycle_done', accepted=len(candidates))
        return candidates

    async def collect_graduated_candidates(self) -> list[TokenCandidate]:
        """Збирає pump.fun токени що graduated на Raydium.

        Джерело: pump.fun frontend API (/coins?complete=true)
          - complete = True  → bonding curve заповнена
          - raydium_pool != None → є пул на Raydium
          - usd_market_cap >= $100k (мінімальна капіталізація)

        Після цього збагачуємо через DexScreener (liquidity, holders, volume)
        і відправляємо в orchestrator де risk engine перевіряє
        website / X / domain / security як pump_graduated профіль.

        Канонічне правило для Pump Graduated:
          - suffix ...pump на Solana
          - venue Raydium або PumpSwap
          - проходить 4 graduated pre-filter-и
          - має сайт; соціалки валідуються окремо (social-gap токени маркуються окремо)
        """
        if not settings.enable_graduated_intake:
            self._telemetry('graduated_cycle_disabled')
            return []

        candidates: list[TokenCandidate] = []
        try:
            coins = await self.pumpfun.fetch_graduated_coins(
                limit=settings.graduated_max_candidates,
                min_market_cap_usd=100_000,
            )
        except Exception as exc:
            logger.warning('pipeline: graduated intake failed: %s', exc)
            return []

        try:
            dex_pairs = await self.dex.new_raydium_graduated_pairs(
                min_liquidity=settings.graduated_min_liquidity,
                min_volume_24h=settings.graduated_min_volume_24h,
                min_txns_24h=settings.graduated_min_txns_24h,
                min_age_hours=settings.graduated_min_age_hours,
                max_results=settings.graduated_max_candidates * 2,
            )
        except Exception as exc:
            logger.warning('pipeline: dex graduated prefilter failed: %s', exc)
            dex_pairs = []
        if settings.enable_graduated_early_catch:
            dex_pairs.extend(await self._collect_graduated_pairs_from_known_suffixes())
            dex_pairs.extend(await self._collect_graduated_pairs_from_latest_profiles())
            dex_pairs.extend(await self._collect_graduated_pairs_from_birdeye_suffix())

        coins_by_mint = {
            str(coin.get('mint') or ''): coin
            for coin in coins
            if coin.get('mint')
        }
        dex_pairs_by_mint = {
            str((pair.get('baseToken') or {}).get('address') or ''): pair
            for pair in dex_pairs
            if (pair.get('baseToken') or {}).get('address')
        }

        self._telemetry(
            'graduated_cycle_start',
            pumpfun_discovered=len(coins_by_mint),
            dex_prefiltered=len(dex_pairs_by_mint),
            early_catch_enabled=settings.enable_graduated_early_catch,
            min_liquidity=settings.graduated_min_liquidity,
            min_volume_24h=settings.graduated_min_volume_24h,
            min_txns_24h=settings.graduated_min_txns_24h,
            min_age_hours=settings.graduated_min_age_hours,
        )

        for mint, pair in dex_pairs_by_mint.items():
            if not mint:
                continue
            coin = coins_by_mint.get(mint)

            # Дедуп — не обробляємо той самий токен знову в межах 1 год
            key = f'graduated:seen:{mint}'
            if await GLOBAL_TTL_CACHE.get(key):
                self._telemetry('graduated_dedup_skip', mint=mint)
                continue
            await GLOBAL_TTL_CACHE.set(key, {'seen': True}, ttl_seconds=settings.graduated_dedup_ttl_seconds)

            # Нормалізуємо з pump.fun API даних
            candidate = Normalizer.from_pumpfun_intake(coin) if coin else Normalizer.from_dex_pair(pair)
            if not candidate:
                self._telemetry('graduated_normalizer_none', mint=mint)
                continue

            # Маркуємо як graduated
            candidate.raw['discovery_source'] = 'pumpfun_graduated' if coin else 'dexscreener_graduated'
            candidate.raw['intake_priority'] = 'graduated'
            candidate.raw['graduated_raydium'] = True
            candidate.raw['graduated_confirmed'] = True
            candidate.raw['lifecycle_stage'] = 'graduated'
            candidate.raw['raydium_pool'] = (coin or {}).get('raydium_pool') or pair.get('pairAddress')
            candidate.raw['complete'] = bool((coin or {}).get('complete', False))
            candidate.raw['graduated_via'] = 'pumpfun_and_dex' if coin else 'dex_only_fallback'
            candidate.raw['graduated_filters'] = {
                'min_liquidity': settings.graduated_min_liquidity,
                'min_volume_24h': settings.graduated_min_volume_24h,
                'min_txns_24h': settings.graduated_min_txns_24h,
                'min_age_hours': settings.graduated_min_age_hours,
            }
            candidate.raw['graduated_prefilter'] = self._graduated_prefilter_from_pair(pair)
            pre = candidate.raw.get('graduated_prefilter') or {}
            has_valid_social = bool(pre.get('has_valid_social'))
            candidate.raw['graduated_social_ok'] = has_valid_social
            candidate.raw['graduated_social_gap'] = bool(pre.get('has_website')) and not has_valid_social
            if candidate.raw['graduated_social_gap']:
                candidate.raw['graduated_social_gap_reason'] = 'missing_or_invalid_social'

            # Фільтр по максимальному віку — відкидаємо "старі" graduated токени
            # Fartcoin/jellyjelly/pippin місяцями висять в списку і засмічують систему
            _pair_created_ms = float(pair.get('pairCreatedAt') or 0)
            if _pair_created_ms > 0:
                _age_hours = (datetime.now(timezone.utc).timestamp() * 1000.0 - _pair_created_ms) / 3_600_000.0
                _max_age_h = float(getattr(settings, 'pump_graduated_max_launch_age_hours', 72) or 72)
                if _age_hours > _max_age_h:
                    self._telemetry('graduated_too_old', mint=mint,
                                    age_hours=round(_age_hours, 1), max_age_hours=_max_age_h)
                    continue

            # Канонічне graduated-збагачення: pair уже пройшла 4 pre-filter-и DexScreener.
            candidate = Normalizer.enrich_from_pair(candidate, pair)

            tagged = self._tag_candidate(candidate)
            self._telemetry(
                'graduated_candidate',
                mint=mint,
                symbol=tagged.symbol,
                liquidity_usd=tagged.liquidity_usd,
                profile=tagged.raw.get('decision_profile'),
                via=tagged.raw.get('graduated_via'),
            )
            await self._emit_strong_graduated_alert(tagged)
            candidates.append(tagged)

        self._telemetry('graduated_cycle_done', accepted=len(candidates))
        return candidates

    @staticmethod
    def _graduated_prefilter_from_pair(pair: dict) -> dict:
        h24 = (pair.get('txns') or {}).get('h24') or {}
        info = pair.get('info') or {}
        websites = info.get('websites') or []
        socials = info.get('socials') or []
        has_website = any(str(site.get('url') or '').strip() for site in websites if isinstance(site, dict))
        has_valid_social = False
        has_x_social = False
        has_telegram_social = False
        for social in socials:
            if not isinstance(social, dict):
                continue
            social_url = str(social.get('url') or '').strip()
            if not social_url:
                continue
            social_type = str(social.get('type') or social.get('platform') or '').lower()
            if social_type in {'twitter', 'x'}:
                has_x_social = True
                if is_valid_x_handle(social_url):
                    has_valid_social = True
            if social_type == 'telegram':
                has_telegram_social = True
                if is_valid_telegram_url(social_url):
                    has_valid_social = True
        return {
            'liquidity_usd': float((pair.get('liquidity') or {}).get('usd') or 0),
            'volume_24h': float((pair.get('volume') or {}).get('h24') or 0),
            'txns_24h': int(h24.get('buys') or 0) + int(h24.get('sells') or 0),
            'pair_created_at': pair.get('pairCreatedAt'),
            'dex_id': pair.get('dexId'),
            'has_website': has_website,
            'has_valid_social': has_valid_social,
            'has_x_social': has_x_social,
            'has_telegram_social': has_telegram_social,
        }

    async def _collect_graduated_pairs_from_known_suffixes(self) -> list[dict]:
        base_filter = (
            TokenCandidateRecord.chain == 'solana',
            (TokenCandidateRecord.token_family == 'pump_suffix') | TokenCandidateRecord.token_address.like('%pump'),
        )
        total_q = select(func.count()).select_from(TokenCandidateRecord).where(*base_filter)
        total = int((await self.session.execute(total_q)).scalar() or 0)
        if total <= 0:
            return []

        cursor_key = 'graduated:backfill:cursor'
        cursor_payload = await GLOBAL_TTL_CACHE.get(cursor_key) or {}
        offset = int(cursor_payload.get('offset') or 0)
        batch_size = max(10, int(settings.graduated_backfill_batch_size))
        safe_offset = offset % total
        q = (
            select(TokenCandidateRecord.token_address)
            .where(*base_filter)
            .order_by(TokenCandidateRecord.first_seen_at.desc())
            .offset(safe_offset)
            .limit(batch_size)
        )
        token_addresses = [row[0] for row in (await self.session.execute(q)).all()]
        next_offset = (safe_offset + batch_size) % max(total, 1)
        await GLOBAL_TTL_CACHE.set(cursor_key, {'offset': next_offset}, ttl_seconds=settings.graduated_backfill_cursor_ttl_seconds)

        pairs: list[dict] = []
        seen: set[str] = set()
        for token_address in token_addresses:
            try:
                token_pairs = await self.dex.token_pairs('solana', token_address)
            except Exception:
                continue
            for pair in token_pairs:
                if not self._passes_graduated_prefilter(pair, token_address):
                    continue
                key = str((pair.get('baseToken') or {}).get('address') or '')
                if key and key not in seen:
                    seen.add(key)
                    pairs.append(pair)
        return pairs

    async def _collect_graduated_pairs_from_latest_profiles(self) -> list[dict]:
        pairs: list[dict] = []
        try:
            profiles = await self.dex.latest_token_profiles()
        except Exception:
            return pairs
        seen: set[str] = set()
        for profile in profiles:
            if (profile.get('chainId') or '').lower() != 'solana':
                continue
            token_address = str(profile.get('tokenAddress') or '')
            if not is_valid_solana_pump_suffix(token_address):
                continue
            try:
                token_pairs = await self.dex.token_pairs('solana', token_address)
            except Exception:
                continue
            for pair in token_pairs:
                if not self._passes_graduated_prefilter(pair, token_address):
                    continue
                key = str((pair.get('baseToken') or {}).get('address') or '')
                if key and key not in seen:
                    seen.add(key)
                    pairs.append(pair)
        return pairs

    async def _collect_graduated_pairs_from_birdeye_suffix(self) -> list[dict]:
        pairs: list[dict] = []
        if not settings.enable_birdeye:
            return pairs
        try:
            listings = await self.birdeye.new_listings(limit=min(settings.birdeye_new_listing_limit, 120))
        except Exception:
            return pairs
        seen: set[str] = set()
        for item in listings:
            token_address = str(item.get('address') or item.get('mint') or '')
            if not is_valid_solana_pump_suffix(token_address):
                continue
            try:
                token_pairs = await self.dex.token_pairs('solana', token_address)
            except Exception:
                continue
            for pair in token_pairs:
                if not self._passes_graduated_prefilter(pair, token_address):
                    continue
                key = str((pair.get('baseToken') or {}).get('address') or '')
                if key and key not in seen:
                    seen.add(key)
                    pairs.append(pair)
        return pairs

    def _passes_graduated_prefilter(self, pair: dict, token_address: str) -> bool:
        from datetime import datetime, timedelta, timezone

        if (pair.get('chainId') or '').lower() != 'solana':
            return False
        dex_id = str(pair.get('dexId') or '').lower()
        if 'raydium' not in dex_id and 'pumpswap' not in dex_id:
            return False
        base_addr = str((pair.get('baseToken') or {}).get('address') or '')
        if base_addr.lower() != str(token_address).lower():
            return False
        liq = float((pair.get('liquidity') or {}).get('usd') or 0)
        if liq < settings.graduated_min_liquidity:
            return False
        vol = float((pair.get('volume') or {}).get('h24') or 0)
        if vol < settings.graduated_min_volume_24h:
            return False
        h24 = ((pair.get('txns') or {}).get('h24') or {})
        total_txns = int(h24.get('buys') or 0) + int(h24.get('sells') or 0)
        if total_txns < settings.graduated_min_txns_24h:
            return False
        prefilter = self._graduated_prefilter_from_pair(pair)
        # Website stays mandatory for graduated intake. Social validity is tracked
        # separately and routed to a dedicated social-gap feed.
        if not bool(prefilter.get('has_website')):
            return False
        if settings.pump_graduated_quality_mode:
            if not passes_market_gate(liq, vol, float(total_txns), settings, 'solana'):
                return False
        pair_created = pair.get('pairCreatedAt')
        if not pair_created:
            return False
        try:
            created_dt = datetime.fromtimestamp(pair_created / 1000, tz=timezone.utc)
        except Exception:
            return False
        return created_dt <= datetime.now(timezone.utc) - timedelta(hours=settings.graduated_min_age_hours)

    async def _emit_strong_graduated_alert(self, candidate: TokenCandidate) -> None:
        if not settings.enable_graduated_strong_alerts:
            return
        raw = candidate.raw or {}
        pre = raw.get('graduated_prefilter') or {}
        liquidity = float(candidate.liquidity_usd or 0.0)
        volume_24h = float(pre.get('volume_24h') or 0.0)
        txns_24h = int(pre.get('txns_24h') or 0)
        has_site = bool(candidate.website)
        has_social = bool(candidate.x_handle or candidate.telegram_url)
        strong = (
            liquidity >= settings.graduated_min_liquidity * 2
            and volume_24h >= settings.graduated_min_volume_24h * 2
            and txns_24h >= settings.graduated_min_txns_24h * 2
            and has_site
            and has_social
        )
        if not strong:
            return
        key = f'graduated:strong_alert:{candidate.token_address}'
        if await GLOBAL_TTL_CACHE.get(key):
            return
        await GLOBAL_TTL_CACHE.set(key, {'sent': True}, ttl_seconds=settings.graduated_strong_alert_ttl_seconds)
        try:
            await self.realtime_alerts.create(
                candidate.chain.value,
                candidate.token_address,
                'strong_graduated_candidate',
                'warning',
                {
                    'lifecycle_stage': raw.get('lifecycle_stage') or 'graduated',
                    'liquidity_usd': liquidity,
                    'volume_24h': volume_24h,
                    'txns_24h': txns_24h,
                    'website': candidate.website,
                    'x_handle': candidate.x_handle,
                    'telegram_url': candidate.telegram_url,
                    'source': raw.get('discovery_source') or raw.get('source'),
                },
            )
        except Exception as exc:
            logger.warning('pipeline: failed to emit strong graduated alert token=%s error=%s', candidate.token_address, exc)

    async def poll_graduated_and_enqueue(self) -> int:
        """Поллить graduated токени і кладе в чергу."""
        if not self.queue:
            raise RuntimeError('queue_service is required for polling mode')
        graduated_candidates = await self.collect_graduated_candidates()
        count = 0
        for candidate in graduated_candidates:
            await self.queue.enqueue_ingest(
                QueueMessage(chain=candidate.chain, token_address=candidate.token_address, payload=candidate.model_dump(mode='json')),
                fast=False,
            )
            self._telemetry(
                'graduated_enqueue',
                mint=candidate.token_address,
                liquidity_usd=candidate.liquidity_usd,
            )
            count += 1
        await self._send_graduated_top7_telegram(graduated_candidates)
        self._telemetry('graduated_poll_done', enqueued=count)
        return count

    @staticmethod
    def _candidate_pair_created_ms(candidate: TokenCandidate) -> float:
        raw = candidate.raw or {}
        pre = raw.get('graduated_prefilter') or {}
        pair = raw.get('pair') or {}
        value = (
            pre.get('pair_created_at')
            or pre.get('pairCreatedAt')
            or pair.get('pairCreatedAt')
            or raw.get('pair_created_at')
            or raw.get('pairCreatedAt')
        )
        try:
            ts = float(value)
            if ts < 10_000_000_000:
                ts *= 1000.0
            return ts
        except Exception:
            return 0.0

    @staticmethod
    def _extract_solana_holder_count(report: object) -> int | None:
        try:
            token = (getattr(report, 'raw', {}) or {}).get('goplus_solana') or {}
            value = token.get('holder_count')
            if value is None:
                return None
            count = int(value)
            return count if count >= 0 else None
        except Exception:
            return None

    @staticmethod
    def _extract_market_cap_usd(candidate: TokenCandidate) -> float | None:
        try:
            direct = float(candidate.market_cap_usd or 0.0)
            if direct > 0:
                return direct
        except Exception:
            pass
        raw = candidate.raw or {}
        pre = raw.get('graduated_prefilter') or {}
        pair = raw.get('pair') or {}
        for value in (
            pre.get('market_cap'),
            pre.get('marketCap'),
            pair.get('marketCap'),
            raw.get('market_cap'),
            raw.get('marketCap'),
        ):
            try:
                parsed = float(value)
                if parsed > 0:
                    return parsed
            except Exception:
                continue
        return None

    @staticmethod
    def _format_usd_compact(value: float | None) -> str:
        if value is None or value <= 0:
            return '-'
        if value >= 1_000_000_000:
            return f'${value / 1_000_000_000:.2f}B'
        if value >= 1_000_000:
            return f'${value / 1_000_000:.2f}M'
        if value >= 1_000:
            return f'${value / 1_000:.1f}K'
        return f'${value:,.0f}'

    async def _ensure_candidate_holders(self, candidate: TokenCandidate) -> None:
        if candidate.chain != Chain.SOLANA:
            return
        if candidate.holders is not None and int(candidate.holders or 0) > 0:
            return
        cache_key = f'holders:goplus:{candidate.token_address}'
        cached = await GLOBAL_TTL_CACHE.get(cache_key)
        if isinstance(cached, dict):
            cached_count = cached.get('holders')
            try:
                parsed_cached = int(cached_count)
            except Exception:
                parsed_cached = None
            if parsed_cached is not None and parsed_cached > 0:
                candidate.holders = parsed_cached
                candidate.raw = dict(candidate.raw or {})
                candidate.raw['holders_source'] = 'goplus_solana_cache'
                return
        try:
            report = await self.security.analyze(candidate)
        except Exception:
            return
        holder_count = self._extract_solana_holder_count(report)
        if holder_count is None or holder_count <= 0:
            return
        candidate.holders = holder_count
        candidate.raw = dict(candidate.raw or {})
        candidate.raw['holders_source'] = 'goplus_solana'
        await GLOBAL_TTL_CACHE.set(cache_key, {'holders': holder_count}, ttl_seconds=900)

    async def _send_graduated_top7_telegram(self, candidates: list[TokenCandidate]) -> None:
        if not candidates:
            return
        if not settings.enable_graduated_top_telegram_alerts:
            return
        if not settings.enable_telegram or not settings.telegram_bot_token or not settings.telegram_chat_id:
            return

        top_n = max(1, int(settings.graduated_top_telegram_count))
        max_age_seconds = max(1.0, float(settings.pump_graduated_max_launch_age_hours)) * 3600.0
        long_dedup_ttl_seconds = max(
            int(settings.graduated_top_telegram_ttl_seconds),
            int(max_age_seconds),
        )
        now_ms = datetime.now(timezone.utc).timestamp() * 1000.0
        sorted_candidates = sorted(
            candidates,
            key=lambda c: (
                -self._candidate_pair_created_ms(c),
                -float(c.liquidity_usd or 0.0),
                -float((c.raw or {}).get('graduated_prefilter', {}).get('volume_24h') or 0.0),
            ),
        )
        selected: list[TokenCandidate] = []
        for candidate in sorted_candidates:
            pair_ms = self._candidate_pair_created_ms(candidate)
            if pair_ms <= 0:
                continue
            if (now_ms - pair_ms) > max_age_seconds * 1000.0:
                continue
            raw = candidate.raw or {}
            if candidate.chain == Chain.SOLANA:
                pair = raw.get('pair') or {}
                pre = raw.get('graduated_prefilter') or {}
                dex_id = str(pair.get('dexId') or pre.get('dex_id') or '').lower()
                allowed_main = [str(v).lower() for v in (settings.pump_graduated_main_allowed_dex or ['raydium'])]
                if not self._dex_matches(dex_id, allowed_main):
                    continue
            metrics = extract_graduated_metrics(raw, liquidity_fallback=float(candidate.liquidity_usd or 0.0))
            if settings.pump_graduated_quality_mode:
                if not candidate.website:
                    continue
                if not has_quality_social(
                    candidate.x_handle,
                    candidate.telegram_url,
                    require_valid_social=settings.pump_graduated_quality_require_valid_social,
                ):
                    continue
                if not passes_market_gate(metrics['liquidity_usd'], metrics['volume_24h'], metrics['txns_24h'], settings, candidate.chain.value):
                    continue
                if not has_holders_signal(candidate.holders, metrics['txns_24h'], settings, candidate.chain.value):
                    continue
            short_key = f'graduated:tg:top:{candidate.token_address}'
            if await GLOBAL_TTL_CACHE.get(short_key):
                continue
            pair_ms_int = int(pair_ms)
            long_key = f'graduated:tg:top:launch:{candidate.chain.value}:{candidate.token_address}:{pair_ms_int}'
            if await GLOBAL_TTL_CACHE.get(long_key):
                continue
            await GLOBAL_TTL_CACHE.set(short_key, {'sent': True}, ttl_seconds=settings.graduated_top_telegram_ttl_seconds)
            await GLOBAL_TTL_CACHE.set(long_key, {'sent': True}, ttl_seconds=long_dedup_ttl_seconds)
            selected.append(candidate)
            if len(selected) >= top_n:
                break
        if not selected:
            return

        for candidate in selected:
            await self._ensure_candidate_holders(candidate)

        lines = [f'Pump Graduated | New Top {len(selected)}']
        for idx, candidate in enumerate(selected, start=1):
            pre = (candidate.raw or {}).get('graduated_prefilter') or {}
            pair = (candidate.raw or {}).get('pair') or {}
            pair_ms = self._candidate_pair_created_ms(candidate)
            launched = '-'
            if pair_ms > 0:
                try:
                    launched = datetime.fromtimestamp(pair_ms / 1000.0, tz=timezone.utc).strftime('%Y-%m-%d %H:%M UTC')
                except Exception:
                    launched = '-'
            symbol = candidate.symbol or candidate.name or candidate.token_address[:8]
            chain = str(candidate.chain.value or '').lower()
            dex_chain = {'solana': 'solana', 'bsc': 'bsc', 'base': 'base', 'ethereum': 'ethereum'}.get(chain, 'solana')
            chart_target = str(pair.get('pairAddress') or candidate.token_address)
            chart_url = f'https://dexscreener.com/{dex_chain}/{chart_target}'
            if chain == 'solana':
                explorer_url = f'https://solscan.io/token/{candidate.token_address}'
            elif chain == 'bsc':
                explorer_url = f'https://bscscan.com/token/{candidate.token_address}'
            elif chain == 'base':
                explorer_url = f'https://basescan.org/token/{candidate.token_address}'
            else:
                explorer_url = f'https://etherscan.io/token/{candidate.token_address}'
            holders_label = '-' if candidate.holders is None else str(int(candidate.holders))
            market_cap_label = self._format_usd_compact(self._extract_market_cap_usd(candidate))
            lines.append(
                f'{idx}. {symbol} | {chain.upper()} | ${float(candidate.liquidity_usd or 0):,.0f} liq | mcap {market_cap_label} | {holders_label} holders | txns24h {int(pre.get("txns_24h") or 0)}'
            )
            lines.append(f'   Contract: {explorer_url}')
            lines.append(f'   CA: {candidate.token_address}')
            lines.append(f'   Chart: {chart_url}')
            lines.append(f'   launched: {launched}')

        url = f'https://api.telegram.org/bot{settings.telegram_bot_token}/sendMessage'
        try:
            await self.http.post_json(
                url,
                json={
                    'chat_id': settings.telegram_chat_id,
                    'text': '\n'.join(lines),
                    'disable_web_page_preview': True,
                },
            )
            self._telemetry('graduated_top7_telegram_sent', count=len(selected))
        except Exception as exc:
            logger.warning('pipeline: failed to send graduated top telegram alert: %s', exc)

    async def _collect_multichain_graduated_fast_lane(self) -> list[TokenCandidate]:
        if not settings.pump_graduated_multichain_enabled:
            return []
        if not settings.enable_pump_graduated_evm_fast_lane:
            return []

        queries_map = settings.pump_graduated_evm_fast_lane_queries or {}
        max_candidates = max(10, int(settings.pump_graduated_evm_fast_lane_max_candidates))
        dedup_ttl = max(60, int(settings.pump_graduated_evm_fast_lane_dedup_ttl_seconds))
        candidates: list[TokenCandidate] = []
        seen: set[tuple[str, str]] = set()

        for chain in settings.pump_graduated_multichain_chains:
            chain_norm = str(chain or '').lower()
            for query in queries_map.get(chain_norm, []):
                try:
                    pairs = await self.dex.search_pairs(query)
                except Exception as exc:
                    logger.warning('pipeline: evm fast-lane search failed chain=%s query=%s err=%s', chain_norm, query, exc)
                    continue
                scanned = 0
                for pair in pairs:
                    if (pair.get('chainId') or '').lower() != chain_norm:
                        continue
                    if scanned >= max(1, int(settings.pump_graduated_evm_fast_lane_max_pairs_per_query)):
                        break
                    scanned += 1
                    token_address = str((pair.get('baseToken') or {}).get('address') or '')
                    if not token_address:
                        continue
                    key = (chain_norm, token_address.lower())
                    if key in seen:
                        continue
                    cache_key = f'graduated:evm_fastlane:seen:{chain_norm}:{token_address.lower()}'
                    if await GLOBAL_TTL_CACHE.get(cache_key):
                        continue
                    probe_raw = {
                        'chainId': chain_norm,
                        'pair': pair,
                        'graduated_prefilter': self._graduated_prefilter_from_pair(pair),
                    }
                    if not is_multichain_graduated_signal(chain_norm, probe_raw, settings):
                        continue
                    await GLOBAL_TTL_CACHE.set(cache_key, {'seen': True}, ttl_seconds=dedup_ttl)
                    candidate = Normalizer.from_dex_pair(pair)
                    if not candidate:
                        continue
                    candidate.raw['fast_lane'] = True
                    candidate.raw['intake_priority'] = 'graduated_fast_lane'
                    candidate.raw['discovery_source'] = 'multichain_graduated_fastlane'
                    candidate.raw['graduated_confirmed'] = True
                    candidate.raw['lifecycle_stage'] = 'graduated'
                    candidate.raw['launchpad'] = 'multichain_quality'
                    candidate.raw['multichain_graduated'] = True
                    candidate.raw['graduated_via'] = f'evm_fast_lane:{query}'
                    candidate.raw['graduated_prefilter'] = self._graduated_prefilter_from_pair(pair)
                    tagged = self._tag_candidate(candidate)
                    self._telemetry(
                        'evm_graduated_fastlane_candidate',
                        chain=chain_norm,
                        query=query,
                        token=token_address,
                        liquidity_usd=tagged.liquidity_usd,
                        profile=(tagged.raw or {}).get('decision_profile'),
                    )
                    await self._emit_strong_graduated_alert(tagged)
                    seen.add(key)
                    candidates.append(tagged)
                    if len(candidates) >= max_candidates:
                        return candidates
        return candidates

    async def _collect_dex_candidates(self) -> list[TokenCandidate]:
        candidates: list[TokenCandidate] = []
        try:
            dex_profiles = await self.dex.latest_token_profiles()
        except Exception as exc:
            logger.warning('pipeline: dex latest_token_profiles failed: %s', exc)
            dex_profiles = []

        for profile in dex_profiles:
            candidate = Normalizer.from_dex_profile(profile)
            if not candidate or candidate.chain not in MONITORED_CHAINS:
                continue
            candidate = await self._enrich_from_pairs(candidate)
            candidates.append(self._tag_candidate(candidate))

        try:
            url = f'{self.dex.base}/token-boosts/latest/v1'
            data = await self.dex.http.get_json(url)
            if isinstance(data, list):
                for profile in data:
                    if (profile.get('chainId') or '').lower() not in BOOSTED_CHAINS:
                        continue
                    candidate = Normalizer.from_dex_profile(profile)
                    if not candidate:
                        continue
                    candidate = await self._enrich_from_pairs(candidate)
                    candidates.append(self._tag_candidate(candidate))
        except Exception as exc:
            logger.warning('pipeline: dexscreener token-boosts failed: %s', exc)
        return candidates

    async def _collect_birdeye_candidates(self) -> list[TokenCandidate]:
        try:
            birdeye_listings = await self.birdeye.new_listings(limit=settings.birdeye_new_listing_limit)
        except Exception as exc:
            logger.warning('pipeline: birdeye.new_listings failed: %s', exc)
            return []
        candidates: list[TokenCandidate] = []
        for item in birdeye_listings:
            candidate = Normalizer.from_birdeye_listing(item)
            if not candidate:
                continue
            candidates.append(self._tag_candidate(candidate))
        return candidates

    async def _collect_market_candidates(self) -> list[TokenCandidate]:
        candidates: list[TokenCandidate] = []
        if settings.enable_coingecko:
            try:
                for candidate in await self.coingecko.recently_added(limit=50):
                    if candidate.chain in MONITORED_CHAINS:
                        candidates.append(self._tag_candidate(candidate))
            except Exception as exc:
                logger.warning('pipeline: coingecko failed: %s', exc)

        if settings.enable_coinmarketcap:
            try:
                for candidate in await self.coinmarketcap.recently_added(limit=50):
                    if candidate.chain in MONITORED_CHAINS:
                        candidates.append(self._tag_candidate(candidate))
            except Exception as exc:
                logger.warning('pipeline: coinmarketcap failed: %s', exc)
        return candidates

    async def _enrich_from_pairs(self, candidate: TokenCandidate) -> TokenCandidate:
        try:
            pairs = await self.dex.token_pairs(candidate.chain.value, candidate.token_address)
            if pairs:
                candidate = Normalizer.enrich_from_pair(candidate, pairs[0])
        except Exception:
            pass
        return candidate

    def _dedup_candidates(self, candidates: list[TokenCandidate]) -> list[TokenCandidate]:
        dedup: dict[tuple[str, str], TokenCandidate] = {}
        for candidate in candidates:
            key = (candidate.chain.value, candidate.token_address)
            existing = dedup.get(key)
            if existing is None:
                dedup[key] = candidate
                continue
            if (candidate.raw or {}).get('fast_lane') and not (existing.raw or {}).get('fast_lane'):
                dedup[key] = candidate
                continue
            if candidate.liquidity_usd and not existing.liquidity_usd:
                dedup[key] = candidate
        return list(dedup.values())

    def _tag_candidate(self, candidate: TokenCandidate) -> TokenCandidate:
        family = classify_token_family(candidate.chain.value, candidate.token_address, candidate.raw)
        candidate.raw.update({k: v for k, v in family.items() if v is not None})
        if family.get('token_family_reason') == 'multichain_graduated_quality':
            candidate.raw['multichain_graduated'] = True
            candidate.raw.setdefault('launchpad', 'multichain_quality')
            candidate.raw['lifecycle_stage'] = 'graduated'
            candidate.raw['graduated_confirmed'] = True
        profile = classify_decision_profile(candidate.chain.value, candidate.token_address, candidate.raw, candidate.first_seen_at)
        candidate.raw.update({k: v for k, v in profile.items() if v is not None})
        prev_stage = str(candidate.raw.get('lifecycle_stage') or '').lower()
        prev_graduated = bool(candidate.raw.get('graduated_confirmed'))
        if profile.get('decision_profile') == 'pump_graduated' or prev_stage == 'graduated' or prev_graduated:
            # Graduation state must be monotonic. Do not let a stale early snapshot
            # overwrite a token that is already graduated/confirmed.
            candidate.raw['lifecycle_stage'] = 'graduated'
            candidate.raw['graduated_confirmed'] = bool(profile.get('graduated_confirmed') or prev_graduated or prev_stage == 'graduated')
        elif profile.get('decision_profile') == 'pump_early':
            candidate.raw['lifecycle_stage'] = 'early'
            candidate.raw['graduated_confirmed'] = False
        else:
            candidate.raw['lifecycle_stage'] = 'standard'
            candidate.raw['graduated_confirmed'] = False
        candidate.raw.setdefault('source', (candidate.raw.get('source') or 'dexscreener'))
        return candidate

    async def poll_and_enqueue(self) -> int:
        if not self.queue:
            raise RuntimeError('queue_service is required for polling mode')
        count = 0
        graduated_batch: list[TokenCandidate] = []
        for candidate in await self.collect_candidates():
            fast = bool((candidate.raw or {}).get('fast_lane'))
            await self.queue.enqueue_ingest(
                QueueMessage(chain=candidate.chain, token_address=candidate.token_address, payload=candidate.model_dump(mode='json')),
                fast=fast,
            )
            raw = candidate.raw or {}
            if raw.get('lifecycle_stage') == 'graduated' and bool(raw.get('graduated_confirmed')):
                graduated_batch.append(candidate)
            if self._is_pump_candidate(candidate):
                self._telemetry(
                    'enqueue',
                    mint=candidate.token_address,
                    queue='ingest_fast' if fast else 'ingest',
                    liquidity_usd=candidate.liquidity_usd,
                    holders=candidate.holders,
                )
            count += 1
        await self._send_graduated_top7_telegram(graduated_batch)
        return count

    async def poll_pump_and_enqueue(self) -> int:
        if not self.queue:
            raise RuntimeError('queue_service is required for polling mode')
        count = 0
        for candidate in await self.collect_pump_candidates():
            await self.queue.enqueue_ingest(
                QueueMessage(chain=candidate.chain, token_address=candidate.token_address, payload=candidate.model_dump(mode='json')),
                fast=True,
            )
            self._telemetry(
                'enqueue',
                mint=candidate.token_address,
                queue='ingest_fast',
                liquidity_usd=candidate.liquidity_usd,
                holders=candidate.holders,
            )
            count += 1
        self._telemetry('pump_poll_done', enqueued=count)
        return count

    async def run_once(self) -> list[dict[str, str | float | list[str]]]:
        candidates = await self.collect_candidates()
        graduated_batch: list[TokenCandidate] = []
        for candidate in candidates:
            raw = candidate.raw or {}
            if raw.get('lifecycle_stage') == 'graduated' and bool(raw.get('graduated_confirmed')):
                graduated_batch.append(candidate)
        await self._send_graduated_top7_telegram(graduated_batch)
        return await self._evaluate(candidates)

    async def run_graduated_once(self) -> list[dict[str, str | float | list[str]]]:
        """Збирає graduated кандидатів і одразу оцінює — без черги.
        
        Використовується scheduler-ом замість poll_graduated_and_enqueue(),
        щоб graduated токени не зависали в черзі без Redis worker-а.
        """
        candidates = await self.collect_graduated_candidates()
        if candidates:
            await self._send_graduated_top7_telegram(candidates)
        return await self._evaluate(candidates)

    async def run_pump_fast_once(self) -> list[dict[str, str | float | list[str]]]:
        return await self._evaluate(await self.collect_pump_candidates())

    async def _evaluate(self, candidates: list[TokenCandidate]) -> list[dict[str, str | float | list[str]]]:
        results: list[dict[str, str | float | list[str]]] = []
        for candidate in candidates:
            decision = await self.orchestrator.evaluate(candidate)
            if decision is None:
                continue  # invalid address or guard rejected before decision object created
            if self._is_pump_candidate(candidate):
                self._telemetry(
                    'decision',
                    mint=candidate.token_address,
                    status=decision.status,
                    score=decision.score,
                    reasons=' | '.join(decision.reasons[:6]),
                    liquidity_usd=candidate.liquidity_usd,
                    holders=candidate.holders,
                )
            results.append({
                'chain': candidate.chain.value,
                'token_address': candidate.token_address,
                'status': decision.status,
                'score': decision.score,
                'reasons': decision.reasons,
            })
        return results
