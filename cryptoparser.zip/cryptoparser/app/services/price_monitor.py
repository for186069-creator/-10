"""
Price monitor job.

Monitors recently approved tokens and sends Telegram alerts on sharp liquidity moves.
Runs from scheduler every few minutes.
"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any

from sqlalchemy import select, text
from sqlalchemy.ext.asyncio import AsyncSession

from app.adapters.dexscreener import DexScreenerClient
from app.core.config import settings
from app.db.base import AsyncSessionLocal
from app.db.models import TokenDecisionRecord
from app.utils.http import HttpClient

log = logging.getLogger(__name__)

DUMP_DROP_PCT = 30.0
CRITICAL_DROP_PCT = 60.0
PUMP_RISE_PCT = 50.0
ALERT_COOLDOWN_H = 4
MONITOR_DAYS = 14
WINDOW_MINUTES = 60

_CHAIN_SLUG: dict[str, str] = {
    "ethereum": "ethereum",
    "bsc": "bsc",
    "base": "base",
    "solana": "solana",
}


@dataclass(frozen=True)
class ApprovedDecision:
    chain: str
    token_address: str
    score: float


class PriceMonitor:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session
        self.dex = DexScreenerClient()
        self.http = HttpClient()
        self._alert_cooldown: dict[str, datetime] = {}

    async def run(self) -> dict[str, int]:
        stats = {"checked": 0, "alerts_sent": 0, "errors": 0}

        try:
            await self._ensure_snapshot_schema()
        except Exception as exc:
            log.warning("price_monitor: cannot init snapshots schema: %s", exc)
            stats["errors"] += 1
            return stats

        cutoff = datetime.now(timezone.utc) - timedelta(days=MONITOR_DAYS)
        q = (
            select(
                TokenDecisionRecord.chain,
                TokenDecisionRecord.token_address,
                TokenDecisionRecord.score,
            )
            .where(
                TokenDecisionRecord.status == "APPROVE",
                TokenDecisionRecord.created_at >= cutoff,
            )
            .order_by(TokenDecisionRecord.created_at.desc())
        )
        rows = list((await self.session.execute(q)).all())

        seen: set[str] = set()
        unique: list[ApprovedDecision] = []
        for chain, token_address, score in rows:
            chain_str = str(chain or "")
            token_str = str(token_address or "")
            if not chain_str or not token_str:
                continue
            key = f"{chain_str}:{token_str}"
            if key in seen:
                continue
            seen.add(key)
            unique.append(
                ApprovedDecision(
                    chain=chain_str,
                    token_address=token_str,
                    score=float(score or 0.0),
                )
            )

        log.info("price_monitor: checking %d approved tokens", len(unique))

        for decision in unique:
            stats["checked"] += 1
            try:
                await self._check_token(decision, stats)
            except Exception as exc:
                log.warning("price_monitor error %s: %s", decision.token_address[:12], exc)
                stats["errors"] += 1

        log.info("price_monitor run: %s", stats)
        return stats

    async def _check_token(self, decision: ApprovedDecision, stats: dict[str, int]) -> None:
        chain_slug = _CHAIN_SLUG.get(decision.chain.lower(), decision.chain.lower())
        pairs = await self.dex.token_pairs(chain_slug, decision.token_address)
        now = datetime.now(timezone.utc)

        current_liq = _sum_liquidity(pairs)
        await self._save_snapshot(decision.chain, decision.token_address, current_liq, now)

        prev_liq = await self._get_prev_liquidity(
            decision.chain,
            decision.token_address,
            now - timedelta(minutes=WINDOW_MINUTES + 10),
            now - timedelta(minutes=WINDOW_MINUTES - 10),
        )
        if prev_liq is None:
            return

        if not pairs and prev_liq > 1000:
            await self._send_alert(
                decision,
                "PAIRS_GONE",
                {"prev_liq": prev_liq, "current_liq": 0.0},
                stats,
            )
            return

        if prev_liq <= 0 or current_liq <= 0:
            return

        change_pct = (current_liq - prev_liq) / prev_liq * 100.0
        if change_pct <= -CRITICAL_DROP_PCT:
            await self._send_alert(
                decision,
                "CRITICAL_RUG",
                {"prev_liq": prev_liq, "current_liq": current_liq, "change_pct": change_pct},
                stats,
            )
        elif change_pct <= -DUMP_DROP_PCT:
            await self._send_alert(
                decision,
                "DUMP",
                {"prev_liq": prev_liq, "current_liq": current_liq, "change_pct": change_pct},
                stats,
            )
        elif change_pct >= PUMP_RISE_PCT:
            await self._send_alert(
                decision,
                "PUMP",
                {"prev_liq": prev_liq, "current_liq": current_liq, "change_pct": change_pct},
                stats,
            )

    async def _send_alert(
        self,
        decision: ApprovedDecision,
        alert_type: str,
        data: dict[str, Any],
        stats: dict[str, int],
    ) -> None:
        cooldown_key = f"{decision.token_address}:{alert_type}"
        last = self._alert_cooldown.get(cooldown_key)
        if last and (datetime.now(timezone.utc) - last).total_seconds() < ALERT_COOLDOWN_H * 3600:
            return

        emoji = {
            "CRITICAL_RUG": "💀",
            "PAIRS_GONE": "💀",
            "DUMP": "🔴",
            "PUMP": "🚀",
        }.get(alert_type, "⚠️")
        change = float(data.get("change_pct", 0.0) or 0.0)
        sign = "+" if change >= 0 else ""
        chain_label = decision.chain.upper()

        lines = [
            f"{emoji} {alert_type} | {chain_label} | {decision.token_address[:12]}…",
            f'Liquidity: ${float(data.get("prev_liq", 0.0) or 0.0):,.0f} -> ${float(data.get("current_liq", 0.0) or 0.0):,.0f}',
        ]
        if change:
            lines.append(f"Change (1h): {sign}{change:.1f}%")
        lines.append(f"Score at approve: {decision.score:.1f}")
        lines.append(f"https://dexscreener.com/{decision.chain}/{decision.token_address}")

        await self._tg("\n".join(lines))
        self._alert_cooldown[cooldown_key] = datetime.now(timezone.utc)
        stats["alerts_sent"] += 1
        log.info("price_monitor alert %s %s", alert_type, decision.token_address[:12])

    async def _tg(self, text_msg: str) -> None:
        if not settings.enable_telegram or not settings.telegram_bot_token:
            return
        url = f"https://api.telegram.org/bot{settings.telegram_bot_token}/sendMessage"
        try:
            await self.http.post_json(
                url,
                json={
                    "chat_id": settings.telegram_chat_id,
                    "text": text_msg,
                    "disable_web_page_preview": True,
                },
            )
        except Exception as exc:
            log.warning("price_monitor tg send failed: %s", exc)

    async def _save_snapshot(
        self,
        chain: str,
        token_address: str,
        liquidity: float,
        ts: datetime,
    ) -> None:
        try:
            await self.session.execute(
                text(
                    "INSERT INTO price_snapshots (chain, token_address, liquidity_usd, recorded_at) "
                    "VALUES (:chain, :token_address, :liquidity_usd, :recorded_at)"
                ),
                {
                    "chain": chain,
                    "token_address": token_address,
                    "liquidity_usd": liquidity,
                    "recorded_at": ts,
                },
            )
            await self.session.commit()
        except Exception as exc:
            await self.session.rollback()
            log.warning("price_monitor snapshot save failed %s: %s", token_address[:12], exc)

    async def _get_prev_liquidity(
        self,
        chain: str,
        token_address: str,
        ts_min: datetime,
        ts_max: datetime,
    ) -> float | None:
        try:
            row = (
                await self.session.execute(
                    text(
                        "SELECT liquidity_usd FROM price_snapshots "
                        "WHERE chain=:chain AND token_address=:token_address "
                        "AND recorded_at BETWEEN :ts_min AND :ts_max "
                        "ORDER BY recorded_at DESC LIMIT 1"
                    ),
                    {
                        "chain": chain,
                        "token_address": token_address,
                        "ts_min": ts_min,
                        "ts_max": ts_max,
                    },
                )
            ).fetchone()
            return float(row[0]) if row else None
        except Exception as exc:
            log.warning("price_monitor history read failed %s: %s", token_address[:12], exc)
            return None

    async def _ensure_snapshot_schema(self) -> None:
        await self.session.execute(
            text(
                "CREATE TABLE IF NOT EXISTS price_snapshots ("
                "chain VARCHAR(24) NOT NULL, "
                "token_address VARCHAR(128) NOT NULL, "
                "liquidity_usd FLOAT NOT NULL, "
                "recorded_at DATETIME NOT NULL"
                ")"
            )
        )
        await self.session.execute(
            text(
                "CREATE INDEX IF NOT EXISTS ix_price_snapshots_chain_token_recorded_at "
                "ON price_snapshots (chain, token_address, recorded_at)"
            )
        )
        await self.session.commit()


def _sum_liquidity(pairs: list[dict]) -> float:
    total = 0.0
    for pair in pairs:
        liq = pair.get("liquidity", {})
        if isinstance(liq, dict):
            total += float(liq.get("usd", 0.0) or 0.0)
    return total


async def run_price_monitor(session_factory) -> None:
    async with session_factory() as session:
        monitor = PriceMonitor(session)
        await monitor.run()


if __name__ == "__main__":
    from app.core.logging import configure_logging

    configure_logging()

    async def _main() -> None:
        async with AsyncSessionLocal() as session:
            stats = await PriceMonitor(session).run()
            print(stats)

    asyncio.run(_main())
