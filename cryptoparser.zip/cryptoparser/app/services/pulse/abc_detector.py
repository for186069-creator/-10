from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any, Sequence

from sqlalchemy import select

from app.core.config import settings
from app.db.base import AsyncSessionLocal
from app.db.models import PriceSnapshotRecord
from app.services.pulse.candle_aggregator import (
    Candle, CandleAggregator, PricePoint,
    aggregate_candles, build_multi_tf,
)


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

@dataclass(slots=True)
class WaveResult:
    phase: str
    point_bottom: float | None   # дно після graduation dump
    point_a: float | None        # HIGH_A — вершина хвилі A
    point_b: float | None        # LOW_B  — дно хвилі B (точка входу)
    point_c: float | None        # поточна ціна / вершина C
    a_size_pct: float            # розмір A у % від дна
    b_retrace_pct: float         # глибина B як % від A
    c_vs_a_pct: float            # скільки C пройшла відносно A
    fib_level: float
    is_valid: bool
    confidence: float


@dataclass(slots=True)
class ABCSignal:
    detected: bool
    wave_result: WaveResult
    entry_price: float | None = None
    stop_loss: float | None = None
    take_profit: float | None = None
    take_profit_conservative: float | None = None
    take_profit_aggressive: float | None = None
    rr_ratio: float = 0.0
    confidence: float = 0.0
    entry_reason: str = 'no_signal'
    phase: str = 'unknown'
    timeframe_used: str = ''
    wave_data: dict = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_FIBO = (0.236, 0.382, 0.5, 0.618, 0.764, 1.0, 1.272, 1.618)


def _fib(v: float) -> float:
    return min(_FIBO, key=lambda f: abs(f - v))


def _clamp(v: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, v))


def _ts(c: Candle | PricePoint) -> float:
    return float(getattr(c, 'timestamp', 0.0) or 0.0)


def _no(phase: str, reason: str, data: dict | None = None) -> ABCSignal:
    wr = WaveResult(phase, None, None, None, None, 0.0, 0.0, 0.0, 0.0, False, 0.0)
    return ABCSignal(False, wr, None, None, None, None, None,
                     0.0, 0.0, reason, phase, '2s', data or {})


# ---------------------------------------------------------------------------
# Detector
# ---------------------------------------------------------------------------

class ABCDetector:
    """
    Masterforex-V ABC LONG детектор для pump.fun graduated токенів.

    Структура патерну (LONG/BUY):

        Graduation pump → dump → ДНО (точка відліку)
             ↓
        A — вгору від дна  (перший імпульс покупців)
             ↓
        B — вниз           (корекція 38.2–76.4% від A, але ВИЩЕ дна!)
             ↓
        ВХІД в кінці B    (ФЗР: свічка закрилась вище HIGH_A)
             ↓
        C — вгору          (наш прибуток)

    Стратегії: survival, pump_graduated, smart_wallet.
    """

    def __init__(self) -> None:
        self.aggregator       = CandleAggregator()
        self.ctx_sec          = int(getattr(settings, 'abc_candle_seconds',            60) or  60)
        self.sig_sec          = int(getattr(settings, 'abc_signal_candle_seconds',     30) or  30)
        self.ent_sec          = int(getattr(settings, 'abc_entry_candle_seconds',      10) or  10)
        self.min_ticks        = int(getattr(settings, 'abc_min_ticks_for_analysis',    40) or  40)
        self.min_a_pct        = float(getattr(settings, 'abc_min_a_size_pct',        0.08) or 0.08)
        self.max_a_pct        = float(getattr(settings, 'abc_max_a_size_pct',        0.80) or 0.80)
        self.min_b_ret        = float(getattr(settings, 'abc_min_b_retrace',        0.382) or 0.382)
        self.max_b_ret        = float(getattr(settings, 'abc_max_b_retrace',        0.764) or 0.764)
        self.min_dump_pct     = float(getattr(settings, 'abc_min_dump_pct',          0.10) or 0.10)
        self.sl_buf           = float(getattr(settings, 'abc_stop_loss_buffer_pct',  0.02) or 0.02)
        self.min_rr           = float(getattr(settings, 'abc_min_rr',               1.5)  or 1.5)
        self.min_conf         = float(getattr(settings, 'abc_min_confidence',        0.55) or 0.55)
        self.lookback_min     = int(getattr(settings, 'abc_snapshot_lookback_minutes', 120) or 120)
        self.snap_limit       = int(getattr(settings, 'abc_snapshot_limit',          1200) or 1200)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def detect(
        self,
        chain: str,
        token_address: str,
        impulse_high: float | None = None,
        current_price: float | None = None,
        snapshots: Sequence[PriceSnapshotRecord] | None = None,
    ) -> ABCSignal:
        import logging as _lg
        log = _lg.getLogger('pulse.abc')

        # 1. Завантажити snapshots
        if snapshots is not None:
            rows = list(snapshots)
        else:
            cutoff = datetime.now(timezone.utc) - timedelta(minutes=self.lookback_min)
            async with AsyncSessionLocal() as session:
                rows = (
                    await session.execute(
                        select(PriceSnapshotRecord)
                        .where(
                            PriceSnapshotRecord.chain == chain,
                            PriceSnapshotRecord.token_address == token_address,
                            PriceSnapshotRecord.captured_at >= cutoff,
                        )
                        .order_by(PriceSnapshotRecord.captured_at.desc())
                        .limit(self.snap_limit)
                    )
                ).scalars().all()

        ticks = self.aggregator.from_snapshots(list(reversed(rows)))
        log.debug('abc_ticks chain=%s token=%s ticks=%d min=%d',
                  chain, token_address[:12], len(ticks), self.min_ticks)

        if len(ticks) < self.min_ticks:
            return _no('no_data', 'mfv_insufficient_ticks',
                       {'ticks': len(ticks), 'min': self.min_ticks})

        # 2. Підібрати таймфрейм під реальну щільність тіку.
        # 2-секундний paper-trading loop не може наповнити 5m/1m/30s
        # вікно достатньо швидко, тому для live/watching режиму
        # використовуємо адаптивно коротші бакети, доки історія не стане довшою.
        history_span_sec = float((ticks[-1].timestamp - ticks[0].timestamp) if len(ticks) >= 2 else 0.0)
        if history_span_sec < float(self.ctx_sec * 3):
            ctx_sec, sig_sec, ent_sec = 20, 10, 5
            tf_mode = 'adaptive_live'
        else:
            ctx_sec, sig_sec, ent_sec = self.ctx_sec, self.sig_sec, self.ent_sec
            tf_mode = 'default'

        c5m, c1m, c30s = build_multi_tf(
            ticks,
            context_seconds=ctx_sec,
            signal_seconds=sig_sec,
            entry_seconds=ent_sec,
        )
        log.debug(
            'abc_tf_mode chain=%s token=%s mode=%s span_sec=%.1f ctx=%d sig=%d ent=%d',
            chain,
            token_address[:12],
            tf_mode,
            history_span_sec,
            ctx_sec,
            sig_sec,
            ent_sec,
        )
        min_c5m, min_c1m, min_c30s = (2,3,3) if tf_mode=='adaptive_live' else (3,5,5)
        if len(c5m) < min_c5m:
            return _no('no_data', 'mfv_insufficient_5m', {'n': len(c5m)})
        if len(c1m) < min_c1m:
            return _no('no_data', 'mfv_insufficient_1m', {'n': len(c1m)})
        if len(c30s) < min_c30s:
            return _no('no_data', 'mfv_insufficient_30s', {'n': len(c30s)})

        curr = float(current_price or ticks[-1].price)

        # 3. Знайти ДНО після graduation dump
        #    Дно = глобальний мінімум за весь період (5-хв свічки)
        bot_candle = min(c5m, key=lambda c: c.low)
        bot        = float(bot_candle.low or 0.0)
        bot_ts     = _ts(bot_candle)

        if bot <= 0:
            return _no('no_data', 'mfv_no_bottom')

        # Перевірка: перед дном був реальний dump
        grad_high = float(impulse_high or 0.0)
        if grad_high <= 0:
            pre = [c for c in c5m if _ts(c) < bot_ts]
            if pre:
                grad_high = max(c.high for c in pre)

        if grad_high > 0:
            dump_pct = (grad_high - bot) / max(grad_high, 1e-9)
            if dump_pct < self.min_dump_pct:
                return _no('no_data', 'mfv_dump_too_small',
                           {'dump_pct': round(dump_pct, 3), 'grad_high': grad_high, 'bot': bot})

        # 4. Хвиля A — перший рух ВГОРУ від дна (1-хв свічки після дна)
        post_bot = [c for c in c1m if _ts(c) >= bot_ts]
        if len(post_bot) < 3:
            return _no('waiting_wave_a', 'mfv_waiting_wave_a',
                       {'bot': bot, 'bot_ts': bot_ts})

        # HIGH_A = перший локальний максимум після дна
        high_a      = 0.0
        high_a_idx  = 0
        high_a_ts   = 0.0
        for i, c in enumerate(post_bot[1:], 1):
            if c.high > high_a:
                high_a     = c.high
                high_a_idx = i
                high_a_ts  = _ts(c)
            # Зупиняємось коли ціна відкотилась >12% від поточного піку
            if high_a > 0 and c.close < high_a * 0.88:
                break

        if high_a <= bot:
            return _no('waiting_wave_a', 'mfv_no_wave_a_yet', {'bot': bot})

        a_size = (high_a - bot) / max(bot, 1e-9)
        if not (self.min_a_pct <= a_size <= self.max_a_pct):
            return _no('wave_a', f'mfv_a_out_of_range a={a_size:.3f}',
                       {'bot': bot, 'high_a': high_a, 'a_size_pct': round(a_size * 100, 2)})

        # 5. Хвиля B — корекція ВНИЗ після HIGH_A (1-хв свічки після HIGH_A)
        post_a = [c for c in c1m if _ts(c) > high_a_ts]
        if len(post_a) < 2:
            wr = WaveResult('wave_b', bot, high_a, None, None,
                            a_size * 100, 0.0, 0.0, 0.0, False, 0.40)
            return ABCSignal(False, wr, None, None, None, None, None,
                             0.0, 0.40, 'mfv_waiting_wave_b', 'wave_b', '1m',
                             {'bot': bot, 'high_a': high_a})

        a_range  = high_a - bot
        low_b    = float('inf')
        low_b_ts = 0.0

        for c in post_a:
            # КЛЮЧОВА УМОВА MF-V: B не може йти нижче дна
            if c.low <= bot:
                # Нове дно — ABC скасовується, шукаємо новий патерн
                return _no('waiting_wave_a', 'mfv_b_broke_bottom',
                           {'bot': bot, 'high_a': high_a, 'low_attempt': c.low})
            if c.low < low_b:
                low_b    = c.low
                low_b_ts = _ts(c)
            # Зупиняємось коли ціна відновилась від дна B на >3%
            if low_b < float('inf') and c.close > low_b * 1.03:
                break

        if low_b == float('inf') or low_b <= 0:
            return _no('wave_b', 'mfv_no_wave_b_yet', {'high_a': high_a})

        b_ret = (high_a - low_b) / max(a_range, 1e-9)

        if b_ret < self.min_b_ret:
            wr = WaveResult('wave_b', bot, high_a, low_b, None,
                            a_size * 100, b_ret, 0.0, _fib(b_ret), False, 0.38)
            return ABCSignal(False, wr, None, None, None, None, None,
                             0.0, 0.38, f'mfv_b_shallow b={b_ret:.3f}', 'wave_b', '1m',
                             {'bot': bot, 'high_a': high_a, 'low_b': low_b})

        if b_ret > self.max_b_ret:
            wr = WaveResult('wave_b', bot, high_a, low_b, None,
                            a_size * 100, b_ret, 0.0, _fib(b_ret), False, 0.35)
            return ABCSignal(False, wr, None, None, None, None, None,
                             0.0, 0.35, f'mfv_b_deep b={b_ret:.3f}', 'wave_b', '1m',
                             {'bot': bot, 'high_a': high_a, 'low_b': low_b})

        # 6. ФЗР — підтвердження розвороту B
        #    30-сек свічка закрилась ВИЩЕ HIGH_A після LOW_B
        post_b_30s = [c for c in c30s if _ts(c) >= low_b_ts]
        if len(post_b_30s) < 2:
            wr = WaveResult('wave_b', bot, high_a, low_b, None,
                            a_size * 100, b_ret, 0.0, _fib(b_ret), False, 0.45)
            return ABCSignal(False, wr, None, None, None, None, None,
                             0.0, 0.45, 'mfv_waiting_fzr', 'wave_b', '30s',
                             {'bot': bot, 'high_a': high_a, 'low_b': low_b})

        fzr_ok = False
        for c in post_b_30s:
            if c.close > high_a:
                fzr_ok = True
                break

        # Також підтверджено якщо поточна ціна вже вище HIGH_A
        if not fzr_ok and curr > high_a:
            fzr_ok = True

        # Soft-ФЗР: якщо ціна підійшла до HIGH_A в межах 5% — вважаємо "fzr_forming"
        # Це дозволяє graduated токенам входити на підході до зони, а не чекати пробою
        near_fzr = not fzr_ok and curr >= high_a * 0.90

        if not fzr_ok:
            phase_out = 'fzr_forming' if near_fzr else 'wave_c'
            conf_out = 0.50 if near_fzr else 0.50
            wr = WaveResult(phase_out, bot, high_a, low_b, None,
                            a_size * 100, b_ret, 0.0, _fib(b_ret), False, conf_out)
            return ABCSignal(False, wr, curr, low_b * (1.0 - self.sl_buf), None, None, None,
                             0.0, conf_out, 'mfv_fzr_not_confirmed', phase_out, '30s',
                             {'bot': bot, 'high_a': high_a, 'low_b': low_b, 'near_fzr': near_fzr})

        # 7. Розрахувати entry / SL / TP
        entry = curr
        sl    = low_b * (1.0 - self.sl_buf)
        risk  = max(entry - sl, 1e-9)

        # TP1: LOW_B + a_range  (C = A, Фібо 100%)
        tp1 = low_b + a_range
        # TP2: HIGH_A + a_range * 1.618  (розширення Фібо 161.8%)
        tp2 = high_a + a_range * 1.618

        rr1 = max(0.0, tp1 - entry) / risk
        rr2 = max(0.0, tp2 - entry) / risk

        if rr2 >= 3.0:
            tp, rr = tp2, rr2
        elif rr1 >= self.min_rr:
            tp, rr = tp1, rr1
        else:
            wr = WaveResult('fzr_confirmed', bot, high_a, low_b, curr,
                            a_size * 100, b_ret, 0.0, _fib(b_ret), False, 0.55)
            return ABCSignal(False, wr, entry, sl, tp1, tp1, tp2, rr1, 0.55,
                             f'mfv_rr_low rr1={rr1:.2f} rr2={rr2:.2f}',
                             'fzr_confirmed', '5m/1m/30s/2s',
                             {'bot': bot, 'high_a': high_a, 'low_b': low_b,
                              'rr1': rr1, 'rr2': rr2})

        # Перевірка що ми в зоні входу (ціна близько до HIGH_A або нижче)
        entry_ok = entry <= high_a * 1.15  # 15% зона входу (мем токени рухаються швидко)
        if not entry_ok:
            wr = WaveResult('fzr_confirmed', bot, high_a, low_b, curr,
                            a_size * 100, b_ret, 0.0, _fib(b_ret), False, 0.58)
            return ABCSignal(False, wr, entry, sl, tp, tp1, tp2, rr, 0.58,
                             f'mfv_entry_too_high entry={entry:.8f} high_a={high_a:.8f}',
                             'fzr_confirmed', '5m/1m/30s/2s',
                             {'bot': bot, 'high_a': high_a, 'low_b': low_b})

        # 8. Confidence
        conf = 0.0
        if 0.10 <= a_size <= 0.60:            conf += 0.25
        if 0.382 <= b_ret  <= 0.618:          conf += 0.25
        if fzr_ok:                            conf += 0.20
        if entry_ok:                          conf += 0.15
        if rr >= 3.0:                         conf += 0.15
        conf = _clamp(conf)

        if conf < self.min_conf:
            wr = WaveResult('fzr_confirmed', bot, high_a, low_b, curr,
                            a_size * 100, b_ret, 0.0, _fib(b_ret), False, conf)
            return ABCSignal(False, wr, entry, sl, tp, tp1, tp2, rr, conf,
                             f'mfv_low_conf conf={conf:.2f}',
                             'fzr_confirmed', '5m/1m/30s/2s',
                             {'bot': bot, 'high_a': high_a, 'low_b': low_b})

        # 9. ВХІД ГОТОВИЙ
        c_pct = max(0.0, curr - low_b) / max(a_range, 1e-9)
        wr = WaveResult('entry_ready', bot, high_a, low_b, curr,
                        a_size * 100, b_ret, c_pct, _fib(c_pct), True, conf)

        reason = (
            f'mfv_long_entry '
            f'bot={bot:.8f} a={high_a:.8f} b={low_b:.8f} '
            f'rr={rr:.2f} conf={conf:.2f}'
        )
        return ABCSignal(
            True, wr, entry, sl, tp, tp1, tp2, rr, conf,
            reason, 'entry_ready', '5m/1m/30s/2s',
            {
                'bottom_price':    bot,
                'high_a':          high_a,
                'low_b':           low_b,
                'entry':           entry,
                'stop_loss':       sl,
                'tp_conservative': tp1,
                'tp_aggressive':   tp2,
                'rr1':             round(rr1, 2),
                'rr2':             round(rr2, 2),
                'a_size_pct':      round(a_size * 100, 2),
                'b_retrace_pct':   round(b_ret * 100, 2),
                'c_pct':           round(c_pct * 100, 2),
                'fzr_confirmed':   fzr_ok,
                'grad_high':       grad_high,
                'dump_pct':        round((grad_high - bot) / max(grad_high, 1e-9) * 100, 2) if grad_high > 0 else 0.0,
            },
        )
