from __future__ import annotations

import logging

from app.core.config import settings
from app.utils.cache import GLOBAL_CACHE
from app.utils.http import HttpClient

logger = logging.getLogger(__name__)


class PulseAlerter:
    def __init__(self) -> None:
        self.http = HttpClient()

    async def on_open(self, position) -> None:
        emoji = {'farm': '🌾', 'survival': '🛡️', 'smart_wallet': '🐋'}.get(position.strategy, '📊')
        text = (
            f"{emoji} PULSE — позиція відкрита\n"
            f"Токен: {position.symbol or position.token_address[:12]}\n"
            f"Чейн: {position.chain.upper()}\n"
            f"Стратегія: {position.strategy}\n"
            f"Ціна входу: ${self._fmt_price(position.entry_price)}\n"
            f"SL: {position.stop_loss_pct}% | TP: +{position.take_profit_pct}%\n"
            f"Розмір: ${position.paper_size_usd:.0f} (paper)"
        )
        await self._send(text)

    async def on_close(self, position) -> None:
        pnl = position.paper_pnl_pct or 0
        pnl_usd = position.paper_pnl_usd or 0
        emoji = '✅' if pnl >= 0 else '❌'
        reason_map = {
            'take_profit': '🎯 Take Profit',
            'stop_loss': '🛑 Stop Loss',
            'trailing_stop': '📉 Trailing Stop',
            'time_limit': '⏱ Time Limit',
            'stagnation': '🪫 Stagnation',
            'token_dead': '💀 Токен помер',
            'liquidity_collapse': '💧 Ліквідність впала',
            'holders_dump': '🏃 Холдери виходять',
            'circuit_breaker': '🔌 Circuit Breaker',
            'manual_close': '✋ Manual Close',
            'dev_wallet_dump': '🚨 Dev Wallet Dump',
        }
        reason_text = reason_map.get(position.exit_reason, position.exit_reason or 'unknown')
        sign = '+' if pnl >= 0 else ''
        text = (
            f"{emoji} PULSE — позиція закрита\n"
            f"Токен: {position.symbol or position.token_address[:12]}\n"
            f"P&L: {sign}{pnl:.1f}% (${sign}{pnl_usd:.2f} paper)\n"
            f"Причина: {reason_text}\n"
            f"Стратегія: {position.strategy} | {position.chain.upper()}"
        )
        await self._send(text)

    async def on_circuit_breaker(self, daily_pnl: float) -> None:
        text = (
            f"🔌 PULSE — Circuit Breaker активовано\n"
            f"Денний збиток: ${daily_pnl:.2f} paper\n"
            f"Нові позиції заблоковані до кінця дня (UTC)"
        )
        await self._send(text, dedup_key='circuit_breaker', dedup_ttl=3600)

    async def on_partial_exit(self, position, fraction: float) -> None:
        text = (
            f"🟡 PULSE — partial TP\n"
            f"Токен: {position.symbol or position.token_address[:12]}\n"
            f"Продано: {fraction * 100:.0f}%\n"
            f"PnL: {position.paper_pnl_pct:+.1f}% (${position.paper_pnl_usd:+.2f} paper)"
        )
        await self._send(text)

    def _fmt_price(self, p: float | None) -> str:
        if not p:
            return '–'
        if p < 0.0001:
            return f'{p:.2e}'
        if p < 0.01:
            return f'{p:.6f}'
        return f'{p:.4f}'

    async def _send(self, text: str, dedup_key: str | None = None, dedup_ttl: int = 60) -> None:
        if not settings.enable_telegram or not settings.telegram_bot_token or not settings.telegram_chat_id:
            return
        if dedup_key:
            existing = await GLOBAL_CACHE.get(f'pulse-alert:{dedup_key}')
            if existing is not None:
                return
            await GLOBAL_CACHE.set(f'pulse-alert:{dedup_key}', True, ttl_seconds=dedup_ttl)
        try:
            url = f'https://api.telegram.org/bot{settings.telegram_bot_token}/sendMessage'
            await self.http.post_json(
                url,
                json={
                    'chat_id': settings.telegram_chat_id,
                    'text': text,
                    'disable_web_page_preview': True,
                },
            )
        except Exception as e:
            logger.debug('pulse_alert send failed: %s', e)
