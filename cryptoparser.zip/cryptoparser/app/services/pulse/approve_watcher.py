"""
approve_watcher.py — підхоплює старі APPROVE з token_decisions і ставить їх в watching.

Логіка:
  1. Читає token_decisions WHERE status IN ('APPROVE','FARM_APPROVE')
     за останні approve_watcher_lookback_hours годин
  2. Виключає токени що вже є в token_lifecycle (paper_open / watching)
  3. Виключає токени старіші за max_launch_age_hours (Fartcoin, WOJAK тощо)
  4. Відкриває watching для решти — ABC детектор підхопить при наступному tick
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone

from sqlalchemy import func, select, text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.db.base import AsyncSessionLocal
from app.db.models import TokenCandidateRecord, TokenDecisionRecord, TokenLifecycleRecord
from app.models.token import Chain, TokenCandidate

logger = logging.getLogger(__name__)


async def run_approve_watcher(session_factory=None) -> int:
    """Повертає кількість нових watching позицій відкритих за цикл."""
    factory = session_factory or AsyncSessionLocal
    async with factory() as session:
        return await _run(session)


async def _run(session: AsyncSession) -> int:
    if not settings.paper_trading_enabled:
        return 0

    lookback_hours = float(getattr(settings, 'approve_watcher_lookback_hours', 48.0) or 48.0)
    max_age_hours  = float(getattr(settings, 'pump_graduated_max_launch_age_hours', 48.0) or 48.0)
    max_watching   = int(getattr(settings, 'approve_watcher_max_per_cycle', 20) or 20)
    min_score      = float(getattr(settings, 'approve_watcher_min_score', 70.0) or 70.0)
    min_liquidity  = float(getattr(settings, 'paper_min_liquidity_exit_usd', 30_000.0) or 30_000.0)

    since = datetime.now(timezone.utc) - timedelta(hours=lookback_hours)

    # 1. Всі свіжі APPROVE/FARM_APPROVE з БД
    decisions_q = (
        select(TokenDecisionRecord)
        .where(
            TokenDecisionRecord.status.in_(['APPROVE', 'FARM_APPROVE']),
            TokenDecisionRecord.created_at >= since,
            TokenDecisionRecord.score >= min_score,
        )
        .order_by(TokenDecisionRecord.score.desc())
        .limit(200)
    )
    result = await session.execute(decisions_q)
    decisions = list(result.scalars().all())

    if not decisions:
        return 0

    token_keys = [(d.chain, d.token_address) for d in decisions]

    # 2. Які вже є в lifecycle (watching, open АБО CLOSED — виключаємо щоб не відкривати повторно)
    existing_q = (
        select(TokenLifecycleRecord.chain, TokenLifecycleRecord.token_address)
        .where(
            TokenLifecycleRecord.status.in_(['watching', 'paper_open', 'paper_closed']),
        )
    )
    existing_result = await session.execute(existing_q)
    existing_set = {(r.chain, r.token_address) for r in existing_result}

    # 3. Candidates з БД для метаданих
    addresses = [t for _, t in token_keys]
    candidates_q = (
        select(TokenCandidateRecord)
        .where(TokenCandidateRecord.token_address.in_(addresses))
    )
    cand_result = await session.execute(candidates_q)
    cand_map = {r.token_address: r for r in cand_result.scalars().all()}

    # Перевіряємо поточну кількість watching позицій (виключаємо стейли > 45хв)
    _fresh_cutoff = datetime.now(timezone.utc) - timedelta(minutes=45)
    watching_count_q = (
        select(func.count(TokenLifecycleRecord.id))
        .where(TokenLifecycleRecord.status == 'watching')
        .where(
            (TokenLifecycleRecord.first_seen_at.is_(None)) |
            (TokenLifecycleRecord.first_seen_at >= _fresh_cutoff)
        )
    )
    watching_count_res = await session.execute(watching_count_q)
    current_watching = watching_count_res.scalar() or 0
    # Резервуємо 5 слотів для fresh токенів — не заповнюємо watchlist повністю
    max_total_watching = 35
    if current_watching >= max_total_watching:
        logger.debug('approve_watcher watchlist_full watching=%d max=%d', current_watching, max_total_watching)
        return 0

    opened = 0
    now = datetime.now(timezone.utc)

    for decision in decisions:
        if opened >= max_watching:
            break
        if current_watching + opened >= max_total_watching:
            break

        key = (decision.chain, decision.token_address)
        if key in existing_set:
            continue

        cand_rec = cand_map.get(decision.token_address)

        # Перевірка віку пари (якщо є)
        if cand_rec:
            raw = cand_rec.raw or {}
            pair_created_ms = (
                (raw.get('pair') or {}).get('pairCreatedAt')
                or raw.get('pairCreatedAt')
                or raw.get('pair_created_at')
            )
            if pair_created_ms:
                try:
                    pair_dt = datetime.fromtimestamp(float(pair_created_ms) / 1000, tz=timezone.utc)
                    age_hours = (now - pair_dt).total_seconds() / 3600.0
                    if age_hours > max_age_hours:
                        logger.debug(
                            'approve_watcher skip=too_old token=%s age_h=%.1f',
                            decision.token_address[:12], age_hours,
                        )
                        continue
                except Exception:
                    pass

        # Перевірка safety: пропускаємо якщо cannot_sell або honeypot
        evidence = decision.evidence or {}
        reasons = decision.reasons or []
        if isinstance(reasons, str):
            import json as _json
            try:
                reasons = _json.loads(reasons)
            except Exception:
                reasons = [reasons]
        bad_flags = {'cannot_sell_or_unknown', 'honeypot_or_unknown', 'safety_gate:cannot_sell_or_unknown'}
        if any(r in bad_flags for r in reasons):
            logger.debug('approve_watcher skip=safety token=%s', decision.token_address[:12])
            continue

        # Перевірка ліквідності з candidate record
        if not cand_rec:
            # Немає запису в БД — немає даних для перевірки MCap/liq → пропускаємо
            logger.debug('approve_watcher skip=no_cand_rec token=%s', decision.token_address[:12])
            continue
        if cand_rec:
            cand_liq = float(cand_rec.liquidity_usd or 0.0)
            # MCap перевірка — блокуємо токени з низьким MCap
            cand_mcap = float(cand_rec.market_cap_usd or 0.0)
            min_mcap = float(getattr(settings, 'pulse_min_market_cap_usd', 30_000.0) or 30_000.0)
            if 0 < cand_mcap < min_mcap:
                logger.debug(
                    'approve_watcher skip=low_mcap token=%s mcap=%.0f < %.0f',
                    decision.token_address[:12], cand_mcap, min_mcap,
                )
                continue
            if cand_liq < min_liquidity:  # block None/0 too — unknown liquidity is dangerous
                logger.debug(
                    'approve_watcher skip=low_liq token=%s liq=%.0f < %.0f',
                    decision.token_address[:12], cand_liq, min_liquidity,
                )
                continue

        # Визначаємо decision_profile для graduated токенів
        decision_profile = str(evidence.get('decision_profile') or '').lower().strip()
        if not decision_profile:
            raw_r = cand_rec.raw or {} if cand_rec else {}
            decision_profile = str(raw_r.get('decision_profile') or raw_r.get('profile') or '').lower().strip()
        if not decision_profile and decision.status in ('APPROVE', 'FARM_APPROVE'):
            # Якщо token_address закінчується на 'pump' — це pump_graduated
            if decision.token_address.endswith('pump'):
                decision_profile = 'pump_graduated'

        # Відкриваємо watching
        try:
            # Перевіряємо чи вже не існує (race condition)
            check = await session.execute(
                select(TokenLifecycleRecord)
                .where(
                    TokenLifecycleRecord.chain == decision.chain,
                    TokenLifecycleRecord.token_address == decision.token_address,
                    TokenLifecycleRecord.status.in_(['watching', 'paper_open']),
                )
                .limit(1)
            )
            if check.scalar_one_or_none() is not None:
                continue

            lifecycle = TokenLifecycleRecord()
            lifecycle.chain         = decision.chain
            lifecycle.token_address = decision.token_address
            lifecycle.status        = 'watching'
            lifecycle.exit_reason   = 'APPROVE'
            lifecycle.entry_score   = float(decision.score or 0.0)
            _strat = str((decision.evidence or {}).get('strategy_hint') or 'smart_wallet')
            lifecycle.strategy           = _strat
            lifecycle.entry_brain_strategy = _strat
            lifecycle.entry_at      = now
            lifecycle.peak_at       = now
            lifecycle.first_seen_at = now
            lifecycle.updated_at    = now
            lifecycle.last_checked_at = now

            if cand_rec:
                lifecycle.symbol       = cand_rec.symbol
                lifecycle.pair_address = (
                    cand_rec.pair_address
                    or (cand_rec.raw or {}).get('pair', {}).get('pairAddress')
                )
                lifecycle.liquidity_usd = cand_rec.liquidity_usd
                lifecycle.holders       = cand_rec.holders

            lifecycle.entry_signals = {
                'source': 'approve_watcher',
                'decision_score': float(decision.score or 0.0),
                'decision_status': decision.status,
                'subscores': decision.subscores or {},
                'decision_profile': decision_profile or None,
            }
            lifecycle.execution_metadata = {
                'watch_reason': 'approve_watcher',
                'entry_score': float(decision.score or 0.0),
                'entry_momentum_score': float((decision.subscores or {}).get('continuation', 0.5)),
                'decision_profile': decision_profile or None,
                'chain': decision.chain,
            }

            session.add(lifecycle)
            existing_set.add(key)
            opened += 1

            logger.info(
                'pump_telemetry event=approve_watcher_open token=%s chain=%s score=%.1f',
                decision.token_address[:12],
                decision.chain,
                decision.score,
            )

        except Exception as exc:
            logger.warning('approve_watcher error token=%s: %s', decision.token_address[:12], exc)
            continue

    if opened:
        await session.commit()
        logger.info('pump_telemetry event=approve_watcher_done opened=%d', opened)

    return opened
