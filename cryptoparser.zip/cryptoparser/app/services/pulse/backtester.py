from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.db.models import PriceSnapshotRecord, TokenLifecycleRecord


@dataclass(slots=True)
class BacktestParams:
    sl_pct: float = 8.0
    tp_pct: float = 20.0
    trailing_pct: float = 15.0
    partial_tp_pct: float = 30.0
    partial_tp_fraction: float = 0.5
    stagnation_minutes: int = 60
    min_liquidity_exit_usd: float = 30_000.0
    paper_gas_fee_usd: float = 0.35
    price_batch_slippage_pct: float = 1.0


class Backtester:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def run(self, days: int = 30, params: dict[str, Any] | None = None) -> dict[str, Any]:
        cfg = self._merge_params(params or {})
        since = datetime.now(timezone.utc) - timedelta(days=max(1, int(days)))
        result = await self.session.execute(
            select(TokenLifecycleRecord).where(
                TokenLifecycleRecord.status == 'paper_closed',
                TokenLifecycleRecord.entry_at >= since,
                TokenLifecycleRecord.entry_price.isnot(None),
            )
        )
        trades = list(result.scalars().all())
        simulations: list[dict[str, Any]] = []
        for trade in trades:
            snapshots = await self._load_snapshots(trade.chain, trade.token_address, trade.entry_at, trade.exit_at)
            if not snapshots:
                continue
            simulations.append(self._simulate_trade(trade, snapshots, cfg))

        return self._summarize(simulations, cfg, days)

    async def grid_search(self, grid: list[dict[str, Any]], days: int = 30) -> dict[str, Any]:
        best: dict[str, Any] | None = None
        trials: list[dict[str, Any]] = []
        for params in grid:
            result = await self.run(days=days, params=params)
            trial = {'params': params, 'result': result}
            trials.append(trial)
            score = float(result.get('avg_pnl_pct') or 0.0)
            if best is None or score > float(best['result'].get('avg_pnl_pct') or float('-inf')):
                best = trial
        return {'best': best, 'trials': trials}


    async def walk_forward(self, days: int = 90, folds: int = 4, params: dict[str, Any] | None = None) -> dict[str, Any]:
        """Walk-forward style out-of-sample check on already closed trades.

        Splits trades chronologically into contiguous holdout folds and evaluates
        each fold independently using the existing simulator.
        """
        cfg = self._merge_params(params or {})
        since = datetime.now(timezone.utc) - timedelta(days=max(1, int(days)))
        result = await self.session.execute(
            select(TokenLifecycleRecord).where(
                TokenLifecycleRecord.status == 'paper_closed',
                TokenLifecycleRecord.entry_at >= since,
                TokenLifecycleRecord.entry_price.isnot(None),
            ).order_by(TokenLifecycleRecord.entry_at.asc())
        )
        trades = list(result.scalars().all())
        if not trades:
            return {'days': days, 'folds': folds, 'trades': 0, 'fold_results': [], 'win_rate': 0.0, 'avg_pnl_pct': 0.0, 'total_pnl_usd': 0.0, 'total_fees_usd': 0.0, 'oos_win_rate': 0.0, 'oos_avg_pnl_pct': 0.0, 'oos_total_fees_usd': 0.0}

        folds = max(2, min(int(folds or 4), max(2, len(trades))))
        chunk = max(1, len(trades) // (folds + 1))
        fold_results: list[dict[str, Any]] = []
        all_results: list[dict[str, Any]] = []
        for idx in range(folds):
            test_start = (idx + 1) * chunk
            if test_start >= len(trades):
                break
            test_end = len(trades) if idx == folds - 1 else min(len(trades), test_start + chunk)
            holdout = trades[test_start:test_end]
            if not holdout:
                continue
            simulations: list[dict[str, Any]] = []
            for trade in holdout:
                snapshots = await self._load_snapshots(trade.chain, trade.token_address, trade.entry_at, trade.exit_at)
                if not snapshots:
                    continue
                simulations.append(self._simulate_trade(trade, snapshots, cfg))
            if not simulations:
                continue
            fold_results.append(self._summarize(simulations, cfg, days))
            all_results.extend(simulations)

        if not all_results:
            return {'days': days, 'folds': folds, 'trades': len(trades), 'fold_results': fold_results, 'win_rate': 0.0, 'avg_pnl_pct': 0.0, 'total_pnl_usd': 0.0, 'total_fees_usd': 0.0, 'oos_win_rate': 0.0, 'oos_avg_pnl_pct': 0.0, 'oos_total_fees_usd': 0.0}

        oos_wins = [r for r in all_results if float(r.get('pnl_pct') or 0.0) > 0]
        oos_pnl = [float(r.get('pnl_pct') or 0.0) for r in all_results]
        oos_usd = [float(r.get('pnl_usd') or 0.0) for r in all_results]
        oos_fees = [float(r.get('fees_usd') or 0.0) for r in all_results]
        return {
            'days': days,
            'folds': folds,
            'trades': len(trades),
            'fold_results': fold_results,
            'oos_trades': len(all_results),
            'oos_win_rate': round(len(oos_wins) / len(all_results), 4),
            'oos_avg_pnl_pct': round(sum(oos_pnl) / len(oos_pnl), 4),
            'oos_total_pnl_usd': round(sum(oos_usd), 4),
            'oos_total_fees_usd': round(sum(oos_fees), 4),
            'total_pnl_usd': round(sum(oos_usd), 4),
            'total_fees_usd': round(sum(oos_fees), 4),
            'win_rate': round(len(oos_wins) / len(all_results), 4),
            'avg_pnl_pct': round(sum(oos_pnl) / len(oos_pnl), 4),
        }

    async def _load_snapshots(
        self,
        chain: str,
        token_address: str,
        entry_at: datetime | None,
        exit_at: datetime | None,
    ) -> list[PriceSnapshotRecord]:
        start = entry_at or (datetime.now(timezone.utc) - timedelta(days=1))
        end = exit_at or datetime.now(timezone.utc)
        result = await self.session.execute(
            select(PriceSnapshotRecord)
            .where(
                PriceSnapshotRecord.chain == chain,
                PriceSnapshotRecord.token_address == token_address,
                PriceSnapshotRecord.captured_at >= start,
                PriceSnapshotRecord.captured_at <= end,
            )
            .order_by(PriceSnapshotRecord.captured_at.asc())
        )
        return list(result.scalars().all())

    def _simulate_trade(self, trade: TokenLifecycleRecord, snapshots: list[PriceSnapshotRecord], cfg: BacktestParams) -> dict[str, Any]:
        entry_price = float(trade.entry_price or 0.0)
        if entry_price <= 0:
            return {'token_address': trade.token_address, 'skipped': True, 'reason': 'missing_entry_price'}

        entry_size = float(trade.paper_size_usd or 0.0)
        if entry_size <= 0:
            entry_size = 100.0

        realized_pnl_usd = 0.0
        fees_usd = float(cfg.paper_gas_fee_usd)
        hold_minutes = 0.0
        remaining_size = entry_size
        peak_price = entry_price
        partial_done = bool(trade.partial_exit_done)
        partial_trigger_price = entry_price * (1.0 + cfg.partial_tp_pct / 100.0)
        partial_fraction = max(min(cfg.partial_tp_fraction, 1.0), 0.0)
        last_snapshot_time = snapshots[0].captured_at

        for snap in snapshots:
            price = float(snap.price_usd or 0.0)
            if price <= 0:
                continue
            peak_price = max(peak_price, price)
            pnl_pct = ((price - entry_price) / entry_price) * 100.0
            minutes_open = (snap.captured_at - (trade.entry_at or last_snapshot_time)).total_seconds() / 60.0
            liquidity = float(snap.liquidity_usd or 0.0)

            hold_minutes = max(hold_minutes, (snap.captured_at - (trade.entry_at or last_snapshot_time)).total_seconds() / 60.0)

            if not partial_done and price >= partial_trigger_price:
                sold_size = remaining_size * partial_fraction
                realized_pnl_usd += sold_size * pnl_pct / 100.0
                remaining_size -= sold_size
                partial_done = True
                fees_usd += float(cfg.paper_gas_fee_usd)
                continue

            if pnl_pct <= -abs(float(cfg.sl_pct)):
                realized_pnl_usd += remaining_size * pnl_pct / 100.0
                fees_usd += float(cfg.paper_gas_fee_usd)
                return self._result_row(trade, 'stop_loss', realized_pnl_usd - fees_usd, snapshots, cfg)

            if pnl_pct >= float(cfg.tp_pct):
                realized_pnl_usd += remaining_size * pnl_pct / 100.0
                fees_usd += float(cfg.paper_gas_fee_usd)
                return self._result_row(trade, 'take_profit', realized_pnl_usd - fees_usd, snapshots, cfg)

            if price > peak_price:
                peak_price = price

            drawdown_from_peak_pct = ((price - peak_price) / peak_price) * 100.0 if peak_price > 0 else 0.0
            if drawdown_from_peak_pct <= -abs(float(cfg.trailing_pct)) and pnl_pct > 0:
                realized_pnl_usd += remaining_size * pnl_pct / 100.0
                fees_usd += float(cfg.paper_gas_fee_usd)
                return self._result_row(trade, 'trailing_stop', realized_pnl_usd - fees_usd, snapshots, cfg)

            if liquidity > 0 and liquidity < float(cfg.min_liquidity_exit_usd):
                realized_pnl_usd += remaining_size * pnl_pct / 100.0
                fees_usd += float(cfg.paper_gas_fee_usd)
                return self._result_row(trade, 'liquidity_collapse', realized_pnl_usd - fees_usd, snapshots, cfg)

            if minutes_open >= float(cfg.stagnation_minutes) and pnl_pct < 0.0:
                realized_pnl_usd += remaining_size * pnl_pct / 100.0
                fees_usd += float(cfg.paper_gas_fee_usd)
                return self._result_row(trade, 'stagnation', realized_pnl_usd - fees_usd, snapshots, cfg)

        final_price = float(snapshots[-1].price_usd or entry_price)
        final_pnl_pct = ((final_price - entry_price) / entry_price) * 100.0
        realized_pnl_usd += remaining_size * final_pnl_pct / 100.0
        fees_usd += float(cfg.paper_gas_fee_usd)
        return self._result_row(trade, 'time_limit', realized_pnl_usd - fees_usd, snapshots, cfg)

    def _result_row(
        self,
        trade: TokenLifecycleRecord,
        exit_reason: str,
        net_pnl_usd: float,
        snapshots: list[PriceSnapshotRecord],
        cfg: BacktestParams,
    ) -> dict[str, Any]:
        entry_size = float(trade.paper_size_usd or 100.0)
        pnl_pct = (net_pnl_usd / entry_size) * 100.0 if entry_size > 0 else 0.0
        return {
            'chain': trade.chain,
            'token_address': trade.token_address,
            'symbol': trade.symbol,
            'strategy': trade.strategy,
            'exit_reason': exit_reason,
            'pnl_usd': round(net_pnl_usd, 4),
            'pnl_pct': round(pnl_pct, 4),
            'entry_at': trade.entry_at.isoformat() if trade.entry_at else None,
            'exit_at': trade.exit_at.isoformat() if trade.exit_at else None,
            'snapshots': len(snapshots),
            'entry_delay_seconds': trade.entry_delay_seconds,
            'graduated_at': trade.graduated_at.isoformat() if trade.graduated_at else None,
            'fees_usd': round(fees_usd, 4),
            'net_pnl_usd': round(net_pnl_usd, 4),
            'hold_minutes': round(hold_minutes, 2),
        }

    def _summarize(self, simulations: list[dict[str, Any]], cfg: BacktestParams, days: int) -> dict[str, Any]:
        if not simulations:
            return {'days': days, 'trades': 0, 'results': [], 'win_rate': 0.0, 'avg_pnl_pct': 0.0, 'total_pnl_usd': 0.0, 'total_fees_usd': 0.0, 'avg_hold_minutes': 0.0}
        wins = [r for r in simulations if float(r.get('pnl_pct') or 0.0) > 0]
        pnl_values = [float(r.get('pnl_pct') or 0.0) for r in simulations]
        usd_values = [float(r.get('pnl_usd') or 0.0) for r in simulations]
        fees_values = [float(r.get('fees_usd') or 0.0) for r in simulations]
        hold_values = [float(r.get('hold_minutes') or 0.0) for r in simulations]
        return {
            'days': days,
            'trades': len(simulations),
            'win_rate': round(len(wins) / len(simulations), 4),
            'avg_pnl_pct': round(sum(pnl_values) / len(pnl_values), 4),
            'median_pnl_pct': round(sorted(pnl_values)[len(pnl_values) // 2], 4),
            'total_pnl_usd': round(sum(usd_values), 4),
            'total_fees_usd': round(sum(fees_values), 4),
            'avg_hold_minutes': round(sum(hold_values) / len(hold_values), 2) if hold_values else 0.0,
            'params': cfg.__dict__,
            'results': simulations,
        }

    @staticmethod
    def _merge_params(params: dict[str, Any]) -> BacktestParams:
        defaults = BacktestParams()
        payload = defaults.__dict__.copy()
        for key, value in params.items():
            if key in payload and value is not None:
                payload[key] = value
        return BacktestParams(**payload)
