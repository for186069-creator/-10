
from __future__ import annotations

import json
import re

from app.core.config import settings
from dataclasses import dataclass
from difflib import SequenceMatcher
from pathlib import Path

from app.models.token import TokenCandidate


@dataclass(slots=True)
class BlacklistDecision:
    blacklisted: bool
    reason: str | None = None


class PulseBlacklistStore:
    def __init__(self, storage_path: Path | None = None) -> None:
        self.storage_path = storage_path or Path(__file__).resolve().parents[3] / "data" / "pulse_blacklist.json"
        self.storage_path.parent.mkdir(parents=True, exist_ok=True)

    def _split(self, value: str | None) -> set[str]:
        if not value:
            return set()
        return {part.strip().lower() for part in re.split(r"[;,]+", value) if part.strip()}

    def _load_file(self) -> dict[str, list[str]]:
        try:
            if self.storage_path.exists():
                data = json.loads(self.storage_path.read_text(encoding="utf-8"))
                if isinstance(data, dict):
                    return {
                        "deployers": [str(x).strip().lower() for x in data.get("deployers", []) if str(x).strip()],
                        "families": [str(x).strip().lower() for x in data.get("families", []) if str(x).strip()],
                        "patterns": [str(x).strip().lower() for x in data.get("patterns", []) if str(x).strip()],
                    }
        except Exception:
            pass
        return {"deployers": [], "families": [], "patterns": []}

    def _save_file(self, data: dict[str, list[str]]) -> None:
        try:
            payload = {
                "deployers": sorted(set(data.get("deployers", []))),
                "families": sorted(set(data.get("families", []))),
                "patterns": sorted(set(data.get("patterns", []))),
            }
            self.storage_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
        except Exception:
            pass

    def _blob(self, candidate: TokenCandidate) -> tuple[str, str, str, str, str]:
        deployer = str(
            getattr(candidate, "deployer_address", None)
            or (candidate.raw or {}).get("deployer_address")
            or (candidate.raw or {}).get("creator_address")
            or (candidate.raw or {}).get("creator")
            or ""
        ).strip().lower()
        family = str((candidate.raw or {}).get("token_family") or (candidate.raw or {}).get("launchpad") or "").strip().lower()
        name = str(getattr(candidate, "name", "") or "").strip().lower()
        symbol = str(getattr(candidate, "symbol", "") or "").strip().lower()
        blob = " ".join([deployer, family, name, symbol]).strip()
        return deployer, family, name, symbol, blob

    def match(self, candidate: TokenCandidate) -> BlacklistDecision:
        deployer, family, name, symbol, blob = self._blob(candidate)
        env_deployers = self._split(settings.paper_blacklist_deployers or None)
        env_families = self._split(settings.paper_blacklist_token_families or None)
        env_patterns = [p.strip().lower() for p in re.split(r"[;,]+", settings.paper_blacklist_patterns or "") if p.strip()]
        stored = self._load_file()
        threshold = float(settings.paper_blacklist_similarity_threshold or 0.86)

        if deployer and (deployer in env_deployers or deployer in stored["deployers"]):
            return BlacklistDecision(True, "deployer_blacklisted")
        if family and (family in env_families or family in stored["families"]):
            return BlacklistDecision(True, "family_blacklisted")

        for pat in list(env_patterns) + list(stored["patterns"]):
            if not pat:
                continue
            if pat in blob:
                self.remember(candidate, pat)
                return BlacklistDecision(True, f"pattern_blacklisted:{pat}")
            for probe in (name, symbol, family, deployer, blob):
                if probe and SequenceMatcher(None, pat, probe).ratio() >= threshold:
                    self.remember(candidate, pat)
                    return BlacklistDecision(True, f"similarity_blacklisted:{pat}")
        return BlacklistDecision(False, None)

    def remember(self, candidate: TokenCandidate, token: str) -> None:
        deployer, family, _, _, blob = self._blob(candidate)
        stored = self._load_file()
        if deployer:
            stored["deployers"].append(deployer)
        if family:
            stored["families"].append(family)
        if token:
            stored["patterns"].append(token.strip().lower())
        if blob:
            stored["patterns"].append(blob[:160].strip().lower())
        self._save_file(stored)
