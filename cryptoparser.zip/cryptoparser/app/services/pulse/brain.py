
from __future__ import annotations

import logging

from dataclasses import dataclass, field
from typing import Any

from app.core.config import settings
from app.models.token import BehaviorProfile, SecurityReport, SocialProfile, TokenCandidate, WebsiteProfile
from app.services.decay_engine import analyze_decay
from app.services.momentum_tracker import MomentumTracker
from app.services.pulse.mfv_confirmation import MFVConfirmationLayer, MFVConfirmationResult


def _clamp(value: float, minimum: float = 0.0, maximum: float = 1.0) -> float:
    return max(minimum, min(maximum, value))


logger = logging.getLogger(__name__)


def _pair_from_candidate(candidate: TokenCandidate) -> dict[str, Any]:
    raw = candidate.raw or {}
    pair = raw.get('pair')
    return pair if isinstance(pair, dict) else {}


def _safe_float(value: Any, default: float = 0.0) -> float:
    try:
        if value is None or value == '':
            return float(default)
        return float(value)
    except Exception:
        return float(default)


def _price_change_score(pair: dict[str, Any]) -> tuple[float, list[str]]:
    changes = pair.get('priceChange') or {}
    if not isinstance(changes, dict):
        changes = {}
    m5 = _safe_float(changes.get('m5'))
    h1 = _safe_float(changes.get('h1'))
    h6 = _safe_float(changes.get('h6'))
    h24 = _safe_float(changes.get('h24'))
    weighted = (m5 * 0.20) + (h1 * 0.35) + (h6 * 0.25) + (h24 * 0.20)
    score = _clamp((weighted + 25.0) / 60.0)
    reasons = [
        f'price_change_m5={m5:.2f}',
        f'price_change_h1={h1:.2f}',
        f'price_change_h6={h6:.2f}',
        f'price_change_h24={h24:.2f}',
    ]
    if h1 > 0 and h6 > 0:
        reasons.append('price_momentum_positive' if h1 >= h6 * 0.25 else 'price_momentum_fading')
    return score, reasons


def _onchain_flow_score(candidate: TokenCandidate, security: SecurityReport) -> tuple[float, list[str]]:
    pair = _pair_from_candidate(candidate)
    txns = pair.get('txns') if isinstance(pair.get('txns'), dict) else {}
    buys_5m = _safe_float((txns.get('m5') or {}).get('buys'))
    sells_5m = _safe_float((txns.get('m5') or {}).get('sells'))
    buys_h1 = _safe_float((txns.get('h1') or {}).get('buys'))
    sells_h1 = _safe_float((txns.get('h1') or {}).get('sells'))
    buys_total = buys_5m + buys_h1
    sells_total = sells_5m + sells_h1
    buy_pressure = buys_total / max(1.0, buys_total + sells_total)
    trade_intensity = min(1.0, (buys_total + sells_total) / 200.0)
    holder_base = _safe_float(candidate.holders, 0.0)
    holder_component = _clamp(holder_base / 500.0)
    liquidity = _safe_float(candidate.liquidity_usd, 0.0)
    liq_component = _clamp(liquidity / 100_000.0)
    top10 = _safe_float(security.top10_holder_pct, 0.0)
    concentration_penalty = 0.0
    if top10 > 35.0:
        concentration_penalty = min(0.35, (top10 - 35.0) / 100.0)
    score = _clamp(
        (buy_pressure * 0.40)
        + (trade_intensity * 0.20)
        + (holder_component * 0.20)
        + (liq_component * 0.20)
        - concentration_penalty
    )
    reasons = [
        f'buy_pressure={buy_pressure:.4f}',
        f'trade_intensity={trade_intensity:.4f}',
        f'holder_component={holder_component:.4f}',
        f'liquidity_component={liq_component:.4f}',
    ]
    if buys_total > sells_total:
        reasons.append('buy_flow_positive')
    if concentration_penalty > 0:
        reasons.append('holder_concentration_penalty')
    return score, reasons


def _wallet_trust_score(candidate: TokenCandidate, security: SecurityReport) -> tuple[float, list[str]]:
    wallet_rep = _safe_float(security.creator_wallet_reputation, 50.0)
    raw = candidate.raw or {}
    extra = _safe_float(raw.get('wallet_reputation') or raw.get('wallet_reputation_score') or raw.get('dev_wallet_reputation'), 50.0)
    score = _clamp(((wallet_rep * 0.7) + (extra * 0.3)) / 100.0)
    reasons = [f'wallet_rep={wallet_rep:.2f}', f'wallet_rep_extra={extra:.2f}']
    if score >= 0.75:
        reasons.append('wallet_trust_high')
    elif score <= 0.40:
        reasons.append('wallet_trust_low')
    return score, reasons


def _multi_timeframe_momentum_score(candidate: TokenCandidate) -> tuple[float, list[str]]:
    pair = _pair_from_candidate(candidate)
    changes = pair.get('priceChange') or {}
    if not isinstance(changes, dict):
        changes = {}
    m5 = _safe_float(changes.get('m5'))
    m15 = _safe_float(changes.get('m15'))
    h1 = _safe_float(changes.get('h1'))
    h6 = _safe_float(changes.get('h6'))
    h24 = _safe_float(changes.get('h24'))
    weighted = (m5 * 0.15) + (m15 * 0.15) + (h1 * 0.30) + (h6 * 0.25) + (h24 * 0.15)
    score = _clamp((weighted + 30.0) / 70.0)
    reasons = [
        f'mtf_m5={m5:.2f}',
        f'mtf_m15={m15:.2f}',
        f'mtf_h1={h1:.2f}',
        f'mtf_h6={h6:.2f}',
        f'mtf_h24={h24:.2f}',
    ]
    if m5 > 0 and h1 > 0:
        reasons.append('mtf_momentum_aligned')
    elif m5 < 0 and h1 > 0:
        reasons.append('mtf_fake_breakout_risk')
    return score, reasons


@dataclass
class BrainResult:
    continuation_score: float
    survival_score: float
    momentum_score: float
    quality_score: float
    decay_penalty: float
    strategy_hint: str
    confidence: float
    ml_score: float = 0.0
    onchain_score: float = 0.0
    wallet_score: float = 0.0
    multi_timeframe_momentum_score: float = 0.0
    confirmation_score: float = 0.0
    post_fzr_momentum_score: float = 0.0
    volume_expansion_score: float = 0.0
    liquidity_flow_score: float = 0.0
    confirmation_multiplier: float = 1.0
    confirmation_reasons: list[str] = field(default_factory=list)
    signals: list[str] = field(default_factory=list)
    breakdown: dict[str, float] = field(default_factory=dict)


class PulseBrain:
    def __init__(self) -> None:
        self.confirmation_layer = MFVConfirmationLayer()

    def analyze(
        self,
        candidate: TokenCandidate,
        security: SecurityReport,
        social: SocialProfile,
        website: WebsiteProfile,
        behavior: BehaviorProfile | None,
        bundle_data: dict[str, Any] | None,
        pattern_context: dict[str, Any] | None = None,
        decision_profile: str = '',
    ) -> BrainResult:
        signals: list[str] = []

        liquidity = float(candidate.liquidity_usd or 0.0)
        holders = int(candidate.holders or 0)
        top10_holder_pct = float(security.top10_holder_pct or 0.0)

        survival_score = 0.5
        if liquidity >= 50_000:
            survival_score += 0.15
            signals.append('survival_liquidity_strong')
        elif liquidity >= 10_000:
            survival_score += 0.10
            signals.append('survival_liquidity_ok')
        if holders >= 500:
            survival_score += 0.10
            signals.append('survival_holders_strong')
        elif holders >= 200:
            survival_score += 0.05
            signals.append('survival_holders_ok')
        if social.exists is True:
            survival_score += 0.10
            signals.append('social_exists')
        if website.exists is True:
            survival_score += 0.05
            signals.append('website_exists')
        if security.mint_authority_none is False:
            survival_score -= 0.20
            signals.append('mint_authority_exists')
        if security.freeze_authority_none is False:
            survival_score -= 0.20
            signals.append('freeze_authority_exists')
        if top10_holder_pct > 50:
            survival_score -= 0.15
            signals.append('top10_holder_concentration')
        survival_score = _clamp(survival_score)

        momentum_result = MomentumTracker().analyze(candidate)
        momentum_score = _clamp((float(momentum_result.score) + 30.0) / 70.0)
        signals.extend(momentum_result.reasons)

        decay = analyze_decay(candidate)
        decay_penalty = _clamp(float(decay.penalty) / 50.0)
        signals.extend(decay.reasons)

        pair = _pair_from_candidate(candidate)
        volume_1h = float((pair.get('volume') or {}).get('h1') or candidate.raw.get('volume_h1') or 0.0)
        volume_6h = float((pair.get('volume') or {}).get('h6') or candidate.raw.get('volume_h6') or 0.0)
        volume_24h = float((pair.get('volume') or {}).get('h24') or candidate.raw.get('volume_h24') or 0.0)
        market_cap = float(candidate.market_cap_usd or pair.get('marketCap') or pair.get('fdv') or 0.0)
        volume_ratio = (volume_1h / market_cap) if market_cap > 0 else 0.0

        mtf_momentum_score, mtf_reasons = _multi_timeframe_momentum_score(candidate)
        onchain_score, onchain_reasons = _onchain_flow_score(candidate, security)
        wallet_score, wallet_reasons = _wallet_trust_score(candidate, security)

        # Pre-graduation wallet_rep boost: якщо trusted dev був виявлений ДО graduation
        _pre_grad_wr = float((candidate.raw or {}).get('pre_grad_wallet_rep') or 0)
        if _pre_grad_wr >= 70 and wallet_score < 0.70:
            wallet_score = max(wallet_score, _pre_grad_wr / 100.0)
            wallet_reasons.append(f'pre_grad_wallet_rep={_pre_grad_wr:.0f}')

        signals.extend(mtf_reasons)
        signals.extend(onchain_reasons)
        signals.extend(wallet_reasons)

        quality_score = 0.5
        is_evm = candidate.chain.value in {'ethereum', 'base', 'bsc'}
        if is_evm and security.renounced is True:
            quality_score += 0.10
            signals.append('contract_renounced')
        if is_evm and security.lp_locked_days is not None and int(security.lp_locked_days) >= 180:
            quality_score += 0.10
            signals.append('lp_locked_180d')
        if social.followers is not None and int(social.followers) >= 1000:
            quality_score += 0.15
            signals.append('social_followers_strong')
        if social.account_age_days is not None and int(social.account_age_days) >= 30:
            quality_score += 0.05
            signals.append('social_account_mature')
        if website.domain_age_days is not None and int(website.domain_age_days) >= 30:
            quality_score += 0.05
            signals.append('domain_mature')
        if security.creator_wallet_reputation is not None and float(security.creator_wallet_reputation) >= 70:
            quality_score += 0.10
            signals.append('creator_reputation_strong')
        if security.wash_trading_risk is not None and float(security.wash_trading_risk) >= 0.7:
            quality_score -= 0.20
            signals.append('wash_trading_risk')
        if behavior and behavior.suspicious is True:
            quality_score -= 0.15
            signals.append('behavior_suspicious')
        if market_cap > 0 and volume_ratio >= float(settings.pulse_volume_min_ratio):
            momentum_score = _clamp(momentum_score + float(settings.pulse_volume_momentum_bonus))
            quality_score = _clamp(quality_score + float(settings.pulse_volume_accumulation_bonus))
            signals.append('volume_spike_to_mcap')
        elif volume_1h > 0 and volume_6h > 0 and volume_1h >= (volume_6h / 6.0):
            momentum_score = _clamp(momentum_score + 0.05)
            signals.append('volume_accumulation')
        if mtf_momentum_score >= 0.70:
            momentum_score = _clamp(momentum_score + 0.07)
            signals.append('mtf_momentum_strong')
        if onchain_score >= 0.70:
            quality_score = _clamp(quality_score + 0.05)
            signals.append('onchain_strength')
        signals.extend([
            f'volume_1h={volume_1h:.2f}',
            f'volume_6h={volume_6h:.2f}',
            f'volume_24h={volume_24h:.2f}',
            f'volume_ratio={volume_ratio:.4f}',
        ])
        quality_score = _clamp(quality_score)

        raw = (
            survival_score * 0.32
            + momentum_score * 0.20
            + quality_score * 0.18
            + (1.0 - decay_penalty) * 0.08
            + mtf_momentum_score * 0.10
            + onchain_score * 0.06
            + wallet_score * 0.06
        )
        continuation_score = _clamp(raw)

        ml_score = _clamp(
            continuation_score * 0.34
            + survival_score * 0.12
            + quality_score * 0.12
            + momentum_score * 0.12
            + mtf_momentum_score * 0.12
            + onchain_score * 0.10
            + wallet_score * 0.08
        )

        pattern_context = pattern_context or {}
        abc_confirmed = bool(pattern_context.get('mfv_confirmed', pattern_context.get('abc_confirmed')))
        abc_confidence = float(pattern_context.get('mfv_confidence', pattern_context.get('abc_confidence') or 0.0))
        mfv_phase = str(pattern_context.get('mfv_phase', pattern_context.get('abc_phase') or 'unknown')).lower().strip()
        mfv_rr = float(pattern_context.get('mfv_rr', pattern_context.get('abc_rr') or 0.0))
        confirmation_result = MFVConfirmationResult()
        if abc_confirmed:
            confirmation_result = self.confirmation_layer.evaluate(
                candidate=candidate,
                security=security,
                pattern_context=pattern_context,
                momentum_score=momentum_score,
                mtf_momentum_score=mtf_momentum_score,
                onchain_score=onchain_score,
                wallet_score=wallet_score,
                liquidity=liquidity,
                market_cap=market_cap,
                volume_1h=volume_1h,
                volume_6h=volume_6h,
                volume_24h=volume_24h,
            )
            signals.extend(confirmation_result.reasons)
            signals.append(f'mfv_confirmed_conf={abc_confidence:.2f}')
            signals.append(f'mfv_phase={mfv_phase}')
            signals.append(f'mfv_rr={mfv_rr:.2f}')
            signals.append('mfv_structure_aligned')
            if confirmation_result.confirmed:
                signals.append('mfv_confirmation_passed')
                abc_boost = min(0.12, 0.03 + (abc_confidence * 0.03) + min(mfv_rr, 5.0) * 0.01 + confirmation_result.composite_score * 0.05)
                continuation_score = _clamp(continuation_score + abc_boost)
                ml_score = _clamp(ml_score + abc_boost * 0.5)
                if confirmation_result.composite_score >= 0.70:
                    signals.append('mfv_confirmation_strong')
            else:
                signals.append('mfv_confirmation_soft')

        bundle_data = bundle_data or {}
        bundle_severity = str(bundle_data.get('bundle_severity') or bundle_data.get('severity') or 'none').lower()
        bundle_supply_percent = float(
            bundle_data.get('bundle_supply_percent')
            or bundle_data.get('bundle_supply_pct')
            or bundle_data.get('supply_percent')
            or 0.0
        )

        # Balanced strategy router: survival and smart_wallet remain comparable,
        # but confirmed MFV and graduated candidates should bias toward survival.
        strategy_hint = 'skip'
        strategy_scores = {
            'survival': 0.0,
            'smart_wallet': 0.0,
            'farm': 0.0,
        }
        base_quality = max(continuation_score, survival_score, momentum_score, ml_score)
        mfv_bonus = 0.0
        if abc_confirmed:
            mfv_bonus += min(0.12, 0.03 + (abc_confidence * 0.03) + min(mfv_rr, 5.0) * 0.01)
        if confirmation_result.confirmed:
            mfv_bonus += min(0.08, confirmation_result.composite_score * 0.04)
        strategy_scores['survival'] = (
            continuation_score * 0.36
            + survival_score * 0.30
            + ml_score * 0.16
            + mtf_momentum_score * 0.11
            + min(liquidity / 250_000.0, 1.0) * 0.06
            + mfv_bonus
        )
        strategy_scores['smart_wallet'] = (
            momentum_score * 0.24
            + mtf_momentum_score * 0.24
            + onchain_score * 0.14
            + wallet_score * 0.08
            + ml_score * 0.06
            + mfv_bonus * 0.70
        )
        strategy_scores['farm'] = (
            continuation_score * 0.22
            + survival_score * 0.16
            + ml_score * 0.10
            + (0.20 if bundle_severity in ('medium', 'high') and bundle_supply_percent < 20 else 0.0)
            + (0.08 if bundle_severity in ('medium', 'high') else 0.0)
            + mfv_bonus
        )

        # Explicit hard preference for farm only when bundle evidence is strong;
        # otherwise choose the highest score among survival / smart_wallet.
        if confirmation_result.confirmed and mfv_phase in {'entry_ready', 'fzr_confirmed'}:
            strategy_scores['survival'] += min(0.12, 0.05 + confirmation_result.composite_score * 0.06)
            strategy_scores['smart_wallet'] -= 0.05
        if decision_profile == 'pump_graduated':
            strategy_scores['survival'] += 0.08
            strategy_scores['smart_wallet'] -= 0.08
            if strategy_scores['survival'] >= strategy_scores['smart_wallet'] - 0.08:
                strategy_scores['survival'] += 0.04
        if bundle_severity in ('medium', 'high') and bundle_supply_percent < 20:
            strategy_hint = 'farm'
        else:
            top_strategy = max(strategy_scores, key=strategy_scores.get)
            if top_strategy == 'survival' and abs(strategy_scores['survival'] - strategy_scores['smart_wallet']) <= 0.03:
                strategy_hint = 'smart_wallet'  # survival вимкнена
            else:
                # survival вимкнена — якщо brain вибрав survival, замінюємо на smart_wallet
                strategy_hint = top_strategy if top_strategy != 'survival' else 'smart_wallet' 

        # Strong MFV should route to survival first; smart_wallet remains a fallback only.
        if abc_confirmed and continuation_score >= 0.55 and strategy_hint != 'farm':
            if confirmation_result.confirmed and mfv_phase in {'entry_ready', 'fzr_confirmed'} and mfv_rr >= 3.0 and liquidity >= 25_000:
                strategy_hint = 'smart_wallet'  # survival вимкнена
            elif confirmation_result.composite_score >= 0.60 and mfv_phase in {'entry_ready', 'fzr_confirmed'} and mtf_momentum_score >= 0.60:
                strategy_hint = 'smart_wallet'  # survival вимкнена
            elif confirmation_result.composite_score >= 0.58:
                strategy_hint = 'farm' if bundle_severity in ('medium', 'high') else 'smart_wallet'  # survival вимкнена
            elif momentum_score >= 0.70:
                strategy_hint = 'smart_wallet'
        signals.append(f'strategy_{strategy_hint}')
        if wallet_score <= 0.35:
            signals.append('wallet_trust_low')
        if ml_score >= 0.75:
            signals.append('ml_score_strong')
        elif ml_score <= 0.40:
            signals.append('ml_score_weak')

        confidence = _clamp(min(continuation_score, survival_score, momentum_score, ml_score) * 1.2)
        logger.info(
            'brain_decision token=%s chain=%s strategy=%s continuation=%.3f survival=%.3f momentum=%.3f quality=%.3f ml=%.3f conf=%.3f abc=%s mfv_phase=%s mfv_rr=%.2f mfv_conf=%.2f confirmation=%.3f',
            candidate.token_address,
            candidate.chain.value,
            strategy_hint,
            continuation_score,
            survival_score,
            momentum_score,
            quality_score,
            ml_score,
            confidence,
            bool(abc_confirmed),
            mfv_phase,
            mfv_rr,
            abc_confidence,
            confirmation_result.composite_score,
        )
        breakdown = {
            'survival_weighted': survival_score * 0.32,
            'momentum_weighted': momentum_score * 0.20,
            'quality_weighted': quality_score * 0.18,
            'decay_weighted': (1.0 - decay_penalty) * 0.08,
            'mtf_momentum_weighted': mtf_momentum_score * 0.10,
            'onchain_weighted': onchain_score * 0.06,
            'wallet_weighted': wallet_score * 0.06,
            'confirmation_score': confirmation_result.composite_score,
            'confirmation_multiplier': confirmation_result.size_multiplier,
            'post_fzr_momentum_score': confirmation_result.post_fzr_momentum_score,
            'volume_expansion_score': confirmation_result.volume_expansion_score,
            'liquidity_flow_score': confirmation_result.liquidity_flow_score,
            'liquidity_usd': liquidity,
            'holders': float(holders),
            'top10_holder_pct': top10_holder_pct,
            'bundle_supply_percent': bundle_supply_percent,
            'volume_1h': volume_1h,
            'volume_6h': volume_6h,
            'volume_24h': volume_24h,
            'volume_ratio': volume_ratio,
            'ml_score': ml_score,
            'mtf_momentum_score': mtf_momentum_score,
            'onchain_score': onchain_score,
            'wallet_score': wallet_score,
        }
        return BrainResult(
            continuation_score=round(continuation_score, 4),
            survival_score=round(survival_score, 4),
            momentum_score=round(momentum_score, 4),
            quality_score=round(quality_score, 4),
            decay_penalty=round(decay_penalty, 4),
            strategy_hint=strategy_hint,
            confidence=round(confidence, 4),
            ml_score=round(ml_score, 4),
            onchain_score=round(onchain_score, 4),
            wallet_score=round(wallet_score, 4),
            multi_timeframe_momentum_score=round(mtf_momentum_score, 4),
            confirmation_score=round(confirmation_result.composite_score, 4),
            post_fzr_momentum_score=round(confirmation_result.post_fzr_momentum_score, 4),
            volume_expansion_score=round(confirmation_result.volume_expansion_score, 4),
            liquidity_flow_score=round(confirmation_result.liquidity_flow_score, 4),
            confirmation_multiplier=round(confirmation_result.size_multiplier, 4),
            confirmation_reasons=confirmation_result.reasons,
            signals=signals,
            breakdown={key: round(value, 4) if isinstance(value, float) else value for key, value in breakdown.items()},
        )
