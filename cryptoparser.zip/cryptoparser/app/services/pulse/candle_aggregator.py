from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable, Sequence


@dataclass(slots=True)
class PricePoint:
    timestamp: float
    price: float
    volume: float = 0.0


@dataclass(slots=True)
class Candle:
    timestamp: float
    open: float
    high: float
    low: float
    close: float
    volume: float = 0.0
    tick_count: int = 0


def candle_to_price_point(candle: Candle) -> PricePoint:
    return PricePoint(timestamp=float(candle.timestamp), price=float(candle.close), volume=float(candle.volume or 0.0))


def _floor_ts(ts: float, seconds: int) -> float:
    seconds = max(1, int(seconds or 1))
    return float(int(ts) // seconds * seconds)


def aggregate_candles(ticks: Sequence[PricePoint], seconds: int = 60) -> list[Candle]:
    if not ticks:
        return []
    ordered = sorted((t for t in ticks if t.price > 0 and t.timestamp > 0), key=lambda p: p.timestamp)
    if not ordered:
        return []

    bucket_seconds = max(1, int(seconds or 1))
    candles: list[Candle] = []
    bucket_start = _floor_ts(ordered[0].timestamp, bucket_seconds)
    bucket_ticks: list[PricePoint] = []

    def flush_bucket(start_ts: float, items: list[PricePoint]) -> None:
        if not items:
            return
        prices = [float(x.price) for x in items if x.price > 0]
        if not prices:
            return
        candles.append(
            Candle(
                timestamp=float(start_ts),
                open=float(prices[0]),
                high=float(max(prices)),
                low=float(min(prices)),
                close=float(prices[-1]),
                volume=float(sum(float(x.volume or 0.0) for x in items)),
                tick_count=len(items),
            )
        )

    for tick in ordered:
        tick_bucket = _floor_ts(tick.timestamp, bucket_seconds)
        if tick_bucket != bucket_start:
            flush_bucket(bucket_start, bucket_ticks)
            # fill gaps with flat candles so multi-TF analysis keeps continuity
            next_bucket = bucket_start + bucket_seconds
            while next_bucket < tick_bucket:
                prev_close = candles[-1].close if candles else (bucket_ticks[-1].price if bucket_ticks else tick.price)
                candles.append(
                    Candle(
                        timestamp=float(next_bucket),
                        open=float(prev_close),
                        high=float(prev_close),
                        low=float(prev_close),
                        close=float(prev_close),
                        volume=0.0,
                        tick_count=0,
                    )
                )
                next_bucket += bucket_seconds
            bucket_start = tick_bucket
            bucket_ticks = [tick]
        else:
            bucket_ticks.append(tick)

    flush_bucket(bucket_start, bucket_ticks)
    return candles


def build_multi_tf(
    ticks: Sequence[PricePoint],
    context_seconds: int = 300,
    signal_seconds: int = 60,
    entry_seconds: int = 30,
) -> tuple[list[Candle], list[Candle], list[Candle]]:
    return (
        aggregate_candles(ticks, context_seconds),
        aggregate_candles(ticks, signal_seconds),
        aggregate_candles(ticks, entry_seconds),
    )


class CandleAggregator:
    def from_snapshots(self, snapshots: Sequence[Any]) -> list[PricePoint]:
        points: list[PricePoint] = []
        for s in snapshots:
            try:
                ts = getattr(s, 'created_at_ts', None)
                if ts is None:
                    created_at = getattr(s, 'created_at', None) or getattr(s, 'captured_at', None)
                    if hasattr(created_at, 'timestamp'):
                        ts = created_at.timestamp()
                    elif isinstance(created_at, str):
                        from datetime import datetime
                        try:
                            ts = datetime.fromisoformat(created_at).timestamp()
                        except Exception:
                            ts = 0.0
                    else:
                        ts = created_at
                ts_f = float(ts or 0.0)
                price = getattr(s, 'price', None)
                if price is None:
                    price = getattr(s, 'price_usd', 0.0)
                price_f = float(price or 0.0)
                vol = getattr(s, 'volume', None)
                if vol is None:
                    vol = getattr(s, 'volume_usd', 0.0)
                vol_f = float(vol or 0.0)
                if ts_f > 0 and price_f > 0:
                    points.append(PricePoint(timestamp=ts_f, price=price_f, volume=vol_f))
            except Exception:
                continue
        points.sort(key=lambda p: p.timestamp)
        return points
