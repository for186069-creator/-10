# app/services/pulse/decision_engine.py
# PULSE — sole decision maker.
# Valid outputs: APPROVE | FARM_APPROVE | REJECT
from __future__ import annotations
from dataclasses import dataclass, field

from app.core.config import settings

# Score weights read from settings (backed by .env via pydantic-settings)
W_RISK   = settings.pulse_w_risk
W_CONT   = settings.pulse_w_continuation
W_WALLET = settings.pulse_w_wallet
W_BUNDLE = settings.pulse_w_bundle


@dataclass
class SignalBundle:
    mint:                   str
    symbol:                 str   = ''
    current_price:          float = 0.0
    risk_score:             float = 0.0          # blended risk score 0–100
    risk_flags:             dict  = field(default_factory=dict)
    continuation_score:     float = 0.5          # 0–1
    continuation_available: bool  = False
    wallet_score:           float = 0.5          # 0–1
    wallet_available:       bool  = False
    bundle_score:           float = 0.5          # 0–1
    bundle_detected:        bool  = False
    liquidity_usd:          float = 0.0


@dataclass
class DecisionResult:
    mint:             str
    symbol:           str
    decision:         str          # "APPROVE" | "FARM_APPROVE" | "REJECT"
    final_score:      float
    paper_usd:        float = 0.0
    rejection_reasons: list = field(default_factory=list)
    trade_ready:      bool = False
    trade_ready_score: float = 0.0
    trade_ready_reason: str = ''
    evidence:         dict = field(default_factory=dict)


class DecisionEngine:
    """
    PULSE decision engine — receives a clean SignalBundle and returns
    APPROVE / FARM_APPROVE / REJECT.

    Thresholds are read DYNAMICALLY inside evaluate() so that .env changes
    (or test overrides) take effect without restarting Python.
    """

    def evaluate(self, s: SignalBundle) -> DecisionResult:
        # Read thresholds from settings (backed by .env via pydantic-settings)
        th_approve     = settings.pulse_threshold_approve
        th_trade_ready = settings.pulse_threshold_trade_ready
        th_farm        = settings.pulse_threshold_farm_approve

        risk_component = min(max(float(s.risk_score or 0), 0), 100) / 100.0

        # Neutral fallback when signal is unavailable
        cont_norm   = float(s.continuation_score) if s.continuation_available else 0.5
        wallet_norm = float(s.wallet_score)        if s.wallet_available       else 0.5
        bundle_norm = float(s.bundle_score)        if s.bundle_detected        else 0.5

        composite = round(
            W_RISK   * risk_component +
            W_CONT   * cont_norm      +
            W_WALLET * wallet_norm    +
            W_BUNDLE * bundle_norm,
            4,
        )

        # Для pump_graduated без bundle — composite структурно не може досягти 0.75
        # (bundle_norm=0.5 neutral відтягує weighted average)
        # Graduated = підтверджені liquidity+volume на Raydium = достатній сигнал
        _grad_override = (
            not s.bundle_detected
            and float(s.risk_score or 0) >= 75.0
            and float(s.continuation_score or 0) >= 0.45
            and composite >= th_approve
        )
        if _grad_override:
            trade_ready = True
            trade_ready_reason = f'graduated_composite_ok:{composite:.4f}>={th_approve:.4f}'
        elif composite >= th_approve:
            # If composite already above approve threshold, treat as trade_ready
            # (avoids silently blocking approved tokens that have composite just above threshold)
            trade_ready = True
            trade_ready_reason = f'composite_trade_ready:{composite:.4f}>={th_approve:.4f}'
        else:
            trade_ready = composite >= th_trade_ready
            trade_ready_reason = (
                'composite_trade_ready'
                if trade_ready
                else f'composite_below_trade_ready:{composite:.4f}<{th_trade_ready:.4f}'
            )

        evidence = {
            'decision_profile': 'standard',
            'composite': composite,
            'risk_component': round(risk_component, 4),
            'continuation_norm': round(cont_norm, 4),
            'wallet_norm': round(wallet_norm, 4),
            'bundle_norm': round(bundle_norm, 4),
            'approval_threshold': th_approve,
            'trade_ready_threshold': th_trade_ready,
            'farm_threshold': th_farm,
            'trade_ready': trade_ready,
            'trade_ready_reason': trade_ready_reason,
        }

        # FARM path: bundled buy with a good farm score
        if s.bundle_detected and s.bundle_score >= th_farm:
            farm_trade_ready = trade_ready and s.bundle_score >= th_farm
            evidence.update({
                'trade_ready': farm_trade_ready,
                'trade_ready_reason': (
                    trade_ready_reason
                    if farm_trade_ready
                    else f'farm_not_trade_ready:{composite:.4f}/{s.bundle_score:.4f}'
                ),
                'farm_bundle_score': float(s.bundle_score),
            })
            return DecisionResult(
                mint=s.mint,
                symbol=s.symbol,
                decision='FARM_APPROVE',
                final_score=composite,
                paper_usd=20.0,
                trade_ready=farm_trade_ready,
                trade_ready_score=composite,
                trade_ready_reason=evidence['trade_ready_reason'],
                evidence=evidence,
            )

        # APPROVE path
        if composite >= th_approve:
            paper = round(
                10.0 + 40.0 * (composite - th_approve) / max(1.0 - th_approve, 1e-6),
                2,
            )
            paper = min(paper, 50.0)  # cap at max
            return DecisionResult(
                mint=s.mint,
                symbol=s.symbol,
                decision='APPROVE',
                final_score=composite,
                paper_usd=paper,
                trade_ready=trade_ready,
                trade_ready_score=composite,
                trade_ready_reason=trade_ready_reason,
                evidence=evidence,
            )

        # REJECT
        evidence['trade_ready'] = False
        evidence['trade_ready_reason'] = trade_ready_reason
        return DecisionResult(
            mint=s.mint,
            symbol=s.symbol,
            decision='REJECT',
            final_score=composite,
            rejection_reasons=[f'score_too_low: {composite:.4f} < {th_approve}'],
            trade_ready=False,
            trade_ready_score=composite,
            trade_ready_reason=trade_ready_reason,
            evidence=evidence,
        )
