from __future__ import annotations

from dataclasses import dataclass
import math
import random

from app.core.config import settings


@dataclass(slots=True)
class ExecutionQuote:
    requested_size_usd: float
    filled_size_usd: float
    fill_pct: float
    executed_price: float
    latency_seconds: int
    gas_fee_usd: float
    priority_fee_usd: float
    slippage_pct: float
    spread_pct: float
    impact_pct: float
    execution_drift_pct: float
    execution_score: float
    route_used: str
    chunks: int
    failed: bool = False
    failure_reason: str | None = None


class ExecutionFailed(RuntimeError):
    def __init__(self, side: str, reason: str, quote: ExecutionQuote | None = None) -> None:
        self.side = side
        self.reason = reason
        self.quote = quote
        super().__init__(f'{side} execution failed: {reason}')


class PulseExecutionSimulator:
    """Paper-execution realism layer.

    H8 adds:
    - dynamic slippage cap
    - impact cap by liquidity
    - order splitting
    - spread simulation
    - partial fills
    - abort-on-deviation
    - failed swap simulation
    """

    def __init__(self) -> None:
        self._rng = random.Random()

    def quote(
        self,
        *,
        side: str,
        base_price: float,
        size_usd: float | None = None,
        liquidity_usd: float | None = None,
        route_used: str | None = None,
    ) -> ExecutionQuote:
        if base_price <= 0:
            raise ExecutionFailed(side, 'invalid_price')

        requested_size = max(float(size_usd if size_usd is not None else settings.paper_trading_position_size_usd), 0.0)
        if requested_size <= 0:
            raise ExecutionFailed(side, 'invalid_size')

        liquidity = float(liquidity_usd or 0.0)
        liquidity_safe = max(liquidity, 1.0)
        max_impact_pct = max(float(settings.paper_max_order_impact_pct), 0.0)
        max_effective_size = requested_size
        if liquidity > 0 and max_impact_pct > 0:
            max_effective_size = min(requested_size, liquidity * max_impact_pct)

        # Split larger orders so each chunk has a smaller footprint.
        split_count = 1
        if settings.paper_order_split_enabled and max_effective_size > 0 and liquidity > 0:
            footprint = max_effective_size / liquidity_safe
            split_count = max(1, int(math.ceil(footprint / max(max_impact_pct, 0.002))))
            split_count = min(split_count, max(int(settings.paper_order_max_splits), 1))

        # Chunks are executed sequentially with slightly different conditions.
        chunk_size = max_effective_size / split_count if split_count > 0 else max_effective_size
        total_filled = 0.0
        weighted_price = 0.0
        total_latency = 0
        total_fee = 0.0
        total_priority_fee = 0.0
        slippage_sum = 0.0
        spread_sum = 0.0
        impact_sum = 0.0
        filled_chunks = 0
        aborted = False
        fail_reason: str | None = None

        for index in range(split_count):
            chunk_requested = chunk_size if index < split_count - 1 else max(max_effective_size - chunk_size * (split_count - 1), 0.0)
            if chunk_requested <= 0:
                continue

            latency = self._latency_seconds()
            spread_pct = self._spread_pct(liquidity)
            partial_fill_pct = self._partial_fill_pct(liquidity=liquidity, size_usd=chunk_requested)
            chunk_filled = chunk_requested * partial_fill_pct
            impact_pct = (chunk_filled / liquidity_safe) * 100.0 if liquidity > 0 else 0.0
            slippage_pct = self._dynamic_slippage_pct(
                side=side,
                latency_seconds=latency,
                liquidity_usd=liquidity,
                order_size_usd=chunk_filled,
                spread_pct=spread_pct,
            )

            # A price moving beyond the allowed deviation is treated as an abort.
            actual_deviation_pct = min(100.0, (slippage_pct * 0.6) + (spread_pct * 0.4) + (impact_pct * 0.35))
            if actual_deviation_pct > float(settings.paper_price_deviation_abort_pct):
                aborted = True
                fail_reason = 'price_moved'
                break

            if self._rng.random() < self._chunk_fail_rate(liquidity, chunk_requested):
                aborted = True
                fail_reason = 'swap_failed'
                break

            # Adverse movement: entry worse, exit worse.
            market_multiplier = 1.0 + (actual_deviation_pct / 100.0) if side == 'entry' else 1.0 - (actual_deviation_pct / 100.0)
            executed_price = max(base_price * market_multiplier, 0.0)

            total_filled += chunk_filled
            weighted_price += executed_price * chunk_filled
            total_latency += latency
            base_fee = max(float(settings.paper_gas_fee_usd), 0.0)
            priority_fee = self._priority_fee_usd(
                latency_seconds=latency,
                spread_pct=spread_pct,
                impact_pct=impact_pct,
                liquidity_usd=liquidity,
            )
            total_fee += base_fee + priority_fee
            total_priority_fee += priority_fee
            slippage_sum += slippage_pct
            spread_sum += spread_pct
            impact_sum += impact_pct
            filled_chunks += 1

        if total_filled <= 0:
            latency = total_latency or self._latency_seconds()
            return ExecutionQuote(
                requested_size_usd=requested_size,
                filled_size_usd=0.0,
                fill_pct=0.0,
                executed_price=base_price,
                latency_seconds=latency,
                gas_fee_usd=0.0,
                priority_fee_usd=0.0,
                slippage_pct=0.0,
                spread_pct=0.0,
                impact_pct=0.0,
                execution_drift_pct=0.0,
                execution_score=0.0,
                route_used=route_used or self._default_route_used(split_count),
                chunks=max(split_count, 1),
                failed=True,
                failure_reason=fail_reason or 'swap_failed',
            )

        fill_pct = total_filled / requested_size if requested_size > 0 else 0.0
        avg_price = weighted_price / total_filled if total_filled > 0 else base_price
        avg_slippage = slippage_sum / filled_chunks if filled_chunks else 0.0
        avg_spread = spread_sum / filled_chunks if filled_chunks else 0.0
        avg_impact = impact_sum / filled_chunks if filled_chunks else 0.0
        route_label = route_used or self._default_route_used(split_count)
        execution_drift_pct = abs((avg_price - base_price) / base_price) * 100.0 if base_price > 0 else 0.0
        execution_score = self._execution_score(
            fill_pct=fill_pct,
            slippage_pct=avg_slippage,
            spread_pct=avg_spread,
            impact_pct=avg_impact,
            drift_pct=execution_drift_pct,
            latency_seconds=max(total_latency, 0),
        )

        return ExecutionQuote(
            requested_size_usd=requested_size,
            filled_size_usd=total_filled,
            fill_pct=fill_pct,
            executed_price=avg_price,
            latency_seconds=max(total_latency, 0),
            gas_fee_usd=total_fee,
            priority_fee_usd=total_priority_fee,
            slippage_pct=avg_slippage,
            spread_pct=avg_spread,
            impact_pct=avg_impact,
            execution_drift_pct=execution_drift_pct,
            execution_score=execution_score,
            route_used=route_label,
            chunks=max(split_count, 1),
            failed=False,
            failure_reason='partial_fill' if fill_pct < 0.999 else None,
        )


    def _default_route_used(self, split_count: int) -> str:
        if split_count > 1:
            return f'simulated_split_route_x{split_count}'
        return 'simulated_single_route'

    def _priority_fee_usd(
        self,
        *,
        latency_seconds: int,
        spread_pct: float,
        impact_pct: float,
        liquidity_usd: float,
    ) -> float:
        base = max(float(settings.paper_gas_fee_usd), 0.0) * 0.25
        liquidity_factor = 1.0
        if liquidity_usd <= 0:
            liquidity_factor = 1.6
        elif liquidity_usd < 20_000:
            liquidity_factor = 1.35
        elif liquidity_usd > 100_000:
            liquidity_factor = 0.85
        dynamic = base * liquidity_factor
        dynamic += max(spread_pct, 0.0) * 0.004
        dynamic += max(impact_pct, 0.0) * 0.02
        dynamic += max(latency_seconds, 0) * 0.002
        return round(max(dynamic, 0.0), 6)

    def _execution_score(
        self,
        *,
        fill_pct: float,
        slippage_pct: float,
        spread_pct: float,
        impact_pct: float,
        drift_pct: float,
        latency_seconds: int,
    ) -> float:
        score = 100.0
        score -= max(0.0, (1.0 - min(max(fill_pct, 0.0), 1.0))) * 18.0
        score -= max(slippage_pct, 0.0) * 7.5
        score -= max(spread_pct, 0.0) * 5.0
        score -= max(impact_pct, 0.0) * 4.5
        score -= max(drift_pct, 0.0) * 6.5
        score -= max(latency_seconds, 0) * 0.9
        return max(0.0, min(100.0, round(score, 2)))

    def _latency_seconds(self) -> int:
        lo = max(float(settings.paper_latency_min_seconds), 0.0)
        hi = max(float(settings.paper_latency_max_seconds), lo)
        return max(0, int(round(self._rng.uniform(lo, hi))))

    def _spread_pct(self, liquidity_usd: float) -> float:
        base = self._rng.uniform(float(settings.paper_spread_min_pct), float(settings.paper_spread_max_pct))
        if liquidity_usd <= 0:
            return base * 1.8
        if liquidity_usd < 20_000:
            return base * 1.6
        if liquidity_usd < 50_000:
            return base * 1.25
        if liquidity_usd > 100_000:
            return base * 0.8
        return base

    def _partial_fill_pct(self, *, liquidity: float, size_usd: float) -> float:
        fill_floor = max(float(settings.paper_partial_fill_min_pct), 0.0)
        fill_ceiling = max(float(settings.paper_partial_fill_max_pct), fill_floor)
        if liquidity <= 0:
            fill_ceiling = min(fill_ceiling, 0.8)
        elif liquidity < 20_000:
            fill_floor = max(fill_floor, 0.75)
            fill_ceiling = min(fill_ceiling, 0.95)
        elif liquidity < 50_000:
            fill_floor = max(fill_floor, 0.88)
        elif liquidity < 100_000:
            fill_floor = max(fill_floor, 0.93)
        else:
            fill_floor = max(fill_floor, 0.96)
        raw = self._rng.uniform(fill_floor, fill_ceiling)
        # Bigger chunks are slightly less likely to fully fill.
        footprint = size_usd / max(liquidity, 1.0) if liquidity > 0 else 1.0
        penalty = min(max(footprint * 1.5, 0.0), 0.10)
        return max(min(raw - penalty, fill_ceiling), 0.0)

    def _dynamic_slippage_pct(
        self,
        *,
        side: str,
        latency_seconds: int,
        liquidity_usd: float,
        order_size_usd: float,
        spread_pct: float,
    ) -> float:
        base = 0.12 + (latency_seconds * float(settings.paper_latency_drift_per_second_pct))
        if liquidity_usd >= 100_000:
            base *= 0.4
        elif liquidity_usd >= 50_000:
            base *= 0.7
        elif 0 < liquidity_usd < 20_000:
            base *= 1.8

        impact_pct = (order_size_usd / max(liquidity_usd, 1.0)) * 100.0 if liquidity_usd > 0 else 2.0
        dynamic = base + (impact_pct * 1.5) + (spread_pct * 0.6) + self._rng.uniform(0.0, 0.25)
        if side == 'entry':
            dynamic *= 1.05
        else:
            dynamic *= 0.85
        return min(
            max(dynamic, float(settings.paper_dynamic_slippage_min_pct)),
            float(settings.paper_dynamic_slippage_max_pct),
        )

    def _chunk_fail_rate(self, liquidity: float, chunk_requested: float) -> float:
        fail_rate = float(settings.paper_fail_rate)
        if liquidity < 20_000:
            fail_rate *= 1.5
        elif liquidity > 100_000:
            fail_rate *= 0.75
        if liquidity > 0:
            footprint = chunk_requested / liquidity
            fail_rate *= 1.0 + min(max(footprint * 4.0, 0.0), 1.5)
        return min(max(fail_rate, 0.0), 0.95)
