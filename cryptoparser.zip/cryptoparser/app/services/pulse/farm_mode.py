from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.db.models import FarmPosition, RealtimeAlertRecord
from app.services.bundle_analyzer import BundleAnalysis, BundleScorer, BundleWalletMonitor
from app.utils.http import HttpClient

logger = logging.getLogger(__name__)


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _ensure_aware(value: datetime | None) -> datetime | None:
    if value is None:
        return None
    if value.tzinfo is None:
        return value.replace(tzinfo=timezone.utc)
    return value


def _rpc_url() -> str:
    urls = settings.rpc_urls_for_chain('solana')
    return urls[0] if urls else 'https://api.mainnet-beta.solana.com'


class FarmModeEngine:
    def __init__(self, session: AsyncSession | None = None, rpc_url: str | None = None):
        self.session = session
        self.scorer = BundleScorer()
        self.monitor = BundleWalletMonitor()
        self.rpc_url = rpc_url or _rpc_url()

    def should_enter(
        self,
        mint: str,
        risk_score: float,
        bundle_analysis: BundleAnalysis,
        current_price: float,
    ) -> tuple[bool, str]:
        if risk_score < float(settings.farm_mode_min_risk_score):
            return False, f'risk_score_too_low: {risk_score:.1f} < {settings.farm_mode_min_risk_score}'

        if current_price <= 0:
            return False, 'missing_current_price'

        scored = self.scorer.score(bundle_analysis)
        if not scored.farmable:
            return False, f'bundle_not_farmable: {scored.reason}'

        if scored.farm_score < float(settings.farm_mode_min_farm_score):
            return False, f'farm_score_too_low: {scored.farm_score:.2f}'

        return True, f'farm_approved: bundle_score={scored.farm_score:.2f} risk={risk_score:.1f}'

    async def open_position(
        self,
        mint: str,
        symbol: str | None,
        entry_price: float,
        bundle_analysis: BundleAnalysis,
    ) -> FarmPosition | None:
        if self.session is None:
            raise RuntimeError('FarmModeEngine.open_position requires an AsyncSession')

        existing = (
            await self.session.execute(
                select(FarmPosition).where(FarmPosition.mint == mint, FarmPosition.status == 'OPEN')
            )
        ).scalar_one_or_none()
        if existing is not None:
            return existing

        scored = self.scorer.score(bundle_analysis)
        position = FarmPosition(
            mint=mint,
            symbol=symbol,
            entry_price=entry_price,
            paper_amount_usd=float(settings.farm_mode_paper_usd),
            bundle_wallet_count=scored.wallet_count,
            bundle_pct=scored.bundle_pct,
            bundle_farm_score=scored.farm_score,
            bundle_wallets_json=json.dumps(scored.wallets),
            current_price=entry_price,
            peak_price=entry_price,
            entry_time=_utc_now(),
            last_checked=_utc_now(),
            status='OPEN',
        )
        self.session.add(position)
        self.session.add(
            RealtimeAlertRecord(
                chain='solana',
                token_address=mint,
                event_type='farm_open',
                severity='medium',
                payload={
                    'symbol': symbol,
                    'entry_price': entry_price,
                    'bundle_wallet_count': scored.wallet_count,
                    'bundle_pct': scored.bundle_pct,
                    'bundle_farm_score': scored.farm_score,
                },
            )
        )
        await self.session.flush()
        logger.info(
            'farm_position_opened mint=%s symbol=%s entry=%.8f farm_score=%.2f',
            mint,
            symbol,
            entry_price,
            scored.farm_score,
        )
        return position

    async def check_exit(self, position: FarmPosition) -> str | None:
        if self.session is None:
            raise RuntimeError('FarmModeEngine.check_exit requires an AsyncSession')

        current = float(position.current_price or 0.0)
        entry = float(position.entry_price or 0.0)
        if current <= 0 or entry <= 0:
            return None
        pnl_pct = (current - entry) / entry

        try:
            wallets = json.loads(position.bundle_wallets_json or '[]')
            if wallets:
                monitor_result = await self.monitor.check_still_holding(position.mint, wallets, self.rpc_url)
                position.bundle_sold_pct = monitor_result['sold_pct']
                position.bundle_danger = monitor_result['danger']
                await self.session.flush()
                if monitor_result['danger']:
                    return 'BUNDLE_DUMP'
        except Exception as exc:
            logger.warning('bundle_monitor_error mint=%s err=%s', position.mint, exc)

        if pnl_pct <= float(settings.farm_mode_stop_loss):
            return 'STOP_LOSS'

        if pnl_pct >= float(settings.farm_mode_take_profit):
            return 'TAKE_PROFIT'

        if position.peak_price:
            peak_pnl = (float(position.peak_price) - entry) / entry
            if peak_pnl >= float(settings.farm_mode_trailing_activate):
                trailing_sl = float(position.peak_price) * (1.0 - float(settings.farm_mode_trailing_distance))
                if current <= trailing_sl:
                    return 'TRAILING_STOP'

        entry_time = _ensure_aware(position.entry_time)
        if entry_time:
            elapsed_min = (_utc_now() - entry_time).total_seconds() / 60.0
            if elapsed_min >= int(settings.farm_mode_time_limit_minutes):
                return 'TIME_LIMIT'

        return None

    async def close_position(self, position_id: int, exit_reason: str, exit_price: float) -> FarmPosition | None:
        if self.session is None:
            raise RuntimeError('FarmModeEngine.close_position requires an AsyncSession')

        pos = (
            await self.session.execute(select(FarmPosition).where(FarmPosition.id == position_id))
        ).scalar_one_or_none()
        if not pos:
            return None

        pnl_pct = (exit_price - float(pos.entry_price)) / float(pos.entry_price) if pos.entry_price else 0.0
        pnl_usd = float(pos.paper_amount_usd or 0.0) * pnl_pct
        pos.exit_price = exit_price
        pos.exit_time = _utc_now()
        pos.exit_reason = exit_reason
        pos.pnl_pct = round(pnl_pct, 4)
        pos.pnl_usd = round(pnl_usd, 4)
        pos.current_price = exit_price
        pos.status = 'CLOSED'
        pos.last_checked = _utc_now()
        self.session.add(
            RealtimeAlertRecord(
                chain='solana',
                token_address=pos.mint,
                event_type='farm_exit',
                severity='medium',
                payload={
                    'exit_reason': exit_reason,
                    'pnl_pct': pos.pnl_pct,
                    'pnl_usd': pos.pnl_usd,
                    'exit_price': exit_price,
                },
            )
        )
        await self.session.flush()
        logger.info('farm_position_closed mint=%s reason=%s pnl=%.1f%%', pos.mint, exit_reason, pnl_pct * 100.0)
        return pos

    async def get_token_price(self, mint: str) -> float | None:
        try:
            data = await HttpClient().get_json(
                f'{settings.dexscreener_base_url.rstrip("/")}/latest/dex/tokens/{mint}',
                timeout=8,
            )
        except Exception:
            return None
        pairs = data.get('pairs') if isinstance(data, dict) else None
        if not isinstance(pairs, list) or not pairs:
            return None
        try:
            return float((pairs[0] or {}).get('priceUsd') or 0.0)
        except Exception:
            return None

    async def tick(self) -> list[dict[str, Any]]:
        if self.session is None:
            raise RuntimeError('FarmModeEngine.tick requires an AsyncSession')

        rows = list(
            (
                await self.session.execute(
                    select(FarmPosition).where(FarmPosition.status == 'OPEN').order_by(FarmPosition.entry_time.asc())
                )
            )
            .scalars()
            .all()
        )
        events: list[dict[str, Any]] = []
        for pos in rows:
            try:
                current_price = await self.get_token_price(pos.mint)
                if current_price is None or current_price <= 0:
                    continue
                pos.current_price = current_price
                pos.peak_price = max(float(pos.peak_price or current_price), current_price)
                pos.last_checked = _utc_now()
                exit_reason = await self.check_exit(pos)
                action = 'hold'
                if exit_reason:
                    await self.close_position(pos.id, exit_reason, current_price)
                    action = 'exit'
                events.append(
                    {
                        'mint': pos.mint,
                        'action': action,
                        'reason': exit_reason,
                        'pnl_pct': ((current_price - float(pos.entry_price)) / float(pos.entry_price)) * 100.0
                        if pos.entry_price
                        else 0.0,
                    }
                )
            except Exception as exc:
                logger.error('farm_tick_error mint=%s err=%s', pos.mint, exc)
                continue
        await self.session.flush()
        return events


async def run_farm_mode_tick(session_factory) -> None:
    async with session_factory() as session:
        engine = FarmModeEngine(session)
        events = await engine.tick()
        for event in events:
            logger.info(
                'farm_mode_tick event=%s mint=%s reason=%s pnl_pct=%.1f',
                event['action'],
                event['mint'],
                event['reason'],
                event.get('pnl_pct', 0.0),
            )
        await session.commit()
