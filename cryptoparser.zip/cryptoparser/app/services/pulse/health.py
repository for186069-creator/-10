from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from app.core.config import settings
from app.services.ops_alerts import OpsAlerter
from app.utils.cache import GLOBAL_CACHE


class PulseHealthMonitor:
    def __init__(self) -> None:
        self.alerts = OpsAlerter()

    @staticmethod
    def _now() -> datetime:
        return datetime.now(timezone.utc)

    async def record_tick(self) -> None:
        await GLOBAL_CACHE.set('pulse:health:last_tick_at', self._now().isoformat(), ttl_seconds=86400)

    async def record_new_token(self) -> None:
        await GLOBAL_CACHE.set('pulse:health:last_new_token_at', self._now().isoformat(), ttl_seconds=86400)

    async def record_dex_error(self, count: int = 1) -> None:
        current = await GLOBAL_CACHE.get('pulse:health:dex_error_count') or 0
        try:
            current_int = int(current)
        except Exception:
            current_int = 0
        await GLOBAL_CACHE.set('pulse:health:dex_error_count', current_int + max(1, int(count)), ttl_seconds=86400)

    async def reset_dex_errors(self) -> None:
        await GLOBAL_CACHE.set('pulse:health:dex_error_count', 0, ttl_seconds=86400)

    async def record_execution_failure(self, kind: str = 'unknown') -> None:
        key = f'pulse:health:execution_failure_count:{kind}'
        current = await GLOBAL_CACHE.get(key) or 0
        try:
            current_int = int(current)
        except Exception:
            current_int = 0
        await GLOBAL_CACHE.set(key, current_int + 1, ttl_seconds=86400)

    async def total_execution_failures(self) -> int:
        keys = [
            'pulse:health:execution_failure_count:entry',
            'pulse:health:execution_failure_count:exit',
            'pulse:health:execution_failure_count:partial_exit',
            'pulse:health:execution_failure_count:unknown',
        ]
        total = 0
        for key in keys:
            total += await self._read_int(key)
        return total

    async def reset_execution_failures(self) -> None:
        keys = [
            'pulse:health:execution_failure_count:entry',
            'pulse:health:execution_failure_count:exit',
            'pulse:health:execution_failure_count:partial_exit',
            'pulse:health:execution_failure_count:unknown',
        ]
        for key in keys:
            await GLOBAL_CACHE.set(key, 0, ttl_seconds=86400)

    async def check_and_alert(self) -> list[dict[str, Any]]:
        now = self._now()
        alerts: list[dict[str, Any]] = []

        last_tick = await self._read_dt('pulse:health:last_tick_at')
        if last_tick is None or (now - last_tick).total_seconds() >= float(settings.pulse_health_stale_tick_minutes) * 60.0:
            alerts.append({'kind': 'tick_stale', 'last_tick_at': last_tick.isoformat() if last_tick else None})

        last_new_token = await self._read_dt('pulse:health:last_new_token_at')
        if last_new_token is None or (now - last_new_token).total_seconds() >= float(settings.pulse_health_stale_new_token_minutes) * 60.0:
            alerts.append({'kind': 'new_token_stale', 'last_new_token_at': last_new_token.isoformat() if last_new_token else None})

        dex_errors = await self._read_int('pulse:health:dex_error_count')
        if dex_errors >= int(settings.pulse_health_dex_error_threshold):
            alerts.append({'kind': 'dex_errors', 'count': dex_errors})

        execution_failures = await self.total_execution_failures()
        if execution_failures >= int(settings.pulse_health_execution_failure_threshold):
            alerts.append({'kind': 'execution_failures', 'count': execution_failures})
            await self.reset_execution_failures()

        for alert in alerts:
            await self.alerts.notify_failure('pulse_health', alert['kind'], alert)
        return alerts

    async def _read_dt(self, key: str) -> datetime | None:
        value = await GLOBAL_CACHE.get(key)
        if not value:
            return None
        try:
            return datetime.fromisoformat(str(value))
        except Exception:
            return None

    async def _read_int(self, key: str) -> int:
        value = await GLOBAL_CACHE.get(key)
        try:
            return int(value or 0)
        except Exception:
            return 0
