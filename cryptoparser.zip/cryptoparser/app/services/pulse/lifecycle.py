from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.db.models import PaperTradeRecord, PriceSnapshotRecord, ReputationRecord, TokenLifecycleRecord
from app.models.token import Decision, TokenCandidate
from app.services.pulse.brain import BrainResult
from app.utils.http import HttpClient


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _ensure_aware(value: datetime | None) -> datetime | None:
    if value is None:
        return None
    if value.tzinfo is None:
        return value.replace(tzinfo=timezone.utc)
    return value


def _to_float(value: Any) -> float | None:
    try:
        if value is None or value == '':
            return None
        return float(value)
    except Exception:
        return None


def _raw_pair(candidate: TokenCandidate) -> dict[str, Any]:
    raw = candidate.raw or {}
    pair = raw.get('pair')
    if isinstance(pair, dict):
        return pair
    pairs = raw.get('pairs')
    if isinstance(pairs, list) and pairs and isinstance(pairs[0], dict):
        return pairs[0]
    return {}


def extract_price_from_candidate(candidate: TokenCandidate) -> float | None:
    raw = candidate.raw or {}
    pair = _raw_pair(candidate)
    for value in (
        raw.get('price_usd'),
        raw.get('priceUsd'),
        pair.get('priceUsd'),
        pair.get('price_usd'),
    ):
        parsed = _to_float(value)
        if parsed is not None and parsed > 0:
            return parsed
    return None


def extract_liquidity_from_candidate(candidate: TokenCandidate) -> float | None:
    if candidate.liquidity_usd is not None:
        return float(candidate.liquidity_usd)
    pair = _raw_pair(candidate)
    liquidity = pair.get('liquidity') if isinstance(pair.get('liquidity'), dict) else {}
    for value in (liquidity.get('usd'), pair.get('liquidity_usd')):
        parsed = _to_float(value)
        if parsed is not None:
            return parsed
    return None


def extract_market_cap_from_candidate(candidate: TokenCandidate) -> float | None:
    if candidate.market_cap_usd is not None:
        return float(candidate.market_cap_usd)
    pair = _raw_pair(candidate)
    for value in (pair.get('marketCap'), pair.get('fdv'), candidate.fdv_usd):
        parsed = _to_float(value)
        if parsed is not None:
            return parsed
    return None


async def fetch_price_from_dexscreener(token_address: str) -> float | None:
    try:
        data = await HttpClient().get_json(
            f'{settings.dexscreener_base_url.rstrip("/")}/latest/dex/tokens/{token_address}',
            timeout=8,
        )
        pairs = data.get('pairs') if isinstance(data, dict) else None
        if isinstance(pairs, list) and pairs:
            return _to_float((pairs[0] or {}).get('priceUsd'))
    except Exception:
        return None
    return None


def _apply_slippage(price: float | None, *, side: str, liquidity_usd: float | None = None) -> float | None:
    if price is None:
        return None
    if not settings.paper_simulate_slippage:
        return price
    pct = float(settings.paper_slippage_entry_pct if side == 'entry' else settings.paper_slippage_exit_pct)
    if liquidity_usd is not None:
        if liquidity_usd >= 100_000:
            pct = min(pct, 0.5)
        elif liquidity_usd >= 50_000:
            pct = min(pct, 1.5)
        else:
            pct = max(pct, 3.0)
    factor = 1.0 + (pct / 100.0) if side == 'entry' else 1.0 - (pct / 100.0)
    return max(price * factor, 0.0)


def _extract_graduation_timestamp(candidate: TokenCandidate) -> datetime | None:
    raw = candidate.raw or {}
    pre = raw.get('graduated_prefilter') or {}
    pair = raw.get('pair') or {}
    value = (raw.get('graduated_at') or raw.get('graduation_at') or raw.get('pair_created_at') or raw.get('pairCreatedAt') or pre.get('pair_created_at') or pre.get('pairCreatedAt') or pair.get('pairCreatedAt'))
    if value is None:
        return None
    if isinstance(value, datetime):
        return _ensure_aware(value)
    try:
        if isinstance(value, str):
            if value.isdigit():
                value = int(value)
            else:
                return _ensure_aware(datetime.fromisoformat(value.replace('Z', '+00:00')))
        ts = float(value)
        if ts > 10_000_000_000:
            ts /= 1000.0
        return datetime.fromtimestamp(ts, tz=timezone.utc)
    except Exception:
        return None


def _extract_dev_wallet(candidate: TokenCandidate, decision: Decision) -> str | None:
    evidence = (decision.evidence or {}) if isinstance(decision.evidence, dict) else {}
    for key in ('dev_wallet', 'dev_wallet_address', 'creator_wallet', 'deployer_wallet', 'funding_wallet'):
        value = evidence.get(key) or (candidate.raw or {}).get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    for key in ('funding_wallet', 'creator_address', 'deployer_address'):
        value = getattr(candidate, key, None)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return None


class LifecycleService:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def get_lifecycle(self, chain: str, token_address: str) -> TokenLifecycleRecord | None:
        result = await self.session.execute(
            select(TokenLifecycleRecord).where(
                TokenLifecycleRecord.chain == chain,
                TokenLifecycleRecord.token_address == token_address,
            )
        )
        return result.scalar_one_or_none()

    @staticmethod
    def _trade_key_from_lifecycle(lifecycle: TokenLifecycleRecord) -> str | None:
        entry_at = _ensure_aware(lifecycle.entry_at)
        exit_at = _ensure_aware(lifecycle.exit_at)
        if entry_at is None or exit_at is None:
            return None
        return f'{lifecycle.chain}:{lifecycle.token_address}:{entry_at.isoformat()}:{exit_at.isoformat()}'

    async def _persist_closed_trade(self, lifecycle: TokenLifecycleRecord) -> None:
        trade_key = self._trade_key_from_lifecycle(lifecycle)
        if not trade_key:
            return
        existing = await self.session.execute(
            select(PaperTradeRecord).where(PaperTradeRecord.trade_key == trade_key).limit(1)
        )
        if existing.scalar_one_or_none() is not None:
            return

        self.session.add(
            PaperTradeRecord(
                trade_key=trade_key,
                chain=lifecycle.chain,
                token_address=lifecycle.token_address,
                symbol=lifecycle.symbol,
                strategy=lifecycle.strategy,
                status='paper_closed',
                entry_price=lifecycle.entry_price,
                entry_execution_price=lifecycle.entry_execution_price,
                exit_price=lifecycle.exit_price,
                raw_exit_price=lifecycle.raw_exit_price,
                requested_size_usd=lifecycle.requested_size_usd,
                filled_size_usd=lifecycle.filled_size_usd,
                fill_pct=lifecycle.fill_pct,
                paper_size_usd=float(lifecycle.paper_size_usd or 0.0),
                execution_fees_usd=float(lifecycle.execution_fees_usd or 0.0),
                realized_pnl_usd=float(lifecycle.realized_pnl_usd or 0.0),
                paper_pnl_usd=float(lifecycle.paper_pnl_usd or 0.0),
                paper_pnl_pct=float(lifecycle.paper_pnl_pct or 0.0),
                entry_delay_seconds=lifecycle.entry_delay_seconds,
                entry_latency_seconds=lifecycle.entry_latency_seconds,
                exit_latency_seconds=lifecycle.exit_latency_seconds,
                graduated_at=lifecycle.graduated_at,
                entry_continuation_score=lifecycle.entry_continuation_score,
                entry_risk_score=lifecycle.entry_risk_score,
                token_family=lifecycle.token_family,
                exit_reason=lifecycle.exit_reason,
                execution_state=lifecycle.execution_state,
                pair_address=lifecycle.pair_address,
                entry_signals=lifecycle.entry_signals,
                exit_signals=lifecycle.exit_signals,
                execution_metadata=lifecycle.execution_metadata,
                lifecycle_id=lifecycle.id,
                entry_at=lifecycle.entry_at,
                exit_at=lifecycle.exit_at,
                created_at=_utc_now(),
            )
        )

    async def can_reenter(
        self,
        candidate: TokenCandidate,
        brain_result: BrainResult,
        existing: TokenLifecycleRecord | None = None,
    ) -> bool:
        if not settings.paper_reentry_enabled:
            return False
        lifecycle = existing or await self.get_lifecycle(candidate.chain.value, candidate.token_address)
        if lifecycle is None:
            return True
        if lifecycle.status != 'paper_closed':
            return False
        # Дозволяємо повторний вхід після будь-якого виходу крім явного скаму
        _blocked_exits = {'honeypot', 'scam_detected', 'blacklisted', 'rug_pull'}
        if str(lifecycle.exit_reason or '').lower() in _blocked_exits:
            return False
        if int(lifecycle.reentry_count or 0) >= int(settings.paper_reentry_max_count):
            return False
        if lifecycle.exit_at is not None:
            elapsed = (_utc_now() - _ensure_aware(lifecycle.exit_at)).total_seconds() / 60.0
            if elapsed < float(settings.paper_reentry_cooldown_minutes):
                return False
        if brain_result.continuation_score < float(settings.paper_reentry_min_continuation_score):
            return False
        liquidity = extract_liquidity_from_candidate(candidate) or float(lifecycle.current_liquidity_usd or lifecycle.entry_liquidity_usd or 0.0)
        if liquidity < float(settings.paper_reentry_min_liquidity_usd):
            return False
        return True

    async def open_position(
        self,
        candidate: TokenCandidate,
        decision: Decision,
        brain_result: BrainResult,
        bundle_data: dict | None = None,
        paper_size_usd: float = 100.0,
        requested_size_usd: float | None = None,
        filled_size_usd: float | None = None,
        fill_pct: float | None = None,
        entry_slippage_pct: float | None = None,
        entry_spread_pct: float | None = None,
        entry_impact_pct: float | None = None,
        entry_execution_drift_pct: float | None = None,
        entry_execution_score: float | None = None,
        entry_route_used: str | None = None,
        entry_priority_fee_usd: float | None = None,
        execution_price: float | None = None,
        execution_latency_seconds: int | None = None,
        execution_fee_usd: float | None = None,
        execution_state: str = 'open',
        execution_metadata: dict | None = None,
        force_bypass: bool = False,
    ) -> TokenLifecycleRecord:
        raw_entry_price = extract_price_from_candidate(candidate)
        if raw_entry_price is None:
            raw_entry_price = await fetch_price_from_dexscreener(candidate.token_address)
        if raw_entry_price is None:
            raise ValueError('entry_price_unavailable')

        now = _utc_now()
        strategy = brain_result.strategy_hint if brain_result.strategy_hint not in ('skip', None, '', 'unknown') else 'smart_wallet'
        volatility_pct = await self._recent_volatility_pct(candidate.chain.value, candidate.token_address)
        stop_loss, take_profit, trailing_stop, time_limit = self._exit_params(strategy, volatility_pct=volatility_pct)
        bundle_data = bundle_data or {}
        entry_liquidity = extract_liquidity_from_candidate(candidate)
        entry_holders = candidate.holders
        requested_size_usd = float(requested_size_usd if requested_size_usd is not None else paper_size_usd)
        actual_filled_size = float(filled_size_usd if filled_size_usd is not None else requested_size_usd)
        if actual_filled_size <= 0:
            actual_filled_size = requested_size_usd
        actual_fill_pct = float(fill_pct if fill_pct is not None else (actual_filled_size / requested_size_usd if requested_size_usd else 1.0))
        entry_execution_price = float(execution_price or _apply_slippage(raw_entry_price, side='entry', liquidity_usd=entry_liquidity) or raw_entry_price)
        entry_fee_usd = float(execution_fee_usd if execution_fee_usd is not None else settings.paper_gas_fee_usd)

        existing = await self.get_lifecycle(candidate.chain.value, candidate.token_address)
        lifecycle = existing or TokenLifecycleRecord(
            chain=candidate.chain.value,
            token_address=candidate.token_address,
            first_seen_at=candidate.first_seen_at or now,
        )
        if existing is None:
            self.session.add(lifecycle)
        elif lifecycle.status == 'paper_closed':
            lifecycle.reentry_count = int(lifecycle.reentry_count or 0) + 1

        lifecycle.symbol = candidate.symbol
        lifecycle.status = 'paper_open'
        lifecycle.strategy = strategy
        lifecycle.requested_size_usd = requested_size_usd
        lifecycle.filled_size_usd = actual_filled_size
        lifecycle.fill_pct = actual_fill_pct
        lifecycle.entry_price = entry_execution_price
        lifecycle.entry_execution_price = entry_execution_price
        lifecycle.current_price = entry_execution_price
        lifecycle.peak_price = entry_execution_price
        lifecycle.exit_price = None
        lifecycle.raw_exit_price = None
        lifecycle.entry_latency_seconds = execution_latency_seconds
        lifecycle.exit_latency_seconds = None
        lifecycle.execution_fees_usd = entry_fee_usd
        lifecycle.remaining_size_usd = actual_filled_size
        lifecycle.realized_pnl_usd = 0.0
        lifecycle.entry_liquidity_usd = entry_liquidity
        lifecycle.current_liquidity_usd = entry_liquidity
        lifecycle.peak_liquidity_usd = entry_liquidity
        lifecycle.entry_holders = entry_holders
        lifecycle.current_holders = entry_holders
        lifecycle.peak_holders = entry_holders
        lifecycle.paper_size_usd = actual_filled_size
        lifecycle.paper_pnl_usd = -entry_fee_usd
        lifecycle.paper_pnl_pct = (lifecycle.paper_pnl_usd / float(actual_filled_size)) * 100.0 if actual_filled_size else 0.0
        lifecycle.stop_loss_pct = stop_loss
        lifecycle.take_profit_pct = take_profit
        lifecycle.trailing_stop_pct = trailing_stop
        lifecycle.time_limit_minutes = time_limit
        lifecycle.exit_reason = None
        lifecycle.entry_continuation_score = brain_result.continuation_score
        lifecycle.entry_risk_score = decision.score
        lifecycle.entry_brain_strategy = brain_result.strategy_hint
        lifecycle.bundle_severity = bundle_data.get('bundle_severity') or bundle_data.get('severity')
        lifecycle.bundle_wallet_count = bundle_data.get('early_wallet_cluster_size') or bundle_data.get('wallet_count')
        lifecycle.bundle_supply_pct = (
            bundle_data.get('bundle_supply_percent')
            or bundle_data.get('bundle_supply_pct')
            or bundle_data.get('supply_percent')
        )
        lifecycle.pair_address = candidate.pair_address or ((candidate.raw or {}).get('pair') or {}).get('pairAddress')
        lifecycle.graduated_at = _extract_graduation_timestamp(candidate)
        lifecycle.entry_delay_seconds = int(max(0.0, (_utc_now() - lifecycle.graduated_at).total_seconds())) if lifecycle.graduated_at else None
        dev_wallet = _extract_dev_wallet(candidate, decision)
        lifecycle.token_family = (candidate.raw or {}).get('token_family') or (candidate.raw or {}).get('launchpad')
        lifecycle.entry_slippage_pct = entry_slippage_pct
        lifecycle.entry_spread_pct = entry_spread_pct
        lifecycle.entry_impact_pct = entry_impact_pct
        lifecycle.execution_state = execution_state
        lifecycle.execution_state_reason = 'entry_filled'
        lifecycle.execution_state_updated_at = now
        lifecycle.execution_attempts = int(lifecycle.execution_attempts or 0) + 1
        lifecycle.execution_metadata = {
            **(lifecycle.execution_metadata or {}),
            **(execution_metadata or {}),
            'requested_size_usd': requested_size_usd,
            'filled_size_usd': actual_filled_size,
            'fill_pct': actual_fill_pct,
            'entry_slippage_pct': entry_slippage_pct,
            'entry_spread_pct': entry_spread_pct,
            'entry_impact_pct': entry_impact_pct,
            'entry_execution_drift_pct': entry_execution_drift_pct,
            'entry_execution_score': entry_execution_score,
            'entry_route_used': entry_route_used,
            'entry_priority_fee_usd': entry_priority_fee_usd,
            'risk_tier': (decision.evidence or {}).get('risk_tier'),
            'safety_gate_reason': ((decision.evidence or {}).get('safety_gate') or {}).get('reason'),
            'entry_execution_price': entry_execution_price,
            'entry_latency_seconds': execution_latency_seconds,
            'entry_fee_usd': entry_fee_usd,
            'volatility_pct': volatility_pct,
        }
        lifecycle.entry_signals = {
            'risk_score': decision.score,
            'decision_status': decision.status,
            'continuation_score': brain_result.continuation_score,
            'survival_score': brain_result.survival_score,
            'momentum_score': brain_result.momentum_score,
            'strategy_hint': brain_result.strategy_hint,
            'confidence': brain_result.confidence,
            'bundle_severity': (bundle_data or {}).get('bundle_severity'),
            'bundle_supply_pct': (bundle_data or {}).get('bundle_supply_percent') or (bundle_data or {}).get('bundle_supply_pct'),
            'token_family': (candidate.raw or {}).get('token_family'),
            'pair_address': lifecycle.pair_address,
            'graduated_at': lifecycle.graduated_at.isoformat() if lifecycle.graduated_at else None,
            'minutes_since_graduation': round((_utc_now() - lifecycle.graduated_at).total_seconds() / 60.0, 2) if lifecycle.graduated_at else None,
            'volume_h1': float((((candidate.raw or {}).get('pair') or {}).get('volume', {}) or {}).get('h1') or (candidate.raw or {}).get('volume_h1') or 0.0),
            'volume_h6': float((((candidate.raw or {}).get('pair') or {}).get('volume', {}) or {}).get('h6') or (candidate.raw or {}).get('volume_h6') or 0.0),
            'volume_h24': float((((candidate.raw or {}).get('pair') or {}).get('volume', {}) or {}).get('h24') or (candidate.raw or {}).get('volume_h24') or 0.0),
            'market_cap_usd': extract_market_cap_from_candidate(candidate),
            'dev_wallet_address': dev_wallet,
            'chain': candidate.chain.value,
            'gem_score': (decision.evidence or {}).get('gem', {}).get('score'),
            'ml_risk_score': (decision.evidence or {}).get('ml_risk', {}).get('score'),
            'has_community': bool((decision.evidence or {}).get('community')),
            'decay_penalty': (decision.evidence or {}).get('decay', {}).get('penalty'),
            'entry_execution_price': entry_execution_price,
            'entry_latency_seconds': execution_latency_seconds,
            'execution_fee_usd': entry_fee_usd,
            'entry_slippage_pct': entry_slippage_pct,
            'entry_spread_pct': entry_spread_pct,
            'entry_impact_pct': entry_impact_pct,
            'entry_execution_drift_pct': entry_execution_drift_pct,
            'entry_execution_score': entry_execution_score,
            'entry_route_used': entry_route_used,
            'entry_priority_fee_usd': entry_priority_fee_usd,
            'risk_tier': (decision.evidence or {}).get('risk_tier'),
            'safety_gate_reason': ((decision.evidence or {}).get('safety_gate') or {}).get('reason'),
            'volatility_pct': volatility_pct,
            'requested_size_usd': requested_size_usd,
            'filled_size_usd': actual_filled_size,
            'fill_pct': actual_fill_pct,
        }
        lifecycle.exit_signals = None
        lifecycle.partial_exit_done = False
        lifecycle.partial_exit_pct = None
        lifecycle.entry_at = now
        lifecycle.peak_at = now
        lifecycle.exit_at = None
        lifecycle.last_checked_at = now
        lifecycle.updated_at = now

        self.session.add(
            PriceSnapshotRecord(
                chain=candidate.chain.value,
                token_address=candidate.token_address,
                price_usd=entry_execution_price,
                liquidity_usd=entry_liquidity,
                holders=entry_holders,
                market_cap_usd=extract_market_cap_from_candidate(candidate),
                source='dexscreener',
            )
        )
        await self.session.flush()
        return lifecycle

    async def update_position(

        self,
        lifecycle: TokenLifecycleRecord,
        current_price: float,
        current_liquidity: float | None = None,
        current_holders: int | None = None,
    ) -> dict:
        now = _utc_now()
        entry_price = float(lifecycle.entry_execution_price or lifecycle.entry_price or 0.0)
        if entry_price <= 0 or current_price <= 0:
            lifecycle.last_checked_at = now
            lifecycle.updated_at = now
            await self.session.flush()
            return {'action': 'hold', 'reason': None}

        remaining_size = float(lifecycle.remaining_size_usd or lifecycle.paper_size_usd or 0.0)
        realized = float(lifecycle.realized_pnl_usd or 0.0)
        fees = float(lifecycle.execution_fees_usd or 0.0)
        pnl_pct = ((current_price - entry_price) / entry_price) * 100.0
        lifecycle.current_price = current_price
        lifecycle.current_liquidity_usd = current_liquidity
        lifecycle.current_holders = current_holders
        lifecycle.last_checked_at = now
        lifecycle.updated_at = now

        if current_liquidity is not None:
            if lifecycle.peak_liquidity_usd is None or current_liquidity > float(lifecycle.peak_liquidity_usd or 0.0):
                lifecycle.peak_liquidity_usd = current_liquidity
        if current_holders is not None:
            if lifecycle.peak_holders is None or current_holders > int(lifecycle.peak_holders or 0):
                lifecycle.peak_holders = current_holders

        if pnl_pct >= float(settings.paper_partial_tp_pct) and not lifecycle.partial_exit_done:
            lifecycle.paper_pnl_usd = realized + remaining_size * (pnl_pct / 100.0) - fees
            lifecycle.paper_pnl_pct = (lifecycle.paper_pnl_usd / float(lifecycle.paper_size_usd or 1.0)) * 100.0
            await self.session.flush()
            return {
                'action': 'partial_exit',
                'reason': 'partial_take_profit',
                'fraction': float(settings.paper_partial_tp_fraction),
            }

        if pnl_pct <= float(lifecycle.stop_loss_pct or -25.0):
            lifecycle.paper_pnl_usd = realized + remaining_size * (pnl_pct / 100.0) - fees
            lifecycle.paper_pnl_pct = (lifecycle.paper_pnl_usd / float(lifecycle.paper_size_usd or 1.0)) * 100.0
            await self.session.flush()
            return {'action': 'exit', 'reason': 'stop_loss'}

        if pnl_pct >= float(lifecycle.take_profit_pct or 100.0):
            lifecycle.paper_pnl_usd = realized + remaining_size * (pnl_pct / 100.0) - fees
            lifecycle.paper_pnl_pct = (lifecycle.paper_pnl_usd / float(lifecycle.paper_size_usd or 1.0)) * 100.0
            await self.session.flush()
            return {'action': 'exit', 'reason': 'take_profit'}

        peak_price = float(lifecycle.peak_price or entry_price)
        if current_price > peak_price:
            lifecycle.peak_price = current_price
            lifecycle.peak_at = now
            peak_price = current_price

        # If position already had enough unrealized gain, do not let it revert below
        # the configured locked-profit threshold.
        peak_gain_pct = ((peak_price - entry_price) / entry_price) * 100.0 if entry_price > 0 else 0.0
        break_even_activate_pct = float(getattr(settings, 'paper_break_even_activate_pct', 0.0) or 0.0)
        break_even_lock_pct = float(getattr(settings, 'paper_break_even_lock_pct', 0.0) or 0.0)
        # Break-even lock: захищає вже зафіксований прибуток.
        # Спрацьовує ТІЛЬКИ якщо позиція вже була в плюсі на рівні lock_pct
        # (а не просто торкнулась peak >= activate і впала в мінус — це
        # звичайна волатильність, а не "втрачений прибуток").
        if break_even_activate_pct > 0 and peak_gain_pct >= break_even_activate_pct and pnl_pct <= break_even_lock_pct and pnl_pct > 0:
            lifecycle.paper_pnl_usd = realized + remaining_size * (pnl_pct / 100.0) - fees
            lifecycle.paper_pnl_pct = (lifecycle.paper_pnl_usd / float(lifecycle.paper_size_usd or 1.0)) * 100.0
            await self.session.flush()
            return {'action': 'exit', 'reason': 'break_even_lock'}

        drawdown_from_peak = ((current_price - peak_price) / peak_price) * 100.0 if peak_price > 0 else 0.0
        if drawdown_from_peak <= float(lifecycle.trailing_stop_pct or -15.0) and pnl_pct > 0:
            lifecycle.paper_pnl_usd = realized + remaining_size * (pnl_pct / 100.0) - fees
            lifecycle.paper_pnl_pct = (lifecycle.paper_pnl_usd / float(lifecycle.paper_size_usd or 1.0)) * 100.0
            await self.session.flush()
            return {'action': 'exit', 'reason': 'trailing_stop'}

        entry_at = _ensure_aware(lifecycle.entry_at) or now
        minutes_open = (now - entry_at).total_seconds() / 60.0
        if minutes_open >= float(lifecycle.time_limit_minutes or 60):
            lifecycle.paper_pnl_usd = realized + remaining_size * (pnl_pct / 100.0) - fees
            lifecycle.paper_pnl_pct = (lifecycle.paper_pnl_usd / float(lifecycle.paper_size_usd or 1.0)) * 100.0
            await self.session.flush()
            return {'action': 'exit', 'reason': 'time_limit'}

        if current_liquidity is not None and current_liquidity < float(settings.paper_min_liquidity_exit_usd):
            lifecycle.paper_pnl_usd = realized + remaining_size * (pnl_pct / 100.0) - fees
            lifecycle.paper_pnl_pct = (lifecycle.paper_pnl_usd / float(lifecycle.paper_size_usd or 1.0)) * 100.0
            await self.session.flush()
            return {'action': 'exit', 'reason': 'liquidity_collapse'}

        entry_holders = int(lifecycle.entry_holders or 0)
        if current_holders is not None and entry_holders > 0 and current_holders < entry_holders * 0.5:
            lifecycle.paper_pnl_usd = realized + remaining_size * (pnl_pct / 100.0) - fees
            lifecycle.paper_pnl_pct = (lifecycle.paper_pnl_usd / float(lifecycle.paper_size_usd or 1.0)) * 100.0
            await self.session.flush()
            return {'action': 'exit', 'reason': 'holders_dump'}

        if minutes_open >= float(settings.paper_stagnation_exit_minutes) and pnl_pct < float(settings.paper_stagnation_min_pnl_pct):
            lifecycle.paper_pnl_usd = realized + remaining_size * (pnl_pct / 100.0) - fees
            lifecycle.paper_pnl_pct = (lifecycle.paper_pnl_usd / float(lifecycle.paper_size_usd or 1.0)) * 100.0
            await self.session.flush()
            return {'action': 'exit', 'reason': 'stagnation'}

        lifecycle.paper_pnl_usd = realized + remaining_size * (pnl_pct / 100.0) - fees
        lifecycle.paper_pnl_pct = (lifecycle.paper_pnl_usd / float(lifecycle.paper_size_usd or 1.0)) * 100.0
        await self.session.flush()
        return {'action': 'hold', 'reason': None}

    async def apply_partial_exit(
        self,
        lifecycle: TokenLifecycleRecord,
        execution_price: float,
        sold_fraction: float,
        execution_latency_seconds: int | None = None,
        execution_fee_usd: float | None = None,
        exit_slippage_pct: float | None = None,
        exit_spread_pct: float | None = None,
        exit_impact_pct: float | None = None,
        exit_execution_drift_pct: float | None = None,
        exit_execution_score: float | None = None,
        exit_route_used: str | None = None,
        exit_priority_fee_usd: float | None = None,
    ) -> TokenLifecycleRecord:
        now = _utc_now()
        entry_price = float(lifecycle.entry_execution_price or lifecycle.entry_price or 0.0)
        if entry_price <= 0:
            raise ValueError('entry_price_missing')
        base_size = float(lifecycle.remaining_size_usd or lifecycle.paper_size_usd or 0.0)
        sold_fraction = max(min(float(sold_fraction), 1.0), 0.0)
        sold_size = base_size * sold_fraction
        remaining_size = max(base_size - sold_size, 0.0)
        move_pct = ((float(execution_price) - entry_price) / entry_price) * 100.0
        realized = sold_size * (move_pct / 100.0)
        lifecycle.realized_pnl_usd = float(lifecycle.realized_pnl_usd or 0.0) + realized
        lifecycle.remaining_size_usd = remaining_size
        lifecycle.partial_exit_done = True
        lifecycle.partial_exit_pct = sold_fraction * 100.0
        lifecycle.exit_latency_seconds = execution_latency_seconds
        lifecycle.execution_fees_usd = float(lifecycle.execution_fees_usd or 0.0) + float(execution_fee_usd if execution_fee_usd is not None else settings.paper_gas_fee_usd)
        lifecycle.current_price = execution_price
        lifecycle.execution_state = 'partial_exit'
        lifecycle.execution_state_reason = 'partial_take_profit'
        lifecycle.execution_state_updated_at = now
        lifecycle.execution_attempts = int(lifecycle.execution_attempts or 0) + 1
        lifecycle.exit_slippage_pct = exit_slippage_pct
        lifecycle.exit_spread_pct = exit_spread_pct
        lifecycle.exit_impact_pct = exit_impact_pct
        lifecycle.execution_metadata = {
            **(lifecycle.execution_metadata or {}),
            'partial_exit_fraction': sold_fraction,
            'partial_exit_size_usd': sold_size,
            'remaining_size_usd': remaining_size,
            'exit_slippage_pct': exit_slippage_pct,
            'exit_spread_pct': exit_spread_pct,
            'exit_impact_pct': exit_impact_pct,
            'execution_latency_seconds': execution_latency_seconds,
            'execution_fee_usd': float(execution_fee_usd if execution_fee_usd is not None else settings.paper_gas_fee_usd),
        }
        lifecycle.last_checked_at = now
        lifecycle.updated_at = now
        unrealized_remaining = remaining_size * (move_pct / 100.0)
        lifecycle.paper_pnl_usd = float(lifecycle.realized_pnl_usd or 0.0) + unrealized_remaining - float(lifecycle.execution_fees_usd or 0.0)
        lifecycle.paper_pnl_pct = (lifecycle.paper_pnl_usd / float(lifecycle.paper_size_usd or 1.0)) * 100.0
        await self.session.flush()
        return lifecycle

    async def close_position(
        self,
        lifecycle: TokenLifecycleRecord,
        exit_price: float,
        exit_reason: str,
        exit_signals: dict | None = None,
        raw_exit_price: float | None = None,
        execution_price: float | None = None,
        execution_latency_seconds: int | None = None,
        execution_fee_usd: float | None = None,
        exit_slippage_pct: float | None = None,
        exit_spread_pct: float | None = None,
        exit_impact_pct: float | None = None,
        exit_execution_drift_pct: float | None = None,
        exit_execution_score: float | None = None,
        exit_route_used: str | None = None,
        exit_priority_fee_usd: float | None = None,
    ) -> TokenLifecycleRecord:
        now = _utc_now()
        entry_price = float(lifecycle.entry_execution_price or lifecycle.entry_price or 0.0)
        raw_exit_price = exit_price if raw_exit_price is None else raw_exit_price
        exit_execution_price = float(execution_price or _apply_slippage(raw_exit_price, side='exit', liquidity_usd=float(lifecycle.current_liquidity_usd or lifecycle.entry_liquidity_usd or 0.0)) or raw_exit_price)
        pnl_pct = ((exit_execution_price - entry_price) / entry_price) * 100.0 if entry_price > 0 else 0.0
        remaining_size = float(lifecycle.remaining_size_usd or lifecycle.paper_size_usd or 0.0)
        close_fee = float(execution_fee_usd if execution_fee_usd is not None else settings.paper_gas_fee_usd)
        lifecycle.realized_pnl_usd = float(lifecycle.realized_pnl_usd or 0.0) + (remaining_size * (pnl_pct / 100.0))
        lifecycle.execution_fees_usd = float(lifecycle.execution_fees_usd or 0.0) + close_fee
        lifecycle.exit_price = exit_execution_price
        lifecycle.raw_exit_price = raw_exit_price
        lifecycle.entry_price = lifecycle.entry_execution_price or lifecycle.entry_price
        lifecycle.current_price = exit_execution_price
        lifecycle.exit_reason = exit_reason
        lifecycle.exit_at = now
        lifecycle.exit_latency_seconds = execution_latency_seconds
        lifecycle.paper_pnl_usd = float(lifecycle.realized_pnl_usd or 0.0) - float(lifecycle.execution_fees_usd or 0.0)
        lifecycle.paper_pnl_pct = (lifecycle.paper_pnl_usd / float(lifecycle.paper_size_usd or 1.0)) * 100.0 if float(lifecycle.paper_size_usd or 0.0) > 0 else 0.0
        lifecycle.status = 'paper_closed'
        lifecycle.execution_state = 'closed'
        lifecycle.execution_state_reason = exit_reason
        lifecycle.execution_state_updated_at = now
        lifecycle.execution_attempts = int(lifecycle.execution_attempts or 0) + 1
        lifecycle.exit_slippage_pct = exit_slippage_pct
        lifecycle.exit_spread_pct = exit_spread_pct
        lifecycle.exit_impact_pct = exit_impact_pct
        lifecycle.last_checked_at = now
        lifecycle.updated_at = now
        lifecycle.remaining_size_usd = 0.0
        lifecycle.execution_metadata = {
            **(lifecycle.execution_metadata or {}),
            'exit_reason': exit_reason,
            'exit_slippage_pct': exit_slippage_pct,
            'exit_spread_pct': exit_spread_pct,
            'exit_impact_pct': exit_impact_pct,
            'exit_execution_drift_pct': exit_execution_drift_pct,
            'exit_execution_score': exit_execution_score,
            'exit_route_used': exit_route_used,
            'exit_priority_fee_usd': exit_priority_fee_usd,
            'raw_exit_price': raw_exit_price,
            'execution_price': exit_execution_price,
            'execution_latency_seconds': execution_latency_seconds,
            'execution_fee_usd': close_fee,
            'execution_drift_pct': exit_execution_drift_pct,
            'execution_score': exit_execution_score,
            'route_used': exit_route_used,
            'priority_fee_usd': exit_priority_fee_usd,
        }
        lifecycle.exit_signals = exit_signals or {
            'exit_reason': exit_reason,
            'minutes_open': int(((now - (_ensure_aware(lifecycle.entry_at) or now)).total_seconds()) / 60),
            'final_pnl_pct': round(pnl_pct, 2),
            'raw_exit_price': raw_exit_price,
            'execution_price': exit_execution_price,
            'execution_latency_seconds': execution_latency_seconds,
            'execution_fee_usd': close_fee,
            'execution_drift_pct': exit_execution_drift_pct,
            'execution_score': exit_execution_score,
            'route_used': exit_route_used,
            'priority_fee_usd': exit_priority_fee_usd,
        }
        await self._persist_closed_trade(lifecycle)
        await self.session.flush()
        return lifecycle

    async def open_watching(self, candidate: TokenCandidate, skip_reason: str, entry_score: float, strategy_hint: str | None = None) -> TokenLifecycleRecord:
        now = _utc_now()
        entry_price = extract_price_from_candidate(candidate)
        if entry_price is None:
            entry_price = await fetch_price_from_dexscreener(candidate.token_address)
        entry_liquidity = extract_liquidity_from_candidate(candidate)
        existing = await self.get_lifecycle(candidate.chain.value, candidate.token_address)
        lifecycle = existing or TokenLifecycleRecord(
            chain=candidate.chain.value,
            token_address=candidate.token_address,
            first_seen_at=candidate.first_seen_at or now,
        )
        if existing is None:
            self.session.add(lifecycle)
        lifecycle.symbol = candidate.symbol
        lifecycle.status = 'watching'
        lifecycle.strategy = strategy_hint or None
        lifecycle.requested_size_usd = 0.0
        lifecycle.filled_size_usd = 0.0
        lifecycle.fill_pct = 0.0
        lifecycle.entry_price = entry_price
        lifecycle.entry_execution_price = entry_price
        lifecycle.current_price = entry_price
        lifecycle.peak_price = entry_price
        lifecycle.exit_price = None
        lifecycle.raw_exit_price = None
        lifecycle.entry_latency_seconds = 0
        lifecycle.exit_latency_seconds = None
        lifecycle.execution_fees_usd = 0.0
        lifecycle.remaining_size_usd = 0.0
        lifecycle.realized_pnl_usd = 0.0
        lifecycle.entry_liquidity_usd = entry_liquidity
        lifecycle.current_liquidity_usd = entry_liquidity
        lifecycle.peak_liquidity_usd = entry_liquidity
        lifecycle.entry_holders = candidate.holders
        lifecycle.current_holders = candidate.holders
        lifecycle.peak_holders = candidate.holders
        lifecycle.paper_size_usd = 0.0
        lifecycle.paper_pnl_usd = 0.0
        lifecycle.paper_pnl_pct = 0.0
        lifecycle.stop_loss_pct = 0.0
        lifecycle.take_profit_pct = 0.0
        lifecycle.trailing_stop_pct = 0.0
        lifecycle.time_limit_minutes = int(settings.near_miss_watch_hours * 60)
        lifecycle.exit_reason = skip_reason
        lifecycle.entry_risk_score = entry_score
        lifecycle.entry_continuation_score = min(entry_score / 100.0, 1.0) if entry_score and entry_score > 1.0 else (entry_score or 0.0)  # normalized 0-1 fallback for momentum_hint
        lifecycle.entry_brain_strategy = strategy_hint or 'smart_wallet'  # реальна стратегія, не 'watching'
        lifecycle.token_family = (candidate.raw or {}).get('token_family') or (candidate.raw or {}).get('launchpad')
        lifecycle.execution_state = 'watching'
        lifecycle.execution_state_reason = skip_reason
        lifecycle.execution_state_updated_at = now
        lifecycle.execution_attempts = int(lifecycle.execution_attempts or 0) + 1
        # Зберігаємо wallet_reputation при watching (pump_early)
        # щоб при graduation orchestrator знав про trusted dev заздалегідь
        _wallet_rep = float(
            getattr(getattr(candidate, '_security', None), 'deployer_wallet_reputation', None)
            or (candidate.raw or {}).get('wallet_reputation')
            or (candidate.raw or {}).get('dev_wallet_reputation')
            or 0
        )
        lifecycle.execution_metadata = {
            **(lifecycle.execution_metadata or {}),
            'watch_reason': skip_reason,
            'entry_score': entry_score,
            'entry_momentum_score': entry_score,  # used by fzr_fast_path in _reevaluate_watching_position
            'chain': candidate.chain.value,
            'token_family': (candidate.raw or {}).get('token_family'),
            'pre_grad_wallet_rep': _wallet_rep if _wallet_rep > 0 else None,
            'decision_profile': str((candidate.raw or {}).get('decision_profile') or candidate.lifecycle_stage or '').lower().strip() or None,
        }
        lifecycle.entry_signals = {
            'watch_reason': skip_reason,
            'entry_score': entry_score,
            'chain': candidate.chain.value,
            'token_family': (candidate.raw or {}).get('token_family'),
            'pre_grad_wallet_rep': _wallet_rep if _wallet_rep > 0 else None,
        }
        lifecycle.pair_address = (
            candidate.pair_address
            or ((candidate.raw or {}).get('pair') or {}).get('pairAddress')
            or lifecycle.pair_address  # зберігаємо якщо вже є
        )
        lifecycle.exit_signals = None
        lifecycle.entry_at = now
        lifecycle.peak_at = now
        lifecycle.exit_at = None
        lifecycle.last_checked_at = now
        lifecycle.updated_at = now
        await self.session.flush()
        return lifecycle

    async def get_open_positions(self) -> list[TokenLifecycleRecord]:
        result = await self.session.execute(
            select(TokenLifecycleRecord)
            .where(TokenLifecycleRecord.status == 'paper_open')
            .order_by(TokenLifecycleRecord.entry_at.desc())
        )
        return list(result.scalars().all())

    async def get_watching_positions(self) -> list[TokenLifecycleRecord]:
        result = await self.session.execute(
            select(TokenLifecycleRecord)
            .where(TokenLifecycleRecord.status == 'watching')
            .order_by(TokenLifecycleRecord.entry_at.desc())
        )
        return list(result.scalars().all())

    async def get_closed_trades(self, limit: int = 100) -> list[PaperTradeRecord]:
        result = await self.session.execute(
            select(PaperTradeRecord)
            .where(PaperTradeRecord.status == 'paper_closed')
            .order_by(PaperTradeRecord.exit_at.desc())
            .limit(max(1, int(limit)))
        )
        return list(result.scalars().all())

    async def get_daily_pnl(self) -> float:
        today_start = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
        result = await self.session.execute(
            select(func.sum(PaperTradeRecord.paper_pnl_usd)).where(
                PaperTradeRecord.exit_at >= today_start,
            )
        )
        return float(result.scalar() or 0.0)

    async def is_circuit_breaker_active(self) -> bool:
        if not settings.daily_loss_limit_usd:
            return False
        daily_pnl = await self.get_daily_pnl()
        return daily_pnl <= -abs(float(settings.daily_loss_limit_usd))


    async def _recent_volatility_pct(self, chain: str, token_address: str, lookback_minutes: int = 60, limit: int = 8) -> float | None:
        cutoff = _utc_now() - timedelta(minutes=max(5, int(lookback_minutes)))
        result = await self.session.execute(
            select(PriceSnapshotRecord)
            .where(
                PriceSnapshotRecord.chain == chain,
                PriceSnapshotRecord.token_address == token_address,
                PriceSnapshotRecord.captured_at >= cutoff,
                PriceSnapshotRecord.price_usd.isnot(None),
            )
            .order_by(PriceSnapshotRecord.captured_at.desc())
            .limit(max(2, int(limit)))
        )
        rows = list(result.scalars().all())
        prices = [float(row.price_usd or 0.0) for row in reversed(rows) if float(row.price_usd or 0.0) > 0]
        if len(prices) < 2:
            return None
        returns: list[float] = []
        for prev, cur in zip(prices, prices[1:]):
            if prev <= 0:
                continue
            returns.append(abs((cur - prev) / prev) * 100.0)
        if not returns:
            return None
        low = min(prices)
        high = max(prices)
        range_pct = ((high - low) / low) * 100.0 if low > 0 else 0.0
        volatility = (sum(returns) / len(returns) * 0.7) + (range_pct * 0.3)
        return round(min(max(volatility, 0.0), 25.0), 2)

    async def get_wallet_reputation_score(self, wallet_address: str | None) -> float | None:
        """Повертає reputation_score девелопера з БД (0-100). None якщо невідомий."""
        if not wallet_address:
            return None
        try:
            result = await self.session.execute(
                select(ReputationRecord)
                .where(
                    ReputationRecord.entity_type == 'wallet',
                    ReputationRecord.entity_value == wallet_address.lower().strip(),
                )
                .limit(1)
            )
            row = result.scalar_one_or_none()
            if row is None:
                return None
            return float(row.reputation_score)
        except Exception:
            return None

    async def get_consecutive_win_streak(
        self,
        chain: str | None = None,
        limit: int = 10,
    ) -> tuple[int, datetime | None]:
        """Кількість прибуткових підряд з кінця + час останнього закриття."""
        q = (
            select(PaperTradeRecord)
            .where(PaperTradeRecord.status == 'paper_closed')
        )
        if chain:
            q = q.where(PaperTradeRecord.chain == chain)
        q = q.order_by(PaperTradeRecord.exit_at.desc()).limit(max(1, int(limit)))
        result = await self.session.execute(q)
        rows = list(result.scalars().all())
        if not rows:
            return 0, None
        last_close_at: datetime | None = rows[0].exit_at
        streak = 0
        for row in rows:
            if float(row.paper_pnl_pct or 0.0) > 0:
                streak += 1
            else:
                break
        return streak, last_close_at

    async def _recent_price_momentum_pct(
        self,
        chain: str,
        token_address: str,
        lookback_minutes: int = 15,
        limit: int = 6,
    ) -> float | None:
        """% зміни ціни за останні lookback_minutes хвилин з PriceSnapshotRecord.
        
        Повертає None якщо недостатньо даних (менше 2 знімків).
        """
        since = datetime.now(timezone.utc) - timedelta(minutes=max(1, lookback_minutes))
        try:
            result = await self.session.execute(
                select(PriceSnapshotRecord)
                .where(
                    PriceSnapshotRecord.chain == chain,
                    PriceSnapshotRecord.token_address == token_address,
                    PriceSnapshotRecord.recorded_at >= since,
                )
                .order_by(PriceSnapshotRecord.recorded_at.asc())
                .limit(max(2, int(limit)))
            )
            snapshots = list(result.scalars().all())
            if len(snapshots) < 2:
                return None
            first_price = float(snapshots[0].price_usd or 0.0)
            last_price = float(snapshots[-1].price_usd or 0.0)
            if first_price <= 0:
                return None
            return round((last_price - first_price) / first_price * 100.0, 2)
        except Exception:
            return None

    async def apply_stack_addition(
        self,
        position: TokenLifecycleRecord,
        execution_price: float,
        add_size_usd: float,
        execution_latency_seconds: float = 0.0,
        execution_fee_usd: float = 0.0,
        entry_slippage_pct: float = 0.0,
        entry_spread_pct: float = 0.0,
        entry_impact_pct: float = 0.0,
        entry_execution_drift_pct: float = 0.0,
        entry_execution_score: float = 1.0,
        entry_route_used: str | None = None,
        entry_priority_fee_usd: float = 0.0,
        entry_signals: dict | None = None,
    ) -> None:
        """Додає до відкритої позиції (stacking/averaging).
        
        Перераховує середню ціну входу і збільшує filled_size_usd.
        """
        old_size = float(position.filled_size_usd or 0.0)
        old_price = float(position.entry_price or execution_price)
        new_size = old_size + add_size_usd
        if new_size > 0:
            # Зважена середня ціна входу
            new_avg_price = (old_size * old_price + add_size_usd * execution_price) / new_size
        else:
            new_avg_price = execution_price

        position.entry_price = new_avg_price
        position.filled_size_usd = new_size
        position.requested_size_usd = float(position.requested_size_usd or 0.0) + add_size_usd

        # Зберігаємо інфо про стек в entry_signals
        existing = dict(position.entry_signals or {})
        stack_history = existing.get('stack_history', [])
        stack_history.append({
            'price': execution_price,
            'size_usd': add_size_usd,
            'fee_usd': execution_fee_usd,
            'slippage_pct': entry_slippage_pct,
            'route': entry_route_used,
            **(entry_signals or {}),
        })
        existing['stack_history'] = stack_history
        existing['stack_count'] = len(stack_history)
        position.entry_signals = existing
        self.session.add(position)

    async def get_consecutive_loss_streak(

        self,
        chain: str | None = None,
        limit: int = 20,
    ) -> tuple[int, datetime | None]:
        """Повертає (кількість збиткових підряд з кінця, час останнього закриття).

        Використовується paper_trader для:
          - kill_switch: 5+ підряд збиткових → пауза 30 хв
          - entry_guard: 3+ підряд збиткових → cooldown між входами
        """
        q = (
            select(PaperTradeRecord)
            .where(PaperTradeRecord.status == 'paper_closed')
        )
        if chain:
            q = q.where(PaperTradeRecord.chain == chain)
        q = q.order_by(PaperTradeRecord.exit_at.desc()).limit(max(1, int(limit)))
        result = await self.session.execute(q)
        rows = list(result.scalars().all())

        if not rows:
            return 0, None

        last_close_at: datetime | None = rows[0].exit_at

        streak = 0
        for row in rows:
            pnl = float(row.paper_pnl_pct or 0.0)
            if pnl < 0:
                streak += 1
            else:
                break  # перервалась серія — стоп

        return streak, last_close_at

    async def get_stats(self, days: int = 7) -> dict:
        since = _utc_now() - timedelta(days=max(1, int(days)))
        result = await self.session.execute(
            select(PaperTradeRecord)
            .where(
                PaperTradeRecord.status == 'paper_closed',
                PaperTradeRecord.exit_at >= since,
            )
            .order_by(PaperTradeRecord.exit_at.desc())
        )
        rows = list(result.scalars().all())
        # Виключаємо фантомні записи: позиції, що закрились прямо зі статусу
        # 'watching' через timeout, ніколи не проходили open_position() —
        # exit_price=None, реальної торгівлі не було. Без цього вони
        # рахуються як 0%-трейди і спотворюють winrate / by_strategy.
        _phantom_exit_reasons = {'watching_timeout', 'watching_timeout_no_price'}
        rows = [
            r for r in rows
            if not (r.exit_reason in _phantom_exit_reasons and r.exit_price is None)
        ]
        wins = [r for r in rows if float(r.paper_pnl_pct or 0.0) > 0]
        losses = [r for r in rows if float(r.paper_pnl_pct or 0.0) <= 0]

        def _avg(items: list[PaperTradeRecord]) -> float:
            return sum(float(r.paper_pnl_pct or 0.0) for r in items) / len(items) if items else 0.0

        def _trade_dict(row: PaperTradeRecord | None) -> dict | None:
            if row is None:
                return None
            meta = row.execution_metadata or {}
            if not isinstance(meta, dict):
                meta = {}
            entry = row.entry_signals or {}
            if not isinstance(entry, dict):
                entry = {}
            _invalid_strategy = {'', 'watching', 'unknown', 'none', 'null'}
            strategy_hint = str(
                row.strategy
                or meta.get('strategy_hint')
                or meta.get('entry_brain_strategy')
                or entry.get('strategy_hint')
                or ''
            ).strip().lower()
            if strategy_hint in _invalid_strategy:
                strategy_hint = str(meta.get('strategy_hint') or entry.get('strategy_hint') or '').strip().lower()
            if strategy_hint in _invalid_strategy:
                strategy_hint = 'unknown'
            abc_wave = (
                meta.get('abc_wave')
                or meta.get('mfv_phase')
                or meta.get('abc_phase')
                or entry.get('abc_wave')
                or entry.get('mfv_phase')
                or entry.get('abc_phase')
            )
            abc_confidence = (
                meta.get('mfv_confidence')
                or meta.get('abc_confidence')
                or entry.get('mfv_confidence')
                or entry.get('abc_confidence')
            )
            stop_loss_pct = (
                meta.get('stop_loss_pct')
                or entry.get('stop_loss_pct')
            )
            take_profit_pct = (
                meta.get('take_profit_pct')
                or meta.get('dynamic_take_profit_pct')
                or entry.get('take_profit_pct')
            )
            duration_minutes = None
            _entry_at = _ensure_aware(row.entry_at)
            _exit_at = _ensure_aware(row.exit_at)
            if _entry_at and _exit_at:
                duration_minutes = round((_exit_at - _entry_at).total_seconds() / 60.0, 1)
            return {
                'chain': row.chain,
                'token_address': row.token_address,
                'symbol': row.symbol,
                'strategy': strategy_hint,
                'execution_state': row.execution_state,
                'requested_size_usd': row.requested_size_usd,
                'filled_size_usd': row.filled_size_usd,
                'fill_pct': row.fill_pct,
                'pnl_pct': row.paper_pnl_pct,
                'pnl_usd': row.paper_pnl_usd,
                'entry_price': row.entry_price,
                'exit_price': row.exit_price,
                'entry_at': row.entry_at.isoformat() if row.entry_at else None,
                'exit_at': row.exit_at.isoformat() if row.exit_at else None,
                'duration_minutes': duration_minutes,
                'stop_loss_pct': stop_loss_pct,
                'take_profit_pct': take_profit_pct,
                'abc_wave': abc_wave,
                'abc_confidence': round(float(abc_confidence), 2) if abc_confidence is not None else None,
                'exit_reason': row.exit_reason,
                'entry_delay_seconds': row.entry_delay_seconds,
                'graduated_at': row.graduated_at.isoformat() if row.graduated_at else None,
            }

        best = max(rows, key=lambda r: float(r.paper_pnl_pct or 0.0), default=None)
        worst = min(rows, key=lambda r: float(r.paper_pnl_pct or 0.0), default=None)
        by_strategy: dict[str, dict] = {}
        for strategy in ('farm', 'survival', 'smart_wallet'):
            s_rows = [r for r in rows if r.strategy == strategy]
            s_wins = [r for r in s_rows if float(r.paper_pnl_pct or 0.0) > 0]
            by_strategy[strategy] = {
                'trades': len(s_rows),
                'win_rate': len(s_wins) / len(s_rows) if s_rows else 0.0,
                'avg_pnl': _avg(s_rows),
            }

        # Рахуємо відкриті позиції окремо (для UI дашборду)
        open_result = await self.session.execute(
            select(TokenLifecycleRecord)
            .where(TokenLifecycleRecord.status == 'paper_open')
        )
        open_rows = list(open_result.scalars().all())
        open_pnl_usd = sum(float(r.paper_pnl_usd or 0.0) for r in open_rows)

        return {
            'total_trades': len(rows),
            'win_count': len(wins),
            'loss_count': len(losses),
            'win_rate': round(len(wins) / len(rows), 4) if rows else 0.0,
            'avg_win_pct': round(_avg(wins), 2),
            'avg_loss_pct': round(_avg(losses), 2),
            'total_pnl_usd': round(sum(float(r.paper_pnl_usd or 0.0) for r in rows), 2),
            'total_pnl_pct': round(_avg(rows), 2),
            'open_positions': len(open_rows),
            'open_pnl_usd': round(open_pnl_usd, 2),
            'best_trade': _trade_dict(best),
            'worst_trade': _trade_dict(worst),
            'by_strategy': by_strategy,
            'days': days,
            'has_data': len(rows) > 0,
        }

    @staticmethod
    def _exit_params(strategy: str | None, volatility_pct: float | None = None) -> tuple[float, float, float, int]:
        # SL / TP / trailing / time_limit — читаємо з settings або використовуємо дефолти
        try:
            from app.core.config import settings as _s
        except Exception:
            _s = None
        vol = max(float(volatility_pct or 0.0), 0.0)
        widen = 1.0 + min(vol / 20.0, 0.75)
        tighten = 1.0 - min(vol / 80.0, 0.25)
        time_shorten = 1.0 - min(vol / 120.0, 0.30)
        if strategy == 'survival':
            sl  = float(getattr(_s, 'pulse_survival_stop_loss_pct',  None) or -8.0) * widen
            tp  = float(getattr(_s, 'pulse_survival_take_profit_pct', None) or 20.0) * (1.0 + min(vol / 35.0, 0.50))
            return sl, tp, sl * 0.5 * tighten, max(20, int(round(40 * time_shorten)))
        if strategy == 'smart_wallet':
            sl  = float(getattr(_s, 'pulse_smart_wallet_stop_loss_pct',  None) or -8.0) * widen
            tp  = float(getattr(_s, 'pulse_smart_wallet_take_profit_pct', None) or 25.0) * (1.0 + min(vol / 35.0, 0.50))
            return sl, tp, sl * 0.5 * tighten, max(20, int(round(45 * time_shorten)))
        # skip/None/unknown/watching → smart_wallet defaults (безпечніший fallback ніж farm)
        if strategy in (None, 'skip', '', 'unknown', 'watching'):
            sl  = float(getattr(_s, 'pulse_smart_wallet_stop_loss_pct',  None) or -8.0) * widen
            tp  = float(getattr(_s, 'pulse_smart_wallet_take_profit_pct', None) or 25.0) * (1.0 + min(vol / 35.0, 0.50))
            return sl, tp, sl * 0.5 * tighten, max(20, int(round(45 * time_shorten)))
        # farm / default
        sl  = float(getattr(_s, 'farm_mode_stop_loss',  None) or -0.08) * 100 * widen
        tp  = float(getattr(_s, 'farm_mode_take_profit', None) or 0.20) * 100 * (1.0 + min(vol / 35.0, 0.50))
        trl = sl * 0.5 * tighten
        tlim = max(5, int(round((getattr(_s, 'farm_mode_time_limit_minutes', None) or 10) * time_shorten)))
        return sl, tp, trl, tlim
