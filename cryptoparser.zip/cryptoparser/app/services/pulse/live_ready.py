from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.db.models import LivePositionRecord, RealtimeAlertRecord, TokenLifecycleRecord
from app.utils.cache import GLOBAL_CACHE


@dataclass(slots=True)
class LiveGuardResult:
    allowed: bool
    reason: str | None = None
    capped_size_usd: float | None = None


class LiveReadyController:
    """Live-ready scaffolding.

    This does not send real transactions. It exists so the paper engine and the
    future live engine share the same state machine, risk guard, and recovery rules.
    """

    def __init__(self, session: AsyncSession):
        self.session = session

    @staticmethod
    def _now() -> datetime:
        return datetime.now(timezone.utc)

    async def guard_entry(
        self,
        *,
        requested_size_usd: float,
        liquidity_usd: float | None,
        chain: str,
        token_address: str,
        entry_delay_minutes: float | None = None,
        trading_mode: str = 'paper',
    ) -> LiveGuardResult:
        mode = str(trading_mode or 'paper').lower()
        if settings.live_kill_switch_enabled and mode == 'live':
            await self._record_block(chain, token_address, 'kill_switch', requested_size_usd, mode)
            return LiveGuardResult(False, 'kill_switch')

        size = max(float(requested_size_usd or 0.0), 0.0)
        if size <= 0:
            await self._record_block(chain, token_address, 'invalid_size', requested_size_usd, mode)
            return LiveGuardResult(False, 'invalid_size')

        min_window = float(settings.live_entry_timing_window_min_minutes or 0.0)
        max_window = float(settings.live_entry_timing_window_max_minutes or 0.0)
        if entry_delay_minutes is not None:
            if min_window > 0 and entry_delay_minutes < min_window:
                await self._record_block(chain, token_address, 'entry_timing_too_early', requested_size_usd, mode)
                return LiveGuardResult(False, 'entry_timing_too_early')
            if max_window > 0 and entry_delay_minutes > max_window:
                await self._record_block(chain, token_address, 'entry_timing_too_late', requested_size_usd, mode)
                return LiveGuardResult(False, 'entry_timing_too_late')

        max_position = float(settings.live_max_position_usd or 0.0) if mode == 'live' else 0.0
        if max_position > 0 and size > max_position:
            size = max_position

        if mode == 'live':
            if settings.live_kill_switch_enabled:
                await self._record_block(chain, token_address, 'kill_switch', requested_size_usd, mode)
                return LiveGuardResult(False, 'kill_switch')
            open_positions = await self.live_open_positions_count(chain)
            max_open_positions = int(getattr(settings, 'live_max_open_positions', 0) or 0)
            if max_open_positions > 0 and open_positions >= max_open_positions:
                await self._record_block(chain, token_address, 'max_open_positions', requested_size_usd, mode)
                return LiveGuardResult(False, 'max_open_positions')
            total_exposure = await self.total_open_exposure_usd(trading_mode='live')
            if float(settings.live_max_total_exposure_usd or 0.0) > 0 and (total_exposure + size) > float(settings.live_max_total_exposure_usd):
                await self._record_block(chain, token_address, 'max_total_exposure', requested_size_usd, mode)
                return LiveGuardResult(False, 'max_total_exposure')
            if float(getattr(settings, 'daily_loss_limit_usd', 0.0) or 0.0) > 0:
                daily_pnl = await self.live_daily_realized_pnl_usd()
                if daily_pnl <= -abs(float(settings.daily_loss_limit_usd)):
                    await self._record_block(chain, token_address, 'daily_loss_limit', requested_size_usd, mode)
                    return LiveGuardResult(False, 'daily_loss_limit')
        else:
            total_exposure = await self.total_open_exposure_usd(trading_mode='paper')
            if float(settings.live_max_total_exposure_usd or 0.0) > 0 and (total_exposure + size) > float(settings.live_max_total_exposure_usd):
                return LiveGuardResult(False, 'max_total_exposure')

        if liquidity_usd and liquidity_usd > 0:
            impact_pct = size / float(liquidity_usd)
            cap = float(settings.paper_max_order_impact_pct or 0.0)
            if cap > 0 and impact_pct > cap:
                size = float(liquidity_usd) * cap
        return LiveGuardResult(True, None, size)

    async def live_open_positions_count(self, chain: str) -> int:
        result = await self.session.execute(
            select(func.count()).select_from(LivePositionRecord).where(
                LivePositionRecord.chain == chain,
                LivePositionRecord.status == 'OPEN',
            )
        )
        return int(result.scalar_one() or 0)

    async def total_open_exposure_usd(self, trading_mode: str = 'paper') -> float:
        mode = str(trading_mode or 'paper').lower()
        if mode == 'live':
            result = await self.session.execute(
                select(LivePositionRecord).where(LivePositionRecord.status == 'OPEN')
            )
            rows = list(result.scalars().all())
            total = 0.0
            for row in rows:
                total += float(row.current_size_usd or row.entry_size_usd or 0.0)
            return total

        result = await self.session.execute(
            select(TokenLifecycleRecord).where(TokenLifecycleRecord.status == 'paper_open')
        )
        rows = list(result.scalars().all())
        total = 0.0
        for row in rows:
            total += float(row.remaining_size_usd or row.paper_size_usd or 0.0)
        return total

    async def live_daily_realized_pnl_usd(self) -> float:
        today_start = self._now().replace(hour=0, minute=0, second=0, microsecond=0)
        result = await self.session.execute(
            select(func.sum(LivePositionRecord.realized_pnl_usd)).where(
                LivePositionRecord.status == 'CLOSED',
                LivePositionRecord.exit_at >= today_start,
            )
        )
        return float(result.scalar() or 0.0)

    async def _record_block(self, chain: str, token_address: str, reason: str, requested_size_usd: float, trading_mode: str) -> None:
        self.session.add(
            RealtimeAlertRecord(
                chain=chain,
                token_address=token_address,
                event_type='live_entry_blocked',
                severity='medium',
                payload={
                    'reason': reason,
                    'requested_size_usd': float(requested_size_usd or 0.0),
                    'trading_mode': trading_mode,
                },
            )
        )
        await self.session.flush()

    async def mark_state(self, lifecycle: TokenLifecycleRecord, state: str, reason: str | None = None, metadata: dict[str, Any] | None = None) -> TokenLifecycleRecord:
        lifecycle.execution_state = state
        lifecycle.execution_state_reason = reason
        lifecycle.execution_state_updated_at = self._now()
        lifecycle.execution_attempts = int(lifecycle.execution_attempts or 0) + 1
        if metadata:
            lifecycle.execution_metadata = {**(lifecycle.execution_metadata or {}), **metadata}
        await self.session.flush()
        return lifecycle

    async def reconcile_stale(self) -> list[dict[str, Any]]:
        if not settings.live_recovery_enabled:
            return []

        stale_before = self._now() - timedelta(minutes=max(1, int(settings.live_recovery_stale_minutes)))
        result = await self.session.execute(
            select(TokenLifecycleRecord).where(
                TokenLifecycleRecord.status == 'paper_open',
                TokenLifecycleRecord.execution_state.in_({'entering', 'exiting', 'partial_exit'}),
                TokenLifecycleRecord.execution_state_updated_at <= stale_before,
            )
        )
        rows = list(result.scalars().all())
        alerts: list[dict[str, Any]] = []
        for row in rows:
            row.execution_state = 'needs_recovery'
            row.execution_state_reason = 'stale_state'
            row.execution_state_updated_at = self._now()
            row.execution_metadata = {
                **(row.execution_metadata or {}),
                'recovery_flagged_at': row.execution_state_updated_at.isoformat(),
            }
            alerts.append({'token_address': row.token_address, 'chain': row.chain, 'state': row.execution_state})
            self.session.add(
                RealtimeAlertRecord(
                    chain=row.chain,
                    token_address=row.token_address,
                    event_type='live_state_recovery',
                    severity='medium',
                    payload={'execution_state': row.execution_state, 'reason': row.execution_state_reason},
                )
            )
        if alerts:
            await GLOBAL_CACHE.set('pulse:live:recovery:last_count', len(alerts), ttl_seconds=86400)
        await self.session.flush()
        return alerts
