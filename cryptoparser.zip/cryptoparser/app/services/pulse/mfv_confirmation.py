
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from app.core.config import settings


def _clamp(value: float, minimum: float = 0.0, maximum: float = 1.0) -> float:
    return max(minimum, min(maximum, value))


def _safe_float(value: Any, default: float = 0.0) -> float:
    try:
        if value is None or value == '':
            return float(default)
        return float(value)
    except Exception:
        return float(default)


def _pair_from_candidate(candidate: Any) -> dict[str, Any]:
    raw = getattr(candidate, 'raw', None) or {}
    pair = raw.get('pair')
    return pair if isinstance(pair, dict) else {}


@dataclass(slots=True)
class MFVConfirmationResult:
    post_fzr_momentum_score: float = 0.0
    volume_expansion_score: float = 0.0
    liquidity_flow_score: float = 0.0
    composite_score: float = 0.0
    size_multiplier: float = 1.0
    confirmed: bool = False
    reasons: list[str] = field(default_factory=list)


class MFVConfirmationLayer:
    """Post-MFV confirmation layer for paper/live entry timing."""

    def evaluate(
        self,
        candidate: Any,
        security: Any,
        pattern_context: dict[str, Any] | None,
        momentum_score: float,
        mtf_momentum_score: float,
        onchain_score: float,
        wallet_score: float,
        liquidity: float,
        market_cap: float,
        volume_1h: float,
        volume_6h: float,
        volume_24h: float,
    ) -> MFVConfirmationResult:
        pattern_context = pattern_context or {}
        pair = _pair_from_candidate(candidate)
        price_changes = pair.get('priceChange') if isinstance(pair.get('priceChange'), dict) else {}
        if not isinstance(price_changes, dict):
            price_changes = {}
        txns = pair.get('txns') if isinstance(pair.get('txns'), dict) else {}
        if not isinstance(txns, dict):
            txns = {}

        mfv_confirmed = bool(pattern_context.get('mfv_confirmed', pattern_context.get('abc_confirmed')))
        mfv_phase = str(pattern_context.get('mfv_phase', pattern_context.get('abc_phase') or 'unknown')).lower().strip()
        mfv_rr = float(pattern_context.get('mfv_rr', pattern_context.get('abc_rr') or 0.0) or 0.0)
        mfv_confidence = float(pattern_context.get('mfv_confidence', pattern_context.get('abc_confidence') or 0.0) or 0.0)

        m5 = _safe_float(price_changes.get('m5'))
        m15 = _safe_float(price_changes.get('m15'))
        h1 = _safe_float(price_changes.get('h1'))
        h6 = _safe_float(price_changes.get('h6'))
        _ = _safe_float(price_changes.get('h24'))
        price_component = (
            _clamp(max(0.0, m5) / 18.0) * 0.18
            + _clamp(max(0.0, m15) / 24.0) * 0.16
            + _clamp(max(0.0, h1) / 35.0) * 0.34
            + _clamp(max(0.0, h6) / 60.0) * 0.12
            + _clamp(min(max(mfv_rr, 0.0), 5.0) / 5.0) * 0.20
        )
        post_fzr_momentum_score = _clamp((price_component * 0.45) + (momentum_score * 0.30) + (mtf_momentum_score * 0.25))

        vol_h1 = max(0.0, volume_1h)
        vol_h6 = max(0.0, volume_6h)
        vol_h24 = max(0.0, volume_24h)
        market_cap = max(0.0, market_cap)
        volume_ratio = (vol_h1 / market_cap) if market_cap > 0 else 0.0
        vol_growth_6h = _clamp((vol_h1 / max(vol_h6, 1.0)) / 3.0)
        vol_growth_24h = _clamp((vol_h1 / max(vol_h24, 1.0)) / 6.0)
        volume_velocity = _clamp(volume_ratio * 14.0)
        volume_expansion_score = _clamp((vol_growth_6h * 0.36) + (vol_growth_24h * 0.24) + (volume_velocity * 0.40))

        buys_5m = _safe_float((txns.get('m5') or {}).get('buys'))
        sells_5m = _safe_float((txns.get('m5') or {}).get('sells'))
        buys_h1 = _safe_float((txns.get('h1') or {}).get('buys'))
        sells_h1 = _safe_float((txns.get('h1') or {}).get('sells'))
        buys_total = buys_5m + buys_h1
        sells_total = sells_5m + sells_h1
        trade_total = buys_total + sells_total
        buy_pressure = buys_total / max(1.0, trade_total)
        trade_intensity = _clamp(trade_total / 240.0)
        liq_component = _clamp(liquidity / 100_000.0)
        top10 = _safe_float(getattr(security, 'top10_holder_pct', 0.0))
        concentration_penalty = 0.0
        if top10 > 35.0:
            concentration_penalty = min(0.30, (top10 - 35.0) / 120.0)
        liquidity_flow_score = _clamp(
            (buy_pressure * 0.42)
            + (trade_intensity * 0.20)
            + (liq_component * 0.28)
            + (_clamp((wallet_score + onchain_score) / 2.0) * 0.10)
            - concentration_penalty
        )

        composite_score = _clamp((post_fzr_momentum_score * 0.40) + (volume_expansion_score * 0.30) + (liquidity_flow_score * 0.30))
        if mfv_confirmed:
            composite_score = _clamp(composite_score + min(0.05, 0.02 + mfv_confidence * 0.03))
        if mfv_phase == 'entry_ready':
            composite_score = _clamp(composite_score + 0.04)
        elif mfv_phase == 'fzr_confirmed':
            composite_score = _clamp(composite_score + 0.02)

        hard_floor = float(getattr(settings, 'mfv_confirmation_hard_floor', 0.35) or 0.35)
        confirmed = bool(
            mfv_confirmed
            and composite_score >= hard_floor
            and post_fzr_momentum_score >= 0.40
            and volume_expansion_score >= 0.35
            and liquidity_flow_score >= 0.35
        )

        size_multiplier = _clamp(0.88 + (composite_score * 0.34), 0.80, 1.20)
        reasons = [
            f'mfv_confirmed={mfv_confirmed}',
            f'mfv_phase={mfv_phase}',
            f'mfv_rr={mfv_rr:.2f}',
            f'mfv_conf={mfv_confidence:.2f}',
            f'post_fzr_momentum={post_fzr_momentum_score:.4f}',
            f'volume_expansion={volume_expansion_score:.4f}',
            f'liquidity_flow={liquidity_flow_score:.4f}',
            f'composite={composite_score:.4f}',
            f'buy_pressure={buy_pressure:.4f}',
            f'volume_ratio={volume_ratio:.4f}',
        ]
        if buys_total > sells_total:
            reasons.append('buy_pressure_positive')
        if volume_expansion_score >= 0.60:
            reasons.append('volume_expansion_strong')
        if post_fzr_momentum_score >= 0.60:
            reasons.append('post_fzr_momentum_strong')
        if liquidity_flow_score >= 0.60:
            reasons.append('liquidity_flow_strong')
        if concentration_penalty > 0:
            reasons.append('holder_concentration_penalty')
        if confirmed:
            reasons.append('mfv_confirmation_passed')
        else:
            reasons.append('mfv_confirmation_soft')

        return MFVConfirmationResult(
            post_fzr_momentum_score=round(post_fzr_momentum_score, 4),
            volume_expansion_score=round(volume_expansion_score, 4),
            liquidity_flow_score=round(liquidity_flow_score, 4),
            composite_score=round(composite_score, 4),
            size_multiplier=round(size_multiplier, 4),
            confirmed=confirmed,
            reasons=reasons,
        )
