from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any

from sklearn.feature_extraction import DictVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score
from sklearn.model_selection import train_test_split

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.models import TokenLifecycleRecord


@dataclass(slots=True)
class MLEntry:
    features: dict[str, Any]
    target_win: int
    target_pnl_pct: float


class PulseMLExportService:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def export_rows(self, days: int = 180, limit: int = 10_000) -> list[dict[str, Any]]:
        since = datetime.now(timezone.utc) - timedelta(days=max(1, int(days)))
        result = await self.session.execute(
            select(TokenLifecycleRecord)
            .where(
                TokenLifecycleRecord.status == 'paper_closed',
                TokenLifecycleRecord.entry_at >= since,
                TokenLifecycleRecord.entry_signals.isnot(None),
            )
            .order_by(TokenLifecycleRecord.exit_at.desc())
            .limit(int(limit))
        )
        rows = []
        for row in result.scalars().all():
            rows.append(self._row_to_dict(row))
        return rows

    async def train_baseline(self, days: int = 180, limit: int = 10_000) -> dict[str, Any]:
        rows = await self.export_rows(days=days, limit=limit)
        if len(rows) < 20:
            return {'trained': False, 'reason': 'insufficient_data', 'rows': len(rows)}

        X = []
        y = []
        for row in rows:
            target = int(float(row.get('paper_pnl_pct') or 0.0) > 0.0)
            y.append(target)
            features = dict(row)
            features.pop('paper_pnl_pct', None)
            features.pop('paper_pnl_usd', None)
            features.pop('win', None)
            X.append(features)

        if len(set(y)) < 2:
            return {'trained': False, 'reason': 'single_class_only', 'rows': len(rows)}
        class_counts = {label: y.count(label) for label in set(y)}
        if min(class_counts.values()) < 2:
            return {'trained': False, 'reason': 'too_few_samples_per_class', 'rows': len(rows), 'class_counts': class_counts}

        vectorizer = DictVectorizer(sparse=True)
        X_vec = vectorizer.fit_transform(X)
        X_train, X_test, y_train, y_test = train_test_split(X_vec, y, test_size=0.25, random_state=42, stratify=y)
        model = LogisticRegression(max_iter=1000)
        model.fit(X_train, y_train)
        preds = model.predict(X_test)
        probs = model.predict_proba(X_test)[:, 1] if hasattr(model, 'predict_proba') else None
        metrics = {
            'trained': True,
            'rows': len(rows),
            'features': int(X_vec.shape[1]),
            'accuracy': round(float(accuracy_score(y_test, preds)), 4),
            'f1': round(float(f1_score(y_test, preds)), 4),
            'roc_auc': round(float(roc_auc_score(y_test, probs)), 4) if probs is not None and len(set(y_test)) > 1 else None,
        }
        return metrics

    @staticmethod
    def _row_to_dict(row: TokenLifecycleRecord) -> dict[str, Any]:
        entry = row.entry_signals or {}
        exit_signals = row.exit_signals or {}
        features: dict[str, Any] = {
            'chain': row.chain,
            'strategy': row.strategy or 'none',
            'symbol': row.symbol or '',
            'token_family': row.token_family or entry.get('token_family') or '',
            'entry_delay_seconds': row.entry_delay_seconds or 0,
            'graduated_confirmed': int(bool(row.graduated_at)),
            'minutes_since_graduation': float(entry.get('minutes_since_graduation') or 0.0),
            'volatility_pct': float(entry.get('volatility_pct') or 0.0),
            'entry_execution_drift_pct': float(entry.get('entry_execution_drift_pct') or 0.0),
            'entry_execution_score': float(entry.get('entry_execution_score') or 0.0),
            'entry_route_used': str(entry.get('entry_route_used') or ''),
            'entry_priority_fee_usd': float(entry.get('entry_priority_fee_usd') or 0.0),
            'volume_h1': float(entry.get('volume_h1') or 0.0),
            'volume_h6': float(entry.get('volume_h6') or 0.0),
            'volume_h24': float(entry.get('volume_h24') or 0.0),
            'volume_ratio': float(entry.get('volume_ratio') or 0.0),
            'market_cap_usd': float(entry.get('market_cap_usd') or 0.0),
            'bundle_severity': entry.get('bundle_severity') or '',
            'bundle_supply_pct': float(entry.get('bundle_supply_pct') or 0.0),
            'risk_score': float(entry.get('risk_score') or 0.0),
            'continuation_score': float(entry.get('continuation_score') or 0.0),
            'survival_score': float(entry.get('survival_score') or 0.0),
            'momentum_score': float(entry.get('momentum_score') or 0.0),
            'confidence': float(entry.get('confidence') or 0.0),
            'gem_score': float(entry.get('gem_score') or 0.0),
            'ml_risk_score': float(entry.get('ml_risk_score') or 0.0),
            'has_community': int(bool(entry.get('has_community'))),
            'decay_penalty': float(entry.get('decay_penalty') or 0.0),
            'exit_reason_code': exit_signals.get('exit_reason') or row.exit_reason or 'unknown',
            'partial_exit_done': int(bool(row.partial_exit_done)),
            'entry_latency_seconds': int(row.entry_latency_seconds or 0),
            'exit_latency_seconds': int(row.exit_latency_seconds or 0),
            'exit_execution_drift_pct': float(exit_signals.get('exit_execution_drift_pct') or entry.get('exit_execution_drift_pct') or 0.0),
            'exit_execution_score': float(exit_signals.get('exit_execution_score') or entry.get('exit_execution_score') or 0.0),
            'exit_route_used': str(exit_signals.get('exit_route_used') or entry.get('exit_route_used') or ''),
            'exit_priority_fee_usd': float(exit_signals.get('exit_priority_fee_usd') or entry.get('exit_priority_fee_usd') or 0.0),
            'pnl_pct': float(row.paper_pnl_pct or 0.0),
            'paper_pnl_usd': float(row.paper_pnl_usd or 0.0),
            'win': int(float(row.paper_pnl_pct or 0.0) > 0.0),
        }
        return features
