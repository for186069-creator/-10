from __future__ import annotations

import os
import logging
import re
import dataclasses
from datetime import datetime, timezone, timedelta
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings

# ── Dedup lock: запобігає подвійному відкриттю одного токена ─────────────────
# Ключ: "chain:token_address", значення — UTC timestamp відкриття
import time as _time
_OPENING_TOKENS: dict[str, float] = {}   # {key: opened_at_ts}
_OPENING_COOLDOWN_SEC = 300              # 5 хвилин cooldown після paper_closed
from app.adapters.dexscreener import DexScreenerClient
from app.adapters.evm_explorer import EVMExplorerClient
from app.adapters.solana_rpc import SolanaRpcClient
from app.db.models import PriceSnapshotRecord, RealtimeAlertRecord, TokenLifecycleRecord
from app.models.token import BehaviorProfile, Chain, Decision, SecurityReport, SocialProfile, TokenCandidate, WebsiteProfile
from app.services.pulse.brain import BrainResult, PulseBrain
from app.services.pulse.alerter import PulseAlerter
from app.services.pulse.execution import ExecutionFailed, ExecutionQuote, PulseExecutionSimulator
from app.services.pulse.health import PulseHealthMonitor
from app.services.pulse.lifecycle import LifecycleService, extract_liquidity_from_candidate, extract_price_from_candidate
from app.services.pulse.risk_guard import risk_size_multiplier
from app.services.pulse.live_ready import LiveGuardResult, LiveReadyController
from app.services.pulse.blacklist_store import PulseBlacklistStore
from app.services.pulse.abc_detector import ABCDetector
from app.utils.cache import GLOBAL_CACHE
from app.utils.http import HttpClient

logger = logging.getLogger(__name__)


class PaperTrader:
    def __init__(self, session: AsyncSession):
        self.session = session
        self.lifecycle = LifecycleService(session)
        self.brain = PulseBrain()
        self.alerter = PulseAlerter()
        self.dex = DexScreenerClient()
        self.health = PulseHealthMonitor()
        self.live_ready = LiveReadyController(session)
        self.blacklist = PulseBlacklistStore()
        self.evm = EVMExplorerClient()
        self.solana = SolanaRpcClient()
        self.execution = PulseExecutionSimulator()
        self.abc_detector = ABCDetector()

    @staticmethod
    def _market_regime(volatility_pct: float | None, momentum_score: float, win_streak: int, loss_streak: int = 0) -> tuple[str, float]:
        vol = float(volatility_pct or 0.0)
        momentum = float(momentum_score or 0.0)
        if loss_streak >= 3:
            return 'risk_off', 0.55
        if win_streak >= 3 and momentum >= float(getattr(settings, 'paper_market_regime_high_momentum_score', 0.60) or 0.60):
            return 'profit_lock', 1.25
        if vol >= float(getattr(settings, 'paper_market_regime_high_vol_pct', 16.0) or 16.0):
            return 'risk_off', 0.60
        if vol <= float(getattr(settings, 'paper_market_regime_low_vol_pct', 3.0) or 3.0) and momentum >= float(getattr(settings, 'paper_market_regime_high_momentum_score', 0.60) or 0.60):
            return 'risk_on', 1.20 if win_streak >= 2 else 1.10
        if momentum >= float(getattr(settings, 'paper_market_regime_low_momentum_score', 0.35) or 0.35):
            return 'neutral', 1.00
        return 'defensive', 0.80

    @staticmethod
    def _trading_mode() -> str:
        if bool(getattr(settings, 'live_trading_enabled', False)) and not bool(getattr(settings, 'live_trading_dry_run', True)):
            return 'live'
        return 'paper'

    @staticmethod
    def _fzr_override_thresholds(mode: str) -> tuple[float, float, float, float]:
        if mode == 'live':
            return (
                float(getattr(settings, 'fzr_trade_ready_override_min_rr_live', 2.0) or 2.0),
                float(getattr(settings, 'fzr_trade_ready_override_min_confidence_live', 0.70) or 0.70),
                float(getattr(settings, 'fzr_trade_ready_override_min_liquidity_usd_live', 40_000.0) or 40_000.0),
                float(getattr(settings, 'fzr_trade_ready_override_size_multiplier_live', 0.35) or 0.35),
            )
        return (
            float(getattr(settings, 'fzr_trade_ready_override_min_rr_paper', 1.8) or 1.8),
            float(getattr(settings, 'fzr_trade_ready_override_min_confidence_paper', 0.65) or 0.65),
            float(getattr(settings, 'fzr_trade_ready_override_min_liquidity_usd_paper', 25_000.0) or 25_000.0),
            float(getattr(settings, 'fzr_trade_ready_override_size_multiplier_paper', 0.5) or 0.5),
        )

    def _is_blacklisted_candidate(self, candidate: TokenCandidate) -> tuple[bool, str | None]:
        decision = self.blacklist.match(candidate)
        return decision.blacklisted, decision.reason


    @staticmethod
    def _watch_candidate_from_lifecycle(
        position: TokenLifecycleRecord,
        current_price: float | None = None,
        current_liquidity: float | None = None,
        current_holders: int | None = None,
    ) -> TokenCandidate:
        raw_payload: dict[str, Any] = {}
        for source in (getattr(position, 'entry_signals', None), getattr(position, 'execution_metadata', None)):
            if isinstance(source, dict):
                raw_payload.update(source)
        if current_price is not None and current_price > 0:
            raw_payload['price_usd'] = current_price
        return TokenCandidate(
            chain=Chain(position.chain),
            token_address=position.token_address,
            pair_address=position.pair_address,
            symbol=position.symbol,
            first_seen_at=position.first_seen_at or position.entry_at or datetime.now(timezone.utc),
            liquidity_usd=current_liquidity if current_liquidity is not None else position.current_liquidity_usd,
            holders=current_holders if current_holders is not None else position.current_holders,
            raw=raw_payload,
        )

    async def _recent_price_snapshots_for_token(
        self,
        chain: str,
        token_address: str,
        limit: int = 1200,
    ) -> list[PriceSnapshotRecord]:
        result = await self.session.execute(
            select(PriceSnapshotRecord)
            .where(
                PriceSnapshotRecord.chain == chain,
                PriceSnapshotRecord.token_address == token_address,
            )
            .order_by(PriceSnapshotRecord.captured_at.desc())
            .limit(limit)
        )
        return list(reversed(list(result.scalars().all())))

    def _dedup_can_open(self, chain: str, token_address: str) -> bool:
        """Повертає True якщо токен можна відкрити зараз (не в cooldown)."""
        key = f"{chain}:{token_address}"
        last_ts = _OPENING_TOKENS.get(key, 0.0)
        return (_time.time() - last_ts) >= _OPENING_COOLDOWN_SEC

    def _dedup_register_open(self, chain: str, token_address: str) -> None:
        """Реєструє відкриття токена щоб наступний відкритий трейд чекав cooldown."""
        _OPENING_TOKENS[f"{chain}:{token_address}"] = _time.time()
        # Очищуємо старі записи (> 10 хв) щоб не накопичувались
        now = _time.time()
        for k in list(_OPENING_TOKENS):
            if now - _OPENING_TOKENS[k] > 600:
                del _OPENING_TOKENS[k]

    async def _reevaluate_watching_position(
        self,
        position: TokenLifecycleRecord,
        current_price: float,
        current_liquidity: float | None,
        current_holders: int | None,
        snapshots: list[PriceSnapshotRecord] | None = None,
    ) -> TokenLifecycleRecord | None:
        if current_price <= 0:
            return None

        candidate = self._watch_candidate_from_lifecycle(position, current_price, current_liquidity, current_holders)
        impulse_high = float(position.peak_price or position.entry_price or current_price or 0.0)
        abc_signal = await self._abc_signal_for_candidate(candidate, impulse_high=impulse_high, snapshots=snapshots)
        mfv_confirmed = bool(abc_signal.get('mfv_confirmed') or abc_signal.get('abc_confirmed'))
        mfv_phase = str(abc_signal.get('mfv_phase') or abc_signal.get('abc_phase') or '').lower().strip()

        # ── Brain-метрики з моменту approve (execution_metadata) ────────────────
        _meta = position.execution_metadata or {}
        if not isinstance(_meta, dict):
            _meta = {}
        _entry_score = float(position.entry_risk_score or _meta.get('entry_score') or 0.0)  # decision.score, 0-100
        _entry_continuation = float(position.entry_continuation_score or 0.0)
        if _entry_continuation <= 0.0:
            # fallback: approve_watcher не завжди заповнює entry_continuation_score —
            # використовуємо нормалізований decision.score як проксі (0-100 -> 0-1)
            _entry_continuation = _entry_score / 100.0 if _entry_score > 0 else 0.0
        _entry_momentum = float(_meta.get('entry_momentum_score') or _entry_continuation or 0.0)

        momentum_hint = _entry_momentum
        fzr_fast_path = mfv_phase == 'fzr_forming' and momentum_hint > 0.70
        mfv_confidence_hint = float(abc_signal.get('mfv_confidence') or abc_signal.get('abc_confidence') or 0.0)
        current_liquidity_val = float(current_liquidity or 0.0)
        _fzr_forming_watch = (
            mfv_phase in ('fzr_forming', 'wave_b', 'wave_c')
            and mfv_confidence_hint >= 0.55  # підвищено з 0.35
            and current_liquidity_val >= 25_000.0  # підвищено з 20K
        )
        # fzr_forming_watch дозволений ТІЛЬКИ якщо є підтверджений RR
        mfv_rr_val = float(abc_signal.get('mfv_rr') or abc_signal.get('abc_rr') or 0.0)
        _fzr_forming_watch_rr_ok = _fzr_forming_watch and mfv_rr_val >= 2.5
        mfv_entry_gate = bool(
            (mfv_phase == 'entry_ready' and mfv_confirmed)
            or mfv_phase == 'fzr_confirmed'
            or fzr_fast_path
            or _fzr_forming_watch_rr_ok
        )

        # ── COMPOSITE ENTRY SCORE (без hard ABC-gate) ────────────────────────────
        # Якщо ABC ще не дав фази (unknown/no_data/wave_a/waiting_*), але brain-метрики
        # на момент approve вже були дуже сильними — дозволяємо вхід без очікування
        # на ABC-структуру, яка для коротко живучих pump.fun токенів часто фізично
        # не встигає сформуватись. Пороги свідомо консервативні (топ-кандидати).
        # ПРИМІТКА: execution_metadata['entry_momentum_score'] зберігає
        # decision.subscores['continuation'] (а не справжній brain momentum_score),
        # тому порівнюємо з тим самим порогом, що й _entry_continuation.
        _abc_not_ready = mfv_phase in ('', 'unknown', 'no_data', 'wave_a', 'waiting_wave_a')
        _composite_entry_gate = bool(
            _abc_not_ready
            and _entry_score >= 80.0
            and _entry_continuation >= 0.70
            and _entry_momentum >= 0.70
            and current_liquidity_val >= 25_000.0
        )
        if _composite_entry_gate:
            mfv_entry_gate = True
            mfv_phase = mfv_phase or 'composite_no_abc'

        if not mfv_entry_gate:
            return None

        if _composite_entry_gate:
            logger.info(
                'pulse_composite_entry token=%s score=%.1f continuation=%.3f momentum=%.3f liq=%.0f phase=%s',
                position.token_address[:12], _entry_score, _entry_continuation, _entry_momentum, current_liquidity_val, mfv_phase,
            )

        # ── FRESHNESS CHECK: ABC сигнал не має бути старим ────────────────────
        # Якщо токен в watchlist > N хв і ABC тільки зараз підтвердив — пропускаємо
        # (означає що це помираючий токен, не свіже ралі)
        _signal_ts = float(abc_signal.get('signal_at_ts') or abc_signal.get('confirmed_at') or 0.0)
        _watching_since = position.first_seen_at or position.created_at
        if _watching_since:
            from datetime import timezone as _tz
            _ws = _watching_since.replace(tzinfo=_tz.utc) if _watching_since.tzinfo is None else _watching_since
            _watching_minutes = (datetime.now(_tz.utc) - _ws).total_seconds() / 60.0
            # Graduated pump tokens can take 4-8h to form ABC pattern after graduation dump
            # Use longer window if liquidity is still healthy (token not dying)
            _max_watch_minutes = 120.0 if current_liquidity_val >= 50_000.0 else 45.0
            if _watching_minutes > _max_watch_minutes and not _composite_entry_gate:
                # Токен в watchlist занадто довго — закриваємо щоб звільнити слот.
                # Виняток: _composite_entry_gate — якщо brain-score підтвердив вхід
                # без ABC, відкриваємось незалежно від часу в watchlist.
                try:
                    position.status = 'paper_closed'
                    position.exit_reason = 'watching_timeout'
                    position.exit_at = datetime.now(timezone.utc)
                    position.updated_at = datetime.now(timezone.utc)
                    self.session.add(position)
                    await self.session.flush()
                except Exception:
                    pass
                return None

        # ── DEDUP: cooldown після попереднього відкриття ───────────────────────
        _chain_val = str(position.chain or '')
        if not self._dedup_can_open(_chain_val, position.token_address):
            return None

        # ── PRE-ENTRY LIQUIDITY CHECK ──────────────────────────────────────────
        _re_min_liq = float(settings.paper_min_liquidity_exit_usd) * 2.0  # 2x exit threshold
        # CRITICAL: блокуємо якщо ліквідність None/0/низька — невідома ліквідність = небезпека
        _watch_liq = float(current_liquidity or 0.0)
        if _watch_liq < _re_min_liq:
            # Якщо ліквідність деградувала нижче мінімуму — закриваємо watching слот
            try:
                position.status = 'paper_closed'
                position.exit_reason = 'watching_liquidity_too_low'
                position.exit_at = datetime.now(timezone.utc)
                position.updated_at = datetime.now(timezone.utc)
                self.session.add(position)
                await self.session.flush()
            except Exception:
                pass
            return None

        decision = Decision(
            status='APPROVE',
            score=float(_entry_score or position.entry_risk_score or 0.0),
            reasons=['watchlist_mfv_confirmed' if not _composite_entry_gate else 'composite_entry_score'],
            evidence={
                'trade_ready': True,
                'trade_ready_reason': 'watchlist_mfv_confirmed' if not _composite_entry_gate else 'composite_entry_score',
                'decision_profile': 'pump_graduated',
                'mfv_phase': mfv_phase,
                'mfv_rr': float(abc_signal.get('mfv_rr') or 0.0),
                'mfv_confidence': float(abc_signal.get('mfv_confidence') or 0.0),
            },
        )
        _raw_strat = str(position.strategy or position.entry_brain_strategy or '').strip()
        # Фільтруємо невалідні значення стратегії з watching статусу
        strategy_hint = _raw_strat if _raw_strat not in ('', 'watching', 'unknown', 'skip', 'survival', 'none', 'null') else 'smart_wallet' 
        brain_result = BrainResult(
            continuation_score=_entry_continuation,
            survival_score=_entry_continuation,
            momentum_score=_entry_momentum,
            quality_score=_entry_continuation,
            decay_penalty=0.0,
            strategy_hint=strategy_hint if strategy_hint not in ('skip', 'survival', 'watching', 'unknown', '') else 'smart_wallet',
            confidence=float(abc_signal.get('mfv_confidence') or 0.5),
            confirmation_score=float(abc_signal.get('mfv_confidence') or 0.0),
            post_fzr_momentum_score=float(abc_signal.get('mfv_confidence') or 0.0),
            volume_expansion_score=float(abc_signal.get('mfv_confidence') or 0.0),
            liquidity_flow_score=float(abc_signal.get('mfv_confidence') or 0.0),
            confirmation_multiplier=1.0,
            confirmation_reasons=['watchlist_mfv_confirmed'],
            signals=['watchlist_mfv_confirmed'],
            breakdown={'watchlist_mfv_confirmed': float(abc_signal.get('mfv_confidence') or 0.0)},
        )
        return await self.lifecycle.open_position(
            candidate=candidate,
            decision=decision,
            brain_result=brain_result,
            bundle_data={},
            paper_size_usd=float(settings.paper_trading_position_size_usd),
            execution_price=current_price,
            execution_latency_seconds=0,
            execution_fee_usd=float(settings.paper_gas_fee_usd),
            execution_state='open',
            force_bypass=True,
        )



    async def _abc_signal_for_candidate(self, candidate: TokenCandidate, impulse_high: float | None = None, snapshots: list[PriceSnapshotRecord] | None = None) -> dict[str, Any]:
        if not bool(getattr(settings, 'abc_enabled', True)):
            return {
                'mfv_confirmed': False,
                'abc_confirmed': False,
                'mfv_reason': 'mfv_disabled',
                'abc_reason': 'mfv_disabled',
                'mfv_phase': 'disabled',
                'mfv_timeframe': '',
            }
        try:
            current_price = extract_price_from_candidate(candidate)
            signal = await self.abc_detector.detect(
                candidate.chain.value,
                candidate.token_address,
                impulse_high=impulse_high,
                current_price=current_price,
                snapshots=snapshots,
            )
            wave = signal.wave_result
            mfv_confirmed = bool(signal.detected)
            payload = {
                'mfv_confirmed': mfv_confirmed,
                'abc_confirmed': mfv_confirmed,
                'mfv_reason': signal.entry_reason,
                'abc_reason': signal.entry_reason,
                'mfv_rr': float(signal.rr_ratio or 0.0),
                'abc_rr': float(signal.rr_ratio or 0.0),
                'mfv_confidence': float(signal.confidence or 0.0),
                'abc_confidence': float(signal.confidence or 0.0),
                'mfv_entry_price': signal.entry_price,
                'abc_entry_price': signal.entry_price,
                'mfv_stop_loss': signal.stop_loss,
                'abc_stop_loss': signal.stop_loss,
                'mfv_take_profit': signal.take_profit,
                'abc_take_profit': signal.take_profit,
                'mfv_take_profit_conservative_price': signal.take_profit_conservative,
                'mfv_take_profit_aggressive_price': signal.take_profit_aggressive,
                'mfv_phase': signal.phase,
                'abc_phase': signal.phase,
                'mfv_timeframe': signal.timeframe_used,
                'abc_timeframe': signal.timeframe_used,
                'mfv_wave': {
                    'phase': signal.phase,
                    'confidence': float(wave.confidence or 0.0),
                    'fib_level': float(wave.fib_level or 0.0),
                    'a_size_pct': float(wave.a_size_pct or 0.0),
                    'b_retrace_pct': float(wave.b_retrace_pct or 0.0),
                    'c_vs_a_pct': float(wave.c_vs_a_pct or 0.0),
                    'pivot_mf': float(signal.wave_data.get('pivot_mf') or 0.0),
                    'low_a': float(signal.wave_data.get('low_a') or 0.0),
                    'high_b': float(signal.wave_data.get('high_b') or 0.0),
                    'low_c': float(signal.wave_data.get('low_c') or 0.0),
                    'fzr_type': signal.wave_data.get('fzr_type'),
                },
                'abc_wave': {
                    'phase': signal.phase,
                    'confidence': float(wave.confidence or 0.0),
                    'fib_level': float(wave.fib_level or 0.0),
                    'a_size_pct': float(wave.a_size_pct or 0.0),
                    'b_retrace_pct': float(wave.b_retrace_pct or 0.0),
                    'c_vs_a_pct': float(wave.c_vs_a_pct or 0.0),
                },
            }
            return payload
        except Exception as exc:
            return {
                'mfv_confirmed': False,
                'abc_confirmed': False,
                'mfv_reason': f'mfv_error:{exc}',
                'abc_reason': f'mfv_error:{exc}',
                'mfv_phase': 'error',
                'abc_phase': 'error',
                'mfv_timeframe': '',
            }

    async def on_approve(self,
        candidate: TokenCandidate,
        decision: Decision,
        security: SecurityReport,
        social: SocialProfile,
        website: WebsiteProfile,
        behavior: BehaviorProfile | None,
        bundle_data: dict | None = None,
    ) -> TokenLifecycleRecord | None:
        if not settings.paper_trading_enabled:
            return None

        existing = await self.lifecycle.get_lifecycle(candidate.chain.value, candidate.token_address)
        decision_evidence = decision.evidence or {}
        decision_profile = str((decision_evidence.get('decision_profile') or (candidate.raw or {}).get('decision_profile') or candidate.lifecycle_stage or '')).lower().strip()
        graduated_entry = decision_profile == 'pump_graduated'
        approved_status = str(getattr(decision, 'status', '') or '').upper() in {'APPROVE', 'FARM_APPROVE'}
        approved_candidate = approved_status or graduated_entry
        if existing is not None:
            existing_status = str(existing.status or '').lower().strip()
            if existing_status == 'paper_open':
                return None
            # Preserve closed trade history in token_lifecycle.
            # This table has a unique row per token, so reopening the same token
            # would overwrite the closed result and corrupt analytics.
            if existing_status == 'paper_closed':
                return existing
            if existing_status == 'watching' and not approved_candidate:
                return None

        if not approved_candidate:
            return None

        abc_impulse_high = None
        for _key in ('graduation_price', 'peak_price', 'impulse_high', 'pivot_high'):
            _raw = decision_evidence.get(_key)
            if _raw is None:
                continue
            try:
                _val = float(_raw)
            except (TypeError, ValueError):
                continue
            if _val > 0:
                abc_impulse_high = _val
                break

        # Fallback: взяти максимальну ціну з candidate.raw
        if not abc_impulse_high:
            for _rk in ('graduation_price', 'peak_price', 'impulse_high', 'pivot_high', 'priceUsd', 'price_usd'):
                _rv = (candidate.raw or {}).get(_rk)
                if _rv:
                    try:
                        _rv_f = float(_rv)
                        if _rv_f > 0:
                            abc_impulse_high = _rv_f
                            break
                    except (TypeError, ValueError):
                        pass

        # Fallback: максимальна ціна з price_snapshots_pulse за останні 360 хв
        if not abc_impulse_high:
            try:
                from sqlalchemy import select, func
                from app.db.models import PriceSnapshotRecord
                from datetime import datetime, timezone, timedelta
                since_ts = datetime.now(timezone.utc) - timedelta(minutes=360)
                _max_res = await self.session.execute(
                    select(func.max(PriceSnapshotRecord.price_usd)).where(
                        PriceSnapshotRecord.token_address == candidate.token_address,
                        PriceSnapshotRecord.captured_at >= since_ts,
                    )
                )
                _max_price = _max_res.scalar()
                if _max_price and float(_max_price) > 0:
                    abc_impulse_high = float(_max_price)
            except Exception:
                pass

        # Завантажуємо snapshots один раз щоб уникнути вкладеної сесії в abc_detector
        # (abc_detector відкриває нову AsyncSessionLocal якщо snapshots=None → db locked)
        _on_approve_snapshots = await self._recent_price_snapshots_for_token(
            candidate.chain.value, candidate.token_address
        )
        abc_signal = await self._abc_signal_for_candidate(
            candidate, impulse_high=abc_impulse_high, snapshots=_on_approve_snapshots
        )
        brain_result = self.brain.analyze(
            candidate,
            security,
            social,
            website,
            behavior,
            bundle_data,
            pattern_context=abc_signal,
            decision_profile=decision_profile,
        )
        trading_mode = self._trading_mode()
        decision_trade_ready = bool(getattr(decision, 'trade_ready', False) or (decision_evidence.get('trade_ready') if isinstance(decision_evidence, dict) else False))
        decision_trade_ready_reason = str(getattr(decision, 'trade_ready_reason', '') or decision_evidence.get('trade_ready_reason') or '').strip()
        mfv_required = bool(getattr(settings, 'abc_enabled', True))
        mfv_confirmed = bool(abc_signal.get('mfv_confirmed') or abc_signal.get('abc_confirmed'))
        mfv_phase = str(abc_signal.get('mfv_phase') or abc_signal.get('abc_phase') or '').lower().strip()
        mfv_rr = float(abc_signal.get('mfv_rr') or abc_signal.get('abc_rr') or 0.0)
        mfv_confidence = float(abc_signal.get('mfv_confidence') or abc_signal.get('abc_confidence') or 0.0)
        entry_liquidity_hint = float(extract_liquidity_from_candidate(candidate) or 0.0)
        mfv_allowed_wait_phases = {
            'no_data',
            'waiting_wave_a',
            'mfv_insufficient_ticks',
            'mfv_insufficient_5m',
            'mfv_insufficient_1m',
            'mfv_insufficient_30s',
            'mfv_no_post_peak_data',
            'mfv_no_context',
            'mfv_waiting_pivot_break',
        }
        entry_momentum_score = float(getattr(brain_result, 'momentum_score', 0.0) or 0.0)
        fzr_fast_path = mfv_phase == 'fzr_forming' and entry_momentum_score > 0.70
        allowed_mfv_phases = {'entry_ready', 'fzr_confirmed'}
        if graduated_entry:
            allowed_mfv_phases = allowed_mfv_phases | {'fzr_forming', 'wave_b', 'wave_c', 'wave_a'}
        # fzr_confirmed must be allowed to enter even if detector.detected=False;
        # fast-path: very high momentum can skip waiting for fzr_confirmed.
        # For graduated pump tokens: also allow fzr_forming if confidence is decent
        _fzr_forming_graduated = (
            mfv_phase in ('fzr_forming', 'wave_b', 'wave_c')
            and graduated_entry
            and mfv_confidence >= 0.40  # знижено з 0.55 — wave_b mfv_conf зазвичай ~0.40
            and entry_liquidity_hint >= 25_000.0  # підвищено з 20K
        )
        # Wave A на graduated токенах: ABC ще не дав mfv_rr (rr рахується лише з wave_b),
        # тому пускаємо за brain momentum/quality — proxy сигнал замість RR
        _wave_a_graduated = (
            mfv_phase == 'wave_a'
            and graduated_entry
            and entry_momentum_score >= 0.80
            and entry_liquidity_hint >= 25_000.0
        )
        mfv_entry_gate = bool(
            (mfv_phase == 'entry_ready' and mfv_confirmed)
            or mfv_phase == 'fzr_confirmed'
            or fzr_fast_path
            or _fzr_forming_graduated
            or _wave_a_graduated
        )
        fzr_override_applied = False
        fzr_override_size_multiplier = 1.0
        if approved_candidate and not decision_trade_ready and mfv_entry_gate and bool(getattr(settings, 'fzr_trade_ready_override_enabled', False)):
            min_rr, min_conf, min_liquidity, size_multiplier = self._fzr_override_thresholds(trading_mode)
            if mfv_rr >= min_rr and mfv_confidence >= min_conf and entry_liquidity_hint >= min_liquidity:
                decision_trade_ready = True
                decision_trade_ready_reason = f'fzr_override:{trading_mode}'
                fzr_override_applied = True
                fzr_override_size_multiplier = max(min(size_multiplier, 1.0), 0.05)
        # Graduated fzr_forming direct entry: ТІЛЬКИ з підтвердженим RR >= 2.5
        # Без RR — це ставка без підстав → причина збитків
        if approved_candidate and not decision_trade_ready and _fzr_forming_graduated:
            if mfv_rr >= 2.5:
                decision_trade_ready = True
                decision_trade_ready_reason = 'fzr_forming_graduated_entry'
            # else: чекаємо entry_ready або fzr_confirmed — не торгуємо без RR
        is_farm_approve_early = str(getattr(decision, 'status', '') or '').upper() == 'FARM_APPROVE'
        force_trade = bool(
            approved_candidate
            and mfv_entry_gate
            and (brain_result.strategy_hint != 'skip' or graduated_entry)
        )
        # Farm-approve токени теж чекають ABC підтвердження (ABC як фільтр ругів):
        # bundled_buy = кити зайшли, ABC підтверджує що тримають і рухаються далі
        open_gate = bool(approved_candidate and decision_trade_ready and mfv_entry_gate)
        trade_intent = False
        # Survival вимкнена: graduated + ABC → farm (кити вже там, ABC підтвердив)
        if approved_candidate and graduated_entry and mfv_entry_gate:
            if is_farm_approve_early:
                brain_result = dataclasses.replace(brain_result, strategy_hint='farm')
            else:
                # Без bundled_buy → smart_wallet (ширший TP ніж survival)
                brain_result = dataclasses.replace(brain_result, strategy_hint='smart_wallet')
        # Farm-approve + ABC: C-хвиля з farm SL/TP
        elif is_farm_approve_early and mfv_entry_gate:
            brain_result = dataclasses.replace(brain_result, strategy_hint='farm')
        # smart_wallet залишається smart_wallet (більший TP ніж survival)
        # Не переключаємо на survival — вона вимкнена
        if approved_candidate and not open_gate:
            wait_reason = decision_trade_ready_reason or 'decision_not_trade_ready'
            if not decision_trade_ready:
                wait_reason = decision_trade_ready_reason or 'decision_not_trade_ready'
            elif mfv_required and not mfv_confirmed:
                wait_reason = f'mfv_wait:{mfv_phase or "unknown"}'
            elif mfv_phase not in allowed_mfv_phases:
                wait_reason = f'mfv_wait:{mfv_phase or "unknown"}'
            logger.debug(
                'pulse_trade_wait reason=%s token=%s profile=%s strategy=%s decision=%s trade_ready=%s mfv=%s phase=%s',
                wait_reason,
                candidate.token_address[:12],
                decision_profile or 'unknown',
                brain_result.strategy_hint,
                str(getattr(decision, 'status', '') or '').upper(),
                decision_trade_ready,
                mfv_confirmed,
                mfv_phase or 'unknown',
            )
            record = await self.lifecycle.open_watching(
                candidate,
                wait_reason,
                float(decision.score or 0.0),
                strategy_hint=brain_result.strategy_hint,
            )
            self.session.add(
                RealtimeAlertRecord(
                    chain=candidate.chain.value,
                    token_address=candidate.token_address,
                    event_type='paper_watch_opened',
                    severity='low',
                    payload={
                        'reason': wait_reason,
                        'strategy': brain_result.strategy_hint,
                        'decision_score': float(decision.score or 0.0),
                        'decision_status': str(getattr(decision, 'status', '') or '').upper(),
                        'approved_candidate': approved_candidate,
                        'trade_ready': decision_trade_ready,
                        'trade_ready_reason': decision_trade_ready_reason or 'composite_below_trade_ready',
                        'trading_mode': trading_mode,
                        'fzr_override_applied': fzr_override_applied,
                        'mfv_rr': mfv_rr,
                        'mfv_confidence': mfv_confidence,
                        'entry_liquidity_hint': entry_liquidity_hint,
                        'mfv_phase': mfv_phase or 'unknown',
                        'mfv_confirmed': mfv_confirmed,
                        'mfv_entry_gate': mfv_entry_gate,
                        'graduated_entry': graduated_entry,
                    },
                )
            )
            return record
        trade_intent = force_trade
        import logging as _log
        _log.getLogger('pulse.flow').info(
            'pulse_decision_flow mint=%s profile=%s approved=%s trade_ready=%s strategy=%s score=%.2f status=%s mfv=%s mfv_rr=%.2f',
            candidate.token_address[:16],
            decision_profile or 'unknown',
            approved_candidate,
            decision_trade_ready,
            brain_result.strategy_hint,
            float(brain_result.continuation_score or 0.0),
            str(getattr(decision, 'status', '') or '').upper(),
            bool(abc_signal.get('mfv_confirmed') or abc_signal.get('abc_confirmed')),
            float(abc_signal.get('abc_rr') or 0.0),
        )
        if force_trade and brain_result.strategy_hint == 'skip':
            if mfv_confirmed:
                brain_result = dataclasses.replace(brain_result, strategy_hint='farm' if is_farm_approve_early else 'smart_wallet')
            else:
                brain_result = dataclasses.replace(brain_result, strategy_hint='farm' if (is_farm_approve_early or graduated_entry) else 'smart_wallet')
        # survival вимкнена: force_trade → farm або smart_wallet
        if force_trade and graduated_entry and brain_result.strategy_hint not in ('farm', 'smart_wallet'):
            brain_result = dataclasses.replace(brain_result, strategy_hint='farm' if is_farm_approve_early else 'smart_wallet')
        # Фінальний захист: якщо strategy досі 'skip' або None — не торгувати взагалі
        if brain_result.strategy_hint in ('skip', None, ''):
            return None
        if existing is not None and not force_trade and not await self.lifecycle.can_reenter(candidate, brain_result, existing):
            logger.info('pulse_entry_block reason=cannot_reenter token=%s', candidate.token_address[:12])
            return None

        if not force_trade and await self.lifecycle.is_circuit_breaker_active():
            daily_pnl = await self.lifecycle.get_daily_pnl()
            await self.alerter.on_circuit_breaker(daily_pnl)
            return None

        open_count = (
            await self.session.execute(
                select(TokenLifecycleRecord).where(TokenLifecycleRecord.status == 'paper_open')
            )
        ).scalars().all()

        min_score = float(settings.pulse_min_score_to_trade or 0.0)
        if min_score > 0 and not trade_intent and float(decision.score or 0.0) < min_score:
            logger.debug(
                'pulse_skip reason=score_below_min score=%.1f min=%.1f token=%s',
                float(decision.score or 0.0),
                min_score,
                candidate.token_address[:12],
            )
            return None

        if len(open_count) >= int(settings.paper_trading_max_open_positions):
            logger.debug(
                'pulse_skip reason=max_positions_reached open=%d max=%d token=%s',
                len(open_count),
                int(settings.paper_trading_max_open_positions),
                candidate.token_address[:12],
            )
            return None

        if not await self._check_chain_exposure(candidate.chain.value):
            logger.debug(
                'pulse_skip reason=chain_exposure_reached chain=%s token=%s',
                candidate.chain.value,
                candidate.token_address[:12],
            )
            return None

        family_key = str((candidate.raw or {}).get('token_family') or (candidate.raw or {}).get('launchpad') or '').strip().lower()
        deployer_key = str(
            getattr(candidate, 'deployer_address', None)
            or (candidate.raw or {}).get('deployer_address')
            or (candidate.raw or {}).get('creator_address')
            or (candidate.raw or {}).get('creator')
            or ''
        ).strip().lower()
        total_exposure = sum(float(p.paper_size_usd or p.remaining_size_usd or 0.0) for p in open_count)
        if total_exposure >= float(getattr(settings, 'live_max_total_exposure_usd', 500.0) or 500.0):
            logger.info('pulse_entry_block reason=total_exposure_reached exposure=%.1f max=%.1f token=%s', total_exposure, float(getattr(settings, 'live_max_total_exposure_usd', 500.0) or 500.0), candidate.token_address[:12])
            return None
        if family_key:
            family_exposure = sum(float(p.paper_size_usd or p.remaining_size_usd or 0.0) for p in open_count if str((p.execution_metadata or {}).get('token_family') or p.token_family or '').strip().lower() == family_key)
            if family_exposure >= float(getattr(settings, 'paper_max_family_exposure_usd', 150.0) or 150.0):
                logger.info('pulse_entry_block reason=family_exposure_reached family=%s exposure=%.1f max=%.1f token=%s', family_key, family_exposure, float(getattr(settings, 'paper_max_family_exposure_usd', 150.0) or 150.0), candidate.token_address[:12])
                return None
        if deployer_key:
            deployer_exposure = sum(float(p.paper_size_usd or p.remaining_size_usd or 0.0) for p in open_count if str((p.execution_metadata or {}).get('dev_wallet_address') or ((p.entry_signals or {}) if isinstance(p.entry_signals, dict) else {}).get('dev_wallet_address') or '').strip().lower() == deployer_key)
            if deployer_exposure >= float(getattr(settings, 'paper_max_deployer_exposure_usd', 120.0) or 120.0):
                logger.info('pulse_entry_block reason=deployer_exposure_reached deployer=%s exposure=%.1f max=%.1f token=%s', deployer_key, deployer_exposure, float(getattr(settings, 'paper_max_deployer_exposure_usd', 120.0) or 120.0), candidate.token_address[:12])
                return None
        strategy_key = str(brain_result.strategy_hint or '').strip().lower()
        if strategy_key:
            strategy_exposure = sum(float(p.paper_size_usd or p.remaining_size_usd or 0.0) for p in open_count if str(p.strategy or '').strip().lower() == strategy_key)
            if strategy_exposure >= float(getattr(settings, 'paper_max_strategy_exposure_usd', 250.0) or 250.0):
                logger.info('pulse_entry_block reason=strategy_exposure_reached strategy=%s exposure=%.1f max=%.1f token=%s', strategy_key, strategy_exposure, float(getattr(settings, 'paper_max_strategy_exposure_usd', 250.0) or 250.0), candidate.token_address[:12])
                return None

        # Farm strategy вже встановлена вище (через ABC gate).
        # Якщо brain ще 'skip' без ABC — залишаємо skip (не входимо без підтвердження).
        is_farm_approve = is_farm_approve_early

        if not force_trade and brain_result.strategy_hint == 'skip':
            return None

        min_score = float(settings.pulse_brain_min_continuation_score)
        if graduated_entry:
            min_score = 0.0
        elif brain_result.strategy_hint == 'farm':
            min_score = float(settings.pulse_farm_min_continuation_score)
        elif brain_result.strategy_hint == 'survival':
            min_score = float(settings.pulse_survival_min_continuation_score)
        if not force_trade and brain_result.continuation_score < min_score:
            logger.info('pulse_entry_block reason=continuation_score_too_low cont=%.3f min=%.3f token=%s', float(brain_result.continuation_score or 0.0), min_score, candidate.token_address[:12])
            return None

        blacklisted, blacklist_reason = self._is_blacklisted_candidate(candidate)
        if blacklisted:
            self.session.add(
                RealtimeAlertRecord(
                    chain=candidate.chain.value,
                    token_address=candidate.token_address,
                    event_type='paper_entry_guard_blocked',
                    severity='medium',
                    payload={'reason': blacklist_reason, 'token': candidate.token_address},
                )
            )
            return None

        dev_wallet = str(
            getattr(candidate, 'deployer_address', None)
            or getattr(candidate, 'creator_address', None)
            or (candidate.raw or {}).get('deployer_address')
            or (candidate.raw or {}).get('creator_address')
            or (candidate.raw or {}).get('creator')
            or ''
        ).strip().lower()
        wallet_reputation_score = await self.lifecycle.get_wallet_reputation_score(dev_wallet)

        entry_delay_minutes = float(getattr(settings, 'paper_entry_delay_minutes', 2.0) or 2.0)
        first_seen_at = getattr(candidate, 'first_seen_at', None)
        if first_seen_at is not None:
            if first_seen_at.tzinfo is None:
                first_seen_at = first_seen_at.replace(tzinfo=timezone.utc)
            minutes_since_first_seen = (datetime.now(timezone.utc) - first_seen_at).total_seconds() / 60.0
            if minutes_since_first_seen < entry_delay_minutes:
                logger.info('pulse_entry_block reason=entry_delay_not_elapsed elapsed=%.2f required=%.2f token=%s', minutes_since_first_seen, entry_delay_minutes, candidate.token_address[:12])
                return None

        pair_volume = (((candidate.raw or {}).get('pair') or {}).get('volume') or {})
        vol_h1 = float(pair_volume.get('h1') or (candidate.raw or {}).get('volume_h1') or 0.0)
        vol_h6 = float(pair_volume.get('h6') or (candidate.raw or {}).get('volume_h6') or 0.0)
        vol_h24 = float(pair_volume.get('h24') or (candidate.raw or {}).get('volume_h24') or 0.0)
        decay_min_ratio = float(getattr(settings, 'paper_volume_decay_ratio_min', 0.70) or 0.70)
        decay_h24_ratio = float(getattr(settings, 'paper_volume_decay_ratio_h24_min', 0.18) or 0.18)
        if not trade_intent:
            if vol_h6 > 0 and vol_h1 / vol_h6 < decay_min_ratio:
                logger.info('pulse_entry_block reason=volume_decay_h6 ratio=%.3f min=%.3f token=%s', vol_h1 / vol_h6 if vol_h6 else 0.0, decay_min_ratio, candidate.token_address[:12])
                return None
            if vol_h24 > 0 and vol_h1 / vol_h24 < decay_h24_ratio:
                logger.info('pulse_entry_block reason=volume_decay_h24 ratio=%.4f min=%.3f token=%s', vol_h1 / vol_h24 if vol_h24 else 0.0, decay_h24_ratio, candidate.token_address[:12])
                return None

        recent_momentum_pct = await self.lifecycle._recent_price_momentum_pct(candidate.chain.value, candidate.token_address, lookback_minutes=15, limit=6)
        if not trade_intent and recent_momentum_pct is not None and recent_momentum_pct >= float(getattr(settings, 'paper_fake_breakout_momentum_pct', 12.0) or 12.0):
            if float(brain_result.continuation_score or 0.0) < float(getattr(settings, 'paper_fake_breakout_continuation_floor', 0.80) or 0.80):
                logger.info('pulse_entry_block reason=fake_breakout momentum=%.2f cont=%.2f token=%s', recent_momentum_pct, float(brain_result.continuation_score or 0.0), candidate.token_address[:12])
                return None

        recent_volatility_pct = await self.lifecycle._recent_volatility_pct(candidate.chain.value, candidate.token_address)
        if not trade_intent and recent_volatility_pct is not None and recent_volatility_pct > float(getattr(settings, 'paper_max_entry_volatility_pct', 12.0) or 12.0):
            logger.info('pulse_entry_block reason=volatility_too_high vol=%.2f max=%.2f token=%s', recent_volatility_pct, float(getattr(settings, 'paper_max_entry_volatility_pct', 12.0) or 12.0), candidate.token_address[:12])
            return None

        ml_score = float(getattr(brain_result, 'ml_score', 0.0) or 0.0)
        mtf_score = float(getattr(brain_result, 'multi_timeframe_momentum_score', 0.0) or 0.0)
        onchain_score = float(getattr(brain_result, 'onchain_score', 0.0) or 0.0)
        wallet_score = float(getattr(brain_result, 'wallet_score', 0.0) or 0.0)
        if not trade_intent and ml_score < float(settings.paper_min_ml_score or 0.55):
            logger.info('pulse_entry_block reason=ml_score_too_low ml=%.3f min=%.3f token=%s', ml_score, float(settings.paper_min_ml_score or 0.55), candidate.token_address[:12])
            return None
        if not trade_intent and mtf_score < float(settings.paper_min_mtf_momentum_score or 0.35):
            logger.info('pulse_entry_block reason=mtf_score_too_low mtf=%.3f min=%.3f token=%s', mtf_score, float(settings.paper_min_mtf_momentum_score or 0.35), candidate.token_address[:12])
            return None
        if not trade_intent and wallet_reputation_score is not None and wallet_reputation_score < float(settings.paper_min_wallet_reputation_score or 35.0):
            logger.info('pulse_entry_block reason=wallet_reputation_too_low rep=%.1f min=%.1f token=%s', wallet_reputation_score, float(settings.paper_min_wallet_reputation_score or 35.0), candidate.token_address[:12])
            return None

        loss_streak, last_close_at = await self.lifecycle.get_consecutive_loss_streak(chain=candidate.chain.value, limit=10)
        if not trade_intent and loss_streak >= int(getattr(settings, 'paper_max_consecutive_losses', 3) or 3):
            if last_close_at is not None:
                elapsed_minutes = (datetime.now(timezone.utc) - last_close_at).total_seconds() / 60.0
                if elapsed_minutes < float(getattr(settings, 'paper_loss_streak_cooldown_minutes', 15) or 15):
                    logger.info('pulse_entry_block reason=loss_streak_cooldown streak=%d elapsed=%.1f token=%s', loss_streak, elapsed_minutes, candidate.token_address[:12])
                    return None

        win_streak, _ = await self.lifecycle.get_consecutive_win_streak(chain=candidate.chain.value, limit=10)
        if not trade_intent and win_streak >= int(getattr(settings, 'paper_profit_lock_win_streak', 3) or 3):
            if float(decision.score or 0.0) < float(getattr(settings, 'paper_profit_lock_min_score', 85.0) or 85.0):
                logger.info('pulse_entry_block reason=profit_lock_score win_streak=%d score=%.1f min=%.1f token=%s', win_streak, float(decision.score or 0.0), float(getattr(settings, 'paper_profit_lock_min_score', 85.0) or 85.0), candidate.token_address[:12])
                return None
            if float(brain_result.continuation_score or 0.0) < float(getattr(settings, 'paper_profit_lock_min_continuation_score', 0.60) or 0.60):
                logger.info('pulse_entry_block reason=profit_lock_continuation win_streak=%d cont=%.3f min=%.3f token=%s', win_streak, float(brain_result.continuation_score or 0.0), float(getattr(settings, 'paper_profit_lock_min_continuation_score', 0.60) or 0.60), candidate.token_address[:12])
                return None

        position_size = self._position_size_for_entry(decision, brain_result, volatility_pct=recent_volatility_pct, win_streak=win_streak, loss_streak=loss_streak, force_trade=force_trade)
        forced_floor = float(getattr(settings, 'paper_forced_trade_min_size_usd', 20.0) or 20.0)
        if fzr_override_applied:
            forced_floor = max(forced_floor * fzr_override_size_multiplier, 5.0)
        if force_trade:
            position_size = max(position_size, forced_floor)
        ml_multiplier = max(float(settings.paper_ml_size_floor or 0.80), min(float(settings.paper_ml_size_ceiling or 1.30), 0.80 + (ml_score * 0.50)))
        if wallet_reputation_score is not None:
            ml_multiplier *= max(0.75, min(1.20, 0.85 + (wallet_reputation_score / 200.0)))
        mfv_size_multiplier = 1.0
        confirmation_multiplier = 1.0
        if mfv_confirmed:
            mfv_rr = float(abc_signal.get('mfv_rr') or abc_signal.get('abc_rr') or 0.0)
            mfv_size_multiplier = min(1.20, 1.05 + min(0.15, mfv_rr * 0.03))
            confirmation_multiplier = float(getattr(brain_result, 'confirmation_multiplier', 1.0) or 1.0)
            confirmation_multiplier = max(0.50, min(1.50, confirmation_multiplier))
        position_size *= ml_multiplier * mfv_size_multiplier * confirmation_multiplier
        if fzr_override_applied:
            position_size *= fzr_override_size_multiplier

        market_regime, market_regime_multiplier = self._market_regime(
            recent_volatility_pct, float(brain_result.momentum_score or 0.0), win_streak, loss_streak
        )
        scaled_size = position_size * market_regime_multiplier
        position_size = max(scaled_size, forced_floor) if force_trade else scaled_size

        # Chain filter: перевіряємо чи chain дозволений для paper trade
        _allowed_chains = [ch.strip().lower() for ch in (settings.paper_allowed_chains or 'solana').split(',') if ch.strip()]
        _token_chain = str(getattr(candidate.chain, 'value', candidate.chain) or '').lower()
        if _allowed_chains and _token_chain not in _allowed_chains:
            events.append({'action': 'skipped', 'reason': f'chain_not_allowed:{_token_chain}', 'token': candidate.token_address})
            return events

        base_stop_loss, base_take_profit, _, _ = self.lifecycle._exit_params(brain_result.strategy_hint if brain_result.strategy_hint != 'skip' else None, volatility_pct=recent_volatility_pct)
        quality = max(
            float(brain_result.continuation_score or 0.0),
            float(brain_result.momentum_score or 0.0),
            float(decision.score or 0.0) / 100.0,
            ml_score,
            mtf_score,
            onchain_score,
            wallet_score,
            (wallet_reputation_score / 100.0) if wallet_reputation_score is not None else 0.0,
        )
        if quality >= 0.85:
            dynamic_take_profit = 35.0
        elif quality >= 0.70:
            dynamic_take_profit = 25.0
        elif quality >= 0.55:
            dynamic_take_profit = 18.0
        else:
            dynamic_take_profit = 12.0
        if recent_volatility_pct is not None:
            if recent_volatility_pct <= 4.0:
                dynamic_take_profit += 4.0
            elif recent_volatility_pct >= 15.0:
                dynamic_take_profit -= 4.0
        if brain_result.strategy_hint == 'survival':
            dynamic_take_profit = min(max(dynamic_take_profit, 10.0), 18.0)
        elif brain_result.strategy_hint == 'smart_wallet':
            dynamic_take_profit = min(max(dynamic_take_profit, 15.0), 30.0)
        else:
            dynamic_take_profit = min(max(dynamic_take_profit, 12.0), 40.0)
        if mfv_confirmed:
            confirmation_score = float(getattr(brain_result, 'confirmation_score', 0.0) or 0.0)
            current_price_hint = float(extract_price_from_candidate(candidate) or 0.0)
            mfv_cons_price = float(abc_signal.get('mfv_take_profit_conservative_price') or abc_signal.get('abc_take_profit_conservative_price') or 0.0)
            mfv_agg_price = float(abc_signal.get('mfv_take_profit_aggressive_price') or abc_signal.get('abc_take_profit_aggressive_price') or abc_signal.get('abc_take_profit') or 0.0)
            mfv_stop_price = float(abc_signal.get('mfv_stop_loss') or abc_signal.get('abc_stop_loss') or 0.0)
            mfv_cons_pct = ((mfv_cons_price - current_price_hint) / max(current_price_hint, 1e-9)) * 100.0 if mfv_cons_price > 0 and current_price_hint > 0 else 0.0
            mfv_agg_pct = ((mfv_agg_price - current_price_hint) / max(current_price_hint, 1e-9)) * 100.0 if mfv_agg_price > 0 and current_price_hint > 0 else 0.0
            mfv_stop_pct = ((mfv_stop_price - current_price_hint) / max(current_price_hint, 1e-9)) * 100.0 if mfv_stop_price > 0 and current_price_hint > 0 else 0.0
            if mfv_stop_pct < 0:
                base_stop_loss = max(base_stop_loss, mfv_stop_pct)
            if confirmation_score >= 0.75:
                dynamic_take_profit = min(dynamic_take_profit + 4.0, 45.0)
            elif confirmation_score >= 0.60:
                dynamic_take_profit = min(dynamic_take_profit + 2.0, 40.0)
            if brain_result.strategy_hint == 'survival' and mfv_cons_pct > 0:
                dynamic_take_profit = min(max(mfv_cons_pct, 10.0), 18.0)
            elif brain_result.strategy_hint == 'smart_wallet' and mfv_agg_pct > 0:
                dynamic_take_profit = min(max(mfv_agg_pct, 15.0), 32.0)
            elif brain_result.strategy_hint == 'farm' and mfv_agg_pct > 0:
                dynamic_take_profit = min(max(mfv_agg_pct, 18.0), 45.0)
            else:
                dynamic_take_profit = min(dynamic_take_profit + 2.0, 45.0)

        fee_pct = (float(settings.paper_gas_fee_usd) / max(position_size, 1e-9)) * 100.0
        rr_after_fee = max(0.0, dynamic_take_profit - fee_pct * 2.0) / max(0.01, abs(float(base_stop_loss)) + fee_pct * 2.0)
        min_rr = 2.0  # always require min 2:1 RR
        if rr_after_fee < min_rr:
            return None

        # ── DEDUP: не відкривати якщо відкривали цей токен < 5 хв тому ─────────
        _chain_str = candidate.chain.value if hasattr(candidate.chain, 'value') else str(candidate.chain)
        if not self._dedup_can_open(_chain_str, candidate.token_address):
            return None

        open_count_now = await self.lifecycle.get_open_positions()
        if len(open_count_now) >= int(settings.paper_trading_max_open_positions):
            return None
        if sum(1 for p in open_count_now if p.chain == candidate.chain.value) >= int(settings.max_positions_per_chain):
            return None

        price_payload = await self._candidate_pair_payload(candidate.chain.value, candidate.token_address, candidate.pair_address)
        base_price = (price_payload or {}).get('price') or extract_price_from_candidate(candidate)
        liquidity = (price_payload or {}).get('liquidity') or extract_liquidity_from_candidate(candidate)
        if base_price is None:
            return None

        # ── PRE-ENTRY LIQUIDITY GUARD ──────────────────────────────────────────
        # Мінімум: у 2x вище за поріг виходу — щоб не входити і одразу виходити
        _min_entry_liq = float(settings.paper_min_liquidity_exit_usd) * 2.0   # default: 60_000
        _entry_liq = float(liquidity or 0.0)
        # CRITICAL: якщо liq=None/0 — теж блокуємо (невідома ліквідність = небезпека)
        if _entry_liq < _min_entry_liq:
            return None  # ліквідність при вході занадто низька або невідома

        if force_trade and trading_mode == 'paper':
            guard = LiveGuardResult(True, 'force_trade_bypass', position_size)
        else:
            guard = await self.live_ready.guard_entry(
                requested_size_usd=position_size,
                liquidity_usd=liquidity,
                chain=candidate.chain.value,
                token_address=candidate.token_address,
                entry_delay_minutes=self._estimate_entry_delay_minutes(candidate),
                trading_mode=trading_mode,
            )
            if not guard.allowed:
                self.session.add(
                    RealtimeAlertRecord(
                        chain=candidate.chain.value,
                        token_address=candidate.token_address,
                        event_type='paper_entry_guard_blocked',
                        severity='medium',
                        payload={
                            'reason': guard.reason,
                            'requested_size_usd': position_size,
                            'trading_mode': trading_mode,
                            'fzr_override_applied': fzr_override_applied,
                        },
                    )
                )
                return None
        execution_size = float(guard.capped_size_usd or position_size)

        try:
            quote = self.execution.quote(
                side='entry',
                base_price=float(base_price),
                size_usd=execution_size,
                liquidity_usd=liquidity,
                route_used=self._best_route_label(price_payload),
            )
        except ExecutionFailed as exc:
            quote = ExecutionQuote(
                requested_size_usd=execution_size,
                filled_size_usd=execution_size,
                fill_pct=1.0,
                executed_price=float(base_price),
                latency_seconds=0,
                gas_fee_usd=float(settings.paper_gas_fee_usd),
                priority_fee_usd=0.0,
                slippage_pct=0.0,
                spread_pct=0.0,
                impact_pct=0.0,
                execution_drift_pct=0.0,
                execution_score=100.0,
                route_used='forced_fallback_route',
                chunks=1,
                failed=False,
                failure_reason=f'forced_fallback:{exc.reason}',
            )
        if quote.failed and force_trade:
            quote = ExecutionQuote(
                requested_size_usd=execution_size,
                filled_size_usd=execution_size,
                fill_pct=1.0,
                executed_price=float(base_price),
                latency_seconds=0,
                gas_fee_usd=float(settings.paper_gas_fee_usd),
                priority_fee_usd=0.0,
                slippage_pct=0.0,
                spread_pct=0.0,
                impact_pct=0.0,
                execution_drift_pct=0.0,
                execution_score=100.0,
                route_used='forced_fallback_route',
                chunks=1,
                failed=False,
                failure_reason=f'forced_fallback:{quote.failure_reason or "unknown"}',
            )
        elif quote.failed:
            await self.health.record_execution_failure('entry')
            self.session.add(
                RealtimeAlertRecord(
                    chain=candidate.chain.value,
                    token_address=candidate.token_address,
                    event_type='paper_entry_failed',
                    severity='medium',
                    payload={'reason': quote.failure_reason, 'strategy': brain_result.strategy_hint},
                )
            )
            if force_trade:
                logger.debug(
                    'pulse_entry_quote_fallback reason=%s token=%s strategy=%s',
                    quote.failure_reason or 'quote_failed',
                    candidate.token_address[:12],
                    brain_result.strategy_hint,
                )
                quote = ExecutionQuote(
                    requested_size_usd=execution_size,
                    filled_size_usd=execution_size,
                    fill_pct=1.0,
                    executed_price=float(base_price),
                    latency_seconds=0,
                    gas_fee_usd=float(settings.paper_gas_fee_usd),
                    priority_fee_usd=0.0,
                    slippage_pct=0.0,
                    spread_pct=0.0,
                    impact_pct=0.0,
                    execution_drift_pct=0.0,
                    execution_score=100.0,
                    route_used='force_trade_fallback_route',
                    chunks=1,
                    failed=False,
                    failure_reason=f'fallback:{quote.failure_reason or "unknown"}',
                )
            else:
                return None

        max_spread_pct = float(getattr(settings, 'paper_spread_max_pct', 1.0) or 1.0)
        max_slippage_pct = float(getattr(settings, 'paper_slippage_entry_pct', 2.5) or 2.5)
        max_impact_pct = float(getattr(settings, 'paper_max_order_impact_pct', 0.01) or 0.01)
        if max_impact_pct <= 1.0:
            max_impact_pct *= 100.0
        if float(quote.spread_pct or 0.0) > max_spread_pct or float(quote.slippage_pct or 0.0) > max_slippage_pct or float(quote.impact_pct or 0.0) > max_impact_pct:
            self.session.add(
                RealtimeAlertRecord(
                    chain=candidate.chain.value,
                    token_address=candidate.token_address,
                    event_type='paper_entry_guard_blocked',
                    severity='medium',
                    payload={
                        'reason': 'spread_slippage_impact_filter',
                        'spread_pct': float(quote.spread_pct or 0.0),
                        'slippage_pct': float(quote.slippage_pct or 0.0),
                        'impact_pct': float(quote.impact_pct or 0.0),
                        'trading_mode': trading_mode,
                        'fzr_override_applied': fzr_override_applied,
                    },
                )
            )
            if not force_trade:
                return None
            logger.debug(
                'pulse_entry_quality_bypass spread=%.2f slippage=%.2f impact=%.2f token=%s strategy=%s',
                float(quote.spread_pct or 0.0),
                float(quote.slippage_pct or 0.0),
                float(quote.impact_pct or 0.0),
                candidate.token_address[:12],
                brain_result.strategy_hint,
            )

        try:
            record = await self.lifecycle.open_position(
                candidate=candidate,
                decision=decision,
                brain_result=brain_result,
                bundle_data=bundle_data,
                paper_size_usd=position_size,
                requested_size_usd=position_size,
                filled_size_usd=quote.filled_size_usd,
                fill_pct=quote.fill_pct,
                entry_slippage_pct=quote.slippage_pct,
                entry_spread_pct=quote.spread_pct,
                entry_impact_pct=quote.impact_pct,
                execution_price=quote.executed_price,
                execution_latency_seconds=quote.latency_seconds,
                execution_fee_usd=quote.gas_fee_usd,
                entry_execution_drift_pct=quote.execution_drift_pct,
                entry_execution_score=quote.execution_score,
                entry_route_used=quote.route_used,
                entry_priority_fee_usd=quote.priority_fee_usd,
                execution_state='entering',
                execution_metadata={
                    'chunks': quote.chunks,
                    'failure_reason': quote.failure_reason,
                    'route_used': quote.route_used,
                    'entry_execution_drift_pct': quote.execution_drift_pct,
                    'entry_execution_score': quote.execution_score,
                    'entry_priority_fee_usd': quote.priority_fee_usd,
                    'risk_tier': (decision.evidence or {}).get('risk_tier'),
                    'safety_gate_reason': ((decision.evidence or {}).get('safety_gate') or {}).get('reason'),
                    'recent_volatility_pct': recent_volatility_pct,
                    'win_streak': win_streak,
                    'loss_streak': loss_streak,
                    'market_regime': market_regime,
                    'market_regime_multiplier': market_regime_multiplier,
                    'dynamic_take_profit_pct': dynamic_take_profit,
                    'entry_momentum_score': float(brain_result.momentum_score or 0.0),
                    'entry_continuation_score': float(brain_result.continuation_score or 0.0),
                    'ml_score': ml_score,
                    'mtf_momentum_score': mtf_score,
                    'onchain_score': onchain_score,
                    'wallet_score': wallet_score,
                    'wallet_reputation_score': wallet_reputation_score,
                    'dev_wallet_address': dev_wallet,
                    'trading_mode': trading_mode,
                    'decision_trade_ready': decision_trade_ready,
                    'decision_trade_ready_reason': decision_trade_ready_reason,
                    'fzr_override_applied': fzr_override_applied,
                    'fzr_override_size_multiplier': fzr_override_size_multiplier if fzr_override_applied else 1.0,
                    'abc_confirmed': bool(abc_signal.get('abc_confirmed')),
                    'abc_reason': abc_signal.get('abc_reason'),
                    'abc_rr': float(abc_signal.get('abc_rr') or 0.0),
                    'abc_wave': abc_signal.get('abc_wave'),
                    'mfv_confirmed': bool(abc_signal.get('mfv_confirmed')),
                    'mfv_reason': abc_signal.get('mfv_reason'),
                    'mfv_rr': float(abc_signal.get('mfv_rr') or 0.0),
                    'mfv_confirmation_score': float(getattr(brain_result, 'confirmation_score', 0.0) or 0.0),
                    'mfv_post_fzr_momentum_score': float(getattr(brain_result, 'post_fzr_momentum_score', 0.0) or 0.0),
                    'mfv_volume_expansion_score': float(getattr(brain_result, 'volume_expansion_score', 0.0) or 0.0),
                    'mfv_liquidity_flow_score': float(getattr(brain_result, 'liquidity_flow_score', 0.0) or 0.0),
                    'mfv_confirmation_multiplier': float(getattr(brain_result, 'confirmation_multiplier', 1.0) or 1.0),
                    'mfv_wave': abc_signal.get('mfv_wave'),
                },
                force_bypass=force_trade,
            )
        except Exception as exc:
            logger.warning(
                'paper_entry_error token=%s chain=%s strategy=%s error=%s',
                candidate.token_address[:12],
                candidate.chain.value,
                brain_result.strategy_hint,
                str(exc),
            )
            await self.health.record_execution_failure('entry')
            self.session.add(
                RealtimeAlertRecord(
                    chain=candidate.chain.value,
                    token_address=candidate.token_address,
                    event_type='paper_entry_error',
                    severity='high',
                    payload={'error': str(exc), 'strategy': brain_result.strategy_hint},
                )
            )
            return None

        self.session.add(
            RealtimeAlertRecord(
                chain=candidate.chain.value,
                token_address=candidate.token_address,
                event_type='paper_open',
                severity='low',
                payload={
                    'strategy': brain_result.strategy_hint,
                    'continuation_score': brain_result.continuation_score,
                    'decision_score': decision.score,
                    'entry_latency_seconds': quote.latency_seconds,
                    'entry_execution_price': quote.executed_price,
                    'ml_score': ml_score,
                    'mtf_momentum_score': mtf_score,
                    'onchain_score': onchain_score,
                    'wallet_score': wallet_score,
                    'wallet_reputation_score': wallet_reputation_score,
                    'abc_confirmed': bool(abc_signal.get('abc_confirmed')),
                    'abc_rr': float(abc_signal.get('abc_rr') or 0.0),
                    'mfv_confirmed': bool(abc_signal.get('mfv_confirmed')),
                    'mfv_rr': float(abc_signal.get('mfv_rr') or 0.0),
                },
            )
        )
        logger.info(
            'pump_telemetry event=trade_opened chain=%s mint=%s strategy=%s status=%s risk_tier=%s lot_usd=%.2f fill_pct=%.1f rr_after_fee=%.2f trade_intent=%s mfv=%s',
            candidate.chain.value,
            candidate.token_address,
            brain_result.strategy_hint,
            str(getattr(decision, 'status', '') or '').upper(),
            (decision.evidence or {}).get('risk_tier'),
            float(quote.filled_size_usd or 0.0),
            float(quote.fill_pct or 0.0) * 100.0,
            float(rr_after_fee or 0.0),
            trade_intent,
            bool(abc_signal.get('mfv_confirmed') or abc_signal.get('abc_confirmed')),
        )
        await self.live_ready.mark_state(record, 'open', 'entry_filled', {'chunks': quote.chunks})
        await self.session.flush()
        await self.alerter.on_open(record)
        await self.health.record_new_token()
        return record

    async def _check_chain_exposure(self, chain: str) -> bool:
        open_positions = await self.lifecycle.get_open_positions()
        chain_count = sum(1 for p in open_positions if p.chain == chain)
        return chain_count < int(settings.max_positions_per_chain)

    async def tick(self) -> list[dict]:
        events: list[dict] = []
        await self.health.record_tick()

        kill_until_raw = await GLOBAL_CACHE.get('pulse:paper:kill_until')
        if isinstance(kill_until_raw, str) and kill_until_raw:
            try:
                kill_until = datetime.fromisoformat(kill_until_raw)
                if kill_until.tzinfo is None:
                    kill_until = kill_until.replace(tzinfo=timezone.utc)
                if datetime.now(timezone.utc) < kill_until:
                    events.append({'action': 'paused', 'reason': 'kill_switch', 'until': kill_until.isoformat()})
                    return events
            except Exception:
                pass

        open_positions = await self.lifecycle.get_open_positions()
        watching_positions = await self.lifecycle.get_watching_positions() if settings.track_near_misses else []
        batch_payloads = await self._fetch_batch_payloads(open_positions + watching_positions)

        loss_streak, last_loss_at = await self.lifecycle.get_consecutive_loss_streak(limit=20)
        if loss_streak >= settings.paper_max_consecutive_losses:
            # Збільшуємо паузу пропорційно до streak щоб не re-arm одразу
            pause_minutes = min(10 * (loss_streak - settings.paper_max_consecutive_losses + 1), 60)
            until = datetime.now(timezone.utc) + timedelta(minutes=pause_minutes)
            await GLOBAL_CACHE.set('pulse:paper:kill_until', until.isoformat(), ttl_seconds=int(pause_minutes * 60))
            events.append({'action': 'paused', 'reason': 'kill_switch_armed', 'until': until.isoformat(), 'streak': loss_streak})
            return events

        for position in open_positions:
            price_payload = batch_payloads.get((position.chain, position.token_address))
            if price_payload is None:
                price_payload = await self._candidate_pair_payload(position.chain, position.token_address, position.pair_address)
            current_price = price_payload.get('price') if price_payload else None
            # Для Solana: Birdeye (якщо є ключ) або DexScreener fallback
            if position.chain == 'solana':
                birdeye_price = await self._get_price_birdeye(position.token_address)
                if birdeye_price is not None and birdeye_price > 0:
                    current_price = birdeye_price
                    price_payload = {
                        **(price_payload or {}),
                        'price': birdeye_price,
                        'source': 'birdeye_or_dex_fallback',
                    }
                    # Зберігаємо pair_address якщо ще не збережено в lifecycle
                    if not position.pair_address:
                        cached_pair = await GLOBAL_CACHE.get(
                            f'pulse:pair_addr:solana:{position.token_address}'
                        )
                        if cached_pair and isinstance(cached_pair, str):
                            position.pair_address = cached_pair
            if current_price is None and position.chain == 'solana':
                birdeye_price = await self._get_price_birdeye(position.token_address)
                if birdeye_price is not None and birdeye_price > 0:
                    current_price = birdeye_price
                price_payload = {'price': current_price, 'liquidity': None, 'market_cap': None} if current_price is not None else None
            if current_price is None:
                last_checked = position.last_checked_at or position.entry_at or position.first_seen_at
                last_checked_aware = last_checked.replace(tzinfo=timezone.utc) if last_checked and last_checked.tzinfo is None else last_checked
                minutes_blind = (datetime.now(timezone.utc) - last_checked_aware).total_seconds() / 60 if last_checked_aware else 9999
                if minutes_blind >= 10:
                    last_known = float(position.current_price or position.entry_price or 0.0)
                    await self.lifecycle.close_position(
                        position,
                        last_known,
                        'token_dead',
                        raw_exit_price=last_known,
                        execution_price=last_known,
                        execution_latency_seconds=0,
                        execution_fee_usd=float(settings.paper_gas_fee_usd),
                        exit_signals={'exit_reason': 'token_dead', 'minutes_blind': round(minutes_blind, 1)},
                    )
                    await self.alerter.on_close(position)
                    self.session.add(
                        RealtimeAlertRecord(
                            chain=position.chain,
                            token_address=position.token_address,
                            event_type='exit_dead',
                            severity='high',
                            payload={
                                'strategy': position.strategy,
                                'pnl_pct': position.paper_pnl_pct,
                                'pnl_usd': position.paper_pnl_usd,
                                'reason': position.exit_reason,
                            },
                        )
                    )
                    events.append({'token': position.token_address, 'action': 'exit', 'reason': 'token_dead', 'pnl_pct': float(position.paper_pnl_pct or 0.0)})
                continue

            current_liquidity = price_payload.get('liquidity') if price_payload else None
            current_holders = position.current_holders
            self.session.add(
                PriceSnapshotRecord(
                    chain=position.chain,
                    token_address=position.token_address,
                    price_usd=current_price,
                    liquidity_usd=current_liquidity,
                    holders=current_holders,
                    market_cap_usd=price_payload.get('market_cap') if price_payload else None,
                    source='dexscreener',
                )
            )

            entry_at = position.entry_at or position.first_seen_at
            if entry_at and entry_at.tzinfo is None:
                entry_at = entry_at.replace(tzinfo=timezone.utc)
            minutes_open = (datetime.now(timezone.utc) - entry_at).total_seconds() / 60.0 if entry_at else 0.0
            hard_max_hold_minutes = float(position.time_limit_minutes or 60.0)
            if minutes_open >= hard_max_hold_minutes:
                result = {'action': 'exit', 'reason': 'time_limit'}
            else:
                result = await self.lifecycle.update_position(
                    position,
                    current_price=current_price,
                    current_liquidity=current_liquidity,
                    current_holders=current_holders,
                )
            if result.get('action') == 'partial_exit':
                await self.live_ready.mark_state(position, 'partial_exit', 'partial_take_profit')
                sell_size = float(position.remaining_size_usd or position.paper_size_usd or 0.0) * float(result.get('fraction') or settings.paper_partial_tp_fraction)
                quote = self.execution.quote(
                    side='exit',
                    base_price=float(current_price),
                    size_usd=sell_size,
                    liquidity_usd=current_liquidity,
                    route_used=self._best_route_label(price_payload),
                )
                if quote.failed:
                    await self.health.record_execution_failure('partial_exit')
                    self.session.add(
                        RealtimeAlertRecord(
                            chain=position.chain,
                            token_address=position.token_address,
                            event_type='partial_exit_failed',
                            severity='medium',
                            payload={'reason': quote.failure_reason, 'token': position.token_address},
                        )
                    )
                    await self.live_ready.mark_state(position, 'open', 'partial_exit_failed')
                    events.append({'token': position.token_address, 'action': 'partial_exit_failed', 'reason': quote.failure_reason, 'pnl_pct': float(position.paper_pnl_pct or 0.0)})
                    continue
                sold_fraction = float(quote.filled_size_usd / max(sell_size, 1e-9)) if sell_size > 0 else float(result.get('fraction') or settings.paper_partial_tp_fraction)
                await self.lifecycle.apply_partial_exit(
                    position,
                    execution_price=quote.executed_price,
                    sold_fraction=sold_fraction,
                    execution_latency_seconds=quote.latency_seconds,
                    execution_fee_usd=quote.gas_fee_usd,
                    exit_slippage_pct=quote.slippage_pct,
                    exit_spread_pct=quote.spread_pct,
                    exit_impact_pct=quote.impact_pct,
                    exit_execution_drift_pct=quote.execution_drift_pct,
                    exit_execution_score=quote.execution_score,
                    exit_route_used=quote.route_used,
                    exit_priority_fee_usd=quote.priority_fee_usd,
                )
                self.session.add(
                    RealtimeAlertRecord(
                        chain=position.chain,
                        token_address=position.token_address,
                        event_type='partial_tp',
                        severity='low',
                        payload={
                            'strategy': position.strategy,
                            'pnl_pct': position.paper_pnl_pct,
                            'pnl_usd': position.paper_pnl_usd,
                            'fraction': float(result.get('fraction') or settings.paper_partial_tp_fraction),
                        },
                    )
                )
                await self.live_ready.mark_state(position, 'open', 'partial_exit_complete')
                events.append({'token': position.token_address, 'action': 'partial_exit', 'reason': result.get('reason'), 'pnl_pct': float(position.paper_pnl_pct or 0.0)})
                continue

            if result.get('action') == 'exit':
                await self.live_ready.mark_state(position, 'exiting', str(result.get('reason') or 'exit'))
                quote = self.execution.quote(
                    side='exit',
                    base_price=float(current_price),
                    size_usd=float(position.remaining_size_usd or position.paper_size_usd or 0.0),
                    liquidity_usd=current_liquidity,
                    route_used=self._best_route_label(price_payload),
                )
                if quote.failed:
                    await self.health.record_execution_failure('exit')
                    self.session.add(
                        RealtimeAlertRecord(
                            chain=position.chain,
                            token_address=position.token_address,
                            event_type='exit_failed',
                            severity='medium',
                            payload={'reason': quote.failure_reason, 'token': position.token_address},
                        )
                    )
                    await self.live_ready.mark_state(position, 'open', 'exit_failed')
                    events.append({'token': position.token_address, 'action': 'exit_failed', 'reason': quote.failure_reason, 'pnl_pct': float(position.paper_pnl_pct or 0.0)})
                    continue
                await self.lifecycle.close_position(
                    position,
                    current_price,
                    str(result.get('reason') or 'exit'),
                    raw_exit_price=current_price,
                    execution_price=quote.executed_price,
                    execution_latency_seconds=quote.latency_seconds,
                    execution_fee_usd=quote.gas_fee_usd,
                    exit_slippage_pct=quote.slippage_pct,
                    exit_spread_pct=quote.spread_pct,
                    exit_impact_pct=quote.impact_pct,
                    exit_execution_drift_pct=quote.execution_drift_pct,
                    exit_execution_score=quote.execution_score,
                    exit_route_used=quote.route_used,
                    exit_priority_fee_usd=quote.priority_fee_usd,
                    exit_signals={
                        'exit_reason': str(result.get('reason') or 'exit'),
                        'source': 'tick',
                        'chunks': quote.chunks,
                        'route_used': quote.route_used,
                        'execution_drift_pct': quote.execution_drift_pct,
                        'execution_score': quote.execution_score,
                        'priority_fee_usd': quote.priority_fee_usd,
                    },
                )
                event_type = self._exit_event_type(str(result.get('reason') or 'exit'))
                self.session.add(
                    RealtimeAlertRecord(
                        chain=position.chain,
                        token_address=position.token_address,
                        event_type=event_type,
                        severity='medium',
                        payload={
                            'strategy': position.strategy,
                            'pnl_pct': position.paper_pnl_pct,
                            'pnl_usd': position.paper_pnl_usd,
                            'reason': position.exit_reason,
                            'exit_latency_seconds': quote.latency_seconds,
                        },
                    )
                )
                await self.alerter.on_close(position)
                events.append({'token': position.token_address, 'action': 'exit', 'reason': result.get('reason') or 'exit', 'pnl_pct': float(position.paper_pnl_pct or 0.0)})
                continue
            else:
                entry_continuation = float((position.execution_metadata or {}).get('entry_continuation_score') or 0.0)
                entry_momentum = float((position.execution_metadata or {}).get('entry_momentum_score') or 0.0)
                stack_score_ok = float(position.paper_pnl_pct or 0.0) >= 3.0 and entry_continuation >= 0.75 and entry_momentum >= 0.60
                if stack_score_ok and float(position.remaining_size_usd or 0.0) > 0:
                    add_size = min(
                        float(position.paper_size_usd or 0.0) * 0.5,
                        float(settings.paper_trading_position_size_usd) * 0.5,
                        float(getattr(settings, 'paper_max_stack_add_usd', 50.0) or 50.0),
                    )
                    if add_size > 0:
                        quote = self.execution.quote(
                            side='entry',
                            base_price=float(current_price),
                            size_usd=add_size,
                            liquidity_usd=current_liquidity,
                            route_used=self._best_route_label(price_payload),
                        )
                        if not quote.failed:
                            await self.lifecycle.apply_stack_addition(
                                position,
                                execution_price=quote.executed_price,
                                add_size_usd=quote.filled_size_usd,
                                execution_latency_seconds=quote.latency_seconds,
                                execution_fee_usd=quote.gas_fee_usd,
                                entry_slippage_pct=quote.slippage_pct,
                                entry_spread_pct=quote.spread_pct,
                                entry_impact_pct=quote.impact_pct,
                                entry_execution_drift_pct=quote.execution_drift_pct,
                                entry_execution_score=quote.execution_score,
                                entry_route_used=quote.route_used,
                                entry_priority_fee_usd=quote.priority_fee_usd,
                                entry_signals={
                                    'stacked': True,
                                    'source': 'tick',
                                    'chunks': quote.chunks,
                                    'route_used': quote.route_used,
                                    'execution_drift_pct': quote.execution_drift_pct,
                                    'execution_score': quote.execution_score,
                                    'priority_fee_usd': quote.priority_fee_usd,
                                },
                            )
                            self.session.add(
                                RealtimeAlertRecord(
                                    chain=position.chain,
                                    token_address=position.token_address,
                                    event_type='stack_add',
                                    severity='low',
                                    payload={'strategy': position.strategy, 'added_usd': quote.filled_size_usd, 'pnl_pct': position.paper_pnl_pct},
                                )
                            )
                            events.append({'token': position.token_address, 'action': 'stack', 'reason': 'momentum_stack', 'pnl_pct': float(position.paper_pnl_pct or 0.0)})
                            continue
                dev_reason = await self._maybe_dev_wallet_exit(position)
                if dev_reason:
                    await self.live_ready.mark_state(position, 'exiting', dev_reason)
                    quote = self.execution.quote(
                    side='exit',
                    base_price=float(current_price),
                    size_usd=float(position.remaining_size_usd or position.paper_size_usd or 0.0),
                    liquidity_usd=current_liquidity,
                    route_used=self._best_route_label(price_payload),
                )
                    if quote.failed:
                        await self.health.record_execution_failure('exit')
                        self.session.add(
                            RealtimeAlertRecord(
                                chain=position.chain,
                                token_address=position.token_address,
                                event_type='exit_failed',
                                severity='high',
                                payload={'reason': quote.failure_reason, 'token': position.token_address, 'trigger': dev_reason},
                            )
                        )
                        await self.live_ready.mark_state(position, 'open', 'exit_failed')
                        events.append({'token': position.token_address, 'action': 'exit_failed', 'reason': quote.failure_reason, 'pnl_pct': float(position.paper_pnl_pct or 0.0)})
                        continue
                    await self.lifecycle.close_position(
                        position,
                        current_price,
                        dev_reason,
                        raw_exit_price=current_price,
                        execution_price=quote.executed_price,
                        execution_latency_seconds=quote.latency_seconds,
                        execution_fee_usd=quote.gas_fee_usd,
                        exit_slippage_pct=quote.slippage_pct,
                        exit_spread_pct=quote.spread_pct,
                        exit_impact_pct=quote.impact_pct,
                        exit_execution_drift_pct=quote.execution_drift_pct,
                        exit_execution_score=quote.execution_score,
                        exit_route_used=quote.route_used,
                        exit_priority_fee_usd=quote.priority_fee_usd,
                        exit_signals={
                            'exit_reason': dev_reason,
                            'source': 'dev_wallet_monitor',
                            'chunks': quote.chunks,
                            'route_used': quote.route_used,
                            'execution_drift_pct': quote.execution_drift_pct,
                            'execution_score': quote.execution_score,
                            'priority_fee_usd': quote.priority_fee_usd,
                        },
                    )
                    self.session.add(
                        RealtimeAlertRecord(
                            chain=position.chain,
                            token_address=position.token_address,
                            event_type='exit_dev_wallet',
                            severity='high',
                            payload={
                                'strategy': position.strategy,
                                'pnl_pct': position.paper_pnl_pct,
                                'pnl_usd': position.paper_pnl_usd,
                                'reason': dev_reason,
                                'exit_latency_seconds': quote.latency_seconds,
                            },
                        )
                    )
                    await self.alerter.on_close(position)
                    result = {'action': 'exit', 'reason': dev_reason}
                    events.append({'token': position.token_address, 'action': 'exit', 'reason': dev_reason, 'pnl_pct': float(position.paper_pnl_pct or 0.0)})
            # event already appended in the specific exit / partial_exit / hold branch above

        for position in watching_positions:
            price_payload = batch_payloads.get((position.chain, position.token_address))
            if price_payload is None:
                price_payload = await self._candidate_pair_payload(position.chain, position.token_address, position.pair_address)
            current_price = price_payload.get('price') if price_payload else None
            if current_price is None and position.chain == 'solana':
                current_price = await self._get_price_birdeye(position.token_address)
            # Останній fallback — DexScreener прямо по token address (без pair_address)
            if current_price is None:
                try:
                    _fb_payload = await self._candidate_pair_payload(position.chain, position.token_address, None)
                    if _fb_payload:
                        current_price = _fb_payload.get('price')
                        if price_payload is None:
                            price_payload = _fb_payload
                        # Кешуємо pair_address якщо знайшли
                        _found_pair = _fb_payload.get('pair_address')
                        if current_price and _found_pair and not position.pair_address:
                            position.pair_address = _found_pair
                except Exception:
                    pass
            # ── ТАЙМАУТ без ціни: навіть якщо ціни немає — перевіряємо таймаут ──
            _ws_ts = position.first_seen_at or position.created_at
            if current_price is None and _ws_ts is not None:
                _ws2 = _ws_ts.replace(tzinfo=timezone.utc) if _ws_ts.tzinfo is None else _ws_ts
                _age_min = (datetime.now(timezone.utc) - _ws2).total_seconds() / 60.0
                _liq_now = float(position.current_liquidity_usd or 0.0)
                _timeout_min = 120.0 if _liq_now >= 50_000.0 else 45.0
                if _age_min > _timeout_min:
                    position.status = 'paper_closed'
                    position.exit_reason = 'watching_timeout_no_price'
                    position.exit_at = datetime.now(timezone.utc)
                    position.updated_at = datetime.now(timezone.utc)
                    self.session.add(position)
                    await self.session.flush()
                continue
            current_liquidity = price_payload.get('liquidity') if price_payload else None
            position.current_price = current_price
            position.current_liquidity_usd = current_liquidity
            position.last_checked_at = datetime.now(timezone.utc)
            position.updated_at = datetime.now(timezone.utc)
            # Зберігаємо snapshot щоб ABCDetector міг накопичити тіки
            self.session.add(
                PriceSnapshotRecord(
                    chain=position.chain,
                    token_address=position.token_address,
                    price_usd=current_price,
                    liquidity_usd=current_liquidity,
                    holders=position.current_holders,
                    market_cap_usd=price_payload.get('market_cap') if price_payload else None,
                    source='watching_tick',
                )
            )
            await self.session.flush()
            recent_snapshots = await self._recent_price_snapshots_for_token(position.chain, position.token_address)

            promoted = None
            try:
                promoted = await self._reevaluate_watching_position(
                    position,
                    current_price=current_price,
                    current_liquidity=current_liquidity,
                    current_holders=position.current_holders,
                    snapshots=recent_snapshots,
                )
            except Exception as exc:
                logger.debug('watching_reeval_failed token=%s err=%s', position.token_address[:12], exc)

            if promoted is not None:
                self._dedup_register_open(position.chain, position.token_address)
                events.append({'token': position.token_address, 'action': 'open', 'reason': 'mfv_confirmed_after_watch', 'pnl_pct': 0.0})
                continue

            entry_price = float(position.entry_price or 0.0)
            if entry_price > 0:
                peak_price = float(position.peak_price or entry_price)
                if current_price > peak_price:
                    position.peak_price = current_price
                    peak_price = current_price
                peak_gain_pct = ((peak_price - entry_price) / entry_price) * 100.0
                _entry_dt = position.entry_at or position.first_seen_at
                if _entry_dt and _entry_dt.tzinfo is None:
                    _entry_dt = _entry_dt.replace(tzinfo=timezone.utc)
                hours_old = (datetime.now(timezone.utc) - _entry_dt).total_seconds() / 3600.0 if _entry_dt else 0.0
                if hours_old >= float(settings.near_miss_watch_hours) and peak_gain_pct >= float(settings.near_miss_threshold_pct):
                    position.exit_reason = f'near_miss_{peak_gain_pct:.0f}pct'
                if hours_old >= float(settings.near_miss_watch_hours):
                    position.status = 'expired'
            events.append({'token': position.token_address, 'action': 'watch', 'reason': position.exit_reason, 'pnl_pct': 0.0})

        events.append({
            'token': '__summary__',
            'action': 'analytics',
            'reason': 'paper_trading_tick_summary',
            'pnl_pct': 0.0,
            'open_positions': len(open_positions),
            'watching_positions': len(watching_positions),
            'events_before_summary': len(events),
        })
        await self.session.flush()
        return events

    async def refresh_open_position_prices(self, positions: list[TokenLifecycleRecord]) -> int:
        """Refresh current_price/current_liquidity for open positions without running exits."""
        open_positions = [p for p in positions if getattr(p, 'status', None) == 'paper_open']
        if not open_positions:
            return 0

        batch_payloads = await self._fetch_batch_payloads(open_positions)
        refreshed = 0
        now = datetime.now(timezone.utc)

        for position in open_positions:
            price_payload = batch_payloads.get((position.chain, position.token_address))
            if price_payload is None:
                price_payload = await self._candidate_pair_payload(position.chain, position.token_address, position.pair_address)

            current_price = price_payload.get('price') if price_payload else None
            if position.chain == 'solana':
                birdeye_price = await self._get_price_birdeye(position.token_address)
                if birdeye_price is not None and birdeye_price > 0:
                    current_price = birdeye_price
                    price_payload = {**(price_payload or {}), 'price': birdeye_price, 'source': 'birdeye_or_dex_fallback'}

            if current_price is None:
                continue

            position.current_price = float(current_price)
            position.current_liquidity_usd = price_payload.get('liquidity') if price_payload else None
            position.last_checked_at = now
            position.updated_at = now

            entry_price = float(position.entry_price or 0.0)
            if entry_price > 0:
                peak_price = float(position.peak_price or entry_price)
                if current_price > peak_price:
                    position.peak_price = current_price

            refreshed += 1

        await self.session.flush()
        return refreshed

    async def _fetch_batch_payloads(self, positions: list[TokenLifecycleRecord]) -> dict[tuple[str, str], dict[str, Any]]:
        payloads: dict[tuple[str, str], dict[str, float | None]] = {}
        if not settings.pulse_price_batch_enabled:
            return payloads
        by_chain: dict[str, list[str]] = {}
        for position in positions:
            if position.token_address:
                by_chain.setdefault(position.chain, []).append(position.token_address)
        for chain, addresses in by_chain.items():
            key = f"pulse:dex_batch:{chain}:{','.join(sorted(dict.fromkeys(addresses)))}"
            cached = await GLOBAL_CACHE.get(key)
            if isinstance(cached, dict):
                for addr, pair in cached.items():
                    if isinstance(pair, dict):
                        payloads[(chain, addr)] = pair
                continue
            try:
                batch = await self.dex.token_pairs_batch(chain, addresses)
                if batch:
                    await self.health.reset_dex_errors()
                    cached_payload = {addr: self._pair_to_payload(pair) for addr, pair in batch.items()}
                    await GLOBAL_CACHE.set(key, cached_payload, ttl_seconds=15)
                    for addr, pair in cached_payload.items():
                        payloads[(chain, addr)] = pair
                else:
                    await self.health.record_dex_error()
            except Exception:
                await self.health.record_dex_error()
        return payloads

    async def _candidate_pair_payload(
        self,
        chain: str,
        token_address: str,
        pair_address: str | None,
    ) -> dict[str, Any] | None:
        cache_key = f'pulse:dex_pair:{chain}:{token_address}:{pair_address or "-"}'
        cached = await GLOBAL_CACHE.get(cache_key)
        if isinstance(cached, dict):
            return cached
        _dex_headers = {
            'User-Agent': (
                'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                'AppleWebKit/537.36 (KHTML, like Gecko) '
                'Chrome/124.0.0.0 Safari/537.36'
            ),
            'Accept': 'application/json, text/plain, */*',
            'Origin': 'https://dexscreener.com',
        }
        try:
            data = await HttpClient().get_json(
                f'{settings.dexscreener_base_url.rstrip("/")}/latest/dex/tokens/{token_address}',
                headers=_dex_headers,
                timeout=8,
            )
        except Exception:
            await self.health.record_dex_error()
            return None
        pairs = data.get('pairs') if isinstance(data, dict) else None
        if not isinstance(pairs, list) or not pairs:
            await self.health.record_dex_error()
            return None
        pair = None
        if pair_address:
            pair = next(
                (p for p in pairs if str(p.get('pairAddress') or '').lower() == pair_address.lower()),
                None,
            )
        if pair is None:
            pair = pairs[0]
        payload = self._pair_to_payload(pair)
        await GLOBAL_CACHE.set(cache_key, payload, ttl_seconds=15)
        return payload

    @staticmethod
    def _pair_to_payload(pair: dict[str, Any]) -> dict[str, float | None | str]:
        return {
            'price': PaperTrader._to_float(pair.get('priceUsd')),
            'liquidity': PaperTrader._to_float((pair.get('liquidity') or {}).get('usd')),
            'market_cap': PaperTrader._to_float(pair.get('marketCap') or pair.get('fdv')),
            'route_used': PaperTrader._route_used_from_pair(pair),
        }

    async def _maybe_dev_wallet_exit(self, position: TokenLifecycleRecord) -> str | None:
        if not settings.pulse_dev_wallet_monitor_enabled:
            return None
        signals = position.entry_signals or {}
        wallet = signals.get('dev_wallet_address') or signals.get('dev_wallet') or signals.get('creator_wallet') or signals.get('deployer_wallet')
        if not wallet:
            return None
        cache_key = f'pulse:devdump:{position.chain}:{position.token_address}:{wallet}'
        cached = await GLOBAL_CACHE.get(cache_key)
        if cached is not None:
            return str(cached) if cached else None
        try:
            if position.chain == 'solana':
                if await self._solana_dev_wallet_sold(wallet, position.token_address):
                    await GLOBAL_CACHE.set(cache_key, 'dev_wallet_dump', ttl_seconds=int(settings.pulse_dev_wallet_sell_alert_ttl_seconds))
                    return 'dev_wallet_dump'
            elif position.chain in {'ethereum', 'base', 'bsc'}:
                if await self._evm_dev_wallet_sold(wallet, position.pair_address or signals.get('pair_address')):
                    await GLOBAL_CACHE.set(cache_key, 'dev_wallet_dump', ttl_seconds=int(settings.pulse_dev_wallet_sell_alert_ttl_seconds))
                    return 'dev_wallet_dump'
        except Exception:
            return None
        return None

    async def _evm_dev_wallet_sold(self, wallet: str, pair_address: str | None) -> bool:
        if not pair_address:
            return False
        from app.models.token import Chain
        for chain in (Chain.ETHEREUM, Chain.BASE, Chain.BSC):
            txs = await self.evm.get_normal_transactions(chain, wallet, offset=20, sort='desc')
            for tx in txs:
                if str(tx.get('to') or '').lower() == pair_address.lower():
                    return True
        return False

    async def _solana_dev_wallet_sold(self, wallet: str, mint: str) -> bool:
        signatures = await self.solana.get_signatures_for_address(wallet, limit=12)
        txs = await self.solana.get_transactions([row.get('signature') for row in signatures if row.get('signature')][:12])
        for tx in txs:
            meta = tx.get('meta') if isinstance(tx, dict) else None
            if not isinstance(meta, dict):
                continue
            pre = meta.get('preTokenBalances') or []
            post = meta.get('postTokenBalances') or []
            pre_amount = self._solana_owner_token_amount(pre, wallet, mint)
            post_amount = self._solana_owner_token_amount(post, wallet, mint)
            if pre_amount is not None and post_amount is not None and post_amount < pre_amount:
                return True
        return False

    @staticmethod
    def _solana_owner_token_amount(balances: list[dict[str, Any]], owner: str, mint: str) -> float | None:
        for row in balances:
            if str(row.get('mint') or '').lower() != mint.lower():
                continue
            if str(row.get('owner') or '').lower() != owner.lower():
                continue
            ui = row.get('uiTokenAmount') or {}
            amount = ui.get('uiAmount') if isinstance(ui, dict) else None
            if amount is None and isinstance(ui, dict):
                raw_amt = ui.get('amount')
                try:
                    amount = float(raw_amt) / (10 ** int(ui.get('decimals') or 0)) if raw_amt is not None else None
                except Exception:
                    amount = None
            try:
                return float(amount) if amount is not None else None
            except Exception:
                return None
        return None

    async def _get_price_birdeye(self, token_address: str) -> float | None:
        # Спроба 1: Birdeye (якщо увімкнено і є API ключ)
        if settings.enable_birdeye:
            try:
                from app.adapters.birdeye import BirdeyeClient
                client = BirdeyeClient()
                overview = await client.token_overview(token_address)
                if overview:
                    price = overview.get('price') or overview.get('priceUsd')
                    result = self._to_float(price)
                    if result and result > 0:
                        return result
            except Exception:
                pass

        # Спроба 2: DexScreener fallback (завжди безкоштовно)
        try:
            cache_key = f'pulse:price_fallback:solana:{token_address}'
            cached = await GLOBAL_CACHE.get(cache_key)
            if isinstance(cached, float) and cached > 0:
                return cached

            data = await HttpClient().get_json(
                f'{settings.dexscreener_base_url.rstrip("/")}/latest/dex/tokens/{token_address}',
                timeout=8,
            )
            pairs = data.get('pairs') if isinstance(data, dict) else None
            if isinstance(pairs, list) and pairs:
                # Беремо пару з найбільшою ліквідністю
                best = max(
                    pairs,
                    key=lambda p: float((p.get('liquidity') or {}).get('usd') or 0),
                    default=pairs[0],
                )
                price = self._to_float(best.get('priceUsd'))
                if price and price > 0:
                    # Зберігаємо pair_address в кеші для майбутніх запитів
                    await GLOBAL_CACHE.set(cache_key, price, ttl_seconds=15)
                    pair_addr = best.get('pairAddress')
                    if pair_addr:
                        await GLOBAL_CACHE.set(
                            f'pulse:pair_addr:solana:{token_address}',
                            pair_addr,
                            ttl_seconds=300,
                        )
                    return price
        except Exception:
            pass

        return None

    def _position_size_for_entry(
        self,
        decision: Decision,
        brain_result,
        volatility_pct: float | None = None,
        win_streak: int = 0,
        loss_streak: int = 0,
        force_trade: bool = False,
    ) -> float:
        base = float(settings.paper_trading_position_size_usd)
        score = float(decision.score or 0.0)
        if score < 80.0:
            score_factor = 0.5
        elif score < 90.0:
            score_factor = 1.0
        else:
            score_factor = 1.5

        strategy_multiplier = {
            'farm': 0.75,
            'survival': 1.0,
            'smart_wallet': 0.65,
        }.get(str(brain_result.strategy_hint or ''), 1.0)

        regime, regime_multiplier = self._market_regime(volatility_pct, float(brain_result.momentum_score or 0.0), win_streak, loss_streak)
        if regime == 'profit_lock':
            regime_multiplier *= 1.15

        if win_streak >= int(getattr(settings, 'paper_profit_lock_win_streak', 3) or 3):
            min_score = float(getattr(settings, 'paper_profit_lock_min_score', 85.0) or 85.0)
            min_cont = float(getattr(settings, 'paper_profit_lock_min_continuation_score', 0.60) or 0.60)
            if score >= min_score and float(brain_result.continuation_score or 0.0) >= min_cont:
                regime_multiplier *= float(getattr(settings, 'paper_profit_lock_high_quality_multiplier', 1.25) or 1.25)
            else:
                regime_multiplier *= float(getattr(settings, 'paper_profit_lock_low_quality_multiplier', 0.75) or 0.75)

        risk_tier = str((decision.evidence or {}).get('risk_tier') or '').upper().strip()
        tier_multiplier = risk_size_multiplier(risk_tier)
        floor = 20.0 if force_trade else 10.0
        return max(floor, base * score_factor * strategy_multiplier * regime_multiplier * tier_multiplier)

    async def get_price_from_dexscreener(
        self, chain: str, token_address: str, pair_address: str | None
    ) -> float | None:
        payload = await self._candidate_pair_payload(chain, token_address, pair_address)
        return payload.get('price') if payload else None

    @staticmethod
    def _route_used_from_pair(pair: dict[str, Any] | None) -> str | None:
        if not isinstance(pair, dict):
            return None
        dex_id = str(pair.get('dexId') or '').strip()
        pair_address = str(pair.get('pairAddress') or '').strip()
        if dex_id or pair_address:
            return ':'.join([part for part in (dex_id or 'dex', pair_address or 'pair') if part])
        return None

    def _best_route_label(self, price_payload: dict[str, Any] | None) -> str:
        if not isinstance(price_payload, dict):
            return 'simulated_route'
        route = price_payload.get('route_used')
        if route:
            return str(route)
        return 'simulated_route'

    @staticmethod
    def _estimate_entry_delay_minutes(candidate: TokenCandidate) -> float | None:
        raw = candidate.raw or {}
        value = raw.get('graduated_at') or raw.get('graduation_at') or ((raw.get('pair') or {}).get('pairCreatedAt'))
        if value is None:
            return None
        try:
            if isinstance(value, (int, float)):
                # DexScreener style timestamps are ms since epoch.
                ts = float(value) / 1000.0 if float(value) > 10_000_000_000 else float(value)
                from datetime import datetime, timezone
                dt = datetime.fromtimestamp(ts, tz=timezone.utc)
            else:
                from datetime import datetime, timezone
                txt = str(value).strip()
                if txt.isdigit():
                    ts = float(txt) / 1000.0 if len(txt) > 10 else float(txt)
                    dt = datetime.fromtimestamp(ts, tz=timezone.utc)
                else:
                    dt = datetime.fromisoformat(txt.replace('Z', '+00:00'))
                    if dt.tzinfo is None:
                        dt = dt.replace(tzinfo=timezone.utc)
            return max(0.0, (datetime.now(timezone.utc) - dt).total_seconds() / 60.0)
        except Exception:
            return None

    @staticmethod
    def _to_float(value: Any) -> float | None:
        try:
            if value is None or value == '':
                return None
            return float(value)
        except Exception:
            return None

    @staticmethod
    def _exit_event_type(reason: str) -> str:
        mapping = {
            'take_profit': 'exit_tp',
            'stop_loss': 'exit_sl',
            'trailing_stop': 'exit_trailing',
            'break_even_lock': 'exit_break_even',
            'time_limit': 'exit_time',
            'liquidity_collapse': 'exit_liquidity',
            'holders_dump': 'exit_holders',
            'token_dead': 'exit_dead',
            'stagnation': 'exit_stagnation',
            'partial_take_profit': 'partial_tp',
            'dev_wallet_dump': 'exit_dev_wallet',
        }
        return mapping.get(reason, 'exit')
