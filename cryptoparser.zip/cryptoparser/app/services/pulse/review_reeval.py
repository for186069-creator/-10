from __future__ import annotations

import logging
import os
import re
from datetime import datetime, timedelta, timezone

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.db.models import ManualReviewRecord, TokenCandidateRecord
from app.models.token import BehaviorProfile, Chain, Decision, SecurityReport, SocialProfile, TokenCandidate, WebsiteProfile
from app.services.pulse.brain import BrainResult
from app.services.pulse.lifecycle import LifecycleService, fetch_price_from_dexscreener
from app.services.pulse.blacklist_store import PulseBlacklistStore

logger = logging.getLogger(__name__)

_BLACKLIST_STORE = PulseBlacklistStore()

def _is_blacklisted_candidate(candidate: TokenCandidate) -> tuple[bool, str | None]:
    decision = _BLACKLIST_STORE.match(candidate)
    return decision.blacklisted, decision.reason


class ReviewReEvaluator:
    MIN_AGE_MINUTES = 20
    MAX_AGE_HOURS = 4

    def __init__(self, session: AsyncSession):
        self.session = session
        self.lifecycle = LifecycleService(session)
        self.blacklist = _BLACKLIST_STORE

    async def run(self) -> int:
        now = datetime.now(timezone.utc)
        min_age = now - timedelta(minutes=self.MIN_AGE_MINUTES)
        max_age = now - timedelta(hours=self.MAX_AGE_HOURS)
        result = await self.session.execute(
            select(ManualReviewRecord).where(
                ManualReviewRecord.status == 'OPEN',
                ManualReviewRecord.created_at <= min_age,
                ManualReviewRecord.created_at >= max_age,
            ).limit(20)
        )
        reviews = list(result.scalars().all())
        count = 0
        for review in reviews:
            outcome = await self._reeval_one(review)
            review.status = outcome
            review.updated_at = now
            count += 1
        await self.session.flush()
        return count

    async def _reeval_one(self, review: ManualReviewRecord) -> str:
        candidate = await self._load_candidate(review.chain, review.token_address)
        current_price = await fetch_price_from_dexscreener(review.token_address)
        if current_price is None:
            return 'EXPIRED'

        liquidity = candidate.liquidity_usd if candidate else None
        if liquidity is not None and liquidity < 1000:
            return 'EXPIRED'

        continuation_score = 0.45
        if liquidity is not None:
            if liquidity >= 50_000:
                continuation_score += 0.20
            elif liquidity >= 10_000:
                continuation_score += 0.10
            else:
                continuation_score += 0.05
        if candidate and candidate.holders is not None:
            if candidate.holders >= 200:
                continuation_score += 0.10
            elif candidate.holders >= 50:
                continuation_score += 0.05
        continuation_score = min(1.0, continuation_score)

        if continuation_score < 0.55:
            return 'OPEN'

        if candidate is None:
            candidate = TokenCandidate(chain=review.chain, token_address=review.token_address)

        decision = Decision(
            status='APPROVE',
            score=max(40.0, continuation_score * 100.0),
            reasons=['review_reeval:live_price_ok'],
            subscores={'review_reeval': continuation_score},
            evidence={'review_reeval': {'current_price': current_price, 'liquidity': liquidity}},
        )
        brain_result = BrainResult(
            continuation_score=continuation_score,
            survival_score=min(1.0, continuation_score + 0.05),
            momentum_score=continuation_score,
            quality_score=continuation_score,
            decay_penalty=0.0,
            strategy_hint='farm' if (liquidity or 0) >= 50_000 else 'farm',
            confidence=continuation_score,
            signals=['review_reeval'],
            breakdown={'review_reeval': continuation_score},
        )

        min_score = float(settings.pulse_min_score_to_trade or 0.0)
        if min_score > 0 and float(decision.score or 0.0) < min_score:
            return 'OPEN'
        blacklisted, _blacklist_reason = _is_blacklisted_candidate(candidate)
        if blacklisted:
            return 'OPEN'
        loss_streak, last_close_at = await self.lifecycle.get_consecutive_loss_streak(chain=candidate.chain.value, limit=10)
        if loss_streak >= int(getattr(settings, 'paper_max_consecutive_losses', 3) or 3):
            if last_close_at is not None:
                elapsed_minutes = (datetime.now(timezone.utc) - last_close_at).total_seconds() / 60.0
                if elapsed_minutes < float(getattr(settings, 'paper_loss_streak_cooldown_minutes', 15) or 15):
                    return 'OPEN'
        win_streak, _ = await self.lifecycle.get_consecutive_win_streak(chain=candidate.chain.value, limit=10)
        if win_streak >= int(getattr(settings, 'paper_profit_lock_win_streak', 3) or 3):
            if float(decision.score or 0.0) < float(getattr(settings, 'paper_profit_lock_min_score', 85.0) or 85.0):
                return 'OPEN'
            if float(brain_result.continuation_score or 0.0) < float(getattr(settings, 'paper_profit_lock_min_continuation_score', 0.60) or 0.60):
                return 'OPEN'
        open_positions = await self.lifecycle.get_open_positions()
        if len(open_positions) >= int(settings.paper_trading_max_open_positions):
            return 'OPEN'
        chain_count = sum(1 for p in open_positions if p.chain == candidate.chain.value)
        if chain_count >= int(settings.max_positions_per_chain):
            return 'OPEN'

        await self.lifecycle.open_position(
            candidate=candidate,
            decision=decision,
            brain_result=brain_result,
            bundle_data={},
            paper_size_usd=float(settings.paper_trading_position_size_usd),
        )
        return 'REVIEWED'

    async def _load_candidate(self, chain: str, token_address: str) -> TokenCandidate | None:
        result = await self.session.execute(
            select(TokenCandidateRecord).where(
                TokenCandidateRecord.chain == chain,
                TokenCandidateRecord.token_address == token_address,
            )
        )
        row = result.scalar_one_or_none()
        if row is None:
            return None
        return TokenCandidate(
            chain=Chain(row.chain),
            token_address=row.token_address,
            pair_address=row.pair_address,
            symbol=row.symbol,
            name=row.name,
            deployer_address=row.deployer_address,
            first_seen_at=row.first_seen_at,
            liquidity_usd=row.liquidity_usd,
            holders=row.holders,
            website=row.website,
            x_handle=row.x_handle,
            telegram_url=row.telegram_url,
            raw=row.raw or {},
        )
