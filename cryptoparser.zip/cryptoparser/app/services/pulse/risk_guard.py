from __future__ import annotations

from typing import Any

from app.core.config import settings

HARD_BLOCK_PREFIXES: tuple[str, ...] = (
    'cannot_sell',
    'honeypot',
    'lp_not_locked',
    'owner_not_renounced',
    'proxy_contract',
    'mint_enabled',
    'blacklist_function_present',
    'pause_function_present',
    'owner_can_change_fee',
    'owner_can_block_wallets',
    'mint_authority_exists',
    'freeze_authority_exists',
    'creator_wallet_malicious',
    'scam_contract_similarity',
    'malicious_wallet_cluster',
    'wash_trading_detected',
    'rug_risk',
)

SOFT_REASON_PREFIXES: tuple[str, ...] = (
    'low_',
    'missing_',
    'domain_',
    'website_',
    'x_',
    'holder_concentration',
    'bundled_buy_detected',
    'deployer_reputation_too_low',
    'cross_chain_match_risk',
    'decay_',
)


def _flatten_reasons(items: list[Any] | None) -> list[str]:
    out: list[str] = []
    for item in items or []:
        if isinstance(item, str) and item.strip():
            out.append(item.strip())
    return out


def collect_signal_reasons(decision: Any, extra_reasons: list[str] | None = None) -> list[str]:
    reasons: list[str] = []
    if getattr(decision, 'reasons', None):
        reasons.extend(_flatten_reasons(list(getattr(decision, 'reasons', []) or [])))
    evidence = getattr(decision, 'evidence', None) or {}
    if isinstance(evidence, dict):
        for key in ('security_reasons', 'social_reasons', 'website_reasons', 'behavior_reasons', 'advisory_reasons'):
            reasons.extend(_flatten_reasons(evidence.get(key) if isinstance(evidence.get(key), list) else []))
    reasons.extend(_flatten_reasons(extra_reasons))
    dedup: list[str] = []
    seen: set[str] = set()
    for reason in reasons:
        if reason not in seen:
            seen.add(reason)
            dedup.append(reason)
    return dedup


def hard_block_reason(reasons: list[str], flags: dict[str, Any] | None = None, holders: int | None = None) -> str | None:
    flags = flags or {}
    if bool(settings.paper_hard_block_unknown_holders) and (holders is None or int(holders or 0) <= 0):
        return 'holders_unknown'
    for reason in reasons:
        normalized = reason.lower()
        if any(normalized.startswith(prefix) for prefix in HARD_BLOCK_PREFIXES):
            return reason
    if bool(flags.get('honeypot')):
        return 'honeypot_flag'
    if bool(flags.get('rug_risk')):
        return 'rug_risk_flag'
    if bool(flags.get('blacklist')):
        return 'blacklist_flag'
    buy_tax = float(flags.get('buy_tax') or 0.0)
    sell_tax = float(flags.get('sell_tax') or 0.0)
    if buy_tax > 0.0 or sell_tax > 0.0:
        return f'tax_too_high buy={buy_tax:.2f} sell={sell_tax:.2f}'
    return None


def risk_tier(score: float, reasons: list[str], hard_block: str | None = None) -> str:
    if hard_block:
        return 'C'
    soft_flags = 0
    for reason in reasons:
        normalized = reason.lower()
        if normalized.startswith(('pre_gate:', 'pulse_gate:')):
            continue
        if any(normalized.startswith(prefix) for prefix in SOFT_REASON_PREFIXES):
            soft_flags += 1
    if score >= float(settings.paper_risk_tier_a_min_score) and soft_flags == 0:
        return 'A'
    if score >= float(settings.paper_risk_tier_b_min_score) and soft_flags <= int(settings.paper_risk_tier_b_max_soft_reasons):
        return 'B'
    return 'C'


def risk_size_multiplier(tier: str) -> float:
    tier = str(tier or '').upper().strip()
    if tier == 'A':
        return 1.0
    if tier == 'B':
        return float(settings.paper_risk_tier_b_size_multiplier)
    if tier == 'C':
        return float(settings.paper_risk_tier_c_size_multiplier)
    return 1.0
