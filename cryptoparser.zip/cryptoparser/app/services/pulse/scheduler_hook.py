from __future__ import annotations

import logging

from app.services.pulse.health import PulseHealthMonitor
from app.services.pulse.live_ready import LiveReadyController
from app.services.pulse.paper_trader import PaperTrader
from app.services.pulse.review_reeval import ReviewReEvaluator

logger = logging.getLogger(__name__)


async def run_paper_trading_tick(session_factory) -> list[dict]:
    logger.info('pump_telemetry event=scheduler_job_start job=paper_trading_tick')
    async with session_factory() as session:
        trader = PaperTrader(session)
        events = await trader.tick()
        for event in events:
            token = event.get('token') or event.get('token_address') or '__summary__'
            reason = event.get('reason') or event.get('event') or ''
            pnl_pct = float(event.get('pnl_pct', 0) or 0.0)
            if event.get('action') == 'analytics':
                logger.info(
                    'pulse_paper_trade event=%s token=%s reason=%s pnl_pct=%.1f open_positions=%s watching_positions=%s summary_events=%s',
                    event.get('action', 'unknown'),
                    token,
                    reason,
                    pnl_pct,
                    event.get('open_positions', 0),
                    event.get('watching_positions', 0),
                    event.get('events_before_summary', 0),
                )
            else:
                logger.info(
                    'pulse_paper_trade event=%s token=%s reason=%s pnl_pct=%.1f',
                    event.get('action', 'unknown'),
                    token,
                    reason,
                    pnl_pct,
                )
        await session.commit()
    logger.info('pump_telemetry event=scheduler_job_done job=paper_trading_tick results=%s', len(events))
    return events


async def run_review_reeval(session_factory) -> None:
    async with session_factory() as session:
        reeval = ReviewReEvaluator(session)
        count = await reeval.run()
        logger.info('pulse_review_reeval evaluated=%d', count)
        await session.commit()


async def run_pulse_health_check() -> None:
    monitor = PulseHealthMonitor()
    alerts = await monitor.check_and_alert()
    for alert in alerts:
        logger.warning('pulse_health alert=%s details=%s', alert.get('kind'), alert)


async def run_live_recovery(session_factory) -> None:
    async with session_factory() as session:
        controller = LiveReadyController(session)
        alerts = await controller.reconcile_stale()
        if alerts:
            logger.warning('pulse_live_recovery reconciled=%d', len(alerts))
        await session.commit()
