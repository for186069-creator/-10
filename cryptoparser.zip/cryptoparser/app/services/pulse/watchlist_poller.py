"""
watchlist_poller.py
-------------------
Збирає PriceSnapshotRecord для токенів зі статусом 'watching' в БД,
щоб ABCDetector мав достатньо тіків до моменту реального входу.

Запускається як окремий scheduler job кожні N секунд
(WATCHLIST_POLL_INTERVAL_SECONDS, дефолт 30).

Логіка:
  1. Беремо всі TokenLifecycleRecord зі status='watching'
  2. Для кожного запитуємо ціну через DexScreener (1 запит / токен)
  3. Зберігаємо PriceSnapshotRecord у БД
  4. Обмеження: не більше WATCHLIST_MAX_TOKENS_PER_TICK (дефолт 40) за один тік,
     щоб не спамити API.
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import TYPE_CHECKING

from sqlalchemy import select

from app.core.config import settings
from app.db.models import PriceSnapshotRecord, TokenLifecycleRecord
from app.utils.http import HttpClient

if TYPE_CHECKING:
    from sqlalchemy.ext.asyncio import AsyncSession

logger = logging.getLogger(__name__)

_MAX_TOKENS = 40
_CACHE_TTL = 28  # трохи менше інтервалу поллера


async def _fetch_price_dexscreener(token_address: str) -> dict | None:
    """Мінімальний запит до DexScreener, повертає {price, liquidity, market_cap} або None."""
    try:
        base_url = settings.dexscreener_base_url.rstrip('/')
        data = await HttpClient().get_json(
            f'{base_url}/latest/dex/tokens/{token_address}',
            timeout=8,
        )
    except Exception as exc:
        logger.debug('watchlist_poller dex_error token=%s err=%s', token_address[:12], exc)
        return None

    pairs = data.get('pairs') if isinstance(data, dict) else None
    if not isinstance(pairs, list) or not pairs:
        return None

    pair = pairs[0]
    price_raw = pair.get('priceUsd') or pair.get('price_usd')
    try:
        price = float(price_raw) if price_raw else None
    except (TypeError, ValueError):
        price = None

    liq_raw = (pair.get('liquidity') or {}).get('usd')
    try:
        liquidity = float(liq_raw) if liq_raw else None
    except (TypeError, ValueError):
        liquidity = None

    mc_raw = pair.get('marketCap') or pair.get('fdv')
    try:
        market_cap = float(mc_raw) if mc_raw else None
    except (TypeError, ValueError):
        market_cap = None

    if price is None:
        return None

    return {'price': price, 'liquidity': liquidity, 'market_cap': market_cap}


async def run_watchlist_snapshot_tick(session: AsyncSession) -> int:
    """
    Основний метод — викликається scheduler-ом.
    Повертає кількість збережених снапшотів.
    """
    max_tokens = int(getattr(settings, 'watchlist_max_tokens_per_tick', _MAX_TOKENS) or _MAX_TOKENS)

    # Беремо watching токени, сортуємо по updated_at (найстаріші — першими)
    result = await session.execute(
        select(TokenLifecycleRecord)
        .where(TokenLifecycleRecord.status == 'watching')
        .order_by(TokenLifecycleRecord.updated_at.asc())
        .limit(max_tokens)
    )
    watching: list[TokenLifecycleRecord] = list(result.scalars().all())

    if not watching:
        return 0

    saved = 0
    for rec in watching:
        payload = await _fetch_price_dexscreener(rec.token_address)
        if payload is None:
            continue

        session.add(PriceSnapshotRecord(
            chain=rec.chain,
            token_address=rec.token_address,
            price_usd=payload['price'],
            liquidity_usd=payload.get('liquidity'),
            holders=rec.current_holders,
            market_cap_usd=payload.get('market_cap'),
            source='watchlist_poller',
        ))
        saved += 1

        # Pre-graduation bundle detection:
        # Якщо токен ще watching і ліквідність ще низька (pre-graduation),
        # перевіряємо top10 концентрацію через DexScreener.
        # Записуємо bundle_severity в lifecycle — щоб після graduation
        # orchestrator знав що кити заходили ДО graduation.
        if rec.bundle_severity is None:
            top10 = payload.get('top10_holder_pct')
            liq = float(payload.get('liquidity') or 0)
            if top10 is not None:
                top10 = float(top10)
                if top10 >= 55 and liq >= 5_000:
                    rec.bundle_severity = 'high'
                    rec.bundle_supply_pct = top10
                    logger.info(
                        'watchlist_poller pre_graduation_bundle_detected token=%s top10=%.1f%% liq=%.0f',
                        rec.token_address[:12], top10, liq
                    )
                elif top10 >= 40 and liq >= 3_000:
                    rec.bundle_severity = 'medium'
                    rec.bundle_supply_pct = top10

    logger.info(
        'pump_telemetry event=watchlist_snapshot_tick watching=%s saved=%s',
        len(watching),
        saved,
    )
    return saved
