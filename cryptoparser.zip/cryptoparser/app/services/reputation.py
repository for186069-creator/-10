from __future__ import annotations

from app.db.repositories import DeployerRepository, ReputationRepository
from app.models.token import DeployerProfile, SecurityReport, TokenCandidate


class ReputationService:
    def __init__(self, repo: ReputationRepository, deployers: DeployerRepository | None = None) -> None:
        self.repo = repo
        self.deployers = deployers

    async def apply(self, candidate: TokenCandidate, security: SecurityReport) -> SecurityReport:
        deployer = candidate.deployer_address or candidate.creator_address
        if deployer and await self.repo.is_blacklisted('wallet', deployer):
            security.deployer_wallet_reputation = 0.0
            security.reasons.append('blacklisted_deployer_wallet')
        rep = await self.repo.get_reputation('wallet', deployer)
        if rep:
            security.deployer_wallet_reputation = rep.reputation_score
            if rep.flagged:
                security.reasons.append(rep.reason_code or 'wallet_flagged')
        domain = candidate.website
        if domain and await self.repo.is_blacklisted('domain', domain):
            security.reasons.append('blacklisted_domain')
        return security

    async def apply_deployer_profile(self, chain: str, profile: DeployerProfile, security: SecurityReport) -> SecurityReport:
        if self.deployers:
            await self.deployers.upsert(profile, chain)
        security.deployer_wallet_reputation = profile.reputation_score
        security.funding_wallet = profile.funding_wallet
        if profile.rugs_count >= 2:
            security.reasons.append('deployer_multiple_rugs')
        if profile.reputation_score < 25:
            security.reasons.append('deployer_reputation_critical')
        return security
