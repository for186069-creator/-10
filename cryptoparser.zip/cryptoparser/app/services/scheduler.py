from __future__ import annotations

import asyncio
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Awaitable, Callable

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.db.base import AsyncSessionLocal
from app.db.models import JobRunRecord, ScheduledJobRecord
from app.observability.metrics import METRICS
from app.observability.spans import async_span
from app.queue.coordination import WorkerCoordinator
from app.services.ops_alerts import OpsAlerter


@dataclass
class ScheduledJobDefinition:
    job_name: str
    interval_seconds: int
    handler: Callable[[], Awaitable[None]]
    enabled: bool = True


class JobScheduler:
    def __init__(self, session: AsyncSession, jobs: list[ScheduledJobDefinition]) -> None:
        self.session = session
        self.jobs = jobs
        self.alerts = OpsAlerter()

    async def ensure_jobs(self) -> None:
        for job in self.jobs:
            row = await self._get(job.job_name)
            if row is None:
                self.session.add(
                    ScheduledJobRecord(
                        job_name=job.job_name,
                        enabled=job.enabled,
                        interval_seconds=job.interval_seconds,
                        next_run_at=datetime.now(timezone.utc),
                    )
                )
        await self.session.commit()

    async def run_due_jobs(self) -> int:
        await self.ensure_jobs()
        q = select(ScheduledJobRecord).where(
            ScheduledJobRecord.enabled.is_(True),
            ScheduledJobRecord.next_run_at <= datetime.now(timezone.utc),
        ).order_by(ScheduledJobRecord.next_run_at.asc())
        rows = list((await self.session.execute(q)).scalars().all())
        ran = 0
        for row in rows:
            definition = next((j for j in self.jobs if j.job_name == row.job_name), None)
            if definition is None:
                continue
            await self._run_job(row, definition)
            ran += 1
        return ran

    async def _run_job(self, row: ScheduledJobRecord, definition: ScheduledJobDefinition) -> None:
        started = datetime.now(timezone.utc)
        run = JobRunRecord(job_name=row.job_name, status='RUNNING', started_at=started)
        self.session.add(run)
        await self.session.commit()
        try:
            async with async_span('scheduler.job', job_name=row.job_name):
                async with METRICS.timer(f'scheduler_{row.job_name}'):
                    await definition.handler()
            run.status = 'SUCCESS'
            row.last_run_at = started
            row.next_run_at = started + timedelta(seconds=row.interval_seconds)
            row.last_error = None
            await METRICS.incr('scheduler_job_success_total')
        except asyncio.CancelledError:
            # Не вбиваємо шедулер — логуємо і продовжуємо
            run.status = 'FAILED'
            run.error_message = 'cancelled'
            row.last_error = 'cancelled'
            row.next_run_at = datetime.now(timezone.utc) + timedelta(seconds=30)
        except Exception as exc:
            run.status = 'FAILED'
            run.error_message = str(exc)
            row.last_error = str(exc)
            row.next_run_at = datetime.now(timezone.utc) + timedelta(seconds=max(30, row.interval_seconds // 2))
            await METRICS.incr('scheduler_job_failures_total')
            await self.alerts.notify_failure('scheduler', f'job_failed:{row.job_name}', {'error': str(exc)})
        finally:
            run.finished_at = datetime.now(timezone.utc)
            await self.session.commit()

    async def _get(self, job_name: str) -> ScheduledJobRecord | None:
        q = select(ScheduledJobRecord).where(ScheduledJobRecord.job_name == job_name)
        return (await self.session.execute(q)).scalar_one_or_none()


async def run_scheduler_forever(jobs: list[ScheduledJobDefinition]) -> None:
    coordinator = WorkerCoordinator('scheduler')
    await coordinator.start()
    try:
        while True:
            try:
                async with coordinator.leader('cryptoparser:leader:scheduler') as acquired:
                    if acquired:
                        async with AsyncSessionLocal() as session:
                            scheduler = JobScheduler(session, jobs)
                            await scheduler.run_due_jobs()
            except asyncio.CancelledError:
                raise  # реальний shutdown — пробрасуємо
            except Exception as exc:
                import logging
                logging.getLogger(__name__).warning('scheduler tick error: %s', exc)
            await asyncio.sleep(10)
    except asyncio.CancelledError:
        pass
    finally:
        await coordinator.stop()
