from __future__ import annotations

import hashlib
import re
from typing import TYPE_CHECKING, Any

from app.models.token import Chain, ContractFingerprint, SecurityReport, TokenCandidate

if TYPE_CHECKING:  # pragma: no cover
    from app.db.repositories import FingerprintRepository
else:
    FingerprintRepository = Any

SUSPICIOUS_SELECTORS = {
    '0xdd62ed3e': 'allowance_like',
    '0x8456cb59': 'pause_like',
    '0x79ba5097': 'blacklist_like',
    '0x40c10f19': 'mint_like',
    '0xf2fde38b': 'transfer_ownership_like',
}

KNOWN_SCAM_FINGERPRINTS = {
    'scam_proxy_template': 92.0,
    'scam_blacklist_template': 88.0,
}


class ContractSimilarityService:
    def __init__(self, repo: FingerprintRepository | None = None) -> None:
        self.repo = repo

    async def apply(self, candidate: TokenCandidate, security: SecurityReport) -> SecurityReport:
        fingerprint = self.build_fingerprint(candidate, security)
        if self.repo:
            existing = await self.repo.get_by_hash(candidate.chain.value, fingerprint.fingerprint_hash)
            if existing:
                fingerprint.similarity_score = max([row.similarity_score for row in existing] + [fingerprint.similarity_score])
                fingerprint.matched_template = existing[0].matched_template or fingerprint.matched_template
                fingerprint.reasons.append('matched_existing_fingerprint')
            await self.repo.upsert(fingerprint)
        security.bytecode_hash = fingerprint.bytecode_hash
        security.fingerprint_hash = fingerprint.fingerprint_hash
        security.similarity_risk = max(security.similarity_risk or 0.0, fingerprint.similarity_score)
        security.reasons.extend(fingerprint.reasons)
        return security

    def build_fingerprint(self, candidate: TokenCandidate, security: SecurityReport) -> ContractFingerprint:
        raw = candidate.raw or {}
        bytecode = str(raw.get('bytecode') or raw.get('sourceCode') or candidate.token_address)
        bytecode_hash = hashlib.sha256(bytecode.encode()).hexdigest()[:32]
        selectors = sorted(set(re.findall(r'0x[a-fA-F0-9]{8}', bytecode)))
        suspicious = [selector for selector in selectors if selector.lower() in SUSPICIOUS_SELECTORS]
        canonical = '|'.join([
            candidate.chain.value,
            str(security.proxy),
            str(security.mint_enabled),
            str(security.blacklist_function),
            str(security.pause_function),
            ','.join(sorted(suspicious)),
        ])
        fingerprint_hash = hashlib.sha256(canonical.encode()).hexdigest()[:32]
        similarity_score = 10.0 + (len(suspicious) * 18.0)
        matched_template = None
        reasons: list[str] = []
        if security.proxy and security.blacklist_function:
            matched_template = 'scam_proxy_template'
            similarity_score = max(similarity_score, KNOWN_SCAM_FINGERPRINTS[matched_template])
            reasons.append('proxy_blacklist_pattern')
        elif security.blacklist_function or security.owner_can_block_wallets:
            matched_template = 'scam_blacklist_template'
            similarity_score = max(similarity_score, KNOWN_SCAM_FINGERPRINTS[matched_template])
            reasons.append('blacklist_control_pattern')
        return ContractFingerprint(
            chain=Chain(candidate.chain),
            token_address=candidate.token_address,
            bytecode_hash=bytecode_hash,
            fingerprint_hash=fingerprint_hash,
            selectors=selectors,
            suspicious_selectors=suspicious,
            similarity_score=min(similarity_score, 99.0),
            matched_template=matched_template,
            reasons=reasons,
        )
