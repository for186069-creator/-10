from __future__ import annotations
from dataclasses import dataclass, field
from app.models.token import BehaviorProfile, SecurityReport


@dataclass
class SmartMoneyResult:
    score: float = 0.0
    reasons: list[str] = field(default_factory=list)


class SmartMoneyTracker:
    def fast(self, candidate) -> SmartMoneyResult:
        score = 0.0
        reasons: list[str] = []
        buy_tax = candidate.taxes_buy_pct or 0
        sell_tax = candidate.taxes_sell_pct or 0
        if buy_tax == 0 and sell_tax == 0:
            score += 8; reasons.append('zero_tax')
        elif buy_tax > 0 or sell_tax > 0:
            score -= 15; reasons.append('high_tax')
        return SmartMoneyResult(score=max(-25.0, min(score, 20.0)), reasons=reasons)

    def full(self, security: SecurityReport, behavior: BehaviorProfile | None) -> SmartMoneyResult:
        score = 0.0
        reasons: list[str] = []

        if security.renounced:
            score += 10; reasons.append('renounced')
        if security.honeypot:
            score -= 40; reasons.append('honeypot')
        if security.can_sell is False:
            score -= 40; reasons.append('cannot_sell')
        if security.mint_enabled:
            score -= 15; reasons.append('mint_enabled')
        if security.blacklist_function:
            score -= 8; reasons.append('blacklist_function')
        lp_days = security.lp_locked_days or 0
        if lp_days >= 180:
            score += 12; reasons.append('lp_locked_long')
        elif lp_days >= 30:
            score += 6; reasons.append('lp_locked_short')

        if behavior:
            if behavior.bundled_buy_detected:
                score -= 5; reasons.append('bundle_buy')
            if behavior.wash_trading_risk and behavior.wash_trading_risk > 0.6:
                score -= 10; reasons.append('wash_trading')

            early_wallets = getattr(behavior, 'early_wallet_count', 0) or (behavior.raw or {}).get('early_wallet_count', 0) or 0
            large_buys = getattr(behavior, 'early_large_buys', 0) or (behavior.raw or {}).get('early_large_buys', 0) or 0
            liquidity_growth = getattr(behavior, 'liquidity_growth_rate', 0) or (behavior.raw or {}).get('liquidity_growth_rate', 0) or 0

            if early_wallets >= 6:
                score += 6; reasons.append('multi_wallet_accumulation')
            elif early_wallets >= 3:
                score += 3; reasons.append('few_wallet_accumulation')

            if large_buys >= 2:
                score += 8; reasons.append('early_large_buyers')
            elif large_buys == 1:
                score += 4; reasons.append('single_large_buyer')

            if liquidity_growth >= 0.25:
                score += 6; reasons.append('liquidity_growth_strong')
            elif liquidity_growth >= 0.10:
                score += 3; reasons.append('liquidity_growth_moderate')

        return SmartMoneyResult(score=max(-60.0, min(score, 25.0)), reasons=reasons)
