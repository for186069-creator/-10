from __future__ import annotations
from dataclasses import dataclass, field
from app.models.token import SocialProfile, WebsiteProfile


@dataclass
class SocialResult:
    score: float = 0.0
    reasons: list[str] = field(default_factory=list)


class SocialVelocity:
    def fast(self, candidate) -> SocialResult:
        score = 0.0
        reasons: list[str] = []
        if candidate.x_handle:
            score += 6; reasons.append('has_twitter')
        if candidate.telegram_url:
            score += 6; reasons.append('has_telegram')
        if candidate.website:
            score += 4; reasons.append('has_website')
        return SocialResult(score=max(0.0, min(score, 20.0)), reasons=reasons)

    def full(self, social: SocialProfile | None, website: WebsiteProfile | None) -> SocialResult:
        score = 0.0
        reasons: list[str] = []

        if social:
            followers = social.followers or 0
            age = social.account_age_days or 0
            if followers >= 5000:
                score += 15; reasons.append('followers_high')
            elif followers >= 500:
                score += 8; reasons.append('followers_ok')
            elif followers < 50:
                score -= 5; reasons.append('followers_low')
            if age >= 180:
                score += 8; reasons.append('account_mature')
            elif age < 7:
                score -= 10; reasons.append('account_new')
            if social.suspicious:
                score -= 12; reasons.append('social_suspicious')

        if website:
            if website.exists and website.https_ok:
                score += 5; reasons.append('website_ok')
            if website.domain_age_days and website.domain_age_days < 7:
                score -= 8; reasons.append('domain_new')
            if website.broken_links:
                score -= 5; reasons.append('broken_links')

        return SocialResult(score=max(-25.0, min(score, 30.0)), reasons=reasons)
