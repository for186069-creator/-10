"""
Threshold Calibrator — аналізує outcome-лейбли та рекомендує оптимальні
пороги approve_score / review_score.

Алгоритм:
  1. Завантажує всі token_decisions що мають outcome-лейбл
  2. Grid search по (approve: 60–94 step 2) × (review: 40–74 step 2)
  3. Для кожної пари порогів рахує precision / recall / F1 на APPROVE
  4. Знаходить оптимум і зберігає звіт у config/threshold_calibration.json
  5. НІЧОГО не змінює в settings автоматично — тільки рекомендація

Потрібно мінімум MIN_SAMPLES лейблів щоб результат був статистично значимим.

Запуск через scheduler (job_name='threshold_calibrator'),
або вручну: python -m app.services.threshold_calibrator
"""

from __future__ import annotations

import asyncio
import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.base import AsyncSessionLocal
from app.db.models import AnalystLabelRecord, TokenDecisionRecord

log = logging.getLogger(__name__)

CALIBRATION_PATH = Path('config/threshold_calibration.json')

MIN_SAMPLES = 20       # мінімум лейблів для запуску
TOP_N       = 10       # скільки найкращих threshold-пар зберігати у звіті

# Grid
APPROVE_RANGE = range(60, 96, 2)   # 60, 62, …, 94
REVIEW_RANGE  = range(40, 76, 2)   # 40, 42, …, 74

# RUG_WEIGHT — штраф за FP (approve rug) більший ніж за FN (miss legit)
# 1.0 = стандартний F1; >1.0 = пріоритизуємо precision (менше помилок approve)
BETA_PRECISION_WEIGHT = 1.5    # F-beta: beta < 1 → більше ваги precision


class ThresholdCalibrator:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    # ── публічний entry-point ────────────────────────────────────────────────

    async def run(self) -> dict[str, Any]:
        labeled = await self._load_labeled()

        if len(labeled) < MIN_SAMPLES:
            log.warning(
                'threshold_calibrator: %d samples < MIN_SAMPLES=%d, skipping',
                len(labeled), MIN_SAMPLES,
            )
            return {
                'status':       'skipped',
                'reason':       'insufficient_data',
                'sample_count': len(labeled),
                'required':     MIN_SAMPLES,
            }

        rugs   = [r for r in labeled if r['outcome'] in ('rug', 'dead')]
        legits = [r for r in labeled if r['outcome'] == 'alive']

        best  = self._grid_search_best(labeled)
        top_n = self._grid_search_topn(labeled)

        report: dict[str, Any] = {
            'generated_at':              datetime.now(timezone.utc).isoformat(),
            'sample_count':              len(labeled),
            'rug_count':                 len(rugs),
            'legit_count':               len(legits),
            'rug_rate_pct':              round(len(rugs) / len(labeled) * 100, 1),
            # поточні значення з коду (захардкоджені для довідки)
            'current_approve_score':     78.0,
            'current_review_score':      62.0,
            # рекомендація
            'recommended_approve_score': best['approve_threshold'],
            'recommended_review_score':  best['review_threshold'],
            'best_metrics':              best,
            'top_n_grid':                top_n,
            'notes': (
                f'Grid search {len(list(APPROVE_RANGE))}×{len(list(REVIEW_RANGE))} '
                f'на {len(labeled)} лейблах. '
                f'Метрика: F-beta (beta={BETA_PRECISION_WEIGHT}), пріоритет precision. '
                'Зміна threshold вимагає ручного підтвердження в .env / config.'
            ),
        }

        _write_report(report)

        log.info(
            'threshold_calibrator: recommend approve=%.1f review=%.1f  '
            '(fbeta=%.3f precision=%.3f recall=%.3f rug_rate=%.1f%%)',
            best['approve_threshold'], best['review_threshold'],
            best['fbeta'], best['precision'], best['recall'],
            report['rug_rate_pct'],
        )
        return report

    # ── завантаження даних ───────────────────────────────────────────────────

    async def _load_labeled(self) -> list[dict[str, Any]]:
        """Джойнить token_decisions + outcome-лейбли."""
        q_labels = select(AnalystLabelRecord).where(AnalystLabelRecord.label == 'outcome')
        label_rows = list((await self.session.execute(q_labels)).scalars().all())

        # Беремо найсвіжіший лейбл для кожного токену
        outcome_map: dict[tuple[str, str], str] = {}
        for lbl in sorted(label_rows, key=lambda x: x.created_at):
            key = (lbl.chain, lbl.token_address)
            # outcome_tracker перезаписує ручні лейбли (вони об'єктивніші)
            if key not in outcome_map or lbl.analyst == 'outcome_tracker':
                outcome_map[key] = lbl.value

        if not outcome_map:
            return []

        results: list[dict[str, Any]] = []
        for (chain, token_address), outcome in outcome_map.items():
            # Перше рішення по токену — саме те, яке ми і оцінюємо
            q = (
                select(TokenDecisionRecord)
                .where(
                    TokenDecisionRecord.chain         == chain,
                    TokenDecisionRecord.token_address == token_address,
                )
                .order_by(TokenDecisionRecord.created_at.asc())
                .limit(1)
            )
            decision = (await self.session.execute(q)).scalar_one_or_none()
            if decision is None:
                continue
            results.append({
                'chain':         chain,
                'token_address': token_address,
                'score':         float(decision.score),
                'status':        decision.status,
                'outcome':       outcome,
            })

        log.info('threshold_calibrator: loaded %d labeled decisions', len(results))
        return results

    # ── grid search ──────────────────────────────────────────────────────────

    def _grid_search_best(self, labeled: list[dict]) -> dict[str, Any]:
        best: dict[str, Any] = {'fbeta': -1.0}
        for approve_t in APPROVE_RANGE:
            for review_t in REVIEW_RANGE:
                if review_t >= approve_t:
                    continue
                m = _evaluate(labeled, float(approve_t), float(review_t))
                if m['fbeta'] > best['fbeta']:
                    best = m
        return best

    def _grid_search_topn(self, labeled: list[dict]) -> list[dict[str, Any]]:
        all_results: list[dict[str, Any]] = []
        for approve_t in APPROVE_RANGE:
            for review_t in REVIEW_RANGE:
                if review_t >= approve_t:
                    continue
                all_results.append(_evaluate(labeled, float(approve_t), float(review_t)))
        all_results.sort(key=lambda x: x['fbeta'], reverse=True)
        return all_results[:TOP_N]


# ── утиліти ───────────────────────────────────────────────────────────────────

def _evaluate(
    labeled: list[dict],
    approve_t: float,
    review_t: float,
) -> dict[str, Any]:
    """
    Симулює pipeline-рішення з заданими порогами і рахує метрики.

    True Positive:  score >= approve_t, outcome == alive   (правильний APPROVE)
    False Positive: score >= approve_t, outcome in rug/dead (пропустили rug!)
    False Negative: score <  approve_t, outcome == alive   (miss легітного)
    True Negative:  score <  approve_t, outcome in rug/dead (правильно відхилили)
    """
    tp = fp = fn = tn = 0
    for row in labeled:
        score    = row['score']
        is_legit = row['outcome'] == 'alive'
        approved = score >= approve_t

        if approved and is_legit:
            tp += 1
        elif approved and not is_legit:
            fp += 1
        elif not approved and is_legit:
            fn += 1
        else:
            tn += 1

    precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    recall    = tp / (tp + fn) if (tp + fn) > 0 else 0.0

    # F-beta: beta > 1 → більше ваги precision (штрафуємо FP сильніше)
    b2 = BETA_PRECISION_WEIGHT ** 2
    fbeta = (
        (1 + b2) * precision * recall / (b2 * precision + recall)
        if (b2 * precision + recall) > 0
        else 0.0
    )

    return {
        'approve_threshold': float(approve_t),
        'review_threshold':  float(review_t),
        'precision':         round(precision, 4),
        'recall':            round(recall, 4),
        'fbeta':             round(fbeta, 4),
        'tp': tp, 'fp': fp, 'fn': fn, 'tn': tn,
    }


def _write_report(report: dict[str, Any]) -> None:
    CALIBRATION_PATH.parent.mkdir(parents=True, exist_ok=True)
    CALIBRATION_PATH.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding='utf-8')
    log.info('threshold_calibrator: report written to %s', CALIBRATION_PATH)
    _auto_apply_thresholds(report)


def _auto_apply_thresholds(report: dict[str, Any]) -> None:
    """Автоматично оновлює approve_score і review_score в .env якщо є рекомендація."""
    new_approve = report.get('recommended_approve_score')
    new_review  = report.get('recommended_review_score')
    if new_approve is None or new_review is None:
        return

    env_path = Path('.env')
    if not env_path.exists():
        log.warning('threshold_calibrator: .env not found, cannot auto-apply')
        return

    try:
        lines = env_path.read_text(encoding='utf-8').splitlines()
        updated = []
        approve_found = review_found = False
        for line in lines:
            if line.startswith('APPROVE_SCORE='):
                updated.append(f'APPROVE_SCORE={new_approve}')
                approve_found = True
            elif line.startswith('REVIEW_SCORE='):
                updated.append(f'REVIEW_SCORE={new_review}')
                review_found = True
            else:
                updated.append(line)
        if not approve_found:
            updated.append(f'APPROVE_SCORE={new_approve}')
        if not review_found:
            updated.append(f'REVIEW_SCORE={new_review}')
        env_path.write_text('\n'.join(updated) + '\n', encoding='utf-8')
        log.info(
            'threshold_calibrator: auto-applied approve=%.1f review=%.1f to .env',
            new_approve, new_review,
        )
    except Exception as e:
        log.warning('threshold_calibrator: failed to auto-apply thresholds: %s', e)


# ── scheduler entry-point ────────────────────────────────────────────────────

async def run_threshold_calibration(session_factory) -> None:
    async with session_factory() as session:
        calibrator = ThresholdCalibrator(session)
        await calibrator.run()


# ── standalone ───────────────────────────────────────────────────────────────

if __name__ == '__main__':
    import sys
    from app.core.logging import configure_logging
    configure_logging()

    async def _main() -> None:
        async with AsyncSessionLocal() as session:
            report = await ThresholdCalibrator(session).run()
            print(json.dumps(report, indent=2, ensure_ascii=False))

    asyncio.run(_main())
