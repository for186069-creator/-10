from __future__ import annotations

import asyncio
import json
import time
from typing import Any, Awaitable, Callable, Protocol

from app.core.config import settings
from app.utils.locks import LOCAL_LOCKS, REDIS_LOCKS

try:  # pragma: no cover
    import redis.asyncio as redis
except Exception:  # pragma: no cover
    redis = None


Loader = Callable[[], Awaitable[Any]]


class CacheBackend(Protocol):
    async def get(self, key: str) -> Any | None: ...
    async def set(self, key: str, value: Any, ttl_seconds: int | None = None) -> None: ...
    async def delete(self, key: str) -> None: ...


class InMemoryTTLCache(CacheBackend):
    def __init__(self, ttl_seconds: int = 300, max_entries: int = 2048) -> None:
        self.ttl_seconds = ttl_seconds
        self.max_entries = max_entries
        self._store: dict[str, tuple[float, Any]] = {}
        self._lock = asyncio.Lock()

    async def get(self, key: str) -> Any | None:
        async with self._lock:
            row = self._store.get(key)
            if not row:
                return None
            expires_at, value = row
            if expires_at < time.time():
                self._store.pop(key, None)
                return None
            return value

    async def set(self, key: str, value: Any, ttl_seconds: int | None = None) -> None:
        async with self._lock:
            if len(self._store) >= self.max_entries:
                self._evict_oldest()
            ttl = ttl_seconds if ttl_seconds is not None else self.ttl_seconds
            self._store[key] = (time.time() + ttl, value)

    async def delete(self, key: str) -> None:
        async with self._lock:
            self._store.pop(key, None)

    def _evict_oldest(self) -> None:
        if not self._store:
            return
        oldest_key = min(self._store.items(), key=lambda kv: kv[1][0])[0]
        self._store.pop(oldest_key, None)


class RedisTTLCache(CacheBackend):
    def __init__(self, redis_url: str, prefix: str = 'cryptoparser:cache') -> None:
        if redis is None:
            raise RuntimeError('redis package is not installed')
        self.client = redis.from_url(redis_url, decode_responses=True)
        self.prefix = prefix.rstrip(':')

    def _full_key(self, key: str) -> str:
        return f'{self.prefix}:{key}'

    async def get(self, key: str) -> Any | None:
        payload = await self.client.get(self._full_key(key))
        if payload is None:
            return None
        return json.loads(payload)

    async def set(self, key: str, value: Any, ttl_seconds: int | None = None) -> None:
        ttl = ttl_seconds if ttl_seconds is not None else settings.cache_ttl_seconds
        await self.client.set(self._full_key(key), json.dumps(value), ex=ttl)

    async def delete(self, key: str) -> None:
        await self.client.delete(self._full_key(key))


class MultiLevelCache(CacheBackend):
    def __init__(self, memory: InMemoryTTLCache, redis_cache: CacheBackend | None = None) -> None:
        self.memory = memory
        self.redis_cache = redis_cache

    async def get(self, key: str) -> Any | None:
        value = await self.memory.get(key)
        if value is not None:
            return value
        if self.redis_cache is None:
            return None
        value = await self.redis_cache.get(key)
        if value is not None:
            await self.memory.set(key, value)
        return value

    async def set(self, key: str, value: Any, ttl_seconds: int | None = None) -> None:
        await self.memory.set(key, value, ttl_seconds=ttl_seconds)
        if self.redis_cache is not None:
            await self.redis_cache.set(key, value, ttl_seconds=ttl_seconds)

    async def delete(self, key: str) -> None:
        await self.memory.delete(key)
        if self.redis_cache is not None:
            await self.redis_cache.delete(key)

    async def get_or_set(self, key: str, loader: Loader, ttl_seconds: int | None = None) -> Any:
        existing = await self.get(key)
        if existing is not None:
            return existing

        local_lock = await LOCAL_LOCKS.get_lock(key)
        async with local_lock:
            existing = await self.get(key)
            if existing is not None:
                return existing

            if REDIS_LOCKS is not None:
                async with REDIS_LOCKS.acquire(key, ttl_seconds=max(ttl_seconds or settings.cache_ttl_seconds, 30), wait_timeout=5.0) as acquired:
                    if not acquired:
                        existing = await self.get(key)
                        if existing is not None:
                            return existing
                    else:
                        existing = await self.get(key)
                        if existing is not None:
                            return existing
                        value = await loader()
                        if value is not None:
                            await self.set(key, value, ttl_seconds=ttl_seconds)
                        return value

            value = await loader()
            if value is not None:
                await self.set(key, value, ttl_seconds=ttl_seconds)
            return value


_memory_cache = InMemoryTTLCache(ttl_seconds=settings.cache_ttl_seconds, max_entries=settings.cache_max_entries)
_redis_cache: CacheBackend | None = None
if settings.use_redis_cache:
    try:  # pragma: no cover
        _redis_cache = RedisTTLCache(settings.redis_url, prefix=settings.redis_cache_prefix)
    except Exception:
        _redis_cache = None

GLOBAL_CACHE = MultiLevelCache(memory=_memory_cache, redis_cache=_redis_cache)
GLOBAL_TTL_CACHE = GLOBAL_CACHE
