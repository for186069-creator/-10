from __future__ import annotations

from datetime import datetime, timezone
import re
from urllib.parse import urlparse


_X_HANDLE_RE = re.compile(r'^[A-Za-z0-9_]{2,15}$')
_X_RESERVED = {
    'home',
    'explore',
    'search',
    'i',
    'intent',
    'settings',
    'messages',
    'notifications',
    'compose',
    'login',
    'signup',
    'hashtag',
    'share',
}
_TG_HOSTS = {'t.me', 'telegram.me', 'www.t.me', 'www.telegram.me'}


def _to_float(value: object, default: float = 0.0) -> float:
    try:
        return float(value)
    except Exception:
        return default


def _to_int(value: object, default: int = 0) -> int:
    try:
        return int(value)
    except Exception:
        return default


def _chain_key(chain: str | None) -> str:
    return str(chain or 'solana').strip().lower() or 'solana'


def _chain_threshold(settings: object, key: str, chain: str | None, default: float) -> float:
    by_chain = getattr(settings, f'{key}_by_chain', None) or {}
    if isinstance(by_chain, dict):
        value = by_chain.get(_chain_key(chain))
        if value is not None:
            return _to_float(value, default)
    return _to_float(getattr(settings, key, default), default)


def normalized_x_handle(value: str | None) -> str | None:
    if not value:
        return None
    raw = str(value).strip()
    if not raw:
        return None
    if raw.startswith('http://') or raw.startswith('https://'):
        parsed = urlparse(raw)
        host = (parsed.netloc or '').lower()
        if not host.endswith('x.com') and not host.endswith('twitter.com'):
            return None
        parts = [p for p in (parsed.path or '').split('/') if p]
        if not parts:
            return None
        first = parts[0].lstrip('@')
        if not first:
            return None
        if first.lower() in _X_RESERVED:
            return None
        raw = first
    raw = raw.lstrip('@').strip()
    if not raw:
        return None
    if raw.lower() in _X_RESERVED:
        return None
    if not _X_HANDLE_RE.fullmatch(raw):
        return None
    return raw


def is_valid_x_handle(value: str | None) -> bool:
    return normalized_x_handle(value) is not None


def is_valid_telegram_url(value: str | None) -> bool:
    if not value:
        return False
    raw = str(value).strip()
    if not raw:
        return False
    if not raw.startswith('http://') and not raw.startswith('https://'):
        raw = f'https://{raw}'
    try:
        parsed = urlparse(raw)
    except Exception:
        return False
    if (parsed.netloc or '').lower() not in _TG_HOSTS:
        return False
    parts = [p for p in (parsed.path or '').split('/') if p]
    if not parts:
        return False
    return True


def has_quality_social(x_handle: str | None, telegram_url: str | None, require_valid_social: bool = True) -> bool:
    if require_valid_social:
        return is_valid_x_handle(x_handle) or is_valid_telegram_url(telegram_url)
    return bool((x_handle or '').strip() or (telegram_url or '').strip())


def extract_graduated_metrics(candidate_raw: dict, liquidity_fallback: float = 0.0) -> dict[str, float]:
    prefilter = candidate_raw.get('graduated_prefilter') or {}
    pair = candidate_raw.get('pair') or {}
    pair_h24 = (pair.get('txns') or {}).get('h24') or {}
    return {
        'liquidity_usd': _to_float(
            prefilter.get('liquidity_usd')
            or (pair.get('liquidity') or {}).get('usd')
            or liquidity_fallback,
            0.0,
        ),
        'volume_24h': _to_float(
            prefilter.get('volume_24h')
            or (pair.get('volume') or {}).get('h24')
            or 0.0,
            0.0,
        ),
        'txns_24h': float(
            _to_int(
                prefilter.get('txns_24h')
                or (_to_int(pair_h24.get('buys')) + _to_int(pair_h24.get('sells'))),
                0,
            )
        ),
    }


def pair_created_ms_from_raw(raw: dict) -> float | None:
    pre = raw.get('graduated_prefilter') or {}
    pair = raw.get('pair') or {}
    value = (
        pre.get('pair_created_at')
        or pre.get('pairCreatedAt')
        or pair.get('pairCreatedAt')
        or raw.get('pair_created_at')
        or raw.get('pairCreatedAt')
    )
    try:
        ts = float(value)
        if ts < 10_000_000_000:
            ts *= 1000.0
        return ts
    except Exception:
        return None


def is_within_launch_window(raw: dict, settings: object) -> bool:
    pair_ms = pair_created_ms_from_raw(raw)
    if pair_ms is None:
        return False
    age_seconds = (datetime.now(timezone.utc).timestamp() * 1000.0 - pair_ms) / 1000.0
    min_age_seconds = float(getattr(settings, 'graduated_min_age_hours', 0.0) or 0.0) * 3600.0
    max_age_seconds = float(getattr(settings, 'pump_graduated_max_launch_age_hours', 0.0) or 0.0) * 3600.0
    if age_seconds < min_age_seconds:
        return False
    if max_age_seconds > 0 and age_seconds > max_age_seconds:
        return False
    return True


def _pair_has_quality_web_and_social(raw: dict, require_valid_social: bool = True) -> bool:
    pair = raw.get('pair') or {}
    info = pair.get('info') or {}
    websites = info.get('websites') or []
    socials = info.get('socials') or []
    has_site = any(str(site.get('url') or '').strip() for site in websites if isinstance(site, dict))
    if not has_site:
        return False
    for social in socials:
        if not isinstance(social, dict):
            continue
        social_url = str(social.get('url') or '').strip()
        if not social_url:
            continue
        social_type = str(social.get('type') or social.get('platform') or '').lower()
        if social_type in {'twitter', 'x'} and (is_valid_x_handle(social_url) if require_valid_social else True):
            return True
        if social_type == 'telegram' and (is_valid_telegram_url(social_url) if require_valid_social else True):
            return True
    return False


def is_multichain_graduated_signal(chain: str | None, raw: dict | None, settings: object) -> bool:
    if not bool(getattr(settings, 'pump_graduated_multichain_enabled', False)):
        return False
    raw = raw or {}
    chain_norm = _chain_key(chain)
    allowed_chains = {str(v).lower() for v in (getattr(settings, 'pump_graduated_multichain_chains', []) or [])}
    if chain_norm not in allowed_chains:
        return False

    pair = raw.get('pair') or {}
    pair_chain = str(pair.get('chainId') or raw.get('chainId') or '').lower()
    if pair_chain and pair_chain != chain_norm:
        return False

    dex_id = str(pair.get('dexId') or raw.get('dexId') or '').lower()
    allowed_dex = {
        str(v).lower()
        for v in ((getattr(settings, 'pump_graduated_multichain_allowed_dex', {}) or {}).get(chain_norm) or [])
    }
    if allowed_dex and dex_id not in allowed_dex:
        return False

    if not is_within_launch_window(raw, settings):
        return False

    require_valid_social = bool(getattr(settings, 'pump_graduated_quality_require_valid_social', True))
    if not _pair_has_quality_web_and_social(raw, require_valid_social=require_valid_social):
        return False

    metrics = extract_graduated_metrics(raw)
    if not passes_market_gate(metrics['liquidity_usd'], metrics['volume_24h'], metrics['txns_24h'], settings, chain_norm):
        return False

    return True


def passes_market_gate(
    liquidity_usd: float,
    volume_24h: float,
    txns_24h: float,
    settings: object,
    chain: str | None = None,
) -> bool:
    chain_norm = _chain_key(chain)
    min_liquidity = _chain_threshold(settings, 'pump_graduated_quality_min_liquidity', chain_norm, 0.0)
    min_volume_24h = _chain_threshold(settings, 'pump_graduated_quality_min_volume_24h', chain_norm, 0.0)
    min_txns_24h = _chain_threshold(settings, 'pump_graduated_quality_min_txns_24h', chain_norm, 0.0)
    return (
        liquidity_usd >= min_liquidity
        and volume_24h >= min_volume_24h
        and txns_24h >= min_txns_24h
    )


def has_holders_signal(holders: int | None, txns_24h: float, settings: object, chain: str | None = None) -> bool:
    chain_norm = _chain_key(chain)
    min_holders = int(_chain_threshold(settings, 'pump_graduated_min_holders', chain_norm, 0.0))
    fallback_txns = int(_chain_threshold(settings, 'pump_graduated_quality_holders_fallback_txns', chain_norm, 0.0))
    if holders is not None and int(holders) >= min_holders:
        return True
    return txns_24h >= float(fallback_txns)


def first_blocking_reason(reasons: list[str] | tuple[str, ...], settings: object) -> str | None:
    if not reasons:
        return None
    blocked_exact = set(getattr(settings, 'pump_graduated_quality_block_reasons', []) or [])
    blocked_prefixes = tuple(getattr(settings, 'pump_graduated_quality_block_reason_prefixes', []) or [])
    for reason in reasons:
        if reason in blocked_exact:
            return reason
        for prefix in blocked_prefixes:
            if prefix and str(reason).startswith(prefix):
                return reason
    return None


def passes_quality_gate(item: dict, settings: object) -> tuple[bool, str | None]:
    if not bool(getattr(settings, 'pump_graduated_quality_mode', False)):
        return True, None

    score = _to_float(item.get('score'))
    if score < float(getattr(settings, 'pump_graduated_quality_min_score', 0.0) or 0.0):
        return False, 'quality_score'

    has_site = bool(item.get('website'))
    if not has_site:
        return False, 'website'

    require_valid_social = bool(getattr(settings, 'pump_graduated_quality_require_valid_social', True))
    if not has_quality_social(item.get('x_handle'), item.get('telegram_url'), require_valid_social=require_valid_social):
        return False, 'social'

    candidate_raw = item.get('candidate_raw') or item.get('raw') or {}
    chain_norm = _chain_key(item.get('chain'))
    metrics = extract_graduated_metrics(candidate_raw, liquidity_fallback=_to_float(item.get('liquidity_usd')))
    if not passes_market_gate(metrics['liquidity_usd'], metrics['volume_24h'], metrics['txns_24h'], settings, chain_norm):
        return False, 'market'

    if not has_holders_signal(item.get('holders'), metrics['txns_24h'], settings, chain_norm):
        return False, 'holders_signal'

    status = str(item.get('status') or '')
    if bool(getattr(settings, 'pump_graduated_quality_require_non_reject', True)) and status == 'REJECT':
        return False, 'rejected'

    reasons = item.get('reasons') or []
    if isinstance(reasons, tuple):
        reasons = list(reasons)
    if not isinstance(reasons, list):
        reasons = []
    blocked = first_blocking_reason(reasons, settings)
    if blocked:
        return False, f'blocked:{blocked}'

    return True, None
