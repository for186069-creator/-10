from __future__ import annotations

import asyncio
from typing import Any

import aiohttp

from app.core.config import settings


class HttpClient:
    _semaphore = asyncio.Semaphore(settings.max_concurrent_requests)

    def __init__(self) -> None:
        self.timeout = aiohttp.ClientTimeout(total=settings.request_timeout_seconds)
        self.headers = {'User-Agent': settings.http_user_agent}

    async def get_json(self, url: str, *, headers: dict[str, str] | None = None, params: dict[str, Any] | None = None, timeout: float | None = None) -> Any:
        return await self._request('GET', url, headers=headers, params=params, expect_json=True, timeout=timeout)

    async def get_text(self, url: str, *, headers: dict[str, str] | None = None, timeout: float | None = None) -> str:
        return await self._request('GET', url, headers=headers, expect_json=False, timeout=timeout)

    async def post_json(self, url: str, *, headers: dict[str, str] | None = None, json: Any | None = None, data: dict[str, Any] | None = None, timeout: float | None = None) -> Any:
        return await self._request('POST', url, headers=headers, json=json, data=data, expect_json=True, timeout=timeout)

    async def post_text(self, url: str, *, headers: dict[str, str] | None = None, json: Any | None = None, data: dict[str, Any] | None = None, timeout: float | None = None) -> str:
        return await self._request('POST', url, headers=headers, json=json, data=data, expect_json=False, timeout=timeout)

    async def _request(self, method: str, url: str, *, headers: dict[str, str] | None = None, params: dict[str, Any] | None = None, json: dict[str, Any] | None = None, data: dict[str, Any] | None = None, expect_json: bool = True, timeout: float | None = None) -> Any:
        effective_timeout = aiohttp.ClientTimeout(total=timeout) if timeout is not None else self.timeout
        async with self._semaphore:
            async with aiohttp.ClientSession(timeout=effective_timeout, headers={**self.headers, **(headers or {})}) as session:
                for attempt in range(3):
                    try:
                        async with session.request(method, url, params=params, json=json, data=data) as response:
                            if response.status in {429, 500, 502, 503, 504} and attempt < 2:
                                await asyncio.sleep(1.5 * (attempt + 1))
                                continue
                            response.raise_for_status()
                            return await response.json(content_type=None) if expect_json else await response.text()
                    except aiohttp.ClientError:
                        if attempt == 2:
                            raise
                        await asyncio.sleep(1.5 * (attempt + 1))
