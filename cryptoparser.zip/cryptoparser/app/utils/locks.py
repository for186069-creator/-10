from __future__ import annotations

import asyncio
import secrets
import time
from contextlib import asynccontextmanager

from app.core.config import settings

try:  # pragma: no cover
    import redis.asyncio as redis
except Exception:  # pragma: no cover
    redis = None


class LocalLockManager:
    def __init__(self) -> None:
        self._locks: dict[str, asyncio.Lock] = {}
        self._guard = asyncio.Lock()

    async def get_lock(self, key: str) -> asyncio.Lock:
        async with self._guard:
            lock = self._locks.get(key)
            if lock is None:
                lock = asyncio.Lock()
                self._locks[key] = lock
            return lock


class RedisLockManager:
    def __init__(self, redis_url: str, prefix: str = 'cryptoparser:lock') -> None:
        if redis is None:
            raise RuntimeError('redis package is not installed')
        self.client = redis.from_url(redis_url, decode_responses=True)
        self.prefix = prefix.rstrip(':')

    def _key(self, key: str) -> str:
        return f'{self.prefix}:{key}'

    @asynccontextmanager
    async def acquire(self, key: str, ttl_seconds: int = 30, wait_timeout: float = 10.0):
        token = secrets.token_hex(8)
        redis_key = self._key(key)
        deadline = time.time() + wait_timeout
        acquired = False
        try:
            while time.time() < deadline:
                acquired = bool(await self.client.set(redis_key, token, ex=ttl_seconds, nx=True))
                if acquired:
                    break
                await asyncio.sleep(0.05)
            yield acquired
        finally:
            if acquired:
                current = await self.client.get(redis_key)
                if current == token:
                    await self.client.delete(redis_key)


LOCAL_LOCKS = LocalLockManager()
REDIS_LOCKS = None
if settings.use_redis_cache:
    try:  # pragma: no cover
        REDIS_LOCKS = RedisLockManager(settings.redis_url)
    except Exception:
        REDIS_LOCKS = None
