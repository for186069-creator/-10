from __future__ import annotations

import asyncio
import random
import time
from dataclasses import dataclass, field
from typing import Generic, Iterable, TypeVar

T = TypeVar('T')


@dataclass
class ProviderState(Generic[T]):
    value: T
    weight: float = 1.0
    quota_per_minute: int = 120
    failures: int = 0
    cooldown_until: float = 0.0
    successes: int = 0
    last_latency_ms: float | None = None
    recent_calls: list[float] = field(default_factory=list)

    def available(self) -> bool:
        return self.cooldown_until <= time.time() and self.remaining_quota() > 0

    def remaining_quota(self) -> int:
        now = time.time()
        self.recent_calls = [ts for ts in self.recent_calls if now - ts < 60]
        return max(self.quota_per_minute - len(self.recent_calls), 0)

    def reserve(self) -> None:
        self.recent_calls.append(time.time())

    def score(self) -> float:
        quota_factor = self.remaining_quota() / max(self.quota_per_minute, 1)
        success_bias = 1 + (self.successes * 0.03)
        failure_penalty = 1 + (self.failures * 0.25)
        latency_penalty = 1 + ((self.last_latency_ms or 0) / 5000)
        return (self.weight * quota_factor * success_bias) / (failure_penalty * latency_penalty)


class ProviderRotator(Generic[T]):
    def __init__(
        self,
        providers: Iterable[T],
        *,
        cooldown_seconds: int = 30,
        weights: dict[str, float] | None = None,
        quotas_per_minute: dict[str, int] | None = None,
    ) -> None:
        values = [p for p in providers if p]
        if not values:
            raise ValueError('at least one provider is required')
        self.cooldown_seconds = cooldown_seconds
        weights = weights or {}
        quotas_per_minute = quotas_per_minute or {}
        self.states = [
            ProviderState(
                value=v,
                weight=float(weights.get(str(v), 1.0)),
                quota_per_minute=int(quotas_per_minute.get(str(v), 120)),
            )
            for v in values
        ]
        self._lock = asyncio.Lock()

    async def ordered(self) -> list[T]:
        async with self._lock:
            return [state.value for state in self._sorted_states()]

    async def reserve_next(self) -> T:
        async with self._lock:
            state = self._sorted_states()[0]
            state.reserve()
            return state.value

    def _sorted_states(self) -> list[ProviderState[T]]:
        available = [s for s in self.states if s.available()]
        unavailable = [s for s in self.states if not s.available()]
        if not available:
            unavailable.sort(key=lambda s: (s.cooldown_until, -s.weight, s.failures))
            return unavailable
        available.sort(key=lambda s: (-s.score(), random.random()))
        unavailable.sort(key=lambda s: (s.cooldown_until, -s.weight))
        return available + unavailable

    async def mark_success(self, provider: T, *, latency_ms: float | None = None) -> None:
        async with self._lock:
            for state in self.states:
                if state.value == provider:
                    state.successes += 1
                    state.failures = max(state.failures - 1, 0)
                    state.cooldown_until = 0.0
                    state.last_latency_ms = latency_ms
                    return

    async def mark_failure(self, provider: T) -> None:
        async with self._lock:
            for state in self.states:
                if state.value == provider:
                    state.failures += 1
                    state.cooldown_until = time.time() + min(self.cooldown_seconds * max(state.failures, 1), 300)
                    return

    async def snapshot(self) -> list[dict[str, float | int | str | None]]:
        async with self._lock:
            return [
                {
                    'provider': str(s.value),
                    'weight': s.weight,
                    'quota_per_minute': s.quota_per_minute,
                    'remaining_quota': s.remaining_quota(),
                    'failures': s.failures,
                    'successes': s.successes,
                    'cooldown_until': s.cooldown_until,
                    'last_latency_ms': s.last_latency_ms,
                }
                for s in self._sorted_states()
            ]
