from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass

from app.core.config import settings

try:  # pragma: no cover
    import redis.asyncio as redis
except Exception:  # pragma: no cover
    redis = None


@dataclass
class BudgetDecision:
    allowed: bool
    remaining: int
    retry_after_seconds: float = 0.0


class DistributedRateBudget:
    def __init__(self) -> None:
        self._local: dict[str, tuple[int, int]] = {}
        self._lock = asyncio.Lock()
        self._redis = redis.from_url(settings.redis_url, decode_responses=True) if (settings.use_redis_cache and redis is not None) else None

    def _bucket_key(self, group: str, provider: str) -> tuple[str, int]:
        minute = int(time.time() // 60)
        return f'cryptoparser:budget:{group}:{provider}:{minute}', minute

    async def consume(self, group: str, provider: str, quota_per_minute: int) -> BudgetDecision:
        quota = max(int(quota_per_minute or settings.provider_default_quota_per_minute), 1)
        if self._redis is not None:
            return await self._consume_redis(group, provider, quota)
        return await self._consume_local(group, provider, quota)

    async def remaining(self, group: str, provider: str, quota_per_minute: int) -> int:
        quota = max(int(quota_per_minute or settings.provider_default_quota_per_minute), 1)
        if self._redis is not None:
            key, _ = self._bucket_key(group, provider)
            used = int(await self._redis.get(key) or 0)
            return max(quota - used, 0)
        async with self._lock:
            key, minute = self._bucket_key(group, provider)
            used, stored_minute = self._local.get(key, (0, minute))
            if stored_minute != minute:
                return quota
            return max(quota - used, 0)

    async def _consume_local(self, group: str, provider: str, quota: int) -> BudgetDecision:
        async with self._lock:
            key, minute = self._bucket_key(group, provider)
            used, stored_minute = self._local.get(key, (0, minute))
            if stored_minute != minute:
                used = 0
            if used >= quota:
                retry_after = 60 - (time.time() % 60)
                return BudgetDecision(False, 0, retry_after)
            used += 1
            self._local[key] = (used, minute)
            return BudgetDecision(True, max(quota - used, 0), 0.0)

    async def _consume_redis(self, group: str, provider: str, quota: int) -> BudgetDecision:
        key, _ = self._bucket_key(group, provider)
        used = await self._redis.incr(key)
        if used == 1:
            await self._redis.expire(key, 70)
        if int(used) > quota:
            retry_after = 60 - (time.time() % 60)
            return BudgetDecision(False, 0, retry_after)
        return BudgetDecision(True, max(quota - int(used), 0), 0.0)


GLOBAL_RATE_BUDGET = DistributedRateBudget()
