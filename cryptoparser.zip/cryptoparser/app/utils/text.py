from __future__ import annotations

import re

from app.utils.graduated_quality import normalized_x_handle


def normalize_handle(value: str | None) -> str | None:
    return normalized_x_handle(value)


def normalize_url(value: str | None) -> str | None:
    if not value:
        return None
    value = value.strip().rstrip('/')
    if not value.startswith('http://') and not value.startswith('https://'):
        value = 'https://' + value
    return value


def contains_address(text: str, address: str | None) -> bool:
    if not text or not address:
        return False
    return address.lower() in text.lower()


def first_match(pattern: str, text: str, flags: int = re.IGNORECASE | re.DOTALL) -> str | None:
    match = re.search(pattern, text, flags)
    return re.sub(r'\s+', ' ', match.group(1)).strip() if match else None
