from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from app.core.config import settings
from app.utils.graduated_quality import is_multichain_graduated_signal

PUMP_SUFFIX = 'pump'
_PUMP_HINTS = ('pump.fun', 'pumpfun', 'pumpswap', 'pump swap')


def is_valid_solana_pump_suffix(token_address: str | None) -> bool:
    addr = (token_address or '').strip()
    if not addr:
        return False
    if not addr.endswith(PUMP_SUFFIX):
        return False
    # Solana mints are base58; pump suffix uses only base58-safe chars.
    if not (32 <= len(addr) <= 44):
        return False
    allowed = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz'
    return all(ch in allowed for ch in addr)


def classify_token_family(chain: str | None, token_address: str | None, raw: dict[str, Any] | None = None) -> dict[str, Any]:
    chain_norm = (chain or '').lower()
    raw = raw or {}
    addr = (token_address or '').strip()

    result: dict[str, Any] = {
        'token_family': 'standard',
        'launchpad': None,
        'token_family_reason': None,
        'is_pump_family': False,
    }

    if is_multichain_graduated_signal(chain_norm, raw, settings):
        result.update({
            'token_family': str(raw.get('token_family') or 'multichain_graduated'),
            'launchpad': raw.get('launchpad') or 'multichain_quality',
            'token_family_reason': 'multichain_graduated_quality',
            'is_pump_family': True,
        })
        return result

    if chain_norm != 'solana' or not addr:
        return result

    haystacks = [
        str(raw.get('url') or ''),
        str(raw.get('website') or ''),
        str(raw.get('symbol') or ''),
        str(raw.get('name') or ''),
        str(raw.get('description') or ''),
    ]
    extensions = raw.get('extensions') or {}
    if isinstance(extensions, dict):
        haystacks.extend(str(v or '') for v in extensions.values())
    pair = raw.get('pair') or {}
    if isinstance(pair, dict):
        info = pair.get('info') or {}
        for site in info.get('websites') or []:
            haystacks.append(str(site.get('url') or ''))
        for social in info.get('socials') or []:
            haystacks.append(str(social.get('url') or ''))

    text = ' '.join(h.lower() for h in haystacks if h)

    if is_valid_solana_pump_suffix(addr):
        result.update({
            'token_family': 'pump_suffix',
            'launchpad': 'pump_fun',
            'token_family_reason': 'solana_mint_suffix_pump',
            'is_pump_family': True,
        })
        return result

    if any(hint in text for hint in _PUMP_HINTS):
        result.update({
            'token_family': 'pump_fun',
            'launchpad': 'pump_fun',
            'token_family_reason': 'pump_fun_metadata_hint',
            'is_pump_family': True,
        })
    return result


def _coerce_datetime(value: Any) -> datetime | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        dt = value
    elif isinstance(value, str):
        raw = value.strip()
        if not raw:
            return None
        if raw.endswith('Z'):
            raw = raw[:-1] + '+00:00'
        try:
            dt = datetime.fromisoformat(raw)
        except ValueError:
            return None
    else:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt


def classify_decision_profile(chain: str | None, token_address: str | None, raw: dict[str, Any] | None = None, first_seen_at: Any = None) -> dict[str, Any]:
    raw = raw or {}
    family = classify_token_family(chain, token_address, raw)
    dt = _coerce_datetime(first_seen_at or raw.get('first_seen_at'))
    age_minutes: float | None = None
    if dt is not None:
        age_minutes = max((datetime.now(timezone.utc) - dt).total_seconds() / 60.0, 0.0)
    is_pump_family = bool(
        family.get('is_pump_family')
        or raw.get('multichain_graduated')
        or str(raw.get('token_family') or '').lower() == 'multichain_graduated'
        or str(raw.get('launchpad') or '').lower() == 'multichain_quality'
    )
    pair = raw.get('pair') or {}
    dex_id = str(pair.get('dexId') or '').lower() if isinstance(pair, dict) else ''
    has_graduated_pair = 'raydium' in dex_id or 'pumpswap' in dex_id
    has_multichain_signal = bool(
        raw.get('multichain_graduated')
        or family.get('token_family_reason') == 'multichain_graduated_quality'
    )
    has_graduation_signal = bool(
        raw.get('graduated_confirmed')
        or raw.get('graduated_raydium')
        or has_multichain_signal
        or raw.get('lifecycle_stage') == 'graduated'
        or (raw.get('complete') is True and raw.get('raydium_pool'))
        or (raw.get('raydium_pool') and has_graduated_pair)
    )
    in_grace = bool(
        is_pump_family
        and not has_graduation_signal
        and (age_minutes is None or age_minutes <= settings.pump_early_grace_minutes)
    )
    is_graduated = bool(is_pump_family and has_graduation_signal)
    if is_graduated:
        profile = 'pump_graduated'
    elif in_grace:
        profile = 'pump_early'
    else:
        profile = 'standard'
    return {
        'decision_profile': profile,
        'is_pump_early': in_grace,
        'is_pump_graduated': is_graduated,
        'token_age_minutes': round(age_minutes, 2) if age_minutes is not None else None,
        'graduated_confirmed': has_graduation_signal,
    }
