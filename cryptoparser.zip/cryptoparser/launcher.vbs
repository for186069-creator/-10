Set sh = CreateObject("WScript.Shell")
base = CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName)

sh.Run "cmd /c cd /d """ & base & """ && python -m app.main scheduler >> scheduler.log 2>&1", 0, False
sh.Run "cmd /c cd /d """ & base & """ && python -m app.main admin >> admin.log 2>&1", 0, False
