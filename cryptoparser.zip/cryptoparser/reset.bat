@echo off
chcp 65001 >nul
title CryptoParser — Reset
color 0C

echo.
echo  ╔══════════════════════════════════════╗
echo  ║   CryptoParser  ^|  RESET DATABASE    ║
echo  ╚══════════════════════════════════════╝
echo.
echo  ВСІ дані будуть видалені:
echo  - токени, рішення, алерти
echo  - ручні Review
echo  - графи, ML-дані
echo  - статистика
echo.
set /p CONFIRM=  Введи YES для підтвердження: 

if /i not "%CONFIRM%"=="YES" (
    echo.
    echo  Скасовано.
    pause & exit /b 0
)

echo.
echo  Зупини start.bat якщо він запущений, потім натисни будь-яку клавішу...
pause >nul

echo.
echo  [1/3] Видаляю базу даних...
if exist cryptoparser.db (
    del /f cryptoparser.db
    echo        cryptoparser.db видалено
) else (
    echo        cryptoparser.db не знайдено — пропускаю
)

echo.
echo  [2/3] Очищую кеш Python...
for /d /r . %%d in (__pycache__) do (
    if exist "%%d" rd /s /q "%%d" 2>nul
)
echo        __pycache__ очищено

echo.
echo  [3/3] Створюю нову базу даних...
python -m alembic upgrade head
if %errorlevel% neq 0 (
    echo  [ERROR] Не вдалось створити БД. Спробуй запустити start.bat — він створить автоматично.
    pause & exit /b 1
)

echo.
echo  ╔══════════════════════════════════════╗
echo  ║   Готово! База очищена.              ║
echo  ║   Запускай start.bat                 ║
echo  ╚══════════════════════════════════════╝
echo.
pause
