[CmdletBinding()]
param(
    [string]$OutputDir = "dist",
    [string]$PackagePrefix = "cryptoparser-gumroad-release",
    [switch]$KeepStaging
)

$ErrorActionPreference = "Stop"

$Root = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$Timestamp = Get-Date -Format "yyyyMMdd-HHmm"
$OutputPath = Join-Path $Root $OutputDir
$StagingPath = Join-Path $OutputPath "$PackagePrefix-$Timestamp"
$ZipPath = "$StagingPath.zip"

if (-not (Test-Path -LiteralPath $OutputPath)) {
    New-Item -ItemType Directory -Path $OutputPath | Out-Null
}
if (Test-Path -LiteralPath $StagingPath) {
    Remove-Item -LiteralPath $StagingPath -Recurse -Force
}
if (Test-Path -LiteralPath $ZipPath) {
    Remove-Item -LiteralPath $ZipPath -Force
}
New-Item -ItemType Directory -Path $StagingPath | Out-Null

$excludeDirs = @(
    ".git",
    ".pytest_cache",
    "__pycache__",
    ".venv",
    "venv",
    "dist",
    "build",
    "gumroad-package"
)

$excludeFiles = @(
    ".env",
    "cryptoparser.db",
    "admin.log",
    "scheduler.log",
    "reset.bat",
    "validate_pump_patch.py",
    "validation_report*.txt",
    "scripts\\generate_onboarding_pdf.py",
    "scripts\\build_gumroad_package.ps1",
    "scripts\\build_final_release.ps1",
    "*.pyc",
    "*.pyo"
)

$robocopyArgs = @(
    $Root,
    $StagingPath,
    "/E",
    "/R:1",
    "/W:1",
    "/NFL",
    "/NDL",
    "/NJH",
    "/NJS",
    "/NC",
    "/NS",
    "/NP"
)

if ($excludeDirs.Count -gt 0) {
    $robocopyArgs += "/XD"
    $robocopyArgs += $excludeDirs
}
if ($excludeFiles.Count -gt 0) {
    $robocopyArgs += "/XF"
    $robocopyArgs += $excludeFiles
}

& robocopy @robocopyArgs | Out-Null
$robocopyExit = $LASTEXITCODE
if ($robocopyExit -gt 7) {
    throw "robocopy failed with exit code $robocopyExit"
}

# Hard prune files that /XF path matching may miss.
foreach ($relative in @(
    "scripts\\generate_onboarding_pdf.py",
    "scripts\\build_gumroad_package.ps1",
    "scripts\\build_final_release.ps1"
)) {
    $prunePath = Join-Path $StagingPath $relative
    if (Test-Path -LiteralPath $prunePath) {
        Remove-Item -LiteralPath $prunePath -Force
    }
}
try {
    $scriptsDir = Join-Path $StagingPath "scripts"
    if (Test-Path -LiteralPath $scriptsDir) {
        $items = Get-ChildItem -LiteralPath $scriptsDir -Force
        if (-not $items) {
            Remove-Item -LiteralPath $scriptsDir -Force
        }
    }
} catch {
    # Ignore optional cleanup failure.
}

# Ensure buyer docs exist in release root.
foreach ($doc in @("README.md", "LICENSE", "GUMROAD_CHECKLIST.md", "GUMROAD_LISTING.md", "BUYER_ONBOARDING.md", "BUYER_ONBOARDING.pdf", ".env.example")) {
    $docPath = Join-Path $Root $doc
    if (-not (Test-Path -LiteralPath $docPath)) {
        throw "Required release doc missing: $doc"
    }
}

Compress-Archive -Path $StagingPath -DestinationPath $ZipPath -Force

if (-not $KeepStaging) {
    Remove-Item -LiteralPath $StagingPath -Recurse -Force
}

Write-Host "Final release package ready:" -ForegroundColor Green
Write-Host $ZipPath
