[CmdletBinding()]
param(
    [string]$OutputDir = "dist",
    [string]$PackagePrefix = "cryptoparser-gumroad",
    [switch]$KeepStaging
)

$ErrorActionPreference = "Stop"

$Root = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$Timestamp = Get-Date -Format "yyyyMMdd-HHmm"
$OutputPath = Join-Path $Root $OutputDir
$StagingPath = Join-Path $OutputPath "$PackagePrefix-$Timestamp"
$ZipPath = "$StagingPath.zip"

if (-not (Test-Path -LiteralPath $OutputPath)) {
    New-Item -ItemType Directory -Path $OutputPath | Out-Null
}
if (Test-Path -LiteralPath $StagingPath) {
    Remove-Item -LiteralPath $StagingPath -Recurse -Force
}
if (Test-Path -LiteralPath $ZipPath) {
    Remove-Item -LiteralPath $ZipPath -Force
}
New-Item -ItemType Directory -Path $StagingPath | Out-Null

$excludeDirs = @(
    ".git",
    ".pytest_cache",
    "__pycache__",
    ".venv",
    "venv",
    "dist",
    "build",
    "gumroad-package"
)

$excludeFiles = @(
    ".env",
    "cryptoparser.db",
    "admin.log",
    "scheduler.log",
    "*.pyc",
    "*.pyo"
)

$robocopyArgs = @(
    $Root,
    $StagingPath,
    "/E",
    "/R:1",
    "/W:1",
    "/NFL",
    "/NDL",
    "/NJH",
    "/NJS",
    "/NC",
    "/NS",
    "/NP"
)

if ($excludeDirs.Count -gt 0) {
    $robocopyArgs += "/XD"
    $robocopyArgs += $excludeDirs
}
if ($excludeFiles.Count -gt 0) {
    $robocopyArgs += "/XF"
    $robocopyArgs += $excludeFiles
}

& robocopy @robocopyArgs | Out-Null
$robocopyExit = $LASTEXITCODE
if ($robocopyExit -gt 7) {
    throw "robocopy failed with exit code $robocopyExit"
}

Compress-Archive -Path $StagingPath -DestinationPath $ZipPath -Force

if (-not $KeepStaging) {
    Remove-Item -LiteralPath $StagingPath -Recurse -Force
}

Write-Host "Gumroad package ready:" -ForegroundColor Green
Write-Host $ZipPath

