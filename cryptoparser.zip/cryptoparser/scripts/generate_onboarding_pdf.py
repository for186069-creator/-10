from __future__ import annotations

from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "BUYER_ONBOARDING.md"
DST = ROOT / "BUYER_ONBOARDING.pdf"


def _escape_pdf_text(text: str) -> str:
    return text.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")


def _markdown_to_lines(raw: str) -> list[str]:
    lines: list[str] = []
    for original in raw.splitlines():
        line = original.rstrip()
        if line.startswith("# "):
            lines.append(line[2:].strip().upper())
            lines.append("")
            continue
        if line.startswith("## "):
            lines.append(line[3:].strip())
            continue
        if line.startswith("```"):
            continue
        if line.startswith("- "):
            lines.append(f"- {line[2:].strip()}")
            continue
        if line.startswith(("1. ", "2. ", "3. ", "4. ", "5. ", "6. ", "7. ", "8. ", "9. ")):
            lines.append(line)
            continue
        lines.append(line)

    # Keep it one-page friendly by dropping very long blank runs.
    cleaned: list[str] = []
    blank = False
    for item in lines:
        if item == "":
            if blank:
                continue
            blank = True
            cleaned.append(item)
            continue
        blank = False
        cleaned.append(item)
    return cleaned


def _build_pdf(lines: list[str]) -> bytes:
    max_lines = 52  # fit on one US Letter page with 12pt leading
    lines = lines[:max_lines]
    content = ["BT", "/F1 11 Tf", "54 760 Td", "12 TL"]
    for line in lines:
        if line == "":
            content.append("T*")
            continue
        content.append(f"({_escape_pdf_text(line)}) Tj")
        content.append("T*")
    content.append("ET")
    stream = ("\n".join(content) + "\n").encode("latin-1", errors="replace")

    objs: list[bytes] = []
    objs.append(b"1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n")
    objs.append(b"2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n")
    objs.append(
        b"3 0 obj\n"
        b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] "
        b"/Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>\n"
        b"endobj\n"
    )
    objs.append(b"4 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>\nendobj\n")
    objs.append(
        f"5 0 obj\n<< /Length {len(stream)} >>\nstream\n".encode("ascii")
        + stream
        + b"endstream\nendobj\n"
    )

    out = bytearray()
    out.extend(b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n")

    offsets = [0]
    for obj in objs:
        offsets.append(len(out))
        out.extend(obj)

    xref_pos = len(out)
    out.extend(f"xref\n0 {len(objs) + 1}\n".encode("ascii"))
    out.extend(b"0000000000 65535 f \n")
    for off in offsets[1:]:
        out.extend(f"{off:010d} 00000 n \n".encode("ascii"))

    out.extend(
        (
            "trailer\n"
            f"<< /Size {len(objs) + 1} /Root 1 0 R >>\n"
            "startxref\n"
            f"{xref_pos}\n"
            "%%EOF\n"
        ).encode("ascii")
    )
    return bytes(out)


def main() -> None:
    if not SRC.exists():
        raise SystemExit(f"Source not found: {SRC}")
    lines = _markdown_to_lines(SRC.read_text(encoding="utf-8"))
    pdf = _build_pdf(lines)
    DST.write_bytes(pdf)
    print(f"Generated: {DST}")


if __name__ == "__main__":
    main()

