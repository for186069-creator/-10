"""
CryptoParser — Setup Wizard
GUI конфігуратор .env файлу
"""

# ── DPI fix (ПЕРШИМ — до будь-якого tkinter) ──────────────────────────────
import ctypes, sys
if sys.platform == "win32":
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass

# ── Стандартні імпорти ────────────────────────────────────────────────────
import os, secrets, subprocess, threading, tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path

# ── Шлях до .env (поруч з wizard) ────────────────────────────────────────
BASE_DIR = Path(__file__).parent
ENV_PATH = BASE_DIR / ".env"

# ── Кольорова схема ───────────────────────────────────────────────────────
BG       = "#0f0f0f"
BG2      = "#1a1a1a"
BG3      = "#242424"
ACCENT   = "#e53935"
GREEN    = "#2e7d32"
FG       = "#f0f0f0"
FG2      = "#9e9e9e"
BORDER   = "#333333"
FONT     = ("Segoe UI", 10)
FONT_B   = ("Segoe UI", 10, "bold")
FONT_H   = ("Segoe UI", 13, "bold")

# ── Читання / запис .env ──────────────────────────────────────────────────
def read_env() -> dict:
    env = {}
    if ENV_PATH.exists():
        for line in ENV_PATH.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, _, v = line.partition("=")
                env[k.strip()] = v.strip()
    return env

def write_env(env: dict):
    lines = []
    if ENV_PATH.exists():
        for line in ENV_PATH.read_text(encoding="utf-8").splitlines():
            stripped = line.strip()
            if stripped and not stripped.startswith("#") and "=" in stripped:
                k = stripped.split("=", 1)[0].strip()
                if k in env:
                    lines.append(f"{k}={env.pop(k)}")
                else:
                    lines.append(line)
            else:
                lines.append(line)
    for k, v in env.items():
        lines.append(f"{k}={v}")
    ENV_PATH.write_text("\n".join(lines) + "\n", encoding="utf-8")

# ── Допоміжні UI-компоненти ───────────────────────────────────────────────
def enable_paste(entry):
    """Явний бінд Ctrl+V / правої кнопки для вставки"""
    def paste(e=None):
        try:
            text = entry.clipboard_get()
            try:    entry.delete(tk.SEL_FIRST, tk.SEL_LAST)
            except: pass
            entry.insert(tk.INSERT, text)
        except Exception:
            pass
        return "break"
    entry.bind("<Control-v>", paste)
    entry.bind("<Control-V>", paste)
    # правий клік → контекстне меню
    menu = tk.Menu(entry, tearoff=0, bg=BG3, fg=FG, activebackground=ACCENT,
                   activeforeground=FG, font=FONT)
    menu.add_command(label="Paste", command=paste)
    menu.add_command(label="Copy",
                     command=lambda: entry.event_generate("<<Copy>>"))
    menu.add_command(label="Cut",
                     command=lambda: entry.event_generate("<<Cut>>"))
    menu.add_separator()
    menu.add_command(label="Select All",
                     command=lambda: entry.select_range(0, "end"))
    def show_menu(e):
        menu.tk_popup(e.x_root, e.y_root)
    entry.bind("<Button-3>", show_menu)

def labeled_entry(parent, label, desc="", show="", width=52):
    frame = tk.Frame(parent, bg=BG2, bd=0, highlightthickness=1,
                     highlightbackground=BORDER)
    frame.pack(fill="x", padx=18, pady=6)

    top = tk.Frame(frame, bg=BG2)
    top.pack(fill="x", padx=12, pady=(10, 2))
    tk.Label(top, text=label, font=FONT_B, bg=BG2, fg=FG).pack(side="left")
    if desc:
        tk.Label(top, text=f"  ({desc})", font=("Segoe UI", 9),
                 bg=BG2, fg=FG2).pack(side="left")

    entry = tk.Entry(frame, font=FONT, bg=BG3, fg=FG, insertbackground=FG,
                     relief="flat", bd=0, width=width, show=show)
    entry.pack(padx=12, pady=(2, 10), fill="x")
    enable_paste(entry)
    return entry, frame

def labeled_entry_with_toggle(parent, label, desc="", width=52):
    """Entry з кнопкою Show/Hide"""
    frame = tk.Frame(parent, bg=BG2, bd=0, highlightthickness=1,
                     highlightbackground=BORDER)
    frame.pack(fill="x", padx=18, pady=6)

    top = tk.Frame(frame, bg=BG2)
    top.pack(fill="x", padx=12, pady=(10, 2))
    tk.Label(top, text=label, font=FONT_B, bg=BG2, fg=FG).pack(side="left")
    if desc:
        tk.Label(top, text=f"  ({desc})", font=("Segoe UI", 9),
                 bg=BG2, fg=FG2).pack(side="left")

    row = tk.Frame(frame, bg=BG2)
    row.pack(fill="x", padx=12, pady=(2, 10))

    entry = tk.Entry(row, font=FONT, bg=BG3, fg=FG, insertbackground=FG,
                     relief="flat", bd=0, show="•")
    entry.pack(side="left", fill="x", expand=True)
    enable_paste(entry)

    visible = tk.BooleanVar(value=False)
    def toggle():
        entry.config(show="" if visible.get() else "•")
        visible.set(not visible.get())
        btn.config(text="Hide" if visible.get() else "Show")
    btn = tk.Button(row, text="Show", font=("Segoe UI", 9), bg=BG3, fg=FG2,
                    relief="flat", bd=0, cursor="hand2", command=toggle)
    btn.pack(side="right", padx=(8, 0))
    return entry, frame

def labeled_checkbox(parent, label, desc=""):
    frame = tk.Frame(parent, bg=BG2, bd=0, highlightthickness=1,
                     highlightbackground=BORDER)
    frame.pack(fill="x", padx=18, pady=6)

    var = tk.BooleanVar()
    row = tk.Frame(frame, bg=BG2)
    row.pack(fill="x", padx=12, pady=10)
    cb = tk.Checkbutton(row, variable=var, bg=BG2, fg=FG,
                        selectcolor=BG3, activebackground=BG2,
                        font=FONT, text="Enabled")
    cb.pack(side="left")
    tk.Label(row, text=label, font=FONT_B, bg=BG2, fg=FG).pack(side="left",
                                                                padx=(12, 0))
    if desc:
        tk.Label(row, text=f"  ({desc})", font=("Segoe UI", 9),
                 bg=BG2, fg=FG2).pack(side="left")
    return var, frame

def labeled_scale(parent, label, from_, to, desc=""):
    frame = tk.Frame(parent, bg=BG2, bd=0, highlightthickness=1,
                     highlightbackground=BORDER)
    frame.pack(fill="x", padx=18, pady=6)

    top = tk.Frame(frame, bg=BG2)
    top.pack(fill="x", padx=12, pady=(10, 2))
    tk.Label(top, text=label, font=FONT_B, bg=BG2, fg=FG).pack(side="left")
    if desc:
        tk.Label(top, text=f"  ({desc})", font=("Segoe UI", 9),
                 bg=BG2, fg=FG2).pack(side="left")

    var = tk.DoubleVar()
    val_label = tk.Label(top, text="0", font=FONT_B, bg=BG2, fg=ACCENT,
                         width=6)
    val_label.pack(side="right")

    scale = tk.Scale(frame, variable=var, from_=from_, to=to,
                     orient="horizontal", bg=BG2, fg=FG,
                     troughcolor=BG3, highlightthickness=0,
                     sliderrelief="flat", bd=0, resolution=1,
                     command=lambda v: val_label.config(text=str(int(float(v)))))
    scale.pack(fill="x", padx=12, pady=(0, 10))
    return var, frame

def section_header(parent, text):
    tk.Label(parent, text=text, font=FONT_H, bg=BG, fg=ACCENT,
             anchor="w").pack(fill="x", padx=18, pady=(16, 4))

# ── Головне вікно ─────────────────────────────────────────────────────────
class SetupWizard(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("CryptoParser — Setup Wizard")
        self.configure(bg=BG)
        self.resizable(True, True)
        self.geometry("780x680")
        self.minsize(700, 580)

        # центрування
        self.update_idletasks()
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        x = (sw - 780) // 2
        y = (sh - 680) // 2
        self.geometry(f"780x680+{x}+{y}")

        self.env = read_env()
        self._auto_fix_token()
        self._build_ui()
        self._load_values()

    # ── авто-замінює небезпечний токен ───────────────────────────────────
    def _auto_fix_token(self):
        t = self.env.get("ADMIN_API_TOKEN", "")
        if not t or t in ("22", "changeme", "your_token_here", ""):
            self.env["ADMIN_API_TOKEN"] = secrets.token_hex(24)

    # ── Верхній хедер ────────────────────────────────────────────────────
    def _build_ui(self):
        header = tk.Frame(self, bg="#1a0000", height=72)
        header.pack(fill="x")
        header.pack_propagate(False)
        tk.Label(header, text="⬡  CryptoParser", font=("Segoe UI", 18, "bold"),
                 bg="#1a0000", fg=ACCENT).pack(side="left", padx=24, pady=16)
        tk.Label(header, text="Configuration Wizard", font=("Segoe UI", 11),
                 bg="#1a0000", fg=FG2).pack(side="left", pady=16)

        # ── Tabs ─────────────────────────────────────────────────────────
        style = ttk.Style(self)
        style.theme_use("default")
        style.configure("Dark.TNotebook", background=BG, borderwidth=0,
                        tabmargins=[0, 0, 0, 0])
        style.configure("Dark.TNotebook.Tab", background=BG2, foreground=FG2,
                        padding=[14, 8], font=FONT, borderwidth=0)
        style.map("Dark.TNotebook.Tab",
                  background=[("selected", BG), ("active", BG3)],
                  foreground=[("selected", FG)])

        self.nb = ttk.Notebook(self, style="Dark.TNotebook")
        self.nb.pack(fill="both", expand=True, padx=0, pady=0)

        self._tab_security()
        self._tab_api_keys()
        self._tab_telegram()
        self._tab_risk()
        self._tab_rpc()
        self._tab_advanced()

        # ── Кнопки внизу ─────────────────────────────────────────────────
        bottom = tk.Frame(self, bg="#111111", height=60)
        bottom.pack(fill="x", side="bottom")
        bottom.pack_propagate(False)

        tk.Button(bottom, text="✕  Cancel", font=FONT_B, bg="#2a2a2a",
                  fg=FG2, relief="flat", bd=0, padx=20, cursor="hand2",
                  command=self.destroy).pack(side="left", padx=18, pady=12)

        tk.Button(bottom, text="💾  Save & Close", font=FONT_B, bg=ACCENT,
                  fg=FG, relief="flat", bd=0, padx=20, cursor="hand2",
                  command=self._save_close).pack(side="right", padx=10, pady=12)

        tk.Button(bottom, text="▶  Save & Launch", font=FONT_B, bg=GREEN,
                  fg=FG, relief="flat", bd=0, padx=20, cursor="hand2",
                  command=self._save_launch).pack(side="right", padx=4, pady=12)

    # ── Tab: Security ─────────────────────────────────────────────────────
    def _tab_security(self):
        f = self._make_scroll_tab("🔐  Security")
        section_header(f, "Admin Access")

        frm = tk.Frame(f, bg=BG2, bd=0, highlightthickness=1,
                       highlightbackground=BORDER)
        frm.pack(fill="x", padx=18, pady=6)
        tk.Label(frm, text="Admin API Token", font=FONT_B,
                 bg=BG2, fg=FG).pack(anchor="w", padx=12, pady=(10, 2))
        tk.Label(frm, text="  (ADMIN_API_TOKEN)", font=("Segoe UI", 9),
                 bg=BG2, fg=FG2).pack(anchor="w", padx=12)

        row = tk.Frame(frm, bg=BG2)
        row.pack(fill="x", padx=12, pady=(4, 10))
        self.w_token = tk.Entry(row, font=FONT, bg=BG3, fg=FG,
                                insertbackground=FG, relief="flat", bd=0)
        self.w_token.pack(side="left", fill="x", expand=True)
        tk.Button(row, text="Generate", font=("Segoe UI", 9), bg=ACCENT,
                  fg=FG, relief="flat", bd=0, padx=10, cursor="hand2",
                  command=self._gen_token).pack(side="right", padx=(8, 0))

        section_header(f, "Environment")
        self.w_env, _ = labeled_entry(f, "ENV", "ENV", width=20)
        self.w_dryrun, _ = labeled_checkbox(f, "Dry Run", "DRY_RUN")

    # ── Tab: API Keys ─────────────────────────────────────────────────────
    def _tab_api_keys(self):
        f = self._make_scroll_tab("🔑  API Keys")
        section_header(f, "Blockchain APIs")
        self.w_etherscan, _ = labeled_entry_with_toggle(f, "Etherscan API Key",
                                                        "ETHERSCAN_API_KEY")
        self.w_birdeye, _   = labeled_entry_with_toggle(f, "Birdeye API Key",
                                                        "BIRDEYE_API_KEY")
        self.w_goplus, _    = labeled_entry_with_toggle(f, "GoPlus API Key",
                                                        "GOPLUS_API_KEY (optional)")

    # ── Tab: Telegram ─────────────────────────────────────────────────────
    def _tab_telegram(self):
        f = self._make_scroll_tab("📡  Telegram")
        section_header(f, "Bot Configuration")
        self.w_tg_token, _   = labeled_entry_with_toggle(f, "Bot Token",
                                                         "TELEGRAM_BOT_TOKEN")
        self.w_tg_chat, _    = labeled_entry(f, "Chat ID", "TELEGRAM_CHAT_ID")
        self.w_tg_enable, _  = labeled_checkbox(f, "Enable Telegram",
                                                "ENABLE_TELEGRAM")

    # ── Tab: Risk Filters ─────────────────────────────────────────────────
    def _tab_risk(self):
        f = self._make_scroll_tab("⚙️  Risk Filters")
        section_header(f, "Score Thresholds")
        self.w_min_score, _  = labeled_scale(f, "Min Score",       0, 100,
                                             "MIN_SCORE")
        self.w_min_liq, _    = labeled_scale(f, "Min Liquidity",   0, 500000,
                                             "MIN_LIQUIDITY_USD")
        self.w_min_hold, _   = labeled_scale(f, "Min Holders",     0, 1000,
                                             "MIN_HOLDERS")
        self.w_poll, _       = labeled_scale(f, "Poll Interval (s)", 10, 300,
                                             "POLL_INTERVAL")

    # ── Tab: RPC Nodes ────────────────────────────────────────────────────
    def _tab_rpc(self):
        f = self._make_scroll_tab("🌐  RPC Nodes")
        section_header(f, "Blockchain RPC URLs")
        self.w_sol_rpc, _ = labeled_entry(f, "Solana RPC",   "SOLANA_RPC_URL")
        self.w_bsc_rpc, _ = labeled_entry(f, "BSC RPC",      "BSC_RPC_URL")
        self.w_eth_rpc, _ = labeled_entry(f, "Ethereum RPC", "ETH_RPC_URL")
        self.w_base_rpc,_ = labeled_entry(f, "Base RPC",     "BASE_RPC_URL")

    # ── Tab: Advanced ─────────────────────────────────────────────────────
    def _tab_advanced(self):
        f = self._make_scroll_tab("🔧  Advanced")
        section_header(f, "Database & Services")
        self.w_db_url, _    = labeled_entry(f, "Database URL",      "DATABASE_URL")
        self.w_birdeye_en,_ = labeled_checkbox(f, "Enable Birdeye",  "ENABLE_BIRDEYE")
        self.w_goplus_en, _ = labeled_checkbox(f, "Enable GoPlus",   "ENABLE_GOPLUS")
        self.w_honeypot, _  = labeled_checkbox(f, "Enable Honeypot", "ENABLE_HONEYPOT")

    # ── Хелпери ───────────────────────────────────────────────────────────
    def _make_scroll_tab(self, title):
        outer = tk.Frame(self.nb, bg=BG)
        self.nb.add(outer, text=f"  {title}  ")

        canvas = tk.Canvas(outer, bg=BG, highlightthickness=0, bd=0)
        sb = ttk.Scrollbar(outer, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=sb.set)

        sb.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)

        inner = tk.Frame(canvas, bg=BG)
        win = canvas.create_window((0, 0), window=inner, anchor="nw")

        def on_configure(e):
            canvas.configure(scrollregion=canvas.bbox("all"))
        def on_canvas_resize(e):
            canvas.itemconfig(win, width=e.width)

        inner.bind("<Configure>", on_configure)
        canvas.bind("<Configure>", on_canvas_resize)
        canvas.bind_all("<MouseWheel>",
                        lambda e: canvas.yview_scroll(-1*(e.delta//120), "units"))
        return inner

    def _gen_token(self):
        self.w_token.delete(0, "end")
        self.w_token.insert(0, secrets.token_hex(24))

    # ── Завантаження значень з .env ───────────────────────────────────────
    def _load_values(self):
        e = self.env
        def s(widget, key, default=""):
            widget.delete(0, "end")
            widget.insert(0, e.get(key, default))
        def b(var, key):
            var.set(e.get(key, "false").lower() in ("true", "1", "yes"))
        def n(var, key, default=0):
            try:    var.set(float(e.get(key, default)))
            except: var.set(default)

        s(self.w_token,      "ADMIN_API_TOKEN")
        s(self.w_env,        "ENV", "production")
        b(self.w_dryrun,     "DRY_RUN")

        s(self.w_etherscan,  "ETHERSCAN_API_KEY")
        s(self.w_birdeye,    "BIRDEYE_API_KEY")
        s(self.w_goplus,     "GOPLUS_API_KEY")

        s(self.w_tg_token,   "TELEGRAM_BOT_TOKEN")
        s(self.w_tg_chat,    "TELEGRAM_CHAT_ID")
        b(self.w_tg_enable,  "ENABLE_TELEGRAM")

        n(self.w_min_score,  "MIN_SCORE", 50)
        n(self.w_min_liq,    "MIN_LIQUIDITY_USD", 10000)
        n(self.w_min_hold,   "MIN_HOLDERS", 50)
        n(self.w_poll,       "POLL_INTERVAL", 60)

        s(self.w_sol_rpc,    "SOLANA_RPC_URL")
        s(self.w_bsc_rpc,    "BSC_RPC_URL")
        s(self.w_eth_rpc,    "ETH_RPC_URL")
        s(self.w_base_rpc,   "BASE_RPC_URL")

        s(self.w_db_url,     "DATABASE_URL",
          "sqlite+aiosqlite:///./cryptoparser.db")
        b(self.w_birdeye_en, "ENABLE_BIRDEYE")
        b(self.w_goplus_en,  "ENABLE_GOPLUS")
        b(self.w_honeypot,   "ENABLE_HONEYPOT")

    # ── Збір значень → dict ───────────────────────────────────────────────
    def _collect(self) -> dict:
        def bval(v): return "true" if v.get() else "false"
        def ival(v): return str(int(v.get()))
        return {
            "ADMIN_API_TOKEN":   self.w_token.get().strip(),
            "ENV":               self.w_env.get().strip(),
            "DRY_RUN":           bval(self.w_dryrun),
            "ETHERSCAN_API_KEY": self.w_etherscan.get().strip(),
            "BIRDEYE_API_KEY":   self.w_birdeye.get().strip(),
            "GOPLUS_API_KEY":    self.w_goplus.get().strip(),
            "TELEGRAM_BOT_TOKEN":self.w_tg_token.get().strip(),
            "TELEGRAM_CHAT_ID":  self.w_tg_chat.get().strip(),
            "ENABLE_TELEGRAM":   bval(self.w_tg_enable),
            "MIN_SCORE":         ival(self.w_min_score),
            "MIN_LIQUIDITY_USD": ival(self.w_min_liq),
            "MIN_HOLDERS":       ival(self.w_min_hold),
            "POLL_INTERVAL":     ival(self.w_poll),
            "SOLANA_RPC_URL":    self.w_sol_rpc.get().strip(),
            "BSC_RPC_URL":       self.w_bsc_rpc.get().strip(),
            "ETH_RPC_URL":       self.w_eth_rpc.get().strip(),
            "BASE_RPC_URL":      self.w_base_rpc.get().strip(),
            "DATABASE_URL":      self.w_db_url.get().strip(),
            "ENABLE_BIRDEYE":    bval(self.w_birdeye_en),
            "ENABLE_GOPLUS":     bval(self.w_goplus_en),
            "ENABLE_HONEYPOT":   bval(self.w_honeypot),
        }

    def _validate(self) -> bool:
        d = self._collect()
        if not d["ADMIN_API_TOKEN"]:
            messagebox.showerror("Validation", "Admin API Token is required.")
            return False
        return True

    def _save_close(self):
        if not self._validate(): return
        write_env(self._collect())
        messagebox.showinfo("Saved", f".env saved to:\n{ENV_PATH}")
        self.destroy()

    def _save_launch(self):
        if not self._validate(): return
        write_env(self._collect())
        messagebox.showinfo("Saved", ".env saved. Launching CryptoParser...")
        bat = BASE_DIR / "start.bat"
        if bat.exists():
            threading.Thread(target=lambda: subprocess.Popen(
                str(bat), cwd=str(BASE_DIR), shell=True), daemon=True).start()
        self.destroy()

# ── Entry point ───────────────────────────────────────────────────────────
if __name__ == "__main__":
    app = SetupWizard()
    app.mainloop()
