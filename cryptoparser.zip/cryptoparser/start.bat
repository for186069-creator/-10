@echo off
title CryptoParser

:: Navigate to app folder
cd /d "%~dp0"

:: Read token from .env
set "TOKEN="
for /f "usebackq tokens=1,* delims==" %%A in (".env") do (
    if /i "%%A"=="ADMIN_API_TOKEN" set "TOKEN=%%B"
)

:: Read admin API port (default 8080)
set "PORT=8080"
for /f "usebackq tokens=1,* delims==" %%A in (".env") do (
    if /i "%%A"=="ADMIN_API_PORT" set "PORT=%%B"
)
if "%PORT%"=="8080" (
  for /f "usebackq tokens=1,* delims==" %%A in (".env") do (
      if /i "%%A"=="PORT" set "PORT=%%B"
  )
)

:: Launch both processes silently via VBScript
echo [*] Starting CryptoParser...
wscript.exe "%~dp0launcher.vbs"

:: Wait for server
echo [*] Waiting for server...
:WAIT_LOOP
timeout /t 2 /nobreak >nul
powershell -Command "try { $r=(Invoke-WebRequest -Uri 'http://localhost:%PORT%/health' -TimeoutSec 2 -UseBasicParsing).StatusCode; if($r -eq 200){exit 0} } catch { exit 1 }" >nul 2>&1
if errorlevel 1 goto WAIT_LOOP

:: Open browser
echo [*] Opening dashboard...
if not "%TOKEN%"=="" (
    start "" "http://localhost:%PORT%/analyst?token=%TOKEN%"
) else (
    start "" "http://localhost:%PORT%/analyst"
)

echo [OK] CryptoParser is running. Do not close this window.
echo      To stop - close this window.
:KEEP_ALIVE
timeout /t 30 /nobreak >nul
goto KEEP_ALIVE
