from __future__ import annotations

import ast
import importlib.util
import py_compile
import re
import sys
import types
from pathlib import Path

ROOT = Path(__file__).resolve().parent

EX1 = 'CGEDT9QZDvvH5GmVkWJH2BXiMJqMJySC9ihWyr7Spump'
EX2 = 'NV2RYH954cTJ3ckFUpvfqaQXU4ARqqDH3562nFSpump'
EX3 = '4YiLHDR4B4pE4R5GUMA8HG8YunyeLwcobtEtvwMupump'

FEED_HTML = f'''
<a href="/coin/{EX1}">A</a>
<img alt="Coin image for {EX2}" src="x">
<script>window.__DATA__={{"mint":"{EX3}"}}</script>
<a href="/coin/{EX1}">dupe</a>
'''
COIN_HTML = '''
<html>
<head>
<title>Just Pumployee $PUMPLOYED | Pump</title>
<meta property="og:title" content="Just Pumployee $PUMPLOYED | Pump">
<meta property="og:description" content="No description...">
</head>
<body>
<a href="https://x.com/examplecoin">x</a>
<a href="https://examplecoin.site">site</a>
</body>
</html>
'''


def check(name: str, cond: bool) -> None:
    if not cond:
        raise AssertionError(name)
    print(f'PASS {name}')


def load_token_classifier():
    path = ROOT / 'app' / 'utils' / 'token_classifier.py'
    spec = importlib.util.spec_from_file_location('token_classifier_mod', path)
    mod = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(mod)
    return mod


def load_pumpfun_module():
    # Stub only the modules PumpFunClient needs at import time.
    cfg_mod = types.ModuleType('app.core.config')
    cfg_mod.settings = types.SimpleNamespace(
        pumpfun_base_url='https://pump.fun',
        pumpswap_base_url='https://swap.pump.fun',
        pumpfun_feed_paths=['/live', '/new'],
        pumpfun_max_candidates_per_cycle=80,
        pumpfun_request_timeout_seconds=12,
    )
    http_mod = types.ModuleType('app.utils.http')

    class DummyHttpClient:
        async def get_text(self, *args, **kwargs):
            return ''

    http_mod.HttpClient = DummyHttpClient

    tc = load_token_classifier()
    sys.modules['app'] = types.ModuleType('app')
    sys.modules['app.core'] = types.ModuleType('app.core')
    sys.modules['app.core.config'] = cfg_mod
    sys.modules['app.utils'] = types.ModuleType('app.utils')
    sys.modules['app.utils.http'] = http_mod
    sys.modules['app.utils.token_classifier'] = tc

    path = ROOT / 'app' / 'adapters' / 'pumpfun.py'
    spec = importlib.util.spec_from_file_location('pumpfun_mod', path)
    mod = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(mod)
    return mod


def parse_ast(path: str) -> ast.AST:
    return ast.parse((ROOT / path).read_text(encoding='utf-8'))


def function_text(path: str, marker: str) -> str:
    text = (ROOT / path).read_text(encoding='utf-8')
    idx = text.index(marker)
    return text[idx: idx + 600]


def main() -> None:
    # 1-4 compile validation
    py_compile.compile(str(ROOT / 'app' / 'adapters' / 'pumpfun.py'), doraise=True)
    check('1 py_compile app/adapters/pumpfun.py', True)
    py_compile.compile(str(ROOT / 'app' / 'services' / 'normalizer.py'), doraise=True)
    check('2 py_compile app/services/normalizer.py', True)
    py_compile.compile(str(ROOT / 'app' / 'admin' / 'api.py'), doraise=True)
    check('3 py_compile app/admin/api.py', True)
    py_compile.compile(str(ROOT / 'app' / 'main.py'), doraise=True)
    check('4 py_compile app/main.py', True)

    # 5-9 token classifier runtime checks
    tc = load_token_classifier()
    check('5 valid pump suffix example 1', tc.is_valid_solana_pump_suffix(EX1))
    check('6 valid pump suffix example 2', tc.is_valid_solana_pump_suffix(EX2))
    check('7 valid pump suffix example 3', tc.is_valid_solana_pump_suffix(EX3))
    check('8 invalid address rejected', not tc.is_valid_solana_pump_suffix(EX1[:-1]))
    fam = tc.classify_token_family('solana', EX1, {'website': f'https://pump.fun/coin/{EX1}'})
    check('9 family classified as pump_suffix', fam['token_family'] == 'pump_suffix' and fam['launchpad'] == 'pump_fun')

    # 10-13 pumpfun parser runtime checks with stubbed imports
    pf = load_pumpfun_module().PumpFunClient()
    mints = pf._extract_mints(FEED_HTML)
    check('10 feed parser extracts 3 unique mints', mints == [EX1, EX2, EX3])
    check('11 title extractor parses current-style title', pf._extract_title(COIN_HTML) == 'Just Pumployee $PUMPLOYED | Pump')
    check('12 description extractor parses current-style description', pf._extract_description(COIN_HTML) == 'No description...')
    check('13 link extractors parse x and website', pf._extract_x_url(COIN_HTML) == 'https://x.com/examplecoin' and pf._extract_website_url(COIN_HTML) == 'https://examplecoin.site')

    # 14-16 source validations in normalizer
    normalizer_src = (ROOT / 'app' / 'services' / 'normalizer.py').read_text(encoding='utf-8')
    check('14 normalizer maps pump website', "item.get('website') or item.get('coin_url')" in normalizer_src)
    check('15 normalizer maps pump x_handle', "x_handle = normalize_handle(item.get('x_url'))" in normalizer_src)
    check('16 normalizer emits links object', "links=links" in normalizer_src)

    # 17-18 source validations in admin api
    api_src = (ROOT / 'app' / 'admin' / 'api.py').read_text(encoding='utf-8')
    check('17 health endpoint is unauthenticated', "@app.get('/health', dependencies=[Depends(admin_auth)])" not in api_src)
    check('18 ready endpoint is unauthenticated', "@app.get('/ready', dependencies=[Depends(admin_auth)])" not in api_src)

    # 19-20 scheduler and fast lane presence in source
    main_src = (ROOT / 'app' / 'main.py').read_text(encoding='utf-8')
    queue_src = (ROOT / 'app' / 'queue' / 'service.py').read_text(encoding='utf-8')
    check('19 scheduler includes pump fast job', "ScheduledJobDefinition('poller_pump_fast'" in main_src)
    check('20 queue prefers ingest fast lane', "msg = await self.backend.pop(settings.queue_name_ingest_fast, timeout=0)" in queue_src)


if __name__ == '__main__':
    main()
