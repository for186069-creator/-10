"""
app/main.py — FastAPI entry point with lifespan + graceful shutdown.

Graceful shutdown:
  1. SIGTERM/SIGINT received → stop accepting new HTTP requests
  2. Cancel all active quotes (LIVE: real cancel_order API calls)
  3. Stop MarketMaker + ClobService
  4. Dispose DB engine
  5. Exit

Bot starts PAUSED — user clicks "Start Trading" via /api/start.
"""
from __future__ import annotations

import asyncio
import signal
import sys
from contextlib import asynccontextmanager

import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from prometheus_client import make_asgi_app

from app.admin.api import admin_router, inject_services, root_router
from app.core.config import settings
from app.core.db import engine
from app.core.logging import configure_logging, get_logger
from app.db.init_db import init_db
from app.services.alerter import alerter
from app.services.analytics import Analytics
from app.services.clob_client import ClobService
from app.services.inventory_manager import InventoryManager
from app.services.market_maker import MarketMaker
from app.services.risk.risk_manager import RiskManager

configure_logging()
log = get_logger(__name__)

# ── Globals (instantiated once) ──────────────────────────────────────────
clob = ClobService()
inventory = InventoryManager()
risk = RiskManager(inventory, clob)
mm = MarketMaker(clob, inventory, risk)
analytics = Analytics()


async def _select_markets() -> list[str]:
    """Pick markets to MM on. Returns token IDs."""
    # 1. Explicit list from config
    explicit = settings.explicit_token_ids
    if explicit:
        log.info("using_explicit_markets", count=len(explicit))
        return explicit
    # 2. Auto-pick from Gamma API
    if settings.auto_pick_markets:
        # Dynamic market count based on bankroll
        if settings.auto_pick_dynamic:
            bankroll = inventory.bankroll
            dynamic_count = max(1, int(bankroll / 10))
            old_count = settings.auto_pick_count
            settings.auto_pick_count = min(dynamic_count, 20)
            log.info(
                "dynamic_market_count",
                bankroll=round(bankroll, 2),
                calculated_markets=settings.auto_pick_count,
                old_setting=old_count,
            )
        infos = await clob.discover_markets()
        if infos:
            # Store MarketInfo objects BEFORE starting clob
            for info in infos:
                clob.markets[info.token_id] = info
            return [info.token_id for info in infos]
    log.error("no_markets_selected")
    return []


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan: startup + shutdown."""
    log.info(
        "bot_starting",
        mode="PAPER" if settings.paper_trading else "LIVE",
        spread=settings.spread_cents,
        order_size=settings.order_size_usdc,
        max_inventory=settings.max_inventory_usdc,
    )

    # Init DB
    await init_db()

    # Select markets
    token_ids = await _select_markets()
    if not token_ids:
        log.error("no_markets_to_trade_exiting")
        # Don't crash — let user hit /api/markets/replace manually
    else:
        # Start CLOB client (REST + WS + market data)
        await clob.start(token_ids)

    # Inject services into admin router
    inject_services(clob, inventory, mm, risk, analytics, alerter)

    # Start MM engine (PAUSED — user clicks Start)
    await mm.start()

    # Wire up signal handlers
    loop = asyncio.get_running_loop()
    stop_event = asyncio.Event()

    def _signal_handler(sig: int) -> None:
        log.info("signal_received", signal=sig)
        stop_event.set()

    for sig in (signal.SIGTERM, signal.SIGINT):
        try:
            loop.add_signal_handler(sig, _signal_handler, sig)
        except NotImplementedError:
            # Windows fallback
            signal.signal(sig, lambda s, f: _signal_handler(s))

    # Background task: wait for stop signal
    stop_task = asyncio.create_task(stop_event.wait())

    yield

    # ── Shutdown ──
    log.info("shutdown_initiated")
    stop_task.cancel()
    try:
        await stop_task
    except asyncio.CancelledError:
        pass

    # 1. Stop MM (cancels all active quotes)
    await mm.stop()
    # 2. Stop CLOB (closes WS + REST polling)
    await clob.stop()
    # 3. Dispose DB engine
    await engine.dispose()
    log.info("shutdown_complete")


app = FastAPI(
    title="Polymarket Professional MM Bot",
    version="1.0.0",
    description="Production-grade market maker with Avellaneda-Stoikov + Kyle's lambda",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Local admin only — tighten in prod if exposed
    allow_methods=["*"],
    allow_headers=["*"],
)

# Routes
app.include_router(admin_router, prefix="/api")
app.include_router(root_router)

# Prometheus metrics at /metrics
metrics_app = make_asgi_app()
app.mount("/metrics", metrics_app)

# Static dashboard at /
import os

if os.path.exists("app/static"):
    app.mount("/", StaticFiles(directory="app/static", html=True), name="static")


if __name__ == "__main__":
    uvicorn.run(
        "app.main:app",
        host=settings.admin_host,
        port=settings.admin_port,
        reload=False,
        log_level=settings.log_level.lower(),
        access_log=False,  # structlog handles our logging
    )
