"""
app/services/analytics.py — P&L analytics + market quality scoring.

Pure functions operating on Trade records (from DB) and current bot state.
"""
from __future__ import annotations

import time
from collections import defaultdict, deque
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone

from app.core.config import settings
from app.core.logging import get_logger

log = get_logger(__name__)


@dataclass
class PnLBucket:
    """One minute bucket of P&L for time-series charts."""

    timestamp: float
    realized_pnl: float = 0.0
    trade_count: int = 0


class Analytics:
    """Compute P&L, win rate, Sharpe, drawdown from Trade records."""

    @staticmethod
    def _to_aware(dt: datetime) -> datetime:
        """Convert naive datetime (from SQLite) to timezone-aware UTC.

        FIX: SQLite stores datetimes as naive strings. When SQLAlchemy parses
        them, we get offset-naive datetimes. Comparing with datetime.now(timezone.utc)
        (offset-aware) raises TypeError. This helper normalizes both sides.
        """
        if dt is None:
            return datetime.now(timezone.utc)
        if dt.tzinfo is None:
            return dt.replace(tzinfo=timezone.utc)
        return dt

    @staticmethod
    def compute_summary(trades: list) -> dict:
        """Compute all-time + 24h summary from a list of Trade ORM objects."""
        if not trades:
            return {
                "total_trades": 0,
                "total_realized_pnl": 0.0,
                "win_rate": 0.0,
                "avg_win": 0.0,
                "avg_loss": 0.0,
                "profit_factor": 0.0,
                "max_drawdown": 0.0,
                "sharpe_estimate": 0.0,
                "trades_24h": 0,
                "pnl_24h": 0.0,
            }

        now = datetime.now(timezone.utc)
        cutoff_24h = now - timedelta(hours=24)

        # Win rate based on ROUND-TRIPS (BUY→SELL pairs), not individual fills
        # BUY fills have pnl=-0.005 (gas only) — not real wins/losses
        # SELL fills have real pnl — but counting only SELLs gives 100% if no losses
        # Correct: count each BUY→SELL pair as one round-trip, win if total pnl > 0

        # Group fills by market and pair BUY→SELL chronologically
        from collections import defaultdict
        market_fills = defaultdict(list)
        for t in trades:
            if t.pnl_usdc is not None:
                market_fills[t.market_id].append(t)

        winners = 0
        losers = 0
        wins_pnl = 0.0
        losses_pnl = 0.0

        for market_id, fills in market_fills.items():
            fills.sort(key=lambda x: x.timestamp if x.timestamp else datetime.min)
            open_buy = None
            for t in fills:
                if t.side.value == "BUY":
                    if open_buy is None:
                        open_buy = t
                    else:
                        # Stacked buys without sell — skip for simplicity
                        pass
                elif t.side.value == "SELL" and open_buy is not None:
                    # Complete round-trip
                    rt_pnl = (open_buy.pnl_usdc or 0) + (t.pnl_usdc or 0)
                    if rt_pnl > 0.01:
                        winners += 1
                        wins_pnl += rt_pnl
                    elif rt_pnl < -0.01:
                        losers += 1
                        losses_pnl += abs(rt_pnl)
                    open_buy = None

        closed_count = winners + losers
        win_rate = (winners / max(closed_count, 1)) * 100
        avg_win = wins_pnl / max(winners, 1)
        avg_loss = losses_pnl / max(losers, 1)
        profit_factor = wins_pnl / max(losses_pnl, 0.0001)

        # Build list of round-trip P&Ls for drawdown + sharpe
        rt_pnls: list[float] = []
        for market_id, fills in market_fills.items():
            fills.sort(key=lambda x: x.timestamp if x.timestamp else datetime.min)
            open_buy = None
            for t in fills:
                if t.side.value == "BUY":
                    if open_buy is None:
                        open_buy = t
                elif t.side.value == "SELL" and open_buy is not None:
                    rt_pnl = (open_buy.pnl_usdc or 0) + (t.pnl_usdc or 0)
                    rt_pnls.append(rt_pnl)
                    open_buy = None

        # Max drawdown: peak-to-trough on cumulative P&L
        cumulative = 0.0
        peak = 0.0
        max_dd = 0.0
        for pnl in rt_pnls:
            cumulative += pnl
            peak = max(peak, cumulative)
            dd = peak - cumulative
            max_dd = max(max_dd, dd)

        # Sharpe estimate: mean/std of round-trip P&Ls
        if len(rt_pnls) >= 5:
            mean = sum(rt_pnls) / len(rt_pnls)
            var = sum((p - mean) ** 2 for p in rt_pnls) / max(len(rt_pnls) - 1, 1)
            std = var ** 0.5
            sharpe = mean / std if std > 0 else 0.0
        else:
            sharpe = 0.0

        # FIX: normalize timestamps to aware before comparison (SQLite stores naive)
        trades_24h = [
            t for t in trades
            if t.timestamp and Analytics._to_aware(t.timestamp) >= cutoff_24h
        ]
        pnl_24h = sum(t.pnl_usdc or 0 for t in trades_24h)

        total_pnl = sum(t.pnl_usdc or 0 for t in trades)

        # Include unrealized losses as "open losing positions" in win rate
        # This prevents 100% win rate when bot has stuck losing positions
        # that haven't been sold yet (v1.0.26 blocks selling below entry)
        open_losers = 0
        open_winners = 0
        for market_id, fills in market_fills.items():
            fills.sort(key=lambda x: x.timestamp if x.timestamp else datetime.min)
            open_buy = None
            for t in fills:
                if t.side.value == "BUY":
                    if open_buy is None:
                        open_buy = t
                elif t.side.value == "SELL" and open_buy is not None:
                    open_buy = None
            # If there's an unclosed BUY, it's an "open position"
            # We can't calculate unrealized P&L here (no current mid price)
            # but we count it as neither win nor loss — just "open"

        # Adjusted win rate: (winners) / (winners + losers + open_losers)
        # Open positions with unrealized loss count as "potential losses"
        # For now: just note that win rate only counts CLOSED round-trips
        adjusted_win_rate = win_rate if closed_count > 0 else 0.0

        return {
            "total_trades": len(trades),
            "total_realized_pnl": round(total_pnl, 4),
            "closed_trades": closed_count,
            "win_rate": round(adjusted_win_rate, 1),
            "win_rate_note": f"{closed_count} closed, {len(market_fills) - closed_count} open" if closed_count > 0 else "no closed trades",
            "avg_win": round(avg_win, 4),
            "avg_loss": round(avg_loss, 4),
            "profit_factor": round(profit_factor, 2),
            "max_drawdown": round(max_dd, 4),
            "sharpe_estimate": round(sharpe, 3),
            "trades_24h": len(trades_24h),
            "pnl_24h": round(pnl_24h, 4),
        }

    @staticmethod
    def by_market(trades: list) -> list[dict]:
        """P&L grouped by market_id."""
        by_mkt: dict[str, list] = defaultdict(list)
        for t in trades:
            by_mkt[t.market_id].append(t)

        result = []
        for market_id, mkt_trades in by_mkt.items():
            name = mkt_trades[0].market_name if mkt_trades else market_id[:12]
            pnl = sum(t.pnl_usdc or 0 for t in mkt_trades)
            buys = sum(1 for t in mkt_trades if t.side.value == "BUY")
            sells = sum(1 for t in mkt_trades if t.side.value == "SELL")
            result.append(
                {
                    "market_id": market_id[:16],
                    "market_name": name[:50],
                    "trade_count": len(mkt_trades),
                    "realized_pnl": round(pnl, 4),
                    "buys": buys,
                    "sells": sells,
                }
            )
        result.sort(key=lambda x: x["realized_pnl"], reverse=True)
        return result

    @staticmethod
    def pnl_time_series(trades: list, bucket_sec: int = 60) -> list[dict]:
        """Bucket trades into time intervals for charts."""
        if not trades:
            return []
        buckets: dict[int, PnLBucket] = {}
        for t in trades:
            ts = t.timestamp.timestamp() if t.timestamp else 0
            bucket_ts = (ts // bucket_sec) * bucket_sec
            if bucket_ts not in buckets:
                buckets[bucket_ts] = PnLBucket(timestamp=bucket_ts)
            buckets[bucket_ts].realized_pnl += t.pnl_usdc or 0
            buckets[bucket_ts].trade_count += 1
        return [
            {
                "timestamp": b.timestamp,
                "datetime": datetime.fromtimestamp(b.timestamp, tz=timezone.utc).isoformat(),
                "pnl": round(b.realized_pnl, 4),
                "trades": b.trade_count,
                "cumulative_pnl": 0.0,  # filled below
            }
            for b in sorted(buckets.values(), key=lambda x: x.timestamp)
        ]
