"""
tests/unit/test_market_maker_live.py — Tests for the v1.0.39 LIVE-mode fixes.

These tests cover the four P0 bugs that were fixed in v1.0.39:
  PATCH-1: _pending_orders is populated after LIVE order placement.
  PATCH-2: _liquidate_aged_positions places a real SELL order in LIVE.
  PATCH-3: _handle_pre_resolution places a real order in LIVE.
  PATCH-4: _attempt_active_hedge places a real order on the paired token in LIVE.
  PATCH-5: start_live_polling() creates _poll_task when toggled at runtime.

The ClobService is mocked so we don't need py-clob-client installed to run
these tests — we only verify that the market maker CALLS clob.place_order
with the right arguments and updates its internal state accordingly.

NOTE (honest disclosure): these tests were NOT executed during development
because the test environment lacks fastapi/sqlalchemy/py-clob-client. They
are written to be runnable with `pytest tests/unit/test_market_maker_live.py`
once dependencies are installed. Treat as UNVERIFIED until executed.
"""
from __future__ import annotations

import asyncio
import time
from unittest.mock import AsyncMock, MagicMock

import pytest


# ── Helpers ────────────────────────────────────────────────────────────────


def _make_order_result(success: bool, order_id: str = "", raw: dict | None = None, error: str = ""):
    """Build a fake OrderResult for the mocked ClobService.place_order."""
    from app.services.clob_client import OrderResult

    return OrderResult(success=success, order_id=order_id, raw=raw or {}, error=error)


@pytest.fixture
def fake_book():
    """A balanced book around 0.50 mid."""
    from app.services.clob_client import MarketBook, OrderLevel

    return MarketBook(
        token_id="tok-A",
        bids=[OrderLevel(0.48, 100), OrderLevel(0.47, 200)],
        asks=[OrderLevel(0.52, 100), OrderLevel(0.53, 200)],
        last_price=0.50,
    )


@pytest.fixture
def fake_market_info():
    from app.services.clob_client import MarketInfo

    return MarketInfo(
        token_id="tok-A",
        condition_id="cond-1",
        question="Will X happen?",
        outcome="Yes",
        end_date_ts=time.time() + 86400,
        volume_24h=50000.0,
    )


@pytest.fixture
def live_mm(monkeypatch, fake_book, fake_market_info):
    """Build a MarketMaker wired to a MOCKED ClobService, in LIVE mode.

    We monkeypatch settings.paper_trading = False so all LIVE branches execute.
    """
    from app.core.config import settings
    from app.services.market_maker import MarketMaker
    from app.services.inventory_manager import InventoryManager
    from app.services.risk.risk_manager import RiskManager

    monkeypatch.setattr(settings, "paper_trading", False)
    monkeypatch.setattr(settings, "order_size_usdc", 5.0)
    monkeypatch.setattr(settings, "max_inventory_usdc", 10.0)
    monkeypatch.setattr(settings, "hedging_enabled", True)
    monkeypatch.setattr(settings, "hedging_active_enabled", True)
    monkeypatch.setattr(settings, "inventory_liquidation_enabled", True)
    monkeypatch.setattr(settings, "inventory_liquidation_aggressive_age_sec", 0.01)
    monkeypatch.setattr(settings, "inventory_liquidation_urgent_age_sec", 0.02)
    monkeypatch.setattr(settings, "inventory_liquidation_max_loss_cents", 100.0)

    clob = MagicMock()
    clob.books = {"tok-A": fake_book}
    clob.markets = {"tok-A": fake_market_info}
    clob.place_order = AsyncMock(
        return_value=_make_order_result(True, order_id="ord-1", raw={"price": "0.49"})
    )
    clob.cancel_order = AsyncMock(return_value=True)
    clob.cancel_all = AsyncMock(return_value=0)
    clob.last_ws_msg_age = 1.0

    inventory = InventoryManager()
    inventory.bankroll = 100.0
    risk = RiskManager(inventory, clob)

    mm = MarketMaker(clob, inventory, risk)
    mm._running = True
    return mm


# ── PATCH-1: _pending_orders is populated ─────────────────────────────────


@pytest.mark.asyncio
async def test_patch1_pending_orders_populated_after_live_quote(live_mm, fake_book):
    """After _place_quote_level in LIVE, _pending_orders must contain the
    order_id returned by clob.place_order."""
    from app.services.clob_client import MarketBook

    # Force place_order to return distinct order_ids for bid and ask
    call_n = {"i": 0}

    async def fake_place(token_id, side, price, size_usdc, **kw):
        call_n["i"] += 1
        return _make_order_result(
            True, order_id=f"ord-{side}-{call_n['i']}", raw={"price": str(price)}
        )

    live_mm.clob.place_order = AsyncMock(side_effect=fake_place)

    quote = await live_mm._place_quote_level(
        token_id="tok-A",
        level=1,
        bid_price=0.49,
        ask_price=0.51,
        size_usdc=5.0,
        mid=0.50,
        reservation=0.50,
        spread_cents=4.0,
        market_name="Will X happen?",
        book=fake_book,
    )

    assert quote is not None, "Expected a quote to be placed"
    assert quote.bid_order_id == "ord-BUY-1"
    assert quote.ask_order_id == "ord-SELL-2"
    # The critical assertion: pending orders must now exist
    assert "ord-BUY-1" in live_mm._pending_orders, "PATCH-1: bid order not tracked"
    assert "ord-SELL-2" in live_mm._pending_orders, "PATCH-1: ask order not tracked"
    assert live_mm._pending_orders["ord-BUY-1"]["side"] == "BUY"
    assert live_mm._pending_orders["ord-SELL-2"]["side"] == "SELL"
    assert live_mm._pending_orders["ord-BUY-1"]["token_id"] == "tok-A"


@pytest.mark.asyncio
async def test_patch1_failed_order_not_tracked(live_mm, fake_book):
    """If place_order fails, no pending entry should be created."""
    live_mm.clob.place_order = AsyncMock(
        return_value=_make_order_result(False, error="insufficient balance")
    )

    quote = await live_mm._place_quote_level(
        token_id="tok-A",
        level=1,
        bid_price=0.49,
        ask_price=0.51,
        size_usdc=5.0,
        mid=0.50,
        reservation=0.50,
        spread_cents=4.0,
        market_name="Will X happen?",
        book=fake_book,
    )

    # Both failed → _place_quote_level returns None
    assert quote is None
    assert live_mm._pending_orders == {}, "Failed orders must not be tracked"


# ── PATCH-2: liquidation places a real SELL in LIVE ──────────────────────


@pytest.mark.asyncio
async def test_patch2_liquidation_places_real_sell(live_mm, fake_book, fake_market_info):
    """_liquidate_aged_positions must call clob.place_order with SELL in LIVE
    mode, not call _record_fill directly."""
    # Seed an aged long position
    inv = live_mm.inventory.get_inventory("tok-A")
    inv.net_tokens = 100.0
    inv.avg_entry_price = 0.45
    inv.open_time = time.monotonic() - 1000  # very aged

    # Mock _record_fill to avoid DB writes
    live_mm._record_fill = AsyncMock()

    await live_mm._liquidate_aged_positions()

    # Critical: place_order must have been called with SELL
    live_mm.clob.place_order.assert_called_once()
    args, kwargs = live_mm.clob.place_order.call_args
    # Signature: place_order(token_id, side, price, size_usdc, ...)
    assert args[0] == "tok-A"
    assert args[1] == "SELL", f"Expected SELL, got {args[1]}"
    assert args[2] > 0, "Sell price must be positive"
    live_mm._record_fill.assert_awaited_once()
    assert live_mm._liquidation_count == 1


@pytest.mark.asyncio
async def test_patch2_liquidation_failed_sell_no_phantom_fill(live_mm, fake_book):
    """If the real SELL order fails, _record_fill must NOT be called.
    This is the whole point of the fix — no phantom fills."""
    inv = live_mm.inventory.get_inventory("tok-A")
    inv.net_tokens = 100.0
    inv.avg_entry_price = 0.45
    inv.open_time = time.monotonic() - 1000

    live_mm.clob.place_order = AsyncMock(
        return_value=_make_order_result(False, error="no liquidity")
    )
    live_mm._record_fill = AsyncMock()

    await live_mm._liquidate_aged_positions()

    live_mm.clob.place_order.assert_called_once()
    live_mm._record_fill.assert_not_awaited(), "Phantom fill recorded despite failed order!"
    assert live_mm._liquidation_count == 0


# ── PATCH-3: pre-resolution places a real order in LIVE ──────────────────


@pytest.mark.asyncio
async def test_patch3_pre_resolution_places_real_sell(live_mm, fake_book):
    """_handle_pre_resolution must place a real SELL in LIVE."""
    inv = live_mm.inventory.get_inventory("tok-A")
    inv.net_tokens = 50.0
    inv.avg_entry_price = 0.45
    inv.open_time = time.monotonic()

    live_mm._record_fill = AsyncMock()

    await live_mm._handle_pre_resolution("tok-A", fake_book, "Will X happen?")

    live_mm.clob.place_order.assert_called_once()
    args, _ = live_mm.clob.place_order.call_args
    assert args[0] == "tok-A"
    assert args[1] == "SELL"
    live_mm._record_fill.assert_awaited_once()


# ── PATCH-4: hedge places a real order on the paired token in LIVE ───────


@pytest.mark.asyncio
async def test_patch4_hedge_places_real_order_live(live_mm, fake_book, fake_market_info):
    """_attempt_active_hedge must place a real order on the paired token
    in LIVE mode. Previously the `else` branch was missing entirely."""
    # Build paired token B (the "No" side of the same condition)
    from app.services.clob_client import MarketBook, MarketInfo, OrderLevel

    paired_book = MarketBook(
        token_id="tok-B",
        bids=[OrderLevel(0.47, 100)],
        asks=[OrderLevel(0.48, 100)],
    )
    paired_info = MarketInfo(
        token_id="tok-B",
        condition_id="cond-1",  # same condition_id → pairs with tok-A
        question="Will X happen?",
        outcome="No",
        end_date_ts=time.time() + 86400,
        volume_24h=50000.0,
    )
    live_mm.clob.books["tok-B"] = paired_book
    live_mm.clob.markets["tok-B"] = paired_info

    # Seed a BUY fill on tok-A so a hedge (BUY on tok-B) is attempted
    live_mm.inventory.get_inventory("tok-A").net_tokens = 10.0
    live_mm.inventory.get_inventory("tok-A").avg_entry_price = 0.50

    live_mm._record_fill = AsyncMock()
    live_mm._build_hedging_pairs()

    # filled_price=0.50 (BUY YES), paired ask=0.48 → total=0.98 < 1.0 → arb exists
    await live_mm._attempt_active_hedge(
        filled_token_id="tok-A",
        filled_side="BUY",
        filled_size_usdc=5.0,
        market_name="Will X happen?",
        filled_price=0.50,
    )

    # place_order must have been called on tok-B with side=BUY
    live_mm.clob.place_order.assert_called_once()
    args, _ = live_mm.clob.place_order.call_args
    assert args[0] == "tok-B", f"Hedge should target paired token tok-B, got {args[0]}"
    assert args[1] == "BUY", f"Hedge for BUY fill should BUY paired, got {args[1]}"
    live_mm._record_fill.assert_awaited_once()


# ── PATCH-5: start_live_polling creates the task ─────────────────────────


@pytest.mark.asyncio
async def test_patch5_start_live_polling_creates_task(live_mm):
    """start_live_polling() must create _poll_task when in LIVE mode."""
    assert live_mm._poll_task is None
    await live_mm.start_live_polling()
    assert live_mm._poll_task is not None, "PATCH-5: poll task not created"
    assert not live_mm._poll_task.done()
    # Cleanup
    live_mm._poll_task.cancel()
    try:
        await live_mm._poll_task
    except (asyncio.CancelledError, Exception):
        pass


@pytest.mark.asyncio
async def test_patch5_start_live_polling_idempotent(live_mm):
    """Calling start_live_polling twice must not create a second task."""
    await live_mm.start_live_polling()
    first = live_mm._poll_task
    await live_mm.start_live_polling()
    assert live_mm._poll_task is first, "Idempotency broken — second task created"
    first.cancel()
    try:
        await first
    except (asyncio.CancelledError, Exception):
        pass


@pytest.mark.asyncio
async def test_patch5_start_live_polling_paper_mode_noop(monkeypatch, live_mm):
    """In PAPER mode start_live_polling must be a no-op."""
    from app.core.config import settings

    monkeypatch.setattr(settings, "paper_trading", True)
    await live_mm.start_live_polling()
    assert live_mm._poll_task is None


# ── Sanity: paper mode still uses _record_fill directly ──────────────────


@pytest.mark.asyncio
async def test_paper_liquidation_uses_record_fill_directly(monkeypatch, fake_book, fake_market_info):
    """In PAPER mode _liquidate_aged_positions must NOT call place_order —
    it should call _record_fill directly (legacy simulation path)."""
    from app.core.config import settings
    from app.services.market_maker import MarketMaker
    from app.services.inventory_manager import InventoryManager
    from app.services.risk.risk_manager import RiskManager

    monkeypatch.setattr(settings, "paper_trading", True)
    monkeypatch.setattr(settings, "inventory_liquidation_aggressive_age_sec", 0.01)
    monkeypatch.setattr(settings, "inventory_liquidation_urgent_age_sec", 0.02)
    monkeypatch.setattr(settings, "inventory_liquidation_max_loss_cents", 100.0)

    clob = MagicMock()
    clob.books = {"tok-A": fake_book}
    clob.markets = {"tok-A": fake_market_info}
    clob.place_order = AsyncMock()
    clob.last_ws_msg_age = 1.0

    inventory = InventoryManager()
    inventory.bankroll = 100.0
    risk = RiskManager(inventory, clob)
    mm = MarketMaker(clob, inventory, risk)
    mm._running = True

    inv = mm.inventory.get_inventory("tok-A")
    inv.net_tokens = 100.0
    inv.avg_entry_price = 0.45
    inv.open_time = time.monotonic() - 1000

    mm._record_fill = AsyncMock()

    await mm._liquidate_aged_positions()

    mm.clob.place_order.assert_not_called(), "PAPER liquidation must not call place_order"
    mm._record_fill.assert_awaited_once()
    assert mm._liquidation_count == 1
