"""
app/core/config.py — Validated configuration for the Professional MM Bot.

All settings are loaded from environment / .env via pydantic-settings.
Cents-based values are kept in ACTUAL CENTS (4.0 = 4¢ = $0.04) to match
the mental model of a market maker.
"""
from __future__ import annotations

from functools import lru_cache
from typing import Literal

from pydantic import Field, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Central configuration. All values validated at startup."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # ── Mode ─────────────────────────────────────────────────────────────
    paper_trading: bool = True
    paper_balance_usdc: float = Field(default=20.0, gt=0)

    # ── Polymarket endpoints ─────────────────────────────────────────────
    clob_base_url: str = "https://clob.polymarket.com"
    gamma_url: str = "https://gamma-api.polymarket.com"
    ws_url: str = "wss://ws-subscriptions-clob.polymarket.com/ws/market"
    chain_id: int = 137

    # ── Auth (LIVE only) ─────────────────────────────────────────────────
    polygon_private_key: str = ""
    polygon_wallet_address: str = ""
    signature_type: int = 0  # 0=EOA, 1=POLY_PROXY, 2=POLY_GNOSIS_SAFE
    funder_address: str = ""
    clob_api_key: str = ""
    clob_api_secret: str = ""
    clob_api_passphrase: str = ""

    # ── Market selection ─────────────────────────────────────────────────
    market_token_ids: str = ""
    auto_pick_markets: bool = True
    auto_pick_min_volume_24h: float = Field(default=10000, ge=0)
    auto_pick_min_spread_cents: float = Field(default=1.5, ge=0)
    auto_pick_count: int = Field(default=5, ge=1, le=20)
    # Dynamic market count: auto-adjust based on bankroll (overrides auto_pick_count)
    # Formula: max(1, floor(bankroll / 10)) — $10 capital per market
    # $20 → 2 markets, $35 → 3, $50 → 5, $100 → 10
    auto_pick_dynamic: bool = True
    auto_pick_keywords: str = (
        "NBA,NFL,MLB,NHL,Soccer,League,Match,Game,beat,win,Cup,Championship,"
        "Tournament,Election,Trump,President,Senate,Governor,Congress,"
        "Parliament,Prime,Minister,Russia,Cabinet,Supreme,Fed,rates,launch,"
        "before,July,August,September,announce,reveal,release,"
        "live,breaking,update,just,confirmed,report,today,tonight,tomorrow,"
        "verdict,ruling,decision,result,score,injury,trade,sign,draft,trade"
    )
    auto_pick_exclude_keywords: str = (
        # v1.0.44: expanded exclude list
        # Crypto (highly speculative, no MM edge)
        "bitcoin,btc,ethereum,eth,solana,sol,crypto,dogecoin,xrp,cardano,polygon,"
        # Esports (extreme volatility, 30-40¢ moves in 60s, near-empty books)
        "counter-strike,csgo,cs:go,cs go,dota,lol,lol_,league of legends,"
        "valorant,rainbow six,rocket league,overwatch,call of duty,cod,"
        "map 1,map 2,map 3,bo1,bo3,bo5,handicap,rounds handicap,"
        # Weather/temperature (resolution-style binary, not MM-able)
        "temperature,weather,forecast,degrees,celsius,"
        # Tiny-price markets (price < 5¢ are resolution-gambling, not MM)
        # (handled at runtime via min_price filter, not keyword)
        # High-frequency tweet/post markets (volatile)
        "tweets,posts,retweets,elon musk,twitter"
    )
    pre_resolution_exit_sec: int = Field(default=900, ge=0)

    # ── Avellaneda-Stoikov ───────────────────────────────────────────────
    as_gamma: float = Field(default=0.3, ge=0, le=5.0)
    as_volatility_window_sec: int = Field(default=120, ge=10)
    as_min_volatility: float = Field(default=0.005, gt=0, lt=0.1)

    # ── Kyle's lambda ────────────────────────────────────────────────────
    kyle_max_spread_mult: float = Field(default=3.0, ge=1.0, le=10.0)
    kyle_depth_levels: int = Field(default=5, ge=1, le=20)

    # ── Spread (all values in CENTS) ─────────────────────────────────────
    spread_cents: float = Field(default=4.0, gt=0)
    spread_min_cents: float = Field(default=1.5, gt=0)
    spread_max_cents: float = Field(default=10.0, gt=0)
    spread_volatility_mult: float = Field(default=2.0, ge=1.0, le=10.0)
    requote_threshold_cents: float = Field(default=1.0, gt=0)
    requote_interval_sec: float = Field(default=1.0, gt=0)

    # ── Order sizing ─────────────────────────────────────────────────────
    order_size_usdc: float = Field(default=5.0, gt=0)
    # v1.0.48 FIX (BUG-14): Polymarket hard minimum is $5 USDC. Was $2,
    # which let hedge/liquidation orders in $2-$4 range pass validation
    # and then get rejected by the Polymarket API. Now $5 to match.
    order_size_min_usdc: float = Field(default=5.0, gt=0)
    order_size_autoscale_max_mult: float = Field(default=1.5, ge=1.0, le=3.0)

    # ── Multi-level quoting ──────────────────────────────────────────────
    multi_level_enabled: bool = True
    multi_level_1_capture: float = Field(default=0.15, ge=0, le=1.0)
    multi_level_1_size_pct: float = Field(default=0.45, ge=0, le=1.0)
    multi_level_2_capture: float = Field(default=0.30, ge=0, le=1.0)
    multi_level_2_size_pct: float = Field(default=0.35, ge=0, le=1.0)
    multi_level_3_capture: float = Field(default=0.45, ge=0, le=1.0)
    multi_level_3_size_pct: float = Field(default=0.20, ge=0, le=1.0)

    # ── Inventory ────────────────────────────────────────────────────────
    max_inventory_usdc: float = Field(default=5.0, gt=0)
    max_inventory_pct_of_bankroll: float = Field(default=0.15, gt=0, le=1.0)
    inventory_skew_threshold: float = Field(default=0.25, ge=0, le=1.0)
    inventory_skew_max_cents: float = Field(default=0.5, ge=0)
    inventory_clear_threshold: float = Field(default=0.8, ge=0, le=1.0)
    # v1.0.38: reduced from 180→120 to clear stuck positions faster
    inventory_aging_threshold_sec: float = Field(default=120, ge=0)
    inventory_aging_discount_step_cents: float = Field(default=0.5, ge=0)
    inventory_aging_max_discount_cents: float = Field(default=2.0, ge=0)

    # ── Active inventory liquidation (v1.0.38) ───────────────────────────
    # Background task that aggressively sells aged positions before they
    # become permanently stuck. Solves the "$89 stuck inventory" problem.
    inventory_liquidation_enabled: bool = True
    inventory_liquidation_check_sec: float = Field(default=10.0, gt=0)
    # Age at which we start selling aggressively (at market bid + offset)
    inventory_liquidation_aggressive_age_sec: float = Field(default=240.0, gt=0)
    # Age at which we sell urgently (at/below market bid, accept any loss)
    inventory_liquidation_urgent_age_sec: float = Field(default=480.0, gt=0)
    # Max loss per token we'll accept during urgent liquidation (cents)
    inventory_liquidation_max_loss_cents: float = Field(default=4.0, ge=0)

    # ── Risk controls / circuit breakers ─────────────────────────────────
    max_daily_loss_usd: float = Field(default=5.0, gt=0)
    stop_trading_consecutive_losses: int = Field(default=5, ge=1)
    cancel_on_major_move_cents: float = Field(default=5.0, gt=0)
    min_balance_usd: float = Field(default=2.0, gt=0)
    stale_data_threshold_sec: float = Field(default=30, gt=0)

    # ── Adverse selection ────────────────────────────────────────────────
    adverse_selection_enabled: bool = True
    adverse_selection_move_cents: float = Field(default=3.0, gt=0)
    adverse_selection_window_sec: float = Field(default=10.0, gt=0)
    adverse_selection_cooldown_sec: float = Field(default=30.0, gt=0)

    # ── Hedging ──────────────────────────────────────────────────────────
    hedging_enabled: bool = True
    hedging_active_enabled: bool = True

    # ── Session-based quoting ────────────────────────────────────────────
    session_quoting_enabled: bool = True
    session_active_start_utc: int = Field(default=14, ge=0, le=23)
    session_active_end_utc: int = Field(default=22, ge=1, le=24)
    session_active_spread_mult: float = Field(default=1.2, ge=0.1, le=5.0)
    session_quiet_spread_mult: float = Field(default=0.9, ge=0.1, le=5.0)

    # ── Gas / fees ──────────────────────────────────────────────────────
    # v1.0.48 FIX (BUG-12): gas cost was hardcoded as $0.005 PAPER / $0.001
    # LIVE — both 10-50x too optimistic. Real Polygon gas for order
    # signing/cancel is $0.01-0.05. Now configurable; defaults are still
    # optimistic but at least match order of magnitude. Users should tune
    # to their actual observed gas costs.
    paper_gas_cost_usdc: float = Field(default=0.01, ge=0, le=1.0)
    live_gas_cost_usdc: float = Field(default=0.02, ge=0, le=1.0)

    # ── PAPER simulation realism (v1.0.50, BUG-2) ──────────────────────
    # v1.0.50 FIX (BUG-2): PAPER was too optimistic (+56%/1.5h). Real LIVE
    # will be -50% to +10% due to higher rejection, competition, latency.
    # Now configurable so users can tune PAPER to match their observed LIVE.
    # Defaults are more realistic (were hardcoded before).
    paper_rejection_rate: float = Field(default=0.20, ge=0, le=1)  # was 0.15
    paper_competition_rate: float = Field(default=0.50, ge=0, le=1)  # was 0.40
    paper_fill_prob_base: float = Field(default=0.018, ge=0, le=1)  # was 0.025
    paper_fill_prob_max: float = Field(default=0.06, ge=0, le=1)  # was 0.08
    paper_adverse_drift_min: float = Field(default=0.008, ge=0, le=0.1)  # was 0.005
    paper_adverse_drift_max: float = Field(default=0.020, ge=0, le=0.1)  # was 0.015
    # Simulated latency in seconds (fills don't happen instantly)
    paper_latency_sec: float = Field(default=0.0, ge=0, le=10)

    # ── Telegram ─────────────────────────────────────────────────────────
    telegram_enabled: bool = False
    telegram_bot_token: str = ""
    telegram_chat_id: str = ""
    telegram_daily_summary_hour_utc: int = Field(default=23, ge=0, le=23)

    # ── Admin / DB / logging ─────────────────────────────────────────────
    admin_host: str = "127.0.0.1"
    admin_port: int = Field(default=8000, ge=1, le=65535)
    # v1.0.52: bot starts PAUSED by default. User must click "Start Trading".
    # Set AUTO_START_TRADING=true to auto-start (useful for headless servers).
    auto_start_trading: bool = False
    # NOTE: named MM_DATABASE_URL to avoid collision with the system-wide
    # DATABASE_URL env var present in some hosting environments.
    mm_database_url: str = Field(
        default="sqlite+aiosqlite:///./mm_bot.db", alias="MM_DATABASE_URL"
    )
    log_level: Literal["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"] = "INFO"
    log_format: Literal["json", "console"] = "json"
    # v1.0.52: optional log file. Empty = stdout only. Set to write logs
    # to a file (in addition to stdout). Useful for overnight sessions.
    log_file: str = ""

    # ─────────────────────────────────────────────────────────────────────
    # Validation
    # ─────────────────────────────────────────────────────────────────────

    @field_validator("polygon_wallet_address", "funder_address")
    @classmethod
    def _normalize_address(cls, v: str) -> str:
        return v.strip().lower() if v else ""

    @field_validator("polygon_private_key")
    @classmethod
    def _normalize_key(cls, v: str) -> str:
        v = v.strip()
        if v and not v.startswith("0x"):
            v = "0x" + v
        return v

    @model_validator(mode="after")
    def _check_live_auth(self) -> Settings:
        """If LIVE mode, require private key + wallet address."""
        if not self.paper_trading:
            missing = []
            if not self.polygon_private_key:
                missing.append("POLYGON_PRIVATE_KEY")
            if not self.polygon_wallet_address:
                missing.append("POLYGON_WALLET_ADDRESS")
            if missing:
                raise ValueError(
                    f"LIVE mode requires: {', '.join(missing)}. "
                    "Set PAPER_TRADING=true or provide credentials."
                )
            if self.signature_type not in (0, 1, 2):
                raise ValueError(
                    f"SIGNATURE_TYPE must be 0 (EOA), 1 (POLY_PROXY), or 2 (POLY_GNOSIS_SAFE); "
                    f"got {self.signature_type}"
                )
        return self

    @model_validator(mode="after")
    def _check_spread_bounds(self) -> Settings:
        if not (self.spread_min_cents <= self.spread_cents <= self.spread_max_cents):
            raise ValueError(
                f"Spread bounds violated: need spread_min_cents ({self.spread_min_cents}) "
                f"<= spread_cents ({self.spread_cents}) <= spread_max_cents ({self.spread_max_cents})"
            )
        return self

    @model_validator(mode="after")
    def _check_multi_level_sizes(self) -> Settings:
        if self.multi_level_enabled:
            total = (
                self.multi_level_1_size_pct
                + self.multi_level_2_size_pct
                + self.multi_level_3_size_pct
            )
            if not 0.99 <= total <= 1.01:
                raise ValueError(
                    f"Multi-level size percentages must sum to 1.0; got {total:.3f}"
                )
        return self

    @model_validator(mode="after")
    def _check_session_bounds(self) -> Settings:
        if self.session_active_start_utc >= self.session_active_end_utc:
            raise ValueError(
                f"SESSION_ACTIVE_START_UTC ({self.session_active_start_utc}) must be < "
                f"SESSION_ACTIVE_END_UTC ({self.session_active_end_utc})"
            )
        return self

    # ── Derived helpers ──────────────────────────────────────────────────

    @property
    def keywords_list(self) -> list[str]:
        return [k.strip().lower() for k in self.auto_pick_keywords.split(",") if k.strip()]

    @property
    def exclude_keywords_list(self) -> list[str]:
        return [
            k.strip().lower()
            for k in self.auto_pick_exclude_keywords.split(",")
            if k.strip()
        ]

    @property
    def explicit_token_ids(self) -> list[str]:
        if not self.market_token_ids.strip():
            return []
        return [s.strip() for s in self.market_token_ids.split(",") if s.strip()]


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Cached settings singleton."""
    return Settings()


# Module-level singleton for convenience imports
settings = get_settings()
