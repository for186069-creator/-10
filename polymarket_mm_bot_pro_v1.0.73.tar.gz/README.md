# Polymarket Professional Market Maker Bot

> **Production-grade MM bot** with Avellaneda-Stoikov reservation pricing,
> Kyle's lambda spread optimization, multi-level quoting, and real EIP-712
> order signing via the official `py-clob-client`.

**Current version: v1.0.73** (see `VERSION` file)

## ⚠️ Risk Disclaimer

**Trading prediction markets involves real financial risk.** This bot can lose money:
- Adverse selection (informed traders pick off your quotes)
- Inventory risk (price moves against your position)
- Technical failures (WS disconnect, latency, API outages)
- Black swan events (sports cancellations, election surprises)

**Start with money you can afford to lose.** Recommended progression:
1. Paper mode — 7+ days, verify bankroll grows
2. $5 live — 1 week, verify real fills work
3. $20 live — 2 weeks, monitor P&L trend
4. $50 live — only after stable +P&L at $20

**No guarantees of profit.** Past performance does not predict future results.

---

## What's New vs v10.13

This is a **complete rewrite** of the v10.13 bot. Critical fixes:

| Issue | v10.13 | Pro v1.0 |
|-------|--------|----------|
| LIVE order signing | Stub `signature: ""` — 100% rejection | **Real EIP-712 via `py-clob-client`** |
| `should_quote_bid/ask` | Dead code (`ratio < 2.0` always True) | **Properly blocks at `inventory_clear_threshold`** |
| `resume()` after stale-data halt | Wiped `daily_pnl` (risk control bypass) | **`preserve_counters=True` option** |
| `httpx` | Missing from requirements (silent Telegram fail) | **Properly declared** |
| `inventory_skew_cents` | Hardcoded 0.1¢, ignored config | **Uses `inventory_skew_max_cents` setting** |
| Logging | stdlib only | **structlog (JSON) + Prometheus metrics** |
| Tests | 0 | **113 unit tests, 100% pass** (v1.0.73) |
| Migrations | `create_all` only | **Alembic** |
| Deployment | Manual | **Dockerfile + docker-compose** |
| Pricing model | Naive symmetric spread | **Avellaneda-Stoikov + Kyle's lambda** |
| Quoting | Single level | **3-level (capture 0.15/0.30/0.45¢)** |

---

## Architecture

```
polymarket_mm_bot_pro/
├── app/
│   ├── main.py                    # FastAPI entry + lifespan + graceful shutdown
│   ├── core/
│   │   ├── config.py              # pydantic-settings, validated (40+ params)
│   │   ├── db.py                  # async SQLAlchemy engine
│   │   ├── logging.py             # structlog (JSON or console)
│   │   └── metrics.py             # Prometheus gauges/counters/histograms
│   ├── db/
│   │   ├── models.py              # Trade, Quote, Snapshot, HaltEvent, MetricPoint
│   │   └── init_db.py             # CREATE TABLE (dev) — prod uses Alembic
│   ├── services/
│   │   ├── clob_client.py         # WRAPPER over py-clob-client + WS feed
│   │   ├── market_maker.py        # Main engine: A-S + Kyle + multi-level
│   │   ├── inventory_manager.py   # Position tracking + risk-aware halts
│   │   ├── analytics.py           # P&L, win rate, Sharpe, drawdown
│   │   ├── alerter.py             # Telegram + in-memory alert log
│   │   ├── pricing/
│   │   │   ├── avellaneda_stoikov.py   # Reservation price + inventory penalty
│   │   │   ├── kyle_lambda.py          # Price impact from book imbalance
│   │   │   └── spread_optimizer.py     # Combine all factors → final spread
│   │   └── risk/
│   │       ├── adverse_selection.py    # Real adverse cost measurement
│   │       ├── circuit_breakers.py     # 6 halt conditions
│   │       └── risk_manager.py         # Orchestrator
│   ├── admin/api.py               # 22 REST endpoints + dashboard
│   └── static/index.html          # Dashboard (vanilla JS, dark theme)
├── alembic/                       # DB migrations
│   └── versions/001_initial.py
├── tests/
│   ├── unit/                      # 65 tests: A-S, Kyle, inventory, risk, config
│   └── integration/
├── scripts/
│   ├── run_paper.sh
│   ├── run_live.sh
│   └── healthcheck.py
├── Dockerfile
├── docker-compose.yml
├── requirements.txt
├── requirements-dev.txt
├── pyproject.toml
└── .env.example
```

---

## Quick Start (PAPER mode)

```bash
# 1. Clone + enter dir
cd polymarket_mm_bot_pro

# 2. Create venv + install
python -m venv .venv
source .venv/bin/activate        # Linux/Mac
# .venv\Scripts\activate         # Windows
pip install -r requirements.txt

# 3. Configure
cp .env.example .env
# .env is pre-set for paper mode ($50 balance)

# 4. Run
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000

# 5. Open dashboard
# http://127.0.0.1:8000
# Click "Start Trading" to begin (bot starts PAUSED for safety)
```

---

## Going LIVE (Real Money)

### Prerequisites

1. **MetaMask wallet** with:
   - USDC on Polygon (start with $5-20)
   - ~$5-10 MATIC for gas (covers ~1 year of trading)
2. **Polymarket account** — sign in at polymarket.com with your wallet
3. **On-chain allowances** — approve USDC + Conditional Tokens for:
   - `0x4bFb41d5B3570DeFd03C39a9A4D8dE6Bd8B8982E` (main exchange)
   - `0xC5d563A36AE78145C45a50134d48A1215220f80a` (neg-risk exchange)
   - `0xd91E80cF2E7be2e162c6513ceD06f1dD0dA35296` (neg-risk adapter)

   Easiest: visit polymarket.com, make one small trade manually — they set allowances for you.

### Configuration

Edit `.env`:
```env
PAPER_TRADING=false
POLYGON_PRIVATE_KEY=0x...your_key...
POLYGON_WALLET_ADDRESS=0x...your_address...
SIGNATURE_TYPE=0                 # 0=EOA (MetaMask), 1=POLY_PROXY, 2=GNOSIS_SAFE
# CLOB_API_KEY/SECRET/PASSPHRASE — leave blank; bot derives them on first run
```

### Pre-flight checklist

1. **Run the checklist endpoint:**
   ```bash
   curl http://127.0.0.1:8000/api/live/checklist
   ```
   All 8 checks must pass.

2. **Or use the dashboard:** Click "📋 Live Check" button.

3. **Reduce order size:** Set `ORDER_SIZE_USDC=2` for first live test.

4. **Start the bot:** Click "▶ Start Trading". Watch the first few fills closely.

5. **Verify real orders:** Check [polymarket.com/activity](https://polymarket.com/activity) — your orders should appear.

### First LIVE session checklist

- [ ] `$5` in wallet, `$2` order size, `MAX_DAILY_LOSS_USD=2`
- [ ] Bot ran 24h in paper mode with positive P&L
- [ ] `/api/live/checklist` returns `ready: true`
- [ ] Dashboard shows `LIVE` badge (red)
- [ ] First fill appears in `/api/trades` with `mode: "LIVE"`
- [ ] Order visible on polymarket.com
- [ ] Cancel works (test with "⏸ Pause")
- [ ] Emergency stop works (test "🛑 EMERGENCY STOP")

---

## Strategy: How It Prices Quotes

### 1. Avellaneda-Stoikov Reservation Price

```
r = mid - q × γ × σ²
```

Where:
- `mid` = current market mid price
- `q` = normalized inventory (-1..+1)
- `γ` = `AS_GAMMA` (risk aversion, default 0.3)
- `σ` = volatility from 120s price history

**Effect:** Long inventory → `r < mid` (encourage selling). Short → `r > mid` (encourage buying).

### 2. Kyle's Lambda Spread Multiplier

```
imbalance = 1 - min(bid_depth, ask_depth) / max(bid_depth, ask_depth)
mult = 1 + imbalance × (KYLE_MAX_SPREAD_MULT - 1)
```

**Effect:** Imbalanced book → wider spread (protects against adverse selection).

### 3. Multi-Level Quoting

3 levels placed simultaneously:
- **Level 1** (closest): 0.15¢ capture, 45% of size — highest fill rate
- **Level 2** (middle): 0.30¢ capture, 35% of size — balanced
- **Level 3** (farthest): 0.45¢ capture, 20% of size — highest profit per fill

### 4. Inventory Skew + Aging

- **Skew:** When inventory > 25% of max, shift quotes 0-0.5¢ opposite (progressive).
- **Aging:** Positions held > 5 min get spread discount (0.5¢/min, max 2¢) to encourage liquidation.

### 5. Risk Controls (Circuit Breakers)

Halt triggers (in priority order):
1. `EMERGENCY_STOP` — manual kill switch
2. `MIN_BALANCE` — bankroll < $2 (LIVE only)
3. `STALE_DATA` — WS silent > 30s
4. `DAILY_LOSS` — daily P&L ≤ -$5
5. `CONSECUTIVE_LOSSES` — 5 losing fills in a row

### 6. Adverse Selection Protection

- Track mid-price moves after each fill
- If mid moves >3¢ in 10s after a fill → 30s cooldown on that token
- If win rate <30% over 20 fills → **permanent block** (informed market)
- Global 5s cooldown after any trigger

### 7. Yes/No Hedging

For each market with both Yes and No tokens (same `condition_id`):
- After buying YES, attempt to buy NO if `YES_ask + NO_ask < $1.00` (risk-free)
- Hedge size capped at filled size (prevents the v10.3 bug)

---

## API Reference

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/health` | Liveness probe |
| GET | `/metrics` | Prometheus metrics |
| GET | `/api/dashboard` | Main metrics + recent trades |
| GET | `/api/inventory` | Per-market positions |
| GET | `/api/quotes` | Active quotes (all levels) |
| GET | `/api/markets` | Tracked markets + books |
| POST | `/api/markets/replace` | Replace all markets |
| POST | `/api/markets/refresh_info` | Refresh market metadata |
| GET | `/api/trades` | Trade history (last N) |
| GET | `/api/config` | Current config |
| POST | `/api/config` | Update config (spread, size, etc.) |
| POST | `/api/config/deposit` | Set paper balance |
| POST | `/api/start` | Start trading |
| POST | `/api/pause` | Pause + cancel all quotes |
| POST | `/api/risk/resume` | Resume from halt |
| POST | `/api/emergency_stop` | Kill switch |
| POST | `/api/mode/toggle` | Switch PAPER ↔ LIVE |
| POST | `/api/paper/reset` | Reset paper state |
| GET | `/api/analytics/by_market` | P&L per market |
| GET | `/api/analytics/time_series` | P&L time series |
| GET | `/api/diagnostics` | 8-point health check |
| GET | `/api/live/checklist` | 8-point LIVE readiness |
| GET | `/api/alerts` | Recent alerts |
| GET | `/api/halt_events` | Halt audit trail |

---

## Deployment

### Option A: Direct (home server / VPS)

```bash
# Install
git clone <repo> polymarket_mm_bot
cd polymarket_mm_bot
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# Configure
cp .env.example .env
nano .env  # set your params

# Run paper
./scripts/run_paper.sh

# Or run live (with confirmation prompt)
./scripts/run_live.sh
```

### Option B: Docker

```bash
cp .env.example .env
# Edit .env

docker compose up -d              # paper mode
docker compose logs -f mm-bot     # tail logs
docker compose down               # stop
```

With Prometheus monitoring:
```bash
docker compose --profile monitoring up -d
# Prometheus at http://127.0.0.1:9090
```

### Option C: systemd (24/7 VPS)

Create `/etc/systemd/system/mm-bot.service`:
```ini
[Unit]
Description=Polymarket MM Bot
After=network.target

[Service]
Type=simple
User=ubuntu
WorkingDirectory=/home/ubuntu/polymarket_mm_bot
EnvironmentFile=/home/ubuntu/polymarket_mm_bot/.env
ExecStart=/home/ubuntu/polymarket_mm_bot/.venv/bin/python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl daemon-reload
sudo systemctl enable mm-bot
sudo systemctl start mm-bot
sudo journalctl -u mm-bot -f   # tail logs
```

---

## Testing

```bash
# Install dev deps
pip install -r requirements-dev.txt

# Run unit tests
pytest tests/unit/ -v

# Run with coverage
pytest tests/unit/ --cov=app --cov-report=html

# Run a specific test
pytest tests/unit/test_avellaneda_stoikov.py -v
```

Current coverage: **65 tests, 100% pass**, covering:
- Avellaneda-Stoikov reservation price (8 tests)
- Kyle's lambda (6 tests)
- Spread optimizer (9 tests)
- Inventory manager (14 tests, including bug-fix verifications)
- Risk manager + circuit breakers (15 tests)
- Config validation (13 tests)

---

## Observability

### Logs (structlog, JSON)

```json
{"timestamp":"2025-01-15T14:23:01Z","level":"info","event":"quote_placed",
 "market":"Will Trump win","level":1,"bid":0.4823,"ask":0.5177,
 "mid":0.5,"reservation":0.4987,"spread_cents":4.0,"mode":"PAPER"}
```

### Prometheus Metrics (`/metrics`)

- `mm_bankroll_usd` — current cash
- `mm_equity_usd` — cash + inventory mark-to-mid
- `mm_daily_pnl_usd` — today's realized P&L
- `mm_active_quotes` — active quote count
- `mm_spread_cents{token_id}` — per-market spread
- `mm_reservation_price{token_id}` — A-S reservation
- `mm_kyle_lambda{token_id}` — Kyle's lambda estimate
- `mm_cycle_latency_seconds` — requote cycle latency histogram
- `mm_fills_total{side,mode}` — fill counter
- `mm_adverse_triggers_total` — adverse selection events
- `mm_circuit_breaker_trips_total{reason}` — halt counter

### Grafana dashboard

Import `prometheus.yml` into Prometheus, then build a Grafana dashboard with:
- Bankroll + equity time series
- Daily P&L bar chart
- Fill rate heatmap
- Adverse selection rate
- WS message age

---

## Troubleshooting

### Bot won't start

- **`LIVE mode requires: POLYGON_PRIVATE_KEY`** — set credentials or keep `PAPER_TRADING=true`
- **`Spread bounds violated`** — ensure `spread_min_cents ≤ spread_cents ≤ spread_max_cents`
- **`Multi-level size percentages must sum to 1.0`** — check `MULTI_LEVEL_*_SIZE_PCT` values

### No fills in paper mode

- Check `/api/diagnostics` — Market Data must show fresh books
- Verify `SPREAD_CENTS` not too wide (4-6¢ is sweet spot)
- Markets might be illiquid — try `POST /api/markets/replace?count=6`

### LIVE orders rejected

- Check `/api/live/checklist` — all 8 must pass
- Verify on-chain allowances (USDC + CTF for 3 exchange contracts)
- Ensure `SIGNATURE_TYPE` matches your wallet type (0 for MetaMask EOA)
- Check `ORDER_SIZE_USDC` — too small (<$2) or too large (>$50) rejected

### Bot halts repeatedly

- Check `/api/halt_events` for the reason
- `STALE_DATA` → internet issue, auto-resumes when WS recovers
- `CONSECUTIVE_LOSSES` → strategy not fitting market conditions, widen spread
- `DAILY_LOSS` → hit risk limit, investigate before resuming

### Telegram alerts not sending

- Verify `TELEGRAM_ENABLED=true`, `TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_ID` set
- Test: `curl "https://api.telegram.org/bot<TOKEN>/sendMessage" -d "chat_id=<CHAT>&text=test"`

---

## Development

### Code style

```bash
# Lint
ruff check app/ tests/

# Format
ruff format app/ tests/

# Type check
mypy app/
```

### Adding a new circuit breaker

1. Add method to `app/services/risk/circuit_breakers.py`
2. Register it in `RiskManager.should_halt()`
3. Add test in `tests/unit/test_risk_manager.py`
4. Document in README

### Running Alembic migrations

```bash
# Generate migration after model changes
alembic revision --autogenerate -m "describe change"

# Apply
alembic upgrade head

# Rollback
alembic downgrade -1
```

---

## License

MIT. See `LICENSE` file (create one if distributing).

## Acknowledgments

- [Polymarket](https://polymarket.com) for the CLOB API and `py-clob-client`
- Avellaneda & Stoikov (2008) for the reservation price model
- Kyle (1985) for the price impact model
