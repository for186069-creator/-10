# CHANGELOG: Polymarket MM Bot Pro v1.0.39

**Дата:** 2026-06-30
**Базова версія:** v1.0.38
**Нова версія:** v1.0.39
**Архів:** `polymarket_mm_bot_pro_v1.0.39.tar.gz` (95 KB, 71 файл)

---

## Що змінилось

v1.0.39 — це **патч-реліз для LIVE-готовності**. Виправлено 5 критичних
багів, які робили LIVE-режим небезпечним (бот розміщував ордери але не
виявляв fills, ліквідував "фантомно", не хеджував у LIVE, не запускав
fill-polling при runtime-toggle).

### P0 — Критичні фікси

| # | Баг | Файл | Фікс |
|---|---|---|---|
| PATCH-1 | LIVE-fills ніколи не виявлялись (`_pending_orders` ніколи не populated) | `app/services/market_maker.py:751-812` | Після кожного успішного `place_order` додається запис у `_pending_orders` з token_id, side, price, size, market_name, level, mid, placed_at |
| PATCH-2 | Фантомні fills у ліквідації (LIVE) | `app/services/market_maker.py:1242-1299` | `_liquidate_aged_positions` викликає `clob.place_order(..., order_type="FAK", post_only=False)`; `_record_fill` лише якщо `result.success` |
| PATCH-3 | Фантомні fills у pre-resolution exit | `app/services/market_maker.py:480-560` | Те саме — реальний `place_order` (FAK) для SELL та BUY (short buyback) |
| PATCH-4 | Hedging не працював у LIVE (гілки `else` не існувало) | `app/services/market_maker.py:1589-1636` | Додано LIVE-гілку: реальний `place_order` на paired token через FAK |
| PATCH-5 | Runtime toggle PAPER→LIVE не запускав poll-loop + live client | `app/services/market_maker.py:181-198` + `app/admin/api.py:467-521` | Новий метод `start_live_polling()` + `toggle_mode` викликає `_clob._init_live_client()` + `start_live_polling()` з rollback при помилці |

### P1 — Якість і безпека

| # | Баг | Файл | Фікс |
|---|---|---|---|
| PATCH-6 | `live_checklist` неточності | `app/admin/api.py:723-915` | `< 2` → `< 5` (Polymarket hard min); один виклик `get_balance_allowance`; +перевірки `py-clob-client`, MATIC, ClobClient init, poll-loop alive |

### P2 — Тести

| # | Що | Файл |
|---|---|---|
| PATCH-7 | 10 нових юніт-тестів на движок (mock ClobService) | `tests/unit/test_market_maker_live.py` (новий) |

Тести покривають:
- PATCH-1: populate `_pending_orders` після LIVE quote; failed order не трекається
- PATCH-2: ліквідація викликає `place_order` з SELL; failed sell не створює фантомний fill
- PATCH-3: pre-resolution викликає реальний `place_order` з SELL
- PATCH-4: hedge викликає реальний `place_order` на paired token
- PATCH-5: `start_live_polling` створює task; idempotent; no-op у PAPER
- Regression: PAPER-ліквідація все ще використовує `_record_fill` напряму

---

## Тестовий запуск (VERIFIED)

```
$ cd polymarket_mm_bot_pro
$ pip install -r requirements.txt
$ pytest tests/unit/

tests/unit/test_avellaneda_stoikov.py ........                           [ 10%]
tests/unit/test_config.py .............                                  [ 27%]
tests/unit/test_inventory_manager.py ..............                      [ 46%]
tests/unit/test_kyle_lambda.py ......                                    [ 53%]
tests/unit/test_market_maker_live.py ..........                          [ 67%]
tests/unit/test_risk_manager.py ...............                          [ 86%]
tests/unit/test_spread_optimizer.py ..........                          [100%]

============================================== 76 passed in 2.20s ==================================
```

- 66 існуючих тестів — pass (регресії немає)
- 10 нових тестів — pass
- Покриття `market_maker.py`: 30% (було ~5% — це лише mock-тести; повне
  покриття вимагає інтеграційних тестів з реальним CLOB)

---

## Що НЕ перевірено (UNVERIFIED — чесно)

1. **py-clob-client 0.34.6 не встановлювався** у тестовому середовищі.
   Реальний signing path (`clob_client.py:728-848`) не покритий runtime-тестом.
2. **Реальний Polymarket CLOB не тестувався** — немає тестового гаманця.
   Зокрема не перевірені:
   - Чи приймає Polymarket FAK-ордер з `post_only=False`
   - Формат відповіді `place_order` (я обробляю `price`, `size_matched`,
     `makingAmount` — але фактичний формат залежить від версії API)
   - Чи `get_order(status)` повертає `"MATCHED"`/`"FILLED"` для FAK
3. **Інтеграційний тест з реальним CLOB** — `tests/integration/` порожній.
4. **Реальна поведінка `derive_api_key`** у `clob_client.py:_init_live_client`.

---

## POSSIBLE FAILURE POINTS (залишкові ризики)

1. **Формат відповіді `place_order`** — actual_price може бути неточним
   (~0.001¢ на ордер), якщо Polymarket повертає інший формат.
2. **FAK + post_only=False** — у py-clob-client 0.34.6 ця комбінація
   може викликати помилку. Якщо так — `place_order` поверне `success=False`,
   ліквідація запишеться як failed (безпечно — ретрай через 10с).
3. **`_init_live_client()` у toggle_mode** — 2-5с (RPC-виклик). За цей час
   бот у `USER_PAUSE`. Якщо RPC лежить — rollback до PAPER.
4. **MATIC-перевірка** використовує публічний RPC `polygon-rpc.com`.
   Rate-limit → warning, не блокує.

---

## REQUIRED TESTS (на стороні користувача, перед реальними грошима)

1. **Smoke test на $5 USDC + 0.1 MATIC**:
   - `cp .env.example .env`, вписати credentials
   - `PAPER_TRADING=false`, `ORDER_SIZE_USDC=5.0`, `AUTO_PICK_COUNT=1`, `MULTI_LEVEL_ENABLED=false`
   - `python -m uvicorn app.main:app --host 127.0.0.1 --port 8000`
   - `curl http://127.0.0.1:8000/api/live/checklist` → `ready: true`
   - `curl -X POST http://127.0.0.1:8000/api/start`
   - Спостерігати 30 хв через `/api/dashboard` + порівнювати з polymarket.com/portfolio
2. **Перевірка fill-detection**: після першого fill — `_pending_orders` має
   спорожніти, `bankroll` має зменшитись на `fill_size + 0.001` (gas).
3. **Перевірка ліквідації**: дочекатись aging (240с) — логи `liquidation_order_placed_live`.
4. **Kill switch**: `/api/emergency_stop` — всі ордери мають скасуватись.

---

## CONFIDENCE

| Аспект | % | Чому |
|---|---|---|
| Код-фікс виконано правильно (статично) | 95% | AST OK, grep підтверджує, тести pass |
| Юніт-тести реально pass | 100% | `76 passed in 2.20s` |
| PAPER-режим не зламав | 100% | 66 існуючих + regression test pass |
| LIVE-режим працюватиме end-to-end | 40% | mock-тести pass, реальний CLOB не тестувався |
| Готовність до заливання $1000+ | 0% | Лише після smoke test на $5 |

---

## Рекомендація

1. Залий код на свою машину.
2. `pip install -r requirements.txt`
3. `pytest tests/unit/` → очікуй `76 passed`
4. Smoke test на **$5 USDC + 0.1 MATIC**, 30 хв спостереження.
5. Якщо OK — scale до $20-50.
6. **Не заливай $1000+ без 24+ годин green LIVE-торгівлі на малій сумі.**

---

## Файли (архів `polymarket_mm_bot_pro_v1.0.39.tar.gz`)

```
bot/
├── app/
│   ├── main.py                          (без змін)
│   ├── core/
│   │   ├── config.py                    (без змін)
│   │   ├── db.py                        (без змін)
│   │   ├── logging.py                   (без змін)
│   │   └── metrics.py                   (без змін)
│   ├── db/
│   │   ├── models.py                    (без змін)
│   │   └── init_db.py                   (без змін)
│   ├── services/
│   │   ├── clob_client.py               (без змін)
│   │   ├── market_maker.py              ← MODIFIED (PATCH-1,2,3,4,5)
│   │   ├── inventory_manager.py         (без змін)
│   │   ├── analytics.py                 (без змін)
│   │   ├── alerter.py                   (без змін)
│   │   ├── pricing/                     (без змін)
│   │   └── risk/                        (без змін)
│   ├── admin/
│   │   └── api.py                       ← MODIFIED (PATCH-5, PATCH-6)
│   └── static/index.html                (без змін)
├── tests/
│   ├── conftest.py                      (без змін)
│   └── unit/
│       ├── test_avellaneda_stoikov.py   (без змін, 8 tests)
│       ├── test_config.py               (без змін, 13 tests)
│       ├── test_inventory_manager.py    (без змін, 14 tests)
│       ├── test_kyle_lambda.py          (без змін, 6 tests)
│       ├── test_risk_manager.py         (без змін, 15 tests)
│       ├── test_spread_optimizer.py     (без змін, 10 tests)
│       └── test_market_maker_live.py    ← NEW (10 tests)
├── alembic/                             (без змін)
├── scripts/                             (без змін)
├── Dockerfile                           (без змін)
├── docker-compose.yml                   (без змін)
├── requirements.txt                     (без змін)
├── requirements-dev.txt                 (без змін)
├── pyproject.toml                       (без змін)
├── .env.example                         (без змін)
├── HANDOFF.md                           (без змін — v1.0.38)
├── README.md                            (без змін)
├── VERSION                              ← MODIFIED (v1.0.39 notes)
└── CHANGELOG_v1.0.39.md                 ← NEW (цей файл)
```

---

**Підсумок:** 5 P0-фіксів + 1 P1-фікс + 10 нових тестів. Код логічно готовий
до LIVE, але **поверифікуй на $5** перед тим, як заливати більше.
