# CHANGELOG: Polymarket MM Bot Pro v1.0.40

**Дата:** 2026-07-01
**Базова версія:** v1.0.39
**Нова версія:** v1.0.40
**Причина:** діагностика `markets_discovery_failed` з пустим error

## Що нового

### PATCH-7: Покращене логування помилок (`clob_client.py`)

**Проблема v1.0.39:**
```
{"error": "", "event": "markets_discovery_failed"}
{"error": "", "event": "ws_disconnect"}
```

`str(e)` для `aiohttp.ClientConnectorError`, `asyncio.TimeoutError`,
`ConnectionResetError` часто повертає порожній рядок. Користувач бачив
"no markets" без жодної підказки чому.

**Фікс:** логуємо `error_type` (ім'я класу) + `error_module` + останні
5 рядків traceback. Тепер лог виглядає:
```
{"error": "", "error_type": "ClientConnectorError",
 "error_module": "aiohttp.client_exceptions",
 "traceback": [...], "event": "markets_discovery_failed"}
```

### PATCH-8: Новий endpoint `GET /api/connectivity` (`admin/api.py`)

Тестує 5 точок:
1. **Gamma REST** — `https://gamma-api.polymarket.com/markets`
2. **CLOB REST** — `https://clob.polymarket.com/markets`
3. **CLOB WS** — HTTP probe до `wss://ws-subscriptions-clob.polymarket.com`
4. **DNS resolution** — `gamma-api.polymarket.com` + `clob.polymarket.com`
5. **Internet control** — `cloudflare.com/cdn-cgi/trace` (показує IP + country)

Для кожної точкі: latency_ms, status_code, actual error message.

## Як використовувати

```bash
curl http://127.0.0.1:8000/api/connectivity
```

### Як читати результат

| Сценарій | Діагноз |
|---|---|
| Всі 5 ✅ | Все працює, бот має знайти ринки |
| Gamma+CLOB ❌, Internet ✅, country=US/UK | **Гео-блок Polymarket** — потрібен VPN |
| DNS ❌ | DNS проблема — спробуй `8.8.8.8` |
| Internet ❌ | Фаєрвол/проксі блокує вихідний трафік |
| WS ❌, решта ✅ | WebSocket порт заблокований фаєрволом |

## Тести

- 10 юніт-тестів test_market_maker_live.py — pass (без регресії)
- Усі v1.0.39 фіксі збережені (PATCH-1..PATCH-6)

## Файли

Змінені:
- `app/services/clob_client.py` (PATCH-7)
- `app/admin/api.py` (PATCH-8)
- `VERSION`

Без змін:
- Усе інше з v1.0.39

## Гео-блок Polymarket (ВАЖЛИВО)

Polymarket блокує доступ з:
- 🇺🇸 США
- 🇬🇧 Велика Британія  
- Країни під санкціями (Куба, Іран, КНДР, Сирія)

Якщо `your_country=US` або `GB` — бот не зможе торгувати навіть з v1.0.40.
Потрібен VPN з виходом через іншу країну.

## Smoke test порядок

1. Завантаж v1.0.40
2. Запусти бота в PAPER
3. `curl http://127.0.0.1:8000/api/connectivity`
4. Якщо `ok: true` — чекай `markets_discovered` в логах
5. Якщо `ok: false` — дивись який endpoint впав, дивись `your_country`
