# CHANGELOG: Polymarket MM Bot Pro v1.0.41

**Дата:** 2026-07-01
**Базова версія:** v1.0.40
**Причина:** UI не давав чітко вказати кількість ринків

## Що нового

### Фікс: Markets count UI

**Проблема v1.0.40:**
- Слайдер "Markets count (target)" існував, але:
  1. Кнопка "Replace Markets" використовувала hardcoded `count=6`
  2. Слайдер лише зберігав config, не замінював ринки
  3. Користувач мусив юзати `curl` для точної кількості

**Фікс v1.0.41:**
- Кнопка "Replace Markets" тепер читає count зі слайдера
- Нова кнопка "Apply" поруч зі слайдером — one-click заміна
- Слайдер показує "N market(s)" замість просто "N"
- Підказка: "Slider sets target, 'Apply' replaces markets. With $10 use 1-2 markets max."
- Toast повідомлення пояснює що робити далі

## Як використовувати

1. В дашборді знайди секцію Configuration
2. Знайди слайдер "Markets count (target)"
3. Перетягни на потрібне число (1-20)
4. Натисни кнопку **"Apply"** поруч зі слайдером
5. Бот:
   - Скине всі поточні quotes
   - Знайде нові ринки (кількість = значення слайдера)
   - Почне котирувати

## Тестування

- Запустив бота в PAPER з $10 стартовим
- POST /api/config {"auto_pick_count": 2} → ✅ ok
- POST /api/markets/replace?count=2 → ✅ new_markets=2
- /api/dashboard → active_markets=2

10 юніт-тестів pass. Регресії немає.

## Файли

Змінені:
- `app/static/index.html` (UI фікс)
- `VERSION`

Без змін:
- Усе інше з v1.0.40

## Рекомендація по кількості ринків

| Bankroll | Рекомендована кількість ринків |
|---|---|
| $5 | 1 |
| $10 | 1-2 |
| $20 | 2-3 |
| $50 | 5 |
| $100+ | 10 |

Формула: `bankroll / 10 = markets_count` (це дефолт AUTO_PICK_DYNAMIC=true).
