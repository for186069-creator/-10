# CHANGELOG: Polymarket MM Bot Pro v1.0.42

**Дата:** 2026-07-01
**Базова версія:** v1.0.41
**Причина:** auto_refill додавав ринки понад target

## Проблема v1.0.41

Користувач встановив `auto_pick_count=1` і натиснув Apply. Бот:
1. Замінив ринки на 1 ✅
2. Через 30 циклів: `quotable_markets=0` (спред < 1.5¢)
3. `auto_refill`: "треба ще" → додав 2-й ринок
4. 2-й теж не quotable → додав 3-й
5. … → 8 ринків, банкрол $10, stall

## Фікс v1.0.42

```python
# Було:
if quotable >= target:
    return
# (далі — додавати нескінченно)

# Стало:
if quotable >= target:
    return
if current >= target * 2:  # HARD CAP
    return  # чекаємо, не додаємо
```

- `target=1` → max 2 ринки (1 quotable + 1 buffer)
- `target=3` → max 6 ринків
- Лог: `auto_refill_skipped_hard_cap` коли досягнуто ліміту

## Тестування

- 10 юніт-тестів pass
- Регресії немає

## Файли

Змінені:
- `app/services/market_maker.py` (фікc auto_refill)
- `VERSION`

Без змін:
- Усе інше з v1.0.41
