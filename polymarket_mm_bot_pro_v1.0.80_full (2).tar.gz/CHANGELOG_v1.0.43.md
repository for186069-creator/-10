# CHANGELOG: Polymarket MM Bot Pro v1.0.43

**Дата:** 2026-07-01
**Базова версія:** v1.0.42
**Причина:** multi-level ask намагався продати більше токенів ніж є

## Проблема v1.0.42

В логу:
```
sell_fill_skipped_no_tokens
  market=Will LeBron James
  net_tokens=23.936
  tokens_to_sell=30.9306  ← 30.93 токенів продати, мав лише 23.94!
```

Бот з 3 рівнями ask:
- Level 1: ~$5 = ~10 токенів
- Level 2: ~$5 = ~10 токенів
- Level 3: ~$5 = ~10 токенів
- Разом: ~30 токенів

Кожен рівень незалежно перевіряв `inv.net_tokens > 0` (true, бо 23.94 > 0),
не враховуючи що інші рівні вже "зарезервували" токени.

В **PAPER** — просто warning (симуляція відхиляє надлишок).
В **LIVE** — Polymarket відхиляє 2-й і 3-й ask, fills не відбуваються,
інвентар не ліквідується.

## Фікс v1.0.43

```python
# Було (баг):
for level in levels:
    if inv.net_tokens <= 0:  # ← перевіряє поточний інвентар, не "залишок"
        ask_price = None
    # ... places ask, не зменшуючи remaining

# Стало:
remaining_tokens = inv.net_tokens  # початковий інвентар
for level in levels:
    tokens_needed = level_size / ask_price
    if remaining_tokens <= 0:
        ask_price = None  # немає токенів
    elif remaining_tokens < tokens_needed:
        # Зменшити розмір до залишку (якщо >= $5)
        reduced = remaining_tokens * ask_price
        if reduced >= $5:
            level_size = reduced
        else:
            ask_price = None  # пропуск (Polymarket min $5)
    if ask_price:
        remaining_tokens -= level_size / ask_price  # декремент
```

## Тестування

- 12 юніт-тестів pass (10 + 2 нових)
- Нові тести:
  - `test_patch8_multilevel_ask_does_not_exceed_tokens` — 10 токенів, перевіряє що sum(sell) ≤ 10
  - `test_patch8_zero_tokens_blocks_all_asks` — 0 токенів, 0 SELL ордерів

## Файли

Змінені:
- `app/services/market_maker.py` (фікc multi-level ask)
- `tests/unit/test_market_maker_live.py` (+2 тести)
- `VERSION`

Без змін:
- Усе інше з v1.0.42
