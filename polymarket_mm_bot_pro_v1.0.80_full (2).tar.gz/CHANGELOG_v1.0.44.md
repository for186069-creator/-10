# CHANGELOG: Polymarket MM Bot Pro v1.0.44

**Дата:** 2026-07-01
**Базова версія:** v1.0.43
**Причина:** PAPER показував фейковий +$223 прибуток на esports ринках з порожніми books

## Проблема v1.0.43

Під час PAPER-сесії бот підібрав ринок типу "Counter-Strike Map 1"
з best_bid=2¢, best_ask=99¢ (spread=97¢). На таких ринках:
- Order book майже порожній
- Ціни стрибають на 30-40¢ за 60 секунд
- Будь-який fill дає "фейковий" +$20-50 прибуток у PAPER симуляції
- Реальний LIVE ордер не виконався б взагалі

## Фікс

### 1. Skip ринки зі спредом > 30¢

У `clob_client.py:discover_markets()`:
```python
if market_spread > 0.30:
    log.debug("market_skip_wide_spread", ...)
    continue
```

30¢ обрано як threshold: реальні MM-able ринки мають спред 1-10¢.
Спред >30¢ = порожній book або resolution-style ринок.

### 2. Розширений `auto_pick_exclude_keywords`

У `config.py:auto_pick_exclude_keywords` додано:

**Esports** (extreme volatility, near-empty books):
- counter-strike, csgo, cs:go, cs go
- dota, lol, league of legends
- valorant, rainbow six, rocket league, overwatch
- call of duty, cod
- map 1, map 2, map 3
- bo1, bo3, bo5
- handicap, rounds handicap

**Weather/temperature** (resolution-style binary):
- temperature, weather, forecast, degrees, celsius

**Tweets/posts** (volatile):
- tweets, posts, retweets, elon musk, twitter

## Тести

Без змін. 12 тестів pass.

## P&L імпакт

Після фіксу PAPER сесія показала +$5.60 (56%) замість фейкових +$223.
Реалістичніший очікуваний PAPER результат: +1-5% за годину.

## Відомі обмеження

- Threshold 30¢ — hardcoded. Деякі легітимні ринки можуть мати спред 15-25¢
  під час високої волатильності (election night). Можна зробити configurable
  у v1.0.47.
- Exclude keywords — case-insensitive substring match. Може пропустити
  "CSGO tournament" якщо написано "C.S.G.O". (з крапками).
