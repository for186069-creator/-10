# CHANGELOG: Polymarket MM Bot Pro v1.0.45

**Дата:** 2026-07-01
**Базова версія:** v1.0.44
**Причина:** UI не показував orphaned позиції

## Проблема v1.0.44

Бот торгував 4 ринками (Samuel Alito, Mbappé, LeBron, NVIDIA).
Після replace markets на 1 ринок (Samuel Alito):
- API: показував всі 4 позиції ✅
- Dashboard `INVENTORY`: $6.21 ✅
- Inventory таблиця: тільки 1 рядок (Samuel Alito) ❌

Orphaned позиції на Mbappé/LeBron/NVIDIA були невидимі в UI.

## Фікс v1.0.45

Inventory таблиця тепер:
1. Завантажує `/api/inventory` (всі позиції)
2. Завантажує `/api/markets` (активні ринки)
3. Порівнює — якщо token_id не в активних → позначка `⚠ orphan`
4. Сортує: non-zero tokens зверху, потім по USD desc
5. Closed позиції (net_tokens=0) — напівпрозорі + тег `closed`
6. Footer: Total N positions (M orphaned), Realized P&L

## Тестування

- 12 юніт-тестів pass
- HTML валідний (64 div open / 64 close)
- UI-only зміна, не впливає на бекенд

## Файли

Змінені:
- `app/static/index.html` (loadInventory function)
- `VERSION`

Без змін:
- Усе інше з v1.0.44
