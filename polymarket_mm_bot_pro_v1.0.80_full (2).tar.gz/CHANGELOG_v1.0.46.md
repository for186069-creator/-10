# CHANGELOG v1.0.46 — 9 баг-фіксів

**Дата:** 2026-07-01
**Попередник:** v1.0.45
**Аудит:** AUDIT_v1.0.45.md (виявив 9 критичних/мажорних багів + 22 minor)

---

## Що нового

Ця версія — результат повного аудиту коду v1.0.45. Аудит виявив 9 багів
рівнів CRITICAL/HIGH/MEDIUM. Усі 9 виправлено. Minor баги (BUG-10..31)
залишено для наступних версій.

## Виправлені баги

### CRITICAL (4)

#### BUG-1: auto_refill hard cap = target × 2 → target
**Файл:** `app/services/market_maker.py` (`_maybe_auto_refill`, новий `_replace_non_quotable_markets`)

**Симптом:** Користувач ставить target=1, бот тримав 2 ринки.
**Причина:** v1.0.42 hard cap був `target × 2` — при target=1 дозволяв 2.
**Фікс:** cap = target. Якщо єдиний ринок non-quotable, бот його REPLACES
(новий метод `_replace_non_quotable_markets`), а не додає другий.
**Обережність:** ринки з відкритою позицією (|net_tokens| > 0.5) не замінюються,
щоб не orphaning inventory. Liquidation loop їх очистить через aging.

#### BUG-4: hedge SELL створював нетрековані позиції на блокчейні
**Файл:** `app/services/market_maker.py` (`_attempt_active_hedge`)

**Симптом:** LIVE hedge SELL ордер відправлявся на Polymarket, міг
виконатися, але `_record_fill` мовчки skipав запис через нестачу
токенів → позиція на блокчейні не відображалась в інвентарі.
**Причина:** Перевірка `inv.net_tokens < tokens_to_sell` жила в
`_record_fill` (після `place_order`), а не ДО нього.
**Фікс:** Pre-flight перевірка ДО `place_order`. Додатковий CRITICAL log
`hedge_filled_but_untrackable_live` якщо race condition все ж виникає
(інший concurrent fill змінив inventory між перевіркою і виконанням).

#### BUG-5: _poll_orders фіксив повний fill при missing size_matched
**Файл:** `app/services/market_maker.py` (`_poll_orders`)

**Симптом:** При `status=FILLED_PARTIAL` без `size_matched` бот записував
фантомний fill на повний розмір ордера.
**Причина:** `final.get("size_matched", info["size_usdc"])` — default
був повний розмір замість 0.
**Фікс:** Default = 0. Спроба `makingAmount` (tokens → USDC через price)
як fallback. Warning log при missing size.

#### BUG-6: _poll_orders не записував partial fills на CANCELLED
**Файл:** `app/services/market_maker.py` (`_poll_orders`)

**Симптом:** CANCELLED ордер з `size_matched > 0` мовчно skipався —
часткова fill втрачалась.
**Причина:** Перевірка `if status in ("MATCHED", "FILLED", "FILLED_PARTIAL")`
не включала CANCELLED.
**Фікс:** Записує ANY partial fill незалежно від status (мінімум $0.01
для фільтра dust). Timeout (30с) тепер не pop відразу — дає ще один
cycle для get_order() з фінальним status.

### HIGH (3)

#### BUG-7: _maybe_auto_refill не відновлював auto_pick_count при exception
**Файл:** `app/services/market_maker.py` (`_maybe_auto_refill`)

**Симптом:** `discover_markets()` raise → `settings.auto_pick_count`
застрягав на `max(1, target - quotable)` назавжди.
**Фікс:** `try/finally` з гарантованим restore.

#### BUG-8: discover_markets fallback не мав wide-spread filter (>30¢)
**Файл:** `app/services/clob_client.py` (`discover_markets`)

**Симптом:** При fallback (relaxed spread 0.8¢) бот міг вибрати ринок
зі спредом 97¢. `spread_bonus = 1 + market_spread * 50` робив їх
top-scored.
**Фікс:** Той самий `if market_spread > 0.30: continue` що й в основному
шляху.

#### BUG-9: toggle_mode обходив risk halts
**Файл:** `app/admin/api.py` (`toggle_mode`)

**Симптом:** Користувач міг toggle mode → halt став USER_PAUSE →
`resume(preserve_counters=True)` → halt cleared, навіть якщо
DAILY_LOSS ще активний.
**Фікс:**
1. Refuse toggle якщо halt reason не в `{USER_PAUSE, ""}`.
2. Без auto-resume після toggle — користувач має явно Resume.
3. Повертає `trading_paused: true` щоб UI показував paused state.

### MEDIUM (2)

#### BUG-15: set_deposit не скидав daily_pnl
**Файл:** `app/admin/api.py` (`set_deposit`)

**Симптом:** Після зміни банкролу ($10 → $50) daily_pnl відображав
стару сесію.
**Фікс:** Reset `daily_pnl = 0.0` + `consecutive_losses = 0`.

#### BUG-22: _select_markets безповоротно перезаписував auto_pick_count
**Файл:** `app/main.py` (`_select_markets`)

**Симптом:** Після старту `auto_pick_count = dynamic` значення назавжди.
Якщо користувач вимкне `auto_pick_dynamic`, значення все ще dynamic.
**Фікс:** `try/finally` з restore. Dynamic count обчислюється локально
і передається як temporary override.

---

## Нові тести (6 шт)

У `tests/unit/test_market_maker_live.py`:
- `test_bug1_auto_refill_cap_is_target_not_double`
- `test_bug4_hedge_sell_skipped_when_no_tokens_preflight`
- `test_bug5_poll_orders_no_phantom_fill_when_size_missing`
- `test_bug6_poll_orders_records_partial_on_cancelled`
- `test_bug7_auto_refill_restores_count_on_exception`
- `test_bug9_toggle_mode_blocked_by_risk_halt`

Разом: 18 тестів (12 старих + 6 нових).
Усі UNVERIFIED — не запускались у sandbox (немає Python deps).

---

## Відомі баги, що залишились

Не виправлені в v1.0.46 (для наступних версій):

| # | Баг | Файл | Приорітет |
|---|---|---|---|
| BUG-2 | PAPER симуляція оптимістична | by design | — |
| BUG-3 | Orphaned позиції не ліквідуються швидко | частково вирішено BUG-1 | LOW |
| BUG-10 | _check_fills_paper `continue` пропускає ask | market_maker.py | MEDIUM |
| BUG-11 | _liquidate_aged_positions не обробляє short | market_maker.py | MEDIUM |
| BUG-12 | LIVE gas cost $0.001 — 10-50x занадто низький | market_maker.py | MEDIUM |
| BUG-13 | _apply_book не очищає stale bids/asks | clob_client.py | MEDIUM |
| BUG-14 | order_size_min_usdc $2 vs Polymarket $5 | config.py | MEDIUM |
| BUG-16 | dashboard завантажує ВСІ trades з БД | admin/api.py | LOW |
| BUG-17 | subscribe() реконектить весь WS | clob_client.py | LOW |
| BUG-18 | place_order retry decorator — мертвий код | clob_client.py | LOW |
| BUG-19 | _fetch_book мовчно ковтає exceptions | clob_client.py | LOW |
| BUG-20 | emergency_stop рахує ринки, не ордери | admin/api.py | LOW |
| BUG-21 | stop() мовчно ковтає exceptions тасок | market_maker.py | LOW |
| BUG-23..31 | minor/косметичні | різні | LOW |

---

## Оновлення конфігурації

Без змін. Існуючий `.env` від v1.0.45 сумісний з v1.0.46.

---

## Рекомендація по тестуванню

1. **PAPER сесія 1 год:** запустити v1.0.46 у PAPER, порівняти metrics
   з v1.0.45. Очікувано: ті ж +56% (фікси не змінюють PAPER поведінку,
   крім BUG-1 — тепер max 1 ринок при target=1).
2. **Юніт-тести:** `python -m pytest tests/unit/test_market_maker_live.py -v`
   (потрібні Python deps: fastapi, sqlalchemy, py-clob-client).
3. **LIVE smoke test:** $5 USDC + 0.1 MATIC, 30 хв. Перевірити:
   - `poll_orders_fill_detected` логи з реальними fills
   - Відсутність `hedge_filled_but_untrackable_live` CRITICAL логів
   - Відсутність `poll_orders_size_matched_missing` warning (якщо
     Polymarket повертає size_matched — фікс не тригериться)
4. **Toggle mode test:** запустити PAPER, дочекатись DAILY_LOSS halt,
   спробувати toggle mode — має відмовити з повідомленням.
