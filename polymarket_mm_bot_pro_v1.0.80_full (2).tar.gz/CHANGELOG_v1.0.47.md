# CHANGELOG v1.0.47 — статус-стрінг фікси

**Дата:** 2026-07-01
**Попередник:** v1.0.46
**Причина:** дослідження користувача підтвердило фактичну поведінку Polymarket API

---

## Контекст

Після v1.0.46 користувач надав дослідження (з gpt 5.5) про точну поведінку
Polymarket API для `size_matched` та `CANCELLED` зі partial fill. Це
дослідження виявило 3 невідповідності у моїх v1.0.46 фіксах:

1. Статус `FILLED_PARTIAL` — неіснуючий; Polymarket використовує `PARTIALLY_FILLED`
2. BUG-4 коментар "API would reject" — неправда; Polymarket підтримує шорти
3. `place_order` success check не включав `PARTIALLY_FILLED`

## Виправлення

### FIX-1 (CRITICAL): FILLED_PARTIAL → PARTIALLY_FILLED

**Файли:**
- `app/services/market_maker.py` (3 місця: рядки ~1418, ~1470, ~1432 коментар)
- `app/services/clob_client.py` (1 місце: рядок ~860)

**Симптом:** Код перевіряв `status in ("MATCHED", "FILLED", "FILLED_PARTIAL")`,
але Polymarket API повертає `PARTIALLY_FILLED` (не `FILLED_PARTIAL`).

**Наслідки у v1.0.46:**
- Warning лог `poll_orders_size_matched_missing` не виводився для `PARTIALLY_FILLED` + size_matched=0
- Warning лог `poll_orders_fill_zero_size` не виводився для `PARTIALLY_FILLED` + size_matched=0
- `place_order` success check не розпізнавав `PARTIALLY_FILLED` (рятував `or bool(order_id)`)

**Фікс:** Замінено всі `FILLED_PARTIAL` на `PARTIALLY_FILLED`. `MATCHED` залишено
для зворотної сумісності (може бути застарілий статус).

**Важливо:** Основна функціональність BUG-5/6 фіксів працювала правильно у v1.0.46,
бо:
- BUG-6 записує ANY fill з `size_matched > 0` незалежно від status
- BUG-5 використовує default=0 для missing `size_matched`, не залежить від status
- `place_order` має `or bool(order_id)` fallback

### FIX-2 (MEDIUM): BUG-4 коментарі оновлені

**Файл:** `app/services/market_maker.py` (`_attempt_active_hedge`)

**Було (v1.0.46):** Коментар "Polymarket API would reject" — **неправда**.
Polymarket підтримує шорти: SELL без токенів створює short з $1 collateral.

**Стало (v1.0.47):** Коментар "would open uncontrolled short position".
Бот блокує hedge SELL без токенів політикою (не API), бо:
- Short paired token = економічно еквівалентно long на original token
- Це НЕ хедж — це подвоєння ризику
- Бот не повинен автоматично відкривати shorts через "hedge" логіку

**Повідомлення лога змінено:**
- Було: "would send LIVE SELL with no tokens — Polymarket API would reject"
- Стало: "would open uncontrolled short (Polymarket supports it with $1 collateral, but bot policy blocks shorts via hedge)"

**Поведінка коду БЕЗ ЗМІН** — блокування правильне у v1.0.46 і v1.0.47.

### FIX-3 (LOW): place_order success check

**Файл:** `app/services/clob_client.py:860`

**Було:**
```python
success = status in ("LIVE", "MATCHED", "FILLED", "FILLED_PARTIAL") or bool(order_id)
```

**Стало:**
```python
success = status in ("LIVE", "MATCHED", "FILLED", "PARTIALLY_FILLED") or bool(order_id)
```

Додано `PARTIALLY_FILLED` для коректного розпізнавання FAK ордерів з частковим fill.

---

## Підтверджено з Polymarket API (з користувацького дослідження)

### Статуси ордерів
| Статус | Опис |
|---|---|
| `LIVE` | Ордер на книзі, активний |
| `PARTIALLY_FILLED` | Часткове виконання, ордер ще активний |
| `FILLED` | Повне виконання |
| `CANCELLED` | Скасований (невиконана частина видалена) |

### `size_matched` поведінка
- **Повне виконання:** `size_matched = original_size`, status = `FILLED`
- **Часткове:** `0 < size_matched < original_size`, status = `PARTIALLY_FILLED`
- **Скасування після partial:** `size_matched` зберігається (не зростає далі), status = `CANCELLED`

### WebSocket події
- `type: "UPDATE"` — при частковому виконанні
- `type: "CANCELLATION"` — при скасуванні

### Шорти
Polymarket **підтримує** шорти: SELL YES без токенів створює short з $1 collateral
per contract. Технічно — постачання colateral (pUSD) + створення еквівалентної
довгої позиції NO.

---

## Залишається UNVERIFIED

1. **Поле `remaining`** — може не бути в API офіційно (обчислюється як
   `original_size - size_matched`)
2. **Чи py-clob-client автоматично блокує collateral** для shorts, чи потрібен
   окремий approve
3. **Точний формат WS повідомлень** — чи `type` поле містить `UPDATE`/`CANCELLATION`

---

## Нові тести (3 шт)

У `tests/unit/test_market_maker_live.py`:
- `test_v1047_partially_filled_with_size_records_correctly` — `PARTIALLY_FILLED` + `size_matched=4.00` → записує $4.00
- `test_v1047_filled_status_records_full_size` — `FILLED` + `size_matched=5.00` → записує $5.00
- `test_v1047_hedge_sell_blocked_reason_is_short_not_api_reject` — перевіряє що warning лог містить "short"

Разом: **21 тест** (18 з v1.0.46 + 3 нових). Усі UNVERIFIED.

---

## Рекомендація по тестуванню

1. **Запустити юніт-тести:** `python -m pytest tests/unit/test_market_maker_live.py -v`
2. **LIVE smoke test:** перевірити логи:
   - `poll_orders_fill_detected` з реальними `PARTIALLY_FILLED` статусами
   - Відсутність `poll_orders_size_matched_missing` (якщо API повертає size_matched)
   - `hedge_skipped_insufficient_tokens_preflight` з "short" у reason
3. **Опціонально:** додати WS-based fill detection (bigger change, v1.0.48)

---

## Немао змін

- Конфігурація `.env` — без змін, сумісна з v1.0.46
- Архітектура — без змін
- Endpoints — без змін
- Усі 9 фіксів з v1.0.46 залишаються (ніхто не видалений)
