# CHANGELOG v1.0.48 — 4 MEDIUM баг-фікси

**Дата:** 2026-07-01
**Попередник:** v1.0.47
**Причина:** фікси MEDIUM багів з аудиту v1.0.45

---

## Що нового

Виправлено 4 MEDIUM баги, що залишились з аудиту v1.0.45. Усі 4 впливають
на точність симуляції (PAPER) або фінансову коректність (LIVE).

## Виправлені баги

### BUG-14 (MEDIUM): order_size_min_usdc $2 → $5

**Файл:** `app/core/config.py:100-103`

**Симптом:** `order_size_min_usdc` = $2, але Polymarket hard minimum = $5.
Прямі виклики `place_order` (hedge, liquidation, pre-resolution) з розміром
$2-$4 проходили validation у `clob_client.py:773`, але Polymarket API їх
відкидав.

**Фікс:** default = $5.0. Тепер відповідає `POLYMARKET_MIN_ORDER_USDC`
хардкоду в `_place_multi_level_quotes` (рядок 638).

**Вплив:** hedge/liquidation ордери $2-$4 більше не проходять validation
→ не відправляються → не отримують reject від API.

### BUG-12 (MEDIUM): gas cost configurable + реалістичний

**Файли:** `app/core/config.py:162-169` (нові settings), `app/services/market_maker.py:1734-1737`

**Симптом:** `gas_cost` був hardcoded:
```python
gas_cost = 0.005 if settings.paper_trading else 0.001
```
- PAPER $0.005 — 2x занадто оптимістичний (реальний $0.01)
- LIVE $0.001 — 20-50x занадто оптимістичний (реальний $0.02-0.05)

**Фікс:** Нові settings:
```python
paper_gas_cost_usdc: float = Field(default=0.01, ge=0, le=1.0)
live_gas_cost_usdc: float = Field(default=0.02, ge=0, le=1.0)
```

Код:
```python
gas_cost = settings.paper_gas_cost_usdc if settings.paper_trading else settings.live_gas_cost_usdc
```

**Вплив:**
- PAPER симуляція точніша (менше фейкового прибутку)
- LIVE метрика P&L точніша
- Користувач може перевантажити через `.env`: `PAPER_GAS_COST_USDC=0.03`

### BUG-10 (MEDIUM): _check_fills_paper `continue` пропускає ask перевірку

**Файл:** `app/services/market_maker.py:1180-1309`

**Симптом:** У блоці bid fill simulation було 5 `continue`:
- 15% rejection → `continue` (пропускає ask блок)
- 40% competition → `continue` (пропускає ask блок)
- 20% partial-none → `continue` (пропускає ask блок)
- fill_size < $1.0 → `continue` (пропускає ask блок)
- insufficient balance → `continue` (пропускає ask блок)

При ~60% ймовірності будь-якого skip, ask перевірка пропускалась для
більшості quote-ів кожен цикл. Це занижувало fill rate у PAPER.

**Фікс:** Заміна всіх `continue` на `pass` + рефакторинг `if/elif/else`
для збереження логіки. Тепер bid skip не блокує ask перевірку.

**Вплив:** PAPER fill rate зросте (більш реалістичний). Round-trip
detection частіше спрацьовуватиме.

### BUG-13 (MEDIUM): _apply_book не очищав stale bids/asks

**Файли:** `app/services/clob_client.py:752-763` (`_apply_book`), `292-299` (`_apply_snapshot`)

**Симптом:** Код:
```python
if bids:
    book.bids = bids
if asks:
    book.asks = asks
```
Коли REST/WS повертав порожній book (ринок втратив ліквідність), старі
bids/asks **не очищувались**. Бот продовжував котувати на основі
застарілих даних, бачив "спред" якого не існує.

**Фікс:**
```python
book.bids = bids  # завжди замінювати
book.asks = asks  # навіть якщо порожні
```

**Вплив:** Коли ринок втрачає ліквідність, бот тепер бачить порожній
book і skip ринок (через перевірку `if not book.bids or not book.asks`
в `_process_market`). Раніше міг котувати на stale data.

---

## Нові тести (6 шт)

У `tests/unit/test_market_maker_live.py`:
- `test_bug14_order_size_min_is_5_usdc` — перевіряє default = $5
- `test_bug12_gas_cost_settings_exist` — перевіряє що settings існують
- `test_bug12_gas_cost_deducted_from_bankroll` — перевіряє що gas віднімається
- `test_bug10_bid_rejection_still_checks_ask` — перевіряє що bid skip не блокує ask
- `test_bug13_apply_book_clears_stale_bids` — перевіряє clearing (REST path)
- `test_bug13_apply_snapshot_clears_stale_bids` — перевіряє clearing (WS path)

Разом: **27 тестів** (21 з v1.0.47 + 6 нових). Усі UNVERIFIED.

---

## Немао змін

- Конфігурація `.env` — без змін (нові settings мають defaults)
- Архітектура — без змін
- Endpoints — без змін
- Усі 12 фіксів з v1.0.46/47 залишаються

---

## Оновлення .env (опціонально)

Додано нові settings (з defaults, можна не вказувати):
```env
# Gas costs (v1.0.48) — defaults are realistic but conservative
PAPER_GAS_COST_USDC=0.01
LIVE_GAS_COST_USDC=0.02
```

Якщо хочете більш реалістичні значення (з handoff BUG-2):
```env
PAPER_GAS_COST_USDC=0.03
LIVE_GAS_COST_USDC=0.05
```

---

## Залишається багів

| # | Баг | Рівень | Статус |
|---|---|---|---|
| BUG-2 | PAPER симуляція оптимістична | by design | — |
| BUG-3 | Orphaned позиції (частково вирішено) | LOW | частково |
| BUG-11 | _liquidate_aged_positions не обробляє short | LOW | (бот не відкриває shorts) |
| BUG-16 | dashboard завантажує ВСІ trades | LOW | TODO |
| BUG-17 | subscribe() реконектить весь WS | LOW | TODO |
| BUG-18 | place_order retry decorator — мертвий код | LOW | TODO |
| BUG-19 | _fetch_book мовчно ковтає exceptions | LOW | TODO |
| BUG-20 | emergency_stop рахує ринки, не ордери | LOW | TODO |
| BUG-21 | stop() мовчно ковтає exceptions | LOW | TODO |
| BUG-23-31 | Косметичні (9 шт) | cosmetic | TODO |

**Критичних багів: 0**
**HIGH багів: 0**
**MEDIUM багів: 0** (усі 4 виправлено у v1.0.48)
