# CHANGELOG v1.0.49 — 6 LOW баг-фікси

**Дата:** 2026-07-01
**Попередник:** v1.0.48
**Причина:** фікси всіх LOW багів з аудиту v1.0.45

---

## Що нового

Виправлено всі 6 LOW багів. Після v1.0.49 залишились тільки 5 cosmetic
багів + 1 by design + 1 частково вирішений. **Усі CRITICAL, HIGH, MEDIUM
та LOW баги виправлено.**

## Виправлені баги

### BUG-16 (LOW): dashboard/by_market завантажували ВСІ trades з БД

**Файли:** `app/services/analytics.py`, `app/admin/api.py`

**Симптом:**
```python
# dashboard — завантажує ВСІ trades
all_result = await db.execute(select(Trade))
all_trades = list(all_result.scalars().all())  # тисячі записів!

# by_market — завантажує ВСІ trades
result = await db.execute(select(Trade))
trades = list(result.scalars().all())
```
При тижнях роботи — тисячі Trade ORM об'єктів у пам'яті при кожному
запиті до дашборду.

**Фікс:**
1. `Analytics.compute_summary()` — додано optional override параметри:
   `total_count_override`, `total_pnl_override`, `trades_24h_override`,
   `pnl_24h_override`. Коли надані — використовуються замість обчислення
   з trades list.
2. `Analytics.by_market_from_rows()` — новий метод, приймає SQL GROUP BY
   rows замість Trade ORM об'єктів.
3. `dashboard()` endpoint — SQL `COUNT(*)` + `SUM(pnl_usdc)` для totals
   (fast), завантажує тільки 500 trades для round-trip analysis.
4. `by_market()` endpoint — SQL `GROUP BY market_id` з `CASE` для
   buys/sells count.

**Вплив:** dashboard за O(1) замість O(N). by_market за O(markets)
замість O(trades).

### BUG-17 (LOW): subscribe() реконектив весь WS

**Файл:** `app/services/clob_client.py` (`MarketDataFeed`)

**Симптом:**
```python
async def subscribe(self, token_id):
    self._subscribed.add(token_id)
    await self.stop()   # ← розрив WS для ВСІХ ринків
    await self.start(list(self._subscribed))  # ← перепідключення
```
`_maybe_auto_refill` викликає `subscribe` для кожного нового ринку →
кожен виклик розриває WS для всіх існуючих ринків → data gap.

**Фікс:**
1. Додано `self._ws` reference на активне з'єднання.
2. `subscribe()` відправляє subscribe message на існуючому WS:
   ```python
   await self._ws.send(json.dumps({"type": "Market", "assets_ids": [token_id]}))
   ```
3. Якщо WS down — просто додає до `_subscribed`, наступний connect
   підхопить.
4. `_ws_connect` зберігає/очищає `self._ws` через `try/finally`.

**Вплив:** додавання нового ринку не розриває WS для існуючих. Немає
data gap при auto_refill.

### BUG-18 (LOW): place_order @retry — мертвий код

**Файл:** `app/services/clob_client.py`

**Симптом:**
```python
@retry(retry=retry_if_exception_type(Exception), stop=stop_after_attempt(3))
async def place_order(...):
    ...
    try:
        ...
    except PolyApiException:
        return OrderResult(success=False, ...)
    except Exception:
        return OrderResult(success=False, ...)
```
Усі exceptions catch всередині → retry ніколи не спрацьовує.

**Фікс:** Прибрано `@retry` decorator + видалено `tenacity` import.
Додано коментар з поясненням: якщо потрібен retry-on-network-error,
треба звузити `except Exception` щоб `ConnectionError`/`TimeoutError`
пропагували.

### BUG-19 (LOW): _fetch_book мовчно ковтав exceptions

**Файл:** `app/services/clob_client.py`

**Симптом:**
```python
except Exception:
    pass  # ← неможливо діагностувати помилки
```

**Фікс:**
```python
except Exception as e:
    log.debug("fetch_book_error", token=tid[:12],
              error=str(e), error_type=type(e).__name__)
```
Додано також `log.debug("fetch_book_non_200", ...)` для non-200 responses.

### BUG-20 (LOW): emergency_stop рахував ринки, не ордери

**Файл:** `app/admin/api.py`

**Симптом:**
```python
canceled = 0
for tid in list(_mm.active_quotes.keys()):
    await _mm._cancel_all_levels(tid)
    canceled += 1  # ← рахує РИНКИ, не ордери!
return {"orders_canceled": canceled}  # ← вводить в оману
```
Кожен ринок може мати до 6 ордерів (3 рівні × 2 сторони).

**Фікс:** Рахуємо фактичні `bid_order_id` + `ask_order_id`:
```python
for q in quotes:
    if q.bid_order_id: level_orders += 1
    if q.ask_order_id: level_orders += 1
orders_canceled += level_orders
```
Додано `markets_affected` для сумісності.

### BUG-21 (LOW): stop() мовчно ковтав exceptions тасок

**Файл:** `app/services/market_maker.py`

**Симптом:**
```python
except (asyncio.CancelledError, Exception):
    pass  # ← всі помилки тасок мовчно зникають
```

**Фікс:** Розділено CancelledError (expected) від інших (logged):
```python
except asyncio.CancelledError:
    pass  # expected during shutdown
except Exception as e:
    log.warning("task_stopped_with_error", task=task_name,
                error=str(e), error_type=type(e).__name__)
```
Додано `task_names` dict для людяних логів.

---

## Нові тести (8 шт)

- `test_bug16_compute_summary_with_overrides` — override параметри
- `test_bug16_by_market_from_rows` — SQL rows → response
- `test_bug17_subscribe_no_reconnect_when_ws_active` — WS send без reconnect
- `test_bug17_subscribe_idempotent_for_existing_token` — no-op для існуючого
- `test_bug18_place_order_has_no_retry_decorator` — перевірка відсутності
- `test_bug19_fetch_book_logs_errors` — логування помилок
- `test_bug20_emergency_stop_counts_orders` — 8 ордерів, не 2 ринки
- `test_bug21_stop_logs_task_errors` — логування exceptions

Разом: **35 тестів** (27 + 8). Усі UNVERIFIED.

---

## Стан багів після v1.0.49

```
Всього виявлено:  31 баг
├─ Виправлено:    22  (71%)
├─ By design:      1  (BUG-2)
├─ Частково:       1  (BUG-3)
└─ Cosmetic:       7  (BUG-23-31, скорочено з 9)

КРИТИЧНИХ залишилось:  0  ✅
HIGH залишилось:       0  ✅
MEDIUM залишилось:     0  ✅
LOW залишилось:        0  ✅ ← ВСІ ВИПРАВЛЕНО
```

---

## Немає змін

- Конфігурація `.env` — без змін
- Архітектура — без змін
- Endpoints — без змін (крім покращених responses)
- Усі 16 фіксів з v1.0.46/47/48 залишаються
