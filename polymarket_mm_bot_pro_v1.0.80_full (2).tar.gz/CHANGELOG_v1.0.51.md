# CHANGELOG v1.0.51 — winrate threshold fix

**Дата:** 2026-07-01
**Попередник:** v1.0.50 (фінальні 8 баг-фіксів)
**Причина:** breakeven trades рахувались як losses через занадто низький поріг

---

## Що нового

Виправлено баг у analytics: trades з прибутком/збитком меншим за $0.05
рахувались як losses через поріг `|rt_pnl| > 0.01`. Це штучно знижувало
win rate, бо gas-only breakeven trades (rt_pnl ≈ -$0.02 = 2× gas) падали
в "loss" категорію.

## Виправлений баг (1 шт)

### BUG-32: winrate threshold 0.01 → 0.05
**Файл:** `app/services/analytics.py`
```diff
- if rt_pnl > 0.01:
+ if rt_pnl > 0.05:
      winners += 1
- elif rt_pnl < -0.01:
+ elif rt_pnl < -0.05:
      losers += 1
+ # else: breakeven (gas-only) — not counted as win or loss
```

**Причина:** $0.01 поріг рахував gas-only trades (rt_pnl ≈ -$0.02) як
losses. Новий $0.05 поріг ігнорує breakeven trades повністю, даючи
реалістичніший win rate для round-trip trades.

## Без змін
- Конфігурація `.env` — без змін
- Архітектура — без змін
- Усі інші тести проходять
