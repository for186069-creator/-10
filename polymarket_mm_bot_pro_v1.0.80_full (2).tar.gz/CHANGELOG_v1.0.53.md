# CHANGELOG v1.0.53 — exit_all + log_file + start PAUSED

**Дата:** 2026-07-01
**Попередник:** v1.0.51 (winrate threshold fix)
**Причина:** 3 нових баги виявлено під час PAPER сесії

---

## Що нового

Три фікси на основі PAPER testing:
1. **Replace Markets** тепер відмовляє, якщо є open positions (orphaned prevention)
2. **LOG_FILE** setting дозволяє писати логи у файл (для нічних сесій)
3. **AUTO_START_TRADING=false** — бот стартує PAUSED (час на налаштування)

## Виправлені баги (3 шт)

### BUG-33: replace orphans positions
**Файл:** `app/admin/api.py`
```python
# v1.0.52 FIX: by default, REFUSES to replace markets that have open
# inventory (would orphan positions). Pass force=true to override.
if not force:
    open_markets = [m for m in current_markets if inventory has position]
    if open_markets:
        return 409 "Cannot replace markets: N market(s) have open positions"
```

### BUG-34: log to file (LOG_FILE + DualStream)
**Файл:** `app/core/logging.py`
```python
# v1.0.52: if log_file is set, structlog writes to BOTH stdout and file
if settings.log_file:
    class DualStream:
        """Write to both stdout and a file."""
        def write(self, data):
            self._stdout.write(data)
            self._file.write(data)
    log_stream = DualStream(settings.log_file)
```

### BUG-35: start PAUSED (AUTO_START_TRADING)
**Файли:** `app/core/config.py`, `app/services/market_maker.py`
```python
# config.py
auto_start_trading: bool = False  # default: PAUSED

# market_maker.py
self._trading_paused = not settings.auto_start_trading
```

## Без змін
- Усі попередні тести проходять
- .env отримав `AUTO_START_TRADING=false` та `LOG_FILE=bot.log`
