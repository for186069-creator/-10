# CHANGELOG v1.0.54 — UI cleanup + .env optimized

**Дата:** 2026-07-01
**Попередник:** v1.0.53 (exit_all + log_file + start PAUSED)
**Причина:** UI містив небезпечну кнопку "Replace Markets", .env мав зайві параметри

---

## Що нового

1. **Removed "Replace Markets" button** з UI (orphaned positions risk)
   - Endpoint `/api/markets/replace` залишається доступним з `force=true`
2. **Optimized .env** — прибрано коментарі, залишено лише production-relevant параметри

## UI зміни

### Прибрано з index.html
- Кнопка "Replace Markets" (orphaned positions risk)
- Додано коментар: "Use Add Markets instead — never removes existing markets"

## .env зміни (v1.0.54 optimized)
```env
PAPER_TRADING=true
PAPER_BALANCE_USDC=10.0
AUTO_START_TRADING=false
LOG_FILE=bot.log

AUTO_PICK_MARKETS=true
AUTO_PICK_DYNAMIC=false
AUTO_PICK_COUNT=3
AUTO_PICK_MIN_VOLUME_24H=10000
AUTO_PICK_MIN_SPREAD_CENTS=2.5

SPREAD_CENTS=4.0
SPREAD_MIN_CENTS=2.5
SPREAD_MAX_CENTS=12.0

ORDER_SIZE_USDC=5.0
MULTI_LEVEL_ENABLED=true

HEDGING_ENABLED=true
SESSION_QUOTING_ENABLED=true

INVENTORY_LIQUIDATION_AGGRESSIVE_AGE_SEC=180
INVENTORY_AGING_THRESHOLD_SEC=120

PAPER_REJECTION_RATE=0.20
PAPER_COMPETITION_RATE=0.50
PAPER_GAS_COST_USDC=0.01

ADMIN_PORT=8765
LOG_LEVEL=INFO
LOG_FORMAT=console
TELEGRAM_ENABLED=false
```

## Без змін
- Код без змін (тільки UI + .env)
- Усі тести проходять
