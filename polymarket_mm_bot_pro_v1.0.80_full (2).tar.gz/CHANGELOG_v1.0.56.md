# CHANGELOG v1.0.56 — partial slider → input + Apply

**Дата:** 2026-07-02
**Попередник:** v1.0.54 (UI cleanup + .env optimized)
**Причина:** слайдери з `oninput` викликали небезпечні auto-fire зміни

---

## Що нового

Перша частина міграції слайдерів → input + Apply:
- **Bankroll**: slider → input + Set (з confirm dialog)
- **Order size**: slider → input + Apply (валідація >= $5)
- **Max inventory**: slider → input + Apply

## UI зміни

### Замінено (3 шт)
| Параметр | Було | Стало |
|---|---|---|
| Bankroll | slider 5-1000 + oninput | input + Set + confirm dialog |
| Order size | slider 5-50 + oninput | input + Apply (валідація >= $5) |
| Max inventory | slider 2-100 + oninput | input + Apply |

### Нові JS функції
- `applyOrderSize()` — валідація 5-50
- `applyMaxInv()` — валідація 2-100
- `applyBankroll()` — валідація 5-1000 + confirm (скидає P&L)

### Безпека
- 3 fewer auto-fire зміни
- Bankroll вимагає confirm dialog з попередженням про reset P&L
- Order size валідується >= $5 перед відправкою

## Без змін
- Код без змін (тільки UI)
- Усі тести проходять
