# CHANGELOG v1.0.57 — ALL sliders → input + Apply

**Дата:** 2026-07-02
**Попередник:** v1.0.56 (partial slider → input)
**Причина:** залишились 4 слайдери з auto-fire `oninput`

---

## Що нового

Завершення міграції слайдерів → input + Apply:
- **Spread (cents)**: slider → input 2-10 + Apply
- **A-S gamma**: slider → input 0.1-1.0 + Apply
- **Markets count**: slider → input 1-20 + Apply (was auto-fire!)
- **Min spread**: slider → input 0.5-5 + Apply (was auto-fire!)

## UI зміни

### Замінено (4 шт)
| Параметр | Було | Стало |
|---|---|---|
| Spread (cents) | slider 2-10 + oninput | input + Apply |
| A-S gamma | slider 0.1-1.0 + oninput | input + Apply |
| Markets count | slider 1-20 + oninput (auto-fire!) | input + Apply |
| Min spread | slider 0.5-5 + oninput (auto-fire!) | input + Apply |

### Нові JS функції
- `applySpread()` — валідація 2-10
- `applyGamma()` — валідація 0.1-1.0
- `applyMarketsCount()` — валідація 1-20 (was auto-fire)
- `applyMinSpread()` — валідація 0.5-5 (was auto-fire)

### Покращення
- `loadConfigIntoSliders()` спрощено — helper `setVal()`
- ЖОДЕН параметр не змінюється без явного кліку "Apply"
- Кожна функція має client-side validation
- Toast повідомлення при успіху/помилці
- Server validation errors показуються в toast

## Підсумок міграції (v1.0.56 + v1.0.57)
- **7 слайдерів** замінено на input + Apply
- **0 auto-fire** змін (було 7 слайдерів з `oninput`)
- **7 explicit Apply** кнопок
- Bankroll: додатковий confirm з попередженням про reset P&L

## Без змін
- Код без змін (тільки UI)
- .env без змін (v1.0.54 config)
- Усі тести проходять
