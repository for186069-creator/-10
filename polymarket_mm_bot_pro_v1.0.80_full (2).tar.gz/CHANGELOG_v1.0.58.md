# CHANGELOG v1.0.58 — verification fixes (7 багів)

**Дата:** 2026-07-02
**Попередник:** v1.0.57 (ALL sliders → input + Apply)
**Причина:** верифікація v1.0.57 виявила 7 нових багів (не згаданих у HANDOFF)

---

## Контекст

Після релізу v1.0.57 було проведено незалежну верифікацію:
- Статичний аналіз коду
- Реальний запуск усіх 110 тестів у чистому venv (Python 3.12.13)
- Перевірка кожного баг-фіксу з HANDOFF

**Результат верифікації v1.0.57:**
- 104/110 тестів pass (6 failed)
- 7 нових багів знайдено (не згадані в HANDOFF)
- 1 заявлений баг (requirements.txt httpx) виявився **FALSE POSITIVE** —
  артефакт термінального виводу (символ `[` не відображався у деяких
  repr-контекстах, хоча байти були правильні)

## Виправлені баги (7 шт)

### BUG-N1: requirements.txt — FALSE POSITIVE (не виправлявся)
**Файл:** `requirements.txt` line 22
**Стан:** Перевірено байт-у-байт: рядок `httpx[http2]==0.28.1` (20 байтів,
символ `[` на позиції 5). pip парсить успішно, `h2 v4.3.0` встановлюється
через `[http2]` extra. Початкова діагностика була артефактом термінального
виводу.
**Дія:** Нічого не змінено. Задокументовано як false positive.

### BUG-N2: Портова невідповідність .env ↔ Docker ↔ scripts ⚠️ MEDIUM
**Файли:** `Dockerfile`, `docker-compose.yml`, `scripts/run_paper.sh`, `scripts/run_live.sh`
**Стан:**
- `.env` має `ADMIN_PORT=8765`
- `Dockerfile` хардкодив `EXPOSE 8000` + `--port 8000`
- `docker-compose.yml` хардкодив `8000:8000`
- `scripts/run_*.sh` хардкодили `--port 8000`

**Наслідки:** Користувач плутався, який порт відкривати. `python -m app.main`
йшов на 8765, а `scripts/run_paper.sh` / Docker — на 8000.

**Фікс:**
- `Dockerfile`: `EXPOSE 8765`, `ENV ADMIN_PORT=8765`, CMD через `${ADMIN_PORT}`,
  healthcheck читає `os.environ.get("ADMIN_PORT", "8765")`
- `docker-compose.yml`: `127.0.0.1:8765:8765`, healthcheck на 8765
- `scripts/run_paper.sh` + `run_live.sh`: читають `ADMIN_PORT` з `.env` з
  fallback 8765

### BUG-N3: 4 inventory тести failing через конфіг-невідповідність ⚠️ LOW
**Файли:** `.env` vs `tests/unit/test_inventory_manager.py`
**Стан:**
- `.env`: `MAX_INVENTORY_PCT_OF_BANKROLL=0.50`
- `test_inventory_manager.py` очікує `0.25` (коментар: "max=$25" при bankroll=$100)

**4 failing тести:**
- `test_should_quote_bid_blocks_at_clear_threshold`
- `test_should_quote_ask_blocks_at_clear_threshold`
- `test_quote_skew_negative_when_long`
- `test_quote_skew_positive_when_short`

**Фікс:** Додано в `tests/conftest.py`:
```python
# v1.0.58 FIX (BUG-N3): pin to 0.25 in tests so they are deterministic
# regardless of .env contents. Env vars take precedence over .env in
# pydantic-settings, so this override wins.
os.environ.setdefault("MAX_INVENTORY_PCT_OF_BANKROLL", "0.25")
```

**Важливо:** Код `inventory_manager.py` ПРАВИЛЬНИЙ. Це тест-інфраструктурний фікс.

### BUG-N4: test_bug21 asyncio timing ⚠️ LOW
**Файл:** `tests/unit/test_market_maker_live.py`
**Стан:** Тест створював `asyncio.create_task(failing_task())` і одразу викликав
`await live_mm.stop()`. `stop()` робив `task.cancel()` ДО того, як задача
встигала виконати `raise RuntimeError`. Задача отримувала CancelledError,
stop() ловив `asyncio.CancelledError` (а не Exception) → warning не логувався.

**Фікс:**
1. Додано `await asyncio.sleep(0)` після створення task — дає event loop
   виконати задачу до raise до cancel
2. Замінено `caplog` на `monkeypatch mm_mod.log.warning` — бо structlog
   пише в stdout через PrintLoggerFactory, не через stdlib logging

### BUG-N5: test_v1047 structlog + caplog ⚠️ LOW
**Файл:** `tests/unit/test_market_maker_live.py`
**Стан:** Тест очікував, що `caplog.records` міститиме structlog warning
`hedge_skipped_insufficient_tokens_preflight`. Warning РЕАЛЬНО емітилося
(видно в captured stdout), але caplog не ловив (structlog bypasses stdlib).

**Фікс:** Замінено `caplog` на `monkeypatch mm_mod.log.warning` (як в BUG-N4).

### BUG-N6: Stale pyproject.toml version + README ⚠️ LOW
**Файли:** `pyproject.toml`, `README.md`
**Стан:**
- `pyproject.toml`: `version = "1.0.0"` (залишився з інцепції)
- `README.md`: "**65 unit tests, 100% pass**" (фактично 110)
- README описував "What's New vs v10.13" — не оновлювався

**Фікс:**
- `pyproject.toml`: `version = "1.0.58"` + коментар тримати в sync з VERSION
- `README.md`: додав "Current version: v1.0.58", оновив "110 unit tests, 100% pass"

### BUG-N7: Відсутні CHANGELOG для v1.0.51-57 ⚠️ LOW
**Файли:** `CHANGELOG_v1.0.51.md`, `CHANGELOG_v1.0.53.md`, `CHANGELOG_v1.0.54.md`,
`CHANGELOG_v1.0.56.md`, `CHANGELOG_v1.0.57.md`
**Стан:** Архів мав CHANGELOG лише до v1.0.50.
**Фікс:** Створено 5 CHANGELOG файлів з описом кожної версії.

### BUG-N8: scripts/run_paper.sh посилався на неіснуючий .env.example ⚠️ LOW
**Файли:** `scripts/run_paper.sh`, `scripts/run_live.sh`, `.env.example`
**Стан:** `run_paper.sh` перевіряв `if [ ! -f .env ]; then cp .env.example .env`,
але `.env.example` відсутній. Якщо користувач видаляв `.env` — `cp` ламався.

**Фікс:**
1. `scripts/run_paper.sh`: якщо `.env` немає І `.env.example` немає —
   зрозуміла помилка з інструкцією
2. Створено `.env.example` (копія `.env` з production-safe defaults)

## Тести

### До v1.0.58
```
6 failed, 104 passed in 1.56s
```

### Після v1.0.58
```
110 passed in 5.91s
```

**100% pass rate.**

## Без змін
- Код app/ без змін (тільки тести + deployment + docs)
- .env без змін (v1.0.54 config)
- Усі баг-фікси з v1.0.46-v1.0.57 збережені

## Архітектура
Без змін.

## CONFIDENCE
**85%** (піднято з 75% у v1.0.57 verification)
- Усі 110 тестів pass
- Усі 7 нових багів виправлено (1 false positive задокументовано)
- Порти уніфіковані
- Документація актуальна
- PAPER/LIVE все ще UNVERIFIED (не маю Windows/Polymarket API)
