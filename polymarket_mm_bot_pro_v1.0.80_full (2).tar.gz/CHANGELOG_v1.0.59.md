# CHANGELOG v1.0.59 — auto-refill throttle fix (BUG-N9)

**Дата:** 2026-07-02
**Попередник:** v1.0.58 (verification fixes)
**Причина:** аналіз живого логу PAPER сесії виявив churning auto-refill цикл

---

## Контекст

Після релізу v1.0.58 користувач надав `bot.log` з 17-хвилинної PAPER сесії.
Аналіз логу виявив:

| Метрика | Значення |
|---|---|
| auto_refill циклів | 19 за 17 хв (~1 цикл кожні 54с) |
| market_skip_tight_spread | 1941 подій |
| markets dropped | 45 |
| Усі ринки мали спред | 1.0¢ (min_required 2.0-2.6¢) |

**Симптом:** бот у нескінченному циклі — discover (fallback relaxed до 0.8¢)
→ skip → replace → discover → skip → ... — замінюючи погані ринки на такі ж
погані кожні ~30-54 секунди.

## Коренева причина

`app/services/market_maker.py` line 362, 366:
```python
if self._cycle_count % 30 != 0:
    return
```

З `interval=1.0s` (з .env `REQUOTE_INTERVAL_SEC=1.0`), це = 30s між refill
спробами. 30s занадто мало:
- Ринки не змінюють quotability так швидко
- Коли ВСІ Polymarket ринки мають tight spreads (часто під час низької
  волатильності), бот churning ті ж погані ринки кожні 30s
- 19 циклів за 17 хв = марні CPU/мережеві витрати з нульовою користю

## Виправлений баг (1 шт)

### BUG-N9: auto-refill churning (30s → 300s throttle)

**Файли:** `app/core/config.py`, `app/services/market_maker.py`, `.env`, `.env.example`

#### 1. app/core/config.py — нова settings змінна
```python
# v1.0.59 (BUG-N9): auto-refill throttle.
auto_refill_cooldown_sec: float = Field(default=300.0, ge=30.0, le=3600.0)
```
- Default: 300s = 5 хв
- Range: 30s (агресивно) до 3600s (1 год, дуже консервативно)
- Configurable через .env: `AUTO_REFILL_COOLDOWN_SEC=300.0`

#### 2. app/services/market_maker.py — monotonic-clock throttle

**__init__** (нова змінна стану):
```python
# v1.0.59 (BUG-N9): monotonic-clock timestamp of last auto-refill.
# Initialized to -inf so the first refill can happen immediately on startup.
self._last_auto_refill_mono: float = -float("inf")
```

**_maybe_auto_refill** (замінений throttle):
```python
# OLD (v1.0.46): 30s throttle via cycle_count
if self._cycle_count % 30 != 0:
    return

# NEW (v1.0.59): time-based throttle via monotonic clock
now_mono = time.monotonic()
elapsed = now_mono - self._last_auto_refill_mono
if elapsed < settings.auto_refill_cooldown_sec:
    return
# ... (set _last_auto_refill_mono before refill action)
self._last_auto_refill_mono = now_mono
```

Додано `auto_refill_throttle_passed` log event з `elapsed_sec`,
`cooldown_sec`, `path` (replace/add), `quotable`, `target` для спостереження.

#### 3. .env + .env.example
```env
# v1.0.59 (BUG-N9): auto-refill cooldown (was ~30s, caused churning).
# Now 300s = 5 min. Markets rarely change quotability faster than this.
AUTO_REFILL_COOLDOWN_SEC=300.0
```

## Тести (3 нові)

У `tests/unit/test_market_maker_live.py` додано 3 тести:

### test_bugN9_auto_refill_throttle_blocks_rapid_second_call
- Перший виклик проходить throttle (initial -inf)
- Другий виклик у межах cooldown — MUST be skipped
- Перевіряє що `discover_markets.call_count` не змінився

### test_bugN9_auto_refill_throttle_allows_after_cooldown
- `_last_auto_refill_mono` встановлено на 400s тому (> 300s cooldown)
- Виклик MUST pass throttle
- Перевіряє що `discover_markets` викликаний

### test_bugN9_auto_refill_first_call_passes_immediately
- Після startup `_last_auto_refill_mono == -inf`
- Перший виклик MUST pass immediately (без 5-хв очікування)

**Regression verified:** повернення старого `cycle_count % 30` коду →
всі 3 тести FAIL. З фіксом → всі 3 PASS.

## Що НЕ змінено (за вимогою користувача)

| Параметр | Стан | Причина |
|---|---|---|
| `spread_min_cents` | 2.5¢ (не знижено до 1.0¢) | зниження = збитки |
| `hedging_enabled` | True (не зачеплено) | за вимогою |
| `multi_level_enabled` | True (не зачеплено) | за вимогою |

## Аналіз our_ask=None (НЕ баг, залишено як є)

Дослідження коду підтвердило що `our_ask=None` у 84/87 quote_placed —
**правильна поведінка**, не баг:

| Файл | Line | Логіка |
|---|---|---|
| `market_maker.py` | 827 | `remaining_tokens = inv.net_tokens` |
| `market_maker.py` | 916 | `if ask_price is not None and remaining_tokens <= 0: ask_price = None` |
| `market_maker.py` | 1012-1022 | `if not is_aged and ask_price < inv.avg_entry_price: ask_price = None` |

**Ланцюжок:**
1. Позиція flat (0 tokens) → `remaining_tokens = 0` → `ask_price = None`
2. Polymarket CTF не підтримує shorting — можна продати тільки те, що маєш
3. Бот ставить тільки BID (купля) коли flat → заповнює позицію
4. Коли позиція є (26 tokens) → ask ставиться (3 quotes з 87)

Лог підтверджує: 84/87 quote_placed мають `inventory_tokens=0.0` (flat),
3 мають `26.0262` (long, ask placed).

**Висновок:** чіпати це НЕ треба. Це захист від LIVE rejection (Polymarket
API відхилить SELL без token balance). Видалення блоку зламає LIVE.

## Тести

### До v1.0.59
```
110 passed
```

### Після v1.0.59
```
113 passed in 3.93s
```
(+3 нових тести для BUG-N9)

## Без змін
- app/ код (крім market_maker.py та config.py) — без змін
- Усі баг-фікси з v1.0.46-v1.0.58 збережені
- Порти уніфіковані на 8765 (з v1.0.58)
- .env.example (з v1.0.58) + нова змінна

## Архітектура
Без змін.

## CONFIDENCE
**87%** (піднято з 85% у v1.0.58)
- Усі 113 тестів pass
- BUG-N9 root cause ідентифіковано з живого логу
- Фікс консервативний (5 хв default, configurable)
- Regression тести доводять що фікс працює
- PAPER/LIVE все ще UNVERIFIED (немаю Windows/Polymarket API в sandbox)
