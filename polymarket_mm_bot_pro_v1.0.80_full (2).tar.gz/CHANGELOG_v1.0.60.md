# CHANGELOG v1.0.60 — discovery fallback spread fix (BUG-N10)

**Дата:** 2026-07-02
**Попередник:** v1.0.59 (auto-refill throttle fix)
**Причина:** аналіз 94-хвилинної PAPER сесії виявив, що fallback discovery додавав «сміттєві» ринки (1.0¢ спред), які ніколи не котирувались

---

## Контекст

Після релізу v1.0.59 користувач надав `bot.log` з 94-хвилинної PAPER сесії.
Аналіз логу (23 890 рядків) виявив:

| Метрика | Значення |
|---|---|
| `market_skip_tight_spread` | **22 724** подій |
| Унікальних ринків skip'нуто | 8 (усі зі спредом 1.0¢) |
| Quotable ринків (максимум) | 2 (Will Apple Yes/No) |
| `markets_discovered candidates=0` | 12 разів |
| Спроб додати ринки вручну (5 разів) | усі `markets_add_no_new` |

**Симптом:** після reset (18:50) бот не міг додати більше 2 ринків — усі спроби
повертали `markets_add_no_new`, бо єдиний ринок зі спредом ≥2.5¢ на Polymarket
(Will Apple) вже був у боті. Fallback (розслаблений поріг 0.8¢) не запускався,
бо primary discovery повернув непорожній результат.

При цьому в ранній частині сесії (17:24) fallback УСПІШНО додавав 7 ринків
(Pittsburgh, Putin, Spain, Fed, Strait, Cincinnati, Will Apple), але ВСІ вони
мали спред 1.0¢ і одразу skip'нулись при котируванні (22 724 skip-події).

## Коренева причина

`app/services/clob_client.py` line 594-597:
```python
# Fallback: relax spread threshold to 0.8¢
if not result:
    log.warning("markets_discovery_fallback", relaxed_spread_cents=0.8)
    relaxed = 0.008   # ← HARDCODED 0.8¢
```

Fallback приймав ринки зі спредом ≥0.8¢. Але при котируванні поріг
`SPREAD_MIN_CENTS` = 2.0–2.5¢. Будь-який ринок зі спредом 0.8–2.4¢:
- ✅ проходить fallback discovery
- ❌ fail `market_skip_tight_spread` (market_maker.py:572)
- → ніколи не котирується, лише витрачає WS-підписку та CPU

Це була прогалина в дизайні: два пороги (discovery fallback vs quoting)
не були пов'язані, що дозволяло «сміттєвим» ринкам потрапляти в бот.

## Виправлений баг (1 шт)

### BUG-N10: discovery fallback hardcoded 0.8¢ spread threshold

**Файл:** `app/services/clob_client.py` (рядки 594-610)

#### Було (v1.0.59)
```python
# Fallback: relax spread threshold to 0.8¢
if not result:
    log.warning("markets_discovery_fallback", relaxed_spread_cents=0.8)
    relaxed = 0.008
    ...
```

#### Стало (v1.0.60)
```python
# Fallback: relax spread threshold to settings.spread_min_cents.
# v1.0.60 FIX (BUG-N10): was hardcoded 0.8¢ (0.008), which let the
# fallback pick markets with 0.8–2.4¢ spreads. Those markets then
# failed market_skip_tight_spread (spread < spread_min_cents) at
# quote time — bot added them but never quoted them ("garbage"
# markets, 22 724 skip events in 94-min PAPER session).
# Now: relaxed = spread_min_cents/100, so any market found via
# fallback is guaranteed quotable. Effectively makes fallback
# useful only when primary found 0 candidates — it will still
# find markets with spread_min_cents ≤ spread < auto_pick_min_spread_cents
# (narrow window, e.g. 2.0¢–2.4¢ when auto_pick_min=2.5, spread_min=2.0).
if not result:
    log.warning(
        "markets_discovery_fallback",
        relaxed_spread_cents=settings.spread_min_cents,
    )
    relaxed = settings.spread_min_cents / 100.0
    ...
```

#### Чому це правильно

1. `settings.spread_min_cents` — існуюча validated настройка (`config.py:102`,
   тип `float`, default 1.5, gt=0)
2. `settings` вже імпортовано у файлі (використовується в тій самій функції)
3. Будь-який ринок, знайдений через fallback, гарантовано матиме спред
   ≥ `spread_min_cents` → не буде skip'нутий при котируванні
4. Fallback стає корисним ТІЛЬКИ у вузькому вікні:
   `[spread_min_cents, auto_pick_min_spread_cents)` — наприклад 2.0¢–2.4¢
   при типових налаштуваннях
5. Якщо на Polymarket немає ринків у цьому вікні — fallback поверне 0,
   що **краще** за 7 «сміттєвих» (не витрачає resource)

## Зміна поведінки

| Ситуація | v1.0.59 (було) | v1.0.60 (стало) |
|---|---|---|
| Primary знайшов 0, є ринки 0.8–2.4¢ | Додає їх → 22k skip | Повертає 0 — бот без нових ринків |
| Primary знайшов 0, є ринки 2.0–2.4¢ | Додає їх → skip (якщо spread_min=2.5) | Додає їх → quotable ✅ |
| Primary знайшов ≥1 (Apple) | Fallback не запускається | Fallback не запускається (без змін) |
| Банкрол $40, dynamic=True, target=4 | Apple + 7 сміттєвих | Apple only (2 quotable) |

**Ключова зміна:** бот більше не додає ринки, які гарантовано не торгуватимуть.
Краще мати 2 quotable ринки, ніж 2 quotable + 7 «сміттєвих».

## Тести

### Не додано нових тестів
Згідно з правилами проекту (truth-first, без симуляцій) — новий test-код не
дописується. Regression-покриття для BUG-N10 залишається на розсуд користувача.

### Існуючі тести — не зачеплені
```
$ rg "relaxed|discovery_fallback|0\.008|0\.8¢|fallback" tests/
(no matches)
```
0 збігів у `tests/` — жоден існуючий тест не посилається на змінений код.

### Перевірки виконано
| Перевірка | Результат |
|---|---|
| `python3 -m py_compile app/services/clob_client.py` | ✅ OK (без синтаксичних помилок) |
| Інші `0.008` / `0.8¢` у файлі | ✅ Не залишилось (тільки в коментарі-поясненні) |
| `settings.spread_min_cents` використовується в fallback | ✅ (рядки 608, 610) |
| Тести посилаються на relaxed/fallback | ✅ 0 збігів (не зламає) |

## Що НЕ змінено (за вимогою користувача)

| Параметр | Стан | Причина |
|---|---|---|
| `spread_min_cents` | 2.5¢ (не знижено до 1.0¢) | зниження = збитки |
| `hedging_enabled` | True (не зачеплено) | за вимогою |
| `multi_level_enabled` | True (не зачеплено) | за ворогою |
| `auto_pick_keywords` | не розширено | окреме рішення користувача |

## Архітектура

Без змін — лише 1 файл змінено (`clob_client.py` рядки 594-610).

## Файли, оновлені для v1.0.60

| Файл | Зміна |
|---|---|
| `VERSION` | 1.0.59 → 1.0.60 + change notes |
| `pyproject.toml` | `version = "1.0.60"` |
| `README.md` | `v1.0.59` → `v1.0.60` (2 місця) |
| `CHANGELOG_v1.0.60.md` | NEW (цей файл) |
| `HANDOFF_v1.0.60.md` | NEW |
| `app/services/clob_client.py` | BUG-N10 fix (рядки 594-610) |

Усі інші файли — без змін з v1.0.59.

## CONFIDENCE

**88%**
- Кодова зміна мінімальна (1 рядок логіки + коментар/log для консистентності)
- py_compile passes
- Жоден існуючий тест не посилається на змінений шлях (0 збігів)
- Логіка перевірена читанням: `relaxed = spread_min_cents/100 = 0.025` при
  `spread_min_cents=2.5`, тож fallback приймає лише спред ≥ 2.5¢
- PAPER/LIVE сесія з цим фіксом ще не запущена — UNVERIFIED
- `pytest` не запущено в sandbox (немає Python-залежностей)

## Рекомендація для наступної PAPER сесії

1. Розпакувати `polymarket_mm_bot_pro_v1.0.60.tar.gz`
2. Запустити `pytest tests/ --no-cov -q` локально — очікування 113/113 pass
3. Запустити бота з v1.0.60
4. Перевірити `bot.log`:
   - `markets_discovery_fallback` (якщо буде) має логувати `relaxed_spread_cents=2.5`
     замість `0.8`
   - `market_skip_tight_spread` для fallback-доданих ринків має зникнути
5. Для отримання >2 quotable ринків — паралельно розширити `AUTO_PICK_KEYWORDS`
   (рекомендація Рівня 1A з звіту аналізу)
