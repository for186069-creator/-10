# CHANGELOG v1.0.61 — UI input limits raised (BUG-N11)

**Дата:** 2026-07-02
**Попередник:** v1.0.60 (discovery fallback fix)
**Причина:** користувач не міг встановити order_size > $50 та max_inventory > $100 через HTML-обмеження

---

## Контекст

Після релізу v1.0.60 користувач виявив що в UI панелі бота не можна вибрати:
- Order size > $50 (HTML `max="50"`)
- Max inventory > $100 (HTML `max="100"`)

При цьому API та config.py не мали верхніх лімітів — браузер блокував значення, які бекенд прийняв би.

## Коренева причина

`app/static/index.html` — 4 `<input type="number">` поля мали жорсткі HTML-обмеження `max`:

| Поле | HTML max | JS перевірка | API перевірка | config.py |
|---|---|---|---|---|
| `orderSize` | `max="50"` | `min=5` | `ge=5.0` (без max) | `gt=0` (без max) |
| `maxInv` | `max="100"` | `min=2` | `gt=0` (без max) | `gt=0` (без max) |
| `bankrollInput` | `max="1000"` | `min=5` | (без max) | `gt=0` (без max) |
| `marketsCountSlider` | `max="20"` | `min=1` | (без max) | `ge=1, le=20` |

**Невідповідність:** HTML обмежував жорстко, тоді як бекенд приймав будь-яке додатне значення.

## Виправлений баг (1 шт)

### BUG-N11: HTML input max attributes blocked large values

**Файл:** `app/static/index.html` (4 input fields)

#### Було (v1.0.60)
```html
<input type="number" id="orderSize" min="5" max="50" ...>
<input type="number" id="maxInv" min="2" max="100" ...>
<input type="number" id="bankrollInput" min="5" max="1000" ...>
<input type="number" id="marketsCountSlider" min="1" max="20" ...>
```

#### Стало (v1.0.61)
```html
<input type="number" id="orderSize" min="5" max="1000" ...>
<input type="number" id="maxInv" min="2" max="10000" ...>
<input type="number" id="bankrollInput" min="5" max="100000" ...>
<input type="number" id="marketsCountSlider" min="1" max="50" ...>
```

#### Чому саме ці значення

| Поле | Новий max | Логіка |
|---|---|---|
| `orderSize` | 1000 | Дозволяє $1000 ордери (екстрем для великих банкролів) |
| `maxInv` | 10000 | Дозволяє $10000 інвентар на ринок (whale mode) |
| `bankrollInput` | 100000 | Дозволяє до $100k депозит (інституціонал) |
| `marketsCountSlider` | 50 | Дозволяє 50 одночасних ринків |

#### Бекенд все ще валідує

API `validation_rules` (api.py:454-466) залишились без змін:
- `order_size_usdc >= 5.0` (Polymarket minimum)
- `max_inventory_usdc > 0`
- `max_inventory_pct_of_bankroll` in [0, 1]
- Всі інші config.py Field обмеження

## Що НЕ змінено

| Поле | max | Причина |
|---|---|---|
| `spread` | 10 | Розумний максимум для MM (10¢ спред вже широкий) |
| `minSpread` | 5 | Розумний максимум |
| `asGamma` | 1.0 | UI консервативний (config дозволяє до 5.0) |
| Всі `min` значення | — | Збережені |

## Важливе зауваження про `max_inventory_usdc`

Семантика `max_inventory_usdc` НЕ змінилась (задокументовано в v1.0.60):
- Це **FLOOR** (мінімум), а не CEILING (максимум), незважаючи на назву
- Код: `max(settings.max_inventory_usdc, pct_cap)`
- Ефективний ліміт = `max($max_inv, pct × bankroll)`
- Приклад: `max_inv=$60, pct=0.50, bankroll=$1000` → `max($60, $500) = $500`
- Для реального ліміту $60: встановити `MAX_INVENTORY_PCT_OF_BANKROLL=0.06`

## Тести

- **Без змін** — UI не покривається unit-тестами
- 113 існуючих тестів не зачеплені (HTML-only change)
- `py_compile` N/A (HTML файл)

## Архітектура

Без змін — лише 1 файл (`app/static/index.html`, 4 атрибути).

## Файли, оновлені для v1.0.61

| Файл | Зміна |
|---|---|
| `VERSION` | 1.0.60 → 1.0.61 + change notes |
| `pyproject.toml` | `version = "1.0.61"` |
| `README.md` | `v1.0.60` → `v1.0.61` (2 місця) |
| `CHANGELOG_v1.0.61.md` | NEW (цей файл) |
| `HANDOFF_v1.0.61.md` | NEW |
| `app/static/index.html` | BUG-N11 fix (4 input max атрибути) |

Усі інші файли — без змін з v1.0.60 (включаючи BUG-N10 fix).

## CONFIDENCE

**95%**
- HTML зміна мінімальна (4 атрибути)
- Бекенд вже приймав ці значення (без API змін)
- Жоден Python-код не зачеплений
- UNVERIFIED: не тестував у браузері (немає запущеного бота в sandbox)

## Рекомендація

1. Розпакувати `polymarket_mm_bot_pro_v1.0.61.tar.gz`
2. Запустити бота
3. У UI перевірити що тепер можна ввести:
   - Order size: $80 (для купівлі на $500-800)
   - Max inventory: $500-800
   - Bankroll: $1000+ (без блокування)
4. Див. звіт «Як зробити щоб бот купував на $500-800» для повного набору .env налаштувань
