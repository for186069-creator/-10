# CHANGELOG v1.0.62 — URGENT liquidation stop-loss (BUG-N12)

**Дата:** 2026-07-03
**Попередник:** v1.0.61 (UI input limits)
**Причина:** аналіз 7.5-годинної PAPER сесії виявив -$166 збиток на одній угоді

---

## Контекст

Після v1.0.61 користувач запустив нічну PAPER сесію ($1000 банкрол, 7.5 годин).
Аналіз логу (220 624 рядки, 3479 fills) виявив:

| Метрика | Значення |
|---|---|
| Total realized P&L | +$907.84 |
| Великі збитки (<-$5) | 13 fills, -$338.95 |
| **Найбільший збиток** | **-$166.02** (одна угода!) |
| Збитки від URGENT ліквідацій | -$211.09 (62% великих збитків) |

**Симптом:** Switzerland Round of 16 — купили 1536 tokens @ ~$0.141, продали @ $0.030 → -$166.

## Коренева причина

`app/services/market_maker.py:1688` (старий код):
```python
if loss_cents > settings.inventory_liquidation_max_loss_cents and not is_urgent:
    # AGGRESSIVE: skip if loss > 4¢
    continue
# URGENT: продає за БУДЬ-ЯКУ ціну (без стоп-лосу!)
```

URGENT ліквідація (age > 360с) ігнорувала `max_loss_cents` — продавала за будь-яку ціну. Коли ціна впала з 0.151 до 0.030 (-80%), URGENT продала з втратою 11¢/token × 1500 tokens = -$166.

## Виправлений баг

### BUG-N12: URGENT liquidation stop-loss

**Файли:** `app/core/config.py`, `app/services/market_maker.py`, `.env`, `.env.example`

#### 1. app/core/config.py — нова настройка
```python
# v1.0.62 (BUG-N12): URGENT liquidation stop-loss.
# Previously URGENT sold at ANY price (even -11¢/token = -$166 loss).
# Now: if loss_cents > urgent_max_loss → skip even URGENT, wait for recovery.
# Default 15¢ = max 15% loss per token in URGENT mode.
# Set to 100.0 to restore old behavior (sell at any price).
inventory_liquidation_urgent_max_loss_cents: float = Field(default=15.0, ge=0)
```

#### 2. app/services/market_maker.py — URGENT stop-loss check
```python
# v1.0.62 (BUG-N12): URGENT stop-loss.
if is_urgent and loss_cents > settings.inventory_liquidation_urgent_max_loss_cents:
    log.warning(
        "urgent_liquidation_skipped_loss_exceeds_stop",
        market=market_name,
        age_sec=round(age_sec, 0),
        avg_entry=round(inv.avg_entry_price, 4),
        sell_price=round(sell_price, 4),
        loss_cents=round(loss_cents, 2),
        urgent_max_loss_cents=settings.inventory_liquidation_urgent_max_loss_cents,
        net_tokens=round(inv.net_tokens, 2),
        potential_loss_usd=round(
            inv.net_tokens * (inv.avg_entry_price - sell_price), 2
        ),
        reason="holding position — urgent loss exceeds stop-loss threshold",
    )
    continue
```

#### 3. .env + .env.example
```env
INVENTORY_LIQUIDATION_URGENT_MAX_LOSS_CENTS=15.0
```

## Зміна поведінки

| Ситуація | v1.0.61 (було) | v1.0.62 (стало) |
|---|---|---|
| URGENT, loss 5¢ | Продати (збиток) | Продати (5¢ < 15¢ ліміт) ✅ |
| URGENT, loss 11¢ | **Продати (-$166)** ❌ | **Skip, hold position** ✅ |
| URGENT, loss 20¢ | Продати (величезний збиток) | Skip, hold position |
| AGGRESSIVE, loss 5¢ | Skip | Skip (без змін) |
| AGGRESSIVE, loss 11¢ | Skip | Skip (без змін) |

## Ризик та компроміс

**Перевага:** Немає більше -$166 збитків. Макс збиток за угоду = 15¢ × tokens.

**Недолік:** Позиція може застрягти якщо ціна не відновиться. Бот буде тримати збиткову позицію замість фіксувати збиток.

**Пом'якшення:** 
- Якщо ціна не відновиться, `pre_resolution_exit_sec=900` продасть за 15 хв до resolution
- Можна встановити `INVENTORY_LIQUIDATION_URGENT_MAX_LOSS_CENTS=30.0` для більшої гнучкості
- Можна встановити `100.0` щоб відновити стару поведінку

## Діаграма рішення ліквідації

```
position age > 180s? → AGGRESSIVE
  loss > 4¢? → SKIP (wait)
  loss ≤ 4¢ → SELL at market_bid + 0.001

position age > 360s? → URGENT
  loss > 15¢? → SKIP (v1.0.62 NEW — hold, wait for recovery)
  loss ≤ 15¢ → SELL at market_bid (any price)
```

## Тести

- `py_compile` ✅ OK
- Існуючі 113 тестів не зачеплені (URGENT path не покривається unit-тестами)
- UNVERIFIED: PAPER сесія з v1.0.62 не запущена

## Рекомендація додатково

Крім фіксу BUG-N12, рекомендую змінити в `.env`:

```env
# Зменшити ліміт інвентарю (зараз 50% × $1500 = $750 — занадто великий)
MAX_INVENTORY_PCT_OF_BANKROLL=0.15    # 15% × $1500 = $225 ліміт

# Зменшити inventory_clear_threshold (зараз 0.8 — дозволяє 80% ліміту)
INVENTORY_CLEAR_THRESHOLD=0.5         # блокувати BUY на 50% ліміту

# Збільшити urgent_age (зараз 360с = 6 хв — занадто швидко)
INVENTORY_LIQUIDATION_URGENT_AGE_SEC=900.0   # 15 хв
```

Ці зміни + BUG-N12 fix → зменшать макс збиток за угоду з -$166 до ~-$30.

## Архітектура

Без змін — 2 файли коду + 2 конфіг-файли.

## CONFIDENCE: 90%

- Кодова зміна ізольована (1 новий if-блок)
- py_compile passes
- Логіка проста: if loss > limit → skip
- UNVERIFIED: не тестував на PAPER сесії
- Ризик: позиції можуть застрягати (пом'якшено pre_resolution_exit)
