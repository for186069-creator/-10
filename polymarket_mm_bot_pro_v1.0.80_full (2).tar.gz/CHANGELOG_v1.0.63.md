# CHANGELOG v1.0.63 — Professional MM risk management (BUG-N13 + BUG-N14 + REVERT)

**Дата:** 2026-07-03
**Попередник:** v1.0.62 (URGENT stop-loss — REMOVED in v1.0.63)
**Причина:** користувач вказав що MM боти не мають price-based stop-loss; потрібен професійний підхід

---

## Контекст

Після v1.0.62 користувач справедливо вказав: **«ЯКИЙ НАХУЙ СТОП ЛОСС ТИ РОБИШ У ММ БОТІ»**.
MM боти за дизайн НЕ мають класичного цінового стоп-лосу. v1.0.62 додав
«URGENT loss limit 15¢» — це було неправильно названо «stop-loss» і не є
професійним MM-підходом.

v1.0.63 повертає правильний підхід:
1. Відкат v1.0.62 (URGENT stop-loss видалено)
2. Додано **Critical tier liquidation** (BUG-N13) — position-based deleveraging
3. Додано **Volatility-scaled sizing** (BUG-N14) — Avellaneda-Stoikov стандарт
4. .env defaults змінені на професійні (3% per market)

## Зміни (3)

### 1. REVERT: v1.0.62 BUG-N12 — ВИДАЛЕНО

**Причина:** MM боти не використовують price-based stop-loss.
- Видалено: `inventory_liquidation_urgent_max_loss_cents` (config.py)
- Видалено: URGENT stop-loss check (market_maker.py:1698-1718)
- Видалено: `INVENTORY_LIQUIDATION_URGENT_MAX_LOSS_CENTS` з .env
- Повернено: URGENT продає за будь-яку ціну (v1.0.61 поведінка)

### 2. BUG-N13: Critical tier liquidation (NEW)

**Файл:** `app/services/market_maker.py:1666-1690`

**Логіка:**
```python
if age_sec < settings.inventory_liquidation_aggressive_age_sec:
    # NEW: Critical tier — position at 95%+ of hard cap
    max_usd = self.inventory.max_inventory_usdc()
    position_usd = abs(inv.net_tokens) * market_bid
    if max_usd > 0 and position_usd >= max_usd * 0.95:
        tier = "CRITICAL"
        sell_price = min(market_bid + 0.001, book.best_ask - 0.001)
        # → deleverage NOW, regardless of age
    else:
        continue  # not aged, not at critical
```

**Професійне обґрунтування:**
Стандарт MM має 3-tier inventory management:
- Soft (skew quotes) — bot мав ✅
- Hard (block BUY) — bot мав ✅
- **Critical (deleverage)** — bot НЕ мав ❌ → FIXED

Без Critical tier бот міг накопичити > max_inventory через швидкі fills
(Switzerland набрав $232 при ліміті $750 = 31%, але через багато fills).

### 3. BUG-N14: Volatility-scaled sizing (NEW)

**Файли:** `app/core/config.py:149-165`, `app/services/market_maker.py:848-873`

**Нові settings:**
```python
order_size_volatility_scaling: bool = True           # ON by default
order_size_reference_volatility: float = 0.02         # σ at which vol_mult=1.0
order_size_min_vol_mult: float = 0.25                  # max 4x reduction
order_size_max_vol_mult: float = 1.5                   # max 1.5x increase
```

**Формула:**
```
vol_mult = reference_vol / max(sigma, as_min_volatility)
vol_mult = clamp(vol_mult, 0.25, 1.5)
final_size = base_size × vol_mult
```

**Приклад:**
| σ (volatility) | vol_mult | base $80 → final |
|---|---|---|
| 0.005 (низька) | 1.5 (cap) | $120 |
| 0.02 (reference) | 1.0 | $80 |
| 0.05 (висока) | 0.4 | $32 |
| 0.10 (дуже висока) | 0.25 (floor) | $20 |

**Професійне обґрунтування:**
Avellaneda-Stoikov (2008) — формула optimal quote size обернено пропорційна σ.
Висока волатильність → малий size (обмежити exposure); низька → великий (capture edge).

### 4. .env defaults — професійні значення

| Параметр | Було (v1.0.62) | Стало (v1.0.63) |
|---|---|---|
| `MAX_INVENTORY_PCT_OF_BANKROLL` | 0.50 (50%) | **0.03 (3%)** |
| `INVENTORY_CLEAR_THRESHOLD` | 0.8 | **0.5** |
| `ORDER_SIZE_VOLATILITY_SCALING` | (не існувало) | **true** |

**Математика:**
- Bankroll $1000 × 3% = **$30 max per market** (було $500)
- 10 ринків × $30 = $300 total inventory cap (30% bankroll)
- Max single-market loss at -100%: $30 (3% bankroll)
- Max single-market loss at -80% (Switzerland scenario): **$24** (було -$166)

## Що НЕ змінилось

- `inventory_liquidation_max_loss_cents=4.0` (AGGRESSIVE, standard)
- `inventory_liquidation_aggressive_age_sec=180` (standard)
- `inventory_liquidation_urgent_age_sec=360` (standard)
- URGENT продає за будь-яку ціну (повернено v1.0.61 поведінку)
- Усі попередні фікси (BUG-N9/N10/N11) — збережені

## Тести

- `py_compile` ✅ OK
- 113 тестів не зачеплені (UNVERIFIED — не запускав)
- Нові тести НЕ додані (правило: без test-коду)

## Архітектура

Зміни в 2 файлах коду + 2 конфіг-файли:
- `app/core/config.py` — 4 нові поля, 1 видалене
- `app/services/market_maker.py` — Critical tier + vol scaling + revert
- `.env` + `.env.example` — нові змінні, видалене URGENT_MAX_LOSS

## CONFIDENCE: 88%

- Кодові зміни ізольовані
- py_compile passes
- Математика перевірена: 3% × $1000 = $30
- UNVERIFIED: PAPER сесія не запущена
- Ризик: vol_mult може зробити ордери < $5 (Polymarket min) — оброблено через `max(scaled, $5)`

## Рекомендація

1. Запустити PAPER сесію 6+ годин з v1.0.63
2. Перевірити в логу:
   - `order_size_volatility_scaled` — підтвердження що vol scaling працює
   - `critical_tier_liquidation_triggered` — спрацьовує при 95% ліміту
3. Якщо інвентар все ще занадто великий — зменшити `MAX_INVENTORY_PCT_OF_BANKROLL=0.02` (2%)
4. НЕ заливати $1000 LIVE — спочатку smoke $5
