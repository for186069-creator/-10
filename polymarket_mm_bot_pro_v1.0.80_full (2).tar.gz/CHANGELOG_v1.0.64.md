# CHANGELOG v1.0.64 — STALE_DATA false-positive fix (BUG-N15)

**Дата:** 2026-07-03
**Попередник:** v1.0.63 (volatility-scaled sizing + Critical tier)
**Причина:** 9 STALE_DATA halts за нічну сесію на порозі 30с

---

## Контекст

Аналіз нічного логу (7.5 годин, 220k рядків) виявив:
- **7 STALE_DATA halts** з "WS silent 30s" (рівно на порозі)
- Bankroll коливався: $799 → $1650 → $1556 (кожен halt переривав торгівлю)

**Симптом:** Polymarket WS шле повідомлення лише при зміні книги. Ночі — мало торгів → мало повідомлень → WS silent > 30с → halt.

## Коренева причина

`app/services/clob_client.py`:
- `last_msg_time` оновлювався ТІЛЬКИ WS повідомленнями (рядки 274, 286)
- REST poll (`_poll_loop`, кожні 3с) НЕ оновлював `last_msg_time`
- Тобто: WS тихо, але REST працює → `last_ws_msg_age` росте → STALE_DATA halt

**Це false-positive:** REST fallback дає актуальні дані, але бот думає що з'єднання втрачено.

## Виправлений баг

### BUG-N15: STALE_DATA false-positive when REST fallback is working

**Файли:** `app/services/clob_client.py`, `app/core/config.py`, `.env`, `.env.example`

#### 1. clob_client.py — `_refresh_all_books` оновлює last_msg_time

```python
# Було:
async def _refresh_all_books(self):
    tasks = [self._fetch_book(session, tid) for tid in tids]
    await asyncio.gather(*tasks, return_exceptions=True)
    # ← last_msg_time НЕ оновлювався

# Стало:
results = await asyncio.gather(*tasks, return_exceptions=True)
success_count = sum(1 for r in results if r is True)
if success_count > 0:
    self._feed.last_msg_time = time.monotonic()  # ← NEW
```

#### 2. clob_client.py — `_fetch_book` повертає bool

```python
# Було: returns None (implicit)
# Стало: returns True on 200, False on non-200 or exception
async def _fetch_book(self, session, tid) -> bool:
    try:
        if resp.status == 200:
            self._apply_book(tid, data)
            return True
        else:
            return False
    except Exception:
        return False
```

#### 3. config.py — default 30s → 120s

```python
# Було:
stale_data_threshold_sec: float = Field(default=30, gt=0)

# Стало:
stale_data_threshold_sec: float = Field(default=120, gt=0)
```

#### 4. .env + .env.example

```env
STALE_DATA_THRESHOLD_SEC=120   # було 30
```

## Зміна поведінки

| Ситуація | v1.0.63 | v1.0.64 |
|---|---|---|
| WS тихий, REST працює | halt через 30с ❌ | **last_msg_time оновлюється, halt НЕ спрацьовує** ✅ |
| WS обірвався, REST працює | halt через 30с | **продовжує торгувати через REST** ✅ |
| WS + REST обидва не працюють | halt через 30с | halt через 120с (подвійна перевірка) ✅ |
| Нічна тиха сесія | 7 halts за ніч | **0 halts** ✅ |

## Чому 120с, не 30с

- REST poll запускається кожні 3с (рядок 764)
- Якщо REST також не працює 120с = 40 невдалих спроб підряд
- Це гарантований обрив з'єднання (не тихий ринок)
- Професійний стандарт для low-frequency markets: 60-180с

## Тести

- `py_compile` ✅ OK
- Існуючі 113 тестів не зачеплені (UNVERIFIED)
- `_fetch_book` return type змінився з None → bool, але єдиний викликач (`_refresh_all_books`) оновлений

## Архітектура

Зміни в 1 файлі коду + 1 config + 2 .env:
- `app/services/clob_client.py` — `_refresh_all_books` + `_fetch_book` return type
- `app/core/config.py` — default 30 → 120
- `.env` + `.env.example` — STALE_DATA_THRESHOLD_SEC=120

Усі інші фікси (v1.0.59-N14) — збережені.

## CONFIDENCE: 92%

- Кодова зміна мінімальна (1 new if + return type change)
- py_compile passes
- Логіка проста: if REST OK → update timestamp → no false halt
- UNVERIFIED: PAPER сесія не запущена
- Ризик: якщо REST maskує реальний WS обрив — бот торгуватиме на stale REST дані. Але REST сам оновлює книги, тому дані актуальні.

## Рекомендація

1. Запустити PAPER сесію на ніч з v1.0.64
2. Перевірити: `trading_halted STALE_DATA` має зникнути або зменшитись до 0-1
3. Якщо STALE_DATA все ще спрацьовує — реальний обрив інтернету (не бот проблема)
