# CHANGELOG v1.0.65 — Exit All pricing fix (BUG-N16)

**Дата:** 2026-07-03
**Попередник:** v1.0.64 (STALE_DATA fix)
**Причина:** Exit All втратив $4 unrealized profit, продав за entry+0.5¢ замість mid

---

## Контекст

Користувач виконав Exit All з інвентарем $8 на 2 ринках (Will there be 5+ missed penalties).
UI показував unrealized profit **$4+**. Але Exit All зафіксував лише **$0.14**.

**Аналіз логу:**
| Ринок | avg_entry | mid (реальна ціна) | Продав за (v1.0.64) | Втрата |
|---|---|---|---|---|
| Yes | $0.189 | **$0.322** | $0.194 | **-$3.21** |
| No | $0.545 | **$0.678** | $0.550 | **-$0.80** |
| **Total** | | | | **-$4.01** unrealized втрачено |

## Коренева причина

`app/admin/api.py:689` (старий код):
```python
target_price = round(avg_entry + (min_profit_cents / 100.0), 4)
#                          ↑ entry + 0.5¢ (hardcoded min_profit_cents=0.5)
```

Exit All ігнорував поточну ціну ринку (mid). Продавав за `entry + 0.5¢` навіть коли mid був набагато вищий.

## Виправлений баг

### BUG-N16: Exit All ignores mid price — sells at entry+0.5¢

**Файл:** `app/admin/api.py:681-800`

#### Було (v1.0.64)
```python
target_price = avg_entry + 0.005  # завжди entry + 0.5¢
if market_bid >= target_price:
    sell_price = market_bid       # продаж за bid
else:
    sell_price = target_price     # продаж за entry+0.5¢ (НЕ mid!)
```

#### Стало (v1.0.65) — A + C priority
```python
# A: mid-based target (capture unrealized profit)
mid = (market_bid + market_ask) / 2.0
target_mid = round(mid, 4)

# C: entry + 5¢ floor (raised from 0.5¢)
target_min = round(avg_entry + 0.05, 4)

# Take the LARGER of A and C
target_price = max(target_mid, target_min)
# Cap at ask - 0.001 (would never fill above ask)
target_price = min(target_price, market_ask - 0.001)

if market_bid >= target_price:
    sell_price = market_bid       # продаж за bid (негайно)
else:
    sell_price = target_price     # продаж за max(mid, entry+5¢)
```

#### Логіка пріоритетів

| Пріоритет | Умова | Ціна | Прибуток |
|---|---|---|---|
| **A (mid)** | mid > entry+5¢ | mid | Захоплює unrealized |
| **C (entry+5¢)** | mid < entry+5¢ | entry+5¢ | Мін 5¢ прибутку |
| Cap | target > ask-0.001 | ask-0.001 | Щоб заповнилось |

## Зміна поведінки

| Ситуація | v1.0.64 | v1.0.65 |
|---|---|---|
| entry $0.189, mid $0.322 | Продати $0.194 → **$0.14 прибуток** | Продати $0.322 → **$3.34 прибуток** ✅ |
| entry $0.545, mid $0.678 | Продати $0.550 → **$0.03 прибуток** | Продати $0.677 → **$0.83 прибуток** ✅ |
| entry $0.189, mid $0.190 (тонкий спред) | Продати $0.194 | Продати $0.239 (entry+5¢) |
| entry $0.189, mid $0.189 (без прибутку) | Продати $0.194 (force) | Продати $0.239 (limit, чекати) |

## Ваша ситуація з v1.0.65

Якби користувач мав v1.0.65:
- **Ринок Yes:** 25.10 tokens × ($0.322 - $0.189) = **+$3.34** ✅
- **Ринок No:** 6.27 tokens × ($0.677 - $0.545) = **+$0.83** ✅
- **Total realized: +$4.17** (вместо +$0.14)

## Тести

- `py_compile` ✅ OK
- Існуючі 113 тестів не зачеплені (UNVERIFIED)
- Логіка проста: `max(mid, entry+5¢)` capped at `ask-0.001`

## Архітектура

Зміни в 1 файлі:
- `app/admin/api.py:681-800` — Exit All pricing logic

Усі інші фікси (v1.0.59-N15) — збережені.

## CONFIDENCE: 93%

- Кодова зміна ізольована (1 блок)
- py_compile passes
- Математика перевірена: $4.17 замість $0.14
- UNVERIFIED: PAPER сесія не запущена
- Ризик: якщо mid між bid та ask — target_mid може бути нижче ask, але вищий за bid → limit order чекає заповнення

## Рекомендація

1. Запустити PAPER з v1.0.65
2. Накопичити інвентар (2+ ринки)
3. Виконати Exit All
4. Перевірити: `exit_all_limit_sell_placed` з `target_price` близьким до mid
5. Realized P&L має бути близьким до unrealized (захоплено)
