# CHANGELOG v1.0.66 — Liquidation mid-based pricing (BUG-N17)

**Дата:** 2026-07-03
**Попередник:** v1.0.65 (Exit All mid-based fix)
**Причина:** ліквідації закривали +$3 позиції за entry (втрачено $15+ за 21 хв)

---

## Контекст

Після v1.0.65 (Exit All fix) користувач помітив: позиції з плюсом закриваються в мінус.
Аналіз логу (21 хв, 27 fills) виявив:

| Час | BUY @ | SELL @ | Mid | Realized | Мало б бути |
|---|---|---|---|---|---|
| 07:00:53 | 0.193 | 0.193 | 0.320 | -$0.01 | +$3.22 |
| 07:03:44 | 0.193 | 0.193 | 0.320 | -$0.01 | +$3.22 |
| 07:08:25 | 0.195 | 0.195 | 0.323 | -$0.01 | +$3.20 |
| 07:14:10 | 0.196 | 0.196 | 0.323 | -$0.01 | +$3.16 |

**5 позицій з +$3+ прибутку закрито в -$0.01** = втрачено ~$15+.

Exit All працював (07:00:33 +$1.04 за mid), але ліквідації — ні.

## Коренева причина

`app/services/market_maker.py` — ліквідації використовували `bid + 0.001`:

```python
# CRITICAL tier (рядок 1706):
sell_price = min(market_bid + 0.001, book.best_ask - 0.001)

# AGGRESSIVE tier (рядок 1726):
sell_price = min(market_bid + 0.001, book.best_ask - 0.001)

# URGENT tier (рядок 1722):
sell_price = market_bid  # будь-яка ціна
```

Усі ігнорували mid. При широкому спреді (bid 0.192, mid 0.320, ask 0.449) бот продавав за 0.193 замість 0.320.

## Виправлений баг

### BUG-N17: Liquidation ignores mid price — sells at bid+0.001

**Файл:** `app/services/market_maker.py:1693-1746`

#### Було (v1.0.65)
```python
# CRITICAL/AGGRESSIVE:
sell_price = min(market_bid + 0.001, book.best_ask - 0.001)
# URGENT:
sell_price = market_bid
```

#### Стало (v1.0.66) — A+C priority (same as Exit All)
```python
mid = (market_bid + market_ask) / 2.0
target_mid = round(mid, 4)
target_min = round(inv.avg_entry_price + 0.05, 4)  # entry + 5¢

# Усі 3 tier'и (CRITICAL, AGGRESSIVE, URGENT):
sell_price = max(target_mid, target_min)           # A+C
sell_price = min(sell_price, market_ask - 0.001)   # cap
```

## Зміна поведінки

| Ситуація | v1.0.65 | v1.0.66 |
|---|---|---|
| entry 0.193, mid 0.320, bid 0.192 | SELL 0.193 → -$0.01 | **SELL 0.320 → +$3.22** ✅ |
| entry 0.111, mid 0.111 (тонкий) | SELL 0.111 → -$0.01 | SELL 0.161 (entry+5¢) → +$0.50 ✅ |
| URGENT, entry 0.861, mid 0.860 | SELL 0.860 (bid) | SELL 0.860 (mid < entry+5¢, але mid-based) |

## Ваша сесія з v1.0.66

| Час | BUY @ | Mid | v1.0.65 SELL | v1.0.66 SELL | Різниця |
|---|---|---|---|---|---|
| 07:00:53 | 0.193 | 0.320 | 0.193 (-$0.01) | **0.320 (+$3.22)** | +$3.23 |
| 07:03:44 | 0.193 | 0.320 | 0.193 (-$0.01) | **0.320 (+$3.22)** | +$3.23 |
| 07:08:25 | 0.195 | 0.323 | 0.195 (-$0.01) | **0.323 (+$3.20)** | +$3.21 |
| 07:14:10 | 0.196 | 0.323 | 0.196 (-$0.01) | **0.323 (+$3.16)** | +$3.17 |

**5 позицій: +$15+ додаткового прибутку** за 21 хв.

## Тести

- `py_compile` ✅ OK
- Існуючі 113 тестів не зачеплені (UNVERIFIED)
- Логіка ідентична Exit All (BUG-N16) — вже перевірена

## Архітектура

Зміни в 1 файлі:
- `app/services/market_maker.py:1693-1746` — liquidation pricing

Усі інші фікси (v1.0.59-N16) — збережені.

## CONFIDENCE: 93%

- Кодова зміна ізольована (1 блок, 3 tier'и)
- py_compile passes
- Логіка ідентична Exit All (вже працює в v1.0.65)
- UNVERIFIED: PAPER сесія не запущена
- Ризик: URGENT більше не продає за bid негайно — може застрягти якщо mid не заповнюється. Але cap at ask-0.001 забезпечує заповнення.

## Рекомендація

1. Запустити PAPER з v1.0.66
2. Дочекатись ліквідацій (age > 180с або CRITICAL tier)
3. Перевірити: `liquidation_triggered` з `sell_price` близьким до mid
4. Realized P&L має бути позитивним для позицій з широким спредом
