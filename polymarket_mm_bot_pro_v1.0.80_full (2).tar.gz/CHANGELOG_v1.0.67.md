# CHANGELOG v1.0.67 — PAPER Level 3 stress-test (BUG-N18)

**Дата:** 2026-07-03
**Попередник:** v1.0.66 (liquidation mid-based pricing)
**Причина:** наближення PAPER до реального LIVE — максимально суворі умови

---

## Контекст

Користувач запросив максимально суворі умови PAPER для стрес-тесту:
«чи виживе бот у найгірших умовах?»

ПараметриLevel 3 — worst-case симуляція LIVE: високі rejection, конкуренція, adverse selection, газ.

## Зміна (BUG-N18: PAPER Level 3 stress-test)

**Файли:** `.env`, `.env.example`

### Порівняння параметрів

| Параметр | Було (v1.0.66) | Стало (v1.0.67) | Зміна |
|---|---|---|---|
| `PAPER_REJECTION_RATE` | 0.20 (20%) | **0.55 (55%)** | 2.75x |
| `PAPER_COMPETITION_RATE` | 0.50 (50%) | **0.85 (85%)** | 1.7x |
| `PAPER_FILL_PROB_BASE` | 0.018 (1.8%) | **0.005 (0.5%)** | 3.6x менше |
| `PAPER_FILL_PROB_MAX` | 0.06 (6%) | **0.02 (2%)** | 3x менше |
| `PAPER_ADVERSE_DRIFT_MIN` | 0.008 (0.8%) | **0.025 (2.5%)** | 3.1x |
| `PAPER_ADVERSE_DRIFT_MAX` | 0.020 (2%) | **0.050 (5%)** | 2.5x |
| `PAPER_GAS_COST_USDC` | $0.01 | **$0.04** | 4x |

### Логіка змін

#### Rejection 55%
LIVE: Polymarket API reject'ить частіше через:
- Insufficient balance/allowance
- Stale orders (ціна змінилась)
- Rate limiting
- Network issues

#### Competition 85%
LIVE: Професійні MM (Wintermute, Jane Street, DRW, IMC) забирають fills:
- Низька latency (colocation)
- Більший капітал
- Кращі алгоритми

#### Fill prob 0.5% (base), 2% (max)
LIVE: Maker ордери мають низьку fill prob:
- Активний ринок → ціна рухається, ордер не заповнюється
- Adverse selection: fills лише коли ціна йде проти нас

#### Adverse drift 2.5-5%
LIVE: Informed traders бачать наші quotes:
- Токсичний арбітраж
- Ціна рухається на 2-5% проти ордера
- Fill гарантовано з негативною віддачею

#### Gas $0.04
LIVE: Polygon gas для order signing:
- $0.02-0.05 на 2026 (з config.py коментаря)
- Бот ставить ~1 ордер/сек → газ значний

## Очікуваний ефект

| Метрика | v1.0.66 (було) | v1.0.67 (Level 3) |
|---|---|---|
| Fills за 14 хв | ~30 | **~3-5** (10x менше) |
| Win rate | 100% | **55-70%** |
| Прибуток / 14 хв | +$16.90 | **+$2-4** |
| Прибуток / ніч (7.5 год) | +$907 | **+$100-200** (оцінка) |

## Що перевіряє цей стрес-тест

1. **Чи виживе бот у worst-case?** — якщо +$2-4/14хв → стратегія робитьий
2. **Чи не зольє банкрол?** — якщо банкрол стабільний → risk management працює
3. **Чи працюють фікси v1.0.59-66?** — mid-based ліквідації, vol scaling, Critical tier
4. **Який реальний прибуток?** — наближення до LIVE worst-case

## Тести

- `py_compile` ✅ OK
- Існуючі 113 тестів не зачеплені
- .env зміни не потребують кодових змін

## Архітектура

Зміни в 2 конфіг-файлах:
- `.env` — 7 параметрів оновлено
- `.env.example` — 7 параметрів оновлено

Усі кодові фікси (v1.0.59-N17) — збережені.

## CONFIDENCE: 75%

- Значення Level 3 — оцінка (не VERIFIED)
- Підтверджено GPT-5.5 як реалістичний worst-case
- UNVERIFIED: PAPER сесія не запущена
- Ризик: fills можуть бути занадто рідкісні ($0 прибутку) — але це і є стрес-тест

## Рекомендація

1. Запустити PAPER сесію 6+ годин з v1.0.67
2. Перевірити:
   - Fills count (очікування: 3-5 за 14 хв)
   - Win rate (очікування: 55-70%)
   - Bankroll trajectory (очікування: +$100-200 за ніч)
3. Якщо прибуток >$0 → стратегія життєздатна навіть у worst-case
4. Якщо прибуток -$0 → стратегія потребує доопрацювання перед LIVE

## Як повернутися до Level 1/2

Якщо Level 3 занадто суворий:
```env
# Level 2 (консервативний)
PAPER_REJECTION_RATE=0.45
PAPER_COMPETITION_RATE=0.75
PAPER_FILL_PROB_BASE=0.008
PAPER_FILL_PROB_MAX=0.03
PAPER_ADVERSE_DRIFT_MIN=0.020
PAPER_ADVERSE_DRIFT_MAX=0.040
PAPER_GAS_COST_USDC=0.03

# Level 1 (реалістичний)
PAPER_REJECTION_RATE=0.35
PAPER_COMPETITION_RATE=0.65
PAPER_FILL_PROB_BASE=0.012
PAPER_FILL_PROB_MAX=0.04
PAPER_ADVERSE_DRIFT_MIN=0.015
PAPER_ADVERSE_DRIFT_MAX=0.030
PAPER_GAS_COST_USDC=0.02
```
