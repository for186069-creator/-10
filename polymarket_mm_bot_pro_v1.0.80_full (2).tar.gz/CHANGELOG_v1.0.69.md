# CHANGELOG v1.0.69 — UI: Unrealized P&L окремо (BUG-N20)

**Дата:** 2026-07-03
**Попередник:** v1.0.68 (lower spread thresholds)
**Причина:** UI плутав "profit" ($3.11) з "equity" ($2.32) — різниця в інвентарі

---

## Контекст

Користувач: «пише профіт 3.11 але показуе в еквіті 2.32»

Аналіз виявив: UI показував 2 метрики без пояснення:
- **Total Realized P&L** = сума всіх fills = $3.11
- **Total Equity** = bankroll + inventory = $42.32 + $4.50 = $46.82

Але **bankroll growth** = $42.32 - $40.00 = **$2.32** (це NOT equity).

Користувач плутав "equity" ($2.32) з "profit" ($3.11). Різниця $0.79 = гроші в інвентарі.

## Виправлений баг

### BUG-N20: UI не показує Unrealized P&L окремо

**Файл:** `app/static/index.html`

#### Було (v1.0.68)
9 карток:
- Total Equity (плутано з bankroll growth)
- Bankroll (cash)
- Inventory
- Daily P&L
- Total Realized P&L
- Win Rate, Active Quotes, Fills/Cycles

#### Стало (v1.0.69)
10 карток з чіткими підписами:
- **Total Equity (cash + inv)** ← bankroll + inventory за mid
- **Bankroll (cash)** ← готівка
- **Inventory (at mid)** ← інвентар за поточною ціною
- **Realized P&L (fills)** ← сума всіх fills (колишній "Total Realized P&L")
- **Unrealized P&L (inv)** ← НОВЕ: інвентарний збиток/прибуток за mid
- **Daily P&L (realized)** ← сума fills за день
- Win Rate, Active Quotes, Fills/Cycles

#### JS логіка
```javascript
// v1.0.69 (BUG-N20): Unrealized P&L
const upnl = d.unrealized_pnl_usdc || 0;
const upnlEl = document.getElementById('unrealizedPnl');
upnlEl.textContent = (upnl >= 0 ? '+$' : '-$') + Math.abs(upnl).toFixed(2);
upnlEl.className = 'stat-value ' + (upnl >= 0 ? 'positive' : 'negative');
```

API вже повертає `unrealized_pnl_usdc` (api.py:131) — JS просто не використовував.

## Зміна поведінки

| Метрика | Було | Стало |
|---|---|---|
| "Total Equity" | $46.82 (плутано) | **Total Equity (cash + inv)** $46.82 |
| "Total Realized P&L" | $3.11 | **Realized P&L (fills)** $3.11 |
| — | — | **Unrealized P&L (inv)** +$0.06 (NEW) |
| "Daily P&L" | $3.11 | **Daily P&L (realized)** $3.11 |

Тепер користувач бачить:
- Realized $3.11 (fills)
- Unrealized +$0.06 (інвентар)
- Total Equity $46.82 = bankroll $42.32 + inventory $4.50

## Тести

- HTML-only change, py_compile N/A
- Існуючі 113 тестів не зачеплені

## Архітектура

Зміни в 1 файлі:
- `app/static/index.html` — 1 нова картка + JS логіка + підписи

## CONFIDENCE: 90%

- HTML change мінімальний
- API вже повертає unrealized_pnl_usdc
- UNVERIFIED: не тестував у браузері
- Ризик: grid layout може зламатись з 10 картками (було 9) — але CSS grid адаптивний

## Рекомендація

1. Запустити v1.0.69
2. Перевірити що "Unrealized P&L (inv)" показує значення
3. Тепер Realized + Unrealized = Total Equity growth (зрозуміло)
