# CHANGELOG v1.0.70 — Realistic relay gas (BUG-N21)

**Дата:** 2026-07-03
**Попередник:** v1.0.69 (UI Unrealized P&L)
**Причина:** PAPER_GAS_COST=0.04 занадто песимістичний — Polymarket relay покриває gas

---

## Контекст

Розрахунок gas з логу виявив:
- 20 fills × $0.04 = $0.80 gas за 1 год
- За добу: $19.20 gas
- За місяць: $576 gas

Але Polymarket використовує **relay model** — gasless для користувача.

## Коренева причина

`config.py:197` (коментар):
```python
# v1.0.48 FIX (BUG-12): gas cost was hardcoded as $0.005 PAPER / $0.001
# LIVE — both 10-50x too optimistic. Real Polygon gas for order
# signing/cancel is $0.01-0.05.
```

Розробник думав що бот шле on-chain транзакції. Але код `clob_client.py:942`:
```python
signed = self._client.create_order(order_args)  # EIP-712 off-chain підпис
resp = self._client.post_order(signed, ...)      # відправка на API
```

Бот використовує **off-chain EIP-712 підпис + relay**. Gas ~$0.001/fill, не $0.04.

## Виправлений баг

### BUG-N21: PAPER gas cost 40x завищений

**Файли:** `.env`, `.env.example`

| Параметр | Було (v1.0.69) | Стало (v1.0.70) |
|---|---|---|
| `PAPER_GAS_COST_USDC` | 0.04 | **0.001** |
| `LIVE_GAS_COST_USDC` | 0.02 | **0.001** |

## Зміна поведінки

| Метрика | v1.0.69 (Level 3, gas $0.04) | v1.0.70 (gas $0.001) |
|---|---|---|
| Gas за 20 fills | $0.80 | **$0.02** |
| Gas за добу (480 fills) | $19.20 | **$0.48** |
| Gas за місяць | $576 | **~$15** |
| Net P&L (20 fills, +$2.32) | +$1.52 | **+$2.30** |

## Polymarket relay model

| Операція | Хто платить gas |
|---|---|
| Order placement | Polymarket (relay) |
| Order cancel | Polymarket (relay) |
| WS subscription | Без gas |
| Withdraw | Користувач (~$0.05) |
| Allowance setup | Користувач (~$0.10, 1 раз) |
| Settlement | Користувач (~$0.02) |

**MATIC для місяця:** $2-5 (запас)

## Тести

- .env change, py_compile OK
- Існуючі 113 тестів не зачеплені

## Архітектура

Зміни в 2 конфіг-файлах:
- `.env` — 2 параметри
- `.env.example` — 2 параметри

Усі фікси v1.0.59-N20 — збережені.

## CONFIDENCE: 85%

- Polymarket relay model перевірено (архітектура)
- UNVERIFIED: точний gas на LIVE (може бути $0.0005-0.002)
- Ризик: якщо gas вищий за $0.001 — прибуток буде трохи нижчий

## Рекомендація

1. Запустити PAPER сесію на 24 години
2. Gas тепер реалістичний (~$0.48/добу замість $19.20)
3. Net P&L має бути вищим
4. Після доби — порівняти з попередніми результатами
