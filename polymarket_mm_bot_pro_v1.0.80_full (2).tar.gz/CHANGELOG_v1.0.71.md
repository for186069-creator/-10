# CHANGELOG v1.0.71 — Resolution detector + early pre-resolution exit (BUG-N22)

**Дата:** 2026-07-04
**Попередник:** v1.0.70 (realistic relay gas)
**Причина:** Australia -$3.28 — resolution risk, бот тримав позицію коли ціна впала -94%

---

## Контекст

Сесія 10 годин (v1.0.70): +$19.34 realized, але **-$3.28 unrealized на Australia**.
- Купили 20.44 tokens @ $0.171
- Ціна впала до $0.011 (Australia програє)
- Бот НЕ продав бо: loss 16¢ > ліміт 4¢, ринок замінено (orphaned)

**Ризик:** при повному інвентарі $30 збиток = -$28.

## Виправлення (2 зміни)

### 1. PRE_RESOLUTION_EXIT_SEC: 900 → 3600 (Варіант 3)

**Файли:** `.env`, `.env.example`

```env
PRE_RESOLUTION_EXIT_SEC=3600   # було 900 (15 хв), стане 1 год
```

Бот продає за 1 год до resolution (було 15 хв) — коли ще є ліквідність.

### 2. Resolution detector (Варіант 4, BUG-N22) — НОВА фіча

**Файл:** `app/services/market_maker.py:583-609, 721-775`

#### Логіка
```python
# Якщо mid < 0.05 або mid > 0.95 → ринок майже resolved
if book.mid < 0.05 or book.mid > 0.95:
    if inv.net_tokens > 0.5:
        # Продати негайно (mid-based A+C pricing)
        await self._handle_resolution_exit(token_id, book, market_name)
    else:
        # Просто skip quoting
        return
```

#### _handle_resolution_exit метод
- Використовує **A+C pricing** (same as Exit All / liquidations):
  - `target_mid = mid` (захопити поточну ціну)
  - `target_min = entry + 5¢` (мін прибуток)
  - `sell_price = max(target_mid, target_min)`, capped at `ask - 0.001`
- Лог: `resolution_detector_triggered` + `resolution_exit_sell`

### Різниця від pre_resolution_exit

| Механізм | Тригер | Коли |
|---|---|---|
| `pre_resolution_exit` | time-based | 1 год до end_date |
| `resolution_detector` | price-based | mid < 0.05 або > 0.95 |

Обидва захищають від Australia-сценарію.

## Зміна поведінки

| Ситуація | v1.0.70 | v1.0.71 |
|---|---|---|
| Australia (mid 0.011) | Тримав -$3.28 | **Продав за mid** (збиток менший) ✅ |
| Ринок resolution за 1 год | Продає за 15 хв до | **Продає за 1 год до** ✅ |
| mid < 0.05, нема інвентарю | skip_low_price | skip_near_resolution ✅ |

## Australia сценарій з v1.0.71

```
20:50:09  BUY @ 0.171, mid 0.171
21:00:00  mid впав до 0.045 (< 0.05) → resolution_detector_triggered
21:00:00  SELL @ max(0.045, 0.171+0.05=0.221) capped at ask-0.001
          = sell @ 0.045 (mid, бо 0.221 > ask)
          → збиток (0.171 - 0.045) × 20.44 = -$2.58
          
v1.0.70: -$3.28 (тримав до mid 0.011)
v1.0.71: -$2.58 (продав при mid 0.045)
Економія: $0.70
```

Якщо бот продасть раніше (mid 0.08):
```
SELL @ 0.08 → збиток (0.171 - 0.08) × 20.44 = -$1.86
Економія: $1.42
```

## Тести

- `py_compile` ✅ OK
- Існуючі 113 тестів не зачеплені
- Нова фіча — resolution detector

## Архітектура

Зміни:
- `app/services/market_maker.py:583-609` — resolution detector
- `app/services/market_maker.py:721-775` — _handle_resolution_exit
- `.env` + `.env.example` — PRE_RESOLUTION_EXIT_SEC=3600

Усі фікси v1.0.59-N21 — збережені.

## CONFIDENCE: 90%

- Кодова зміна ізольована
- A+C pricing ідентичний Exit All / liquidations
- UNVERIFIED: PAPER сесія не запущена
- Ризик: resolution detector може спрацювати занадто рано (mid 0.04 → продає, але ціна може відновитись)

## Рекомендація

1. Запустити PAPER сесію з v1.0.71
2. Перевірити: `resolution_detector_triggered` + `resolution_exit_sell` в логу
3. Australia-сценарій: бот продає раніше, збиток менший
4. Інвентар $30 → макс збиток ~$25 замість $28
