# CHANGELOG v1.0.72 — Persistent state crash recovery (BUG-N23)

**Дата:** 2026-07-04
**Попередник:** v1.0.71 (resolution detector)
**Причина:** різке вимкнення ПК → втрата інвентарю/bankroll (в RAM)

---

## Контекст

Користувач: «якщо різко виключиться пк?»

Аналіз виявив:
- **Інвентар в RAM** (не БД) — втрачається при краші
- **Bankroll в RAM** — скидається до .env значення
- **Fills збережені** в `mm_bot.db` (SQLite persistent)

При краші: unrealized P&L втрачено, bankroll скинуто, інвентар = 0.

## Виправлення (BUG-N23: Persistent state for crash recovery)

### 1. Нова таблиця `mm_inventory_state` (models.py)

```python
class InventoryState(Base):
    __tablename__ = "mm_inventory_state"
    id: int = 1  # single row (latest state)
    bankroll: float
    starting_balance: float
    daily_pnl: float
    consecutive_losses: int
    inventories_json: str  # JSON: {token_id: {net_tokens, avg_entry_price, ...}}
    timestamp: datetime
```

### 2. Методи save/load (inventory_manager.py)

```python
async def save_state_to_db(self, db_session):
    # Serialize inventories to JSON, upsert single row
    
async def load_state_from_db(self, db_session) -> bool:
    # Restore bankroll + inventories on startup
    
async def clear_saved_state(self, db_session):
    # Delete on paper_reset
```

### 3. Persistence loop (market_maker.py)

```python
async def _state_persistence_loop(self):
    """Save state every 60s."""
    while self._running:
        await self.inventory.save_state_to_db(db)
        await asyncio.sleep(60)
```

### 4. Load при старті (market_maker.py:159-171)

```python
# v1.0.72: Load inventory state from DB (crash recovery)
async with AsyncSessionLocal() as db:
    restored = await self.inventory.load_state_from_db(db)
    if restored:
        log.info("inventory_state_loaded_on_startup", ...)
```

### 5. Save при shutdown (market_maker.py:207-214)

```python
async def stop(self):
    # v1.0.72: Save state before shutdown
    await self.inventory.save_state_to_db(db)
```

### 6. Clear on paper_reset (api.py:1029)

```python
await _inventory.clear_saved_state(db)
```

## Зміна поведінки

| Ситуація | v1.0.71 | v1.0.72 |
|---|---|---|
| Різке вимкнення ПК | Втрата інвентарю + bankroll | **Відновлення з БД** ✅ |
| Kill -9 | Втрата стану | **Відновлення** ✅ |
| Graceful stop | Втрата стану | **Збереження перед stop** ✅ |
| Paper reset | Скидає RAM | **Скидає RAM + БД** ✅ |

## Що зберігається

| Дані | Збережено? |
|---|---|
| Bankroll | ✅ |
| Starting balance | ✅ |
| Daily P&L | ✅ |
| Consecutive losses | ✅ |
| Інвентар (per market) | ✅ (net_tokens, avg_entry, market_name) |
| Open_time | ❌ (monotonic clock resets) |

## Що НЕ зберігається

- `open_time` (monotonic clock) — позиція не "aged" після рестарту
- `active_quotes` — створюються наново при requote cycle
- `halted` status — бот стартує PAUSED (auto_start_trading=false)

## Тести

- `py_compile` ✅ OK (всі 4 файли)
- Існуючі 113 тестів не зачеплені
- Нова таблиця створюється автоматично (`Base.metadata.create_all`)

## Архітектура

Зміни в 4 файлах:
- `app/db/models.py` — нова таблиця InventoryState
- `app/services/inventory_manager.py` — save/load/clear методи
- `app/services/market_maker.py` — persistence loop + load on start + save on stop
- `app/admin/api.py` — clear_saved_state on paper_reset

Усі фікси v1.0.59-N22 — збережені.

## CONFIDENCE: 88%

- Кодова зміна ізольована
- py_compile passes
- SQLite + SQLAlchemy async — перевірена комбінація
- UNVERIFIED: PAPER сесія з краш-тестом не запущена
- Ризик: якщо DB write fail (disk full) — state не збережеться (logged as warning)

## Рекомендація

1. Запустити PAPER сесію з v1.0.72
2. Зачекати 60с (перший snapshot)
3. Зупинити бота (Ctrl+C або закрити вікно)
4. Запустити знову — перевірити лог:
   - `inventory_state_loaded_on_startup` з bankroll + positions
5. Bankroll + інвентар мають відновитись
