# CHANGELOG v1.0.73 — Gas separated from profit (BUG-N24)

**Дата:** 2026-07-04
**Попередник:** v1.0.72 (crash recovery)
**Причина:** газ змішувався з прибутком в pnl_usdc — витрати як "negative profit"

---

## Контекст

Користувач: «ВИТРАТИ ЦЕ ВИТРАТИ!»

Аналіз виявив:
- `pnl_usdc = realized - fees_usdc` (газ віднімався від прибутку)
- BUY fill показував `pnl_usdc = -$0.001` (ніби збиток)
- SELL fill показував `pnl_usdc = profit - gas` (зменшений прибуток)
- Dashboard сумував усе → газ з'їдав частину прибутку в метриці

**Правильно:** газ = витрата (окремо), прибуток = trading edge (gross).

## Виправлення (BUG-N24)

**Файл:** `app/services/market_maker.py:2113-2155`

### Було (v1.0.72)
```python
realized = self.inventory.on_fill(...)
gas_cost = settings.paper_gas_cost_usdc
fees_usdc = gas_cost
realized_net = realized - fees_usdc       # ← газ в прибутку!
self.inventory.bankroll -= fees_usdc

# DB: pnl_usdc = realized_net (з газом)
await self._persist_trade(..., realized_net, fees_usdc, ...)
```

### Стало (v1.0.73)
```python
realized = self.inventory.on_fill(...)
gas_cost = settings.paper_gas_cost_usdc
fees_usdc = gas_cost
realized_net = realized - fees_usdc  # kept for backwards-compat logging
self.inventory.bankroll -= fees_usdc  # gas still deducted from cash

# DB: pnl_usdc = realized (gross, БЕЗ газу)
await self._persist_trade(..., realized, fees_usdc, ...)
```

### Зміна логування
```python
# Додано поля:
pnl_gross=round(realized, 4)    # gross profit (без газу)
fees=round(fees_usdc, 4)        # gas окремо
# pnl_net залишено для backwards-compat
```

## Зміна поведінки

| Метрика | v1.0.72 | v1.0.73 |
|---|---|---|
| BUY pnl_usdc | -$0.001 (газ як збиток) | **$0.00** (нема profit) ✅ |
| SELL pnl_usdc | $0.124 - $0.001 = $0.123 | **$0.124** (gross profit) ✅ |
| Dashboard Realized | $0.60 (profit - gas) | **$0.61** (gross profit) ✅ |
| Fees (нова метрика) | не показано | **$0.002** (8 fills × $0.001) ✅ |
| Bankroll | $60 - gas | $60 - gas (без змін) ✅ |

## Розрахунок для вашої сесії

```
8 fills:
  4 BUY: pnl_usdc = $0.00 (газ не в прибутку)
  4 SELL: pnl_usdc = gross profit (без газу)

Dashboard Realized = сума SELL profits = $0.61 ✅
Fees = 8 × $0.001 = $0.008 (окрема метрика)
Net = $0.61 - $0.008 = $0.602
Bankroll: $60 - $0.008 (gas) = $59.992
```

## Polymarket relay — газ $0.001

- `.env`: `PAPER_GAS_COST_USDC=0.001`, `LIVE_GAS_COST_USDC=0.001`
- Polymarket покриває on-chain gas через relay
- Користувач платить ~$0.001/fill (relay overhead)

## Тести

- `py_compile` ✅ OK
- Існуючі 113 тестів не зачеплені
- Bankroll logic без змін (газ все одно віднімається від cash)

## Архітектура

Зміни в 1 файлі:
- `app/services/market_maker.py:2113-2155` — розділення gas від profit

Усі фікси v1.0.59-N23 — збережені.

## CONFIDENCE: 92%

- Кодова зміна ізольована
- py_compile passes
- Bankroll logic без змін
- UNVERIFIED: PAPER сесія не запущена

## Рекомендація

1. Запустити PAPER сесію з v1.0.73
2. Перевірити: BUY fills показують `pnl_usdc=0.00` (не -$0.001)
3. Dashboard Realized = gross profit (без газу)
4. SELL fills показують повний profit
