# CHANGELOG v1.0.74 — Save to .env button (BUG-N25)

**Дата:** 2026-07-04
**Попередник:** v1.0.73 (gas separation)
**Причина:** UI зміни не зберігались в .env — втрачались при restart

---

## Контекст

Користувач: «чому ввід данних з панелі не редагуе енв?»

Аналіз виявив:
- UI POST `/api/config` змінює лише RAM (`setattr(settings, key, value)`)
- .env файл не записується
- При restart — RAM скидається до .env значень
- UI зміни (Order Size, Max Inventory, Bankroll) втрачались

## Виправлення (BUG-N25: Save to .env)

### 1. Новий API endpoint `/config/save_env` (api.py:515-605)

```python
@admin_router.post("/config/save_env")
async def save_config_to_env():
    # Зберігає 27 поточних settings з RAM в .env файл
    # Зберігає коментарі та невідомі ключі
    # Додає нові ключі якщо їх нема в .env
```

**Settings що зберігаються (27):**
- PAPER_TRADING, PAPER_BALANCE_USDC
- ORDER_SIZE_USDC, ORDER_SIZE_MIN_USDC, ORDER_SIZE_AUTOSCALE_MAX_MULT
- MAX_INVENTORY_USDC, MAX_INVENTORY_PCT_OF_BANKROLL, INVENTORY_CLEAR_THRESHOLD
- SPREAD_CENTS, SPREAD_MIN_CENTS, SPREAD_MAX_CENTS
- MULTI_LEVEL_ENABLED
- AUTO_PICK_COUNT, AUTO_PICK_MIN_SPREAD_CENTS, AUTO_PICK_MIN_VOLUME_24H
- INVENTORY_LIQUIDATION_AGGRESSIVE_AGE_SEC, INVENTORY_LIQUIDATION_URGENT_AGE_SEC
- PRE_RESOLUTION_EXIT_SEC, STALE_DATA_THRESHOLD_SEC
- PAPER_REJECTION_RATE, PAPER_COMPETITION_RATE
- PAPER_FILL_PROB_BASE, PAPER_FILL_PROB_MAX
- PAPER_ADVERSE_DRIFT_MIN, PAPER_ADVERSE_DRIFT_MAX
- PAPER_GAS_COST_USDC, LIVE_GAS_COST_USDC

### 2. UI кнопка "💾 Save to .env" (index.html:437-444)

```html
<button onclick="saveToEnv()" style="background:var(--green, #22c55e);">
  💾 Save to .env
</button>
```

### 3. JS функція saveToEnv() (index.html:1124-1137)

```javascript
async function saveToEnv() {
  if (!confirm('Save current settings to .env?')) return;
  const r = await fetch(`${API}/config/save_env`, { method: 'POST' });
  toast(`✓ Saved ${d.saved} settings to .env`, 'success');
}
```

## Як працює

1. Змінюєте Order Size / Max Inventory / Bankroll в UI → Applies (RAM)
2. Натискаєте **💾 Save to .env**
3. Бот записує поточні значення в .env файл
4. При restart — значення з .env (не скидаються)

## Зміна поведінки

| Дія | v1.0.73 | v1.0.74 |
|---|---|---|
| UI Apply | RAM only | RAM (без змін) |
| Restart | Скидається до .env | Скидається до .env |
| **Save to .env** | нема | **Зберігає RAM → .env** ✅ |
| Restart після Save | Скидається | **Зберігає значення** ✅ |

## Тести

- `py_compile` ✅ OK
- Існуючі 113 тестів не зачеплені

## Архітектура

Зміни в 2 файлах:
- `app/admin/api.py:515-605` — `/config/save_env` endpoint
- `app/static/index.html:437-444, 1124-1137` — кнопка + JS

## CONFIDENCE: 90%

- Кодова зміна ізольована
- py_compile passes
- .env line-by-line update (зберігає коментарі)
- UNVERIFIED: не тестував запис .env на LIVE

## Рекомендація

1. Запустити v1.0.74
2. Змінити Order Size / Max Inventory / Bankroll в UI
3. Натиснути **💾 Save to .env**
4. Перезапустити бота — перевірити що значення збережені
