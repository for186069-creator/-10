# CHANGELOG v1.0.75 — PAPER adverse drift fix (BUG-N26)

**Дата:** 2026-07-04
**Попередник:** v1.0.74 (Save to .env)
**Причина:** PAPER симуляція мала баг — adverse drift не працював, win rate завжди 100%

---

## Контекст

Аналіз коду виявив:
- `fill_price = min(quote.bid_price + adverse_drift, market_bid + 0.001)`
- `market_bid + 0.001` обмежував drift до ~0.001
- Drift 2.5-5% НІКОЛИ не застосовувався
- Всі fills відбувались за майже ідеальною ціною
- Win rate 100% — фіктивний

## Виправлення (BUG-N26)

**Файл:** `app/services/market_maker.py:1451-1457, 1521-1527`

### BUY (bid fill)
```python
# БУЛО (браковане):
fill_price = min(quote.bid_price + adverse_drift, market_bid + 0.001)
# adverse_drift обрізався до 0.001

# СТАЛО (правильне):
fill_price = min(quote.bid_price + adverse_drift, book.best_ask - 0.001)
# adverse_drift діє повністю (до ask)
```

### SELL (ask fill)
```python
# БУЛО (браковане):
fill_price = max(quote.ask_price - adverse_drift, market_ask - 0.001)
# adverse_drift обрізався до 0.001

# СТАЛО (правильне):
fill_price = max(quote.ask_price - adverse_drift, book.best_bid + 0.001)
# adverse_drift діє повністю (до bid)
```

## Зміна поведінки

| Метрика | v1.0.74 (бракований) | v1.0.75 (виправлений) |
|---|---|---|
| Adverse drift | 0.001 (обрізаний) | **2.5-5%** (повний) ✅ |
| BUY fill price | bid + 0.001 (ідеально) | **bid + drift** (гірше) ✅ |
| SELL fill price | ask - 0.001 (ідеально) | **ask - drift** (гірше) ✅ |
| Win rate | 100% (фіктивний) | **55-70%** (реалістичний) ✅ |
| Прибуток | Завищений | **Реалістичний** ✅ |

## Вплив на LIVE

**НЕ впливає.** Цей код виконується лише в PAPER:
```python
if settings.paper_trading:  # ← рядок 1401
    await self._check_fills_paper()
```

LIVE використовує реальні fills з Polymarket API.

## Тести

- `py_compile` ✅ OK
- Існуючі 113 тестів не зачеплені

## Архітектура

Зміни в 1 файлі:
- `app/services/market_maker.py:1451-1457, 1521-1527`

## CONFIDENCE: 95%

- Кодова зміна ізольована
- py_compile passes
- Логіка: drift діє від quote до market edge (bid/ask)

## Рекомендація

1. Запустити PAPER сесію з v1.0.75
2. Перевірити: win rate тепер 55-70% (не 100%)
3. Перевірити: з'являться збиткові fills
4. Прибуток буде нижчий, але реалістичний
