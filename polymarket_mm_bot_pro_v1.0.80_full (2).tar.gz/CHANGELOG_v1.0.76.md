# CHANGELOG v1.0.76 — Realistic PAPER params based on Polymarket data (BUG-N27)

**Дата:** 2026-07-05
**Попередник:** v1.0.75 (adverse drift fix)
**Причина:** користувач надав реальні дані Polymarket microstructure — параметри скориговано

---

## Контекст

Користувач надав дослідження Polymarket microstructure (Boka et al. 2026, Dubach 2026):
- Top 1% maker share: **84.1%** → competition rate ≈ 84%
- Median adverse selection: **≈0%** (negligible), хвости **0.2-1%**
- Median half-spread: **0.7-2%**
- Median Kyle's λ: **-0.0023** (негативний — ціна рухається ЗА трейдером)
- Унікальних makers на ринок: **<200** (median), нішові: **10-50**

Level 3 мав adverse drift 2.5-5% — завищений у 5-10x порівняно з реальністю.

## Зміни (BUG-N27: Realistic PAPER params)

**Файли:** `.env`, `.env.example`

| Параметр | Level 3 (було) | Реалістичний (стало) | Джерело |
|---|---|---|---|
| `PAPER_COMPETITION_RATE` | 0.85 | **0.84** | Top 1% share = 84.1% |
| `PAPER_FILL_PROB_BASE` | 0.005 | **0.008** | <200 makers, нішеві 10-50 |
| `PAPER_FILL_PROB_MAX` | 0.02 | **0.03** | Реалістичний cap |
| `PAPER_ADVERSE_DRIFT_MIN` | 0.025 (2.5%) | **0.002 (0.2%)** | Median ≈ 0%, хвости 0.2% |
| `PAPER_ADVERSE_DRIFT_MAX` | 0.050 (5%) | **0.010 (1%)** | Хвости до 1% |
| `PAPER_REJECTION_RATE` | 0.55 | **0.55** (без змін) | Нема даних, консервативно |
| `PAPER_BALANCE_USDC` | 10.0 | **60.0** | Для 5-ночного тесту |
| `ORDER_SIZE_USDC` | 5.0 | **10.0** | Більший лот = реалістичніший |
| `MAX_INVENTORY_USDC` | 5.0 | **20.0** | 33% bankroll per market |
| `MAX_INVENTORY_PCT_OF_BANKROLL` | 0.03 | **0.05** | 5% × $60 = $3 floor |
| `MULTI_LEVEL_ENABLED` | true | **false** | 1 рівень = $10 за fill |

## Розрахунок fill prob

```
Level 3: 0.005 × 0.15 × 0.45 = 0.000338 (0.034%)
Realistic: 0.008 × 0.16 × 0.45 = 0.000576 (0.058%)

За 10 год (36000 cycles × 1 quote):
  Level 3: 36000 × 0.034% = 12 fills
  Realistic: 36000 × 0.058% = 21 fills (1.7x більше)
```

## Очікуваний результат за 5 ночей (120 годин)

| Метрика | Level 3 (10 год) | Realistic (120 год) |
|---|---|---|
| Fills | 15 | **250-300** |
| Win rate | 50% | **50-65%** |
| Gross/добу | $16 | **$20-35** |
| Gas/добу | $0.04 | **$0.30** |
| Net/5 ночей | — | **$100-175** |

## Тести

- `py_compile` ✅ OK
- Існуючі 113 тестів не зачеплені

## Архітектура

Зміни в 2 конфіг-файлах:
- `.env` — 10 параметрів оновлено
- `.env.example` — 10 параметрів оновлено

Усі кодові фікси v1.0.59-N26 — збережені.

## CONFIDENCE: 85%

- Параметри на основі реальних даних Polymarket
- UNVERIFIED: PAPER сесія не запущена
- Ризик: adverse drift 0.2-1% може бути занадто низьким для окремих ринків

## Рекомендація

1. Запустити PAPER сесію з v1.0.76 на 5 ночей
2. Банкрол $60, ORDER_SIZE $10
3. Очікуваний прибуток: $100-175 за 5 ночей
4. Після 5 ночей — аналіз результатів
5. Якщо стабільний +P&L → LIVE smoke test
