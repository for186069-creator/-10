# CHANGELOG v1.0.78 — Compromise market selection (BUG-N29)

**Дата:** 2026-07-05
**Попередник:** v1.0.77 (4 зміни market quality)
**Причина:** 3 ринки замало для роботи бота — потрібен компроміс

---

## Контекст

v1.0.77 виключив sports + politics → залишилось 3 AI/Tech ринки. Це замало для реальної торгівлі.

Перевірка Polymarket API показала:
- Усього 16 ринків (spread≥2¢, vol≥$10k, liq≥$5k)
- Якщо виключити sports+politics → 3 ринки (замало)
- Компроміс: виключити тільки esports+crypto+weather+social → **8 ринків** ✅

## 3 зміни (BUG-N29)

### 1. Пом'якшений exclude list

**Файл:** `app/core/config.py:74-90`

**Видалено з exclude:** cup, championship, match, game, score, election, vote, president, senate, governor, congress, parliament, cabinet, primary, Round of 16, Semifinal, Quarterfinal, elimination, advance, reach the, capture, win the

**Додано до exclude:** msi, bilibili, hanwha, t1, gen.g, dwg, skt, faze, navi, team liquid (esports tournaments)

**Залишено в exclude:** crypto, esports (повний), weather, social

### 2. Ліквідність $5k → $10k

**Файл:** `app/services/clob_client.py:545`

```python
if liquidity < 10000:  # було 5000
```

### 3. Resolution 1 год → 6 год

**Файл:** `.env`

```env
PRE_RESOLUTION_EXIT_SEC=21600  # було 3600 (1 год), стане 6 год
```

## Ринки що залишаться (8 кандидатів)

| # | Ринок | Спред | Об'єм | Ліквідність | Безпека |
|---|---|---|---|---|---|
| 1 | FC Seoul win | 2.0¢ | $111k | $19k | ⚠️ Sports |
| 2 | GPT-5.6 July 8 | 3.0¢ | $32k | $12k | ✅ AI/Tech |
| 3 | Portugal vs Spain O/U | 2.0¢ | $18k | $101k | ⚠️ Sports |
| 4 | Argentina Semifinals | 2.0¢ | $16k | $112k | ⚠️ Sports |
| 5 | GPT-5.6 July 10 | 2.0¢ | $15k | $11k | ✅ AI/Tech |
| 6 | Brazil vs Norway Corners | 3.0¢ | $13k | $51k | ⚠️ Sports |
| 7 | Naftali Bennett PM | 2.0¢ | $12k | $88k | ⚠️ Politics |
| 8 | USA Quarterfinals | 2.0¢ | $11k | $176k | ⚠️ Sports |

**Захист від resolution risk:**
- v1.0.71 resolution detector (mid < 0.05 → sell)
- v1.0.78 pre-resolution exit (6 год до resolution → sell)

## Тести

- `py_compile` ✅ OK
- Існуючі 113 тестів не зачеплені

## CONFIDENCE: 85%

- 8 ринків достатньо для роботи
- Resolution detector + 6 год exit захищають від sports/politics risk
- UNVERIFIED: PAPER сесія не запущена
