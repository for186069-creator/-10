# CHANGELOG v1.0.79 — Order lifecycle metrics logger (handoff implementation)

**Дата:** 2026-07-05
**Попередник:** v1.0.78 (compromise market selection)
**Причина:** реалізація хендоффу "Polymarket LIVE Limit Order Metrics Logger" — інструментація шляху подачі ордерів для вимірювання rejection rate та time-to-fill.

---

## Контекст

Хендофф (від Claude → GLM 5.2) вимагає інструментувати (не змінюючи стратегію) 4 точки життєвого циклу ордера:
- (a) pre-submit — генерувати `client_order_ref`, вставити рядок
- (b) submit — перед `POST /order`
- (c) on_response — після відповіді API
- (d) fill/cancel — через poller (user-WS відсутній)

Цільові метрики: **rejection rate** та **time-to-fill percentiles**.

## Деліверабли (3 нових файли + 3 нові settings)

### 1. `app/db/order_metrics_db.py` (новий)
Тонкий SQLite-шар через `aiosqlite`. Окрема БД (`order_metrics.db`), ізольована від `mm_bot.db`. Схема з хендоффу (§3) + одне розширення:
- **`mode` column** (`'LIVE' | 'PAPER'`) — PAPER-рядки забруднювали б percentile-метрики (завжди MATCHED, ~0ms), тож колонка дозволяє репорту фільтрувати лише LIVE.

Helpers: `init_metrics_db()`, `insert_order_event()`, `update_order_event()`, `fetch_unresolved_orders()`, `fetch_all_for_report()`, `store_raw_response()`, `close_metrics_db()`.

### 2. `app/services/order_logger.py` (новий)
`OrderLogger` клас з 4 хуками + фоновий poller. Singleton `order_logger`.

- `pre_submit()` — генерує uuid4, класифікує `market_category` за keywords, обчислює `is_marketable` через `book.best_bid/best_ask`.
- `submit()` — записує `submitted_at`.
- `on_response()` — обчислює `ack_latency_ms`, визначає `final_status`:
  - `success + FILLED/MATCHED` → `filled` (миттєво, poller не потрібен)
  - `success + LIVE/PARTIALLY_FILLED` → `final_status=NULL` (poller доспіватиме)
  - `PolyApiException` → `rejected` / `api_reject`
  - інший Exception → `unknown_transport_error` / `timeout`
- `record_pre_submit_reject()` — для відхилень до API-виклику (tick/size/price validation).
- `fill_poll_loop()` — полл `get_open_orders()` + best-effort `get_trades()`.

### 3. `scripts/metrics_report.py` (новий)
CLI-репорт: rejection rate (за category × stage), fill-time p50/p90/p99 (за category × is_marketable), side stats (auto_cancel, transport_error, retry overhead). Flag `LOW SAMPLE` при n<30.

### 4. Інструментація `app/services/clob_client.py`
`place_order()` інструментовано всередені (backward-compat — сигнатура не змінилася, жоден з 9 call-sites не зачеплено). Усі хуки обгорнуті `try/except` — збій логера не ламає подачу ордерів.

### 5. `app/core/config.py` — 3 нові settings
```python
metrics_db_path: str = "./order_metrics.db"
metrics_log_raw_response: bool = False
metrics_fill_poll_interval_sec: float = 5.0
```

### 6. `app/main.py` — lifecycle
- `lifespan` startup: `init_metrics_db()` + `order_logger.start_poller(clob)` (LIVE only)
- `lifespan` shutdown: `order_logger.stop_poller()` + `close_metrics_db()`

### 7. `.env` + `.env.example` + `requirements.txt`
- Додано 3 змінні оточення.
- Додано `numpy>=1.26,<3.0` для percentile-розрахунку.

---

## Документовані обмеження (truth-first)

1. **`retry_count` / `total_retry_wait_ms` завжди 0.**
   Бот не має retry-wrapper-а (v1.0.49 прибрав мертвий `@retry`). Додавання — поза межами "instrumentation only". Поля залишені для майбутнього.

2. **`seconds_to_game_start` завжди None.**
   Бот не читає `game_start_time` з Gamma (UNVERIFIED — поле може існувати, але ім'я невідоме). Без нього неможливо реалізувати детектор `auto_cancel_game_start` (§4d "within ~1s of game start"). Усі cancels логуються як `cancelled`. TODO для v1.0.80+.

3. **`market_category = 'sports_live'` означає "sports market (pre-match OR in-play)".**
   Без `game_start_time` неможливо розрізнити pre-match vs in-play.

4. **`crypto_updown` частково unreachable.**
   Crypto-ринки виключені конфігом (`auto_pick_exclude_keywords`) з v1.0.44. Категорія залишена для сумісності зі схемою хендоффу.

5. **Fill-detection через `get_trades()` — UNVERIFIED.**
   Сигнатура `py_clob_client.clob_types.TradesRequest` не перевірялася проти встановленої версії. Код має fallback на `get_trades()` без параметрів + try/except. Якщо обидва варіанти не працюють — order логується як `cancelled` (консервативно).

6. **Acceptance check (§6) — PAPER не вимірює нічого корисного.**
   PAPER завжди повертає MATCHED з ~0ms latency. Репорт фільтрує за `mode='LIVE'`. Приймальний тест мусить бути LIVE smoke, а не paper (як просить хендофф §6).

---

## Тести

- `py_compile` ✅ OK для всіх 6 змінених/нових файлів.
- Існуючі 113 тестів не зачеплені (сигнатура `place_order()` незмінна, хуки best-effort).
- UNVERIFIED: PAPER/LIVE сесія не запущена.
- UNVERIFIED: `metrics_report.py` не запускався на реальній БД.

## Архітектура

Зміни у 6 файлах + 3 нових:
- `app/db/order_metrics_db.py` (новий, 130 рядків)
- `app/services/order_logger.py` (новий, 290 рядків)
- `scripts/metrics_report.py` (новий, 175 рядків)
- `app/services/clob_client.py` (інструментація `place_order()`, ~120 рядків хуків)
- `app/core/config.py` (+3 settings)
- `app/main.py` (lifecycle: init + start/stop poller + close DB)
- `.env` + `.env.example` (+3 змінні)
- `requirements.txt` (+numpy)

## CONFIDENCE: 82%

- Код компілюється (py_compile OK).
- Хуки best-effort — не ламають trading.
- UNVERIFIED: py-clob-client `get_trades`/`TradesRequest` API shape.
- UNVERIFIED: PAPER/LIVE сесія не запущена.
- Ризик: `TradesRequest` fallback може не спрацювати → fills логуються як `cancelled` (консервативно, не критично).

## Рекомендація

1. Запустити PAPER сесію — перевірити, що `order_metrics.db` створюється, рядки вставляються (mode=PAPER).
2. Репорт `python scripts/metrics_report.py --mode PAPER` — має показати 100% fill, 0% reject (підтверджує, що логер працює).
3. LIVE smoke test ($5, 1 ринок) — перевірити rejection rate та fill-time на реальних даних.
4. Репорт `python scripts/metrics_report.py --mode LIVE` — очікувані метрики після 2-3 днів LIVE.
