# CHANGELOG v1.0.80 — paper_health.py щоденний snapshot

**Дата:** 2026-07-05
**Попередник:** v1.0.79 (order metrics logger)
**Причина:** 7-денний PAPER-тест до 12 липня — потрібен швидкий щоденний health-check без ручного grep-у логу.

---

## Контекст

v1.0.79 додала логер, але під час тривалого PAPER-тесту (7+ днів) користувачеві треба
щодня відповідати на 3 питання:
1. Чи живий бот (не завис)?
2. Чи росте bankroll, чи падає?
3. Чи немає критичних warnings/errors?

Без скрипта — це ручний `tail bot.log` + `sqlite3` запити. v1.0.80 додає один CLI-скрипт.

## 1 зміна

### 1. `scripts/paper_health.py` (новий, ~330 рядків)

Щоденний health snapshot. Три джерела даних:
- `mm_bot.db` → `mm_inventory_state` (bankroll, daily_pnl), `mm_trades` (fills, P&L, top markets)
- `order_metrics.db` → `order_events` (count, by mode/status/category, pre_submit rejects)
- `bot.log` → ws_disconnects, warnings, errors, остання активність, top events

**Три режими виводу:**
- **Compact (за замовч.)** — один рядок: `bank=$X daily=$Y total=$Z | fills:N/M | order_events=K | ws_disc=W warn=E err=R`
- **Verbose (-v)** — багаторядковий звіт з усіма деталями
- **JSON (--json)** — для cron/моніторингу

**Stale-детекція:** якщо `quote_placed` не було > 300с → прапор `⚠STALE` + exit code 1.

**Exit codes:** 0=OK, 1=STALE, 2=ERROR, 3=UNKNOWN — підходить для cron-алертів.

## Тести

- `py_compile` ✅ OK
- E2E на реальному `bot.log` (2567 рядків, PAPER-сесія v1.0.79) ✅:
  - bank=$61.22, daily=$+1.22, fills=2/2, order_events=1363, ws_disc=1, warn=6, err=0
  - STALE-детекція спрацювала (лог завершився 17 хв тому > поріг 5 хв)
  - top events: 1361 quote_placed, 501 level_size_bumped, 467 vol_scaled
  - pre_submit_validation rejects: 2
- Edge-case (відсутні БД + лог) — не падає, повертає OK з `?` ✅

## Не зачеплено

- Жодного існуючого файлу не змінено.
- 113 тестів не зачеплено (новий standalone скрипт).
- v1.0.79 логер не змінено.

## CONFIDENCE: 92%

- Скрипт синтаксично OK, протестовано на реальному логу.
- UNVERIFIED: не тестувалося на 7-денному логу (нема такого логу).
- UNVERIFIED: sqlite3 read-only mode через `file:...?mode=ro` — стандартний URI, має працювати на Python 3.11+.

## Рекомендація

Запускати щодня о 09:00 (cron):
```bash
0 9 * * * cd /path/to/bot && python scripts/paper_health.py --log bot.log >> paper_health.log 2>&1
# або з алертом при STALE:
0 9 * * * cd /path/to/bot && python scripts/paper_health.py --log bot.log || \
  echo "BOT STALE/ERROR" | mail -s "MM Bot alert" you@example.com
```
