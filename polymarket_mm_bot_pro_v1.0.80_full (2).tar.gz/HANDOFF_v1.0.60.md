# HANDOFF: Polymarket MM Bot Pro v1.0.60

**Дата:** 2026-07-02
**Версія:** v1.0.60
**Попередник:** v1.0.59 (auto-refill throttle fix)
**Стан:** ✅ BUG-N10 виправлено, готовий до PAPER сесії

---

## 1. Що нового в v1.0.60

### Контекст
Після релізу v1.0.59 користувач надав `bot.log` з 94-хвилинної PAPER сесії.
Аналіз логу (23 890 рядків) виявив:

| Метрика | Значення |
|---|---|
| `market_skip_tight_spread` | **22 724** подій |
| Унікальних ринків skip'нуто | 8 (усі зі спредом 1.0¢) |
| Quotable ринків (максимум) | 2 (Will Apple Yes/No) |
| Спроб додати ринки вручну (5 разів) | усі `markets_add_no_new` |

**Симптом:** бот додавав «сміттєві» ринки (спред 1.0¢) через fallback
discovery, але ніколи їх не котирував (22 724 skip-події).

### Виправлений баг (1 шт)

#### BUG-N10: discovery fallback hardcoded 0.8¢ spread threshold

**Коренева причина:**
- `app/services/clob_client.py:597` — `relaxed = 0.008` (0.8¢) HARDCODED
- Fallback приймав ринки зі спредом 0.8–2.4¢
- Але при котируванні поріг `SPREAD_MIN_CENTS` = 2.0–2.5¢
- Будь-який ринок 0.8–2.4¢: проходить discovery → fail quoting → skip

**Фікс (1 файл):**
1. `app/services/clob_client.py` (рядки 594-610):
   - Замінено `relaxed = 0.008` на `relaxed = settings.spread_min_cents / 100.0`
   - Оновлено коментар та `log.warning` для консистентності
   - Будь-який ринок, знайдений через fallback, тепер гарантовано quotable

**Тести:**
- Нові тести НЕ додані (правило: без симуляцій, без test-коду)
- Існуючі 113 тестів не зачеплені (0 збігів `relaxed`/`fallback` у `tests/`)
- `python3 -m py_compile` — ✅ OK

**Regression UNVERIFIED:** повернення старого `0.008` → очікувано не зламає
тести (нічого їх не тестує), але відновить «сміттєві» ринки.

### Поведінка, що змінилась

| Ситуація | v1.0.59 (було) | v1.0.60 (стало) |
|---|---|---|
| Primary знайшов 0, є ринки 0.8–2.4¢ | Додає → skip при quoting | Повертає 0 — без сміття |
| Primary знайшов 0, є ринки 2.0–2.4¢ | Додає → skip (якщо min=2.5) | Додає → quotable ✅ |
| Primary знайшов ≥1 | Fallback не пускається | Без змін |

**Ключова зміна:** бот більше не додає ринки, які гарантовано не торгуватимуть.

---

## 2. Історія версій (v1.0.45 → v1.0.60)

| Версія | Фіксів | Що зроблено |
|---|---|---|
| v1.0.46 | 9 | 4 CRITICAL + 3 HIGH + 2 MEDIUM (повний аудит коду) |
| v1.0.47 | 3 | Статус-стрінги Polymarket API (PARTIALLY_FILLED) |
| v1.0.48 | 4 | MEDIUM: gas cost, order_size_min, stale book, continue bug |
| v1.0.49 | 6 | LOW: SQL aggregates, WS reconnect, retry decorator, fetch logs, emergency count, task errors |
| v1.0.50 | 8 | Cosmetic + by design |
| v1.0.51 | 1 | BUG-32: winrate threshold 0.01→0.05 |
| v1.0.53 | 3 | BUG-33 (replace orphans), BUG-34 (log file), BUG-35 (start PAUSED) |
| v1.0.54 | 2 | UI cleanup, optimized .env |
| v1.0.56 | 3 | Bankroll/OrderSize/MaxInv: sliders → input + Apply |
| v1.0.57 | 4 | Усі слайдери → input + Apply |
| v1.0.58 | 7 | Verification fixes (6 fixed + 1 false positive) |
| v1.0.59 | 1 | BUG-N9: auto-refill throttle 30s → 300s |
| **v1.0.60** | **1** | **BUG-N10: discovery fallback 0.8¢ → spread_min_cents** |

**Всього виправлено: 52+ багів/покращень**

---

## 3. Поточний стан

### Тести
```
$ pytest tests/ --no-cov -q
113 passed in 3.93s   (v1.0.59 result — UNVERIFIED for v1.0.60 in sandbox)
```
**UNVERIFIED** для v1.0.60: pytest не запущено в sandbox (немає Python-залежностей).
Користувач має запустити локально. Очікування: 113/113 pass (змінений код не
покривається тестами).

### Консистентність версії
- `VERSION`: 1.0.60 ✅
- `pyproject.toml`: 1.0.60 ✅
- `README.md`: v1.0.60 ✅
- `CHANGELOG_v1.0.60.md`: ✅ (new)
- `HANDOFF_v1.0.60.md`: ✅ (new, цей файл)
- Порти: 8765 скрізь ✅ (без змін з v1.0.58)

### Що НЕ змінено (за вимогою користувача)
| Параметр | Стан |
|---|---|
| `spread_min_cents` | 2.5¢ (НЕ знижено до 1.0¢ — збитки) |
| `hedging_enabled` | True (НЕ зачеплено) |
| `multi_level_enabled` | True (НЕ зачеплено) |
| `auto_pick_keywords` | не розширено (окреме рішення) |
| `our_ask=None` logic | Залишено (правильна поведінка, не баг) |

---

## 4. Архітектура (зміна в 1 файлі)

```
polymarket_mm_bot_pro/
├── app/
│   └── services/
│       └── clob_client.py  # v1.0.60: BUG-N10 fix (рядки 594-610)
├── VERSION                  # v1.0.60
├── pyproject.toml           # v1.0.60
├── README.md                # v1.0.60
├── CHANGELOG_v1.0.60.md     # NEW
└── HANDOFF_v1.0.60.md       # NEW (цей файл)
```

Усі інші файли — без змін з v1.0.59.

---

## 5. Ключова зміна: discovery fallback spread

### Before (v1.0.59)
```python
# clob_client.py:594-597
# Fallback: relax spread threshold to 0.8¢
if not result:
    log.warning("markets_discovery_fallback", relaxed_spread_cents=0.8)
    relaxed = 0.008   # ← HARDCODED 0.8¢
```
- Приймав ринки зі спредом 0.8–2.4¢
- Усі вони fail `market_skip_tight_spread` (поріг 2.0–2.5¢)
- 22 724 skip-події за 94 хв — марна трата CPU/WS

### After (v1.0.60)
```python
# clob_client.py:594-610
# Fallback: relax spread threshold to settings.spread_min_cents.
if not result:
    log.warning(
        "markets_discovery_fallback",
        relaxed_spread_cents=settings.spread_min_cents,
    )
    relaxed = settings.spread_min_cents / 100.0
```
- Приймає ринки зі спредом ≥ `spread_min_cents` (типово 2.5¢)
- Будь-який знайдений ринок гарантовано quotable
- Fallback корисний лише у вузькому вікні [spread_min_cents, auto_pick_min_spread_cents)

### Log event (змінено)
```
# Було:
[warning] markets_discovery_fallback  relaxed_spread_cents=0.8

# Стало:
[warning] markets_discovery_fallback  relaxed_spread_cents=2.5
```
(значення залежить від `SPREAD_MIN_CENTS` у .env)

---

## 6. Рекомендація для наступної PAPER сесії

1. Розпакувати `polymarket_mm_bot_pro_v1.0.60.tar.gz`
2. Запустити `pytest tests/ --no-cov -q` локально — очікування 113/113 pass
3. Запустити бота з v1.0.60
4. Ринок має бути PAUSED на старті (`AUTO_START_TRADING=false`)
5. Click "Start Trading"
6. Спостерігай лог:
   - `markets_discovery_fallback` (якщо буде) — перевірити що
     `relaxed_spread_cents=2.5` (або значення з вашого .env), а НЕ 0.8
   - `market_skip_tight_spread` для fallback-доданих ринків має зникнути
7. Якщо quotable залишається ≤ 2 — це нормально, бот просто не знайшов
   більше ринків зі спредом ≥2.5¢ на Polymarket. Не churning, не баг.
8. Для отримання >2 quotable ринків — розширити `AUTO_PICK_KEYWORDS` у .env
   (рекомендація Рівня 1A зі звіту аналізу)
9. Exit All для виводу коштів як зазвичай

---

## 7. Чесний підсумок

| Питання | Відповідь |
|---|---|
| Чи виправлено BUG-N10? | ✅ Так (0.008 → settings.spread_min_cents/100.0) |
| Чи our_ask=None це баг? | ❌ Ні (правильна поведінка Polymarket CTF) |
| Чи зачеплено хедж? | ❌ Ні (за вимогою) |
| Чи зачеплено мультілевел? | ❌ Ні (за вимогою) |
| Чи знижено spread до 1.0¢? | ❌ Ні (за вимогою — збитки) |
| Чи 100% тести pass? | ⚠️ UNVERIFIED (pytest не запущено в sandbox; очікування 113/113) |
| Чи можна заливати $1000? | ❌ Ні. Спочатку smoke LIVE на $5 |

**Головне досягнення v1.0.60:**
1. BUG-N10 root cause знайдено з живого логу (94 хв, 23 890 рядків)
2. Фікс мінімальний (1 рядок логіки + коментар/log для консистентності)
3. `py_compile` passes, 0 конфліктів з існуючими тестами
4. Хедж, мультілевел, spread_min, keywords — не зачеплені
5. Бот більше не додаватиме «сміттєві» ринки (спред 0.8–2.4¢)

**Наступний крок:** розпакувати v1.0.60, запустити `pytest tests/`,
потім PAPER сесію — перевірити що `market_skip_tight_spread` для
fallback-доданих ринків зник.

---

## 8. Що НЕ вирішує v1.0.60

Виправлення BUG-N10 усуває «сміттєві» ринки, але НЕ збільшує кількість
quotable ринків на Polymarket. Якщо на Polymarket лише 1 ринок зі спредом
≥2.5¢ (Will Apple), бот матиме 2 quotable токени (Yes+No) незалежно від
`AUTO_PICK_COUNT`.

Для отримання >2 quotable ринків — паралельні дії:
1. Розширити `AUTO_PICK_KEYWORDS` (найбезпечніше)
2. Знизити `AUTO_PICK_MIN_VOLUME_24H=5000` (помірно ризиковано)
3. Встановити `AUTO_PICK_MIN_SPREAD_CENTS=2.0` + `SPREAD_MIN_CENTS=2.0`
4. Manual `MARKET_TOKEN_IDS=...` + `AUTO_PICK_MARKETS=false` (повний контроль)

---

**Автор:** Z.ai Code (truth-first engineering assistant)
**Дата handoff:** 2026-07-02
**CONFIDENCE:** 88% — BUG-N10 fixed + py_compile OK + PAPER/LIVE UNVERIFIED
