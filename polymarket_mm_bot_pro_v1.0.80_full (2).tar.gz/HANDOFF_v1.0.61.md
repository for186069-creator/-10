# HANDOFF: Polymarket MM Bot Pro v1.0.61

**Дата:** 2026-07-02
**Версія:** v1.0.61
**Попередник:** v1.0.60 (discovery fallback fix)
**Стан:** ✅ BUG-N11 виправлено, UI ліміти піднято

---

## 1. Що нового в v1.0.61

### Контекст
Після v1.0.60 користувач виявив що в UI панелі не можна встановити:
- Order size > $50 (HTML `max="50"`)
- Max inventory > $100 (HTML `max="100"`)

При цьому API та config.py не мали верхніх лімітів — браузер блокував значення, які бекенд прийняв би.

### Виправлений баг (1 шт)

#### BUG-N11: HTML input max attributes blocked large values

**Коренева причина:**
- `app/static/index.html` мав жорсткі `max` атрибути на 4 `<input>` полях
- API `validation_rules` (api.py:454-466) не мав верхніх лімітів
- config.py Field не мав верхніх лімітів (`gt=0` only)
- Невідповідність: HTML блокував те, що бекенд прийняв би

**Фікс (1 файл, 4 атрибути):**

| Поле | Було | Стало |
|---|---|---|
| `orderSize` | `max="50"` | `max="1000"` |
| `maxInv` | `max="100"` | `max="10000"` |
| `bankrollInput` | `max="1000"` | `max="100000"` |
| `marketsCountSlider` | `max="20"` | `max="50"` |

**Тести:**
- Без змін (UI не покривається unit-тестами)
- 113 тестів не зачеплені (HTML-only change)
- `py_compile` N/A (HTML файл)

### Поведінка, що змінилась

| Дія | v1.0.60 (було) | v1.0.61 (стало) |
|---|---|---|
| Order size $80 | ❌ браузер блокує | ✅ приймається |
| Max inventory $500 | ❌ браузер блокує | ✅ приймається |
| Bankroll $5000 | ❌ браузер блокує | ✅ приймається |
| Markets count 30 | ❌ браузер блокує | ✅ приймається |

---

## 2. Історія версій (v1.0.45 → v1.0.61)

| Версія | Фіксів | Що зроблено |
|---|---|---|
| v1.0.46 | 9 | 4 CRITICAL + 3 HIGH + 2 MEDIUM |
| v1.0.47 | 3 | Статус-стрінги Polymarket API |
| v1.0.48 | 4 | MEDIUM: gas, order_size_min, stale book, continue bug |
| v1.0.49 | 6 | LOW: SQL, WS reconnect, retry, logs, emergency, tasks |
| v1.0.50 | 8 | Cosmetic + by design |
| v1.0.51 | 1 | BUG-32: winrate threshold |
| v1.0.53 | 3 | BUG-33/34/35: orphans, log file, start PAUSED |
| v1.0.54 | 2 | UI cleanup, optimized .env |
| v1.0.56 | 3 | Sliders → input + Apply |
| v1.0.57 | 4 | Усі слайдери → input + Apply |
| v1.0.58 | 7 | Verification fixes |
| v1.0.59 | 1 | BUG-N9: auto-refill throttle 30s → 300s |
| v1.0.60 | 1 | BUG-N10: discovery fallback 0.8¢ → spread_min_cents |
| **v1.0.61** | **1** | **BUG-N11: UI input max limits raised** |

**Всього: 53+ багів/покращень**

---

## 3. Поточний стан

### Тести
```
$ pytest tests/ --no-cov -q
113 passed   (UNVERIFIED for v1.0.61 — HTML-only change, no Python affected)
```

### Консистентність
- `VERSION`: 1.0.61 ✅
- `pyproject.toml`: 1.0.61 ✅
- `README.md`: v1.0.61 ✅
- `CHANGELOG_v1.0.61.md`: ✅
- `HANDOFF_v1.0.61.md`: ✅ (цей файл)
- BUG-N10 fix (v1.0.60) — збережено ✅
- BUG-N9 fix (v1.0.59) — збережено ✅

### Що НЕ змінено
| Параметр | Стан |
|---|---|
| `spread` max=10 | Розумний для MM |
| `minSpread` max=5 | Розумний |
| `asGamma` max=1.0 | UI консервативний |
| `max_inventory_usdc` семантика | Floor, не ceiling (див. CHANGELOG) |
| Всі бекенд-валідації | Без змін |

---

## 4. Архітектура (зміна в 1 файлі)

```
polymarket_mm_bot_pro/
├── app/
│   ├── services/
│   │   └── clob_client.py    # v1.0.60: BUG-N10 fix (збережено)
│   └── static/
│       └── index.html        # v1.0.61: BUG-N11 fix (4 input max)
├── VERSION                    # v1.0.61
├── pyproject.toml             # v1.0.61
├── README.md                  # v1.0.61
├── CHANGELOG_v1.0.61.md       # NEW
└── HANDOFF_v1.0.61.md         # NEW (цей файл)
```

---

## 5. Рекомендація для користувача

### Щоб бот купував на $500-800 при депозиті $1000

Тепер UI дозволяє встановити потрібні значення. В панелі бота:

1. **Order size:** введіть `$80` (раніше блокувало на $50)
2. **Max inventory:** введіть `$500` (раніше блокувало на $100)
3. **Bankroll:** введіть `$1000` (раніше блокувало на $1000 — тепер до $100000)

Або через `.env` (повний набір для купівлі $500-800):
```env
ORDER_SIZE_USDC=80.0
MAX_INVENTORY_USDC=500.0
MAX_INVENTORY_PCT_OF_BANKROLL=0.80
MULTI_LEVEL_ENABLED=false
INVENTORY_LIQUIDATION_AGGRESSIVE_AGE_SEC=1800.0
INVENTORY_LIQUIDATION_URGENT_AGE_SEC=3600.0
```

### Важливо про `max_inventory_usdc`

Це **FLOOR** (мінімум), не CEILING. Код:
```python
return max(settings.max_inventory_usdc, self.bankroll * settings.max_inventory_pct_of_bankroll)
```
- `max_inv=$500, pct=0.80, bankroll=$1000` → `max($500, $800) = $800` ✅
- `max_inv=$60, pct=0.50, bankroll=$1000` → `max($60, $500) = $500` (не $60!)
- Для реального ліміту $60: `MAX_INVENTORY_PCT_OF_BANKROLL=0.06`

---

## 6. Чесний підсумок

| Питання | Відповідь |
|---|---|
| Чи виправлено BUG-N11? | ✅ Так (4 HTML max піднято) |
| Чи зачеплено Python? | ❌ Ні (тільки HTML) |
| Чи 113 тестів pass? | ⚠️ UNVERIFIED (HTML-only, очікування 113/113) |
| Чи можна ввести $80 order? | ✅ Так (max=1000) |
| Чи можна ввести $500 inventory? | ✅ Так (max=10000) |
| Чи можна заливати $1000 LIVE? | ❌ Ні. Спочатку PAPER 6+ годин, потім smoke LIVE $5 |

**Головне досягнення v1.0.61:**
1. UI більше не блокує великі значення
2. Бекенд-валідація без змін (вже приймала ці значення)
3. Збережено всі попередні фікси (BUG-N9, BUG-N10)
4. 1 файл змінено, 4 атрибути

---

**Автор:** Z.ai Code (truth-first engineering assistant)
**Дата handoff:** 2026-07-02
**CONFIDENCE:** 95% — BUG-N11 fixed + HTML-only change + PAPER/LIVE UNVERIFIED
