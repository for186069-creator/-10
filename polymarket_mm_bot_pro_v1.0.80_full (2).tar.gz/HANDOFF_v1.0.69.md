# HANDOFF: Polymarket MM Bot Pro v1.0.69

**Дата:** 2026-07-03
**Версія:** v1.0.69
**Попередник:** v1.0.68 (lower spread thresholds)
**Стан:** ✅ UI показує Unrealized P&L окремо

---

## 1. Що нового в v1.0.69

### Контекст
Користувач плутав "profit" ($3.11) з "equity" ($2.32). Різниця $0.79 = гроші в інвентарі.

### Виправлений баг (BUG-N20)

**Файл:** `app/static/index.html`

Додано нову картку **"Unrealized P&L (inv)"** — показує збиток/прибуток інвентарю за mid.

### Зміна UI

| Метрика | Було | Стало |
|---|---|---|
| Total Equity | плутано | **Total Equity (cash + inv)** |
| Total Realized P&L | $3.11 | **Realized P&L (fills)** $3.11 |
| — | — | **Unrealized P&L (inv)** +$0.06 (NEW) |
| Daily P&L | $3.11 | **Daily P&L (realized)** $3.11 |

Тепер зрозуміло:
- Realized = сума fills
- Unrealized = інвентар за mid
- Total Equity = bankroll + inventory

---

## 2. Історія версій

| Версія | Фіксів | Що зроблено |
|---|---|---|
| v1.0.59 | 1 | BUG-N9: auto-refill throttle |
| v1.0.60 | 1 | BUG-N10: discovery fallback |
| v1.0.61 | 1 | BUG-N11: UI input limits |
| v1.0.62 | 1 | BUG-N12: URGENT stop-loss (REMOVED) |
| v1.0.63 | 3 | BUG-N13/14 + REVERT |
| v1.0.64 | 1 | BUG-N15: STALE_DATA fix |
| v1.0.65 | 1 | BUG-N16: Exit All mid-based |
| v1.0.66 | 1 | BUG-N17: Liquidation mid-based |
| v1.0.67 | 1 | BUG-N18: PAPER Level 3 |
| v1.0.68 | 1 | BUG-N19: Lower spread thresholds |
| **v1.0.69** | **1** | **BUG-N20: UI Unrealized P&L** |

---

## 3. Поточний стан

### Тести
```
$ pytest tests/ --no-cov -q
113 passed   (UNVERIFIED — HTML-only change)
```

### Консистентність
- `VERSION`: 1.0.69 ✅
- `pyproject.toml`: 1.0.69 ✅
- `README.md`: v1.0.69 ✅
- Усі фікси v1.0.59-N19 — збережені ✅
- PAPER Level 3 — збережено ✅

---

## 4. Рекомендація

1. Запустити v1.0.69
2. Перевірити що "Unrealized P&L (inv)" показує значення
3. Тепер Realized + Unrealized = Total Equity growth

---

**Автор:** Z.ai Code (truth-first)
**Дата:** 2026-07-03
**CONFIDENCE:** 90%
