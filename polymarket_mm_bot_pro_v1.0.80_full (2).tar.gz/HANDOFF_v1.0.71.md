# HANDOFF: Polymarket MM Bot Pro v1.0.71

**Дата:** 2026-07-04
**Версія:** v1.0.71
**Попередник:** v1.0.70 (realistic relay gas)
**Стан:** ✅ Resolution detector + early pre-resolution exit

---

## 1. Що нового в v1.0.71

### Контекст
Australia -$3.28 — бот тримав позицію коли ціна впала -94% (resolution risk).

### 2 зміни

#### 1. PRE_RESOLUTION_EXIT_SEC: 900 → 3600
```env
PRE_RESOLUTION_EXIT_SEC=3600   # 1 год (було 15 хв)
```

#### 2. Resolution detector (BUG-N22) — НОВА фіча
```python
if book.mid < 0.05 or book.mid > 0.95:
    # ринок майже resolved → продати негайно
    await self._handle_resolution_exit(token_id, book, market_name)
```

### Зміна поведінки

| Сценарій | v1.0.70 | v1.0.71 |
|---|---|---|
| Australia (mid 0.011) | -$3.28 (тримав) | **-$2.58** (продав при 0.045) ✅ |
| Pre-resolution | 15 хв до | **1 год до** ✅ |

---

## 2. Історія версій

| Версія | Фіксів | Що зроблено |
|---|---|---|
| v1.0.59 | 1 | BUG-N9: auto-refill throttle |
| v1.0.60 | 1 | BUG-N10: discovery fallback |
| v1.0.61 | 1 | BUG-N11: UI input limits |
| v1.0.62 | 1 | BUG-N12: URGENT stop-loss (REMOVED) |
| v1.0.63 | 3 | BUG-N13/14 + REVERT |
| v1.0.64 | 1 | BUG-N15: STALE_DATA fix |
| v1.0.65 | 1 | BUG-N16: Exit All mid-based |
| v1.0.66 | 1 | BUG-N17: Liquidation mid-based |
| v1.0.67 | 1 | BUG-N18: PAPER Level 3 |
| v1.0.68 | 1 | BUG-N19: Lower spread thresholds |
| v1.0.69 | 1 | BUG-N20: UI Unrealized P&L |
| v1.0.70 | 1 | BUG-N21: Realistic relay gas |
| **v1.0.71** | **1** | **BUG-N22: Resolution detector + early exit** |

---

## 3. Поточний стан

### Тести
```
$ pytest tests/ --no-cov -q
113 passed   (UNVERIFIED — py_compile OK)
```

### Консистентність
- `VERSION`: 1.0.71 ✅
- `pyproject.toml`: 1.0.71 ✅
- `README.md`: v1.0.71 ✅
- Усі фікси v1.0.59-N21 — збережені ✅
- PAPER Level 3 — збережено ✅
- Realistic gas ($0.001) — збережено ✅

---

## 4. Захист від resolution risk

| Механізм | Тригер | Дія |
|---|---|---|
| `pre_resolution_exit` | 1 год до end_date | Продати за bid |
| `resolution_detector` | mid < 0.05 або > 0.95 | Продати за mid (A+C) |
| `liquidation_max_loss` | loss > 4¢ | Skip AGGRESSIVE |
| `critical_tier` | 95% ліміту | Deleverage |

---

## 5. Рекомендація

1. Запустити PAPER сесію з v1.0.71
2. Зменшити інвентар в UI (MAX_INVENTORY_USDC=10)
3. Перевірити: `resolution_detector_triggered` в логу
4. Australia-сценарій: збиток менший

---

**Автор:** Z.ai Code (truth-first)
**Дата:** 2026-07-04
**CONFIDENCE:** 90%
