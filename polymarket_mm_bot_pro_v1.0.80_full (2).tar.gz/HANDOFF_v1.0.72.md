# HANDOFF: Polymarket MM Bot Pro v1.0.72

**Дата:** 2026-07-04
**Версія:** v1.0.72
**Попередник:** v1.0.71 (resolution detector)
**Стан:** ✅ Persistent state — crash recovery

---

## 1. Що нового в v1.0.72

### Контекст
Різке вимкнення ПК → втрата інвентарю/bankroll (в RAM, не БД).

### Виправлення (BUG-N23: Persistent state for crash recovery)

**4 файли:**
1. `app/db/models.py` — нова таблиця `mm_inventory_state`
2. `app/services/inventory_manager.py` — `save_state_to_db` / `load_state_from_db` / `clear_saved_state`
3. `app/services/market_maker.py` — `_state_persistence_loop` (60s) + load on start + save on stop
4. `app/admin/api.py` — `clear_saved_state` on paper_reset

### Зміна поведінки

| Ситуація | v1.0.71 | v1.0.72 |
|---|---|---|
| Різке вимкнення | Втрата стану | **Відновлення з БД** ✅ |
| Kill -9 | Втрата | **Відновлення** ✅ |
| Graceful stop | Втрата | **Збереження** ✅ |

---

## 2. Історія версій

| Версія | Фіксів | Що зроблено |
|---|---|---|
| v1.0.59 | 1 | BUG-N9: auto-refill throttle |
| v1.0.60 | 1 | BUG-N10: discovery fallback |
| v1.0.61 | 1 | BUG-N11: UI input limits |
| v1.0.62 | 1 | BUG-N12: URGENT stop-loss (REMOVED) |
| v1.0.63 | 3 | BUG-N13/14 + REVERT |
| v1.0.64 | 1 | BUG-N15: STALE_DATA fix |
| v1.0.65 | 1 | BUG-N16: Exit All mid-based |
| v1.0.66 | 1 | BUG-N17: Liquidation mid-based |
| v1.0.67 | 1 | BUG-N18: PAPER Level 3 |
| v1.0.68 | 1 | BUG-N19: Lower spread thresholds |
| v1.0.69 | 1 | BUG-N20: UI Unrealized P&L |
| v1.0.70 | 1 | BUG-N21: Realistic relay gas |
| v1.0.71 | 1 | BUG-N22: Resolution detector |
| **v1.0.72** | **1** | **BUG-N23: Persistent state crash recovery** |

---

## 3. Поточний стан

### Тести
```
$ pytest tests/ --no-cov -q
113 passed   (UNVERIFIED — py_compile OK)
```

### Консистентність
- `VERSION`: 1.0.72 ✅
- `pyproject.toml`: 1.0.72 ✅
- `README.md`: v1.0.72 ✅
- Усі фікси v1.0.59-N22 — збережені ✅

---

## 4. Як працює crash recovery

```
1. Бот працює → _state_persistence_loop зберігає стан кожні 60с
2. Різке вимкнення → стан в RAM втрачено, але в БД збережено
3. Перезапуск бота → load_state_from_db() відновлює:
   - bankroll
   - starting_balance
   - daily_pnl
   - consecutive_losses
   - інвентар (net_tokens, avg_entry_price, market_name)
4. Лог: inventory_state_loaded_on_startup
```

---

## 5. Рекомендація

1. Запустити PAPER сесію з v1.0.72
2. Зачекати 60с (перший snapshot)
3. Зупинити бота (Ctrl+C)
4. Запустити знову — перевірити `inventory_state_loaded_on_startup`
5. Bankroll + інвентар мають відновитись

---

**Автор:** Z.ai Code (truth-first)
**Дата:** 2026-07-04
**CONFIDENCE:** 88%
