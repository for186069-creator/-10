# HANDOFF: Polymarket MM Bot Pro v1.0.73

**Дата:** 2026-07-04
**Версія:** v1.0.73
**Попередник:** v1.0.72 (crash recovery)
**Стан:** ✅ Gas відокремлено від прибутку

---

## 1. Що нового в v1.0.73

### Контекст
Газ змішувався з прибутком: `pnl_usdc = realized - gas`. BUY показував -$0.001 (ніби збиток).

### Виправлення (BUG-N24)

**Файл:** `app/services/market_maker.py:2113-2155`

- `pnl_usdc` = gross realized (БЕЗ газу) ✅
- `fees_usdc` = gas (окрема метрика) ✅
- `bankroll` все одно зменшується на gas (без змін)

### Зміна поведінки

| Метрика | v1.0.72 | v1.0.73 |
|---|---|---|
| BUY pnl_usdc | -$0.001 | **$0.00** ✅ |
| SELL pnl_usdc | profit - gas | **gross profit** ✅ |
| Dashboard Realized | profit - gas | **gross profit** ✅ |

---

## 2. Історія версій

| Версія | Фіксів | Що зроблено |
|---|---|---|
| v1.0.59 | 1 | BUG-N9: auto-refill throttle |
| v1.0.60 | 1 | BUG-N10: discovery fallback |
| v1.0.61 | 1 | BUG-N11: UI input limits |
| v1.0.62 | 1 | BUG-N12: URGENT stop-loss (REMOVED) |
| v1.0.63 | 3 | BUG-N13/14 + REVERT |
| v1.0.64 | 1 | BUG-N15: STALE_DATA fix |
| v1.0.65 | 1 | BUG-N16: Exit All mid-based |
| v1.0.66 | 1 | BUG-N17: Liquidation mid-based |
| v1.0.67 | 1 | BUG-N18: PAPER Level 3 |
| v1.0.68 | 1 | BUG-N19: Lower spread thresholds |
| v1.0.69 | 1 | BUG-N20: UI Unrealized P&L |
| v1.0.70 | 1 | BUG-N21: Realistic relay gas |
| v1.0.71 | 1 | BUG-N22: Resolution detector |
| v1.0.72 | 1 | BUG-N23: Persistent state crash recovery |
| **v1.0.73** | **1** | **BUG-N24: Gas separated from profit** |

---

## 3. Поточний стан

### Тести
```
$ pytest tests/ --no-cov -q
113 passed   (UNVERIFIED — py_compile OK)
```

### Консистентність
- `VERSION`: 1.0.73 ✅
- `pyproject.toml`: 1.0.73 ✅
- `README.md`: v1.0.73 ✅
- Усі фікси v1.0.59-N23 — збережені ✅

---

## 4. Як тепер рахується P&L

```
Fill (BUY):
  realized = $0.00 (нема trading edge)
  fees = $0.001 (gas)
  pnl_usdc = $0.00 (gross, БЕЗ газу) ✅
  bankroll -= $0.001 (gas як витрата)

Fill (SELL):
  realized = $0.124 (trading edge)
  fees = $0.001 (gas)
  pnl_usdc = $0.124 (gross, БЕЗ газу) ✅
  bankroll -= $0.001 (gas як витрата)

Dashboard Realized = сума pnl_usdc = gross profit
Fees = сума fees_usdc = total gas
Net = Realized - Fees
```

---

## 5. Рекомендація

1. Запустити PAPER сесію з v1.0.73
2. Перевірити: BUY fills показують `pnl_usdc=0.00`
3. Dashboard Realized = gross profit (без газу)
4. Тепер метрика точна: прибуток ≠ витрати

---

**Автор:** Z.ai Code (truth-first)
**Дата:** 2026-07-04
**CONFIDENCE:** 92%
