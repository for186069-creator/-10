"""Initial schema: trades, quotes, snapshots, halt_events, metric_points.

Revision ID: 001
Revises:
Create Date: 2025-01-01 00:00:00

"""
from __future__ import annotations

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

# revision identifiers
revision: str = "001"
down_revision: Union[str, Sequence[str], None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # mm_trades
    op.create_table(
        "mm_trades",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("market_id", sa.String(), nullable=False),
        sa.Column("market_name", sa.String(), nullable=False),
        sa.Column("condition_id", sa.String(), nullable=True),
        sa.Column("side", sa.Enum("BUY", "SELL", name="side_enum"), nullable=False),
        sa.Column("price", sa.Float(), nullable=False),
        sa.Column("size_usdc", sa.Float(), nullable=False),
        sa.Column("size_tokens", sa.Float(), nullable=False),
        sa.Column("pnl_usdc", sa.Float(), nullable=True),
        sa.Column("fees_usdc", sa.Float(), nullable=True),
        sa.Column("inventory_after", sa.Float(), nullable=True),
        sa.Column("reservation_price", sa.Float(), nullable=True),
        sa.Column("kyle_lambda", sa.Float(), nullable=True),
        sa.Column("spread_cents", sa.Float(), nullable=True),
        sa.Column("level", sa.Integer(), nullable=True),
        sa.Column("order_id", sa.String(), nullable=True),
        sa.Column(
            "mode",
            sa.Enum("PAPER", "LIVE", name="ordermode_enum"),
            nullable=False,
        ),
        sa.Column("is_hedge", sa.Boolean(), nullable=True),
        sa.Column(
            "timestamp",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=False,
        ),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_trades_market_ts", "mm_trades", ["market_id", "timestamp"])
    op.create_index("ix_trades_ts", "mm_trades", ["timestamp"])
    op.create_index("ix_mm_trades_market_id", "mm_trades", ["market_id"])
    op.create_index("ix_mm_trades_condition_id", "mm_trades", ["condition_id"])

    # mm_quotes
    op.create_table(
        "mm_quotes",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("market_id", sa.String(), nullable=False),
        sa.Column("bid_price", sa.Float(), nullable=True),
        sa.Column("ask_price", sa.Float(), nullable=True),
        sa.Column("mid_price", sa.Float(), nullable=False),
        sa.Column("size_usdc", sa.Float(), nullable=False),
        sa.Column("spread_cents", sa.Float(), nullable=False),
        sa.Column("level", sa.Integer(), nullable=True),
        sa.Column(
            "status",
            sa.Enum("PLACED", "FILLED", "CANCELED", "PARTIAL", "EXPIRED", name="quotestatus_enum"),
            nullable=False,
        ),
        sa.Column(
            "timestamp",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=False,
        ),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_mm_quotes_market_id", "mm_quotes", ["market_id"])

    # mm_snapshots
    op.create_table(
        "mm_snapshots",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("market_id", sa.String(), nullable=False),
        sa.Column("mid_price", sa.Float(), nullable=False),
        sa.Column("spread", sa.Float(), nullable=False),
        sa.Column("volatility", sa.Float(), nullable=True),
        sa.Column("kyle_lambda", sa.Float(), nullable=True),
        sa.Column("our_inventory", sa.Float(), nullable=True),
        sa.Column("bankroll_usdc", sa.Float(), nullable=False),
        sa.Column(
            "timestamp",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=False,
        ),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_snap_market_ts", "mm_snapshots", ["market_id", "timestamp"])
    op.create_index("ix_mm_snapshots_market_id", "mm_snapshots", ["market_id"])

    # mm_halt_events
    op.create_table(
        "mm_halt_events",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("event", sa.String(), nullable=False),
        sa.Column("reason", sa.String(), nullable=True),
        sa.Column("detail", sa.Text(), nullable=True),
        sa.Column("bankroll_at_event", sa.Float(), nullable=True),
        sa.Column(
            "timestamp",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=False,
        ),
        sa.PrimaryKeyConstraint("id"),
    )

    # mm_metric_points
    op.create_table(
        "mm_metric_points",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("market_id", sa.String(), nullable=False),
        sa.Column("metric_name", sa.String(), nullable=False),
        sa.Column("value", sa.Float(), nullable=False),
        sa.Column(
            "timestamp",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=False,
        ),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(
        "ix_metric_market_name_ts",
        "mm_metric_points",
        ["market_id", "metric_name", "timestamp"],
    )
    op.create_index("ix_mm_metric_points_market_id", "mm_metric_points", ["market_id"])


def downgrade() -> None:
    op.drop_table("mm_metric_points")
    op.drop_table("mm_halt_events")
    op.drop_table("mm_snapshots")
    op.drop_table("mm_quotes")
    op.drop_table("mm_trades")
    # Drop enums (Postgres only; SQLite ignores)
    for enum_name in ("side_enum", "quotestatus_enum", "ordermode_enum"):
        try:
            sa.Enum(name=enum_name).drop(op.get_bind(), checkfirst=True)
        except Exception:
            pass
