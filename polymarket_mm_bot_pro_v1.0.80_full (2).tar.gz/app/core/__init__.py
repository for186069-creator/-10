"""app.core — configuration, database, logging, metrics."""
