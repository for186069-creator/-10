"""
app/db/init_db.py — Create tables on first run (for dev / paper mode).
Production uses Alembic migrations; see alembic/ directory.
"""
from __future__ import annotations

from app.core.db import Base, engine
from app.core.logging import get_logger
from app.db import models  # noqa: F401 — register all tables

log = get_logger(__name__)


async def init_db() -> None:
    """Create all tables. Idempotent."""
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    log.info("db_initialized", tables=list(Base.metadata.tables.keys()))
