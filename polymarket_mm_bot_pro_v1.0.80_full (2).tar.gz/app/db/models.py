"""
app/db/models.py — ORM models.

Trade       : each individual fill
Quote       : each quote placement (analytics, optional)
Snapshot    : periodic state snapshot for charts
HaltEvent   : each halt/resume event (audit trail)
MetricPoint : time-series of strategy metrics (volatility, lambda, etc.)
"""
from __future__ import annotations

import enum
from datetime import datetime

from sqlalchemy import (
    DateTime,
    Enum,
    Float,
    Index,
    Integer,
    String,
    Text,
    func,
)
from sqlalchemy.orm import Mapped, mapped_column

from app.core.db import Base


class Side(str, enum.Enum):
    BUY = "BUY"    # we bought tokens (someone hit our bid)
    SELL = "SELL"  # we sold tokens (someone hit our ask)


class QuoteStatus(str, enum.Enum):
    PLACED = "PLACED"
    FILLED = "FILLED"
    CANCELED = "CANCELED"
    PARTIAL = "PARTIAL"
    EXPIRED = "EXPIRED"


class OrderMode(str, enum.Enum):
    PAPER = "PAPER"
    LIVE = "LIVE"


class HaltReason(str, enum.Enum):
    CONSECUTIVE_LOSSES = "CONSECUTIVE_LOSSES"
    DAILY_LOSS = "DAILY_LOSS"
    MIN_BALANCE = "MIN_BALANCE"
    STALE_DATA = "STALE_DATA"
    EMERGENCY_STOP = "EMERGENCY_STOP"
    USER_PAUSE = "USER_PAUSE"
    MANUAL = "MANUAL"


class Trade(Base):
    """Each individual fill (one side of a round-trip)."""

    __tablename__ = "mm_trades"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    market_id: Mapped[str] = mapped_column(String, nullable=False, index=True)
    market_name: Mapped[str] = mapped_column(String, nullable=False)
    condition_id: Mapped[str] = mapped_column(String, default="", index=True)
    side: Mapped[Side] = mapped_column(Enum(Side), nullable=False)

    price: Mapped[float] = mapped_column(Float, nullable=False)
    size_usdc: Mapped[float] = mapped_column(Float, nullable=False)
    size_tokens: Mapped[float] = mapped_column(Float, nullable=False)

    # Realized P&L on closing trades (None for opening trades)
    pnl_usdc: Mapped[float | None] = mapped_column(Float, nullable=True)
    # Fees/gas paid on this trade (USD)
    fees_usdc: Mapped[float] = mapped_column(Float, default=0.0)

    # Inventory snapshot at fill time
    inventory_after: Mapped[float] = mapped_column(Float, default=0.0)

    # Strategy context (for post-hoc analysis)
    reservation_price: Mapped[float | None] = mapped_column(Float, nullable=True)
    kyle_lambda: Mapped[float | None] = mapped_column(Float, nullable=True)
    spread_cents: Mapped[float | None] = mapped_column(Float, nullable=True)
    level: Mapped[int] = mapped_column(Integer, default=1)  # multi-level 1/2/3

    order_id: Mapped[str | None] = mapped_column(String, nullable=True)
    mode: Mapped[OrderMode] = mapped_column(
        Enum(OrderMode), default=OrderMode.PAPER, nullable=False
    )
    is_hedge: Mapped[bool] = mapped_column(default=False)
    timestamp: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )

    __table_args__ = (
        Index("ix_trades_market_ts", "market_id", "timestamp"),
        Index("ix_trades_ts", "timestamp"),
    )


class Quote(Base):
    """Each quote placement (sampled — not every quote persisted)."""

    __tablename__ = "mm_quotes"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    market_id: Mapped[str] = mapped_column(String, nullable=False, index=True)
    bid_price: Mapped[float | None] = mapped_column(Float, nullable=True)
    ask_price: Mapped[float | None] = mapped_column(Float, nullable=True)
    mid_price: Mapped[float] = mapped_column(Float, nullable=False)
    size_usdc: Mapped[float] = mapped_column(Float, nullable=False)
    spread_cents: Mapped[float] = mapped_column(Float, nullable=False)
    level: Mapped[int] = mapped_column(Integer, default=1)
    status: Mapped[QuoteStatus] = mapped_column(
        Enum(QuoteStatus), default=QuoteStatus.PLACED, nullable=False
    )
    timestamp: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )


class MarketSnapshot(Base):
    """Periodic snapshots of market + bot state for charts."""

    __tablename__ = "mm_snapshots"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    market_id: Mapped[str] = mapped_column(String, nullable=False, index=True)
    mid_price: Mapped[float] = mapped_column(Float, nullable=False)
    spread: Mapped[float] = mapped_column(Float, nullable=False)
    volatility: Mapped[float] = mapped_column(Float, default=0.0)
    kyle_lambda: Mapped[float] = mapped_column(Float, default=0.0)
    our_inventory: Mapped[float] = mapped_column(Float, default=0.0)
    bankroll_usdc: Mapped[float] = mapped_column(Float, nullable=False)
    timestamp: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )

    __table_args__ = (Index("ix_snap_market_ts", "market_id", "timestamp"),)


class HaltEvent(Base):
    """Audit trail of each halt + resume event."""

    __tablename__ = "mm_halt_events"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    event: Mapped[str] = mapped_column(String, nullable=False)  # "HALT" or "RESUME"
    reason: Mapped[str] = mapped_column(String, default="")
    detail: Mapped[str] = mapped_column(Text, default="")
    bankroll_at_event: Mapped[float] = mapped_column(Float, default=0.0)
    timestamp: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )


class MetricPoint(Base):
    """Time-series of strategy metrics per market."""

    __tablename__ = "mm_metric_points"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    market_id: Mapped[str] = mapped_column(String, nullable=False, index=True)
    metric_name: Mapped[str] = mapped_column(String, nullable=False)
    value: Mapped[float] = mapped_column(Float, nullable=False)
    timestamp: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )

    __table_args__ = (
        Index("ix_metric_market_name_ts", "market_id", "metric_name", "timestamp"),
    )


class InventoryState(Base):
    """v1.0.72 (BUG-N23): Persistent inventory state for crash recovery.

    Stores bankroll + per-market inventory so bot can restore after
    sudden shutdown (power loss, kill -9, container crash).
    Snapshot saved every 60s by _state_persistence_loop in market_maker.
    Loaded once at startup in InventoryManager.__init__.
    """

    __tablename__ = "mm_inventory_state"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    # Single row table (id=1 always) — latest state
    bankroll: Mapped[float] = mapped_column(Float, nullable=False)
    starting_balance: Mapped[float] = mapped_column(Float, nullable=False)
    daily_pnl: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    consecutive_losses: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    # JSON-serialized dict of {token_id: {net_tokens, avg_entry_price, market_name, open_time_mono}}
    # Note: open_time is monotonic — on restart we set it to 0 (position not aged)
    inventories_json: Mapped[str] = mapped_column(Text, nullable=False, default="{}")
    timestamp: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
