"""
app/db/order_metrics_db.py — Thin SQLite layer for order-lifecycle metrics.

Isolated from the main mm_bot.db (uses its own file via METRICS_DB_PATH) so
instrumentation never contends with the trading DB. Raw aiosqlite — no ORM,
no migrations — keeps the logger dependency-free and "thin" per the handoff
spec (§2 deliverable #1).

Schema follows the handoff (§3) with one documented extension:
  - `mode` column (v1.0.79) — 'LIVE' | 'PAPER'. PAPER rows would otherwise
    pollute rejection-rate / fill-time percentiles (PAPER always returns
    MATCHED with ~0ms latency). The report filters on mode='LIVE'.

All public functions are async and safe to call from the order-submission
path. A failed DB write MUST NOT break trading — callers wrap in try/except.
"""
from __future__ import annotations

import json
from typing import Any

import aiosqlite

from app.core.config import settings
from app.core.logging import get_logger

log = get_logger(__name__)

# Module-level connection (aiosqlite serializes writes on a single conn).
_conn: aiosqlite.Connection | None = None

SCHEMA = """
CREATE TABLE IF NOT EXISTS order_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    client_order_ref TEXT NOT NULL UNIQUE,
    polymarket_order_id TEXT,

    market_slug TEXT,
    token_id TEXT,
    condition_id TEXT,
    market_category TEXT,

    side TEXT,
    order_type TEXT,
    price REAL,
    size REAL,
    tick_size REAL,
    is_marketable INTEGER,
    seconds_to_game_start REAL,

    created_at_local TEXT,
    submitted_at TEXT,
    ack_received_at TEXT,
    ack_status TEXT,
    ack_latency_ms REAL,

    first_fill_at TEXT,
    fully_filled_at TEXT,
    cancelled_at TEXT,

    final_status TEXT,
    filled_size REAL,
    fill_ratio REAL,

    time_to_first_fill_ms REAL,
    time_to_full_fill_ms REAL,

    retry_count INTEGER DEFAULT 0,
    total_retry_wait_ms REAL DEFAULT 0,

    reject_reason TEXT,
    reject_stage TEXT,

    raw_response_json TEXT,
    mode TEXT NOT NULL DEFAULT 'LIVE'
);

CREATE INDEX IF NOT EXISTS idx_order_events_status ON order_events(final_status);
CREATE INDEX IF NOT EXISTS idx_order_events_category ON order_events(market_category);
CREATE INDEX IF NOT EXISTS idx_order_events_mode ON order_events(mode);
CREATE INDEX IF NOT EXISTS idx_order_events_ref ON order_events(client_order_ref);
"""


async def init_metrics_db() -> None:
    """Open connection + create tables. Idempotent. Safe to call multiple times."""
    global _conn
    if _conn is not None:
        return
    _conn = await aiosqlite.connect(settings.metrics_db_path)
    _conn.row_factory = aiosqlite.Row
    await _conn.executescript(SCHEMA)
    await _conn.commit()
    log.info("metrics_db_initialized", path=settings.metrics_db_path)


async def close_metrics_db() -> None:
    global _conn
    if _conn is not None:
        await _conn.close()
        _conn = None


def _conn_or_none() -> aiosqlite.Connection | None:
    """Return the connection if initialized, else None (logger is best-effort)."""
    return _conn


async def insert_order_event(row: dict[str, Any]) -> None:
    """Insert a new order_events row. row must include client_order_ref."""
    conn = _conn_or_none()
    if conn is None:
        return
    cols = list(row.keys())
    placeholders = ",".join("?" for _ in cols)
    col_list = ",".join(cols)
    await conn.execute(
        f"INSERT OR REPLACE INTO order_events ({col_list}) VALUES ({placeholders})",
        [row[c] for c in cols],
    )
    await conn.commit()


async def update_order_event(client_order_ref: str, updates: dict[str, Any]) -> None:
    """Patch an existing row by client_order_ref. No-op if row missing."""
    conn = _conn_or_none()
    if conn is None:
        return
    if not updates:
        return
    set_clause = ",".join(f"{k}=?" for k in updates)
    await conn.execute(
        f"UPDATE order_events SET {set_clause} WHERE client_order_ref=?",
        [*updates.values(), client_order_ref],
    )
    await conn.commit()


async def fetch_unresolved_orders() -> list[dict[str, Any]]:
    """Rows that got an ack but no final fill/cancel yet (for the poller)."""
    conn = _conn_or_none()
    if conn is None:
        return []
    async with conn.execute(
        "SELECT client_order_ref, polymarket_order_id, token_id, side, price, size, "
        "submitted_at, market_category, mode FROM order_events "
        "WHERE final_status IS NULL AND polymarket_order_id IS NOT NULL "
        "AND polymarket_order_id != '' AND mode='LIVE'"
    ) as cur:
        return [dict(r) for r in await cur.fetchall()]


async def fetch_all_for_report(mode_filter: str = "LIVE") -> list[dict[str, Any]]:
    """Pull rows for the report. Filters to the requested mode."""
    conn = _conn_or_none()
    if conn is None:
        return []
    async with conn.execute(
        "SELECT market_category, is_marketable, final_status, reject_stage, "
        "time_to_first_fill_ms, time_to_full_fill_ms, retry_count, "
        "total_retry_wait_ms, ack_latency_ms FROM order_events WHERE mode=?",
        (mode_filter,),
    ) as cur:
        return [dict(r) for r in await cur.fetchall()]


async def store_raw_response(client_order_ref: str, raw: dict[str, Any] | None) -> None:
    """Persist raw API response as JSON if METRICS_LOG_RAW_RESPONSE is on."""
    if not settings.metrics_log_raw_response or raw is None:
        return
    await update_order_event(
        client_order_ref, {"raw_response_json": json.dumps(raw, default=str)[:16000]}
    )
