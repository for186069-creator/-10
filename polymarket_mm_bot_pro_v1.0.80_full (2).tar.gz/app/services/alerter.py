"""
app/services/alerter.py — Telegram alerts + in-memory alert log.

Uses httpx (proper async HTTP, unlike v10.13 which had httpx missing
from requirements). Falls back gracefully if Telegram is not configured.
"""
from __future__ import annotations

import asyncio
import time
from collections import deque
from dataclasses import dataclass
from datetime import datetime, timezone

import httpx

from app.core.config import settings
from app.core.logging import get_logger

log = get_logger(__name__)


@dataclass
class Alert:
    level: str  # info | warning | critical
    title: str
    message: str
    timestamp: datetime

    def to_dict(self) -> dict:
        return {
            "timestamp": self.timestamp.isoformat(),
            "level": self.level,
            "title": self.title,
            "message": self.message,
        }


class Alerter:
    """Async alerter with rate limiting + optional Telegram delivery."""

    EMOJI = {"info": "ℹ️", "warning": "⚠️", "critical": "🚨"}

    def __init__(self) -> None:
        self._log: deque[Alert] = deque(maxlen=100)
        self._last_alert_time: dict[str, float] = {}
        self._min_interval_sec = 60
        self._last_daily_summary: datetime | None = None
        self._lock = asyncio.Lock()

    async def send(
        self,
        level: str,
        title: str,
        message: str,
        alert_key: str = "",
        dedupe_sec: int = 60,
    ) -> None:
        """Send an alert. Dedupes by alert_key within dedupe_sec window."""
        async with self._lock:
            if alert_key:
                now_mono = time.monotonic()
                last = self._last_alert_time.get(alert_key, 0)
                if now_mono - last < dedupe_sec:
                    return
                self._last_alert_time[alert_key] = now_mono

            alert = Alert(
                level=level,
                title=title,
                message=message,
                timestamp=datetime.now(timezone.utc),
            )
            self._log.append(alert)

        # Log it
        if level == "critical":
            log.critical("alert", level=level, title=title, message=message)
        elif level == "warning":
            log.warning("alert", level=level, title=title, message=message)
        else:
            log.info("alert", level=level, title=title, message=message)

        # Telegram delivery
        if (
            settings.telegram_enabled
            and settings.telegram_bot_token
            and settings.telegram_chat_id
        ):
            try:
                await self._send_telegram(alert)
            except Exception as e:
                log.debug("telegram_send_failed", error=str(e))

    async def _send_telegram(self, alert: Alert) -> None:
        emoji = self.EMOJI.get(alert.level, "ℹ️")
        text = (
            f"{emoji} *{alert.title}*\n\n{alert.message}\n\n"
            f"_Time: {alert.timestamp.strftime('%Y-%m-%d %H:%M:%S UTC')}_"
        )
        url = f"https://api.telegram.org/bot{settings.telegram_bot_token}/sendMessage"
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.post(
                url,
                json={
                    "chat_id": settings.telegram_chat_id,
                    "text": text,
                    "parse_mode": "Markdown",
                },
            )
            if resp.status_code != 200:
                log.debug("telegram_api_error", status=resp.status_code, body=resp.text[:200])

    async def send_daily_summary(
        self,
        bankroll: float,
        daily_pnl: float,
        total_trades: int,
        win_rate: float,
        hedge_attempts: int,
        hedge_fills: int,
    ) -> None:
        """Once-per-day summary (UTC). Idempotent within 23 hours."""
        now = datetime.now(timezone.utc)
        if self._last_daily_summary:
            if (now - self._last_daily_summary).total_seconds() < 23 * 3600:
                return
        self._last_daily_summary = now

        pnl_str = f"+${daily_pnl:.2f}" if daily_pnl >= 0 else f"-${abs(daily_pnl):.2f}"
        message = (
            f"📊 *Daily Summary*\n\n"
            f"💰 Bankroll: ${bankroll:.2f}\n"
            f"📈 Daily P&L: {pnl_str}\n"
            f"🔄 Total trades: {total_trades}\n"
            f"🎯 Win rate: {win_rate:.1f}%\n"
            f"🛡️ Hedge: {hedge_fills}/{hedge_attempts} fills"
        )
        await self.send("info", "Daily Summary", message, alert_key="daily_summary", dedupe_sec=23 * 3600)

    @property
    def recent_alerts(self) -> list[dict]:
        return [a.to_dict() for a in reversed(self._log)]


# Singleton
alerter = Alerter()
