"""
app/services/inventory_manager.py — Position tracking & risk-aware inventory.

FIXES from v10.13:
  #2 — Dead code: should_quote_bid/ask checked `ratio < 2.0` but ratio ∈ [-1, 1]
        was always True. Now properly blocks at inventory_clear_threshold.
  #6 — Stale-data resume wiped daily_pnl. Now `resume()` takes a flag to
        preserve risk counters when resuming from transient halts.

NEW:
  - FIFO-aware realized P&L (proper accounting for partial closes)
  - Mark-to-mid unrealized P&L
  - Halt event persistence (audit trail)
  - Per-side inventory blocking based on `inventory_clear_threshold`
  - v1.0.72 (BUG-N23): Persistent state — save/load from DB for crash recovery
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import TYPE_CHECKING

from sqlalchemy import select

from app.core.config import settings
from app.core.logging import get_logger

if TYPE_CHECKING:
    from app.services.clob_client import MarketBook

log = get_logger(__name__)


@dataclass
class Inventory:
    """Per-market inventory state. Single-threaded (asyncio) — no locks needed."""

    token_id: str
    market_name: str = ""
    net_tokens: float = 0.0  # + = long, - = short
    avg_entry_price: float = 0.0  # weighted average entry price
    realized_pnl: float = 0.0  # cumulative realized P&L for this market
    fill_count_buy: int = 0
    fill_count_sell: int = 0
    open_time: float = 0.0  # monotonic time when position was opened

    @property
    def net_usdc_at_entry(self) -> float:
        """USD value of net position at entry price."""
        return self.net_tokens * self.avg_entry_price

    def unrealized_pnl(self, current_mid: float) -> float:
        """Mark-to-mid unrealized P&L."""
        return self.net_tokens * (current_mid - self.avg_entry_price)

    def inventory_ratio(self, max_usdc: float) -> float:
        """How close we are to max inventory (-1..+1).

        +1 = max long, -1 = max short, 0 = flat.
        """
        if max_usdc <= 0:
            return 0.0
        return max(-1.0, min(1.0, self.net_usdc_at_entry / max_usdc))


class InventoryManager:
    """Centralized inventory + bankroll tracking + halt control."""

    def __init__(self) -> None:
        self.inventories: dict[str, Inventory] = {}
        self.bankroll: float = settings.paper_balance_usdc
        self.starting_balance: float = settings.paper_balance_usdc
        self.consecutive_losses: int = 0
        self.daily_pnl: float = 0.0
        self.daily_pnl_date: str = self._today()
        self.halted: bool = False
        self.halt_reason: str = ""

    # ── v1.0.72 (BUG-N23): Persistent state for crash recovery ──────────

    async def save_state_to_db(self, db_session) -> None:
        """Save current bankroll + inventories to DB. Called every 60s.

        On crash/restart, load_state_from_db() restores this state.
        """
        from app.db.models import InventoryState

        # Serialize inventories to JSON
        inv_data = {}
        for tid, inv in self.inventories.items():
            if abs(inv.net_tokens) > 0.0001:  # only save non-flat positions
                inv_data[tid] = {
                    "net_tokens": inv.net_tokens,
                    "avg_entry_price": inv.avg_entry_price,
                    "market_name": inv.market_name,
                    "realized_pnl": inv.realized_pnl,
                    # Don't save open_time — monotonic clock resets on restart
                }
        inventories_json = json.dumps(inv_data)

        # Upsert (single row, id=1)
        result = await db_session.execute(
            select(InventoryState).where(InventoryState.id == 1)
        )
        state = result.scalar_one_or_none()
        if state is None:
            state = InventoryState(
                id=1,
                bankroll=self.bankroll,
                starting_balance=self.starting_balance,
                daily_pnl=self.daily_pnl,
                consecutive_losses=self.consecutive_losses,
                inventories_json=inventories_json,
            )
            db_session.add(state)
        else:
            state.bankroll = self.bankroll
            state.starting_balance = self.starting_balance
            state.daily_pnl = self.daily_pnl
            state.consecutive_losses = self.consecutive_losses
            state.inventories_json = inventories_json

        await db_session.commit()

    async def load_state_from_db(self, db_session) -> bool:
        """Load saved state from DB. Called once at startup.

        Returns True if state was restored, False if no saved state.
        """
        from app.db.models import InventoryState

        result = await db_session.execute(
            select(InventoryState).where(InventoryState.id == 1)
        )
        state = result.scalar_one_or_none()
        if state is None:
            log.info("inventory_state_no_saved_state", reason="first run or reset")
            return False

        # Restore bankroll + counters
        self.bankroll = state.bankroll
        self.starting_balance = state.starting_balance
        self.daily_pnl = state.daily_pnl
        self.consecutive_losses = state.consecutive_losses

        # Restore inventories
        inv_data = json.loads(state.inventories_json) if state.inventories_json else {}
        restored_count = 0
        for tid, data in inv_data.items():
            inv = Inventory(
                token_id=tid,
                market_name=data.get("market_name", ""),
                net_tokens=data["net_tokens"],
                avg_entry_price=data["avg_entry_price"],
                realized_pnl=data.get("realized_pnl", 0.0),
                open_time=0.0,  # reset — position not aged on restart
            )
            self.inventories[tid] = inv
            restored_count += 1

        log.info(
            "inventory_state_restored",
            bankroll=round(self.bankroll, 2),
            starting_balance=round(self.starting_balance, 2),
            daily_pnl=round(self.daily_pnl, 2),
            consecutive_losses=self.consecutive_losses,
            positions_restored=restored_count,
        )
        return True

    async def clear_saved_state(self, db_session) -> None:
        """Delete saved state. Called on paper_reset / Exit All."""
        from app.db.models import InventoryState

        result = await db_session.execute(
            select(InventoryState).where(InventoryState.id == 1)
        )
        state = result.scalar_one_or_none()
        if state is not None:
            await db_session.delete(state)
            await db_session.commit()

    # ── Helpers ───────────────────────────────────────────────────────────

    @staticmethod
    def _today() -> str:
        return datetime.now(timezone.utc).strftime("%Y-%m-%d")

    def get_inventory(self, token_id: str) -> Inventory:
        if token_id not in self.inventories:
            self.inventories[token_id] = Inventory(token_id=token_id)
        return self.inventories[token_id]

    def max_inventory_usdc(self) -> float:
        """Effective max inventory per market.

        Uses the LARGER of ($ cap, % of bankroll) so inventory can scale
        as bankroll grows from profits. Previously used min() which kept
        inventory locked at $5 even when bankroll doubled.
        """
        pct_cap = self.bankroll * settings.max_inventory_pct_of_bankroll
        return max(settings.max_inventory_usdc, pct_cap)

    def _rollover_daily_pnl_if_needed(self) -> None:
        """Reset daily_pnl at UTC midnight. NOT on resume (fixes #6)."""
        today = self._today()
        if today != self.daily_pnl_date:
            self.daily_pnl = 0.0
            self.daily_pnl_date = today

    # ── Fill processing ───────────────────────────────────────────────────

    def on_fill(
        self,
        token_id: str,
        side: str,  # "BUY" or "SELL"
        price: float,
        size_usdc: float,
        market_name: str = "",
    ) -> float:
        """Process a fill. Updates inventory + bankroll. Returns realized P&L."""
        self._rollover_daily_pnl_if_needed()

        inv = self.get_inventory(token_id)
        inv.market_name = market_name

        tokens = size_usdc / max(price, 0.001)
        realized = 0.0

        if side == "BUY":
            new_total = inv.net_tokens + tokens
            if inv.net_tokens >= 0:
                # Increasing long — weighted average entry
                new_cost = inv.net_tokens * inv.avg_entry_price + tokens * price
                inv.avg_entry_price = new_cost / max(new_total, 0.001)
                if inv.net_tokens == 0:
                    inv.open_time = _now_monotonic()
            else:
                # Reducing short — realize P&L on closed portion
                # Short was opened at avg_entry; buying back at `price`.
                # P&L = (entry - price) * tokens_bought_back
                closed = min(tokens, abs(inv.net_tokens))
                realized = (inv.avg_entry_price - price) * closed
                # If we flipped to long, remaining becomes new long position
                if new_total > 0:
                    inv.avg_entry_price = price
                    inv.open_time = _now_monotonic()
            inv.net_tokens = new_total
            inv.fill_count_buy += 1
            self.bankroll -= size_usdc  # we paid cash
        else:  # SELL
            new_total = inv.net_tokens - tokens
            if inv.net_tokens > 0:
                # Selling long — realize P&L on closed portion
                closed = min(tokens, inv.net_tokens)
                realized = (price - inv.avg_entry_price) * closed
                # If we flipped to short, remaining becomes new short
                if new_total < 0:
                    inv.avg_entry_price = price
                    inv.open_time = _now_monotonic()
            else:
                # Increasing short — weighted average entry
                new_cost = abs(inv.net_tokens) * inv.avg_entry_price + tokens * price
                inv.avg_entry_price = new_cost / max(abs(new_total), 0.001)
                if inv.net_tokens == 0:
                    inv.open_time = _now_monotonic()
            inv.net_tokens = new_total
            inv.fill_count_sell += 1
            self.bankroll += size_usdc  # we received cash

        inv.realized_pnl += realized
        self.daily_pnl += realized

        # ── Risk counter updates ──
        # v1.0.50 FIX (BUG-27): previously breakeven fills (realized == 0)
        # did NOT reset consecutive_losses. A streak of 4 losses followed by
        # a breakeven would still count as 4 losses, then the next loss
        # would trigger the halt at 5. Now: any non-loss (realized >= 0)
        # resets the counter. This is more forgiving for round-trips that
        # net to zero (gas-only closes).
        if realized < 0:
            self.consecutive_losses += 1
            if self.consecutive_losses >= settings.stop_trading_consecutive_losses:
                self.halt(
                    reason="CONSECUTIVE_LOSSES",
                    detail=f"{self.consecutive_losses} consecutive losses",
                )
        else:
            # realized >= 0 (profit OR breakeven) → reset streak
            self.consecutive_losses = 0

        # Daily loss check (only count losses, not profitable days)
        if self.daily_pnl <= -settings.max_daily_loss_usd:
            self.halt(
                reason="DAILY_LOSS",
                detail=f"Daily P&L ${self.daily_pnl:.2f} ≤ -${settings.max_daily_loss_usd}",
            )

        # Min balance (LIVE)
        if not settings.paper_trading and self.bankroll < settings.min_balance_usd:
            self.halt(
                reason="MIN_BALANCE",
                detail=f"Balance ${self.bankroll:.2f} < ${settings.min_balance_usd}",
            )

        return realized

    # ── Inventory-aware quote skew ────────────────────────────────────────

    def quote_skew(self, token_id: str) -> float:
        """Return skew in CENTS to apply to quotes.

        Positive = shift quotes UP (encourage sells).
        Negative = shift quotes DOWN (encourage buys).
        Zero = symmetric quotes.

        PROGRESSIVE skew: ramps from `inventory_skew_threshold` to 1.0 of max
        inventory, capped at `inventory_skew_max_cents`.
        """
        inv = self.inventories.get(token_id)
        if not inv or inv.net_tokens == 0:
            return 0.0

        max_usd = self.max_inventory_usdc()
        ratio = inv.inventory_ratio(max_usd)
        if abs(ratio) < settings.inventory_skew_threshold:
            return 0.0

        # Long → push quotes DOWN (encourage selling). Short → UP (encourage buying)
        sign = -1.0 if ratio > 0 else 1.0
        # Ramp: 0 at threshold → 1 at max
        magnitude = (abs(ratio) - settings.inventory_skew_threshold) / (
            1.0 - settings.inventory_skew_threshold
        )
        magnitude = max(0.0, min(1.0, magnitude))
        return sign * magnitude * settings.inventory_skew_max_cents

    def should_quote_bid(self, token_id: str) -> bool:
        """Block bid (buying more) when long inventory is near max.

        FIX #2: previously checked `ratio < 2.0` (always True since ratio ∈ [-1,1]).
        Now properly uses inventory_clear_threshold.
        """
        inv = self.inventories.get(token_id)
        if not inv:
            return True
        max_usd = self.max_inventory_usdc()
        ratio = inv.inventory_ratio(max_usd)
        # Block adding to long when ratio > inventory_clear_threshold
        return ratio < settings.inventory_clear_threshold

    def should_quote_ask(self, token_id: str) -> bool:
        """Block ask (selling more) when short inventory is near max."""
        inv = self.inventories.get(token_id)
        if not inv:
            return True
        max_usd = self.max_inventory_usdc()
        ratio = inv.inventory_ratio(max_usd)
        # Block adding to short when ratio < -inventory_clear_threshold
        return ratio > -settings.inventory_clear_threshold

    # ── Halt control ──────────────────────────────────────────────────────

    def halt(self, reason: str, detail: str = "") -> None:
        """Halt trading. reason must match HaltReason enum values."""
        if not self.halted:
            log.critical("trading_halted", reason=reason, detail=detail, bankroll=self.bankroll)
            self.halted = True
            self.halt_reason = f"{reason}: {detail}" if detail else reason
            # Persist audit event
            asyncio_create_task_safely(self._persist_halt_event("HALT", reason, detail))

    def resume(self, preserve_counters: bool = False, source: str = "MANUAL") -> str:
        """Resume trading.

        FIX #6: `preserve_counters=True` keeps daily_pnl + consecutive_losses
        intact. Use this when resuming from transient halts (stale data).
        Use `preserve_counters=False` (default) for manual resumes — resets
        risk counters so user has clean slate after investigating.

        v1.0.50 FIX (BUG-26): added `source` parameter so callers can
        distinguish manual resume (user clicked Resume) from auto-resume
        (WS recovered from STALE_DATA halt). Previously the halt event
        was always logged as "MANUAL" even for automatic resumes.

        Returns previous halt_reason.
        """
        prev = self.halt_reason
        self.halted = False
        self.halt_reason = ""
        if not preserve_counters:
            self.consecutive_losses = 0
            # NOTE: daily_pnl is NOT reset here — only rolls over at UTC midnight
            # so the bot won't immediately re-halt on the same losing day.
            log.info("trading_resumed", counters_reset=True, source=source)
        else:
            log.info("trading_resumed", counters_reset=False, reason="transient_halt", source=source)
        asyncio_create_task_safely(self._persist_halt_event("RESUME", source, prev))
        return prev

    async def _persist_halt_event(self, event: str, reason: str, detail: str) -> None:
        try:
            from app.core.db import AsyncSessionLocal
            from app.db.models import HaltEvent

            async with AsyncSessionLocal() as db:
                db.add(
                    HaltEvent(
                        event=event,
                        reason=reason,
                        detail=detail[:500],
                        bankroll_at_event=self.bankroll,
                    )
                )
                await db.commit()
        except Exception as e:
            log.debug("halt_event_persist_failed", error=str(e))

    # ── Status ────────────────────────────────────────────────────────────

    @property
    def status(self) -> dict:
        total_realized = sum(inv.realized_pnl for inv in self.inventories.values())
        total_inventory_usd = sum(inv.net_usdc_at_entry for inv in self.inventories.values())
        return {
            "bankroll_usdc": round(self.bankroll, 4),
            "starting_balance_usdc": round(self.starting_balance, 2),
            "total_realized_pnl": round(total_realized, 4),
            "daily_pnl_usdc": round(self.daily_pnl, 4),
            "daily_pnl_date": self.daily_pnl_date,
            "total_inventory_usd": round(total_inventory_usd, 4),
            "consecutive_losses": self.consecutive_losses,
            "halted": self.halted,
            "halt_reason": self.halt_reason,
            "max_inventory_usdc": self.max_inventory_usdc(),
            "markets": {
                tid: {
                    "name": inv.market_name,
                    "net_tokens": round(inv.net_tokens, 4),
                    "net_usdc": round(inv.net_usdc_at_entry, 4),
                    "avg_entry": round(inv.avg_entry_price, 4),
                    "realized_pnl": round(inv.realized_pnl, 4),
                    "unrealized_pnl": None,  # filled by caller with current mid
                    "buys": inv.fill_count_buy,
                    "sells": inv.fill_count_sell,
                    # v1.0.50 FIX (BUG-25): age_sec was computed from open_time
                    # even when net_tokens=0 (flat position). Showed stale age
                    # for closed positions. Now: 0 when flat, real age when open.
                    "age_sec": round(_now_monotonic() - inv.open_time, 0)
                    if (inv.open_time and abs(inv.net_tokens) > 0.0001)
                    else 0,
                }
                for tid, inv in self.inventories.items()
            },
        }


# ── Module-level helpers ─────────────────────────────────────────────────


def _now_monotonic() -> float:
    """Avoid importing time at module level for testability."""
    import time

    return time.monotonic()


def asyncio_create_task_safely(coro) -> None:
    """Create a background task without awaiting it. Safe in sync context."""
    try:
        import asyncio

        loop = asyncio.get_running_loop()
        loop.create_task(coro)
    except RuntimeError:
        # No running loop — close the coroutine to avoid 'never awaited' warning
        coro.close()
