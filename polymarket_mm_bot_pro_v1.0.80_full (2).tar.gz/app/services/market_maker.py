"""
app/services/market_maker.py — Professional MM engine.

Combines:
  - Avellaneda-Stoikov reservation price (inventory-aware fair price)
  - Kyle's lambda spread multiplier (order-book imbalance aware)
  - Multi-level quoting (3 price levels)
  - Inventory skew + aging discount
  - Circuit breakers + adverse selection
  - Yes/No hedging (condition_id pairs)

Two modes:
  PAPER : realistic fill simulation (with adverse selection, competition, latency)
  LIVE  : real orders via py-clob-client with EIP-712 signing

Bot starts PAUSED. User must click "Start Trading" via /api/start.
"""
from __future__ import annotations

import asyncio
import random
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from app.core.config import settings
from app.core.logging import get_logger
from app.core.metrics import (
    ACTIVE_QUOTES,
    ADVERSE_TRIGGERS,
    BANKROLL_USD,
    CYCLE_LATENCY_SEC,
    CYCLES_TOTAL,
    DAILY_PNL_USD,
    FILLS_TOTAL,
    HALTED,
    INVENTORY_RATIO,
    INVENTORY_USD,
    KYLE_LAMBDA,
    RESERVATION_PRICE,
    ROUND_TRIPS_TOTAL,
    SPREAD_CENTS,
)
from app.db.models import OrderMode, QuoteStatus, Side, Trade
from app.services.clob_client import ClobService, MarketBook, OrderResult
from app.services.inventory_manager import InventoryManager
from app.services.pricing.avellaneda_stoikov import AvellanedaStoikov
from app.services.pricing.kyle_lambda import KyleLambda
from app.services.pricing.spread_optimizer import SpreadOptimizer
from app.services.risk.risk_manager import RiskManager

log = get_logger(__name__)


@dataclass
class ActiveQuote:
    """Tracks one level of an actively-placed quote for a market."""

    token_id: str
    level: int  # 1, 2, or 3
    bid_price: float | None
    ask_price: float | None
    mid_at_place: float
    size_usdc: float
    reservation_price: float
    spread_cents: float
    placed_at: float = field(default_factory=time.monotonic)
    bid_filled: bool = False
    ask_filled: bool = False
    bid_order_id: str | None = None
    ask_order_id: str | None = None


class MarketMaker:
    """Main MM engine. Runs a requote loop."""

    def __init__(
        self,
        clob: ClobService,
        inventory: InventoryManager,
        risk: RiskManager,
    ) -> None:
        self.clob = clob
        self.inventory = inventory
        self.risk = risk

        # active_quotes: token_id → list of ActiveQuote (one per level)
        self.active_quotes: dict[str, list[ActiveQuote]] = {}
        self._task: asyncio.Task | None = None
        self._cleanup_task: asyncio.Task | None = None
        self._poll_task: asyncio.Task | None = None
        self._liquidation_task: asyncio.Task | None = None  # v1.0.38
        self._persistence_task: asyncio.Task | None = None  # v1.0.72
        self._running = False
        self._cycle_count = 0
        self._fill_count = 0  # Loaded from DB on start()
        self._round_trip_count = 0
        self._liquidation_count = 0  # v1.0.38: tracks forced liquidations
        # v1.0.59 (BUG-N9): monotonic-clock timestamp of last auto-refill.
        # Replaces the old `cycle_count % 30 == 0` throttle (≈30s) which
        # churned markets every 30s. Now throttled by auto_refill_cooldown_sec
        # (default 300s = 5 min). Initialized to -inf so the first refill can
        # happen immediately on startup (gives the bot a chance to populate
        # markets before the cooldown kicks in).
        self._last_auto_refill_mono: float = -float("inf")

        # Bot starts PAUSED. User clicks "Start Trading" to begin.
        self._trading_paused = True

        # Pricing models
        self._as_calc = AvellanedaStoikov()
        self._kyle = KyleLambda()

        # Yes/No hedging pairs: condition_id → {"yes": token_id, "no": token_id}
        self._condition_pairs: dict[str, dict[str, str]] = {}

        # Live mode: pending orders awaiting fill confirmation
        self._pending_orders: dict[str, dict[str, Any]] = {}

        # Stats
        self._hedge_attempts = 0
        self._hedge_fills = 0

    # ── Lifecycle ─────────────────────────────────────────────────────────

    async def start(self) -> None:
        self._running = True

        # v1.0.52 FIX: explicitly enforce paused state at startup.
        # Previously _trading_paused was only set in __init__, which could
        # be reset by accident. Now start() forces it based on settings.
        # Default: PAUSED — user must click "Start Trading".
        self._trading_paused = not settings.auto_start_trading
        if self._trading_paused:
            log.warning(
                "bot_started_PAUSED",
                message="Bot is PAUSED. Click 'Start Trading' in the dashboard to begin quoting.",
                auto_start_trading=settings.auto_start_trading,
            )
        else:
            log.warning(
                "bot_started_TRADING",
                message="Bot auto-started (AUTO_START_TRADING=true). Quotes will be placed immediately.",
                auto_start_trading=settings.auto_start_trading,
            )

        # Load fill_count from DB (survives bot restarts)
        try:
            from app.core.db import AsyncSessionLocal
            from sqlalchemy import select, func
            from app.db.models import Trade
            async with AsyncSessionLocal() as db:
                result = await db.execute(select(func.count(Trade.id)))
                self._fill_count = result.scalar() or 0
                log.info("fill_count_loaded_from_db", fill_count=self._fill_count)
        except Exception as e:
            log.debug("fill_count_load_failed", error=str(e))

        # v1.0.72 (BUG-N23): Load inventory state from DB (crash recovery)
        try:
            from app.core.db import AsyncSessionLocal
            async with AsyncSessionLocal() as db:
                restored = await self.inventory.load_state_from_db(db)
                if restored:
                    log.info(
                        "inventory_state_loaded_on_startup",
                        bankroll=round(self.inventory.bankroll, 2),
                        positions=len(self.inventory.inventories),
                    )
        except Exception as e:
            log.warning("inventory_state_load_failed", error=str(e))

        self._task = asyncio.create_task(self._requote_loop(), name="mm_loop")
        self._cleanup_task = asyncio.create_task(self._db_cleanup_loop(), name="db_cleanup")
        if not settings.paper_trading:
            self._poll_task = asyncio.create_task(self._poll_orders_loop(), name="mm_poll")
        # v1.0.38: active inventory liquidation — aggressively clears stuck positions
        if settings.inventory_liquidation_enabled:
            self._liquidation_task = asyncio.create_task(
                self._liquidation_loop(), name="mm_liquidation"
            )
        # v1.0.72 (BUG-N23): State persistence — save every 60s for crash recovery
        self._persistence_task = asyncio.create_task(
            self._state_persistence_loop(), name="mm_persistence"
        )
        log.info(
            "market_maker_started",
            mode="LIVE" if not settings.paper_trading else "PAPER",
            interval=settings.requote_interval_sec,
            fill_count=self._fill_count,
            liquidation_enabled=settings.inventory_liquidation_enabled,
            trading_paused=self._trading_paused,
        )

    async def stop(self) -> None:
        """Stop the market maker and all background tasks.

        v1.0.49 FIX (BUG-21): previously `except (CancelledError, Exception):
        pass` silently swallowed ALL exceptions from background tasks. If a
        task crashed with a real error (DB failure, network issue), it was
        never logged — making debugging impossible. Now we separate
        CancelledError (expected during shutdown) from other exceptions
        (logged as warnings).
        """
        log.info("market_maker_stopping")
        self._running = False
        # v1.0.72 (BUG-N23): Save state before shutdown
        try:
            from app.core.db import AsyncSessionLocal
            async with AsyncSessionLocal() as db:
                await self.inventory.save_state_to_db(db)
                log.info("inventory_state_saved_on_shutdown")
        except Exception as e:
            log.warning("inventory_state_save_failed_on_shutdown", error=str(e))
        # Cancel all active quotes
        for tid in list(self.active_quotes.keys()):
            await self._cancel_all_levels(tid)
        task_names = {
            self._task: "requote_loop",
            self._cleanup_task: "db_cleanup",
            self._poll_task: "poll_orders",
            self._liquidation_task: "liquidation",
            self._persistence_task: "persistence",
        }
        for task in (self._task, self._cleanup_task, self._poll_task, self._liquidation_task, self._persistence_task):
            if task:
                task_name = task_names.get(task, "unknown")
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass  # expected during shutdown
                except Exception as e:
                    # v1.0.49 (BUG-21): log unexpected exceptions instead of
                    # silently swallowing them. Helps diagnose crashes.
                    log.warning(
                        "task_stopped_with_error",
                        task=task_name,
                        error=str(e),
                        error_type=type(e).__name__,
                    )
        log.info("market_maker_stopped")

    # ── User control ──────────────────────────────────────────────────────

    def start_trading(self) -> None:
        """User clicked 'Start Trading'."""
        self._trading_paused = False
        if self.inventory.halted and "USER_PAUSE" in (self.inventory.halt_reason or ""):
            self.inventory.resume()
        log.info("trading_started_by_user")

    def stop_trading(self) -> None:
        """User clicked 'Pause' — cancel all quotes immediately."""
        self._trading_paused = True
        for tid in list(self.active_quotes.keys()):
            asyncio.create_task(self._cancel_all_levels(tid))
        log.info("trading_paused_by_user")

    async def start_live_polling(self) -> None:
        """v1.0.39: start the LIVE fill-polling task at runtime.

        Previously _poll_orders_loop was only created in start() when the bot
        booted directly into LIVE mode. If the bot started in PAPER and the
        user toggled to LIVE via /api/mode/toggle, _poll_task was never
        created, so fills were never detected even after PATCH-1.
        This method is idempotent — safe to call multiple times.
        """
        if settings.paper_trading:
            log.warning("start_live_polling_called_in_paper_mode")
            return
        if self._poll_task is not None and not self._poll_task.done():
            return  # already running
        self._poll_task = asyncio.create_task(
            self._poll_orders_loop(), name="mm_poll"
        )
        log.info("live_polling_started_at_runtime")

    @property
    def is_trading(self) -> bool:
        return not self._trading_paused and not self.inventory.halted

    # ── Main loop ─────────────────────────────────────────────────────────

    async def _requote_loop(self) -> None:
        # v1.0.52: track paused cycles to log "waiting" periodically
        _paused_cycle = 0
        while self._running:
            try:
                t0 = time.monotonic()
                if self._trading_paused:
                    # v1.0.52: log every 30 cycles (~30s) so user can see
                    # the bot is alive but waiting for "Start Trading"
                    _paused_cycle += 1
                    if _paused_cycle % 30 == 1:
                        log.info(
                            "waiting_for_start_trading",
                            paused_cycles=_paused_cycle,
                            message="Bot is PAUSED. Click 'Start Trading' to begin.",
                        )
                    await asyncio.sleep(settings.requote_interval_sec)
                    continue
                _paused_cycle = 0  # reset when not paused
                if self.inventory.halted:
                    # Check if halt was due to stale data — auto-resume when WS recovers
                    if "STALE_DATA" in (self.inventory.halt_reason or ""):
                        if self.clob.last_ws_msg_age < 10:
                            # v1.0.50 (BUG-26): pass source="AUTO" so the halt
                            # event is logged correctly (not as "MANUAL").
                            self.inventory.resume(preserve_counters=True, source="AUTO")
                            log.info("ws_recovered_resuming")
                            continue
                    # Cancel all quotes while halted
                    for tid in list(self.active_quotes.keys()):
                        await self._cancel_all_levels(tid)
                    await asyncio.sleep(settings.requote_interval_sec)
                    continue
                await self._cycle()
                CYCLE_LATENCY_SEC.observe(time.monotonic() - t0)
            except asyncio.CancelledError:
                break
            except Exception as e:
                log.exception("mm_cycle_error", error=str(e))
            await asyncio.sleep(settings.requote_interval_sec)

    async def _cycle(self) -> None:
        self._cycle_count += 1
        CYCLES_TOTAL.inc()

        # ── Global halt check ──
        should_halt, reason = self.risk.should_halt()
        if should_halt:
            self.inventory.halt(
                reason=reason.split(":")[0],
                detail=reason.split(":", 1)[1] if ":" in reason else "",
            )
            for tid in list(self.active_quotes.keys()):
                await self._cancel_all_levels(tid)
            HALTED.set(1)
            return

        # Auto-refill markets if too few
        await self._maybe_auto_refill()

        # ── Build hedging pairs every 30 cycles ──
        if self._cycle_count % 30 == 1 and settings.hedging_enabled:
            self._build_hedging_pairs()

        # ── Process each market ──
        for tid, book in list(self.clob.books.items()):
            await self._process_market(tid, book)

        # ── Update metrics ──
        BANKROLL_USD.set(self.inventory.bankroll)
        DAILY_PNL_USD.set(self.inventory.daily_pnl)
        total_inv = sum(inv.net_usdc_at_entry for inv in self.inventory.inventories.values())
        INVENTORY_USD.set(total_inv)
        ACTIVE_QUOTES.set(sum(len(qs) for qs in self.active_quotes.values()))
        HALTED.set(1 if self.inventory.halted else 0)

    async def _maybe_auto_refill(self) -> None:
        """If quotable markets dropped below USER'S target, discover new ones.

        v1.0.42: hard cap = target × 2 (prevented infinite refill, but still
                 allowed 2 markets when user wanted 1).
        v1.0.46 FIX (BUG-1): hard cap = target. If user wants 1 market, the
                 bot keeps at most 1. This means if the single market becomes
                 non-quotable (spread < min), the bot now actively REPLACES it
                 rather than keeping it + adding a buffer.
        v1.0.46 FIX (BUG-7): auto_pick_count is now restored via try/finally
                 even when discover_markets() raises.
        v1.0.59 FIX (BUG-N9): replaced `cycle_count % 30` throttle (≈30s)
                 with monotonic-clock cooldown (settings.auto_refill_cooldown_sec,
                 default 300s = 5 min). Prevents churning when ALL Polymarket
                 markets have tight spreads — old behavior burned 19 refill
                 cycles in 17 min getting back the same non-quotable markets.
        """
        # Count QUOTABLE markets (spread >= min, both sides present)
        quotable = sum(
            1 for book in self.clob.books.values()
            if book.bids and book.asks and book.spread * 100 >= settings.spread_min_cents
        )
        current = len(self.clob.books)
        # Dynamic target: adjust based on current bankroll
        if settings.auto_pick_dynamic:
            target = max(1, int(self.inventory.bankroll / 10))
        else:
            target = settings.auto_pick_count

        # Refill only if quotable < target
        if quotable >= target:
            return

        # v1.0.59 (BUG-N9): time-based throttle replaces cycle_count % 30.
        # First call after startup is allowed immediately (_last_auto_refill_mono
        # initialized to -inf in __init__). Subsequent calls are throttled by
        # auto_refill_cooldown_sec. This gives markets time to naturally widen
        # their spreads before we churn them.
        now_mono = time.monotonic()
        elapsed = now_mono - self._last_auto_refill_mono
        if elapsed < settings.auto_refill_cooldown_sec:
            return

        # v1.0.46 (BUG-1): HARD CAP = target (was target × 2).
        # If user set target=1, allow max 1 market. If the single market
        # becomes non-quotable, we REPLACE it (see replace logic below)
        # rather than keeping it and adding a buffer.
        if current >= target:
            # At cap and still not enough quotable markets → try to replace
            # the worst non-quotable market with a fresh one.
            self._last_auto_refill_mono = now_mono
            log.info(
                "auto_refill_throttle_passed",
                elapsed_sec=round(elapsed, 1) if elapsed != float("inf") else 0,
                cooldown_sec=settings.auto_refill_cooldown_sec,
                path="replace",
                quotable=quotable,
                target=target,
            )
            await self._replace_non_quotable_markets(target)
            return

        self._last_auto_refill_mono = now_mono
        log.info(
            "auto_refill_throttle_passed",
            elapsed_sec=round(elapsed, 1) if elapsed != float("inf") else 0,
            cooldown_sec=settings.auto_refill_cooldown_sec,
            path="add",
            quotable=quotable,
            target=target,
        )

        log.info(
            "auto_refill_started",
            total_markets=current,
            quotable_markets=quotable,
            target=target,
            hard_cap=target,
            bankroll=round(self.inventory.bankroll, 2),
            dynamic=settings.auto_pick_dynamic,
            reason=f"fewer than {target} quotable markets (bankroll-based)",
        )
        # v1.0.46 FIX (BUG-7): try/finally restores auto_pick_count even on
        # exception. Previously discover_markets() raising would leave the
        # setting permanently mutated.
        old_count = settings.auto_pick_count
        settings.auto_pick_count = max(1, target - quotable)
        try:
            new_markets = await self.clob.discover_markets()
        finally:
            settings.auto_pick_count = old_count
        added = 0
        for info in new_markets:
            if info.token_id not in self.clob.books:
                self.clob.books[info.token_id] = MarketBook(token_id=info.token_id)
                self.clob.markets[info.token_id] = info
                await self.clob._feed.subscribe(info.token_id)
                added += 1
        if added > 0:
            await self.clob._refresh_all_books()
            log.info("auto_refill_done", added=added, quotable_before=quotable)

    async def _replace_non_quotable_markets(self, target: int) -> None:
        """v1.0.46 (BUG-1): replace non-quotable markets when at hard cap.

        When current >= target but quotable < target, we can't add more
        markets (hard cap reached). Instead we identify the WORST
        non-quotable market (widest spread or empty book), drop it, and
        discover a fresh replacement. This prevents the bot from being
        stuck indefinitely on a dead market.
        """
        # Find non-quotable markets (spread < min or missing side)
        non_quotable: list[tuple[str, float]] = []  # (token_id, spread_cents)
        for tid, book in self.clob.books.items():
            if not book.bids or not book.asks:
                # Empty book — worst kind, prioritize for replacement
                non_quotable.append((tid, 0.0))
            elif book.spread * 100 < settings.spread_min_cents:
                non_quotable.append((tid, book.spread * 100))

        if not non_quotable:
            return  # all markets are quotable, nothing to replace

        # Sort: empty books (spread=0) first, then by tightest spread
        non_quotable.sort(key=lambda x: x[1])

        # Replace at most (target - quotable) markets
        quotable = sum(
            1 for book in self.clob.books.values()
            if book.bids and book.asks and book.spread * 100 >= settings.spread_min_cents
        )
        to_replace = min(target - quotable, len(non_quotable))
        if to_replace <= 0:
            return

        log.info(
            "auto_refill_replace_started",
            non_quotable_count=len(non_quotable),
            to_replace=to_replace,
            target=target,
        )

        # Don't replace markets that have open inventory (would orphan it).
        # We only replace flat markets (no net position).
        replaced = 0
        for tid, _spread in non_quotable:
            if replaced >= to_replace:
                break
            inv = self.inventory.get_inventory(tid)
            if abs(inv.net_tokens) > 0.5:
                # Has open position — skip to avoid orphaning inventory.
                # Liquidation loop will clear it via aging.
                continue

            # Cancel any quotes on this market
            if tid in self.active_quotes:
                await self._cancel_all_levels(tid)
            # Unsubscribe WS
            try:
                await self.clob._feed.unsubscribe(tid)
            except Exception:
                pass
            # Remove from books + markets
            self.clob.books.pop(tid, None)
            self.clob.markets.pop(tid, None)
            self.inventory.inventories.pop(tid, None)
            self._as_calc.clear(tid)
            self._kyle.clear(tid)
            self.risk.adverse_selection.clear(tid)
            self.risk.circuit_breakers.clear_token(tid)
            replaced += 1
            log.info("auto_refill_dropped_market", token=tid[:12])

        if replaced == 0:
            return

        # Discover replacements
        old_count = settings.auto_pick_count
        settings.auto_pick_count = replaced
        try:
            new_markets = await self.clob.discover_markets()
        except Exception as e:
            log.debug("auto_refill_replace_discover_error", error=str(e))
            new_markets = []
        finally:
            settings.auto_pick_count = old_count

        added = 0
        for info in new_markets:
            if info.token_id not in self.clob.books:
                self.clob.books[info.token_id] = MarketBook(token_id=info.token_id)
                self.clob.markets[info.token_id] = info
                await self.clob._feed.subscribe(info.token_id)
                added += 1
        if added > 0:
            await self.clob._refresh_all_books()
            log.info(
                "auto_refill_replace_done",
                replaced=replaced,
                added=added,
                total=len(self.clob.books),
            )

    # ── Per-market processing ─────────────────────────────────────────────

    async def _process_market(self, token_id: str, book: MarketBook) -> None:
        """Update quotes for one market."""
        if not book.bids or not book.asks:
            log.debug("market_skip_empty_book", token=token_id[:12])
            return

        info = self.clob.markets.get(token_id)
        market_name = info.question[:60] if info else token_id[:12]

        # ── Market spread (visible in logs) ──
        market_bid = book.best_bid
        market_ask = book.best_ask
        market_spread_cents = round(book.spread * 100, 2)

        # ── TTR (Time To Resolution) — hours until market ends ──
        ttr_hours = None
        if info and info.end_date_ts > 0:
            now_ts = datetime.now(timezone.utc).timestamp()
            ttr = info.end_date_ts - now_ts
            ttr_hours = round(ttr / 3600, 1)

            # ── Pre-resolution exit ──
            if ttr < settings.pre_resolution_exit_sec:
                log.info(
                    "market_skip_pre_resolution",
                    market=market_name[:40],
                    ttr_hours=ttr_hours,
                    market_spread_cents=market_spread_cents,
                )
                await self._handle_pre_resolution(token_id, book, market_name)
                return

        # ── Market quality filter: skip if spread < spread_min_cents ──
        if market_spread_cents < settings.spread_min_cents:
            log.info(
                "market_skip_tight_spread",
                market=market_name[:40],
                market_spread_cents=market_spread_cents,
                min_required=settings.spread_min_cents,
            )
            if token_id in self.active_quotes:
                await self._cancel_all_levels(token_id)
            return

        # v1.0.71 (BUG-N22): Resolution detector — ринок майже resolved.
        # Якщо mid < 0.05 або mid > 0.95 → ціна майже 0 або 1 → resolution imminent.
        # Продати інвентар негайно (mid-based), поки є ліквідність.
        # Захищає від Australia-сценарію: ціна впала -94%, бот тримав позицію.
        if book.mid < 0.05 or book.mid > 0.95:
            inv_check = self.inventory.get_inventory(token_id)
            if abs(inv_check.net_tokens) > 0.5 and inv_check.net_tokens > 0:
                log.warning(
                    "resolution_detector_triggered",
                    market=market_name[:40],
                    mid=round(book.mid, 4),
                    net_tokens=round(inv_check.net_tokens, 2),
                    avg_entry=round(inv_check.avg_entry_price, 4),
                    reason="mid < 5¢ or > 95¢ — market near resolution, exit now",
                )
                await self._handle_resolution_exit(token_id, book, market_name)
                return
            # No inventory — just skip quoting on near-resolved market
            log.info(
                "market_skip_near_resolution",
                market=market_name[:40],
                mid=round(book.mid, 4),
                reason="mid < 5¢ or > 95¢ — near resolution, no inventory to exit",
            )
            if token_id in self.active_quotes:
                await self._cancel_all_levels(token_id)
            return

        # CRITICAL: Skip very low-priced markets (< 5¢) — token count explodes
        # At $0.004, $5 order = 1250 tokens, tiny price move = huge fake P&L
        if book.mid < 0.05:
            log.info(
                "market_skip_low_price",
                market=market_name[:40],
                mid=round(book.mid, 4),
                reason="price < 5¢ causes token explosion and fake P&L",
            )
            if token_id in self.active_quotes:
                await self._cancel_all_levels(token_id)
            return

        # ── Update A-S pricing ──
        self._as_calc.update(token_id, book.mid)
        self.risk.on_cycle(token_id, book.mid)

        # ── Adverse selection trigger check ──
        if self.risk.adverse_selection.check_trigger(token_id):
            ADVERSE_TRIGGERS.inc()
            log.info(
                "market_skip_adverse_selection",
                market=market_name[:40],
                market_spread_cents=market_spread_cents,
            )
            await self._cancel_all_levels(token_id)
            return

        # ── Risk decision ──
        decision = self.risk.should_quote(token_id, book)
        if not decision.allow_any:
            log.info(
                "market_skip_risk",
                market=market_name[:40],
                market_spread_cents=market_spread_cents,
                reasons=decision.reasons,
            )
            if token_id in self.active_quotes:
                await self._cancel_all_levels(token_id)
            return

        # ── Compute reservation price + optimal spread ──
        inv = self.inventory.get_inventory(token_id)
        max_inv_tokens = self.inventory.max_inventory_usdc() / max(book.mid, 0.01)
        reservation, sigma, inv_penalty = self._as_calc.compute(
            token_id=token_id,
            current_mid=book.mid,
            inventory_tokens=inv.net_tokens,
            max_inventory_tokens=max_inv_tokens,
        )

        # Kyle's lambda spread multiplier
        kyle_lambda_val, kyle_mult = self._kyle.update_and_compute(token_id, book)

        # Session-based multiplier
        session_mult, session_name = SpreadOptimizer.get_session_multiplier()

        # Inventory aging discount (for stale positions)
        aging_discount = self._compute_aging_discount(inv)

        # Final spread
        optimal_spread_cents = SpreadOptimizer.compute(
            base_spread_cents=settings.spread_cents,
            sigma=sigma,
            kyle_mult=kyle_mult,
            session_mult=session_mult,
            aging_discount_cents=aging_discount,
        )

        # ── Update Prometheus gauges ──
        RESERVATION_PRICE.labels(token_id=token_id[:12]).set(reservation)
        KYLE_LAMBDA.labels(token_id=token_id[:12]).set(kyle_lambda_val)
        INVENTORY_RATIO.labels(token_id=token_id[:12]).set(
            inv.inventory_ratio(self.inventory.max_inventory_usdc())
        )
        SPREAD_CENTS.labels(token_id=token_id[:12]).set(optimal_spread_cents)

        # ── Check fills on existing quotes ──
        existing = self.active_quotes.get(token_id)
        if existing:
            await self._check_fills(token_id, book, existing, market_name)
            # Cancel stale quotes (mid drifted or too old)
            existing = self.active_quotes.get(token_id, [])
            still_active: list[ActiveQuote] = []
            for q in existing:
                age = time.monotonic() - q.placed_at
                drift = abs(book.mid - q.mid_at_place)
                if age > 10 or drift > settings.requote_threshold_cents / 100:
                    await self._cancel_quote_level(token_id, q)
                else:
                    still_active.append(q)
            if still_active:
                self.active_quotes[token_id] = still_active
            else:
                self.active_quotes.pop(token_id, None)

        # ── Place new quotes if none active ──
        if token_id not in self.active_quotes or not self.active_quotes[token_id]:
            await self._place_multi_level_quotes(
                token_id=token_id,
                book=book,
                market_name=market_name,
                reservation=reservation,
                spread_cents=optimal_spread_cents,
                decision=decision,
                sigma=sigma,
                kyle_lambda=kyle_lambda_val,
                ttr_hours=ttr_hours,
            )

    async def _handle_resolution_exit(
        self, token_id: str, book: MarketBook, market_name: str
    ) -> None:
        """v1.0.71 (BUG-N22): Exit position when market near resolution.

        Triggered by resolution detector: mid < 0.05 or mid > 0.95.
        Sells at max(mid, entry+5¢) capped at ask-0.001 — same A+C logic
        as Exit All (BUG-N16) and liquidations (BUG-N17).

        Difference from _handle_pre_resolution:
        - pre_resolution: time-based (1h before end_date)
        - resolution_exit: price-based (mid near 0 or 1)

        Both protect from holding through resolution (Australia scenario).
        """
        if token_id in self.active_quotes:
            await self._cancel_all_levels(token_id)
        inv = self.inventory.get_inventory(token_id)
        if abs(inv.net_tokens) > 0.5 and inv.net_tokens > 0 and book.best_bid > 0:
            # A+C pricing (same as Exit All / liquidations)
            mid = (book.best_bid + book.best_ask) / 2.0 if book.best_ask > book.best_bid else book.best_bid
            target_mid = round(mid, 4)
            target_min = round(inv.avg_entry_price + 0.05, 4)
            sell_price = max(target_mid, target_min)
            sell_price = max(0.01, min(0.99, sell_price))
            if book.best_ask > 0:
                sell_price = min(sell_price, round(book.best_ask - 0.001, 4))
            size_usdc = abs(inv.net_tokens) * sell_price

            log.warning(
                "resolution_exit_sell",
                market=market_name[:40],
                mid=round(mid, 4),
                sell_price=round(sell_price, 4),
                avg_entry=round(inv.avg_entry_price, 4),
                net_tokens=round(inv.net_tokens, 2),
                size_usdc=round(size_usdc, 2),
                loss_cents=round((inv.avg_entry_price - sell_price) * 100, 2),
            )

            if settings.paper_trading:
                await self._record_fill(
                    token_id, "SELL", sell_price, size_usdc, market_name,
                    is_liquidation=True,
                )
            else:
                result = await self.clob.place_order(
                    token_id, "SELL", sell_price, size_usdc,
                    order_type="FAK", post_only=False,
                )
                if result.success:
                    await self._record_fill(
                        token_id, "SELL", sell_price, size_usdc, market_name,
                        is_liquidation=True,
                    )

    async def _handle_pre_resolution(
        self, token_id: str, book: MarketBook, market_name: str
    ) -> None:
        """Cancel quotes + liquidate inventory before market resolution.

        v1.0.39 FIX: in LIVE mode this must place a real order. Previously
        _record_fill was called directly (no order sent to Polymarket), so
        the bot decremented inventory/bankroll locally while the real
        position stayed open on-chain through resolution.
        """
        if token_id in self.active_quotes:
            log.warning("pre_resolution_exit", market=market_name[:40], ttr_hours=0)
            await self._cancel_all_levels(token_id)
        inv = self.inventory.get_inventory(token_id)
        if abs(inv.net_tokens) > 0.5:
            if inv.net_tokens > 0 and book.best_bid > 0:
                size_usdc = abs(inv.net_tokens) * book.best_bid
                if settings.paper_trading:
                    await self._record_fill(
                        token_id, "SELL", book.best_bid,
                        size_usdc, market_name, is_liquidation=True,
                    )
                else:
                    # LIVE: place a real FAK sell at best_bid (take what we can).
                    result = await self.clob.place_order(
                        token_id, "SELL", book.best_bid, size_usdc,
                        order_type="FAK", post_only=False,
                    )
                    if result.success:
                        raw = result.raw if isinstance(result.raw, dict) else {}
                        actual_price = book.best_bid
                        if raw.get("price"):
                            try:
                                actual_price = float(raw["price"])
                            except (TypeError, ValueError):
                                pass
                        actual_size = size_usdc
                        if raw.get("size_matched"):
                            try:
                                actual_size = float(raw["size_matched"])
                            except (TypeError, ValueError):
                                pass
                        await self._record_fill(
                            token_id, "SELL", actual_price, actual_size,
                            market_name, is_liquidation=True,
                        )
                        log.info(
                            "pre_resolution_liquidation_live",
                            market=market_name[:40],
                            order_id=result.order_id,
                            price=round(actual_price, 4),
                            size_usdc=round(actual_size, 2),
                        )
                    else:
                        log.error(
                            "pre_resolution_liquidation_failed_live",
                            market=market_name[:40],
                            error=result.error,
                            reason="position will go to resolution",
                        )
            elif inv.net_tokens < 0 and book.best_ask < 1:
                size_usdc = abs(inv.net_tokens) * book.best_ask
                if settings.paper_trading:
                    await self._record_fill(
                        token_id, "BUY", book.best_ask,
                        size_usdc, market_name, is_liquidation=True,
                    )
                else:
                    result = await self.clob.place_order(
                        token_id, "BUY", book.best_ask, size_usdc,
                        order_type="FAK", post_only=False,
                    )
                    if result.success:
                        raw = result.raw if isinstance(result.raw, dict) else {}
                        actual_price = book.best_ask
                        if raw.get("price"):
                            try:
                                actual_price = float(raw["price"])
                            except (TypeError, ValueError):
                                pass
                        actual_size = size_usdc
                        if raw.get("size_matched"):
                            try:
                                actual_size = float(raw["size_matched"])
                            except (TypeError, ValueError):
                                pass
                        await self._record_fill(
                            token_id, "BUY", actual_price, actual_size,
                            market_name, is_liquidation=True,
                        )
                        log.info(
                            "pre_resolution_buyback_live",
                            market=market_name[:40],
                            order_id=result.order_id,
                            price=round(actual_price, 4),
                            size_usdc=round(actual_size, 2),
                        )
                    else:
                        log.error(
                            "pre_resolution_buyback_failed_live",
                            market=market_name[:40],
                            error=result.error,
                            reason="short position will go to resolution",
                        )

    def _compute_aging_discount(self, inv) -> float:
        """Discount spread for stale positions to encourage liquidation."""
        if inv.net_tokens == 0 or inv.open_time == 0:
            return 0.0
        age_sec = time.monotonic() - inv.open_time
        if age_sec < settings.inventory_aging_threshold_sec:
            return 0.0
        steps_past = int((age_sec - settings.inventory_aging_threshold_sec) / 60.0)
        discount = steps_past * settings.inventory_aging_discount_step_cents
        return min(discount, settings.inventory_aging_max_discount_cents)

    # ── Multi-level quote placement ───────────────────────────────────────

    async def _place_multi_level_quotes(
        self,
        token_id: str,
        book: MarketBook,
        market_name: str,
        reservation: float,
        spread_cents: float,
        decision,
        sigma: float,
        kyle_lambda: float,
        ttr_hours: float | None = None,
    ) -> None:
        """Place up to 3 levels of bid/ask quotes around reservation price.

        FIX: Polymarket minimum order size is $5 USDC. If a level's computed
        size falls below $5, we bump it to $5 (rather than skipping) so the
        order is accepted. This means total quote size can exceed base_size
        when multi-level is enabled with small base — that's expected.
        """
        # Polymarket hard minimum (live orders below this are rejected)
        POLYMARKET_MIN_ORDER_USDC = 5.0

        # Inventory skew (shifts center)
        skew_cents = self.inventory.quote_skew(token_id)
        skew_dollars = skew_cents / 100.0

        # Auto-scale size with bankroll (capped)
        scaling = min(
            settings.order_size_autoscale_max_mult,
            self.inventory.bankroll / max(self.inventory.starting_balance, 1.0),
        )
        base_size = settings.order_size_usdc * scaling
        base_size = max(
            settings.order_size_min_usdc,
            min(base_size, settings.order_size_usdc * settings.order_size_autoscale_max_mult),
        )

        # v1.0.63 (BUG-N14): Volatility-scaled sizing.
        # Professional MM scales size INVERSELY to σ: high vol → smaller size,
        # low vol → larger size. This prevents accumulation of large positions
        # in volatile markets (e.g. Switzerland Round of 16, -$166 loss).
        # sigma comes from A-S calculator (avellaneda_stoikov.py:_estimate_sigma).
        if settings.order_size_volatility_scaling and sigma > 0:
            ref_vol = settings.order_size_reference_volatility
            eff_sigma = max(sigma, settings.as_min_volatility)
            vol_mult = ref_vol / eff_sigma
            vol_mult = max(
                settings.order_size_min_vol_mult,
                min(vol_mult, settings.order_size_max_vol_mult),
            )
            scaled_size = base_size * vol_mult
            # Don't shrink below Polymarket $5 minimum
            scaled_size = max(scaled_size, settings.order_size_min_usdc)
            if abs(vol_mult - 1.0) > 0.05:
                log.info(
                    "order_size_volatility_scaled",
                    market=market_name[:30],
                    sigma=round(sigma, 4),
                    vol_mult=round(vol_mult, 3),
                    base_size=round(base_size, 2),
                    scaled_size=round(scaled_size, 2),
                )
            base_size = scaled_size

        # Build levels
        levels = SpreadOptimizer.compute_levels(spread_cents)
        new_quotes: list[ActiveQuote] = []

        # Current inventory for logging
        inv = self.inventory.get_inventory(token_id)
        inventory_usdc = round(inv.net_usdc_at_entry, 2)
        inventory_tokens = round(inv.net_tokens, 4)

        # v1.0.43 FIX: track tokens already committed to asks across levels.
        # Previously each level independently checked `inv.net_tokens > 0`
        # and placed an ask. With 3 levels × ~$5 ask each, total ask tokens
        # could exceed actual holdings (e.g. 30.93 tokens to sell when only
        # 23.94 owned). In PAPER this was a warning; in LIVE Polymarket
        # rejects the 2nd/3rd ask. Now we decrement remaining_tokens as we
        # commit each level's ask.
        remaining_tokens = inv.net_tokens

        for level_idx, (capture_cents, size_pct) in enumerate(levels, start=1):
            level_size = base_size * size_pct
            # FIX: enforce Polymarket $5 minimum per level
            if level_size < POLYMARKET_MIN_ORDER_USDC:
                level_size = POLYMARKET_MIN_ORDER_USDC
                log.info(
                    "level_size_bumped_to_minimum",
                    market=market_name[:30],
                    level=level_idx,
                    original_size=round(base_size * size_pct, 2),
                    bumped_to=POLYMARKET_MIN_ORDER_USDC,
                    reason="Polymarket minimum order = $5",
                )

            # ── JOIN-MARKET LOGIC (fixed v1.0.18) ───────────────────────────
            # Bot places quotes INSIDE the market spread, with FIXED gap from
            # each edge. Gap does NOT scale with optimal_spread — it's a fixed
            # distance that creates the user-requested spread pattern.
            #
            # User request: market 0.3200-0.3400 (2¢) → our 0.3215-0.3385 (1.7¢)
            # So Level 1 gap = 0.15¢ → our_spread = 2¢ - 2×0.15¢ = 1.7¢ ✅
            #
            # Levels (fixed gaps, NOT proportional to optimal spread):
            #   Level 1 (tightest): gap = 0.15¢ → our_spread = market - 0.30¢
            #   Level 2 (middle):   gap = 0.30¢ → our_spread = market - 0.60¢
            #   Level 3 (widest):   gap = 0.45¢ → our_spread = market - 0.90¢
            market_bid = book.best_bid
            market_ask = book.best_ask
            market_spread = market_ask - market_bid

            # FIXED gap per level (in dollars) — from capture_cents / 100
            # capture_cents comes from compute_levels: 0.6/1.2/1.8 for L1/L2/L3
            # when optimal=4¢. But we want FIXED 0.15/0.30/0.45 gaps.
            # So use the CAPTURE PERCENTAGE (0.15/0.30/0.45) directly as cents.
            if settings.multi_level_enabled:
                # Use fixed gaps: 0.15¢, 0.30¢, 0.45¢ for L1/L2/L3
                fixed_gaps = {1: 0.15, 2: 0.30, 3: 0.45}
                gap_cents = fixed_gaps.get(level_idx, 0.15)
            else:
                # Single level: use half the optimal spread as gap
                gap_cents = spread_cents / 2 * 0.15  # 15% of optimal as gap

            gap_dollars = gap_cents / 100.0
            # Cap gap to 40% of market spread (leave room for our spread)
            gap_dollars = min(gap_dollars, market_spread * 0.40)

            # Compute target bid/ask: join market edges, move inward by gap
            effective_mid = (market_bid + market_ask) / 2 + skew_dollars
            target_bid = effective_mid - (market_spread / 2) + gap_dollars
            target_ask = effective_mid + (market_spread / 2) - gap_dollars

            # Hard clamp: never outside market
            if target_bid <= market_bid:
                target_bid = market_bid + 0.0005  # 0.05¢ inside
            if target_ask >= market_ask:
                target_ask = market_ask - 0.0005
            if target_bid >= target_ask:
                continue  # invalid (spread too tight)

            # Clamp to valid range
            target_bid = max(0.01, min(0.99, target_bid))
            target_ask = max(0.01, min(0.99, target_ask))

            # Inventory-aware side blocking
            bid_price = target_bid if decision.allow_bid else None
            ask_price = target_ask if decision.allow_ask else None

            # CRITICAL: Don't place bid if bankroll can't cover it
            # (simulates Polymarket API rejecting order if insufficient balance)
            if bid_price is not None and self.inventory.bankroll < level_size:
                log.debug(
                    "bid_blocked_insufficient_balance",
                    market=market_name[:30],
                    level=level_idx,
                    level_size=round(level_size, 2),
                    bankroll=round(self.inventory.bankroll, 2),
                )
                bid_price = None

            # CRITICAL: Don't place ask if not enough tokens to sell
            # In LIVE: Polymarket API rejects SELL if insufficient token balance
            # (no traditional shorting on CTF — can only sell what you own)
            # v1.0.43: use remaining_tokens (decremented across levels) instead
            # of inv.net_tokens, so we don't commit to sell more than we own.
            inv = self.inventory.get_inventory(token_id)
            # tokens this level would sell at current ask price
            tokens_needed_for_this_level = level_size / max(ask_price or 0.01, 0.01)
            if ask_price is not None and remaining_tokens <= 0:
                # No tokens to sell (or already short) — block ask
                log.debug(
                    "ask_blocked_no_tokens",
                    market=market_name[:30],
                    level=level_idx,
                    net_tokens=round(inv.net_tokens, 4),
                    remaining_tokens=round(remaining_tokens, 4),
                    reason="no tokens to sell (LIVE API would reject)",
                )
                ask_price = None
            elif ask_price is not None and remaining_tokens < tokens_needed_for_this_level:
                # v1.0.43: Not enough tokens to cover this level's full ask size.
                # Two options: (a) skip this level, (b) reduce size to remaining.
                # We choose (b) — sell what we have, but only if >= $5 (Polymarket min).
                # Otherwise skip (LIVE API rejects orders < $5).
                reduced_size = remaining_tokens * (ask_price or 0.01)
                if reduced_size >= POLYMARKET_MIN_ORDER_USDC:
                    log.info(
                        "ask_size_reduced_to_remaining_tokens",
                        market=market_name[:30],
                        level=level_idx,
                        original_size_usdc=round(level_size, 2),
                        reduced_size_usdc=round(reduced_size, 2),
                        remaining_tokens=round(remaining_tokens, 4),
                        reason="would exceed available tokens; reduced to remaining",
                    )
                    level_size = reduced_size
                    # Don't decrement remaining_tokens here — will do after place
                else:
                    log.debug(
                        "ask_skipped_insufficient_tokens",
                        market=market_name[:30],
                        level=level_idx,
                        remaining_tokens=round(remaining_tokens, 4),
                        tokens_needed=round(tokens_needed_for_this_level, 4),
                        reduced_size_usdc=round(reduced_size, 2),
                        reason="remaining tokens below $5 Polymarket minimum",
                    )
                    ask_price = None

            # v1.0.43: decrement remaining_tokens by the tokens this ask commits.
            # This must happen AFTER the checks above but BEFORE the next level.
            if ask_price is not None:
                tokens_committed = level_size / max(ask_price, 0.01)
                remaining_tokens -= tokens_committed

            # v1.0.38: Aggressive ask pricing for aged positions.
            # Previously: bot blocked ALL sells below entry (v1.0.26), then
            # only "allowed" them after aging — but the ask price was still
            # computed from market spread join logic (near market ask), so
            # it never actually filled when price had dropped.
            #
            # NOW: when position is aged, actively LOWER the ask to be near
            # the market bid, ensuring it actually fills and clears inventory.
            if ask_price is not None and inv.net_tokens > 0:
                age_sec = time.monotonic() - inv.open_time if inv.open_time else 0
                is_aged = age_sec > settings.inventory_aging_threshold_sec
                is_very_aged = age_sec >= settings.inventory_liquidation_aggressive_age_sec

                if is_very_aged and book.best_bid > 0:
                    # Very aged: sell at market_bid + 0.001 (front of queue)
                    aggressive_ask = min(
                        book.best_bid + 0.001,
                        book.best_ask - 0.001,
                    )
                    aggressive_ask = max(0.01, min(0.99, aggressive_ask))
                    if aggressive_ask < ask_price:
                        log.info(
                            "ask_aggressive_very_aged",
                            market=market_name[:30],
                            level=level_idx,
                            old_ask=round(ask_price, 4),
                            new_ask=round(aggressive_ask, 4),
                            market_bid=round(book.best_bid, 4),
                            age_sec=round(age_sec, 0),
                            reason="position very aged, lowering ask to market bid",
                        )
                        ask_price = aggressive_ask
                elif is_aged and book.best_bid > 0:
                    # Aged: lower ask toward market bid (but not below entry
                    # unless necessary). This encourages fills.
                    target_aggressive = book.best_bid + (book.spread * 0.25)
                    if target_aggressive < ask_price:
                        ask_price = target_aggressive
                        log.debug(
                            "ask_lowered_aged",
                            market=market_name[:30],
                            level=level_idx,
                            new_ask=round(ask_price, 4),
                            age_sec=round(age_sec, 0),
                        )

                # Final check: block sell below entry ONLY if not aged
                # (aged positions are allowed to sell at a loss — that's
                # the whole point of the aging mechanism)
                if not is_aged and ask_price < inv.avg_entry_price:
                    log.debug(
                        "ask_blocked_below_entry",
                        market=market_name[:30],
                        level=level_idx,
                        ask_price=round(ask_price, 4),
                        avg_entry=round(inv.avg_entry_price, 4),
                        age_sec=round(age_sec, 0),
                        reason="selling below entry would realize loss (not aged yet)",
                    )
                    ask_price = None
                elif is_aged and ask_price < inv.avg_entry_price:
                    log.info(
                        "ask_aged_selling_below_entry",
                        market=market_name[:30],
                        level=level_idx,
                        ask_price=round(ask_price, 4),
                        avg_entry=round(inv.avg_entry_price, 4),
                        age_sec=round(age_sec, 0),
                        loss_cents=round((inv.avg_entry_price - ask_price) * 100, 2),
                        reason="position aged, liquidating even at loss",
                    )

            if bid_price is None and ask_price is None:
                continue

            # Place the quote
            quote = await self._place_quote_level(
                token_id=token_id,
                level=level_idx,
                bid_price=bid_price,
                ask_price=ask_price,
                size_usdc=level_size,
                mid=book.mid,
                reservation=reservation,
                spread_cents=spread_cents,
                market_name=market_name,
                book=book,
                inventory_usdc=inventory_usdc,
                inventory_tokens=inventory_tokens,
                ttr_hours=ttr_hours,
            )
            if quote:
                new_quotes.append(quote)

        if new_quotes:
            self.active_quotes[token_id] = new_quotes

    async def _place_quote_level(
        self,
        token_id: str,
        level: int,
        bid_price: float | None,
        ask_price: float | None,
        size_usdc: float,
        mid: float,
        reservation: float,
        spread_cents: float,
        market_name: str,
        book: MarketBook | None = None,
        inventory_usdc: float = 0.0,
        inventory_tokens: float = 0.0,
        ttr_hours: float | None = None,
    ) -> ActiveQuote | None:
        """Place bid and/or ask for a single level. PAPER=simulate, LIVE=real."""
        if bid_price is None and ask_price is None:
            return None

        bid_order_id = None
        ask_order_id = None

        if not settings.paper_trading:
            # LIVE: place real orders + register them for fill polling.
            # v1.0.39 FIX: previously the order_id returned by place_order was
            # stored ONLY in ActiveQuote.bid/ask_order_id and never added to
            # _pending_orders. As a result _poll_orders() returned early at
            # `if not self._pending_orders: return` and LIVE fills were never
            # detected — bankroll/inventory diverged from reality on the very
            # first fill. We now populate _pending_orders so _poll_orders_loop
            # can detect fills via get_orders / get_order.
            now_mono_place = time.monotonic()
            if bid_price is not None:
                result: OrderResult = await self.clob.place_order(
                    token_id, "BUY", bid_price, size_usdc, post_only=True
                )
                if result.success and result.order_id:
                    bid_order_id = result.order_id
                    self._pending_orders[bid_order_id] = {
                        "token_id": token_id,
                        "side": "BUY",
                        "price": bid_price,
                        "size_usdc": size_usdc,
                        "market_name": market_name,
                        "level": level,
                        "mid_at_place": mid,
                        "placed_at": now_mono_place,
                    }
                else:
                    log.warning(
                        "live_bid_failed",
                        market=market_name[:30],
                        level=level,
                        error=result.error or "no order_id returned",
                    )
                    bid_price = None  # don't track failed order

            if ask_price is not None:
                result = await self.clob.place_order(
                    token_id, "SELL", ask_price, size_usdc, post_only=True
                )
                if result.success and result.order_id:
                    ask_order_id = result.order_id
                    self._pending_orders[ask_order_id] = {
                        "token_id": token_id,
                        "side": "SELL",
                        "price": ask_price,
                        "size_usdc": size_usdc,
                        "market_name": market_name,
                        "level": level,
                        "mid_at_place": mid,
                        "placed_at": now_mono_place,
                    }
                else:
                    log.warning(
                        "live_ask_failed",
                        market=market_name[:30],
                        level=level,
                        error=result.error or "no order_id returned",
                    )
                    ask_price = None

            if bid_price is None and ask_price is None:
                return None

        quote = ActiveQuote(
            token_id=token_id,
            level=level,
            bid_price=bid_price,
            ask_price=ask_price,
            mid_at_place=mid,
            size_usdc=size_usdc,
            reservation_price=reservation,
            spread_cents=spread_cents,
            bid_order_id=bid_order_id,
            ask_order_id=ask_order_id,
        )

        # Compute our actual spread (after clamps) for logging
        our_bid = bid_price if bid_price is not None else None
        our_ask = ask_price if ask_price is not None else None
        our_spread_cents = (
            round((our_ask - our_bid) * 100, 2)
            if (our_bid is not None and our_ask is not None)
            else None
        )

        # Market context (from book, if available)
        market_bid_log = round(book.best_bid, 4) if book and book.best_bid > 0 else None
        market_ask_log = round(book.best_ask, 4) if book and book.best_ask < 1 else None
        market_spread_log = round(book.spread * 100, 2) if book else None

        log.info(
            "quote_placed",
            market=market_name[:30],
            level=level,
            # Market context (what the order book shows)
            market_bid=market_bid_log,
            market_ask=market_ask_log,
            market_spread_cents=market_spread_log,
            # Our quote (inside the market spread)
            our_bid=round(our_bid, 4) if our_bid is not None else None,
            our_ask=round(our_ask, 4) if our_ask is not None else None,
            our_spread_cents=our_spread_cents,
            # Strategy context
            mid=round(mid, 4),
            reservation=round(reservation, 4),
            optimal_spread_cents=round(spread_cents, 2),
            size_usdc=round(size_usdc, 2),
            # Inventory state (per user request)
            inventory_usdc=round(inventory_usdc, 2),
            inventory_tokens=round(inventory_tokens, 4),
            # Time to resolution (per user request — "ttr hours")
            ttr_hours=ttr_hours,
            mode="LIVE" if not settings.paper_trading else "PAPER",
        )
        return quote

    # ── Cancel ────────────────────────────────────────────────────────────

    async def _cancel_all_levels(self, token_id: str) -> None:
        quotes = self.active_quotes.pop(token_id, [])
        for q in quotes:
            await self._cancel_quote_level(token_id, q)

    async def _cancel_quote_level(self, token_id: str, quote: ActiveQuote) -> None:
        if not settings.paper_trading:
            if quote.bid_order_id:
                await self.clob.cancel_order(quote.bid_order_id)
                self._pending_orders.pop(quote.bid_order_id, None)
            if quote.ask_order_id:
                await self.clob.cancel_order(quote.ask_order_id)
                self._pending_orders.pop(quote.ask_order_id, None)

    # ── Fill checking ─────────────────────────────────────────────────────

    async def _check_fills(
        self,
        token_id: str,
        book: MarketBook,
        quotes: list[ActiveQuote],
        market_name: str,
    ) -> None:
        """Check for fills on existing quotes. PAPER=simulate, LIVE=poll."""
        if settings.paper_trading:
            await self._check_fills_paper(token_id, book, quotes, market_name)
        # LIVE mode: fills are detected in _poll_orders_loop

    async def _check_fills_paper(
        self,
        token_id: str,
        book: MarketBook,
        quotes: list[ActiveQuote],
        market_name: str,
    ) -> None:
        """PAPER-mode fill simulation with realistic adverse selection."""
        direction = self._get_market_direction(token_id)

        for quote in quotes:
            # ── Bid fill simulation ──
            # v1.0.48 FIX (BUG-10): previously `continue` here would skip the
            # ask-fill block below for this quote. With 15% rejection + 40%
            # competition + 20% partial-none, ~60% of bid checks skipped ask.
            # Now we use `pass` so the ask block still runs after a bid skip.
            if not quote.bid_filled and quote.bid_price and quote.bid_price > 0:
                market_bid = book.best_bid
                if market_bid > 0:
                    distance = abs(quote.bid_price - market_bid)
                    if quote.bid_price >= market_bid - 0.003 and distance <= 0.015:
                        # v1.0.50 (BUG-2): rejection/competition rates are now
                        # configurable (paper_rejection_rate, paper_competition_rate).
                        # Defaults are more realistic: 20% rejection (was 15%),
                        # 50% competition (was 40%) — closer to real LIVE behavior.
                        if random.random() < settings.paper_rejection_rate:
                            pass  # v1.0.48: was `continue` (skipped ask block)
                        # Competition
                        elif random.random() < settings.paper_competition_rate:
                            pass  # v1.0.48: was `continue`
                        else:
                            # Directional bias (0.3 — informed traders)
                            direction_mult = 1.0 + (direction * -0.3)
                            # Fill probability — now configurable (paper_fill_prob_base/max)
                            market_spread = book.spread
                            activity_mult = 1.3 if market_spread < 0.015 else (0.6 if market_spread > 0.04 else 1.0)
                            closeness = 1.0 - (distance / 0.015)
                            fill_prob = settings.paper_fill_prob_base * closeness * activity_mult * max(0.5, direction_mult)
                            fill_prob = min(settings.paper_fill_prob_max, max(0.005, fill_prob))

                            if random.random() < fill_prob:
                                # Adverse drift — now configurable (paper_adverse_drift_min/max)
                                adverse_drift = book.mid * random.uniform(
                                    settings.paper_adverse_drift_min,
                                    settings.paper_adverse_drift_max,
                                )
                                # v1.0.75 (BUG-N26): Fix adverse drift for BUY.
                                # OLD: fill_price = min(quote.bid_price + adverse_drift, market_bid + 0.001)
                                #      This capped drift at bid+0.001 → drift never applied → 100% win rate.
                                # NEW: Cap at market_ask (can't buy higher than ask). Drift now actually
                                #      makes fill price worse (higher), modeling informed traders.
                                fill_price = min(quote.bid_price + adverse_drift, book.best_ask - 0.001)
                                fill_price = max(0.01, min(0.99, fill_price))
                                # Partial fills (20% none, 40% partial, 40% full — realistic)
                                partial_roll = random.random()
                                if partial_roll < 0.20:
                                    pass  # v1.0.48: was `continue`
                                elif partial_roll < 0.60:
                                    fill_pct = random.uniform(0.40, 0.75)
                                else:
                                    fill_pct = random.uniform(0.85, 1.0)
                                if partial_roll >= 0.20:
                                    fill_size = quote.size_usdc * fill_pct
                                    if fill_size < 1.0:
                                        pass  # v1.0.48: was `continue`
                                    elif not self.inventory.should_quote_bid(token_id):
                                        await self._cancel_all_levels(token_id)
                                        return
                                    # CRITICAL: check bankroll has enough cash for BUY
                                    # (simulates Polymarket API rejecting order if insufficient balance)
                                    elif self.inventory.bankroll < fill_size:
                                        log.warning(
                                            "fill_skipped_insufficient_balance",
                                            side="BUY",
                                            market=market_name[:30],
                                            fill_size=round(fill_size, 2),
                                            bankroll=round(self.inventory.bankroll, 2),
                                            reason="not enough cash to buy (would be rejected in LIVE)",
                                        )
                                        pass  # v1.0.48: was `continue`
                                    else:
                                        await self._record_fill(
                                            token_id, "BUY", fill_price, fill_size, market_name,
                                            level=quote.level, mid_at_fill=quote.mid_at_place,
                                        )
                                        quote.bid_filled = True

            # ── Ask fill simulation ──
            # v1.0.48 FIX (BUG-10): same as bid — `continue` here would skip
            # the round-trip detection below. Now uses `pass`.
            if not quote.ask_filled and quote.ask_price and quote.ask_price < 1:
                market_ask = book.best_ask
                if market_ask < 1:
                    distance = abs(quote.ask_price - market_ask)
                    if quote.ask_price <= market_ask + 0.003 and distance <= 0.015:
                        # v1.0.50 (BUG-2): configurable rejection/competition rates
                        if random.random() < settings.paper_rejection_rate:
                            pass  # v1.0.48: was `continue`
                        # Competition
                        elif random.random() < settings.paper_competition_rate:
                            pass  # v1.0.48: was `continue`
                        else:
                            # Directional bias (0.3 — informed traders)
                            direction_mult = 1.0 + (direction * 0.3)
                            market_spread = book.spread
                            activity_mult = 1.3 if market_spread < 0.015 else (0.6 if market_spread > 0.04 else 1.0)
                            closeness = 1.0 - (distance / 0.015)
                            fill_prob = settings.paper_fill_prob_base * closeness * activity_mult * max(0.5, direction_mult)
                            fill_prob = min(settings.paper_fill_prob_max, max(0.005, fill_prob))

                            if random.random() < fill_prob:
                                # Adverse drift — configurable
                                adverse_drift = book.mid * random.uniform(
                                    settings.paper_adverse_drift_min,
                                    settings.paper_adverse_drift_max,
                                )
                                # v1.0.75 (BUG-N26): Fix adverse drift for SELL.
                                # OLD: fill_price = max(quote.ask_price - adverse_drift, market_ask - 0.001)
                                #      This floored drift at ask-0.001 → drift never applied → 100% win rate.
                                # NEW: Floor at market_bid (can't sell lower than bid). Drift now actually
                                #      makes fill price worse (lower), modeling informed traders.
                                fill_price = max(quote.ask_price - adverse_drift, book.best_bid + 0.001)
                                fill_price = max(0.01, min(0.99, fill_price))
                                # Partial fills (20% none, 40% partial, 40% full — realistic)
                                partial_roll = random.random()
                                if partial_roll < 0.20:
                                    pass  # v1.0.48: was `continue`
                                elif partial_roll < 0.60:
                                    fill_pct = random.uniform(0.40, 0.75)
                                else:
                                    fill_pct = random.uniform(0.85, 1.0)
                                if partial_roll >= 0.20:
                                    fill_size = quote.size_usdc * fill_pct
                                    if fill_size < 1.0:
                                        pass  # v1.0.48: was `continue`
                                    else:
                                        # CRITICAL: Check if we have tokens to sell
                                        # In LIVE: Polymarket API rejects SELL if insufficient token balance
                                        inv_now = self.inventory.get_inventory(token_id)
                                        tokens_to_sell = fill_size / max(fill_price, 0.001)
                                        if inv_now.net_tokens < tokens_to_sell:
                                            log.warning(
                                                "sell_fill_skipped_no_tokens",
                                                market=market_name[:30],
                                                net_tokens=round(inv_now.net_tokens, 4),
                                                tokens_to_sell=round(tokens_to_sell, 4),
                                                reason="insufficient tokens (LIVE API would reject)",
                                            )
                                            pass  # v1.0.48: was `continue`
                                        elif not self.inventory.should_quote_ask(token_id):
                                            await self._cancel_all_levels(token_id)
                                            return
                                        else:
                                            await self._record_fill(
                                                token_id, "SELL", fill_price, fill_size, market_name,
                                                level=quote.level, mid_at_fill=quote.mid_at_place,
                                            )
                                            quote.ask_filled = True

            # ── Round-trip detection (per level) ──
            if quote.bid_filled and quote.ask_filled:
                buy_p = quote.bid_price or 0
                sell_p = quote.ask_price or 0
                log.info(
                    "round_trip",
                    market=market_name[:40],
                    level=quote.level,
                    buy=round(buy_p, 4),
                    sell=round(sell_p, 4),
                    gross_spread=round(sell_p - buy_p, 4),
                )
                ROUND_TRIPS_TOTAL.inc()
                self._round_trip_count += 1

        # Remove fully-filled quotes
        self.active_quotes[token_id] = [q for q in quotes if not (q.bid_filled and q.ask_filled)]
        if not self.active_quotes[token_id]:
            self.active_quotes.pop(token_id, None)

    def _get_market_direction(self, token_id: str) -> float:
        """Estimate short-term direction (-1..+1) from price history."""
        state = self._as_calc.get_state(token_id)
        if not state or len(state.price_history) < 5:
            return 0.0
        prices = [p for _, p in state.price_history]
        recent = prices[-1]
        past = prices[-5]
        if past == 0:
            return 0.0
        change = (recent - past) / past
        return max(-1.0, min(1.0, change * 50))

    # ── LIVE mode: order polling ──────────────────────────────────────────

    async def _poll_orders_loop(self) -> None:
        """In LIVE mode: poll order status to detect fills."""
        await asyncio.sleep(5)
        while self._running:
            try:
                await self._poll_orders()
            except asyncio.CancelledError:
                break
            except Exception as e:
                log.debug("poll_error", error=str(e))
            await asyncio.sleep(3)

    async def _poll_orders(self) -> None:
        """v1.0.46 FIX (BUG-5, BUG-6): safer fill detection.
        v1.0.47 FIX: corrected status strings per Polymarket API docs.

        BUG-5: previously `final.get("size_matched", info["size_usdc"])` would
          default to the FULL order size when the API omitted `size_matched`.
          For PARTIALLY_FILLED this recorded a phantom full fill. Now we treat
          a missing size_matched as 0 (no fill recorded) and log a warning.
        BUG-6: previously only MATCHED/FILLED/FILLED_PARTIAL triggered fill
          recording. A CANCELLED order with a partial fill was silently
          dropped. Now we check size_matched for ANY non-open status and
          record whatever partial fill exists.
        v1.0.47: Polymarket API uses `PARTIALLY_FILLED` (not `FILLED_PARTIAL`).
          Status values: LIVE (active on book), PARTIALLY_FILLED, FILLED,
          CANCELLED. `size_matched` is preserved after CANCELLED (partial
          fill kept). After cancel, size_matched does NOT increase further.
        """
        if not self._pending_orders:
            return
        from py_clob_client.clob_types import OpenOrderParams

        try:
            open_orders = self.clob._client.get_orders(OpenOrderParams())
        except Exception as e:
            log.warning("poll_orders_failed", error=str(e))
            return

        open_ids = {o.get("id") for o in open_orders if isinstance(o, dict)}
        now_mono = time.monotonic()

        for order_id in list(self._pending_orders.keys()):
            info = self._pending_orders[order_id]
            age = now_mono - info["placed_at"]

            # If order is no longer in open list → it filled or was canceled
            if order_id not in open_ids:
                # Check final status via get_order
                try:
                    final = self.clob._client.get_order(order_id)
                except Exception as e:
                    log.debug("get_order_failed", order_id=order_id, error=str(e))
                    self._pending_orders.pop(order_id, None)
                    continue

                if not isinstance(final, dict):
                    log.warning(
                        "poll_orders_unexpected_response",
                        order_id=order_id,
                        response_type=type(final).__name__,
                    )
                    self._pending_orders.pop(order_id, None)
                    continue

                status = (final.get("status", "") or "").upper()

                # v1.0.46 (BUG-5): don't assume full fill when size_matched
                # is missing. Read it explicitly; default to 0 (not the
                # original size) so we don't record phantom fills.
                size_matched_raw = final.get("size_matched")
                if size_matched_raw is None:
                    # Some API responses use "size_matched" (USDC) others use
                    # "makingAmount"/"takingAmount" (tokens). Try both.
                    making = final.get("makingAmount")
                    if making is not None:
                        try:
                            # makingAmount is tokens; convert to USDC at price
                            price_for_conv = float(final.get("price", info["price"]))
                            size_matched_usd = float(making) * price_for_conv
                        except (TypeError, ValueError):
                            size_matched_usd = 0.0
                    else:
                        size_matched_usd = 0.0
                        if status in ("MATCHED", "FILLED", "PARTIALLY_FILLED"):
                            log.warning(
                                "poll_orders_size_matched_missing",
                                order_id=order_id,
                                status=status,
                                reason="API reports fill but no size_matched/makingAmount — recording 0",
                            )
                else:
                    try:
                        size_matched_usd = float(size_matched_raw)
                    except (TypeError, ValueError):
                        size_matched_usd = 0.0
                        log.warning(
                            "poll_orders_size_matched_unparseable",
                            order_id=order_id,
                            raw=size_matched_raw,
                        )

                # v1.0.46 (BUG-6): record ANY partial fill, regardless of
                # status (was: only MATCHED/FILLED/FILLED_PARTIAL). A
                # CANCELLED order may still have a partial fill recorded
                # in size_matched (v1.0.47: confirmed by Polymarket API docs
                # — size_matched is preserved after CANCELLED).
                if size_matched_usd > 0:
                    try:
                        fill_price = float(final.get("price", info["price"]))
                    except (TypeError, ValueError):
                        fill_price = info["price"]

                    # Skip tiny dust fills (< $0.01) — likely rounding noise
                    if size_matched_usd >= 0.01:
                        await self._record_fill(
                            info["token_id"], info["side"], fill_price,
                            size_matched_usd, info["market_name"],
                            level=info.get("level", 1),
                            mid_at_fill=info.get("mid_at_place", fill_price),
                        )
                        log.info(
                            "poll_orders_fill_detected",
                            order_id=order_id,
                            status=status,
                            side=info["side"],
                            size_usdc=round(size_matched_usd, 4),
                            price=round(fill_price, 4),
                            market=info["market_name"][:30],
                        )
                    else:
                        log.debug(
                            "poll_orders_dust_fill_skipped",
                            order_id=order_id,
                            size_usdc=size_matched_usd,
                        )
                elif status in ("MATCHED", "FILLED", "PARTIALLY_FILLED"):
                    # API says filled but size_matched=0 — suspicious, log it
                    log.warning(
                        "poll_orders_fill_zero_size",
                        order_id=order_id,
                        status=status,
                        reason="status indicates fill but size_matched=0; no fill recorded",
                    )

                self._pending_orders.pop(order_id, None)
            elif age > 30:
                # Timeout: cancel. Note: the cancelled order may still have
                # a partial fill that we'll detect on the NEXT poll cycle
                # (after it disappears from open_ids). So we don't pop here
                # immediately — we let the next cycle's get_order() read
                # the final status with size_matched.
                await self.clob.cancel_order(order_id)
                # Give the cancel one more cycle to settle before popping,
                # so the partial-fill check above can run on the final state.
                # If the cancel fails silently, the 30s timeout will retry.
                info["placed_at"] = now_mono - 25  # grace period for next cycle
                log.debug(
                    "poll_orders_cancel_sent",
                    order_id=order_id,
                    age_sec=round(age, 1),
                    reason="order timeout, will re-check final status next cycle",
                )

    # ── Active inventory liquidation (v1.0.38) ───────────────────────────
    # Solves the critical "inventory accumulation" problem: bot buys but
    # won't sell below entry, so positions get stuck when price drops.
    # This loop aggressively clears aged positions by placing sell orders
    # at/below market bid, accepting realized losses to free up capital.

    async def _state_persistence_loop(self) -> None:
        """v1.0.72 (BUG-N23): Save inventory state to DB every 60s.

        Enables crash recovery: if bot dies (power loss, kill -9, OOM),
        load_state_from_db() on next startup restores bankroll + positions.
        """
        await asyncio.sleep(10)  # let bot stabilize first
        while self._running:
            try:
                from app.core.db import AsyncSessionLocal
                async with AsyncSessionLocal() as db:
                    await self.inventory.save_state_to_db(db)
            except asyncio.CancelledError:
                break
            except Exception as e:
                log.warning(
                    "state_persistence_error",
                    error=str(e),
                    error_type=type(e).__name__,
                )
            await asyncio.sleep(60)

    async def _liquidation_loop(self) -> None:
        """Background task: aggressively liquidate aged inventory.

        Runs every `inventory_liquidation_check_sec` seconds. For each
        market with a long position older than `aggressive_age_sec`:
          - Cancel existing quotes (so we can place aggressive ones)
          - Place a SELL at market_bid + 0.001 (front of bid queue)
        If older than `urgent_age_sec`:
          - Place a SELL at market_bid (take whatever we can get)
        This ensures stuck positions are cleared, freeing capital.
        """
        await asyncio.sleep(settings.inventory_liquidation_check_sec)
        while self._running:
            try:
                if not self._trading_paused and not self.inventory.halted:
                    await self._liquidate_aged_positions()
                    # v1.0.50 FIX (BUG-3): also clean up orphaned positions.
                    # These are positions on markets that are no longer in
                    # self.clob.books (market was replaced/closed). Without
                    # this, orphaned positions stay in inventory forever
                    # (unless they hit pre-resolution exit, but if the market
                    # was already replaced we don't track end_date).
                    await self._cleanup_orphaned_positions()
            except asyncio.CancelledError:
                break
            except Exception as e:
                log.warning("liquidation_loop_error", error=str(e))
            await asyncio.sleep(settings.inventory_liquidation_check_sec)

    async def _liquidate_aged_positions(self) -> None:
        """Scan all inventories and liquidate aged ones."""
        now_mono = time.monotonic()
        for token_id, inv in list(self.inventory.inventories.items()):
            # Only liquidate long positions (we can only sell what we own)
            if inv.net_tokens <= 0.5:
                continue
            if inv.open_time == 0:
                continue

            age_sec = now_mono - inv.open_time
            book = self.clob.books.get(token_id)
            if not book or book.best_bid <= 0:
                continue

            info = self.clob.markets.get(token_id)
            market_name = info.question[:40] if info else token_id[:12]

            # Determine liquidation tier based on age
            market_bid = book.best_bid
            market_ask = book.best_ask
            # v1.0.66 (BUG-N17): mid-based liquidation pricing.
            # OLD: sell at bid+0.001 (ignored mid) → lost $3+ per position
            #      when spread was wide (bid 0.192, mid 0.320, ask 0.449).
            # NEW: target = max(mid, entry+5¢), capped at ask-0.001.
            #      Same A+C priority as Exit All (BUG-N16 fix).
            mid = (market_bid + market_ask) / 2.0 if market_ask > market_bid else market_bid
            target_mid = round(mid, 4)
            target_min = round(inv.avg_entry_price + 0.05, 4)  # entry + 5¢
            tier: str = ""
            if age_sec < settings.inventory_liquidation_aggressive_age_sec:
                # v1.0.63 (BUG-N13): Critical tier — inventory at 95%+ of max.
                # Professional MM deleverages immediately when at hard cap,
                # regardless of age. Without this, bot can accumulate beyond
                # max_inventory_usdc via rapid fills and get stuck.
                max_usd = self.inventory.max_inventory_usdc()
                position_usd = abs(inv.net_tokens) * market_bid
                if max_usd > 0 and position_usd >= max_usd * 0.95:
                    is_urgent = False
                    tier = "CRITICAL"
                    # v1.0.66: mid-based pricing (was bid+0.001)
                    sell_price = max(target_mid, target_min)
                    sell_price = min(sell_price, round(market_ask - 0.001, 4))
                    log.warning(
                        "critical_tier_liquidation_triggered",
                        market=market_name,
                        age_sec=round(age_sec, 0),
                        position_usd=round(position_usd, 2),
                        max_usd=round(max_usd, 2),
                        ratio=round(position_usd / max_usd, 3),
                        mid=round(mid, 4),
                        target_mid=round(target_mid, 4),
                        target_min=round(target_min, 4),
                        sell_price=round(sell_price, 4),
                        reason="position at 95%+ of hard cap — deleverage now",
                    )
                else:
                    continue  # not aged enough, not at critical cap
            else:
                is_urgent = age_sec >= settings.inventory_liquidation_urgent_age_sec
                if is_urgent:
                    # Urgent: sell at max(mid, entry+5¢), capped at ask-0.001
                    # v1.0.66: was market_bid (any price), now mid-based
                    sell_price = max(target_mid, target_min)
                    sell_price = min(sell_price, round(market_ask - 0.001, 4))
                    tier = "URGENT"
                else:
                    # Aggressive: sell at max(mid, entry+5¢), capped at ask-0.001
                    # v1.0.66: was bid+0.001, now mid-based
                    sell_price = max(target_mid, target_min)
                    sell_price = min(sell_price, round(market_ask - 0.001, 4))
                    tier = "AGGRESSIVE"

            # Clamp to valid range
            sell_price = max(0.01, min(0.99, sell_price))

            # Check loss tolerance
            loss_cents = (inv.avg_entry_price - sell_price) * 100
            if loss_cents > settings.inventory_liquidation_max_loss_cents and not is_urgent:
                # Loss too big and not urgent yet — wait
                log.debug(
                    "liquidation_skipped_loss_too_big",
                    market=market_name,
                    age_sec=round(age_sec, 0),
                    loss_cents=round(loss_cents, 2),
                    max_loss_cents=settings.inventory_liquidation_max_loss_cents,
                )
                continue

            # Size: sell entire position
            size_usdc = inv.net_tokens * sell_price
            if size_usdc < 1.0:
                continue  # too small to bother

            # Check we have enough tokens (should always be true here)
            tokens_to_sell = inv.net_tokens
            if tokens_to_sell < 0.5:
                continue

            log.info(
                "liquidation_triggered",
                market=market_name,
                tier=tier,
                age_sec=round(age_sec, 0),
                net_tokens=round(inv.net_tokens, 4),
                avg_entry=round(inv.avg_entry_price, 4),
                sell_price=round(sell_price, 4),
                market_bid=round(market_bid, 4),
                loss_cents=round(loss_cents, 2),
                size_usdc=round(size_usdc, 2),
            )

            # Cancel existing quotes for this market (so new aggressive
            # order isn't blocked by stale quotes)
            if token_id in self.active_quotes:
                await self._cancel_all_levels(token_id)

            # v1.0.39 FIX: in LIVE mode we must actually PLACE a sell order on
            # Polymarket. Previously _record_fill was called directly, which
            # updated local inventory/bankroll as if the position had been
            # sold — but no real SELL order ever hit the book. Result: the
            # bot believed it had liquidated, while the real position stayed
            # open on-chain and capital remained locked.
            #
            # We use order_type=FAK (Fill-And-Kill, a.k.a. IOC) so the order
            # either fills (partially or fully) immediately or is cancelled.
            # post_only=False is required because post_only orders can never
            # cross the book (they would be rejected when there is a matching
            # bid, which is exactly what we want here).
            if settings.paper_trading:
                # PAPER: simulate immediate fill at sell_price (legacy path).
                await self._record_fill(
                    token_id, "SELL", sell_price, size_usdc, market_name,
                    level=99,  # level 99 = liquidation
                    mid_at_fill=book.mid,
                    is_liquidation=True,
                )
                self._liquidation_count += 1
            else:
                # LIVE: place a real FAK sell at sell_price.
                from app.services.clob_client import OrderResult as _OR  # noqa: F401
                result = await self.clob.place_order(
                    token_id, "SELL", sell_price, size_usdc,
                    order_type="FAK", post_only=False,
                )
                if result.success:
                    # Try to read actual fill price/size from response.
                    raw = result.raw if isinstance(result.raw, dict) else {}
                    # Polymarket returns "makingAmount" / "takingAmount" or
                    # "price" / "size_matched" depending on endpoint/version.
                    actual_price = sell_price
                    if raw.get("price"):
                        try:
                            actual_price = float(raw["price"])
                        except (TypeError, ValueError):
                            actual_price = sell_price
                    actual_size = size_usdc
                    if raw.get("size_matched"):
                        try:
                            actual_size = float(raw["size_matched"])
                        except (TypeError, ValueError):
                            actual_size = size_usdc
                    elif raw.get("makingAmount"):
                        # makingAmount is in tokens; convert to USDC
                        try:
                            actual_size = float(raw["makingAmount"]) * actual_price
                        except (TypeError, ValueError):
                            actual_size = size_usdc

                    await self._record_fill(
                        token_id, "SELL", actual_price, actual_size, market_name,
                        level=99,
                        mid_at_fill=book.mid,
                        is_liquidation=True,
                    )
                    self._liquidation_count += 1
                    log.info(
                        "liquidation_order_placed_live",
                        market=market_name,
                        tier=tier,
                        order_id=result.order_id,
                        requested_price=round(sell_price, 4),
                        actual_price=round(actual_price, 4),
                        requested_size_usdc=round(size_usdc, 2),
                        actual_size_usdc=round(actual_size, 2),
                    )
                else:
                    log.warning(
                        "liquidation_order_failed_live",
                        market=market_name,
                        tier=tier,
                        sell_price=round(sell_price, 4),
                        size_usdc=round(size_usdc, 2),
                        error=result.error,
                        reason="FAK sell rejected; position remains open",
                    )

    async def _cleanup_orphaned_positions(self) -> None:
        """v1.0.50 FIX (BUG-3): clean up positions on markets no longer in books.

        When markets are replaced (via _replace_non_quotable_markets or
        manual /markets/replace), old positions may remain in
        inventory.inventories if they had open tokens. These "orphaned"
        positions:
          - Can't be liquidated (no book → no market_bid)
          - Can't hit pre-resolution exit (we don't track end_date after replace)
          - Stay forever, cluttering inventory + falsely inflating inventory_value

        This method:
          1. Finds positions where token_id NOT in self.clob.books
          2. If net_tokens == 0 (flat) → remove from inventory (just cleanup)
          3. If net_tokens != 0 (open position) → log warning, attempt to
             re-fetch book once; if still no book, mark as orphaned and
             leave (can't liquidate without market data).
        """
        orphaned_tids: list[str] = []
        for tid, inv in list(self.inventory.inventories.items()):
            if tid in self.clob.books:
                continue  # not orphaned
            if abs(inv.net_tokens) <= 0.0001:
                # Flat position on orphaned market → safe to remove
                orphaned_tids.append(tid)
                log.info(
                    "orphaned_position_removed_flat",
                    token=tid[:12],
                    market=inv.market_name[:40] if inv.market_name else "?",
                    realized_pnl=round(inv.realized_pnl, 4),
                )
            else:
                # Open position on orphaned market → can't liquidate without book
                log.warning(
                    "orphaned_position_open",
                    token=tid[:12],
                    market=inv.market_name[:40] if inv.market_name else "?",
                    net_tokens=round(inv.net_tokens, 4),
                    avg_entry=round(inv.avg_entry_price, 4),
                    realized_pnl=round(inv.realized_pnl, 4),
                    reason="market no longer in books; position will resolve at market close",
                )

        for tid in orphaned_tids:
            inv = self.inventory.inventories.pop(tid, None)
            if inv:
                # Persist the realized P&L to daily_pnl (already counted in
                # inv.realized_pnl, but we log it for audit)
                log.info(
                    "orphaned_inventory_cleaned",
                    token=tid[:12],
                    final_realized_pnl=round(inv.realized_pnl, 4),
                )
            # Also clean up pricing/risk state for this token
            self._as_calc.clear(tid)
            self._kyle.clear(tid)
            self.risk.adverse_selection.clear(tid)
            self.risk.circuit_breakers.clear_token(tid)
            # Remove from active_quotes if present (shouldn't be, but just in case)
            self.active_quotes.pop(tid, None)

    # ── Fill recording ────────────────────────────────────────────────────

    async def _record_fill(
        self,
        token_id: str,
        side: str,
        price: float,
        size_usdc: float,
        market_name: str,
        level: int = 1,
        mid_at_fill: float | None = None,
        is_liquidation: bool = False,
        is_hedge: bool = False,
        _skip_hedge: bool = False,
    ) -> None:
        """Record a fill in inventory + DB. Triggers hedge if applicable."""
        # CRITICAL: Balance/short checks for hedge fills too
        # Hedge fills bypass the quote-placement checks (they come from _attempt_active_hedge)
        # but still must respect balance and short limits
        if is_hedge:
            inv_check = self.inventory.get_inventory(token_id)
            if side == "BUY":
                # Hedge BUY: check bankroll has enough cash
                if self.inventory.bankroll < size_usdc:
                    log.warning(
                        "hedge_fill_skipped_insufficient_balance",
                        market=market_name[:30],
                        side=side,
                        size_usdc=round(size_usdc, 2),
                        bankroll=round(self.inventory.bankroll, 2),
                    )
                    return
            elif side == "SELL":
                # Hedge SELL: check we have tokens to sell (no shorting allowed)
                tokens_to_sell = size_usdc / max(price, 0.001)
                if inv_check.net_tokens < tokens_to_sell:
                    log.warning(
                        "hedge_fill_skipped_no_tokens",
                        market=market_name[:30],
                        side=side,
                        net_tokens=round(inv_check.net_tokens, 4),
                        tokens_to_sell=round(tokens_to_sell, 4),
                        reason="insufficient tokens for hedge (LIVE API would reject)",
                    )
                    return

        realized = self.inventory.on_fill(token_id, side, price, size_usdc, market_name)

        # Costs
        # v1.0.73 (BUG-N24): Gas separated from profit.
        # OLD: realized_net = realized - fees_usdc → gas mixed into pnl_usdc
        #      (BUY showed -$0.001 "profit" which is actually a cost).
        # NEW: pnl_usdc = gross realized (trading edge only)
        #      fees_usdc = gas (separate, shown as cost in UI)
        #      Net = pnl_usdc - fees_usdc (computed by UI, not stored in pnl_usdc)
        # Polymarket relay: gas ~$0.001/fill (relay covers order signing).
        gas_cost = settings.paper_gas_cost_usdc if settings.paper_trading else settings.live_gas_cost_usdc
        fees_usdc = gas_cost
        realized_net = realized - fees_usdc  # kept for backwards-compat logging
        self.inventory.bankroll -= fees_usdc  # gas still deducted from cash

        self._fill_count += 1
        FILLS_TOTAL.labels(side=side, mode="LIVE" if not settings.paper_trading else "PAPER").inc()

        if mid_at_fill is None:
            mid_at_fill = price

        log.info(
            "fill",
            market=market_name[:50],
            side=side,
            price=round(price, 4),
            size_usdc=round(size_usdc, 2),
            pnl_net=round(realized_net, 4),
            pnl_gross=round(realized, 4),
            fees=round(fees_usdc, 4),
            inv_after=round(self.inventory.get_inventory(token_id).net_tokens, 4),
            level=level,
            mode="LIVE" if not settings.paper_trading else "PAPER",
            liquidation=is_liquidation,
            hedge=is_hedge,
        )

        # Persist to DB
        # v1.0.73: pnl_usdc = gross realized (no gas), fees_usdc = gas (separate)
        await self._persist_trade(
            token_id, side, price, size_usdc, realized, fees_usdc, market_name,
            level, is_hedge,
        )

        # Update adverse selection tracking
        self.risk.on_fill(token_id, side, price, mid_at_fill)

        # Trigger hedge (Yes/No pair) — only on real fills, not on hedge fills
        if (
            settings.hedging_enabled
            and settings.hedging_active_enabled
            and not _skip_hedge
            and not is_liquidation
        ):
            try:
                await self._attempt_active_hedge(token_id, side, size_usdc, market_name, price)
            except Exception as e:
                log.debug("hedge_failed", error=str(e))

    async def _attempt_active_hedge(
        self,
        filled_token_id: str,
        filled_side: str,
        filled_size_usdc: float,
        market_name: str,
        filled_price: float,
    ) -> None:
        """Hedge by trading the paired Yes/No token (YES+NO=$1, risk-free).

        When we BUY YES at price P_yes, we can also BUY NO at P_no.
        If P_yes + P_no < 1.0, the position is risk-free (one side always pays $1).
        Same for SELL: SELL YES + SELL NO when P_yes_bid + P_no_bid > 1.0.
        """
        paired_token = self._get_paired_token(filled_token_id)
        if not paired_token:
            log.debug(
                "hedge_skipped_no_pair",
                filled_market=market_name[:30],
                filled_side=filled_side,
                reason="no paired Yes/No token found",
            )
            return
        paired_book = self.clob.books.get(paired_token)
        if not paired_book or not paired_book.bids or not paired_book.asks:
            log.debug(
                "hedge_skipped_no_book",
                filled_market=market_name[:30],
                reason="paired token has no order book",
            )
            return
        paired_info = self.clob.markets.get(paired_token)
        paired_name = paired_info.question[:50] if paired_info else paired_token[:12]

        if filled_side == "BUY":
            hedge_side = "BUY"
            hedge_price = paired_book.best_ask + 0.003
            if hedge_price > 0.99:
                log.debug("hedge_skipped_price", reason="hedge_price > 0.99")
                return
            # Profitability check: YES_ask + NO_ask must be < $1.00
            total_cost = filled_price + paired_book.best_ask
            if total_cost >= 1.0:
                log.debug(
                    "hedge_skipped_unprofitable",
                    filled_price=round(filled_price, 4),
                    paired_ask=round(paired_book.best_ask, 4),
                    total=round(total_cost, 4),
                    reason="YES_ask + NO_ask >= $1.00 (no arbitrage)",
                )
                return
            profit_cents = (1.0 - total_cost) * 100
        else:
            hedge_side = "SELL"
            hedge_price = paired_book.best_bid - 0.003
            if hedge_price < 0.01:
                log.debug("hedge_skipped_price", reason="hedge_price < 0.01")
                return
            # Profitability check: YES_bid + NO_bid must be > $1.00
            total_revenue = filled_price + paired_book.best_bid
            if total_revenue <= 1.0:
                log.debug(
                    "hedge_skipped_unprofitable",
                    filled_price=round(filled_price, 4),
                    paired_bid=round(paired_book.best_bid, 4),
                    total=round(total_revenue, 4),
                    reason="YES_bid + NO_bid <= $1.00 (no arbitrage)",
                )
                return
            profit_cents = (total_revenue - 1.0) * 100

        hedge_size = filled_size_usdc
        if hedge_size < 1.0:
            return

        # v1.0.46 FIX (BUG-4): pre-flight check BEFORE placing the LIVE
        # hedge order. Previously the check lived inside _record_fill(),
        # which is called AFTER place_order() — meaning the real SELL
        # order was sent to Polymarket, possibly filled, and then the
        # local inventory update was silently skipped (because we had
        # no tokens to sell). Result: position moved on-chain but the
        # bot's inventory never reflected it — a silent financial leak.
        #
        # v1.0.47 NOTE: Polymarket DOES support shorting (SELL without
        # tokens creates a short with $1 collateral per contract). So
        # the API would NOT reject this order — it would execute and
        # open a short position. However, opening a short via "hedge"
        # logic is NOT a real hedge: shorting the paired token is
        # economically equivalent to going long on the original token
        # (short NO = long YES), so it doubles our risk instead of
        # neutralizing it. We therefore block it: only hedge SELL when
        # we actually own the paired token (closing an existing long).
        #
        # We check BEFORE place_order():
        #   - hedge SELL: need enough tokens on the paired market
        #     (selling without tokens would open an uncontrolled short)
        #   - hedge BUY:  need enough bankroll
        # If the check fails, we DON'T place the order at all.
        if not settings.paper_trading:
            paired_inv_check = self.inventory.get_inventory(paired_token)
            if hedge_side == "SELL":
                tokens_needed = hedge_size / max(hedge_price, 0.001)
                if paired_inv_check.net_tokens < tokens_needed:
                    log.warning(
                        "hedge_skipped_insufficient_tokens_preflight",
                        filled_market=market_name[:30],
                        paired_market=paired_name[:30],
                        hedge_side=hedge_side,
                        paired_net_tokens=round(paired_inv_check.net_tokens, 4),
                        tokens_needed=round(tokens_needed, 4),
                        reason="would open uncontrolled short (Polymarket supports it with $1 collateral, but bot policy blocks shorts via hedge)",
                    )
                    return
            else:  # hedge_side == "BUY"
                if self.inventory.bankroll < hedge_size:
                    log.warning(
                        "hedge_skipped_insufficient_balance_preflight",
                        filled_market=market_name[:30],
                        paired_market=paired_name[:30],
                        hedge_side=hedge_side,
                        hedge_size=round(hedge_size, 2),
                        bankroll=round(self.inventory.bankroll, 2),
                        reason="would send LIVE BUY with insufficient bankroll",
                    )
                    return

        self._hedge_attempts += 1

        log.info(
            "hedge_attempt",
            filled_market=market_name[:30],
            filled_side=filled_side,
            filled_price=round(filled_price, 4),
            paired_market=paired_name[:30],
            hedge_side=hedge_side,
            hedge_price=round(hedge_price, 4),
            profit_cents=round(profit_cents, 2),
            size_usdc=round(hedge_size, 2),
        )

        if settings.paper_trading:
            if random.random() < 0.80:
                actual_price = hedge_price + random.uniform(-0.0005, 0.0005)
                actual_price = max(0.01, min(0.99, actual_price))
                await self._record_fill(
                    paired_token, hedge_side, actual_price, hedge_size, paired_name,
                    _skip_hedge=True, is_hedge=True,
                )
                self._hedge_fills += 1
                log.info(
                    "hedge_filled",
                    paired_market=paired_name[:40],
                    side=hedge_side,
                    price=round(actual_price, 4),
                    size_usdc=round(hedge_size, 2),
                    profit_cents=round(profit_cents, 2),
                )
            else:
                log.debug("hedge_not_filled", reason="20% paper rejection")
        else:
            # v1.0.39 FIX: LIVE hedging was completely missing — the `else`
            # branch simply did not exist. Now we place a real order on the
            # paired token via FAK so the hedge actually executes on-chain.
            # post_only=False because we want immediate fill (this is an
            # arbitrage, not market making).
            result = await self.clob.place_order(
                paired_token, hedge_side, hedge_price, hedge_size,
                order_type="FAK", post_only=False,
            )
            if result.success:
                raw = result.raw if isinstance(result.raw, dict) else {}
                actual_price = hedge_price
                if raw.get("price"):
                    try:
                        actual_price = float(raw["price"])
                    except (TypeError, ValueError):
                        pass
                actual_size = hedge_size
                if raw.get("size_matched"):
                    try:
                        actual_size = float(raw["size_matched"])
                    except (TypeError, ValueError):
                        pass
                # v1.0.46 (BUG-4): the _record_fill pre-check (is_hedge branch)
                # is now redundant because we did the pre-flight check above.
                # But we keep it as a defensive second guard in case the
                # inventory changed between the pre-flight and now (e.g.
                # another concurrent fill). If _record_fill skips, we log
                # a CRITICAL warning because the LIVE order already went
                # through — the position is real but untracked.
                tokens_to_sell_check = actual_size / max(actual_price, 0.001)
                paired_inv_now = self.inventory.get_inventory(paired_token)
                if hedge_side == "SELL" and paired_inv_now.net_tokens < tokens_to_sell_check:
                    log.critical(
                        "hedge_filled_but_untrackable_live",
                        paired_market=paired_name[:40],
                        side=hedge_side,
                        order_id=result.order_id,
                        actual_size=round(actual_size, 4),
                        actual_price=round(actual_price, 4),
                        paired_net_tokens=round(paired_inv_now.net_tokens, 4),
                        reason="LIVE SELL executed on-chain but inventory cannot be updated — MANUAL RECONCILIATION NEEDED",
                    )
                    # Don't call _record_fill (it would skip anyway), but
                    # still count as a hedge attempt so the fill rate metric
                    # reflects the failure.
                    return
                await self._record_fill(
                    paired_token, hedge_side, actual_price, actual_size,
                    paired_name,
                    _skip_hedge=True, is_hedge=True,
                )
                self._hedge_fills += 1
                log.info(
                    "hedge_filled_live",
                    paired_market=paired_name[:40],
                    side=hedge_side,
                    order_id=result.order_id,
                    price=round(actual_price, 4),
                    size_usdc=round(actual_size, 2),
                    profit_cents=round(profit_cents, 2),
                )
            else:
                log.warning(
                    "hedge_failed_live",
                    paired_market=paired_name[:40],
                    side=hedge_side,
                    hedge_price=round(hedge_price, 4),
                    size_usdc=round(hedge_size, 2),
                    error=result.error,
                )

    def _build_hedging_pairs(self) -> None:
        """Link Yes and No tokens sharing the same condition_id.

        Also supports fallback pairing by identical question text when
        condition_id is missing (some markets on Polymarket don't expose it
        via the events API).
        """
        self._condition_pairs.clear()
        by_condition: dict[str, list[str]] = {}
        by_question: dict[str, list[str]] = {}

        for tid, info in self.clob.markets.items():
            cid = info.condition_id
            if cid:
                by_condition.setdefault(cid, []).append(tid)
            # Fallback: group by question text (Yes/No outcomes share question)
            if info.question:
                by_question.setdefault(info.question, []).append(tid)

        # Primary: by condition_id
        for cid, tokens in by_condition.items():
            if len(tokens) == 2:
                self._register_pair(cid, tokens)

        # Fallback: by question text (only add if not already paired via condition_id)
        already_paired = set()
        for pair in self._condition_pairs.values():
            already_paired.add(pair["yes"])
            already_paired.add(pair["no"])

        for q, tokens in by_question.items():
            if len(tokens) == 2 and tokens[0] not in already_paired:
                # Use question hash as key to avoid collisions
                key = f"q:{hash(q)}"
                self._register_pair(key, tokens)

        if self._condition_pairs:
            log.info(
                "hedging_pairs_built",
                pairs=len(self._condition_pairs),
                by_condition=sum(1 for k in self._condition_pairs if not k.startswith("q:")),
                by_question=sum(1 for k in self._condition_pairs if k.startswith("q:")),
            )

    def _register_pair(self, key: str, tokens: list[str]) -> None:
        """Register a Yes/No pair, determining which is Yes by outcome field."""
        info0 = self.clob.markets.get(tokens[0])
        info1 = self.clob.markets.get(tokens[1])
        if not info0 or not info1:
            return
        # Determine Yes/No by outcome field (case-insensitive)
        out0 = (info0.outcome or "").lower().strip()
        out1 = (info1.outcome or "").lower().strip()
        if out0 == "yes" and out1 == "no":
            self._condition_pairs[key] = {"yes": tokens[0], "no": tokens[1]}
        elif out0 == "no" and out1 == "yes":
            self._condition_pairs[key] = {"yes": tokens[1], "no": tokens[0]}
        else:
            # Fallback: token with higher mid price = "Yes" (probability of event)
            if info0 and info1:
                yes_token = tokens[0] if self.clob.books.get(tokens[0]) and self.clob.books[tokens[0]].mid > 0.5 else tokens[1]
                no_token = tokens[1] if yes_token == tokens[0] else tokens[0]
                self._condition_pairs[key] = {"yes": yes_token, "no": no_token}

    def _get_paired_token(self, token_id: str) -> str | None:
        for pair in self._condition_pairs.values():
            if pair["yes"] == token_id:
                return pair["no"]
            if pair["no"] == token_id:
                return pair["yes"]
        return None

    # ── DB persistence ────────────────────────────────────────────────────

    async def _persist_trade(
        self,
        token_id: str,
        side: str,
        price: float,
        size_usdc: float,
        pnl: float,
        fees_usdc: float,
        market_name: str,
        level: int,
        is_hedge: bool,
    ) -> None:
        try:
            from app.core.db import AsyncSessionLocal

            async with AsyncSessionLocal() as db:
                t = Trade(
                    market_id=token_id,
                    market_name=market_name,
                    condition_id=self.clob.markets.get(token_id, None).condition_id
                    if self.clob.markets.get(token_id)
                    else "",
                    side=Side.BUY if side == "BUY" else Side.SELL,
                    price=price,
                    size_usdc=size_usdc,
                    size_tokens=size_usdc / max(price, 0.001),
                    pnl_usdc=pnl,
                    fees_usdc=fees_usdc,
                    inventory_after=self.inventory.get_inventory(token_id).net_tokens,
                    spread_cents=self._get_active_spread(token_id),
                    level=level,
                    mode=OrderMode.LIVE if not settings.paper_trading else OrderMode.PAPER,
                    is_hedge=is_hedge,
                )
                db.add(t)
                await db.commit()
        except Exception as e:
            log.debug("trade_persist_failed", error=str(e))

    def _get_active_spread(self, token_id: str) -> float | None:
        quotes = self.active_quotes.get(token_id)
        if not quotes:
            return None
        return quotes[0].spread_cents

    async def _db_cleanup_loop(self) -> None:
        """Every 10 minutes, prune old quotes + snapshots (keep last 1000 each)."""
        await asyncio.sleep(600)
        while self._running:
            try:
                from app.core.db import AsyncSessionLocal
                from sqlalchemy import text

                async with AsyncSessionLocal() as db:
                    await db.execute(
                        text(
                            "DELETE FROM mm_quotes WHERE id NOT IN "
                            "(SELECT id FROM mm_quotes ORDER BY id DESC LIMIT 1000)"
                        )
                    )
                    await db.execute(
                        text(
                            "DELETE FROM mm_snapshots WHERE id NOT IN "
                            "(SELECT id FROM mm_snapshots ORDER BY id DESC LIMIT 1000)"
                        )
                    )
                    await db.execute(
                        text(
                            "DELETE FROM mm_metric_points WHERE id NOT IN "
                            "(SELECT id FROM mm_metric_points ORDER BY id DESC LIMIT 5000)"
                        )
                    )
                    await db.commit()
            except Exception as e:
                log.debug("db_cleanup_error", error=str(e))
            await asyncio.sleep(600)

    # ── Status ────────────────────────────────────────────────────────────

    @property
    def status(self) -> dict:
        return {
            "cycle_count": self._cycle_count,
            "fill_count": self._fill_count,
            "round_trip_count": self._round_trip_count,
            "liquidation_count": self._liquidation_count,  # v1.0.38
            "active_quotes": sum(len(qs) for qs in self.active_quotes.values()),
            "pending_live_orders": len(self._pending_orders) if not settings.paper_trading else 0,
            "mode": "LIVE" if not settings.paper_trading else "PAPER",
            "trading_paused": self._trading_paused,
            "halted": self.inventory.halted,
            "halt_reason": self.inventory.halt_reason,
            "hedge_attempts": self._hedge_attempts,
            "hedge_fills": self._hedge_fills,
            "hedge_fill_rate_pct": round(
                self._hedge_fills / max(self._hedge_attempts, 1) * 100, 1
            ),
            "adverse_global_cooldown_sec": round(
                self.risk.adverse_selection.global_cooldown_remaining(), 1
            ),
            "quotes_detail": [
                {
                    "token_id": q.token_id[:12],
                    "market_name": next(
                        (i.question[:30] for i in self.clob.markets.values()
                         if i.token_id == q.token_id),
                        q.token_id[:12]
                    ),
                    "level": q.level,
                    "bid": round(q.bid_price, 4) if q.bid_price is not None else None,
                    "ask": round(q.ask_price, 4) if q.ask_price is not None else None,
                    "mid": round(q.mid_at_place, 4),
                    "reservation": round(q.reservation_price, 4),
                    "optimal_spread_cents": round(q.spread_cents, 2),
                    "our_spread_cents": round(
                        (q.ask_price - q.bid_price) * 100, 2
                    ) if q.bid_price is not None and q.ask_price is not None else None,
                    "bid_filled": q.bid_filled,
                    "ask_filled": q.ask_filled,
                    "age_sec": round(time.monotonic() - q.placed_at, 1),
                }
                for qs in self.active_quotes.values()
                for q in qs
            ],
        }
