"""
app/services/order_logger.py — Order lifecycle metrics logger.

Wraps the existing order-submission path at 4 hooks (handoff §4):
  (a) pre_submit  — before validation: create row, derive context
  (b) submit      — immediately before POST /order: record submitted_at
  (c) on_response — immediately after API returns: ack latency + status
  (d) fill/cancel — background poller: updates fill/cancel timestamps

Design rules (truth-first):
  1. Logger failures MUST NOT break order submission. Every hook is wrapped
     in try/except and logs at warning level on failure.
  2. retry_count / total_retry_wait_ms are left at 0 — the codebase has no
     retry wrapper (v1.0.49 removed the dead @retry). Adding one is out of
     scope ("instrumentation only"). These fields exist for future use.
  3. seconds_to_game_start is always None — the bot does not currently read
     a game_start_time field from Gamma (UNVERIFIED: such a field may exist
     but its name is unknown). auto_cancel_game_start detection (§4d) is
     therefore a stub; cancels are logged as plain 'cancelled' until the
     Gamma field is wired.
  4. market_category is derived from MarketInfo.question via keyword
     matching. 'sports_live' currently means "sports market (pre-match OR
     in-play)" — we cannot distinguish without game_start_time.
  5. PAPER-mode rows are logged with mode='PAPER' so the report can filter
     them out (PAPER always returns MATCHED with ~0ms latency and would
     pollute LIVE percentiles).
"""
from __future__ import annotations

import asyncio
import time
import uuid
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any

from app.core.config import settings
from app.core.logging import get_logger
from app.db import order_metrics_db as mdb

if TYPE_CHECKING:
    from app.services.clob_client import ClobService, OrderResult

log = get_logger(__name__)

# ── Category classifier ──────────────────────────────────────────────────
# Conservative keyword sets. 'sports_live' per the handoff enum, though we
# can't tell pre-match from in-play without game_start_time.
_SPORTS_KW = (
    "nba,nfl,mlb,nhl,soccer,football,baseball,basketball,hockey,tennis,golf,"
    "f1,formula 1,world cup,wimbledon,ucl,champions league,la liga,premier league,"
    "serie a,bundesliga,mls,nwsl,ncaa,march madness,world series,super bowl,"
    "stanley cup,nba finals,world championship,vs,versus,win,beat,cup,match,game,"
    "score,semifinal,quarterfinal,quarter final,round of 16,round of 32,"
    "championship,tournament,playoff,play-offs,playoffs,corner,offside,penalty"
)
_CRYPTO_KW = (
    "bitcoin,btc,ethereum,eth,solana,sol,crypto,dogecoin,xrp,cardano,polygon,matic,"
    "binance,coinbase,up,down,above,below,price"
)

_SPORTS_SET = frozenset(_SPORTS_KW.split(","))
_CRYPTO_SET = frozenset(_CRYPTO_KW.split(","))


def classify_category(question: str) -> str:
    """Return 'sports_live' | 'crypto_updown' | 'other' based on market question."""
    if not question:
        return "other"
    q = question.lower()
    if any(k in q for k in _CRYPTO_SET):
        return "crypto_updown"
    if any(k in q for k in _SPORTS_SET):
        return "sports_live"
    return "other"


def _is_marketable(side: str, price: float, book: Any) -> int:
    """1 if the order would cross the book at submit time, else 0.

    BUY is marketable when price >= best_ask (willing to pay the ask).
    SELL is marketable when price <= best_bid (willing to hit the bid).
    Returns 0 if book is missing or empty.
    """
    if book is None:
        return 0
    try:
        if side == "BUY":
            return 1 if book.best_ask > 0 and price >= book.best_ask else 0
        if side == "SELL":
            return 1 if book.best_bid > 0 and price <= book.best_bid else 0
    except Exception:
        return 0
    return 0


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


class OrderLogger:
    """Hooks into ClobService.place_order() at 4 lifecycle points.

    Singleton via module-level `order_logger`. State is fully in the DB —
    the object itself holds no per-order state except the poller task.
    """

    def __init__(self) -> None:
        self._poller_task: asyncio.Task | None = None
        self._clob: ClobService | None = None

    def attach_clob(self, clob: ClobService) -> None:
        """Wire the ClobService reference (for the fill-poller to call back)."""
        self._clob = clob

    # ── Hook (a): pre-submit ────────────────────────────────────────────
    async def pre_submit(
        self,
        token_id: str,
        side: str,
        price: float,
        size_usdc: float,
        order_type: str,
        clob: ClobService,
    ) -> str:
        """Generate client_order_ref + insert initial row. Returns the ref.

        Called at the very start of place_order(), before any validation.
        """
        ref = str(uuid.uuid4())
        book = clob.books.get(token_id)
        info = clob.markets.get(token_id)
        question = info.question if info else ""
        row = {
            "client_order_ref": ref,
            "token_id": token_id,
            "condition_id": info.condition_id if info else "",
            "market_slug": question[:200] if question else "",
            "market_category": classify_category(question),
            "side": side,
            "order_type": order_type,
            "price": float(price),
            "size": float(size_usdc),
            "tick_size": float(book.tick_size) if book else 0.01,
            "is_marketable": _is_marketable(side, price, book),
            # seconds_to_game_start: None — see module docstring §3
            "seconds_to_game_start": None,
            "created_at_local": _now_iso(),
            "mode": "PAPER" if settings.paper_trading else "LIVE",
        }
        try:
            await mdb.insert_order_event(row)
        except Exception as e:
            log.warning("metrics_pre_submit_failed", error=str(e), ref=ref)
        return ref

    # ── Hook (b): submit (immediately before POST /order) ───────────────
    async def submit(self, ref: str) -> None:
        try:
            await mdb.update_order_event(ref, {"submitted_at": _now_iso()})
        except Exception as e:
            log.warning("metrics_submit_failed", error=str(e), ref=ref)

    # ── Hook (c): on response ───────────────────────────────────────────
    async def on_response(
        self,
        ref: str,
        result: OrderResult,
        submitted_at_iso: str | None,
    ) -> None:
        """Record ack + determine immediate final_status.

        - success + status FILLED/MATCHED → mark filled now (no poller needed).
        - success + status LIVE/PARTIALLY_FILLED → leave final_status NULL
          for the poller to resolve.
        - success=False with PolyApi-style error → 'rejected' / 'api_reject'.
        - success=False with generic exception → 'unknown_transport_error'.
        """
        now = _now_iso()
        ack_latency_ms: float | None = None
        if submitted_at_iso:
            try:
                t_sub = datetime.fromisoformat(submitted_at_iso)
                t_ack = datetime.fromisoformat(now)
                ack_latency_ms = round((t_ack - t_sub).total_seconds() * 1000, 2)
            except Exception:
                ack_latency_ms = None

        raw = result.raw if hasattr(result, "raw") else None
        status = ""
        order_id = ""
        if isinstance(raw, dict):
            status = str(raw.get("status") or "").upper()
            order_id = str(raw.get("orderID") or raw.get("id") or "")

        updates: dict[str, Any] = {
            "ack_received_at": now,
            "ack_status": status or ("PAPER" if settings.paper_trading else "UNKNOWN"),
            "ack_latency_ms": ack_latency_ms,
            "polymarket_order_id": order_id or "",
        }

        # Classify the outcome
        if not result.success:
            err = result.error or ""
            # Heuristic: PolyApiException errors carry a status code / API msg;
            # generic transport errors (timeout, connection reset) do not.
            looks_api_reject = any(
                tok in err
                for tok in ("PolyApiException", "error_msg", "status_code", "reject")
            )
            if looks_api_reject:
                updates["final_status"] = "rejected"
                updates["reject_stage"] = "api_reject"
                updates["reject_reason"] = err[:1000]
            else:
                updates["final_status"] = "unknown_transport_error"
                updates["reject_stage"] = "timeout"
                updates["reject_reason"] = err[:1000]
        else:
            # Success: is it immediately filled?
            if status in ("FILLED", "MATCHED"):
                updates["final_status"] = "filled"
                updates["first_fill_at"] = now
                updates["fully_filled_at"] = now
                updates["filled_size"] = None  # unknown precisely; poller may refine
                updates["fill_ratio"] = 1.0
                if ack_latency_ms is not None:
                    updates["time_to_first_fill_ms"] = ack_latency_ms
                    updates["time_to_full_fill_ms"] = ack_latency_ms
            elif status == "PARTIALLY_FILLED":
                updates["first_fill_at"] = now
                if ack_latency_ms is not None:
                    updates["time_to_first_fill_ms"] = ack_latency_ms
                # final_status stays NULL — poller resolves the rest
            # status == LIVE → final_status stays NULL (resting on book)

        try:
            await mdb.update_order_event(ref, updates)
            await mdb.store_raw_response(ref, raw)
        except Exception as e:
            log.warning("metrics_on_response_failed", error=str(e), ref=ref)

    # ── Hook for pre-submit-validation rejections ───────────────────────
    async def record_pre_submit_reject(self, ref: str, reason: str) -> None:
        """Log a rejection that happened before the API call (tick/size/balance)."""
        try:
            await mdb.update_order_event(
                ref,
                {
                    "final_status": "rejected",
                    "reject_stage": "pre_submit_validation",
                    "reject_reason": reason[:1000],
                },
            )
        except Exception as e:
            log.warning("metrics_pre_submit_reject_failed", error=str(e), ref=ref)

    # ── Hook (d): fill/cancel poller ────────────────────────────────────
    async def fill_poll_loop(self) -> None:
        """Poll get_open_orders() and resolve resting orders.

        Limitation (see module docstring §3): without game_start_time we
        cannot detect auto_cancel_game_start; all cancels are logged as
        plain 'cancelled'. Fills are detected by absence from open-orders +
        best-effort trade-history lookup.
        """
        if self._clob is None:
            log.warning("metrics_poller_no_clob")
            return
        interval = settings.metrics_fill_poll_interval_sec
        log.info("metrics_poller_started", interval_sec=interval)
        while True:
            try:
                await self._poll_once()
            except asyncio.CancelledError:
                raise
            except Exception as e:
                log.warning("metrics_poller_error", error=str(e))
            await asyncio.sleep(interval)

    async def _poll_once(self) -> None:
        if self._clob is None:
            return
        open_orders = await self._clob.get_open_orders()
        open_ids = set()
        for o in open_orders:
            oid = ""
            if isinstance(o, dict):
                oid = str(o.get("id") or o.get("orderID") or "")
            if oid:
                open_ids.add(oid)

        unresolved = await mdb.fetch_unresolved_orders()
        for row in unresolved:
            oid = row.get("polymarket_order_id") or ""
            if not oid or oid in open_ids:
                continue  # still resting, nothing to do
            # Order left the book without us knowing — try trade history first
            filled = await self._check_fill_via_trades(row)
            if filled:
                continue
            # Not found in trades → treat as cancelled
            now = _now_iso()
            await mdb.update_order_event(
                row["client_order_ref"],
                {
                    "final_status": "cancelled",
                    "cancelled_at": now,
                    # TODO(v1.0.80+): if game_start_time becomes available,
                    # upgrade to 'auto_cancel_game_start' when cancel_ts is
                    # within ~1s of game start (handoff §4d).
                },
            )

    async def _check_fill_via_trades(self, row: dict[str, Any]) -> bool:
        """Best-effort: query py-clob-client trades for the token, match by
        order_id. Returns True if a fill was recorded.

        UNVERIFIED: py-clob-client's get_trades signature/return shape is
        not confirmed against the installed version. Wrapped in try/except.
        """
        if self._clob is None or not self._clob._client:
            return False
        token_id = row.get("token_id") or ""
        target_oid = row.get("polymarket_order_id") or ""
        if not token_id or not target_oid:
            return False
        try:
            from py_clob_client.clob_types import TradesRequest  # type: ignore

            req = TradesRequest(token_id=token_id)  # type: ignore[call-arg]
            trades = self._clob._client.get_trades(req)
        except Exception:
            # Fallback: try with no params (older SDK)
            try:
                trades = self._clob._client.get_trades()
            except Exception:
                return False
        if not trades:
            return False
        now = _now_iso()
        submitted = row.get("submitted_at")
        ttf_ms: float | None = None
        if submitted:
            try:
                ttf_ms = round(
                    (datetime.fromisoformat(now) - datetime.fromisoformat(submitted))
                    .total_seconds()
                    * 1000,
                    2,
                )
            except Exception:
                ttf_ms = None
        for t in trades:
            if not isinstance(t, dict):
                continue
            if str(t.get("order_id") or t.get("orderId") or "") != target_oid:
                continue
            try:
                filled_size = float(t.get("size") or 0)
            except (TypeError, ValueError):
                filled_size = None
            size = row.get("size")
            ratio = None
            if filled_size is not None and size:
                ratio = round(filled_size / size, 4) if size > 0 else None
            final = "filled" if (ratio is not None and ratio >= 0.999) else "partial"
            await mdb.update_order_event(
                row["client_order_ref"],
                {
                    "final_status": final,
                    "first_fill_at": now,
                    "fully_filled_at": now if final == "filled" else None,
                    "filled_size": filled_size,
                    "fill_ratio": ratio,
                    "time_to_first_fill_ms": ttf_ms,
                    "time_to_full_fill_ms": ttf_ms if final == "filled" else None,
                },
            )
            return True
        return False

    # ── Lifecycle ───────────────────────────────────────────────────────
    def start_poller(self, clob: ClobService) -> None:
        self.attach_clob(clob)
        if self._poller_task is None or self._poller_task.done():
            self._poller_task = asyncio.create_task(
                self.fill_poll_loop(), name="order_metrics_poller"
            )

    async def stop_poller(self) -> None:
        if self._poller_task:
            self._poller_task.cancel()
            try:
                await self._poller_task
            except asyncio.CancelledError:
                pass
            self._poller_task = None


# Module-level singleton
order_logger = OrderLogger()
