"""app.services.pricing — Pricing models: Avellaneda-Stoikov, Kyle's lambda."""
