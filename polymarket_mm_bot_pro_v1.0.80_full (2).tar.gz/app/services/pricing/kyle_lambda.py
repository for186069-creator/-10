"""
app/services/pricing/kyle_lambda.py — Kyle's lambda (price impact).

Reference: Kyle (1985), "Continuous Auctions and Insider Trading".

Kyle's lambda measures price impact per unit of order flow:
    lambda = dP / dQ  (price change per unit volume)

A HIGH lambda means the market is illiquid — large orders move the price
significantly. For a market maker, this means:
  - Wider spread needed (adverse selection risk is higher)
  - Smaller optimal order size
  - Higher profit per round-trip BUT lower fill rate

Estimation method (simplified):
    lambda ≈ |Δmid| / |net_volume|
  where net_volume = (buy_volume - sell_volume) over a short window.

We don't have trade-flow data from the public API (would need WS user feed).
Instead we approximate lambda from ORDER BOOK IMBALANCE:
    lambda_est = (1 - depth_ratio) * scale
  where depth_ratio = min(bid_depth, ask_depth) / max(bid_depth, ask_depth)

A balanced book (ratio ~1) → low lambda → tight spread OK.
An imbalanced book (ratio ~0.1) → high lambda → widen spread.
"""
from __future__ import annotations

import time
from collections import deque
from dataclasses import dataclass

from app.core.config import settings
from app.core.logging import get_logger
from app.services.clob_client import MarketBook

log = get_logger(__name__)


@dataclass
class KyleState:
    """Per-token Kyle's lambda state."""

    imbalance_history: deque  # of float imbalance ratios
    last_lambda: float
    last_update: float


class KyleLambda:
    """Estimate Kyle's lambda per token from order book imbalance."""

    def __init__(self) -> None:
        self._states: dict[str, KyleState] = {}

    def update_and_compute(self, token_id: str, book: MarketBook) -> tuple[float, float]:
        """Update with latest book snapshot, return (lambda, spread_multiplier).

        spread_multiplier is in [1.0, kyle_max_spread_mult]:
            1.0 = balanced book, no spread expansion
            kyle_max_spread_mult = extremely imbalanced
        """
        if not book.bids or not book.asks:
            return 0.0, 1.0

        levels = settings.kyle_depth_levels
        bid_depth = book.depth_bid(levels)
        ask_depth = book.depth_ask(levels)

        if bid_depth <= 0 or ask_depth <= 0:
            return 0.0, 1.0

        # Imbalance ratio: 1.0 = perfectly balanced, 0.0 = totally one-sided
        depth_ratio = min(bid_depth, ask_depth) / max(bid_depth, ask_depth)
        # Imbalance: 0 = balanced, 1 = totally one-sided
        imbalance = 1.0 - depth_ratio

        # Track history for smoothing
        state = self._states.get(token_id)
        if state is None:
            state = KyleState(
                imbalance_history=deque(maxlen=30),
                last_lambda=0.0,
                last_update=time.monotonic(),
            )
            self._states[token_id] = state
        state.imbalance_history.append(imbalance)
        state.last_update = time.monotonic()

        # Smoothed imbalance (mean of last 30 samples)
        avg_imbalance = sum(state.imbalance_history) / len(state.imbalance_history)

        # Lambda estimate: imbalance scales linearly to a [0, 1] value
        # We don't have trade flow, so this is an ordinal proxy.
        # For the purpose of spread expansion, what matters is the multiplier.
        lambda_est = avg_imbalance
        state.last_lambda = lambda_est

        # Spread multiplier: 1.0 (balanced) → kyle_max_spread_mult (one-sided)
        mult = 1.0 + (lambda_est * (settings.kyle_max_spread_mult - 1.0))
        mult = max(1.0, min(settings.kyle_max_spread_mult, mult))

        return lambda_est, mult

    def get_state(self, token_id: str) -> KyleState | None:
        return self._states.get(token_id)

    def clear(self, token_id: str) -> None:
        self._states.pop(token_id, None)
