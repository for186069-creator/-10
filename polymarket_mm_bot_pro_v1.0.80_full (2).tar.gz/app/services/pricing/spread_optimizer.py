"""
app/services/pricing/spread_optimizer.py — Optimal spread computation.

Combines:
  - Base spread from settings
  - Volatility multiplier (from A-S sigma)
  - Kyle's lambda multiplier (order book imbalance)
  - Session-based multiplier (active/quiet hours)
  - Inventory aging discount (for stale positions)

Final spread is clamped to [spread_min_cents, spread_max_cents].
"""
from __future__ import annotations

from datetime import datetime, timezone

from app.core.config import settings
from app.core.logging import get_logger

log = get_logger(__name__)


class SpreadOptimizer:
    """Compute optimal spread per market, combining all factors."""

    @staticmethod
    def compute(
        base_spread_cents: float,
        sigma: float,
        kyle_mult: float,
        session_mult: float = 1.0,
        aging_discount_cents: float = 0.0,
    ) -> float:
        """Compute final spread in cents.

        Args:
            base_spread_cents: from settings.spread_cents
            sigma: volatility (decimal, e.g. 0.02)
            kyle_mult: Kyle's lambda multiplier (1.0..kyle_max_spread_mult)
            session_mult: session-based multiplier (active/quiet hours)
            aging_discount_cents: subtract this to liquidate stale inventory

        Returns:
            Final spread in cents, clamped to [spread_min, spread_max].
        """
        # Volatility multiplier: scale up spread when sigma is high.
        # We map sigma ∈ [0, 0.05] → mult ∈ [1.0, spread_volatility_mult]
        # using a linear ramp.
        sigma_ref = 0.02  # 2% reference volatility
        vol_mult = 1.0 + (
            min(sigma, 0.05) / sigma_ref
        ) * (settings.spread_volatility_mult - 1.0)

        # Combined multiplier (capped to avoid runaway)
        combined_mult = vol_mult * kyle_mult * session_mult
        combined_mult = max(0.5, min(combined_mult, settings.spread_max_cents / base_spread_cents))

        spread = base_spread_cents * combined_mult

        # Apply inventory aging discount (encourage liquidation of stale positions)
        spread = max(spread - aging_discount_cents, settings.spread_min_cents)

        # Final clamp
        spread = max(settings.spread_min_cents, min(settings.spread_max_cents, spread))

        return spread

    @staticmethod
    def get_session_multiplier() -> tuple[float, str]:
        """Return (multiplier, session_name) based on current UTC hour."""
        if not settings.session_quoting_enabled:
            return 1.0, "disabled"

        hour_utc = datetime.now(timezone.utc).hour
        active_start = settings.session_active_start_utc
        active_end = settings.session_active_end_utc

        if active_start <= hour_utc < active_end:
            return settings.session_active_spread_mult, "active"
        if 0 <= hour_utc < 6:
            return settings.session_quiet_spread_mult, "quiet"
        return 1.0, "normal"

    @staticmethod
    def compute_levels(spread_cents: float) -> list[tuple[float, float]]:
        """Split spread into 3 levels for multi-level quoting.

        Returns list of (capture_cents, size_pct) tuples:
          Level 1 (closest to mid): smallest capture, largest size
          Level 3 (farthest):       largest capture, smallest size

        Each level's "capture" is the HALF-SPREAD at that level (in cents),
        computed as capture_pct × spread_cents. So if spread_cents = 4.0:
          Level 1: capture_pct=0.15 → 0.15 × 4.0 = 0.6¢ half-spread → bid/ask ± 0.6¢
          Level 2: capture_pct=0.30 → 0.30 × 4.0 = 1.2¢ half-spread → bid/ask ± 1.2¢
          Level 3: capture_pct=0.45 → 0.45 × 4.0 = 1.8¢ half-spread → bid/ask ± 1.8¢

        FIX: previously returned fixed capture_cents (0.15¢) regardless of spread,
        which made our quotes impossibly tight (0.3¢ spread) even when optimal
        spread was 10¢.
        """
        if not settings.multi_level_enabled:
            # Single level: half-spread
            return [(spread_cents / 2, 1.0)]

        # capture_pct × spread_cents = actual half-spread in cents
        return [
            (settings.multi_level_1_capture * spread_cents, settings.multi_level_1_size_pct),
            (settings.multi_level_2_capture * spread_cents, settings.multi_level_2_size_pct),
            (settings.multi_level_3_capture * spread_cents, settings.multi_level_3_size_pct),
        ]
