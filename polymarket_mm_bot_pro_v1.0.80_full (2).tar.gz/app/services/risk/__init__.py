"""app.services.risk — Risk management: circuit breakers, adverse selection."""
