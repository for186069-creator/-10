"""
app/services/risk/risk_manager.py — Centralized risk orchestrator.

The RiskManager owns:
  - Circuit breakers (CircuitBreakers)
  - Adverse selection (AdverseSelection)
  - Per-token risk state

It exposes:
  - `should_halt()` — aggregate circuit-breaker check
  - `should_quote(token_id, book)` — per-token decision
  - `record_fill(...)` — post-fill hooks

The MarketMaker calls RiskManager every cycle. RiskManager does NOT place
orders — only returns decisions.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from app.core.config import settings
from app.core.logging import get_logger
from app.services.risk.adverse_selection import AdverseSelection
from app.services.risk.circuit_breakers import CircuitBreakers

if TYPE_CHECKING:
    from app.services.clob_client import ClobService, MarketBook
    from app.services.inventory_manager import InventoryManager

log = get_logger(__name__)


@dataclass
class TokenRiskDecision:
    """Per-token risk decision returned to the market maker."""

    allow_bid: bool
    allow_ask: bool
    reasons: list[str] = field(default_factory=list)

    @property
    def allow_any(self) -> bool:
        return self.allow_bid or self.allow_ask


class RiskManager:
    """Top-level risk orchestrator."""

    def __init__(self, inventory: InventoryManager, clob: ClobService) -> None:
        self.inventory = inventory
        self.clob = clob
        self.circuit_breakers = CircuitBreakers()
        self.adverse_selection = AdverseSelection()
        self._halted_reason: str = ""

    # ── Global halt ───────────────────────────────────────────────────────

    def should_halt(self) -> tuple[bool, str]:
        """Check all global circuit breakers."""
        should, reason = self.circuit_breakers.check_all(self.inventory, self.clob)
        if should:
            self._halted_reason = reason
        return should, reason

    def halt(self, reason: str, detail: str = "") -> None:
        """Manually halt (e.g. user pause)."""
        self.inventory.halt(reason=reason, detail=detail)

    def resume(self, preserve_counters: bool = False) -> str:
        """Resume trading. Resets emergency stop flag."""
        self.circuit_breakers.reset_emergency_stop()
        return self.inventory.resume(preserve_counters=preserve_counters)

    def emergency_stop(self) -> None:
        """Trigger the kill switch."""
        self.circuit_breakers.emergency_stop()
        self.inventory.halt(reason="EMERGENCY_STOP", detail="manual kill switch")

    # ── Per-token decisions ───────────────────────────────────────────────

    def should_quote(self, token_id: str, book: MarketBook) -> TokenRiskDecision:
        """Decide whether to quote on this token. Returns reasons if blocked."""
        reasons: list[str] = []
        allow_bid = True
        allow_ask = True

        # 1. Adverse selection cooldown
        if self.adverse_selection.is_in_cooldown(token_id):
            reasons.append("adverse_selection_cooldown")
            return TokenRiskDecision(allow_bid=False, allow_ask=False, reasons=reasons)

        # 2. Major move check
        moved, move_reason = self.circuit_breakers.check_major_move(token_id, book.mid)
        if moved:
            log.warning("major_move_detected", token_id=token_id[:12], reason=move_reason)
            reasons.append(move_reason)
            return TokenRiskDecision(allow_bid=False, allow_ask=False, reasons=reasons)

        # 3. Inventory-based side blocking
        if not self.inventory.should_quote_bid(token_id):
            allow_bid = False
            reasons.append("inventory_full_long")
        if not self.inventory.should_quote_ask(token_id):
            allow_ask = False
            reasons.append("inventory_full_short")

        return TokenRiskDecision(allow_bid=allow_bid, allow_ask=allow_ask, reasons=reasons)

    # ── Post-fill hooks ───────────────────────────────────────────────────

    def on_fill(
        self,
        token_id: str,
        side: str,
        fill_price: float,
        mid_at_fill: float,
    ) -> None:
        """Called after a fill is recorded. Updates adverse-selection tracking."""
        self.adverse_selection.record_fill(token_id, side, fill_price, mid_at_fill)

    def on_cycle(self, token_id: str, mid: float) -> None:
        """Called every cycle for each token. Updates price tracking."""
        self.adverse_selection.track_price(token_id, mid)

    # ── Status ────────────────────────────────────────────────────────────

    @property
    def status(self) -> dict:
        return {
            "halted": self.inventory.halted,
            "halt_reason": self.inventory.halt_reason,
            "emergency_stop_armed": self.circuit_breakers._emergency_stop_triggered,
            "adverse_global_cooldown_sec": round(
                self.adverse_selection.global_cooldown_remaining(), 1
            ),
        }
