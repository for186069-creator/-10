#!/usr/bin/env python3
"""
scripts/metrics_report.py — CLI report for order lifecycle metrics.

Prints the two headline metrics from the handoff (§5):
  1. Rejection rate (broken down by market_category × reject_stage)
  2. Fill-time percentiles p50/p90/p99 (by market_category × is_marketable)

Side stats:
  - auto_cancel_game_start count + % (expected sports behavior)
  - unknown_transport_error count + % (needs manual reconciliation)
  - avg retry_count / total_retry_wait_ms (throttling overhead)

Usage:
    python scripts/metrics_report.py [--mode LIVE|PAPER|ALL] [--db PATH]

Exits 0 on success, 1 if the DB is empty / not initialized.

Notes (truth-first):
  - SQLite has no native PERCENTILE_CONT; we compute in Python via numpy.
  - Groups with n < 30 are flagged "LOW SAMPLE" — percentages are still
    printed but the report explicitly says so (handoff §5 / §6).
  - auto_cancel_game_start will read 0 until game_start_time is wired
    (see order_logger.py docstring §3).
"""
from __future__ import annotations

import argparse
import asyncio
import os
import sys
from collections import defaultdict
from typing import Any

# Allow running as `python scripts/metrics_report.py` from the project root
# by adding the project root to sys.path (so `app.*` imports resolve).
_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

# numpy is optional at runtime for the bot but required for this report.
try:
    import numpy as np
except ImportError:
    print("ERROR: numpy is required for metrics_report.py. Install: pip install numpy", file=sys.stderr)
    sys.exit(2)

from app.core.config import settings
from app.db import order_metrics_db as mdb


def _pct(n: int, total: int) -> str:
    return f"{(100.0 * n / total):.2f}%" if total else "n/a"


def _percentiles(values: list[float]) -> dict[str, float | None]:
    """Return p50/p90/p99, or all-None if empty."""
    if not values:
        return {"p50": None, "p90": None, "p99": None}
    arr = np.asarray(values, dtype=float)
    return {
        "p50": float(np.percentile(arr, 50)),
        "p90": float(np.percentile(arr, 90)),
        "p99": float(np.percentile(arr, 99)),
    }


def _fmt_ms(v: float | None) -> str:
    if v is None:
        return "—"
    return f"{v:.1f}ms"


async def run_report(mode_filter: str) -> int:
    await mdb.init_metrics_db()

    # ── Pull raw rows ──
    if mode_filter == "ALL":
        rows = await mdb.fetch_all_for_report(mode_filter="LIVE")
        rows += await mdb.fetch_all_for_report(mode_filter="PAPER")
    else:
        rows = await mdb.fetch_all_for_report(mode_filter=mode_filter)

    if not rows:
        print(f"No order_events rows found (mode={mode_filter}).")
        print("Has the bot placed any orders yet?")
        return 1

    total = len(rows)

    print("=" * 78)
    print(f"ORDER METRICS REPORT  (n={total}, mode={mode_filter})")
    print("=" * 78)

    # ── 1. Rejection rate ──
    # Denominator: resolved orders (exclude unknown_transport_error per handoff §5)
    resolved = [r for r in rows if r["final_status"] != "unknown_transport_error"]
    n_resolved = len(resolved)
    rejected = [r for r in resolved if r["final_status"] == "rejected"]

    print("\n## 1. REJECTION RATE")
    print(f"  Resolved orders (denominator): {n_resolved}")
    print(f"  Rejected:                      {len(rejected)}  ({_pct(len(rejected), n_resolved)})")

    by_cat_stage: dict[tuple[str | None, str | None], int] = defaultdict(int)
    for r in rejected:
        by_cat_stage[(r["market_category"], r["reject_stage"])] += 1

    if by_cat_stage:
        print("\n  Breakdown (category × reject_stage):")
        print(f"  {'category':<18} {'stage':<26} {'n':>5} {'% of resolved':>14}")
        print(f"  {'-' * 18} {'-' * 26} {'-' * 5} {'-' * 14}")
        for (cat, stage), n in sorted(by_cat_stage.items(), key=lambda kv: -kv[1]):
            cat_s = cat or "?"
            stage_s = stage or "?"
            print(f"  {cat_s:<18} {stage_s:<26} {n:>5} {_pct(n, n_resolved):>14}")
    else:
        print("  (no rejections recorded)")

    # ── 2. Fill-time percentiles ──
    print("\n## 2. FILL-TIME PERCENTILES (time_to_first_fill_ms / time_to_full_fill_ms)")
    filled = [
        r for r in rows if r["final_status"] in ("filled", "partial") and r["time_to_first_fill_ms"] is not None
    ]

    groups: dict[tuple[str | None, int | None], list[dict[str, Any]]] = defaultdict(list)
    for r in filled:
        groups[(r["market_category"], r["is_marketable"])].append(r)

    if not groups:
        print("  (no fills with timing data recorded)")
    else:
        print(f"  {'category':<18} {'marketable':>10} {'n':>5} {'first p50':>11} {'first p90':>11} "
              f"{'first p99':>11} {'full p50':>11} {'full p90':>11} {'full p99':>11}")
        print(f"  {'-' * 18} {'-' * 10} {'-' * 5} {'-' * 11} {'-' * 11} {'-' * 11} {'-' * 11} {'-' * 11} {'-' * 11}")
        for (cat, mkt), grp in sorted(groups.items(), key=lambda kv: -len(kv[1])):
            first_vals = [g["time_to_first_fill_ms"] for g in grp if g["time_to_first_fill_ms"] is not None]
            full_vals = [g["time_to_full_fill_ms"] for g in grp if g["time_to_full_fill_ms"] is not None]
            fp = _percentiles(first_vals)
            flp = _percentiles(full_vals)
            low = " ⚠ LOW SAMPLE" if len(grp) < 30 else ""
            mkt_s = "YES" if mkt else "NO"
            cat_s = cat or "?"
            print(f"  {cat_s:<18} {mkt_s:>10} {len(grp):>5} "
                  f"{_fmt_ms(fp['p50']):>11} {_fmt_ms(fp['p90']):>11} {_fmt_ms(fp['p99']):>11} "
                  f"{_fmt_ms(flp['p50']):>11} {_fmt_ms(flp['p90']):>11} {_fmt_ms(flp['p99']):>11}{low}")

    # ── Side stats ──
    print("\n## 3. SIDE STATS")
    n_auto = sum(1 for r in rows if r["final_status"] == "auto_cancel_game_start")
    n_transport = sum(1 for r in rows if r["final_status"] == "unknown_transport_error")
    n_cancelled = sum(1 for r in rows if r["final_status"] == "cancelled")
    n_filled = sum(1 for r in rows if r["final_status"] == "filled")
    n_partial = sum(1 for r in rows if r["final_status"] == "partial")
    n_open = sum(1 for r in rows if r["final_status"] is None)

    print(f"  auto_cancel_game_start : {n_auto:>5}  ({_pct(n_auto, total)})  "
          "(expected sports behavior — NOT a defect)")
    print(f"  unknown_transport_error: {n_transport:>5}  ({_pct(n_transport, total)})  "
          "(needs manual reconciliation via getOpenOrders)")
    print(f"  cancelled (generic)    : {n_cancelled:>5}  ({_pct(n_cancelled, total)})")
    print(f"  filled                 : {n_filled:>5}  ({_pct(n_filled, total)})")
    print(f"  partial                : {n_partial:>5}  ({_pct(n_partial, total)})")
    print(f"  still open (unresolved): {n_open:>5}  ({_pct(n_open, total)})")

    # Throttling overhead (retry_count / total_retry_wait_ms)
    retries = [r["retry_count"] or 0 for r in rows]
    waits = [r["total_retry_wait_ms"] or 0 for r in rows]
    avg_retry = sum(retries) / total if total else 0
    avg_wait = sum(waits) / total if total else 0
    print(f"\n  avg retry_count/order        : {avg_retry:.2f}")
    print(f"  avg total_retry_wait_ms/order: {avg_wait:.1f}ms")
    print("  (NOTE: retry fields are always 0 in v1.0.79 — no retry wrapper exists yet)")

    # Sample-size caveat (handoff §6)
    if n_resolved < 30:
        print("\n  ⚠ LOW SAMPLE: fewer than 30 resolved orders — rejection rate is not statistically meaningful.")
    if len(filled) < 30:
        print("  ⚠ LOW SAMPLE: fewer than 30 filled orders — fill-time percentiles are not statistically meaningful.")

    print("\n" + "=" * 78)
    return 0


def main() -> None:
    parser = argparse.ArgumentParser(description="Polymarket order metrics report")
    parser.add_argument("--mode", choices=["LIVE", "PAPER", "ALL"], default="LIVE",
                        help="Filter rows by mode (default: LIVE — PAPER rows are not informative).")
    parser.add_argument("--db", default=None, help="Override METRICS_DB_PATH.")
    args = parser.parse_args()

    if args.db:
        settings.metrics_db_path = args.db

    try:
        rc = asyncio.run(run_report(args.mode))
    finally:
        asyncio.run(mdb.close_metrics_db())
    sys.exit(rc)


if __name__ == "__main__":
    main()
