#!/usr/bin/env python3
"""
scripts/paper_health.py — Щоденний snapshot здоров&apos;я PAPER-сесії.

Призначення: один погляд на стан бота під час тривалого PAPER-тесту
(7+ днів). Не претендує на повний аналіз — лише &quot;чи живий, чи росте,
чи не падає&quot;.

Вивід:
  - Компактний (за замовч.): один рядок з ключовими метриками
  - Розгорнутий (--verbose): деталі по ринках, P&L, warnings

Джерела даних:
  - mm_bot.db          → таблиці mm_trades, mm_inventory_state
  - order_metrics.db   → таблиця order_events
  - bot.log            → ws_disconnect / warnings / errors / last activity

Usage:
    python scripts/paper_health.py
    python scripts/paper_health.py --log bot.log
    python scripts/paper_health.py --verbose
    python scripts/paper_health.py --json    # для моніторингу/cron

Exit codes:
    0 — OK (бот активний за останні 5 хв)
    1 — STALE (нема активності > 5 хв, можливо завис)
    2 — ERROR (БД недоступна / критична помилка)
    3 — UNKNOWN (не вдалося прочитати джерела)
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sqlite3
import sys
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

# Дозволяємо запуск з будь-якої директорії — додаємо корінь проєкту в sys.path.
_PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

# ── Константи ────────────────────────────────────────────────────────────
DEFAULT_BOT_DB = "mm_bot.db"
DEFAULT_METRICS_DB = "order_metrics.db"
DEFAULT_LOG = "bot.log"
STALE_THRESHOLD_SEC = 300  # 5 хв без quote_placed = STALE

# ANSI-коди structlog виводу (як видно в bot.log)
_ANSI_RE = re.compile(r"\x1b[^a-zA-Z]*[a-zA-Z]")
_LOG_LINE_RE = re.compile(
    r"(\S+)\s+\[\s*(\w+)\s*\]\s+(\w+)\s+(.*)"
)


def _strip_ansi(s: str) -> str:
    return _ANSI_RE.sub("", s)


def _parse_log_line(line: str) -> tuple[str, str, str, str] | None:
    """Повертає (timestamp, level, event, kv) або None."""
    clean = _strip_ansi(line).strip()
    m = _LOG_LINE_RE.match(clean)
    if not m:
        return None
    return m.group(1), m.group(2), m.group(3), m.group(4)


def _parse_ts(ts: str) -> datetime | None:
    """ISO timestamp з логу → datetime (UTC)."""
    try:
        return datetime.fromisoformat(ts.replace("Z", "+00:00"))
    except (ValueError, TypeError):
        return None


def _db_size(path: str) -> str:
    """Розмір файлу БД у зручному форматі."""
    try:
        size = os.path.getsize(path)
    except OSError:
        return "?"
    if size < 1024:
        return f"{size}B"
    if size < 1024 * 1024:
        return f"{size / 1024:.1f}KB"
    return f"{size / (1024 * 1024):.1f}MB"


# ── mm_bot.db читання ────────────────────────────────────────────────────
def _read_bot_db(db_path: str) -> dict:
    """bankroll, fills, P&L, round-trips з mm_bot.db."""
    out = {
        "bankroll": None,
        "starting_balance": None,
        "daily_pnl": None,
        "consecutive_losses": None,
        "fills_total": 0,
        "fills_today": 0,
        "pnl_total": 0.0,
        "pnl_today": 0.0,
        "round_trips_total": 0,  # closing trades (pnl_usdc IS NOT NULL)
        "round_trips_today": 0,
        "fees_total": 0.0,
        "last_fill_ts": None,
        "top_markets": [],
    }
    if not os.path.exists(db_path):
        return out
    try:
        conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()

        # bankroll / state
        try:
            cur.execute(
                "SELECT bankroll, starting_balance, daily_pnl, consecutive_losses, "
                "timestamp FROM mm_inventory_state WHERE id=1"
            )
            row = cur.fetchone()
            if row:
                out["bankroll"] = round(row["bankroll"], 4)
                out["starting_balance"] = round(row["starting_balance"], 4)
                out["daily_pnl"] = round(row["daily_pnl"], 4)
                out["consecutive_losses"] = row["consecutive_losses"]
        except sqlite3.Error:
            pass  # таблиця ще не існує

        # today boundary (UTC)
        now = datetime.now(timezone.utc)
        today_str = now.strftime("%Y-%m-%d") + "%"

        # fills total
        try:
            cur.execute("SELECT COUNT(*) AS n FROM mm_trades")
            out["fills_total"] = cur.fetchone()["n"]
            cur.execute(
                "SELECT COUNT(*) AS n FROM mm_trades WHERE timestamp LIKE ?",
                (today_str,),
            )
            out["fills_today"] = cur.fetchone()["n"]
        except sqlite3.Error:
            pass

        # P&L + round-trips (closing trades = pnl_usdc IS NOT NULL)
        try:
            cur.execute(
                "SELECT COALESCE(SUM(pnl_usdc), 0) AS s, COUNT(*) AS n FROM mm_trades "
                "WHERE pnl_usdc IS NOT NULL"
            )
            row = cur.fetchone()
            out["pnl_total"] = round(row["s"], 4)
            out["round_trips_total"] = row["n"]
            cur.execute(
                "SELECT COALESCE(SUM(pnl_usdc), 0) AS s, COUNT(*) AS n FROM mm_trades "
                "WHERE pnl_usdc IS NOT NULL AND timestamp LIKE ?",
                (today_str,),
            )
            row = cur.fetchone()
            out["pnl_today"] = round(row["s"], 4)
            out["round_trips_today"] = row["n"]
        except sqlite3.Error:
            pass

        # fees
        try:
            cur.execute("SELECT COALESCE(SUM(fees_usdc), 0) AS s FROM mm_trades")
            out["fees_total"] = round(cur.fetchone()["s"], 4)
        except sqlite3.Error:
            pass

        # last fill
        try:
            cur.execute(
                "SELECT timestamp FROM mm_trades ORDER BY id DESC LIMIT 1"
            )
            row = cur.fetchone()
            if row:
                out["last_fill_ts"] = row["timestamp"]
        except sqlite3.Error:
            pass

        # top markets (by fills)
        try:
            cur.execute(
                "SELECT market_name, COUNT(*) AS n FROM mm_trades "
                "GROUP BY market_name ORDER BY n DESC LIMIT 5"
            )
            out["top_markets"] = [
                {"market": r["market_name"][:50], "fills": r["n"]}
                for r in cur.fetchall()
            ]
        except sqlite3.Error:
            pass

        conn.close()
    except sqlite3.Error:
        pass
    return out


# ── order_metrics.db читання ─────────────────────────────────────────────
def _read_metrics_db(db_path: str) -> dict:
    out = {
        "order_events_total": 0,
        "by_mode": {},
        "by_final_status": {},
        "by_category": {},
        "rejected_pre_submit": 0,
    }
    if not os.path.exists(db_path):
        return out
    try:
        conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()
        try:
            cur.execute("SELECT COUNT(*) AS n FROM order_events")
            out["order_events_total"] = cur.fetchone()["n"]
            cur.execute(
                "SELECT mode, COUNT(*) AS n FROM order_events GROUP BY mode"
            )
            out["by_mode"] = {r["mode"]: r["n"] for r in cur.fetchall()}
            cur.execute(
                "SELECT COALESCE(final_status, 'NULL') AS fs, COUNT(*) AS n "
                "FROM order_events GROUP BY final_status"
            )
            out["by_final_status"] = {r["fs"]: r["n"] for r in cur.fetchall()}
            cur.execute(
                "SELECT COALESCE(market_category, 'NULL') AS c, COUNT(*) AS n "
                "FROM order_events GROUP BY market_category"
            )
            out["by_category"] = {r["c"]: r["n"] for r in cur.fetchall()}
            cur.execute(
                "SELECT COUNT(*) AS n FROM order_events "
                "WHERE reject_stage='pre_submit_validation'"
            )
            out["rejected_pre_submit"] = cur.fetchone()["n"]
        except sqlite3.Error:
            pass
        conn.close()
    except sqlite3.Error:
        pass
    return out


# ── bot.log читання ──────────────────────────────────────────────────────
def _read_log(log_path: str) -> dict:
    out = {
        "last_event_ts": None,
        "last_event": None,
        "last_quote_ts": None,
        "ws_disconnects": 0,
        "warnings": 0,
        "errors": 0,
        "events_total": 0,
        "events_today": 0,
        "top_events": [],
        "last_warnings": [],
    }
    if not os.path.exists(log_path):
        return out

    now = datetime.now(timezone.utc)
    today_str = now.strftime("%Y-%m-%d")
    event_counter: Counter[str] = Counter()
    recent_warns: list[str] = []

    try:
        with open(log_path, "r", errors="replace") as f:
            for line in f:
                parsed = _parse_log_line(line)
                if not parsed:
                    continue
                ts_str, level, event, kv = parsed
                out["events_total"] += 1
                if ts_str.startswith(today_str):
                    out["events_today"] += 1
                out["last_event_ts"] = ts_str
                out["last_event"] = event

                if level == "warning":
                    out["warnings"] += 1
                    if len(recent_warns) < 5:
                        recent_warns.append(f"{ts_str[11:19]} {event}: {kv[:100]}")
                elif level == "error":
                    out["errors"] += 1
                    if len(recent_warns) < 5:
                        recent_warns.append(f"{ts_str[11:19]} {event}: {kv[:100]}")

                if event == "ws_disconnect":
                    out["ws_disconnects"] += 1
                elif event == "quote_placed":
                    out["last_quote_ts"] = ts_str

                event_counter[event] += 1
    except OSError:
        pass

    out["top_events"] = event_counter.most_common(10)
    out["last_warnings"] = recent_warns

    # Stale check: чи була активність за останні 5 хв
    out["stale"] = False
    if out["last_quote_ts"]:
        last = _parse_ts(out["last_quote_ts"])
        if last:
            age = (now - last).total_seconds()
            out["stale"] = age > STALE_THRESHOLD_SEC
            out["last_activity_sec_ago"] = int(age)
    else:
        out["last_activity_sec_ago"] = None

    return out


# ── Форматування виводу ──────────────────────────────────────────────────
def _fmt_compact(bot: dict, metrics: dict, log: dict, args) -> str:
    """Один рядок з ключовими метриками."""
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%SZ")
    bankroll = bot["bankroll"]
    bankroll_s = f"${bankroll:.2f}" if bankroll is not None else "?"
    daily = bot["daily_pnl"]
    daily_s = f"${daily:+.2f}" if daily is not None else "?"
    total = bot["pnl_total"]
    total_s = f"${total:+.2f}" if total is not None else "?"

    fills_t = bot["fills_today"]
    fills_all = bot["fills_total"]
    rts_t = bot["round_trips_today"]

    oe = metrics["order_events_total"]
    disc = log["ws_disconnects"]
    warns = log["warnings"]
    errs = log["errors"]

    stale_flag = "⚠STALE" if log.get("stale") else "OK"

    return (
        f"[{now}] {stale_flag} | "
        f"bank={bankroll_s} daily={daily_s} total={total_s} | "
        f"fills: {fills_t}today/{fills_all}total rts={rts_t} | "
        f"order_events={oe} | "
        f"ws_disc={disc} warn={warns} err={errs}"
    )


def _fmt_verbose(bot: dict, metrics: dict, log: dict, args) -> str:
    """Розгорнутий багаторядковий вивід."""
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    lines: list[str] = []
    lines.append("=" * 70)
    lines.append(f"PAPER HEALTH SNAPSHOT — {now}")
    lines.append("=" * 70)

    # Stale status
    if log.get("stale"):
        age = log.get("last_activity_sec_ago")
        lines.append(
            f"⚠ СТАТУС: STALE (нема quote_placed {age}s — поріг {STALE_THRESHOLD_SEC}s)"
        )
    else:
        age = log.get("last_activity_sec_ago")
        age_s = f"{age}s ago" if age is not None else "?"
        lines.append(f"✓ СТАТУС: OK (остання активність {age_s})")

    lines.append("")

    # Bankroll
    lines.append("── BANKROLL ──")
    bankroll = bot["bankroll"]
    start = bot["starting_balance"]
    if bankroll is not None and start is not None:
        diff = bankroll - start
        pct = (diff / start * 100) if start else 0
        lines.append(
            f"  Поточний:      ${bankroll:.4f}  (старт ${start:.2f}, "
            f"Δ ${diff:+.2f} / {pct:+.1f}%)"
        )
    else:
        lines.append("  Поточний: ? (mm_inventory_state порожня)")
    daily = bot["daily_pnl"]
    if daily is not None:
        lines.append(f"  Daily P&L:     ${daily:+.4f}")
    total = bot["pnl_total"]
    if total is not None:
        lines.append(f"  Total P&L:     ${total:+.4f}  (fees paid ${bot['fees_total']:.4f})")
    cl = bot["consecutive_losses"]
    if cl is not None:
        lines.append(f"  Consec. losses: {cl}")
    lines.append("")

    # Fills
    lines.append("── FILLS ──")
    lines.append(
        f"  Сьогодні: {bot['fills_today']} fills, {bot['round_trips_today']} round-trips"
    )
    lines.append(f"  Всього:   {bot['fills_total']} fills, {bot['round_trips_total']} round-trips")
    last_fill = bot["last_fill_ts"]
    lines.append(f"  Останній fill: {last_fill or '—'}")
    lines.append("")

    # Top markets
    if bot["top_markets"]:
        lines.append("── ТОП РИНКІВ (за кіл-стю fills) ──")
        for m in bot["top_markets"]:
            lines.append(f"  {m['fills']:>5}  {m['market']}")
        lines.append("")

    # Order events (v1.0.79 logger)
    lines.append("── ORDER EVENTS (v1.0.79 metrics logger) ──")
    lines.append(f"  Всього рядків: {metrics['order_events_total']}")
    if metrics["by_mode"]:
        mode_s = ", ".join(f"{k}={v}" for k, v in sorted(metrics["by_mode"].items()))
        lines.append(f"  За mode:       {mode_s}")
    if metrics["by_final_status"]:
        status_s = ", ".join(
            f"{k}={v}" for k, v in sorted(metrics["by_final_status"].items())
        )
        lines.append(f"  За status:     {status_s}")
    if metrics["by_category"]:
        cat_s = ", ".join(f"{k}={v}" for k, v in sorted(metrics["by_category"].items()))
        lines.append(f"  За category:   {cat_s}")
    if metrics["rejected_pre_submit"]:
        lines.append(
            f"  ⚠ pre_submit_validation rejects: {metrics['rejected_pre_submit']}"
        )
    lines.append("")

    # Log health
    lines.append("── LOG HEALTH ──")
    lines.append(f"  Подій у логу:  {log['events_total']} всього, {log['events_today']} сьогодні")
    lines.append(f"  ws_disconnect: {log['ws_disconnects']}")
    lines.append(f"  warnings:      {log['warnings']}")
    lines.append(f"  errors:        {log['errors']}")
    if log["last_event"]:
        lines.append(f"  Остання подія: {log['last_event']} @ {log['last_event_ts']}")
    lines.append("")

    # Top events
    if log["top_events"]:
        lines.append("── ТОП ПОДІЙ ──")
        for ev, n in log["top_events"]:
            lines.append(f"  {n:>6}  {ev}")
        lines.append("")

    # Last warnings
    if log["last_warnings"]:
        lines.append("── ОСТАННІ WARNINGS/ERRORS ──")
        for w in log["last_warnings"]:
            lines.append(f"  {w}")
        lines.append("")

    # DB sizes
    lines.append("── РОЗМІР БД ──")
    lines.append(f"  mm_bot.db:        {_db_size(args.bot_db)}")
    lines.append(f"  order_metrics.db: {_db_size(args.metrics_db)}")
    lines.append("")

    lines.append("=" * 70)
    return "\n".join(lines)


def _fmt_json(bot: dict, metrics: dict, log: dict, args) -> str:
    return json.dumps(
        {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "stale": log.get("stale", False),
            "bot": bot,
            "metrics": metrics,
            "log": {
                "last_event_ts": log["last_event_ts"],
                "last_quote_ts": log["last_quote_ts"],
                "ws_disconnects": log["ws_disconnects"],
                "warnings": log["warnings"],
                "errors": log["errors"],
                "events_total": log["events_total"],
                "events_today": log["events_today"],
                "last_activity_sec_ago": log.get("last_activity_sec_ago"),
            },
            "db_sizes": {
                "mm_bot_db": _db_size(args.bot_db),
                "order_metrics_db": _db_size(args.metrics_db),
            },
        },
        indent=2,
        default=str,
    )


def main() -> int:
    parser = argparse.ArgumentParser(
        description="PAPER-сесія health snapshot (v1.0.79)"
    )
    parser.add_argument("--bot-db", default=DEFAULT_BOT_DB,
                        help=f"Шлях до mm_bot.db (за замовч.: {DEFAULT_BOT_DB})")
    parser.add_argument("--metrics-db", default=DEFAULT_METRICS_DB,
                        help=f"Шлях до order_metrics.db (за замовч.: {DEFAULT_METRICS_DB})")
    parser.add_argument("--log", default=DEFAULT_LOG,
                        help=f"Шлях до bot.log (за замовч.: {DEFAULT_LOG})")
    parser.add_argument("--verbose", "-v", action="store_true",
                        help="Розгорнутий вивід")
    parser.add_argument("--json", action="store_true",
                        help="JSON вивід (для cron/моніторингу)")
    args = parser.parse_args()

    bot = _read_bot_db(args.bot_db)
    metrics = _read_metrics_db(args.metrics_db)
    log = _read_log(args.log)

    if args.json:
        print(_fmt_json(bot, metrics, log, args))
    elif args.verbose:
        print(_fmt_verbose(bot, metrics, log, args))
    else:
        print(_fmt_compact(bot, metrics, log, args))

    # Exit code: 0 OK, 1 STALE
    if log.get("stale"):
        return 1
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        sys.exit(130)
    except Exception as e:
        print(f"FATAL: {type(e).__name__}: {e}", file=sys.stderr)
        sys.exit(2)
