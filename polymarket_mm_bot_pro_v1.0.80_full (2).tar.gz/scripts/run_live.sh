#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if [ ! -f .env ]; then
    echo "ERROR: .env not found. Create one (see README for required vars)."
    exit 1
fi
if grep -q "^PAPER_TRADING=true" .env; then
    echo "ERROR: PAPER_TRADING=true. Set to false for LIVE."
    exit 1
fi

# v1.0.58 FIX (BUG-N2): was hardcoded to 8000, mismatched .env ADMIN_PORT=8765.
# Now reads ADMIN_PORT from .env with fallback to 8765.
ADMIN_PORT="$(grep -E '^ADMIN_PORT=' .env | cut -d= -f2 | tr -d '[:space:]' || true)"
ADMIN_PORT="${ADMIN_PORT:-8765}"

echo "LIVE MODE - REAL ORDERS. Start with \$5-20 only."
read -p "Type 'yes' to continue: " confirm
[ "$confirm" = "yes" ] || exit 0
echo "Dashboard: http://127.0.0.1:${ADMIN_PORT}"
exec python -m uvicorn app.main:app --host 127.0.0.1 --port "${ADMIN_PORT}" --log-level info
