#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

# v1.0.58 FIX (BUG-N8): .env.example was missing. Now we create .env from
# a minimal inline default if neither .env nor .env.example exists.
if [ ! -f .env ]; then
    if [ -f .env.example ]; then
        echo "Copying .env.example to .env"
        cp .env.example .env
    else
        echo "ERROR: .env not found and .env.example missing."
        echo "       Create .env manually (see README for required vars)."
        exit 1
    fi
fi

# v1.0.58 FIX (BUG-N2): was hardcoded to 8000, mismatched .env ADMIN_PORT=8765.
# Now reads ADMIN_PORT from .env with fallback to 8765.
ADMIN_PORT="$(grep -E '^ADMIN_PORT=' .env | cut -d= -f2 | tr -d '[:space:]' || true)"
ADMIN_PORT="${ADMIN_PORT:-8765}"

echo "Starting PAPER mode. Dashboard: http://127.0.0.1:${ADMIN_PORT}"
exec python -m uvicorn app.main:app --host 127.0.0.1 --port "${ADMIN_PORT}" --log-level info
