"""
tests/unit/test_inventory_manager.py — Inventory + risk controls tests.

Verifies FIXES:
  #2 — should_quote_bid/ask properly blocks at inventory_clear_threshold
  #6 — resume(preserve_counters=True) keeps daily_pnl + consecutive_losses
"""
from __future__ import annotations

import pytest

from app.services.inventory_manager import InventoryManager


class TestInventoryManager:
    @pytest.fixture
    def inv(self):
        return InventoryManager()

    def test_initial_state(self, inv):
        assert inv.bankroll == inv.starting_balance
        assert not inv.halted
        assert inv.consecutive_losses == 0
        assert inv.daily_pnl == 0.0

    def test_buy_creates_long_position(self, inv):
        realized = inv.on_fill("tok", "BUY", price=0.40, size_usdc=10.0, market_name="Test")
        assert realized == 0.0  # opening trade has no realized P&L
        position = inv.get_inventory("tok")
        assert position.net_tokens > 0
        assert position.avg_entry_price == 0.40
        assert inv.bankroll == inv.starting_balance - 10.0

    def test_sell_closes_long_with_profit(self, inv):
        inv.on_fill("tok", "BUY", price=0.40, size_usdc=10.0, market_name="Test")
        realized = inv.on_fill("tok", "SELL", price=0.50, size_usdc=10.0, market_name="Test")
        # Bought 25 tokens (10/0.4). Sold 20 tokens (10/0.5).
        # Closed portion = 20 tokens. P&L = (0.50 - 0.40) * 20 = 2.0
        assert realized == pytest.approx(2.0, rel=0.01)

    def test_sell_closes_long_with_loss(self, inv):
        inv.on_fill("tok", "BUY", price=0.50, size_usdc=10.0, market_name="Test")
        realized = inv.on_fill("tok", "SELL", price=0.40, size_usdc=10.0, market_name="Test")
        # P&L = (0.40 - 0.50) * 20 tokens = -2.0
        assert realized == pytest.approx(-2.0, rel=0.01)
        assert inv.consecutive_losses == 1

    def test_consecutive_losses_trigger_halt(self, inv):
        """5 consecutive losses (default) → halt."""
        # 5 losing round-trips
        for _ in range(5):
            inv.on_fill("tok", "BUY", price=0.50, size_usdc=10.0, market_name="Test")
            inv.on_fill("tok", "SELL", price=0.49, size_usdc=10.0, market_name="Test")
        assert inv.halted
        assert "CONSECUTIVE_LOSSES" in inv.halt_reason

    def test_daily_loss_triggers_halt(self, inv):
        """Single large loss > max_daily_loss → halt."""
        from app.core.config import settings

        # Override for test
        orig = settings.max_daily_loss_usd
        settings.max_daily_loss_usd = 1.0
        try:
            inv.on_fill("tok", "BUY", price=0.50, size_usdc=50.0, market_name="Test")
            inv.on_fill("tok", "SELL", price=0.30, size_usdc=50.0, market_name="Test")
            # Loss = (0.30 - 0.50) * 100 tokens = -20.0
            assert inv.halted
            assert "DAILY_LOSS" in inv.halt_reason
        finally:
            settings.max_daily_loss_usd = orig

    def test_should_quote_bid_blocks_at_clear_threshold(self, inv):
        """FIX #2: bid should be blocked when long inventory ≥ clear_threshold.

        With bankroll=$100 (test default), max_inventory_usdc = max($5, 25%×$100=$25) = $25.
        Need $20+ position to trigger block (ratio ≥ 0.8).
        """
        # Build up a large long position (>80% of max)
        # max = $25, 80% = $20, buy $25 worth to exceed
        inv.on_fill("tok", "BUY", price=0.50, size_usdc=25.0, market_name="Test")
        # ratio = 25/25 = 1.0 > 0.8 → blocked
        assert not inv.should_quote_bid("tok"), "Bid should be blocked when long inventory at clear_threshold"

    def test_should_quote_ask_blocks_at_clear_threshold(self, inv):
        """FIX #2: ask should be blocked when short inventory near max.

        With bankroll=$100, max=$25. $25 short → ratio=-1.0 → blocked.
        """
        inv.on_fill("tok", "SELL", price=0.50, size_usdc=25.0, market_name="Test")
        # net_usdc_at_entry = -25, ratio = -1.0 < -0.8 → ask blocked
        assert not inv.should_quote_ask("tok"), "Ask should be blocked when short inventory at clear_threshold"

    def test_quote_skew_zero_when_flat(self, inv):
        assert inv.quote_skew("tok") == 0.0

    def test_quote_skew_negative_when_long(self, inv):
        """Long inventory → negative skew (shift quotes DOWN to encourage selling).

        With bankroll=$100, max=$25. Need position >25% of max (=threshold 0.25).
        Buy $10 → ratio=0.4 > 0.25 → skew active, negative.
        """
        inv.on_fill("tok", "BUY", price=0.50, size_usdc=10.0, market_name="Test")
        skew = inv.quote_skew("tok")
        assert skew < 0, f"Long should give negative skew, got {skew}"

    def test_quote_skew_positive_when_short(self, inv):
        """Short inventory → positive skew (shift quotes UP to encourage buying).

        With bankroll=$100, max=$25. $10 short → ratio=-0.4, |ratio|>0.25.
        """
        inv.on_fill("tok", "SELL", price=0.50, size_usdc=10.0, market_name="Test")
        skew = inv.quote_skew("tok")
        assert skew > 0, f"Short should give positive skew, got {skew}"

    def test_resume_preserves_counters(self, inv):
        """FIX #6: resume(preserve_counters=True) keeps daily_pnl + consecutive_losses."""
        # Trigger a loss
        inv.on_fill("tok", "BUY", price=0.50, size_usdc=10.0, market_name="Test")
        inv.on_fill("tok", "SELL", price=0.45, size_usdc=10.0, market_name="Test")
        assert inv.consecutive_losses == 1
        assert inv.daily_pnl < 0

        # Halt manually
        inv.halt(reason="STALE_DATA", detail="WS silent 35s")
        assert inv.halted

        # Resume with preserved counters (transient halt)
        inv.resume(preserve_counters=True)
        assert not inv.halted
        assert inv.consecutive_losses == 1, "Counters should be preserved"
        assert inv.daily_pnl < 0, "Daily P&L should be preserved"

    def test_resume_resets_counters_by_default(self, inv):
        """Default resume resets consecutive_losses (manual user resume)."""
        inv.on_fill("tok", "BUY", price=0.50, size_usdc=10.0, market_name="Test")
        inv.on_fill("tok", "SELL", price=0.45, size_usdc=10.0, market_name="Test")
        inv.halt(reason="MANUAL", detail="user")
        inv.resume(preserve_counters=False)
        assert inv.consecutive_losses == 0

    def test_daily_pnl_rollover_at_midnight(self, inv):
        """daily_pnl should reset when date changes."""
        inv.daily_pnl = -5.0
        inv.daily_pnl_date = "2020-01-01"  # ancient
        # Trigger any operation that calls _rollover_daily_pnl_if_needed
        inv.on_fill("tok", "BUY", price=0.50, size_usdc=1.0, market_name="Test")
        # After rollover, daily_pnl should be 0 + this fill's realized (0 for opening)
        assert inv.daily_pnl_date != "2020-01-01"
        assert inv.daily_pnl == 0.0
