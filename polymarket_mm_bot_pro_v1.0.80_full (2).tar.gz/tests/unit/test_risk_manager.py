"""
tests/unit/test_risk_manager.py — Risk manager + circuit breakers tests.
"""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from app.services.risk.adverse_selection import AdverseSelection
from app.services.risk.circuit_breakers import CircuitBreakers
from app.services.risk.risk_manager import RiskManager


class TestCircuitBreakers:
    @pytest.fixture
    def cbs(self):
        return CircuitBreakers()

    @pytest.fixture
    def mock_inventory(self):
        inv = MagicMock()
        inv.bankroll = 100.0
        inv.daily_pnl = 0.0
        inv.consecutive_losses = 0
        return inv

    @pytest.fixture
    def mock_clob(self):
        clob = MagicMock()
        clob.last_ws_msg_age = 1.0
        return clob

    def test_emergency_stop_trips(self, cbs, mock_inventory, mock_clob):
        cbs.emergency_stop()
        should, reason = cbs.check_all(mock_inventory, mock_clob)
        assert should
        assert "EMERGENCY_STOP" in reason

    def test_reset_emergency_stop(self, cbs, mock_inventory, mock_clob):
        cbs.emergency_stop()
        cbs.reset_emergency_stop()
        should, _ = cbs.check_all(mock_inventory, mock_clob)
        assert not should

    def test_min_balance_in_paper_mode(self, cbs):
        """Min balance check is skipped in PAPER mode."""
        from app.core.config import settings

        orig = settings.paper_trading
        settings.paper_trading = True
        try:
            inv = MagicMock()
            inv.bankroll = 0.01  # below min
            should, _ = cbs.check_min_balance(inv)
            assert not should, "Min balance check should be skipped in PAPER"
        finally:
            settings.paper_trading = orig

    def test_daily_loss_trips(self, cbs):
        from app.core.config import settings

        inv = MagicMock()
        inv.daily_pnl = -settings.max_daily_loss_usd - 0.01
        should, reason = cbs.check_daily_loss(inv)
        assert should
        assert "DAILY_LOSS" in reason

    def test_consecutive_losses_trips(self, cbs):
        from app.core.config import settings

        inv = MagicMock()
        inv.consecutive_losses = settings.stop_trading_consecutive_losses
        should, reason = cbs.check_consecutive_losses(inv)
        assert should
        assert "CONSECUTIVE_LOSSES" in reason

    def test_stale_data_trips(self, cbs):
        from app.core.config import settings

        clob = MagicMock()
        clob.last_ws_msg_age = settings.stale_data_threshold_sec + 1
        should, reason = cbs.check_stale_data(clob)
        assert should
        assert "STALE_DATA" in reason

    def test_major_move_detection(self, cbs):
        """A large price move in 60s should trigger."""
        # Need 5+ samples for the check to activate
        token_id = "test-tok"
        for p in [0.50, 0.50, 0.50, 0.50, 0.50]:
            cbs.check_major_move(token_id, p)
        # Now jump to 0.55 (5¢ move)
        moved, reason = cbs.check_major_move(token_id, 0.55)
        assert moved
        assert "MAJOR_MOVE" in reason

    def test_no_major_move_below_threshold(self, cbs):
        """Small moves should not trigger."""
        token_id = "test-tok2"
        cbs.check_major_move(token_id, 0.50)
        moved, _ = cbs.check_major_move(token_id, 0.501)
        assert not moved


class TestAdverseSelection:
    def test_no_trigger_with_empty_history(self):
        adv = AdverseSelection()
        assert not adv.check_trigger("tok")

    def test_trigger_on_sharp_move(self):
        """A >3¢ move in 10s should trigger cooldown."""
        from app.core.config import settings

        adv = AdverseSelection()
        # Simulate history: 0.50 → 0.54 (4¢ move)
        import time

        now = time.monotonic()
        for p in [0.50, 0.50, 0.51, 0.52, 0.53, 0.54]:
            adv._price_history.setdefault("tok", __import__("collections").deque(maxlen=120))
            adv._price_history["tok"].append((now, p))
            now += 1
        # Set last sample to current time
        adv._price_history["tok"].append((time.monotonic(), 0.54))
        triggered = adv.check_trigger("tok")
        # Triggered if move >= threshold
        assert triggered

    def test_cooldown_after_trigger(self):
        """After trigger, token should be in cooldown."""
        adv = AdverseSelection()
        import time

        now = time.monotonic()
        adv._price_history["tok"] = __import__("collections").deque(maxlen=120)
        adv._price_history["tok"].append((now - 5, 0.50))
        adv._price_history["tok"].append((now, 0.55))  # 5¢ move
        adv.check_trigger("tok")
        assert adv.is_in_cooldown("tok")

    def test_permanent_block_after_poor_win_rate(self):
        """20+ fills with <30% win rate → permanent block."""
        import time as _time
        from app.core.config import settings

        adv = AdverseSelection()
        # Use a short window for test (mock the setting)
        orig_window = settings.adverse_selection_window_sec
        settings.adverse_selection_window_sec = 0.01  # 10ms
        try:
            # Record 20 BUY fills at mid=0.50
            for _ in range(20):
                adv.record_fill("tok", "BUY", fill_price=0.50, mid_at_fill=0.50)
            # Wait for fills to age past window
            _time.sleep(0.05)
            # Now track price dropping (so all buys were adverse)
            adv.track_price("tok", 0.40)  # mid fell 10¢
            # Should be permanently blocked
            assert adv.is_in_cooldown("tok")
            stats = adv.get_stats("tok")
            assert stats["permanently_blocked"]
        finally:
            settings.adverse_selection_window_sec = orig_window


class TestRiskManager:
    @pytest.fixture
    def risk(self):
        from app.services.inventory_manager import InventoryManager
        from app.services.clob_client import ClobService

        inv = InventoryManager()
        clob = MagicMock(spec=ClobService)
        clob.last_ws_msg_age = 1.0
        clob.books = {}
        return RiskManager(inv, clob)

    def test_should_quote_returns_decision(self, risk, sample_book):
        from app.services.clob_client import MarketBook

        decision = risk.should_quote("tok", sample_book)
        assert hasattr(decision, "allow_bid")
        assert hasattr(decision, "allow_ask")
        assert hasattr(decision, "reasons")

    def test_emergency_stop_sets_halt(self, risk):
        risk.emergency_stop()
        assert risk.inventory.halted
        assert "EMERGENCY_STOP" in risk.inventory.halt_reason

    def test_resume_clears_emergency(self, risk):
        risk.emergency_stop()
        risk.resume()
        # After resume, emergency flag is cleared
        assert not risk.circuit_breakers._emergency_stop_triggered
