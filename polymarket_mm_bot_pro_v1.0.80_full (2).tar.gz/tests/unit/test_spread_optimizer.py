"""
tests/unit/test_spread_optimizer.py — Spread computation tests.
"""
from __future__ import annotations

import pytest

from app.services.pricing.spread_optimizer import SpreadOptimizer


class TestSpreadOptimizer:
    def test_base_case(self):
        from app.core.config import settings

        spread = SpreadOptimizer.compute(
            base_spread_cents=settings.spread_cents,
            sigma=0.01,  # 1% volatility
            kyle_mult=1.0,
            session_mult=1.0,
        )
        # Should be near base spread (low vol, balanced)
        assert settings.spread_min_cents <= spread <= settings.spread_max_cents

    def test_high_volatility_widens_spread(self):
        from app.core.config import settings

        low_vol = SpreadOptimizer.compute(
            base_spread_cents=4.0,
            sigma=0.005,
            kyle_mult=1.0,
            session_mult=1.0,
        )
        high_vol = SpreadOptimizer.compute(
            base_spread_cents=4.0,
            sigma=0.05,
            kyle_mult=1.0,
            session_mult=1.0,
        )
        assert high_vol > low_vol, "High volatility should widen spread"

    def test_imbalance_widens_spread(self):
        low_imb = SpreadOptimizer.compute(
            base_spread_cents=4.0, sigma=0.01, kyle_mult=1.0, session_mult=1.0
        )
        high_imb = SpreadOptimizer.compute(
            base_spread_cents=4.0, sigma=0.01, kyle_mult=3.0, session_mult=1.0
        )
        assert high_imb > low_imb

    def test_clamped_to_min(self):
        from app.core.config import settings

        spread = SpreadOptimizer.compute(
            base_spread_cents=1.0,  # below min
            sigma=0.001,
            kyle_mult=0.5,  # below 1
            session_mult=0.5,
        )
        assert spread >= settings.spread_min_cents

    def test_clamped_to_max(self):
        from app.core.config import settings

        spread = SpreadOptimizer.compute(
            base_spread_cents=20.0,  # above max
            sigma=0.10,
            kyle_mult=5.0,
            session_mult=2.0,
        )
        assert spread <= settings.spread_max_cents

    def test_aging_discount_reduces_spread(self):
        no_discount = SpreadOptimizer.compute(
            base_spread_cents=4.0, sigma=0.01, kyle_mult=1.0, session_mult=1.0
        )
        with_discount = SpreadOptimizer.compute(
            base_spread_cents=4.0,
            sigma=0.01,
            kyle_mult=1.0,
            session_mult=1.0,
            aging_discount_cents=1.0,
        )
        assert with_discount < no_discount

    def test_multi_level_returns_3_levels(self):
        from app.core.config import settings

        orig = settings.multi_level_enabled
        settings.multi_level_enabled = True
        try:
            levels = SpreadOptimizer.compute_levels(spread_cents=4.0)
            assert len(levels) == 3
            # Captures should be ascending (level 1 tightest)
            assert levels[0][0] < levels[1][0] < levels[2][0]
            # Sizes should sum to 1.0
            total_size = sum(s for _, s in levels)
            assert 0.99 <= total_size <= 1.01
        finally:
            settings.multi_level_enabled = orig

    def test_multi_level_capture_proportional_to_spread(self):
        """FIX: capture must scale with spread_cents, not be fixed.

        At spread=4¢, level 1 capture = 0.15 × 4 = 0.6¢
        At spread=10¢, level 1 capture = 0.15 × 10 = 1.5¢
        """
        from app.core.config import settings

        orig = settings.multi_level_enabled
        settings.multi_level_enabled = True
        try:
            levels_4 = SpreadOptimizer.compute_levels(spread_cents=4.0)
            levels_10 = SpreadOptimizer.compute_levels(spread_cents=10.0)
            # Level 1 capture at spread=10 should be 2.5x the capture at spread=4
            ratio = levels_10[0][0] / levels_4[0][0]
            assert ratio == pytest.approx(2.5, rel=0.01), (
                f"Capture should scale with spread; got ratio {ratio}, expected 2.5"
            )
            # Sanity: at spread=4, level 1 capture should be 0.6¢ (not 0.15¢)
            assert levels_4[0][0] == pytest.approx(0.6, rel=0.01), (
                f"At spread=4¢, level 1 capture should be 0.6¢, got {levels_4[0][0]}"
            )
        finally:
            settings.multi_level_enabled = orig

    def test_single_level_when_disabled(self):
        from app.core.config import settings

        orig = settings.multi_level_enabled
        settings.multi_level_enabled = False
        try:
            levels = SpreadOptimizer.compute_levels(spread_cents=4.0)
            assert len(levels) == 1
            assert levels[0][1] == 1.0  # 100% size
        finally:
            settings.multi_level_enabled = orig

    def test_session_multiplier(self):
        mult, name = SpreadOptimizer.get_session_multiplier()
        assert name in ("active", "quiet", "normal", "disabled")
        assert mult > 0
